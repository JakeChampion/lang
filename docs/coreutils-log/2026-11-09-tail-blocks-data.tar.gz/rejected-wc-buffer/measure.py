import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/work/wc-buffer-evidence')
repo = Path('/workspace/work/lang-coreutils-io')
data = Path('/workspace/work/wc-evidence/inputs/text-64m.txt')
hf = '/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine'
gnu = Path('/workspace/work/gnu-9.12/bin')
bins = {'base': root / 'base/wc', 'candidate': root / 'candidate/wc', 'gnu': gnu / 'wc'}
cases = {'lines': ['-l'], 'bytes': ['-c'], 'all': [], 'words': ['-w'], 'width': ['-L'], 'pipe': ['-l']}
env = dict(os.environ, LC_ALL='C', TZ='UTC')
env.pop('POSIXLY_CORRECT', None)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def argv(name, case):
    if case == 'pipe':
        return ['bash', '-o', 'pipefail', '-c', command(name, case)]
    return [str(bins[name]), *cases[case], str(data)]


def command(name, case):
    if case == 'pipe':
        return f'{gnu}/cat {data} | {bins[name]} -l'
    return ' '.join([str(bins[name]), *cases[case], str(data)])


meta = {
    'started': time.time(),
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'diff': subprocess.check_output(['git', 'diff'], cwd=repo, text=True),
    'input': {'path': str(data), 'sha256': digest(data), 'bytes': data.stat().st_size},
    'binaries': {name: {'path': str(path), 'sha256': digest(path)} for name, path in bins.items()},
    'compiler': {'path': '/workspace/work/wc-evidence/baseline/compiler', 'sha256': digest('/workspace/work/wc-evidence/baseline/compiler')},
    'gnu_version': subprocess.check_output([gnu / 'wc', '--version'], text=True).splitlines()[0],
    'hyperfine_version': subprocess.check_output([hf, '--version'], text=True).strip(),
    'parity': {},
    'limitations': ['One shared EPYC Linux x86-64 host.', 'The pending count-kernel PR is absent from both buffer candidates.'],
}
for case in cases:
    outcomes = {}
    for name in bins:
        r = subprocess.run(argv(name, case), env=env, capture_output=True)
        outcomes[name] = {'stdout': r.stdout.decode(), 'stderr': r.stderr.decode(), 'status': r.returncode}
    assert all(v == outcomes['gnu'] for v in outcomes.values()), (case, outcomes)
    meta['parity'][case] = outcomes
(root / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
summary = {}
for order, names in [('forward', list(bins)), ('reverse', list(reversed(bins)))]:
    for case in cases:
        path = root / f'{case}-{order}.json'
        args = [hf, '--warmup', '5', '--runs', '80', '--export-json', str(path)]
        args += ['--shell=bash -o pipefail'] if case == 'pipe' else ['-N']
        for name in names:
            args += ['--command-name', name, command(name, case)]
        subprocess.run(args, env=env, check=True)
        results = json.loads(path.read_text())['results']
        assert len(results) == 3
        assert {r['name'] for r in results} == set(bins)
        for r in results:
            assert len(r['measurements']) == 80
            assert all(m['exit_code'] == 0 for m in r['measurements'])
        summary[f'{case}-{order}'] = {r['name']: r['summary']['time_wall_clock'] for r in results}
assert meta['diff'] == subprocess.check_output(['git', 'diff'], cwd=repo, text=True)
meta['finished'] = time.time()
(root / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for name, row in summary.items():
    print(name, {n: round(r['mean'] * 1000, 3) for n, r in row.items()})
