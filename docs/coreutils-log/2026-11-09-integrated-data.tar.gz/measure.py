import json,hashlib,os,pathlib,subprocess,shlex,time
p=pathlib.Path('/workspace/work/integrated-coreutils');gnu=pathlib.Path('/workspace/work/gnu-9.12/bin');repo=pathlib.Path('/workspace/work/lang-coreutils')
hf='/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine';rows=json.loads((p/'workloads.json').read_text());identity=json.loads((p/'identity.json').read_text())
env=dict(os.environ,LC_ALL='C',TZ='UTC');env.pop('POSIXLY_CORRECT',None)
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
meta={'identity':identity,'started':time.time(),'hyperfine':subprocess.check_output([hf,'--version'],text=True).strip(),'partner_cat_sha256':sha(gnu/'cat'),'commands':[],'parity':[]}
for row in rows:
 outcomes={}
 for name,exe in [('fern',p/row['utility']),('gnu',gnu/row['utility'])]:
  cmd=row['command'].replace('{}',str(exe)).replace('{gnu}',str(gnu))
  if cmd.endswith(' > /dev/null'):cmd=cmd[:-len(' > /dev/null')]
  args=['bash','-o','pipefail','-c',cmd] if row['shell']=='y' else shlex.split(cmd)
  r=subprocess.run(args,env=env,capture_output=True)
  outcomes[name]={'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stdout_bytes':len(r.stdout),'stderr_hex':r.stderr.hex(),'status':r.returncode}
 assert outcomes['fern']==outcomes['gnu'],(row,outcomes)
 meta['parity'].append({'workload':row,'outcomes':outcomes})
(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
summary=[]
for order,names in [('forward',['fern','gnu']),('reverse',['gnu','fern'])]:
 for i,row in enumerate(rows):
  out=p/f'row{i:02}-{order}.json';args=[hf,'--warmup','5','--runs','80','--export-json',str(out)]
  args+=['--shell=bash -o pipefail'] if row['shell']=='y' else ['-N']
  for name in names:
   exe=p/row['utility'] if name=='fern' else gnu/row['utility'];cmd=row['command'].replace('{}',str(exe)).replace('{gnu}',str(gnu));args+=['--command-name',name,cmd]
  meta['commands'].append(args);(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
  subprocess.run(args,env=env,check=True)
  rs=json.loads(out.read_text())['results'];assert {r['name'] for r in rs}=={'fern','gnu'}
  assert all(len(r['measurements'])==80 and all(m['exit_code']==0 for m in r['measurements']) for r in rs)
  t={r['name']:r['summary']['time_wall_clock'] for r in rs};ratio=t['gnu']['mean']/t['fern']['mean']
  summary.append({'row':i,'order':order,'label':row['label'],'utility':row['utility'],'times':t,'gnu_ratio':ratio,'classification':'ahead' if ratio>1.1 else 'losing' if ratio<.9 else 'noisy'})
  (p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
meta['finished']=time.time();meta['source_head_after']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert meta['source_head_after']==identity['source_head']
assert all(sha(p/u)==identity['binaries'][u]['fern_sha256'] for u in ['wc','tail'])
(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for r in summary:print(r['order'],r['label'],{n:round(v['mean']*1000,3) for n,v in r['times'].items()},round(r['gnu_ratio'],3),r['classification'])
