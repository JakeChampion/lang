import pathlib,subprocess,json,hashlib,statistics,platform,tarfile,shutil,time
p=pathlib.Path('/workspace/work/chown-evidence');repo=pathlib.Path('/workspace/work/lang-coreutils');base='12be8f11864c00d71bc3ae9e0c3bc1ddabea75ef';code='f8085868b695750875005752bf0190e90d7e092c';tree='41a1d48414886bc18e58d0937d6c0620ebad76a9'
def run(*args):return subprocess.check_output(args,cwd=repo,text=True).strip()
def sha(f):return hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
def write(name,obj): (p/name).write_text(json.dumps(obj,indent=2)+'\n')
primary=json.loads((p/'summary.json').read_text());original=json.loads((p/'metadata.json').read_text());summaries={}
for sub in ['balanced','direct-loop']:
 rows=json.loads((p/sub/'summary.json').read_text());assert len(rows)==36;assert len(json.loads((p/sub/'metadata.json').read_text())['commands'])==36
 summaries[sub]=[]
 for i in [1,3,4,11,13,14]:
  rr=[r for r in rows if r['row']==i];t={n:statistics.mean(r['times'][n]['mean']/25 for r in rr) for n in ['base','candidate','gnu']}
  summaries[sub].append({'row':i,'label':rr[0]['label'],'mean_per_utility_ms':{n:v*1000 for n,v in t.items()},'reduction_pct':(1-t['candidate']/t['base'])*100,'gnu_ratio':t['gnu']/t['candidate'],'round_reductions_pct':[(1-r['times']['candidate']['mean']/r['times']['base']['mean'])*100 for r in rr]})
 write(sub+'/aggregate.json',summaries[sub])
valid=[]
for sub,count,runs in [('',40,80),('balanced',36,10),('direct-loop',36,10)]:
 files=list((p/sub).glob('row*.json'));assert len(files)==count
 for f in sorted(files):
  data=json.loads(f.read_text());assert len(data['results'])==3
  for result in data['results']:
   assert len(result['measurements'])==runs and all(x['exit_code']==0 for x in result['measurements'])
  valid.append({'file':str(f.relative_to(p)),'sha256':sha(f),'samples':runs*3})
assert sum(x['samples'] for x in valid)==11760
write('sample-validation.json',{'checked_at':time.time(),'samples':11760,'primary':9600,'repeated_shell':1080,'direct_loop':1080,'rejected':0,'files':valid,'original_primary_source_patch_preserved':original['patch']==run('git','diff',base,'HEAD')+'\n','wrapper_limitation':'Direct-loop exec wrapper reported status1 after all36 blocks, final finished metadata and all6 summary lines. Raw commands all exit0. Independent strict raw-file validation passes; wrapper status is not a passed check. No rerun, filtering or substitution.'})
assert run('git','diff',base,'HEAD','--','compiler','internal/stdlib','bootstrap')==''
(p/'candidate.patch').write_text(run('git','diff',base,'HEAD')+'\n')
sourcefiles=['coreutils/chown.fern','internal/testing/coreutils/chown_test.go','internal/testing/coreutils/chgrp_test.go']
for f in sourcefiles:
 dest=p/'sources'/f;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/f,dest)
(p/'base-source-inventory.txt').write_text(run('git','ls-tree','-r',base,'compiler','internal/stdlib','coreutils','bootstrap')+'\n')
identities={'base_main':base,'local_code_commit':run('git','rev-parse','HEAD'),'published_code_commit':code,'code_tree':tree,'compiler_sha256':sha(p/'base/compiler'),'compiler_and_libraries_unchanged':True,'stage0_sha256':'4698ff2c2123df02546ba2eb419e402018d59db811e75ce236269fd76786f0a3','platform':platform.uname()._asdict(),'model':next(x.split(':',1)[1].strip() for x in pathlib.Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')),'files':{f:{'git_blob':run('git','hash-object',f),'sha256':sha(repo/f)} for f in sourcefiles},'binaries':original['binaries'],'tools':{str(f):sha(f) for f in [pathlib.Path('/workspace/work/gnu-arm-dynamic-9.12/bin/chown'),pathlib.Path('/workspace/work/gnu-arm-dynamic-9.12/bin/chgrp'),pathlib.Path('/workspace/work/arm-tools/root/usr/bin/qemu-aarch64'),pathlib.Path('/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine')]},'sanitized_binaries':{f.name:sha(f) for f in (p/'sanitized').glob('*-linux')},'versions':original['versions'],'source_limit':'These measurements qualify this exact source and compiler only. Main later advanced. They do not qualify a later integrated source.'};write('identities.json',identities)
checks={'native':{'chown_cases':230,'chgrp_cases':150,'skips':0,'help_version':'pass'},'emulated_arm':{'chown_cases':230,'chgrp_cases':150,'skips':0,'help_version':'pass'},'sanitized_cases':94,'sanitized_effects':'Exact native GNU9.12 output/status/modes/ownership/tree. Native x86 and emulated ARM candidate. Census balanced, no sanitizer findings.','negative_controls':'Both new chown regressions fail on unchanged12be baseline. Corrected pattern and original pattern both retained.','checks':['Pinned bootstrap and smoke','full sourcelint','compiler/stdlib complexity ratchet','Go vet coreutils package','gofmt changed Go tests','Fern format changed source','git diff --check'],'wasi':'chown/chgrp capability refusal E066 retained. No added WASI capability.','darwin':'No native Darwin host. Hosted normal platform gates remain required.'};write('checks.json',checks)
commands='''Source /workspace/work/toolchain-env.sh before Go/Wasmtime commands.
Native: FERN_SELFHOST=/workspace/work/chown-evidence/base/compiler FERN_SELFHOST_BUILD_CACHE=/workspace/work/selfhost-test-cache FERN_GNU_COREUTILS=/workspace/work/gnu-9.12/bin go test ./internal/testing/coreutils -run '^(TestChown|TestChgrp)' -count=1 -v
ARM: same compiler/cache, PATH add /workspace/work/arm-tools/root/usr/bin and LD_LIBRARY_PATH /workspace/work/arm-tools/root/usr/lib/x86_64-linux-gnu; FERN_COREUTILS_TARGET=arm64-linux FERN_REQUIRE_ARM64_TOOLING=1 FERN_GNU_COREUTILS=/workspace/work/gnu-arm-dynamic-9.12/bin FERN_COREUTILS_QEMU='/workspace/work/arm-tools/root/usr/bin/qemu-aarch64 -L /workspace/work/arm-tools/root/usr/aarch64-linux-gnu' go test ./internal/testing/coreutils -run '^(TestChown|TestChgrp)' -count=1 -v
Sanitized build each utility and target: FERN_SANITIZE=1 FERN_LEAKCHECK=1 /workspace/work/chown-evidence/base/compiler -target TARGET -o BINARY /workspace/work/lang-coreutils/coreutils/UTILITY.fern /workspace/work/lang-coreutils/internal/stdlib
Sanitized corpus: python3 sanitized/probe.py
Full source lint: go test ./internal/testing/sourcelint -count=1
Complexity: FERN_SELFHOST=/workspace/work/chown-evidence/base/compiler FERN_SELFHOST_BUILD_CACHE=/workspace/work/selfhost-test-cache go test ./internal/testing/e2ecompiler -run '^TestSelfHostRepoComplexityRatchet$' -count=1 -v
Go vet: go vet ./internal/testing/coreutils
Primary: python3 measure.py; exact Hyperfine command argv in metadata.json
Repeated original shell: python3 balanced-driver-original.py; exact argv in balanced/metadata.json
Direct-loop cost diagnostic: python3 direct-loop.py; exact argv in direct-loop/metadata.json
Negative baseline: same test environment in /workspace/work/lang-coreutils-owner-baseline, only new test files copied, go test ./internal/testing/coreutils -run '^TestChown$/(set-id-effects-:-$|nonrecursive-link--L--v-broken$)' -count=1 -v
Bootstrap: bash bootstrap/bootstrap.sh; pinned stage0 identity in base/bootstrap.log
''';(p/'commands.txt').write_text(commands)
ledger=json.loads(pathlib.Path('/workspace/work/stat-evidence/catalogue-ledger.json').read_text());ledger['partial_owner_quiet']={'source':identities,'stop_condition_met':False,'utility_wide_win':False,'qualification':'All20 original rows retained. Short shell calibration and unchanged controls drift. Repeated-shell improvements remain below10%. Direct-loop results isolate utility cost with a distinct launcher; do not replace original rows or claim full utility acceptance.','observations':[]}
for i in range(20):
 rows=[r for r in primary if r['row']==i];ratios=[r['times']['gnu']['mean']/r['times']['candidate']['mean'] for r in rows];ledger['partial_owner_quiet']['observations'].append({'utility':rows[0]['utility'],'workload':rows[0]['label'],'gnu_ratios_forward_reverse':ratios,'triage':'losing' if min(ratios)<0.9 else 'noisy_or_tied' if min(ratios)<=1.1 else 'ahead_observation_only','acceptance':'unresolved full-catalogue requirement','missing':False,'ineligible':False})
write('catalogue-ledger.json',ledger)
# Include text evidence, sources, raw data and rejected/setup failures; exclude executable copies and fixture trees.
excluded={'probe','fixtures','syscall-fixture','empty-baseline'};files=[]
for f in p.rglob('*'):
 if f.name in {'archive-manifest.json','archive-identity.json'} or f.is_symlink() or not f.is_file() or excluded.intersection(f.relative_to(p).parts):continue
 if f.suffix in {'.json','.log','.py','.strace','.tsv','.txt','.patch','.fern','.go'}:files.append(f)
manifest={str(f.relative_to(p)):sha(f) for f in files};write('archive-manifest.json',manifest);files.append(p/'archive-manifest.json')
archive=repo/'docs/coreutils-log/2026-11-09-owner-quiet-data.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(files):t.add(f,arcname=str(f.relative_to(p)),recursive=False)
archivehash=sha(archive);write('archive-identity.json',{'sha256':archivehash,'bytes':archive.stat().st_size,'files':len(files)})
lines=[]
for i in [1,3,11,13]:
 rr=[r for r in primary if r['row']==i];fmt=lambda n:' / '.join(f"{r['times'][n]['mean']*1000:.3f}" for r in rr);lines.append(f"| {rr[0]['label']} | {fmt('base')} | {fmt('candidate')} | {fmt('gnu')} |")
direct=[]
for r in summaries['direct-loop']:
 t=r['mean_per_utility_ms'];direct.append(f"| {r['label']} | {t['base']:.3f} | {t['candidate']:.3f} | {t['gnu']:.3f} | {r['reduction_pct']:.2f}% |")
report=f'''# Quiet ownership changes, 2026-11-09

Quiet nonrecursive chown and chgrp calls now omit unused metadata lookups.
A 200-file batch removes 200 metadata syscalls and retains all 200 ownership syscalls.
The direct-loop cost diagnostic shows 12.0% to 19.1% less time on the four batch rows.
The original short rows have substantial noise. The repeated-shell result remains below the 10% threshold.
This report does not establish a complete utility win or full-catalogue completion.

## Selected loss and implementation

The published November 4 named-group batches lose to GNU coreutils 9.12.
Fern takes 1.84 ms for chown and 1.83 ms for chgrp. GNU takes 1.39 ms and 1.42 ms.
The fresh baseline already beats GNU on those rows on this host. The old source and new source remain separate.

The old path obtains metadata for every operand, even without recursion, verbose output, or a `--from` filter.
The new quiet path calls the ownership operation first.
It reads metadata only after an error, for the original diagnostic.

The failed operation is not retried. Recursive, verbose, and filtered paths retain their metadata checks.
Both utilities share the same ownership implementation. The compiler, libraries, syscall policy, and benchmark sources are unchanged.

Two new GNU parity regressions also require repairs:

- Issue #14924: an empty chown spec must still perform the ownership syscall. On Linux, `chown ':' file` clears set-ID bits.
- Issue #14925: `-H` and `-L` only affect recursive traversal. Without `-R`, `-h -L` must change a broken link itself.

The unchanged baseline fails both regressions. The fixed source passes them on native x86 and emulated ARM.

## Source and measurements

The base is main `{base}`.
The code tree is `{tree}`. The published code commit is `{code}`.
Both utility columns use the same compiler, SHA256 `{identities['compiler_sha256']}`.
The pinned bootstrap and smoke checks pass. The archive has full source and binary identities.

Later main changes do not inherit these performance claims.

Hyperfine 2.0.0 measures all 20 original workloads, with 80 samples per command and five warmups.
Both command orders contain baseline, candidate, and GNU 9.12 on the same fixtures.
All 9600 primary samples remain in the archive, with standard deviations and every raw observation.
Each workload matches GNU stdout, stderr, status, and relevant file-tree state before measurement.

The original same-owner fixtures and shell choices remain unchanged.
No test or compiler build runs beside the measurements.

Primary means below are milliseconds, forward / reverse. They are observations with the short-row limitation below.

| Workload | Baseline | Candidate | GNU 9.12 |
|---|---:|---:|---:|
{chr(10).join(lines)}

## Noise controls and separate cost diagnostic

Hyperfine warns that the shell-calibrated rows below 5 ms can be inaccurate.
One unchanged recursive path shows an apparent 69.2% gain in one order.
Other recursive controls move in opposite directions. These results do not qualify broad utility speedups.
Some original candidate/GNU rows remain tied, noisy, or slower.

A separate balanced check repeats each original shell invocation 25 times per observation.
It covers all six command permutations, 10 samples per command, and two unchanged recursive controls.
Those 1080 observations show only 3.83% to 9.95% batch reductions. They remain below the 10% threshold.

A second 1080-observation diagnostic repeats the utility command 25 times inside one Bash loop.
It retains the original operands, glob expansion, filesystem mutations, and all three binaries.
It removes repeated inner-shell startup and shell calibration. It is a different launcher method.
It isolates utility cost and does not replace an original published row.

The table gives means per utility invocation in milliseconds, across the six balanced orders.
Individual rounds remain variable. The archive retains all rounds.

| Workload | Baseline | Candidate | GNU 9.12 | Time reduction |
|---|---:|---:|---:|---:|
{chr(10).join(direct)}

The direct-loop recursive controls change by -0.22% and -4.39%.
The separate syscall traces explain the bounded batch cost: baseline and GNU perform 200 metadata calls. Candidate performs none.
All three perform 200 ownership calls. Traced call counts are diagnostics, not speed measurements.

## Correctness and gates

- Native GNU 9.12 parity passes 230 chown and 150 chgrp cases, plus help and version checks, with zero skips.
- Emulated ARM GNU 9.12 parity passes the same 380 cases and help/version checks, with zero skips.
- Sanitized native and emulated ARM candidates pass 94 extra cases against native GNU 9.12. Output, status, modes, ownership, and tree match.
- All sanitized cases report equal allocation and release counts, with no sanitizer findings.
- New cases cover empty specs, set-ID effects, quiet and verbose modes, recursive controls, broken and cyclic links, and mixed errors.
- Full source lint, compiler/stdlib complexity, Go vet, changed-file format, and diff checks pass.
- Chown and chgrp retain their WASI capability refusal. No WASI capability was added.
- Native Darwin checks require the normal hosted platform gate. No native ARM or Darwin speed claim is made.

## Preserved failures and limits

The archive retains the two failed baseline regressions and the GNU probes, with before/after modes and timestamps.
The initial strace stat filter missed `newfstatat`. The corrected filter and original traces both remain.
A proposed proc-file denial control returned success. It is not evidence of permission denial.

A sanitized build first omitted the required stdlib argument. Its setup failure remains.
The first balanced driver used `round` as a loop variable. Its final print failed after all samples completed.
The corrected driver and original source/log both remain. No measurement was rejected or replaced.

The direct-loop execution wrapper reported a nonzero status despite complete data and final output.
Independent validation confirms all 36 blocks, all command statuses, and all samples. The wrapper status is not a passed gate.

The host is one shared Linux x86-64 {identities['model']} machine, with the normal scheduler.
The full published scoreboard remains November 4: 669 rows over 106 utilities.
Its conservative ledger retains 349 ahead, 183 loss, 119 noisy, and 18 rounded-tie rows.
The missing stdbuf utility and ten unverified distribution SELinux references remain explicit.
No average, partial utility result, or merged PR satisfies the all-workload stop condition.

## Evidence

[Raw data and scripts](2026-11-09-owner-quiet-data.tar.gz), {archive.stat().st_size} bytes.
Archive SHA256: `{archivehash}`.
The archive includes all 11760 observations, commands, sources, hashes, failures, controls, probes, checks, and the per-utility ledger.
Executable copies remain in the local evidence directory. The archive records their hashes and producers.
'''
(repo/'docs/coreutils-log/2026-11-09-owner-quiet.md').write_text(report)
print('archive',archive.stat().st_size,'bytes',archivehash,'files',len(files))
