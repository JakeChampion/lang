import pathlib,os,subprocess,json,stat,shutil
p=pathlib.Path('/workspace/work/chown-evidence');env=dict(os.environ,LC_ALL='C',TZ='UTC');g=str(os.getgid());u=str(os.getuid())
cases=[('regular',[':'+g,'f']),('verbose',['-v',':'+g,'f']),('changes',['-c',':'+g,'f']),('from',['--from=:'+g,':'+g,'f']),('missing',[':'+g,'missing']),('link',[':'+g,'lnk']),('dangling',[':'+g,'broken']),('link_nofollow',['-h',':'+g,'lnk']),('dangling_nofollow',['-h',':'+g,'broken']),('dir',[':'+g,'d']),('same_both',[u+':'+g,'f']),('none',[':','f']),('mixed',[':'+g,'missing','f','broken','d']),('silent',['-f',':'+g,'missing','f','broken']),('slash',[':'+g,'lnk/']),('loop',[':'+g,'loop'])]
records=[]
for name,args in cases:
 root=p/'probe'/name;root.mkdir(parents=True,exist_ok=True)
 (root/'f').write_bytes(b'abc');os.chmod(root/'f',0o6755);(root/'d').mkdir(exist_ok=True);os.chmod(root/'d',0o2755)
 for n,target in [('lnk','f'),('broken','missing'),('loop','loop')]:
  f=root/n
  if not f.is_symlink():f.symlink_to(target)
 def snap():
  return {f.name:{'mode':oct(f.lstat().st_mode),'uid':f.lstat().st_uid,'gid':f.lstat().st_gid,'ctime_ns':f.lstat().st_ctime_ns,'link':os.readlink(f) if f.is_symlink() else None} for f in root.iterdir()}
 before=snap();cmd=['/usr/bin/strace','-e','trace=%file,fchownat','-o',str(p/f'gnu-{name}.strace'),'/workspace/work/gnu-9.12/bin/chown',*args];r=subprocess.run(cmd,cwd=root,capture_output=True,env=env)
 records.append({'name':name,'args':args,'argv':cmd,'before':before,'after':snap(),'stdout_hex':r.stdout.hex(),'stderr_hex':r.stderr.hex(),'status':r.returncode})
(p/'gnu-probe.json').write_text(json.dumps(records,indent=2)+'\n')
for n in ['regular','verbose','missing','dangling','dangling_nofollow']:
 print(n,'\n'+'\n'.join(x for x in (p/f'gnu-{n}.strace').read_text().splitlines() if any('"'+s+'"' in x for s in ['f','lnk','broken','missing'])))
