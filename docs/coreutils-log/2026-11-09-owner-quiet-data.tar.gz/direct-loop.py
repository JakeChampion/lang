import pathlib,json,subprocess,os,itertools,shlex,statistics,time
p=pathlib.Path('/workspace/work/chown-evidence');a=p/'direct-loop';a.mkdir();m=json.loads((p/'metadata.json').read_text());hf='/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine';env=dict(os.environ,LC_ALL='C',TZ='UTC');env.pop('POSIXLY_CORRECT',None);results=[];meta={'started':time.time(),'purpose':'Auxiliary balanced confirmation after original shell-calibrated short rows and unchanged recursive controls show large drift. All primary9600 samples retained. Each observation repeats25 direct utility calls with original arguments and operand globs in one Bash loop. This distinct launcher is a cost diagnostic, not a replacement published row. Outer wrapper uses --shell=none, no shell calibration. Six command permutations. Two unchanged recursive controls. No concurrent tests or builds.','repetitions':25,'samples':10,'warmup':2,'commands':[]}
for i in [1,3,4,11,13,14]:
 row=m['workloads'][i]
 for name in ['base','candidate','gnu']:
  exe='/workspace/work/gnu-9.12/bin/'+row['utility'] if name=='gnu' else str(p/name/row['utility']);cmd=row['command'].replace('{}',exe)
  wrapper=a/f'row{i:02}-{name}.sh';wrapper.write_text('#!/bin/bash\nset -eo pipefail\nfor ((i=0;i<25;i++)); do\n  '+cmd+'\ndone\n');wrapper.chmod(0o755)
for order_idx,names in enumerate(itertools.permutations(['base','candidate','gnu'])):
 for i in [1,3,4,11,13,14]:
  row=m['workloads'][i];out=a/f'row{i:02}-round{order_idx}.json';args=[hf,'--warmup','2','--runs','10','--shell=none','--export-json',str(out)]
  for name in names:args+=['--command-name',name,str(a/f'row{i:02}-{name}.sh')]
  meta['commands'].append(args);(a/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');subprocess.run(args,env=env,check=True)
  r=json.loads(out.read_text())['results'];assert all(len(x['measurements'])==10 and all(y['exit_code']==0 for y in x['measurements']) for x in r)
  results.append({'row':i,'round':order_idx,'names':names,'label':row['label'],'times':{x['name']:x['summary']['time_wall_clock'] for x in r}});(a/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
meta['finished']=time.time();(a/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for i in [1,3,4,11,13,14]:
 r=[x for x in results if x['row']==i];t={n:statistics.mean(x['times'][n]['mean']/25 for x in r) for n in ['base','candidate','gnu']};print(m['workloads'][i]['label'],{n:round(v*1000,3) for n,v in t.items()},'reduction',round((1-t['candidate']/t['base'])*100,2),'GNU ratio',round(t['gnu']/t['candidate'],3))
