import pathlib,os,subprocess,json,re
p=pathlib.Path('/workspace/work/chown-evidence/sanitized');env=dict(os.environ,LC_ALL='C',TZ='UTC');env['LD_LIBRARY_PATH']='/workspace/work/arm-tools/root/usr/lib/x86_64-linux-gnu';g=str(os.getgid());u=str(os.getuid());records=[]
for target in ['x86-64-linux','arm64-linux']:
 for util in ['chown','chgrp']:
  group=':'+g if util=='chown' else g
  specs=[':',u,':'+g,u+':'+g] if util=='chown' else [g]
  cases=[(spec,flag,[flag,spec,'f','d'] if flag else [spec,'f','d']) for spec in specs for flag in ['','-v','-c','-R','-Rv']]
  cases += [('link',tr,['-h',tr,group,name]) for tr in ['-H','-L','-P'] for name in ['lnk','broken','loop']]
  cases += [('mixed',flag,([flag] if flag else [])+[group,'missing','f','broken','d']) for flag in ['','-f']]
  for i,(spec,flag,args) in enumerate(cases):
   outcomes={}
   for kind in ['gnu','candidate']:
    root=p/'fixtures'/target/util/str(i)/kind;root.mkdir(parents=True,exist_ok=False);(root/'f').write_bytes(b'abc');(root/'f').chmod(0o6755);(root/'d').mkdir();(root/'d'/'a').write_bytes(b'def');(root/'d'/'a').chmod(0o6755)
    for n,to in [('lnk','f'),('broken','missing'),('loop','loop')]: (root/n).symlink_to(to)
    if kind=='gnu':cmd=['/workspace/work/gnu-9.12/bin/'+util,*args]
    elif target=='x86-64-linux':cmd=['bash','-c','exec -a "$0" "$@"',util,str(p/(util+'-'+target)),*args]
    else:cmd=['/workspace/work/arm-tools/root/usr/bin/qemu-aarch64','-L','/workspace/work/arm-tools/root/usr/aarch64-linux-gnu','-0',util,str(p/(util+'-'+target)),*args]
    r=subprocess.run(cmd,cwd=root,capture_output=True,env=env);err=r.stderr
    if kind=='candidate':
     assert b'fern-sanitizer:' not in err,(target,util,args,err)
     m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)[^\n]*\n',err);assert m,(target,util,args,err);assert m[1]==m[2] and int(m[3])==0,(args,err)
     err=err[:m.start()]+err[m.end():]
    tree={str(f.relative_to(root)):{'mode':f.lstat().st_mode,'uid':f.lstat().st_uid,'gid':f.lstat().st_gid,'size':f.lstat().st_size,'link':os.readlink(f) if f.is_symlink() else None} for f in sorted(root.rglob('*'))}
    outcomes[kind]={'cmd':cmd,'stdout_hex':r.stdout.hex(),'stderr_hex':err.hex(),'raw_stderr_hex':r.stderr.hex(),'status':r.returncode,'tree':tree}
   for field in ['stdout_hex','stderr_hex','status','tree']: assert outcomes['gnu'][field]==outcomes['candidate'][field],(target,util,args,field,outcomes)
   records.append({'target':target,'utility':util,'args':args,'outcomes':outcomes});(p/'results.json').write_text(json.dumps(records,indent=2)+'\n')
print('PASS',len(records),'sanitized native and emulated ARM cases, exact GNU stdout/stderr/status/tree, balanced allocations')
