import hashlib,json,os,pathlib,subprocess,time,stat
p=pathlib.Path('/workspace/work/chown-evidence');repo=pathlib.Path('/workspace/work/lang-coreutils');gnu=pathlib.Path('/workspace/work/gnu-9.12/bin');hf='/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine'
env=dict(os.environ,LC_ALL='C',TZ='UTC');env['PATH']=str(gnu)+':'+env['PATH'];env.pop('POSIXLY_CORRECT',None)
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
rows=[]
for util in ['chown','chgrp']:
 text=subprocess.check_output(['bash','-c','out=$1; source "$2"',util,str(p),str(repo/'scripts/coreutils-bench.d'/f'{util}.sh')],env=env,text=True)
 (p/(util+'-workloads.tsv')).write_text(text)
 for line in text.splitlines():
  label,shell,cmd=line.split('\t');rows.append({'utility':util,'label':label,'shell':shell,'command':cmd})
def snapshot():
 result={}
 for name in ['chownbench','chgrpbench']:
  root=p/name
  for f in sorted(root.rglob('*')):
   s=f.lstat();result[str(f.relative_to(p))]={'uid':s.st_uid,'gid':s.st_gid,'mode':s.st_mode,'size':s.st_size,'link':os.readlink(f) if f.is_symlink() else None}
 return result
meta={'started':time.time(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'patch':subprocess.check_output(['git','diff'],cwd=repo,text=True),'compiler_sha256':sha(p/'base/compiler'),'binaries':{n:{u:sha(p/n/u) if n!='gnu' else sha(gnu/u) for u in ['chown','chgrp']} for n in ['base','candidate','gnu']},'versions':{u:subprocess.check_output([gnu/u,'--version'],text=True).splitlines()[0] for u in ['chown','chgrp']},'hyperfine':subprocess.check_output([hf,'--version'],text=True).strip(),'identity':{'uid':os.getuid(),'gid':os.getgid()},'initial_tree':snapshot(),'workloads':rows,'parity':[],'commands':[],'limits':['One shared Linux x86-64 AMD EPYC host. Normal scheduler. All20 published workloads, unchanged shell selection and fixtures. Each command requests the ownership the process already has, as the original benchmark requires. No native ARM/Darwin speed claim. Baseline newly exposed parity failures are preserved separately, not hidden or used for timing claims.']}
for row in rows:
 outcomes={}
 for n in ['base','candidate','gnu']:
  exe=gnu/row['utility'] if n=='gnu' else p/n/row['utility'];cmd=row['command'].replace('{}',str(exe));before=snapshot();r=subprocess.run(['bash','-o','pipefail','-c',cmd],capture_output=True,env=env);after=snapshot()
  outcomes[n]={'stdout_hex':r.stdout.hex(),'stderr_hex':r.stderr.hex(),'status':r.returncode,'tree_equal':before==after};assert before==after
 assert outcomes['base']==outcomes['candidate']==outcomes['gnu'],(row,outcomes)
 meta['parity'].append({'label':row['label'],'outcomes':outcomes})
(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');summary=[]
for order,names in [('forward',['base','candidate','gnu']),('reverse',['gnu','candidate','base'])]:
 for i,row in enumerate(rows):
  output=p/f'row{i:02}-{order}.json';args=[hf,'--warmup','5','--runs','80','--shell=bash -o pipefail','--export-json',str(output)]
  for n in names:
   exe=gnu/row['utility'] if n=='gnu' else p/n/row['utility'];args+=['--command-name',n,row['command'].replace('{}',str(exe))]
  meta['commands'].append(args);(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');subprocess.run(args,env=env,check=True)
  results=json.loads(output.read_text())['results'];assert {r['name'] for r in results}==set(names);assert all(len(r['measurements'])==80 and all(m['exit_code']==0 for m in r['measurements']) for r in results)
  summary.append({'row':i,'order':order,'utility':row['utility'],'label':row['label'],'times':{r['name']:r['summary']['time_wall_clock'] for r in results}});(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert meta['patch']==subprocess.check_output(['git','diff'],cwd=repo,text=True);assert meta['initial_tree']==snapshot();meta['finished']=time.time();(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for r in summary:
 t=r['times'];print(r['order'],r['label'],{n:round(v['mean']*1000,3) for n,v in t.items()},'reduction',round((1-t['candidate']['mean']/t['base']['mean'])*100,2),'GNU ratio',round(t['gnu']['mean']/t['candidate']['mean'],3))
