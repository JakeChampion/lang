import os,json,pathlib,subprocess,time
p=pathlib.Path('/workspace/work/count-batch-evidence');hf='/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine';gnu=pathlib.Path('/workspace/work/gnu-9.12/bin');data='/workspace/work/wc-evidence/inputs/text-64m.txt';env=dict(os.environ,LC_ALL='C',TZ='UTC');env.pop('POSIXLY_CORRECT',None)
for case in ['scan','file','pipe']:
 for order,names in [('forward',['base','candidate']),('reverse',['candidate','base'])]:
  if case!='scan':names=names+['gnu'] if order=='forward' else ['gnu']+names
  args=[hf,'--warmup','5','--runs','40','--export-json',str(p/f'pilot-{case}-{order}.json')]
  args+=['--shell=bash -o pipefail'] if case=='pipe' else ['-N']
  for n in names:
   exe=p/n/('scan' if case=='scan' else 'wc') if n!='gnu' else gnu/'wc';cmd=str(exe)
   if case=='file':cmd+=' -l '+data
   if case=='pipe':cmd=f'{gnu}/cat {data} | {exe} -l'
   args+=['--command-name',n,cmd]
  subprocess.run(args,env=env,check=True)
