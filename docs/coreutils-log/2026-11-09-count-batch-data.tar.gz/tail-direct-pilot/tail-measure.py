import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/work/count-batch-evidence')
repo = Path('/workspace/work/lang-coreutils-count-batch')
data = Path('/workspace/work/wc-evidence/inputs/text-64m.txt')
hf = '/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine'
gnu = Path('/workspace/work/gnu-9.12/bin')
bins = {'base': root / 'base/tail', 'candidate': root / 'candidate/tail', 'gnu': gnu / 'tail'}
cases = {'last_ten': ['-n', '10'], 'last_four_million': ['-n', '4000000'], 'last_bytes': ['-c', '33554432'], 'pipe': ['-n', '10'], 'from_four_million': ['-n', '+4000000']}
env = dict(os.environ, LC_ALL='C', TZ='UTC')
env.pop('POSIXLY_CORRECT', None)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(name, case):
    if case == 'pipe':
        return f'{gnu}/cat {data} | {bins[name]} -n 10'
    return ' '.join([str(bins[name]), *cases[case], str(data)])


meta = {
    'started': time.time(),
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'diff': subprocess.check_output(['git', 'diff'], cwd=repo, text=True),
    'input': {'path': str(data), 'sha256': sha(data), 'bytes': data.stat().st_size},
    'binaries': {name: {'path': str(path), 'sha256': sha(path)} for name, path in bins.items()},
    'compilers': {n: sha(root / n / 'compiler') for n in ['base', 'candidate']},
    'gnu_version': subprocess.check_output([gnu / 'tail', '--version'], text=True).splitlines()[0],
    'hyperfine_version': subprocess.check_output([hf, '--version'], text=True).strip(),
    'limitations': ['One shared EPYC Linux x86-64 host.', 'Both candidates use main d04e79179 sources and libraries. The compiler kernel differs, while tail source is unchanged.', 'All file commands use direct execution with stdout on /dev/null. The pipeline uses Bash and pipefail.'],
    'parity': {},
}
for case in cases:
    outcomes = {}
    for name in bins:
        args = ['bash', '-o', 'pipefail', '-c', command(name, case)] if case == 'pipe' else [str(bins[name]), *cases[case], str(data)]
        r = subprocess.run(args, env=env, capture_output=True)
        outcomes[name] = {'stdout_sha256': hashlib.sha256(r.stdout).hexdigest(), 'stdout_bytes': len(r.stdout), 'stderr': r.stderr.decode(), 'status': r.returncode}
    assert all(v == outcomes['gnu'] for v in outcomes.values()), (case, outcomes)
    meta['parity'][case] = outcomes
(root / 'tail-metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
summary = {}
for order, names in [('forward', list(bins)), ('reverse', list(reversed(bins)))]:
    for case in cases:
        path = root / f'tail-{case}-{order}.json'
        args = [hf, '--warmup', '5', '--runs', '80', '--export-json', str(path)]
        args += ['--shell=bash -o pipefail'] if case == 'pipe' else ['-N']
        for name in names:
            args += ['--command-name', name, command(name, case)]
        subprocess.run(args, env=env, check=True)
        results = json.loads(path.read_text())['results']
        assert len(results) == 3 and {r['name'] for r in results} == set(bins)
        for r in results:
            assert len(r['measurements']) == 80
            assert all(m['exit_code'] == 0 for m in r['measurements'])
        summary[f'{case}-{order}'] = {r['name']: r['summary']['time_wall_clock'] for r in results}
assert meta['diff'] == subprocess.check_output(['git', 'diff'], cwd=repo, text=True)
meta['finished'] = time.time()
(root / 'tail-metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
(root / 'tail-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for name, row in summary.items():
    print(name, {n: round(r['mean'] * 1000, 3) for n, r in row.items()})
