import hashlib,json,os,pathlib,subprocess,time
p=pathlib.Path('/workspace/work/count-batch-evidence');repo=pathlib.Path('/workspace/work/lang-coreutils-count-batch');gnu=pathlib.Path('/workspace/work/gnu-9.12/bin');data=pathlib.Path('/workspace/work/wc-evidence/inputs/text-64m.txt');hf='/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine'
env=dict(os.environ,LC_ALL='C',TZ='UTC');env.pop('POSIXLY_CORRECT',None)
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
cases={'lines':['-l'],'bytes':['-c'],'all':[],'words':['-w'],'width':['-L'],'pipe':['-l']}
meta={'started':time.time(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'patch':subprocess.check_output(['git','diff'],cwd=repo,text=True),'input':{'path':str(data),'bytes':data.stat().st_size,'sha256':sha(data)},'compilers':{n:sha(p/n/'compiler') for n in ['base','candidate']},'binaries':{n:{case:sha(p/n/case) for case in ['wc','scan','dense','string']} for n in ['base','candidate']},'gnu':{'version':subprocess.check_output([gnu/'wc','--version'],text=True).splitlines()[0],'wc_sha256':sha(gnu/'wc'),'partner_cat_sha256':sha(gnu/'cat'),'source_archive_sha256':sha('/workspace/work/gnu-build/coreutils-9.12.tar.xz')},'micro_sources':{c:sha(p/(c+'.fern')) for c in ['scan','dense','string']},'hyperfine':subprocess.check_output([hf,'--version'],text=True).strip(),'commands':[],'parity':{},'limitations':['One shared AMD EPYC Linux x86-64 host. Normal scheduler, no affinity. No native ARM/Darwin timing. All six unchanged wc workloads, direct execution except the GNU-cat pipeline. Auxiliary scan kernels are not utility or GNU wins. Opposite command orders, raw sample variability retained.']}
def cmd(n,case):
 if case in ['scan','dense','string']:return str(p/n/case)
 exe=p/n/'wc' if n!='gnu' else gnu/'wc'
 if case=='pipe':return f'{gnu}/cat {data} | {exe} -l'
 return ' '.join([str(exe),*cases[case],str(data)])
for case in cases:
 out={}
 for n in ['base','candidate','gnu']:
  argv=['bash','-o','pipefail','-c',cmd(n,case)] if case=='pipe' else cmd(n,case).split()
  r=subprocess.run(argv,capture_output=True,env=env);out[n]={'stdout_hex':r.stdout.hex(),'stderr_hex':r.stderr.hex(),'status':r.returncode}
 assert all(v==out['gnu'] for v in out.values()),(case,out)
 meta['parity'][case]=out
for case in ['scan','dense','string']:
 for n in ['base','candidate']:
  r=subprocess.run([p/n/case],capture_output=True,env=env);assert (r.returncode,r.stdout,r.stderr)==(0,b'',b'')
(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');summary={}
for order,names in [('forward',['base','candidate','gnu']),('reverse',['gnu','candidate','base'])]:
 for case in [*cases,'scan','dense','string']:
  ns=[n for n in names if n!='gnu'] if case in ['scan','dense','string'] else names
  out=p/f'final-{case}-{order}.json';argv=[hf,'--warmup','5','--runs','80','--export-json',str(out)];argv+=['--shell=bash -o pipefail'] if case=='pipe' else ['-N']
  for n in ns:argv+=['--command-name',n,cmd(n,case)]
  meta['commands'].append(argv);(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');subprocess.run(argv,env=env,check=True)
  rs=json.loads(out.read_text())['results'];assert {r['name'] for r in rs}==set(ns)
  assert all(len(r['measurements'])==80 and all(m['exit_code']==0 for m in r['measurements']) for r in rs)
  summary[f'{case}-{order}']={r['name']:r['summary']['time_wall_clock'] for r in rs};(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert meta['patch']==subprocess.check_output(['git','diff'],cwd=repo,text=True);assert all(sha(p/n/'compiler')==meta['compilers'][n] for n in ['base','candidate'])
meta['finished']=time.time();(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for k,t in summary.items():print(k,{n:round(v['mean']*1000,3) for n,v in t.items()},'base reduction',round((1-t['candidate']['mean']/t['base']['mean'])*100,2))
