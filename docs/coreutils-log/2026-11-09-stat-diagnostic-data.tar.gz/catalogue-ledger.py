import collections,hashlib,json,pathlib,re
repo=pathlib.Path('/workspace/work/lang-coreutils-stat');src=repo/'docs/coreutils-log/2026-11-04-bench.md';rows=[];utilities={}
for line in src.read_text().splitlines():
 if not line.startswith('| `'):continue
 fields=[x.strip() for x in re.split(r'(?<!\\)\|',line)[1:-1]]
 if len(fields)!=7: raise ValueError(line)
 util,workload,fern,gnu,_,ratio,_=fields;util=util.strip('`')
 try:r=float(ratio.rstrip('×'))
 except ValueError:r=None
 status='missing' if r is None else 'tied' if r==1 else 'noisy' if .9<=r<=1.1 else 'losing' if r<.9 else 'ahead'
 eligibility='unverified_distribution_reference' if util in ['chcon','runcon'] else 'published_GNU_9.12'
 row={'utility':util,'workload':workload,'fern':fern,'gnu':gnu,'ratio':r,'published_status':status,'eligibility':eligibility}
 rows.append(row);u=utilities.setdefault(util,{'ahead':0,'losing':0,'tied':0,'noisy':0,'missing':0,'ineligible':0})
 u[status]+=1
 if eligibility!='published_GNU_9.12':u['ineligible']+=1
utilities['stdbuf']={'ahead':0,'losing':0,'tied':0,'noisy':0,'missing':1,'ineligible':0,'reason':'Absent from catalogue. Repository has no libc FFI implementation. Policy unchanged.'}
d={'source':str(src.relative_to(repo)),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'catalogue_date':'2026-11-04','scoreboard':'https://fern-lang.netlify.app/lang/coreutils/#by-utility','rule':'Rounded ratios: exact 1.00 tied; 0.90 through 1.10 noisy; otherwise triage losing/ahead. This is not fresh acceptance evidence.','eligibility_limit':'The source log does not retain per-utility version diagnostics for chcon/runcon. The benchmark uses distribution SELinux references. Those 10 rows remain ineligible for the strict GNU 9.12 stop condition until exact version and parity are verified. Original published status is retained.','rows':rows,'utilities':utilities,'published_totals':dict(collections.Counter(x['published_status'] for x in rows)),'missing_utilities':['stdbuf']}
pathlib.Path('/workspace/work/stat-evidence/catalogue-ledger.json').write_text(json.dumps(d,indent=2)+'\n')
print(d['published_totals'],len(rows),len(utilities))
