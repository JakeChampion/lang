import hashlib,json,os,pathlib,subprocess,time,shlex
p=pathlib.Path('/workspace/work/stat-evidence'); repo=pathlib.Path('/workspace/work/lang-coreutils-stat')
hf='/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine'
bins={'base':p/'base/stat','candidate':p/'candidate/stat','gnu':pathlib.Path('/workspace/work/gnu-9.12/bin/stat')}
env=dict(os.environ,LC_ALL='C',TZ='UTC');env.pop('POSIXLY_CORRECT',None)
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
rows=[x.split('\t') for x in (p/'workloads.tsv').read_text().splitlines()]
meta={'started':time.time(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'patch':(p/'candidate.patch').read_text(),'source_sha256':{n:sha(p/n/'stat.fern') for n in ['base','candidate']},'binaries':{n:{'path':str(b),'sha256':sha(b)} for n,b in bins.items()},'compiler':{'path':'/workspace/work/wc-evidence/baseline/compiler','sha256':sha('/workspace/work/wc-evidence/baseline/compiler')},'gnu_version':subprocess.check_output([bins['gnu'],'--version'],text=True).splitlines()[0],'hyperfine_version':subprocess.check_output([hf,'--version'],text=True).strip(),'commands':[],'limitations':['One shared Linux x86-64 host. Unpinned scheduler. Both execution orders. Bash glob expansion matches published workload shape. Timing excludes separate allocation probes. Original fixture file types, modes, lengths and names retained. No native ARM64 or Darwin timing.']}
(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
summary={}
for order,names in [('forward',list(bins)),('reverse',list(reversed(bins)))]:
 for i,(label,shell,cmd) in enumerate(rows):
  output=p/f'row{i:02}-{order}.json';args=[hf,'--warmup','5','--runs','80','--export-json',str(output)]
  args+=['--shell=bash'] if shell=='y' else ['-N']
  for n in names: args+=['--command-name',n,cmd.replace('{}',str(bins[n]))]
  meta['commands'].append(args);(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
  subprocess.run(args,env=env,check=True)
  results=json.loads(output.read_text())['results'];assert {r['name'] for r in results}==set(bins)
  for r in results:
   assert len(r['measurements'])==80
   assert all(m['exit_code']==0 for m in r['measurements'])
  summary[f'{i:02}-{order}']={'label':label,'times':{r['name']:r['summary']['time_wall_clock'] for r in results}}
  (p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
meta['finished']=time.time();assert sha(repo/'coreutils/stat.fern')==meta['source_sha256']['candidate']
(p/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
for k,row in summary.items(): print(k,row['label'],{n:round(v['mean']*1000,3) for n,v in row['times'].items()})
