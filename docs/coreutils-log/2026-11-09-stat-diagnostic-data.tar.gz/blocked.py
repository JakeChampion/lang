import json,os,pathlib,subprocess,itertools
p=pathlib.Path('/workspace/work/stat-evidence');hf='/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine'
bins={'base':p/'base/stat','candidate':p/'direct/stat','gnu':pathlib.Path('/workspace/work/gnu-9.12/bin/stat')}
rows=[x.split('\t') for x in (p/'workloads.tsv').read_text().splitlines()];ids=[5,9,2]
orders=[['base','candidate','gnu'],['candidate','gnu','base'],['gnu','base','candidate'],['gnu','candidate','base'],['candidate','base','gnu'],['base','gnu','candidate']]
env=dict(os.environ,LC_ALL='C',TZ='UTC');env.pop('POSIXLY_CORRECT',None)
summary=[]
for block,names in enumerate(orders):
 for row in ids[block%3:]+ids[:block%3]:
  label,shell,cmd=rows[row];out=p/f'blocked-{block}-{row}.json';args=[hf,'--warmup','3','--runs','30','--shell=bash','--export-json',str(out)]
  for name in names:args+=['--command-name',name,cmd.replace('{}',str(bins[name]))]
  subprocess.run(args,env=env,check=True)
  rs=json.loads(out.read_text())['results']
  assert {r['name'] for r in rs}==set(bins)
  assert all(len(r['measurements'])==30 and all(m['exit_code']==0 for m in r['measurements']) for r in rs)
  summary.append({'block':block,'row':row,'label':label,'argv':args,'times':{r['name']:r['summary']['time_wall_clock'] for r in rs}})
  (p/'blocked-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in ids:
 vals=[r for r in summary if r['row']==row];t={n:sum(r['times'][n]['mean'] for r in vals)/len(vals) for n in bins}
 print(rows[row][0],{n:round(v*1000,3) for n,v in t.items()},'reduction',round((1-t['candidate']/t['base'])*100,2),'GNU ratio',round(t['gnu']/t['candidate'],3))
