import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time

root = Path('/workspace/work/wc-evidence')
repo = Path('/workspace/work/lang-coreutils')
hf = '/workspace/work/hyperfine/hyperfine-v2.0.0-x86_64-unknown-linux-gnu/hyperfine'
gnu = Path('/workspace/work/gnu-9.12/bin')
data = root / 'inputs/text-64m.txt'
env = dict(os.environ, LC_ALL='C', TZ='UTC')
env.pop('POSIXLY_CORRECT', None)
bins = {'baseline': root / 'baseline/wc', 'candidate': root / 'candidate/wc', 'gnu': gnu / 'wc'}
cases = {'lines': ['-l'], 'bytes': ['-c'], 'all': [], 'words': ['-w'], 'width': ['-L'], 'pipe': ['-l']}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(name, case):
    if case == 'pipe':
        return f'{gnu}/cat {data} | {bins[name]} -l'
    return ' '.join([str(bins[name]), *cases[case], str(data)])


meta = {
    'started': time.time(), 'platform': platform.platform(),
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'diff': subprocess.check_output(['git', 'diff'], cwd=repo, text=True),
    'input_sha256': sha(data), 'input_bytes': data.stat().st_size,
    'binaries': {name: {'path': str(p), 'sha256': sha(p)} for name, p in bins.items()},
    'compiler_sha256': {name: sha(root / name / 'compiler') for name in ['baseline', 'candidate']},
    'gnu_version': subprocess.check_output([gnu / 'wc', '--version'], text=True).splitlines()[0],
    'gnu_archive_sha256': sha('/workspace/work/gnu-build/coreutils-9.12.tar.xz'),
    'hyperfine': subprocess.check_output([hf, '--version'], text=True).strip(),
    'parity': {},
    'limitations': ['One shared Linux x86-64 host. No native ARM or Darwin performance claim.',
                    'GNU build lacks optional ACL, xattr, and capability libraries. wc does not use them.',
                    'Published scoreboard is older, on different hardware. No substitution of those timing columns.'],
}
for case in cases:
    outcomes = {}
    for name in bins:
        args = ['bash', '-o', 'pipefail', '-c', command(name, case)] if case == 'pipe' else [str(bins[name]), *cases[case], str(data)]
        r = subprocess.run(args, env=env, capture_output=True, check=False)
        outcomes[name] = {'status': r.returncode, 'stdout': r.stdout.decode(), 'stderr': r.stderr.decode()}
    assert all(v == outcomes['gnu'] for v in outcomes.values()), (case, outcomes)
    meta['parity'][case] = outcomes

if (root / 'metadata.json').exists():
    prior = json.loads((root / 'metadata.json').read_text())
    assert prior['diff'] == meta['diff']
    assert prior['binaries'] == meta['binaries']
    meta['started'] = prior['started']
    meta['resumed_after_summary_schema_fix'] = time.time()
(root / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')


def read_results(path, samples):
    data = json.loads(path.read_text())['results']
    for r in data:
        assert len(r['measurements']) == samples
        assert all(m['exit_code'] == 0 for m in r['measurements'])
    return {r['name']: {k: r['summary']['time_wall_clock'][k] for k in ['mean', 'stddev']} for r in data}


rows = {}
for order, names in [('forward', list(bins)), ('reverse', list(reversed(bins)))]:
    for case in cases:
        result = root / f'{case}-{order}.json'
        args = [hf, '--warmup', '5', '--runs', '80', '--export-json', str(result)]
        args += ['-S', 'bash'] if case == 'pipe' else ['-N']
        for name in names:
            args += ['--command-name', name, command(name, case)]
        if not result.exists():
            subprocess.run(args, env=env, check=True)
        rows[f'{case}-{order}'] = read_results(result, 80)
    result = root / f'scan-{order}.json'
    args = [hf, '-N', '--warmup', '5', '--runs', '60', '--export-json', str(result)]
    for name in [n for n in names if n != 'gnu']:
        args += ['--command-name', name, str(root / name / 'scan')]
    if not result.exists():
        subprocess.run(args, env=env, check=True)
    rows[f'scan-{order}'] = read_results(result, 60)
assert meta['diff'] == subprocess.check_output(['git', 'diff'], cwd=repo, text=True)
meta['finished'] = time.time()
(root / 'metadata.json').write_text(json.dumps(meta, indent=2) + '\n')
(root / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
for label, row in rows.items():
    print(label, {name: round(v['mean'] * 1000, 3) for name, v in row.items()}, flush=True)
