(module
  (import "wasi_snapshot_preview1" "proc_exit" (func $__fern_proc_exit (param i32)))
  (import "wasi_snapshot_preview1" "fd_write" (func $__fern_fd_write (param i32 i32 i32 i32) (result i32)))
  (func $__fern_abort_arr
    (i32.store (i32.const 0) (i32.const 2744))
    (i32.store (i32.const 4) (i32.const 31))
    (drop (call $__fern_fd_write (i32.const 2) (i32.const 0) (i32.const 1) (i32.const 8)))
    (unreachable))
  (func $__fern_abort_str
    (i32.store (i32.const 0) (i32.const 2780))
    (i32.store (i32.const 4) (i32.const 32))
    (drop (call $__fern_fd_write (i32.const 2) (i32.const 0) (i32.const 1) (i32.const 8)))
    (unreachable))
  (func $__fern_abort_slice
    (i32.store (i32.const 0) (i32.const 2816))
    (i32.store (i32.const 4) (i32.const 32))
    (drop (call $__fern_fd_write (i32.const 2) (i32.const 0) (i32.const 1) (i32.const 8)))
    (unreachable))
  (func $__fern_abort_alloc
    (i32.store (i32.const 0) (i32.const 2852))
    (i32.store (i32.const 4) (i32.const 35))
    (drop (call $__fern_fd_write (i32.const 2) (i32.const 0) (i32.const 1) (i32.const 8)))
    (unreachable))
  (func $__fern_abort_oom
    (i32.store (i32.const 0) (i32.const 2892))
    (i32.store (i32.const 4) (i32.const 43))
    (drop (call $__fern_fd_write (i32.const 2) (i32.const 0) (i32.const 1) (i32.const 8)))
    (unreachable))
  (func $__fern_abort_free_range
    (i32.store (i32.const 0) (i32.const 2940))
    (i32.store (i32.const 4) (i32.const 41))
    (drop (call $__fern_fd_write (i32.const 2) (i32.const 0) (i32.const 1) (i32.const 8)))
    (unreachable))
  (func $__fern_abort_double_free
    (i32.store (i32.const 0) (i32.const 2988))
    (i32.store (i32.const 4) (i32.const 45))
    (drop (call $__fern_fd_write (i32.const 2) (i32.const 0) (i32.const 1) (i32.const 8)))
    (unreachable))
  (memory (export "memory") 16)
  (global $__str_base i32 (i32.const 192))
  (global $__str_base$runtime i32 (i32.const 2740))
  (global $__tid$http__HttpError i32 (i32.const 0))
  (global $__tid$http__BodyError$http__UnsupportedMediaType i32 (i32.const 1))
  (global $__tid$http__BodyError$http__MalformedJson i32 (i32.const 2))
  (global $__tid$http__BodyError$http__WrongShape i32 (i32.const 3))
  (global $__tid$http__BodyError$http__NotUtf8 i32 (i32.const 4))
  (global $__tid$http__BodyError$http__EndedEarly i32 (i32.const 5))
  (global $__tid$http__HttpLimits i32 (i32.const 6))
  (global $__tid$http____BodyFraming$http__Length i32 (i32.const 7))
  (global $__tid$http____BodyFraming$http__Chunked i32 (i32.const 8))
  (global $__tid$http__ChunkDecoder i32 (i32.const 9))
  (global $__tid$http__ChunkStep$http__ChunkData i32 (i32.const 10))
  (global $__tid$http__ChunkStep$http__ChunkEnd i32 (i32.const 11))
  (global $__tid$http__ChunkStep$http__ChunkRefused i32 (i32.const 12))
  (global $__tid$http__RequestParseError$http__Incomplete i32 (i32.const 13))
  (global $__tid$http__RequestParseError$http__NeedsContinue i32 (i32.const 14))
  (global $__tid$http__RequestParseError$http__Malformed i32 (i32.const 15))
  (global $__tid$http__HttpFramed i32 (i32.const 16))
  (global $__tid$http__HttpFraming$http__Complete i32 (i32.const 17))
  (global $__tid$http__HttpFraming$http__Incomplete i32 (i32.const 18))
  (global $__tid$http__HttpFraming$http__Continue i32 (i32.const 19))
  (global $__tid$http__HttpFraming$http__Malformed i32 (i32.const 20))
  (global $__tid$http__HttpHead i32 (i32.const 21))
  (global $__tid$http__HttpHeading$http__Complete i32 (i32.const 22))
  (global $__tid$http__HttpHeading$http__Incomplete i32 (i32.const 23))
  (global $__tid$http__HttpHeading$http__Malformed i32 (i32.const 24))
  (global $__tid$http____Head i32 (i32.const 25))
  (global $__tid$http__Outgoing i32 (i32.const 26))
  (global $__tid$http__HttpResponseFramed i32 (i32.const 27))
  (global $__tid$http__HttpResponseFraming$http__Complete i32 (i32.const 28))
  (global $__tid$http__HttpResponseFraming$http__Incomplete i32 (i32.const 29))
  (global $__tid$http__HttpResponseFraming$http__Malformed i32 (i32.const 30))
  (global $__tid$string__ParseBoolError$string__EmptyBool i32 (i32.const 31))
  (global $__tid$string__ParseBoolError$string__InvalidBool i32 (i32.const 32))
  (global $__tid$headers__HeaderValueError i32 (i32.const 33))
  (global $__tid$io_buffered__BufWriter i32 (i32.const 34))
  (global $__tid$io_buffered__BufBlock i32 (i32.const 35))
  (global $__tid$io_buffered__ByteLineReader i32 (i32.const 36))
  (global $__tid$io_buffered__LineReader i32 (i32.const 37))
  (global $__tid$json__JsonValue$json__JNull i32 (i32.const 38))
  (global $__tid$json__JsonValue$json__JBool i32 (i32.const 39))
  (global $__tid$json__JsonValue$json__JNumber i32 (i32.const 40))
  (global $__tid$json__JsonValue$json__JString i32 (i32.const 41))
  (global $__tid$json__JsonValue$json__JArray i32 (i32.const 42))
  (global $__tid$json__JsonValue$json__JObject i32 (i32.const 43))
  (global $__tid$json__JsonObject i32 (i32.const 44))
  (global $__tid$json__JsonError i32 (i32.const 45))
  (global $__tid$json__Document i32 (i32.const 46))
  (global $__tid$platform__Host i32 (i32.const 47))
  (global $__tid$url__UrlError i32 (i32.const 48))
  (global $__tid$url__UrlErrorKind$url__EmptyUrl i32 (i32.const 49))
  (global $__tid$url__UrlErrorKind$url__InvalidHost i32 (i32.const 50))
  (global $__tid$url__UrlErrorKind$url__InvalidPort i32 (i32.const 51))
  (global $__tid$url__UrlErrorKind$url__RelativeBase i32 (i32.const 52))
  (global $__tid$utf8__Utf8Error i32 (i32.const 53))
  (global $__tid$number_parse__ParseNumberError$number_parse__EmptyInput i32 (i32.const 54))
  (global $__tid$number_parse__ParseNumberError$number_parse__InvalidDigit i32 (i32.const 55))
  (global $__tid$number_parse__ParseNumberError$number_parse__OutOfRange i32 (i32.const 56))
  (global $__tid$number_parse__ParseNumberError$number_parse__InvalidRadix i32 (i32.const 57))
  (global $__tid$number_parse__DecimalParts i32 (i32.const 58))
  (global $__tid$iter__Mapped i32 (i32.const 59))
  (global $__tid$iter__Filtered i32 (i32.const 60))
  (global $__tid$iter__Taken i32 (i32.const 61))
  (global $__tid$iter__Skipped i32 (i32.const 62))
  (global $__tid$iter__Stepped i32 (i32.const 63))
  (global $__tid$iter__FlatMapped i32 (i32.const 64))
  (global $__tid$iter__Enumerated i32 (i32.const 65))
  (global $__tid$iter__Zipped i32 (i32.const 66))
  (global $__tid$iter__Range i32 (i32.const 67))
  (global $__tid$iter__ArrayIter i32 (i32.const 68))
  (global $__tid$bigint__BigInt i32 (i32.const 69))
  (global $__tid$fetch__Phase$fetch__Connecting i32 (i32.const 70))
  (global $__tid$fetch__Phase$fetch__Inactivity i32 (i32.const 71))
  (global $__tid$fetch__Phase$fetch__Total i32 (i32.const 72))
  (global $__tid$fetch__FetchError$fetch__InvalidUrl i32 (i32.const 73))
  (global $__tid$fetch__FetchError$fetch__InvalidRequest i32 (i32.const 74))
  (global $__tid$fetch__FetchError$fetch__Dns i32 (i32.const 75))
  (global $__tid$fetch__FetchError$fetch__Connect i32 (i32.const 76))
  (global $__tid$fetch__FetchError$fetch__Blocked i32 (i32.const 77))
  (global $__tid$fetch__FetchError$fetch__Tls i32 (i32.const 78))
  (global $__tid$fetch__FetchError$fetch__Timeout i32 (i32.const 79))
  (global $__tid$fetch__FetchError$fetch__Protocol i32 (i32.const 80))
  (global $__tid$fetch__FetchError$fetch__Io i32 (i32.const 81))
  (global $__tid$fetch__FetchError$fetch__Redirect i32 (i32.const 82))
  (global $__tid$fetch__FetchError$fetch__BodyLimit i32 (i32.const 83))
  (global $__tid$fetch__FetchError$fetch__Decode i32 (i32.const 84))
  (global $__tid$fetch__FetchError$fetch__Host i32 (i32.const 85))
  (global $__tid$fetch__FetchError$fetch__Cancelled i32 (i32.const 86))
  (global $__tid$fetch__Timeouts i32 (i32.const 87))
  (global $__tid$fetch__Request i32 (i32.const 88))
  (global $__tid$fetch__Decoding i32 (i32.const 89))
  (global $__tid$fetch____Target i32 (i32.const 90))
  (global $__tid$fetch__Idle i32 (i32.const 91))
  (global $__tid$fetch__Resumable i32 (i32.const 92))
  (global $__tid$fetch__Alternative i32 (i32.const 93))
  (global $__tid$fetch__Kept i32 (i32.const 94))
  (global $__tid$fetch__Shared i32 (i32.const 95))
  (global $__tid$fetch__Driven i32 (i32.const 96))
  (global $__tid$fetch__Mail i32 (i32.const 97))
  (global $__tid$fetch__Answer i32 (i32.const 98))
  (global $__tid$fetch____Place i32 (i32.const 99))
  (global $__tid$fetch__AltSvc i32 (i32.const 100))
  (global $__tid$fetch__Lookup i32 (i32.const 101))
  (global $__tid$fetch__Sockets i32 (i32.const 102))
  (global $__tid$fetch__Policy i32 (i32.const 103))
  (global $__tid$fetch__Allow i32 (i32.const 104))
  (global $__tid$fetch__AllowError i32 (i32.const 105))
  (global $__tid$fetch____AllowRule i32 (i32.const 106))
  (global $__tid$fetch____SharedPick$fetch__OnLoop i32 (i32.const 107))
  (global $__tid$fetch____SharedPick$fetch__OnTask i32 (i32.const 108))
  (global $__tid$fetch____H2Call i32 (i32.const 109))
  (global $__tid$fetch____Conn i32 (i32.const 110))
  (global $__tid$fetch____Record$fetch__RecordTaken i32 (i32.const 111))
  (global $__tid$fetch____Record$fetch__RecordsEnded i32 (i32.const 112))
  (global $__tid$fetch____Record$fetch__RecordAwaited i32 (i32.const 113))
  (global $__tid$fetch____Record$fetch__RecordFailed i32 (i32.const 114))
  (global $__tid$fetch____Read i32 (i32.const 115))
  (global $__tid$fetch____Got i32 (i32.const 116))
  (global $__tid$fetch__ProxyEnv i32 (i32.const 117))
  (global $__tid$fetch____Rule i32 (i32.const 118))
  (global $__tid$fetch____Match$fetch__Every i32 (i32.const 119))
  (global $__tid$fetch____Match$fetch__Named i32 (i32.const 120))
  (global $__tid$fetch____Match$fetch__Under i32 (i32.const 121))
  (global $__tid$fetch____Match$fetch__Addr i32 (i32.const 122))
  (global $__tid$fetch____Match$fetch__Block i32 (i32.const 123))
  (global $__tid$fetch____Match$fetch__Nothing i32 (i32.const 124))
  (global $__tid$fetch____Proxy i32 (i32.const 125))
  (global $__tid$cookie__SameSite$cookie__Unset i32 (i32.const 126))
  (global $__tid$cookie__SameSite$cookie__Strict i32 (i32.const 127))
  (global $__tid$cookie__SameSite$cookie__Lax i32 (i32.const 128))
  (global $__tid$cookie__SameSite$cookie__CrossSite i32 (i32.const 129))
  (global $__tid$cookie__SetCookie i32 (i32.const 130))
  (global $__tid$cookie__CookieError$cookie__BadName i32 (i32.const 131))
  (global $__tid$cookie__CookieError$cookie__BadValueByte i32 (i32.const 132))
  (global $__tid$cookie__CookieError$cookie__BadAttribute i32 (i32.const 133))
  (global $__tid$cookie__CookieError$cookie__TooLong i32 (i32.const 134))
  (global $__tid$cookie__CookieError$cookie__Lifetime i32 (i32.const 135))
  (global $__tid$cookie__CookieError$cookie__Prefix i32 (i32.const 136))
  (global $__tid$cookie__Cookie i32 (i32.const 137))
  (global $__tid$cookie__Ignored$cookie__NotACookie i32 (i32.const 138))
  (global $__tid$cookie__Ignored$cookie__ForeignDomain i32 (i32.const 139))
  (global $__tid$cookie__Ignored$cookie__PublicSuffixDomain i32 (i32.const 140))
  (global $__tid$cookie__Ignored$cookie__InsecureOrigin i32 (i32.const 141))
  (global $__tid$cookie__Ignored$cookie__SecureKept i32 (i32.const 142))
  (global $__tid$cookie__Ignored$cookie__PrefixBroken i32 (i32.const 143))
  (global $__tid$cookie__Ignored$cookie__UnsecuredPartition i32 (i32.const 144))
  (global $__tid$cookie__Jar i32 (i32.const 145))
  (global $__tid$cookie____Parsed i32 (i32.const 146))
  (global $__tid$async__Future$async__Ready i32 (i32.const 147))
  (global $__tid$async__Future$async__Pending i32 (i32.const 148))
  (global $__tid$async__Future$async__Cancelled i32 (i32.const 149))
  (global $__tid$async__Wait i32 (i32.const 150))
  (global $__tid$async__Wake$async__Woke i32 (i32.const 151))
  (global $__tid$async__Wake$async__TimedOut i32 (i32.const 152))
  (global $__tid$async__Wake$async__Cancelled i32 (i32.const 153))
  (global $__tid$async__RealDriver i32 (i32.const 154))
  (global $__tid$async__TaskStatus$async__Done i32 (i32.const 155))
  (global $__tid$async__TaskStatus$async__Suspended i32 (i32.const 156))
  (global $__tid$async__Task i32 (i32.const 157))
  (global $__tid$async__Call i32 (i32.const 158))
  (global $__tid$async__CallStatus$async__Returned i32 (i32.const 159))
  (global $__tid$async__CallStatus$async__Parked i32 (i32.const 160))
  (global $__tid$time__Timestamp i32 (i32.const 161))
  (global $__tid$time__TimeParseError i32 (i32.const 162))
  (global $__tid$time__TimeForm$time__IsoDate i32 (i32.const 163))
  (global $__tid$time__TimeForm$time__Rfc3339 i32 (i32.const 164))
  (global $__tid$time__TimeForm$time__HttpDate i32 (i32.const 165))
  (global $__tid$net__IpAddr$net__V4 i32 (i32.const 166))
  (global $__tid$net__IpAddr$net__V6 i32 (i32.const 167))
  (global $__tid$net__SocketAddr i32 (i32.const 168))
  (global $__tid$net__NetError$net__AddrInUse i32 (i32.const 169))
  (global $__tid$net__NetError$net__AddrNotAvailable i32 (i32.const 170))
  (global $__tid$net__NetError$net__ConnectionRefused i32 (i32.const 171))
  (global $__tid$net__NetError$net__ConnectionReset i32 (i32.const 172))
  (global $__tid$net__NetError$net__ConnectionAborted i32 (i32.const 173))
  (global $__tid$net__NetError$net__TimedOut i32 (i32.const 174))
  (global $__tid$net__NetError$net__WouldBlock i32 (i32.const 175))
  (global $__tid$net__NetError$net__InProgress i32 (i32.const 176))
  (global $__tid$net__NetError$net__NetworkUnreachable i32 (i32.const 177))
  (global $__tid$net__NetError$net__HostUnreachable i32 (i32.const 178))
  (global $__tid$net__NetError$net__Interrupted i32 (i32.const 179))
  (global $__tid$net__NetError$net__Other i32 (i32.const 180))
  (global $__tid$net__Prefix i32 (i32.const 181))
  (global $__tid$net__AddrParseError i32 (i32.const 182))
  (global $__tid$net__AddrKind$net__Ipv4Addr i32 (i32.const 183))
  (global $__tid$net__AddrKind$net__Ipv6Addr i32 (i32.const 184))
  (global $__tid$net__AddrKind$net__IpAddress i32 (i32.const 185))
  (global $__tid$net__AddrKind$net__SocketAddress i32 (i32.const 186))
  (global $__tid$net__AddrKind$net__NetworkPrefix i32 (i32.const 187))
  (global $__tid$net__ListenOptions i32 (i32.const 188))
  (global $__tid$net__Recv$net__Chunk i32 (i32.const 189))
  (global $__tid$net__Recv$net__Elapsed i32 (i32.const 190))
  (global $__tid$net__Recv$net__Abandoned i32 (i32.const 191))
  (global $__tid$net__Shutdown$net__Read i32 (i32.const 192))
  (global $__tid$net__Shutdown$net__Write i32 (i32.const 193))
  (global $__tid$net__Shutdown$net__Both i32 (i32.const 194))
  (global $__tid$net__Batch i32 (i32.const 195))
  (global $__tid$net__Inbox i32 (i32.const 196))
  (global $__tid$trace__Context i32 (i32.const 197))
  (global $__tid$dns__DnsError$dns__NoSuchName i32 (i32.const 198))
  (global $__tid$dns__DnsError$dns__NoData i32 (i32.const 199))
  (global $__tid$dns__DnsError$dns__NoReply i32 (i32.const 200))
  (global $__tid$dns__DnsError$dns__ServerFailure i32 (i32.const 201))
  (global $__tid$dns__DnsError$dns__Refused i32 (i32.const 202))
  (global $__tid$dns__DnsError$dns__Malformed i32 (i32.const 203))
  (global $__tid$dns__DnsError$dns__NoNameserver i32 (i32.const 204))
  (global $__tid$dns__DnsError$dns__NetFailed i32 (i32.const 205))
  (global $__tid$dns__RData$dns__A i32 (i32.const 206))
  (global $__tid$dns__RData$dns__AAAA i32 (i32.const 207))
  (global $__tid$dns__RData$dns__CNAME i32 (i32.const 208))
  (global $__tid$dns__RData$dns__PTR i32 (i32.const 209))
  (global $__tid$dns__RData$dns__Raw i32 (i32.const 210))
  (global $__tid$dns__Question i32 (i32.const 211))
  (global $__tid$dns__Record i32 (i32.const 212))
  (global $__tid$dns__Message i32 (i32.const 213))
  (global $__tid$dns__NameAt i32 (i32.const 214))
  (global $__tid$dns__QuestionAt i32 (i32.const 215))
  (global $__tid$dns__RecordAt i32 (i32.const 216))
  (global $__tid$dns__RecordsAt i32 (i32.const 217))
  (global $__tid$dns__Answer i32 (i32.const 218))
  (global $__tid$dns__OwnerScan i32 (i32.const 219))
  (global $__tid$dns__HostsEntry i32 (i32.const 220))
  (global $__tid$dns__ResolvConf i32 (i32.const 221))
  (global $__tid$dns__SearchPlan i32 (i32.const 222))
  (global $__tid$dns__Slot i32 (i32.const 223))
  (global $__tid$dns__Asked i32 (i32.const 224))
  (global $__tid$dns__Tally i32 (i32.const 225))
  (global $__tid$dns__Suffixes i32 (i32.const 226))
  (global $__tid$dns__Policy i32 (i32.const 227))
  (global $__tid$dns__DialOptions i32 (i32.const 228))
  (global $__tid$dns__Race i32 (i32.const 229))
  (global $__tid$dns__Nat64Prefix i32 (i32.const 230))
  (global $__tid$dns__Resolver i32 (i32.const 231))
  (global $__tid$dns__Seen i32 (i32.const 232))
  (global $__tid$dns__Route i32 (i32.const 233))
  (global $__tid$dns__NetdReply$dns__NetdMore i32 (i32.const 234))
  (global $__tid$dns__NetdReply$dns__NetdDone i32 (i32.const 235))
  (global $__tid$dns__NetdRecord i32 (i32.const 236))
  (global $__tid$brotli__BrotliError$brotli__Truncated i32 (i32.const 237))
  (global $__tid$brotli__BrotliError$brotli__Malformed i32 (i32.const 238))
  (global $__tid$brotli__BrotliError$brotli__TooLarge i32 (i32.const 239))
  (global $__tid$brotli____D i32 (i32.const 240))
  (global $__tid$brotli____Fill i32 (i32.const 241))
  (global $__tid$brotli____Cat i32 (i32.const 242))
  (global $__tid$brotli____Mb i32 (i32.const 243))
  (global $__tid$brotli____Sw i32 (i32.const 244))
  (global $__tid$deflate__InflateError$deflate__Truncated i32 (i32.const 245))
  (global $__tid$deflate__InflateError$deflate__Malformed i32 (i32.const 246))
  (global $__tid$deflate__InflateError$deflate__OutputLimit i32 (i32.const 247))
  (global $__tid$deflate__InflateError$deflate__BadChecksum i32 (i32.const 248))
  (global $__tid$deflate__InflateError$deflate__BadHeader i32 (i32.const 249))
  (global $__tid$deflate__Inflated i32 (i32.const 250))
  (global $__tid$deflate____State i32 (i32.const 251))
  (global $__tid$deflate____Huff i32 (i32.const 252))
  (global $__tid$deflate____Tables i32 (i32.const 253))
  (global $__tid$deflate____Fast i32 (i32.const 254))
  (global $__tid$deflate____Bits i32 (i32.const 255))
  (global $__tid$deflate____Code i32 (i32.const 256))
  (global $__tid$deflate____Span i32 (i32.const 257))
  (global $__tid$deflate____Header i32 (i32.const 258))
  (global $__tid$deflate__InflateReadError$deflate__ReadCodec i32 (i32.const 259))
  (global $__tid$deflate__InflateReadError$deflate__ReadCancelled i32 (i32.const 260))
  (global $__tid$deflate__InflateReadError$deflate__ReadRequest i32 (i32.const 261))
  (global $__tid$deflate__InflateReadError$deflate__ReadBusy i32 (i32.const 262))
  (global $__tid$deflate__InflateChunk i32 (i32.const 263))
  (global $__tid$deflate__InflateReader i32 (i32.const 264))
  (global $__tid$deflate____ReadPhase$deflate__ReadHeader i32 (i32.const 265))
  (global $__tid$deflate____ReadPhase$deflate__ReadStored i32 (i32.const 266))
  (global $__tid$deflate____ReadPhase$deflate__ReadCodes i32 (i32.const 267))
  (global $__tid$deflate____ReadPhase$deflate__ReadCopy i32 (i32.const 268))
  (global $__tid$deflate____ReadPhase$deflate__ReadEnd i32 (i32.const 269))
  (global $__tid$deflate____ReadCursor i32 (i32.const 270))
  (global $__tid$zstd__ZstdError$zstd__Truncated i32 (i32.const 271))
  (global $__tid$zstd__ZstdError$zstd__Malformed i32 (i32.const 272))
  (global $__tid$zstd__ZstdError$zstd__TooLarge i32 (i32.const 273))
  (global $__tid$zstd__ZstdError$zstd__Checksum i32 (i32.const 274))
  (global $__tid$zstd__ZstdError$zstd__Unsupported i32 (i32.const 275))
  (global $__tid$zstd____Frame i32 (i32.const 276))
  (global $__tid$zstd____Header i32 (i32.const 277))
  (global $__tid$zstd____Tables i32 (i32.const 278))
  (global $__tid$zstd____Seqt i32 (i32.const 279))
  (global $__tid$zstd____Block i32 (i32.const 280))
  (global $__tid$zstd____Fse i32 (i32.const 281))
  (global $__tid$zstd____Nc i32 (i32.const 282))
  (global $__tid$zstd____Huf i32 (i32.const 283))
  (global $__tid$zstd____Literals i32 (i32.const 284))
  (global $__tid$zstd____Field i32 (i32.const 285))
  (global $__tid$zstd____Codes i32 (i32.const 286))
  (global $__tid$zstd____Seqb i32 (i32.const 287))
  (global $__tid$zstd____Matches i32 (i32.const 288))
  (global $__tid$zstd____Ct i32 (i32.const 289))
  (global $__tid$zstd____Choice i32 (i32.const 290))
  (global $__tid$zstd____Codes3 i32 (i32.const 291))
  (global $__tid$zstd____Tables3 i32 (i32.const 292))
  (global $__tid$zstd____Enc i32 (i32.const 293))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodGet i32 (i32.const 294))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodHead i32 (i32.const 295))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodPost i32 (i32.const 296))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodPut i32 (i32.const 297))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodDelete i32 (i32.const 298))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodConnect i32 (i32.const 299))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodOptions i32 (i32.const 300))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodTrace i32 (i32.const 301))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodPatch i32 (i32.const 302))
  (global $__tid$wasi_http__WasiHttpMethod$wasi_http__MethodOther i32 (i32.const 303))
  (global $__tid$wasi_http__FutureGot i32 (i32.const 304))
  (global $__tid$wasi_http__Limits i32 (i32.const 305))
  (global $__tid$wasi_http__ErrorCode$wasi_http__DnsTimeout i32 (i32.const 306))
  (global $__tid$wasi_http__ErrorCode$wasi_http__DnsError i32 (i32.const 307))
  (global $__tid$wasi_http__ErrorCode$wasi_http__DestinationNotFound i32 (i32.const 308))
  (global $__tid$wasi_http__ErrorCode$wasi_http__DestinationUnavailable i32 (i32.const 309))
  (global $__tid$wasi_http__ErrorCode$wasi_http__DestinationIpProhibited i32 (i32.const 310))
  (global $__tid$wasi_http__ErrorCode$wasi_http__DestinationIpUnroutable i32 (i32.const 311))
  (global $__tid$wasi_http__ErrorCode$wasi_http__ConnectionRefused i32 (i32.const 312))
  (global $__tid$wasi_http__ErrorCode$wasi_http__ConnectionTerminated i32 (i32.const 313))
  (global $__tid$wasi_http__ErrorCode$wasi_http__ConnectionTimeout i32 (i32.const 314))
  (global $__tid$wasi_http__ErrorCode$wasi_http__ConnectionReadTimeout i32 (i32.const 315))
  (global $__tid$wasi_http__ErrorCode$wasi_http__ConnectionWriteTimeout i32 (i32.const 316))
  (global $__tid$wasi_http__ErrorCode$wasi_http__ConnectionLimitReached i32 (i32.const 317))
  (global $__tid$wasi_http__ErrorCode$wasi_http__TlsProtocolError i32 (i32.const 318))
  (global $__tid$wasi_http__ErrorCode$wasi_http__TlsCertificateError i32 (i32.const 319))
  (global $__tid$wasi_http__ErrorCode$wasi_http__TlsAlertReceived i32 (i32.const 320))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestDenied i32 (i32.const 321))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestLengthRequired i32 (i32.const 322))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestBodySize i32 (i32.const 323))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestMethodInvalid i32 (i32.const 324))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestUriInvalid i32 (i32.const 325))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestUriTooLong i32 (i32.const 326))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestHeaderSectionSize i32 (i32.const 327))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestHeaderSize i32 (i32.const 328))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestTrailerSectionSize i32 (i32.const 329))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpRequestTrailerSize i32 (i32.const 330))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseIncomplete i32 (i32.const 331))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseHeaderSectionSize i32 (i32.const 332))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseHeaderSize i32 (i32.const 333))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseBodySize i32 (i32.const 334))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseTrailerSectionSize i32 (i32.const 335))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseTrailerSize i32 (i32.const 336))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseTransferCoding i32 (i32.const 337))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseContentCoding i32 (i32.const 338))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpResponseTimeout i32 (i32.const 339))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpUpgradeFailed i32 (i32.const 340))
  (global $__tid$wasi_http__ErrorCode$wasi_http__HttpProtocolError i32 (i32.const 341))
  (global $__tid$wasi_http__ErrorCode$wasi_http__LoopDetected i32 (i32.const 342))
  (global $__tid$wasi_http__ErrorCode$wasi_http__ConfigurationError i32 (i32.const 343))
  (global $__tid$wasi_http__ErrorCode$wasi_http__InternalError i32 (i32.const 344))
  (global $__tid$wasi_http__ErrorCode$wasi_http__Unknown i32 (i32.const 345))
  (global $__tid$wasi_http__OutgoingError$wasi_http__Code i32 (i32.const 346))
  (global $__tid$wasi_http__OutgoingError$wasi_http__Field i32 (i32.const 347))
  (global $__tid$wasi_http__OutgoingError$wasi_http__BodyPastCap i32 (i32.const 348))
  (global $__tid$wasi_http__OutgoingError$wasi_http__CutShort i32 (i32.const 349))
  (global $__tid$wasi_http__OutgoingError$wasi_http__Lost i32 (i32.const 350))
  (global $__tid$tls__TlsError$tls__HandshakeFailed i32 (i32.const 351))
  (global $__tid$tls__TlsError$tls__Untrusted i32 (i32.const 352))
  (global $__tid$tls__TlsError$tls__CertificateMissing i32 (i32.const 353))
  (global $__tid$tls__TlsError$tls__SignatureInvalid i32 (i32.const 354))
  (global $__tid$tls__TlsError$tls__SchemeMismatch i32 (i32.const 355))
  (global $__tid$tls__TlsError$tls__SigningFailed i32 (i32.const 356))
  (global $__tid$tls__TlsError$tls__NoRoots i32 (i32.const 357))
  (global $__tid$tls__TlsError$tls__Unresolved i32 (i32.const 358))
  (global $__tid$tls__TlsError$tls__NetFailed i32 (i32.const 359))
  (global $__tid$tls__TlsError$tls__HandshakeTimeout i32 (i32.const 360))
  (global $__tid$tls__TlsError$tls__ClosedEarly i32 (i32.const 361))
  (global $__tid$tls__TlsError$tls__RecordCut i32 (i32.const 362))
  (global $__tid$tls__TlsError$tls__OffloadRefused i32 (i32.const 363))
  (global $__tid$tls__TlsError$tls__KeysRefused i32 (i32.const 364))
  (global $__tid$tls__TlsError$tls__KernelReadFailed i32 (i32.const 365))
  (global $__tid$tls__Failure i32 (i32.const 366))
  (global $__tid$client__Config i32 (i32.const 367))
  (global $__tid$client__Ticket i32 (i32.const 368))
  (global $__tid$client__Session i32 (i32.const 369))
  (global $__tid$client__Step i32 (i32.const 370))
  (global $__tid$client__Offloaded i32 (i32.const 371))
  (global $__tid$client__Connection i32 (i32.const 372))
  (global $__tid$client__Received i32 (i32.const 373))
  (global $__tid$client__Shook i32 (i32.const 374))
  (global $__tid$client__Kerneled i32 (i32.const 375))
  (global $__tid$ktls__Attached$ktls__Kernel i32 (i32.const 376))
  (global $__tid$ktls__Attached$ktls__Unchanged i32 (i32.const 377))
  (global $__tid$ktls__Attached$ktls__Broken i32 (i32.const 378))
  (global $__tid$ktls__Read$ktls__Opened i32 (i32.const 379))
  (global $__tid$ktls__Read$ktls__StreamEnded i32 (i32.const 380))
  (global $__tid$ktls__Read$ktls__NothingYet i32 (i32.const 381))
  (global $__tid$ktls__Read$ktls__WaitCancelled i32 (i32.const 382))
  (global $__tid$ktls__Read$ktls__ReadFailed i32 (i32.const 383))
  (global $__tid$verify__VerifyError$verify__EmptyChain i32 (i32.const 384))
  (global $__tid$verify__VerifyError$verify__Parse i32 (i32.const 385))
  (global $__tid$verify__VerifyError$verify__Pem i32 (i32.const 386))
  (global $__tid$verify__VerifyError$verify__Expired i32 (i32.const 387))
  (global $__tid$verify__VerifyError$verify__NotYetValid i32 (i32.const 388))
  (global $__tid$verify__VerifyError$verify__UnknownCritical i32 (i32.const 389))
  (global $__tid$verify__VerifyError$verify__UnknownIssuer i32 (i32.const 390))
  (global $__tid$verify__VerifyError$verify__NotACa i32 (i32.const 391))
  (global $__tid$verify__VerifyError$verify__PathTooLong i32 (i32.const 392))
  (global $__tid$verify__VerifyError$verify__KeyUsage i32 (i32.const 393))
  (global $__tid$verify__VerifyError$verify__NotForServers i32 (i32.const 394))
  (global $__tid$verify__VerifyError$verify__NotForClients i32 (i32.const 395))
  (global $__tid$verify__VerifyError$verify__NameMismatch i32 (i32.const 396))
  (global $__tid$verify__VerifyError$verify__BadSignature i32 (i32.const 397))
  (global $__tid$verify__VerifyError$verify__NameConstraint i32 (i32.const 398))
  (global $__tid$verify__VerifyError$verify__RootsUnreadable i32 (i32.const 399))
  (global $__tid$verify__VerifyError$verify__UnsupportedAlgorithm i32 (i32.const 400))
  (global $__tid$verify__VerifyError$verify__Distrusted i32 (i32.const 401))
  (global $__tid$verify__VerifyError$verify__DeniedKey i32 (i32.const 402))
  (global $__tid$verify__VerifyError$verify__SearchLimit i32 (i32.const 403))
  (global $__tid$verify__Roots i32 (i32.const 404))
  (global $__tid$verify__Search i32 (i32.const 405))
  (global $__tid$crypto__Md5 i32 (i32.const 406))
  (global $__tid$crypto__Sha1 i32 (i32.const 407))
  (global $__tid$crypto__Sha256 i32 (i32.const 408))
  (global $__tid$crypto__Sha512 i32 (i32.const 409))
  (global $__tid$crypto__Sm3 i32 (i32.const 410))
  (global $__tid$crypto__Blake2b i32 (i32.const 411))
  (global $__tid$crypto__Sha3 i32 (i32.const 412))
  (global $__tid$crypto__Shake i32 (i32.const 413))
  (global $__tid$crypto__ShakeReader i32 (i32.const 414))
  (global $__tid$h2__Config i32 (i32.const 415))
  (global $__tid$h2__Event$h2__Request i32 (i32.const 416))
  (global $__tid$h2__Event$h2__Streamed i32 (i32.const 417))
  (global $__tid$h2__Event$h2__StreamData i32 (i32.const 418))
  (global $__tid$h2__Event$h2__StreamEnd i32 (i32.const 419))
  (global $__tid$h2__Event$h2__Reset i32 (i32.const 420))
  (global $__tid$h2__Event$h2__GoAway i32 (i32.const 421))
  (global $__tid$h2__Event$h2__Closed i32 (i32.const 422))
  (global $__tid$h2__Event$h2__Answered i32 (i32.const 423))
  (global $__tid$h2__Step i32 (i32.const 424))
  (global $__tid$h2____Stream i32 (i32.const 425))
  (global $__tid$h2__Conn i32 (i32.const 426))
  (global $__tid$h2____Run i32 (i32.const 427))
  (global $__tid$h3__Config i32 (i32.const 428))
  (global $__tid$h3__Settings i32 (i32.const 429))
  (global $__tid$h3__Event$h3__HeadersReceived i32 (i32.const 430))
  (global $__tid$h3__Event$h3__DataReceived i32 (i32.const 431))
  (global $__tid$h3__Event$h3__TrailersReceived i32 (i32.const 432))
  (global $__tid$h3__Event$h3__StreamEnded i32 (i32.const 433))
  (global $__tid$h3__Event$h3__StreamAborted i32 (i32.const 434))
  (global $__tid$h3__Event$h3__GoawayReceived i32 (i32.const 435))
  (global $__tid$h3__Action$h3__Write i32 (i32.const 436))
  (global $__tid$h3__Action$h3__Abort i32 (i32.const 437))
  (global $__tid$h3__Action$h3__Stop i32 (i32.const 438))
  (global $__tid$h3__Action$h3__CloseConnection i32 (i32.const 439))
  (global $__tid$h3__Frames i32 (i32.const 440))
  (global $__tid$h3__Req i32 (i32.const 441))
  (global $__tid$h3__Uni i32 (i32.const 442))
  (global $__tid$h3__Session i32 (i32.const 443))
  (global $__tid$h3__Next i32 (i32.const 444))
  (global $__tid$h3q__Event$h3q__Requested i32 (i32.const 445))
  (global $__tid$h3q__Event$h3q__Responded i32 (i32.const 446))
  (global $__tid$h3q__Event$h3q__StreamDropped i32 (i32.const 447))
  (global $__tid$h3q__Event$h3q__Ended i32 (i32.const 448))
  (global $__tid$h3q__Partial i32 (i32.const 449))
  (global $__tid$h3q__Conn i32 (i32.const 450))
  (global $__tid$h3q__Parked i32 (i32.const 451))
  (global $__tid$conn__Config i32 (i32.const 452))
  (global $__tid$conn__Ticket i32 (i32.const 453))
  (global $__tid$conn__Close i32 (i32.const 454))
  (global $__tid$conn__Event$conn__Connected i32 (i32.const 455))
  (global $__tid$conn__Event$conn__Closed i32 (i32.const 456))
  (global $__tid$conn__Space i32 (i32.const 457))
  (global $__tid$conn__Tls$conn__TlsClient i32 (i32.const 458))
  (global $__tid$conn__Tls$conn__TlsServer i32 (i32.const 459))
  (global $__tid$conn__Tls$conn__TlsNone i32 (i32.const 460))
  (global $__tid$conn__Conn i32 (i32.const 461))
  (global $__tid$conn__Cid i32 (i32.const 462))
  (global $__tid$conn__Probe i32 (i32.const 463))
  (global $__tid$conn__Plan i32 (i32.const 464))
  (global $__tid$codec__DecodeErrorKind$codec__InvalidByte i32 (i32.const 465))
  (global $__tid$codec__DecodeErrorKind$codec__InvalidLength i32 (i32.const 466))
  (global $__tid$codec__DecodeErrorKind$codec__InvalidPadding i32 (i32.const 467))
  (global $__tid$codec__DecodeErrorKind$codec__NonZeroTrailingBits i32 (i32.const 468))
  (global $__tid$codec__DecodeError i32 (i32.const 469))
  (global $__tid$encoder__Writer i32 (i32.const 470))
  (global $__tid$crc32__Crc32 i32 (i32.const 471))
  (global $__tid$handshake__HandshakeError$handshake__Record i32 (i32.const 472))
  (global $__tid$handshake__HandshakeError$handshake__Message i32 (i32.const 473))
  (global $__tid$handshake__HandshakeError$handshake__KeyShare i32 (i32.const 474))
  (global $__tid$handshake__HandshakeError$handshake__OutOfOrder i32 (i32.const 475))
  (global $__tid$handshake__HandshakeError$handshake__UnexpectedRecord i32 (i32.const 476))
  (global $__tid$handshake__HandshakeError$handshake__Level i32 (i32.const 477))
  (global $__tid$handshake__HandshakeError$handshake__Illegal i32 (i32.const 478))
  (global $__tid$handshake__HandshakeError$handshake__MissingExtension i32 (i32.const 479))
  (global $__tid$handshake__HandshakeError$handshake__UnsupportedExtension i32 (i32.const 480))
  (global $__tid$handshake__HandshakeError$handshake__NotTls13 i32 (i32.const 481))
  (global $__tid$handshake__HandshakeError$handshake__HandshakeFailure i32 (i32.const 482))
  (global $__tid$handshake__HandshakeError$handshake__NoApplicationProtocol i32 (i32.const 483))
  (global $__tid$handshake__HandshakeError$handshake__BadCertificate i32 (i32.const 484))
  (global $__tid$handshake__HandshakeError$handshake__CertificateRequired i32 (i32.const 485))
  (global $__tid$handshake__HandshakeError$handshake__DecryptError i32 (i32.const 486))
  (global $__tid$handshake__HandshakeError$handshake__PeerAlert i32 (i32.const 487))
  (global $__tid$handshake__HandshakeError$handshake__Entropy i32 (i32.const 488))
  (global $__tid$handshake__HandshakeError$handshake__BadConfig i32 (i32.const 489))
  (global $__tid$handshake__HandshakeError$handshake__Misuse i32 (i32.const 490))
  (global $__tid$handshake__Event$handshake__VerifyServer i32 (i32.const 491))
  (global $__tid$handshake__Event$handshake__SignNeeded i32 (i32.const 492))
  (global $__tid$handshake__Event$handshake__VerifyClient i32 (i32.const 493))
  (global $__tid$handshake__Event$handshake__Connected i32 (i32.const 494))
  (global $__tid$handshake__Event$handshake__PeerClosed i32 (i32.const 495))
  (global $__tid$handshake__Event$handshake__Ticket i32 (i32.const 496))
  (global $__tid$handshake__Event$handshake__ResumeOffered i32 (i32.const 497))
  (global $__tid$handshake__Event$handshake__Crypto i32 (i32.const 498))
  (global $__tid$handshake__Event$handshake__Secret i32 (i32.const 499))
  (global $__tid$handshake__CryptoFlight i32 (i32.const 500))
  (global $__tid$handshake__TrafficSecret i32 (i32.const 501))
  (global $__tid$handshake__Offer i32 (i32.const 502))
  (global $__tid$handshake__Resumed i32 (i32.const 503))
  (global $__tid$handshake__Resumption i32 (i32.const 504))
  (global $__tid$handshake__Verification i32 (i32.const 505))
  (global $__tid$handshake__Signing i32 (i32.const 506))
  (global $__tid$handshake__Conn i32 (i32.const 507))
  (global $__tid$handshake__Flushed i32 (i32.const 508))
  (global $__tid$handshake__Out i32 (i32.const 509))
  (global $__tid$handshake__Wrote i32 (i32.const 510))
  (global $__tid$handshake__Absorbed i32 (i32.const 511))
  (global $__tid$handshake__Next i32 (i32.const 512))
  (global $__tid$handshake__KernelKeys i32 (i32.const 513))
  (global $__tid$handshake__Offloaded i32 (i32.const 514))
  (global $__tid$handshake__ClientConfig i32 (i32.const 515))
  (global $__tid$handshake__Client i32 (i32.const 516))
  (global $__tid$handshake__ClientStep i32 (i32.const 517))
  (global $__tid$handshake__ClientRun i32 (i32.const 518))
  (global $__tid$handshake__Held i32 (i32.const 519))
  (global $__tid$handshake__ClientOffload i32 (i32.const 520))
  (global $__tid$handshake__ServerConfig i32 (i32.const 521))
  (global $__tid$handshake__Server i32 (i32.const 522))
  (global $__tid$handshake__ServerStep i32 (i32.const 523))
  (global $__tid$handshake__ServerRun i32 (i32.const 524))
  (global $__tid$handshake__Choice i32 (i32.const 525))
  (global $__tid$handshake__Negotiated i32 (i32.const 526))
  (global $__tid$handshake__Refusal i32 (i32.const 527))
  (global $__tid$handshake__ServerOffload i32 (i32.const 528))
  (global $__tid$identity__PrivateKey$identity__EcdsaKey i32 (i32.const 529))
  (global $__tid$identity__PrivateKey$identity__Ed25519Seed i32 (i32.const 530))
  (global $__tid$identity__Identity i32 (i32.const 531))
  (global $__tid$identity__KeyError$identity__Pem i32 (i32.const 532))
  (global $__tid$identity__KeyError$identity__BadDer i32 (i32.const 533))
  (global $__tid$identity__KeyError$identity__Certificate i32 (i32.const 534))
  (global $__tid$identity__KeyError$identity__Scalar i32 (i32.const 535))
  (global $__tid$identity__KeyError$identity__Seed i32 (i32.const 536))
  (global $__tid$identity__KeyError$identity__NoKey i32 (i32.const 537))
  (global $__tid$identity__KeyError$identity__NoCertificate i32 (i32.const 538))
  (global $__tid$identity__KeyError$identity__UnsupportedKey i32 (i32.const 539))
  (global $__tid$identity__KeyError$identity__BadKey i32 (i32.const 540))
  (global $__tid$identity__KeyError$identity__Mismatch i32 (i32.const 541))
  (global $__tid$identity__KeyError$identity__CannotSign i32 (i32.const 542))
  (global $__tid$keyschedule__Hash$keyschedule__Sha256 i32 (i32.const 543))
  (global $__tid$keyschedule__Hash$keyschedule__Sha384 i32 (i32.const 544))
  (global $__tid$keyschedule__Aead$keyschedule__Aes128Gcm i32 (i32.const 545))
  (global $__tid$keyschedule__Aead$keyschedule__Aes256Gcm i32 (i32.const 546))
  (global $__tid$keyschedule__Aead$keyschedule__ChaCha20Poly1305 i32 (i32.const 547))
  (global $__tid$keyschedule__CipherSuite$keyschedule__Aes128GcmSha256 i32 (i32.const 548))
  (global $__tid$keyschedule__CipherSuite$keyschedule__Aes256GcmSha384 i32 (i32.const 549))
  (global $__tid$keyschedule__CipherSuite$keyschedule__ChaCha20Poly1305Sha256 i32 (i32.const 550))
  (global $__tid$keyschedule__EarlySecret i32 (i32.const 551))
  (global $__tid$keyschedule__HandshakeSecret i32 (i32.const 552))
  (global $__tid$keyschedule__MasterSecret i32 (i32.const 553))
  (global $__tid$keyschedule__TrafficKeys i32 (i32.const 554))
  (global $__tid$message__MsgError$message__DecodeError i32 (i32.const 555))
  (global $__tid$message__MsgError$message__IllegalParameter i32 (i32.const 556))
  (global $__tid$message__MsgError$message__ProtocolVersion i32 (i32.const 557))
  (global $__tid$message__MsgError$message__UnexpectedMessage i32 (i32.const 558))
  (global $__tid$message__MsgError$message__TooLarge i32 (i32.const 559))
  (global $__tid$message__Extension i32 (i32.const 560))
  (global $__tid$message__ClientHello i32 (i32.const 561))
  (global $__tid$message__ServerHello i32 (i32.const 562))
  (global $__tid$message__NewSessionTicket i32 (i32.const 563))
  (global $__tid$message__CertificateRequest i32 (i32.const 564))
  (global $__tid$message__CertificateEntry i32 (i32.const 565))
  (global $__tid$message__Certificate i32 (i32.const 566))
  (global $__tid$message__CertificateVerify i32 (i32.const 567))
  (global $__tid$message__Message$message__ClientHelloMsg i32 (i32.const 568))
  (global $__tid$message__Message$message__ServerHelloMsg i32 (i32.const 569))
  (global $__tid$message__Message$message__NewSessionTicketMsg i32 (i32.const 570))
  (global $__tid$message__Message$message__EndOfEarlyData i32 (i32.const 571))
  (global $__tid$message__Message$message__EncryptedExtensions i32 (i32.const 572))
  (global $__tid$message__Message$message__CertificateRequestMsg i32 (i32.const 573))
  (global $__tid$message__Message$message__CertificateMsg i32 (i32.const 574))
  (global $__tid$message__Message$message__CertificateVerifyMsg i32 (i32.const 575))
  (global $__tid$message__Message$message__Finished i32 (i32.const 576))
  (global $__tid$message__Message$message__KeyUpdate i32 (i32.const 577))
  (global $__tid$message__Span i32 (i32.const 578))
  (global $__tid$message__Raw i32 (i32.const 579))
  (global $__tid$message__Split i32 (i32.const 580))
  (global $__tid$message__KeyShareEntry i32 (i32.const 581))
  (global $__tid$message__PskIdentity i32 (i32.const 582))
  (global $__tid$message__OfferedPsks i32 (i32.const 583))
  (global $__tid$record__ContentType$record__ChangeCipherSpec i32 (i32.const 584))
  (global $__tid$record__ContentType$record__Alert i32 (i32.const 585))
  (global $__tid$record__ContentType$record__Handshake i32 (i32.const 586))
  (global $__tid$record__ContentType$record__ApplicationData i32 (i32.const 587))
  (global $__tid$record__RecordError$record__RecordOverflow i32 (i32.const 588))
  (global $__tid$record__RecordError$record__UnexpectedContentType i32 (i32.const 589))
  (global $__tid$record__RecordError$record__EmptyFragment i32 (i32.const 590))
  (global $__tid$record__RecordError$record__NoContentType i32 (i32.const 591))
  (global $__tid$record__RecordError$record__BadRecordMac i32 (i32.const 592))
  (global $__tid$record__RecordError$record__SequenceExhausted i32 (i32.const 593))
  (global $__tid$record__RecordError$record__BadKeys i32 (i32.const 594))
  (global $__tid$record__Record i32 (i32.const 595))
  (global $__tid$record__Deframed i32 (i32.const 596))
  (global $__tid$record__Protection i32 (i32.const 597))
  (global $__tid$record__Sealed i32 (i32.const 598))
  (global $__tid$record__Opened i32 (i32.const 599))
  (global $__tid$x509__Algorithm$x509__RsaPkcs1Sha256 i32 (i32.const 600))
  (global $__tid$x509__Algorithm$x509__RsaPkcs1Sha384 i32 (i32.const 601))
  (global $__tid$x509__Algorithm$x509__RsaPkcs1Sha512 i32 (i32.const 602))
  (global $__tid$x509__Algorithm$x509__RsaPssSha256 i32 (i32.const 603))
  (global $__tid$x509__Algorithm$x509__RsaPssSha384 i32 (i32.const 604))
  (global $__tid$x509__Algorithm$x509__RsaPssSha512 i32 (i32.const 605))
  (global $__tid$x509__Algorithm$x509__EcdsaSha256 i32 (i32.const 606))
  (global $__tid$x509__Algorithm$x509__EcdsaSha384 i32 (i32.const 607))
  (global $__tid$x509__Algorithm$x509__EcdsaSha512 i32 (i32.const 608))
  (global $__tid$x509__Algorithm$x509__Ed25519 i32 (i32.const 609))
  (global $__tid$x509__Algorithm$x509__OtherAlgorithm i32 (i32.const 610))
  (global $__tid$x509__PublicKey$x509__RsaKey i32 (i32.const 611))
  (global $__tid$x509__PublicKey$x509__EcKey i32 (i32.const 612))
  (global $__tid$x509__PublicKey$x509__Ed25519Key i32 (i32.const 613))
  (global $__tid$x509__PublicKey$x509__OtherKey i32 (i32.const 614))
  (global $__tid$x509__Name i32 (i32.const 615))
  (global $__tid$x509__Certificate i32 (i32.const 616))
  (global $__tid$x509__X509Error$x509__Der i32 (i32.const 617))
  (global $__tid$x509__X509Error$x509__Malformed i32 (i32.const 618))
  (global $__tid$x509__Pss i32 (i32.const 619))
  (global $__tid$x509__Exts i32 (i32.const 620))
  (global $__tid$x509__Subtrees i32 (i32.const 621))
  (global $__tid$ed25519__Ed25519Error$ed25519__SeedLength i32 (i32.const 622))
  (global $__tid$ed25519__Ed25519Error$ed25519__PublicKeyLength i32 (i32.const 623))
  (global $__tid$ed25519__Ed25519Error$ed25519__PublicKeyEncoding i32 (i32.const 624))
  (global $__tid$ed25519__Point i32 (i32.const 625))
  (global $__tid$ed25519__Cached i32 (i32.const 626))
  (global $__tid$ed25519__PrivateKey i32 (i32.const 627))
  (global $__tid$ed25519__PublicKey i32 (i32.const 628))
  (global $__tid$ecdsa__Curve$ecdsa__P256 i32 (i32.const 629))
  (global $__tid$ecdsa__Curve$ecdsa__P384 i32 (i32.const 630))
  (global $__tid$ecdsa__EcdsaError$ecdsa__Encoding i32 (i32.const 631))
  (global $__tid$ecdsa__EcdsaError$ecdsa__NotOnCurve i32 (i32.const 632))
  (global $__tid$ecdsa__EcdsaError$ecdsa__ScalarRange i32 (i32.const 633))
  (global $__tid$ecdsa__EcdsaError$ecdsa__SigningHash i32 (i32.const 634))
  (global $__tid$ecdsa__PublicKey i32 (i32.const 635))
  (global $__tid$ecdsa__Params i32 (i32.const 636))
  (global $__tid$ecdsa__Point i32 (i32.const 637))
  (global $__tid$ecdsa__CurveData i32 (i32.const 638))
  (global $__tid$ecdsa__PrivateKey i32 (i32.const 639))
  (global $__tid$ecdsa__Proj i32 (i32.const 640))
  (global $__tid$ecdsa__Signer i32 (i32.const 641))
  (global $__tid$ecdsa__Drbg i32 (i32.const 642))
  (global $__tid$sha2__Hash$sha2__Sha256 i32 (i32.const 643))
  (global $__tid$sha2__Hash$sha2__Sha384 i32 (i32.const 644))
  (global $__tid$sha2__Hash$sha2__Sha512 i32 (i32.const 645))
  (global $__tid$rsa__RsaError$rsa__ModulusTooSmall i32 (i32.const 646))
  (global $__tid$rsa__RsaError$rsa__ModulusTooLarge i32 (i32.const 647))
  (global $__tid$rsa__RsaError$rsa__EvenModulus i32 (i32.const 648))
  (global $__tid$rsa__RsaError$rsa__BadExponent i32 (i32.const 649))
  (global $__tid$rsa__PublicKey i32 (i32.const 650))
  (global $__tid$pem__Block i32 (i32.const 651))
  (global $__tid$pem__PemError$pem__Unterminated i32 (i32.const 652))
  (global $__tid$pem__PemError$pem__MismatchedEnd i32 (i32.const 653))
  (global $__tid$pem__PemError$pem__BadBase64 i32 (i32.const 654))
  (global $__tid$pem__Open i32 (i32.const 655))
  (global $__tid$hpack__Field i32 (i32.const 656))
  (global $__tid$hpack__HpackError$hpack__Truncated i32 (i32.const 657))
  (global $__tid$hpack__HpackError$hpack__BadIndex i32 (i32.const 658))
  (global $__tid$hpack__HpackError$hpack__BadInteger i32 (i32.const 659))
  (global $__tid$hpack__HpackError$hpack__BadHuffman i32 (i32.const 660))
  (global $__tid$hpack__HpackError$hpack__BadSizeUpdate i32 (i32.const 661))
  (global $__tid$hpack__HpackError$hpack__TooLarge i32 (i32.const 662))
  (global $__tid$hpack__HpackError$hpack__TooMany i32 (i32.const 663))
  (global $__tid$hpack__Table i32 (i32.const 664))
  (global $__tid$hpack__Decoder i32 (i32.const 665))
  (global $__tid$hpack__Decoded i32 (i32.const 666))
  (global $__tid$hpack__Encoder i32 (i32.const 667))
  (global $__tid$hpack__Encoded i32 (i32.const 668))
  (global $__tid$hpack__Encoding i32 (i32.const 669))
  (global $__tid$frame__Priority i32 (i32.const 670))
  (global $__tid$frame__Setting i32 (i32.const 671))
  (global $__tid$frame__Frame$frame__Data i32 (i32.const 672))
  (global $__tid$frame__Frame$frame__Headers i32 (i32.const 673))
  (global $__tid$frame__Frame$frame__PriorityFrame i32 (i32.const 674))
  (global $__tid$frame__Frame$frame__RstStream i32 (i32.const 675))
  (global $__tid$frame__Frame$frame__Settings i32 (i32.const 676))
  (global $__tid$frame__Frame$frame__PushPromise i32 (i32.const 677))
  (global $__tid$frame__Frame$frame__Ping i32 (i32.const 678))
  (global $__tid$frame__Frame$frame__GoAway i32 (i32.const 679))
  (global $__tid$frame__Frame$frame__WindowUpdate i32 (i32.const 680))
  (global $__tid$frame__Frame$frame__Continuation i32 (i32.const 681))
  (global $__tid$frame__Frame$frame__Unknown i32 (i32.const 682))
  (global $__tid$frame__DataFrame i32 (i32.const 683))
  (global $__tid$frame__HeadersFrame i32 (i32.const 684))
  (global $__tid$frame__PushPromiseFrame i32 (i32.const 685))
  (global $__tid$frame__GoAwayFrame i32 (i32.const 686))
  (global $__tid$frame__UnknownFrame i32 (i32.const 687))
  (global $__tid$frame__FrameError i32 (i32.const 688))
  (global $__tid$frame__Read$frame__Got i32 (i32.const 689))
  (global $__tid$frame__Read$frame__More i32 (i32.const 690))
  (global $__tid$frames__AckRange i32 (i32.const 691))
  (global $__tid$frames__Ecn i32 (i32.const 692))
  (global $__tid$frames__Ack i32 (i32.const 693))
  (global $__tid$frames__ResetStream i32 (i32.const 694))
  (global $__tid$frames__StreamData i32 (i32.const 695))
  (global $__tid$frames__NewConnectionId i32 (i32.const 696))
  (global $__tid$frames__ConnectionClose i32 (i32.const 697))
  (global $__tid$frames__Frame$frames__Padding i32 (i32.const 698))
  (global $__tid$frames__Frame$frames__Ping i32 (i32.const 699))
  (global $__tid$frames__Frame$frames__AckFrame i32 (i32.const 700))
  (global $__tid$frames__Frame$frames__ResetStreamFrame i32 (i32.const 701))
  (global $__tid$frames__Frame$frames__StopSending i32 (i32.const 702))
  (global $__tid$frames__Frame$frames__Crypto i32 (i32.const 703))
  (global $__tid$frames__Frame$frames__NewToken i32 (i32.const 704))
  (global $__tid$frames__Frame$frames__StreamFrame i32 (i32.const 705))
  (global $__tid$frames__Frame$frames__MaxData i32 (i32.const 706))
  (global $__tid$frames__Frame$frames__MaxStreamData i32 (i32.const 707))
  (global $__tid$frames__Frame$frames__MaxStreams i32 (i32.const 708))
  (global $__tid$frames__Frame$frames__DataBlocked i32 (i32.const 709))
  (global $__tid$frames__Frame$frames__StreamDataBlocked i32 (i32.const 710))
  (global $__tid$frames__Frame$frames__StreamsBlocked i32 (i32.const 711))
  (global $__tid$frames__Frame$frames__NewConnectionIdFrame i32 (i32.const 712))
  (global $__tid$frames__Frame$frames__RetireConnectionId i32 (i32.const 713))
  (global $__tid$frames__Frame$frames__PathChallenge i32 (i32.const 714))
  (global $__tid$frames__Frame$frames__PathResponse i32 (i32.const 715))
  (global $__tid$frames__Frame$frames__ConnectionCloseFrame i32 (i32.const 716))
  (global $__tid$frames__Frame$frames__HandshakeDone i32 (i32.const 717))
  (global $__tid$frames__FrameError i32 (i32.const 718))
  (global $__tid$frames__Reader i32 (i32.const 719))
  (global $__tid$qpack__Field i32 (i32.const 720))
  (global $__tid$qpack__QpackError$qpack__DecompressionFailed i32 (i32.const 721))
  (global $__tid$qpack__QpackError$qpack__EncoderStreamError i32 (i32.const 722))
  (global $__tid$qpack__QpackError$qpack__DecoderStreamError i32 (i32.const 723))
  (global $__tid$qpack__Table i32 (i32.const 724))
  (global $__tid$qpack__Decoder i32 (i32.const 725))
  (global $__tid$qpack__Encoder i32 (i32.const 726))
  (global $__tid$streams__Reassembly i32 (i32.const 727))
  (global $__tid$streams__Stream i32 (i32.const 728))
  (global $__tid$streams__Event$streams__Opened i32 (i32.const 729))
  (global $__tid$streams__Event$streams__Readable i32 (i32.const 730))
  (global $__tid$streams__Event$streams__ResetByPeer i32 (i32.const 731))
  (global $__tid$streams__Event$streams__StopRequested i32 (i32.const 732))
  (global $__tid$streams__Streams i32 (i32.const 733))
  (global $__tid$packet__Kind$packet__Initial i32 (i32.const 734))
  (global $__tid$packet__Kind$packet__ZeroRtt i32 (i32.const 735))
  (global $__tid$packet__Kind$packet__Handshake i32 (i32.const 736))
  (global $__tid$packet__Kind$packet__Retry i32 (i32.const 737))
  (global $__tid$packet__Kind$packet__OneRtt i32 (i32.const 738))
  (global $__tid$packet__Kind$packet__VersionNegotiation i32 (i32.const 739))
  (global $__tid$packet__Kind$packet__UnknownVersion i32 (i32.const 740))
  (global $__tid$packet__Header i32 (i32.const 741))
  (global $__tid$packet__Keys i32 (i32.const 742))
  (global $__tid$packet__Opened i32 (i32.const 743))
  (global $__tid$packet__PacketError$packet__PacketCutShort i32 (i32.const 744))
  (global $__tid$packet__PacketError$packet__PacketConnectionIdTooLong i32 (i32.const 745))
  (global $__tid$packet__PacketError$packet__PacketFixedBitClear i32 (i32.const 746))
  (global $__tid$packet__PacketError$packet__PacketVersionListLength i32 (i32.const 747))
  (global $__tid$packet__PacketError$packet__PacketPastDatagram i32 (i32.const 748))
  (global $__tid$packet__PacketError$packet__PacketRetryWithoutToken i32 (i32.const 749))
  (global $__tid$packet__PacketError$packet__PacketTooShortToSample i32 (i32.const 750))
  (global $__tid$packet__PacketError$packet__PacketUndecryptable i32 (i32.const 751))
  (global $__tid$packet__Unprotected i32 (i32.const 752))
  (global $__tid$packet__Long i32 (i32.const 753))
  (global $__tid$params__Params i32 (i32.const 754))
  (global $__tid$recovery__Resend$recovery__CryptoRange i32 (i32.const 755))
  (global $__tid$recovery__Resend$recovery__StreamRange i32 (i32.const 756))
  (global $__tid$recovery__Resend$recovery__Again i32 (i32.const 757))
  (global $__tid$recovery__Sent i32 (i32.const 758))
  (global $__tid$recovery__Space i32 (i32.const 759))
  (global $__tid$recovery__Recovery i32 (i32.const 760))
  (global $__tid$server__Config i32 (i32.const 761))
  (global $__tid$server__Session i32 (i32.const 762))
  (global $__tid$server__Step i32 (i32.const 763))
  (global $__tid$server__Offloaded i32 (i32.const 764))
  (global $__tid$server__Connection i32 (i32.const 765))
  (global $__tid$server__Received i32 (i32.const 766))
  (global $__tid$server__Shook i32 (i32.const 767))
  (global $__tid$server__Kerneled i32 (i32.const 768))
  (global $__tid$keyshare__Group$keyshare__X25519 i32 (i32.const 769))
  (global $__tid$keyshare__Group$keyshare__X25519MlKem768 i32 (i32.const 770))
  (global $__tid$keyshare__Group$keyshare__Secp256r1 i32 (i32.const 771))
  (global $__tid$keyshare__Group$keyshare__Secp256r1MlKem768 i32 (i32.const 772))
  (global $__tid$keyshare__KeyShareError$keyshare__EntropyLength i32 (i32.const 773))
  (global $__tid$keyshare__KeyShareError$keyshare__ShareLength i32 (i32.const 774))
  (global $__tid$keyshare__KeyShareError$keyshare__LowOrder i32 (i32.const 775))
  (global $__tid$keyshare__KeyShareError$keyshare__BadEncapsulationKey i32 (i32.const 776))
  (global $__tid$keyshare__KeyShareError$keyshare__OffCurve i32 (i32.const 777))
  (global $__tid$keyshare__KeyShareError$keyshare__ZeroScalar i32 (i32.const 778))
  (global $__tid$keyshare__ClientShare i32 (i32.const 779))
  (global $__tid$keyshare__ServerShare i32 (i32.const 780))
  (global $__tid$tls12__Keys i32 (i32.const 781))
  (global $__tid$tls12__KeyExchange i32 (i32.const 782))
  (global $__tid$der__DerError$der__Truncated i32 (i32.const 783))
  (global $__tid$der__DerError$der__BadLength i32 (i32.const 784))
  (global $__tid$der__DerError$der__HighTag i32 (i32.const 785))
  (global $__tid$der__DerError$der__UnexpectedTag i32 (i32.const 786))
  (global $__tid$der__DerError$der__BadValue i32 (i32.const 787))
  (global $__tid$der__Element i32 (i32.const 788))
  (global $__tid$der__Length i32 (i32.const 789))
  (global $__tid$der__BitString i32 (i32.const 790))
  (global $__tid$aead__AeadError$aead__KeyLength i32 (i32.const 791))
  (global $__tid$aead__AeadError$aead__NonceLength i32 (i32.const 792))
  (global $__tid$aead__AeadError$aead__Forged i32 (i32.const 793))
  (global $__tid$aead__AeadError$aead__CounterRange i32 (i32.const 794))
  (global $__tid$aes_gcm__Key i32 (i32.const 795))
  (global $__tid$chacha20poly1305__Key i32 (i32.const 796))
  (global $__tid$chacha20poly1305__Stream i32 (i32.const 797))
  (global $__tid$chacha20poly1305__Poly i32 (i32.const 798))
  (global $__tid$field25519__Fe i32 (i32.const 799))
  (global $__tid$montgomery__Modulus i32 (i32.const 800))
  (global $__tid$p256__Fe i32 (i32.const 801))
  (global $__tid$p256__Proj i32 (i32.const 802))
  (global $__tid$huffman__HuffmanError$huffman__InvalidCode i32 (i32.const 803))
  (global $__tid$huffman__HuffmanError$huffman__ExceedsRoom i32 (i32.const 804))
  (global $__tid$mlkem768__MlKemError$mlkem768__SeedLength i32 (i32.const 805))
  (global $__tid$mlkem768__MlKemError$mlkem768__MessageLength i32 (i32.const 806))
  (global $__tid$mlkem768__MlKemError$mlkem768__EncapsulationKeyLength i32 (i32.const 807))
  (global $__tid$mlkem768__MlKemError$mlkem768__DecapsulationKeyLength i32 (i32.const 808))
  (global $__tid$mlkem768__MlKemError$mlkem768__CiphertextLength i32 (i32.const 809))
  (global $__tid$mlkem768__MlKemError$mlkem768__EncapsulationKeyModulus i32 (i32.const 810))
  (global $__tid$mlkem768__MlKemError$mlkem768__DecapsulationKeyHash i32 (i32.const 811))
  (global $__tid$mlkem768__KeyPair i32 (i32.const 812))
  (global $__tid$mlkem768__Encapsulation i32 (i32.const 813))
  (global $__tid$x25519__X25519Error$x25519__ScalarLength i32 (i32.const 814))
  (global $__tid$x25519__X25519Error$x25519__PointLength i32 (i32.const 815))
  (global $__tid$x25519__X25519Error$x25519__LowOrder i32 (i32.const 816))
  (global $__tid$IoError$NotFound i32 (i32.const 817))
  (global $__tid$IoError$PermissionDenied i32 (i32.const 818))
  (global $__tid$IoError$AlreadyExists i32 (i32.const 819))
  (global $__tid$IoError$InvalidUtf8 i32 (i32.const 820))
  (global $__tid$IoError$Interrupted i32 (i32.const 821))
  (global $__tid$IoError$Unsupported i32 (i32.const 822))
  (global $__tid$Body$BodyText i32 (i32.const 823))
  (global $__tid$Body$BodyBytes i32 (i32.const 824))
  (global $__tid$Body$BodyStream i32 (i32.const 825))
  (global $__tid$Body$BodyFile i32 (i32.const 826))
  (global $__tid$Body$BodyChunks i32 (i32.const 827))
  (global $__tid$Body$BodyFileRanges i32 (i32.const 828))
  (global $__tid$IoError$Other i32 (i32.const 829))
  (global $__tid$StreamFault$StreamTooLarge i32 (i32.const 830))
  (global $__tid$StreamFault$StreamFramingTooLarge i32 (i32.const 831))
  (global $__tid$StreamFault$StreamTimeout i32 (i32.const 832))
  (global $__tid$StreamFault$StreamMalformed i32 (i32.const 833))
  (global $__tid$StreamFault$StreamCutShort i32 (i32.const 834))
  (global $__tid$StreamFault$StreamCancelled i32 (i32.const 835))
  (global $__tid$FileStat i32 (i32.const 836))
  (global $__tid$DirEntry i32 (i32.const 837))
  (global $__tid$FsStat i32 (i32.const 838))
  (global $__tid$MountEntry i32 (i32.const 839))
  (global $__tid$WinSize i32 (i32.const 840))
  (global $__tid$Pipe i32 (i32.const 841))
  (global $__tid$ProcessResult i32 (i32.const 842))
  (global $__tid$HeaderMap i32 (i32.const 843))
  (global $__tid$BodySource i32 (i32.const 844))
  (global $__tid$ByteStream i32 (i32.const 845))
  (global $__tid$ChunkProducer i32 (i32.const 846))
  (global $__tid$HttpRequest i32 (i32.const 847))
  (global $__tid$HttpResponse i32 (i32.const 848))
  (global $__tid$Instant i32 (i32.const 849))
  (global $__tid$Duration i32 (i32.const 850))
  (global $__tid$DateTime i32 (i32.const 851))
  (global $__tid$Date i32 (i32.const 852))
  (global $__tid$Time i32 (i32.const 853))
  (global $__tid$Span i32 (i32.const 854))
  (global $__tid$BytesWriter i32 (i32.const 855))
  (global $__tid$Url i32 (i32.const 856))
  (global $__tid$i32 i32 (i32.const 857))
  (global $__tid$boolean i32 (i32.const 858))
  (global $__tid$bool i32 (i32.const 859))
  (global $__tid$i64 i32 (i32.const 860))
  (global $__tid$u32 i32 (i32.const 861))
  (global $__tid$u64 i32 (i32.const 862))
  (global $__tid$usize i32 (i32.const 863))
  (global $__tid$f64 i32 (i32.const 864))
  (global $__tid$f32 i32 (i32.const 865))
  (global $__tid$string i32 (i32.const 866))
  (global $__tid$u8 i32 (i32.const 867))
  (global $__tid$char i32 (i32.const 868))
  (data (i32.const 192) "\07\00\00\00http://")
  (data (i32.const 204) "\08\00\00\00https://")
  (data (i32.const 216) "\0b\00\00\00!$&'()*+,;=")
  (data (i32.const 232) "\00\00\00\00")
  (data (i32.const 236) "\10\00\00\00Content-Length: ")
  (data (i32.const 256) "\02\00\00\00\0d\0a")
  (data (i32.const 264) "\09\00\00\00HTTP/1.1 ")
  (data (i32.const 280) "\01\00\00\00 ")
  (data (i32.const 288) "\08\00\00\00Continue")
  (data (i32.const 300) "\13\00\00\00Switching Protocols")
  (data (i32.const 324) "\02\00\00\00OK")
  (data (i32.const 332) "\07\00\00\00Created")
  (data (i32.const 344) "\08\00\00\00Accepted")
  (data (i32.const 356) "\1d\00\00\00Non-Authoritative Information")
  (data (i32.const 392) "\0a\00\00\00No Content")
  (data (i32.const 408) "\0d\00\00\00Reset Content")
  (data (i32.const 428) "\0f\00\00\00Partial Content")
  (data (i32.const 448) "\10\00\00\00Multiple Choices")
  (data (i32.const 468) "\11\00\00\00Moved Permanently")
  (data (i32.const 492) "\05\00\00\00Found")
  (data (i32.const 504) "\09\00\00\00See Other")
  (data (i32.const 520) "\0c\00\00\00Not Modified")
  (data (i32.const 536) "\09\00\00\00Use Proxy")
  (data (i32.const 552) "\12\00\00\00Temporary Redirect")
  (data (i32.const 576) "\12\00\00\00Permanent Redirect")
  (data (i32.const 600) "\0b\00\00\00Bad Request")
  (data (i32.const 616) "\0c\00\00\00Unauthorized")
  (data (i32.const 632) "\10\00\00\00Payment Required")
  (data (i32.const 652) "\09\00\00\00Forbidden")
  (data (i32.const 668) "\09\00\00\00Not Found")
  (data (i32.const 684) "\12\00\00\00Method Not Allowed")
  (data (i32.const 708) "\0e\00\00\00Not Acceptable")
  (data (i32.const 728) "\1d\00\00\00Proxy Authentication Required")
  (data (i32.const 764) "\0f\00\00\00Request Timeout")
  (data (i32.const 784) "\08\00\00\00Conflict")
  (data (i32.const 796) "\04\00\00\00Gone")
  (data (i32.const 804) "\0f\00\00\00Length Required")
  (data (i32.const 824) "\13\00\00\00Precondition Failed")
  (data (i32.const 848) "\11\00\00\00Payload Too Large")
  (data (i32.const 872) "\0c\00\00\00URI Too Long")
  (data (i32.const 888) "\16\00\00\00Unsupported Media Type")
  (data (i32.const 916) "\15\00\00\00Range Not Satisfiable")
  (data (i32.const 944) "\12\00\00\00Expectation Failed")
  (data (i32.const 968) "\0c\00\00\00I'm a teapot")
  (data (i32.const 984) "\13\00\00\00Misdirected Request")
  (data (i32.const 1008) "\14\00\00\00Unprocessable Entity")
  (data (i32.const 1032) "\09\00\00\00Too Early")
  (data (i32.const 1048) "\10\00\00\00Upgrade Required")
  (data (i32.const 1068) "\15\00\00\00Precondition Required")
  (data (i32.const 1096) "\11\00\00\00Too Many Requests")
  (data (i32.const 1120) "\1f\00\00\00Request Header Fields Too Large")
  (data (i32.const 1156) "\15\00\00\00Internal Server Error")
  (data (i32.const 1184) "\0f\00\00\00Not Implemented")
  (data (i32.const 1204) "\0b\00\00\00Bad Gateway")
  (data (i32.const 1220) "\13\00\00\00Service Unavailable")
  (data (i32.const 1244) "\0f\00\00\00Gateway Timeout")
  (data (i32.const 1264) "\1a\00\00\00HTTP Version Not Supported")
  (data (i32.const 1296) "\1f\00\00\00Network Authentication Required")
  (data (i32.const 1332) "\06\00\00\00Status")
  (data (i32.const 1344) "\0e\00\00\00content-length")
  (data (i32.const 1364) "\0a\00\00\00connection")
  (data (i32.const 1380) "\11\00\00\00transfer-encoding")
  (data (i32.const 1404) "\02\00\00\00: ")
  (data (i32.const 1412) "\17\00\00\00Connection: Upgrade\0d\0a\0d\0a")
  (data (i32.const 1440) "\15\00\00\00Connection: close\0d\0a\0d\0a")
  (data (i32.const 1468) "\1a\00\00\00Connection: keep-alive\0d\0a\0d\0a")
  (data (i32.const 1500) "\04\00\00\00HEAD")
  (data (i32.const 1508) "\01\00\00\000")
  (data (i32.const 1516) "\01\00\00\001")
  (data (i32.const 1524) "\01\00\00\002")
  (data (i32.const 1532) "\01\00\00\003")
  (data (i32.const 1540) "\01\00\00\004")
  (data (i32.const 1548) "\01\00\00\005")
  (data (i32.const 1556) "\01\00\00\006")
  (data (i32.const 1564) "\01\00\00\007")
  (data (i32.const 1572) "\01\00\00\008")
  (data (i32.const 1580) "\01\00\00\009")
  (data (i32.const 1588) "\02\00\00\0010")
  (data (i32.const 1596) "\02\00\00\0011")
  (data (i32.const 1604) "\02\00\00\0012")
  (data (i32.const 1612) "\02\00\00\0013")
  (data (i32.const 1620) "\02\00\00\0014")
  (data (i32.const 1628) "\02\00\00\0015")
  (data (i32.const 1636) "\02\00\00\0016")
  (data (i32.const 1644) "\02\00\00\0017")
  (data (i32.const 1652) "\02\00\00\0018")
  (data (i32.const 1660) "\02\00\00\0019")
  (data (i32.const 1668) "\02\00\00\0020")
  (data (i32.const 1676) "\02\00\00\0021")
  (data (i32.const 1684) "\02\00\00\0022")
  (data (i32.const 1692) "\02\00\00\0023")
  (data (i32.const 1700) "\02\00\00\0024")
  (data (i32.const 1708) "\02\00\00\0025")
  (data (i32.const 1716) "\02\00\00\0026")
  (data (i32.const 1724) "\02\00\00\0027")
  (data (i32.const 1732) "\02\00\00\0028")
  (data (i32.const 1740) "\02\00\00\0029")
  (data (i32.const 1748) "\02\00\00\0030")
  (data (i32.const 1756) "\02\00\00\0031")
  (data (i32.const 1764) "\02\00\00\0032")
  (data (i32.const 1772) "\02\00\00\0033")
  (data (i32.const 1780) "\02\00\00\0034")
  (data (i32.const 1788) "\02\00\00\0035")
  (data (i32.const 1796) "\02\00\00\0036")
  (data (i32.const 1804) "\02\00\00\0037")
  (data (i32.const 1812) "\02\00\00\0038")
  (data (i32.const 1820) "\02\00\00\0039")
  (data (i32.const 1828) "\02\00\00\0040")
  (data (i32.const 1836) "\02\00\00\0041")
  (data (i32.const 1844) "\02\00\00\0042")
  (data (i32.const 1852) "\02\00\00\0043")
  (data (i32.const 1860) "\02\00\00\0044")
  (data (i32.const 1868) "\02\00\00\0045")
  (data (i32.const 1876) "\02\00\00\0046")
  (data (i32.const 1884) "\02\00\00\0047")
  (data (i32.const 1892) "\02\00\00\0048")
  (data (i32.const 1900) "\02\00\00\0049")
  (data (i32.const 1908) "\02\00\00\0050")
  (data (i32.const 1916) "\02\00\00\0051")
  (data (i32.const 1924) "\02\00\00\0052")
  (data (i32.const 1932) "\02\00\00\0053")
  (data (i32.const 1940) "\02\00\00\0054")
  (data (i32.const 1948) "\02\00\00\0055")
  (data (i32.const 1956) "\02\00\00\0056")
  (data (i32.const 1964) "\02\00\00\0057")
  (data (i32.const 1972) "\02\00\00\0058")
  (data (i32.const 1980) "\02\00\00\0059")
  (data (i32.const 1988) "\02\00\00\0060")
  (data (i32.const 1996) "\02\00\00\0061")
  (data (i32.const 2004) "\02\00\00\0062")
  (data (i32.const 2012) "\02\00\00\0063")
  (data (i32.const 2020) "\02\00\00\0064")
  (data (i32.const 2028) "\02\00\00\0065")
  (data (i32.const 2036) "\02\00\00\0066")
  (data (i32.const 2044) "\02\00\00\0067")
  (data (i32.const 2052) "\02\00\00\0068")
  (data (i32.const 2060) "\02\00\00\0069")
  (data (i32.const 2068) "\02\00\00\0070")
  (data (i32.const 2076) "\02\00\00\0071")
  (data (i32.const 2084) "\02\00\00\0072")
  (data (i32.const 2092) "\02\00\00\0073")
  (data (i32.const 2100) "\02\00\00\0074")
  (data (i32.const 2108) "\02\00\00\0075")
  (data (i32.const 2116) "\02\00\00\0076")
  (data (i32.const 2124) "\02\00\00\0077")
  (data (i32.const 2132) "\02\00\00\0078")
  (data (i32.const 2140) "\02\00\00\0079")
  (data (i32.const 2148) "\02\00\00\0080")
  (data (i32.const 2156) "\02\00\00\0081")
  (data (i32.const 2164) "\02\00\00\0082")
  (data (i32.const 2172) "\02\00\00\0083")
  (data (i32.const 2180) "\02\00\00\0084")
  (data (i32.const 2188) "\02\00\00\0085")
  (data (i32.const 2196) "\02\00\00\0086")
  (data (i32.const 2204) "\02\00\00\0087")
  (data (i32.const 2212) "\02\00\00\0088")
  (data (i32.const 2220) "\02\00\00\0089")
  (data (i32.const 2228) "\02\00\00\0090")
  (data (i32.const 2236) "\02\00\00\0091")
  (data (i32.const 2244) "\02\00\00\0092")
  (data (i32.const 2252) "\02\00\00\0093")
  (data (i32.const 2260) "\02\00\00\0094")
  (data (i32.const 2268) "\02\00\00\0095")
  (data (i32.const 2276) "\02\00\00\0096")
  (data (i32.const 2284) "\02\00\00\0097")
  (data (i32.const 2292) "\02\00\00\0098")
  (data (i32.const 2300) "\02\00\00\0099")
  (data (i32.const 2308) "\c8\00\00\0000010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899")
  (data (i32.const 2512) "\49\00\00\00GET /hello HTTP/1.1\0d\0aHost: bench\0d\0aUser-Agent: perf-bench\0d\0aAccept: */*\0d\0a\0d\0a")
  (data (i32.const 2592) "\07\00\00\00OPTIONS")
  (data (i32.const 2604) "\01\00\00\00*")
  (data (i32.const 2612) "\08\00\00\00HTTP/1.0")
  (data (i32.const 2624) "\08\00\00\00HTTP/1.1")
  (data (i32.const 2636) "\04\00\00\00host")
  (data (i32.const 2644) "\06\00\00\00expect")
  (data (i32.const 2656) "\0c\00\00\00100-continue")
  (data (i32.const 2672) "\01\00\00\00,")
  (data (i32.const 2680) "\07\00\00\00chunked")
  (data (i32.const 2692) "\05\00\00\00close")
  (data (i32.const 2704) "\0a\00\00\00keep-alive")
  (data (i32.const 2720) "\06\00\00\00hello ")
  (data (i32.const 2732) "\03\00\00\00GET")
  (data (i32.const 2740) "\1f\00\00\00fern: array index out of range\0a")
  (data (i32.const 2776) "\20\00\00\00fern: string index out of range\0a")
  (data (i32.const 2812) "\20\00\00\00fern: slice range out of bounds\0a")
  (data (i32.const 2848) "\23\00\00\00fern: allocation size out of range\0a")
  (data (i32.const 2888) "\2b\00\00\00fern: out of memory (heap arena exhausted)\0a")
  (data (i32.const 2936) "\29\00\00\00fern: release of memory outside the heap\0a")
  (data (i32.const 2984) "\2d\00\00\00fern: release of memory that is already free\0a")
  (global $__cagg_base i32 (i32.const 3040))
  (global $__cagg_base$runtime i32 (i32.const 4520))
  (data (i32.const 3040) "\ff\ff\ff\ff\10\00\00\00\00\00\00\00\00\00\00\00")
  (data (i32.const 3056) "\ff\ff\ff\ff\20\00\00\00\4b\03\00\00\00\00\00\00\e8\0b\00\00\00\00\00\00\e8\0b\00\00\00\00\00\00")
  (data (i32.const 3088) "\ff\ff\ff\ff\10\01\00\00\00\01\00\00\00\01\00\00\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\00\01\00\00\00\00\00\01\01\00\00\01\00\00\01\00\00\00\00\00\00\00\00\00\00\01\01\01\01\01\01\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\01\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\01\00\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01")
  (data (i32.const 3360) "\ff\ff\ff\ff\10\00\00\00\00\00\00\00\00\00\00\00")
  (data (i32.const 3376) "\ff\ff\ff\ff\18\00\00\00\37\03\00\00\00\00\00\00\e8\00\00\00\00\00\00\00")
  (data (i32.const 3400) "\ff\ff\ff\ff\10\00\00\00\01\00\00\00\00\00\00\00")
  (data (i32.const 3416) "\ff\ff\ff\ff\38\00\00\00\50\03\00\00\00\00\00\00\f4\01\00\00\00\00\00\00\38\0d\00\00\00\00\00\00\f8\0b\00\00\00\00\00\00\f8\0b\00\00\00\00\00\00\50\0d\00\00\00\00\00\00")
  (data (i32.const 3472) "\ff\ff\ff\ff\d8\00\00\00\32\00\00\00\32\00\00\00\64\00\00\00\65\00\00\00\c8\00\00\00\c9\00\00\00\ca\00\00\00\cb\00\00\00\cc\00\00\00\cd\00\00\00\ce\00\00\00\2c\01\00\00\2d\01\00\00\2e\01\00\00\2f\01\00\00\30\01\00\00\31\01\00\00\33\01\00\00\34\01\00\00\90\01\00\00\91\01\00\00\92\01\00\00\93\01\00\00\94\01\00\00\95\01\00\00\96\01\00\00\97\01\00\00\98\01\00\00\99\01\00\00\9a\01\00\00\9b\01\00\00\9c\01\00\00\9d\01\00\00\9e\01\00\00\9f\01\00\00\a0\01\00\00\a1\01\00\00\a2\01\00\00\a5\01\00\00\a6\01\00\00\a9\01\00\00\aa\01\00\00\ac\01\00\00\ad\01\00\00\af\01\00\00\f4\01\00\00\f5\01\00\00\f6\01\00\00\f7\01\00\00\f8\01\00\00\f9\01\00\00\ff\01\00\00")
  (data (i32.const 3688) "\ff\ff\ff\ff\d8\00\00\00\32\00\00\00\32\00\00\00\20\01\00\00\2c\01\00\00\44\01\00\00\4c\01\00\00\58\01\00\00\64\01\00\00\88\01\00\00\98\01\00\00\ac\01\00\00\c0\01\00\00\d4\01\00\00\ec\01\00\00\f8\01\00\00\08\02\00\00\18\02\00\00\28\02\00\00\40\02\00\00\58\02\00\00\68\02\00\00\78\02\00\00\8c\02\00\00\9c\02\00\00\ac\02\00\00\c4\02\00\00\d8\02\00\00\fc\02\00\00\10\03\00\00\1c\03\00\00\24\03\00\00\38\03\00\00\50\03\00\00\68\03\00\00\78\03\00\00\94\03\00\00\b0\03\00\00\c8\03\00\00\d8\03\00\00\f0\03\00\00\08\04\00\00\18\04\00\00\2c\04\00\00\48\04\00\00\60\04\00\00\84\04\00\00\a0\04\00\00\b4\04\00\00\c4\04\00\00\dc\04\00\00\f0\04\00\00\10\05\00\00")
  (data (i32.const 3904) "\ff\ff\ff\ff\90\00\00\00\80\00\00\00\80\00\00\00\01\01\01\01\01\01\01\01\01\00\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01")
  (data (i32.const 4048) "\ff\ff\ff\ff\a0\01\00\00\64\00\00\00\64\00\00\00\e4\05\00\00\ec\05\00\00\f4\05\00\00\fc\05\00\00\04\06\00\00\0c\06\00\00\14\06\00\00\1c\06\00\00\24\06\00\00\2c\06\00\00\34\06\00\00\3c\06\00\00\44\06\00\00\4c\06\00\00\54\06\00\00\5c\06\00\00\64\06\00\00\6c\06\00\00\74\06\00\00\7c\06\00\00\84\06\00\00\8c\06\00\00\94\06\00\00\9c\06\00\00\a4\06\00\00\ac\06\00\00\b4\06\00\00\bc\06\00\00\c4\06\00\00\cc\06\00\00\d4\06\00\00\dc\06\00\00\e4\06\00\00\ec\06\00\00\f4\06\00\00\fc\06\00\00\04\07\00\00\0c\07\00\00\14\07\00\00\1c\07\00\00\24\07\00\00\2c\07\00\00\34\07\00\00\3c\07\00\00\44\07\00\00\4c\07\00\00\54\07\00\00\5c\07\00\00\64\07\00\00\6c\07\00\00\74\07\00\00\7c\07\00\00\84\07\00\00\8c\07\00\00\94\07\00\00\9c\07\00\00\a4\07\00\00\ac\07\00\00\b4\07\00\00\bc\07\00\00\c4\07\00\00\cc\07\00\00\d4\07\00\00\dc\07\00\00\e4\07\00\00\ec\07\00\00\f4\07\00\00\fc\07\00\00\04\08\00\00\0c\08\00\00\14\08\00\00\1c\08\00\00\24\08\00\00\2c\08\00\00\34\08\00\00\3c\08\00\00\44\08\00\00\4c\08\00\00\54\08\00\00\5c\08\00\00\64\08\00\00\6c\08\00\00\74\08\00\00\7c\08\00\00\84\08\00\00\8c\08\00\00\94\08\00\00\9c\08\00\00\a4\08\00\00\ac\08\00\00\b4\08\00\00\bc\08\00\00\c4\08\00\00\cc\08\00\00\d4\08\00\00\dc\08\00\00\e4\08\00\00\ec\08\00\00\f4\08\00\00\fc\08\00\00")
  (data (i32.const 4464) "\ff\ff\ff\ff\20\00\00\00\0e\00\00\00\0e\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\01\00\00")
  (data (i32.const 4496) "\ff\ff\ff\ff\18\00\00\00\05\00\00\00\05\00\00\00\48\54\54\50\2f\00\00\00")
  (global $__fern_ret_word (mut i32) (i32.const 0))
  (global $__fern_ret_word1 (mut i32) (i32.const 0))
  (global $__fern_scalar_word0 (mut i64) (i64.const 0))
  (global $__fern_scalar_word1 (mut i64) (i64.const 0))
  (global $__fern_scalar_word2 (mut i64) (i64.const 0))
  (global $__fern_rc_underflow (mut i32) (i32.const 0))
  (global $__fern_heap_base i32 (i32.const 274864))
  (global $heap (mut i32) (i32.const 274864))
  (global $__fern_heap_pages (mut i32) (i32.const 16))
  (func $__fern_capw (param $w i32) (result i32)
    (local $g i32)
    (if (i32.le_u (local.get $w) (i32.const 256)) (then (return (local.get $w))))
    (if (i32.ge_u (local.get $w) (i32.const 65536)) (then (return (local.get $w))))
    (local.set $g (i32.shl (i32.const 1) (i32.sub (i32.const 29) (i32.clz (local.get $w)))))
    (local.set $w (i32.and (i32.add (local.get $w) (i32.sub (local.get $g) (i32.const 1))) (i32.sub (i32.const 0) (local.get $g))))
    (if (i32.ge_u (local.get $w) (i32.const 65536)) (then (return (i32.sub (i32.const 65536) (i32.const 1)))))
    (local.get $w))
  (func $__fern_alloc (param $n i32) (result i32)
    (local $p i32) (local $cls i32) (local $head i32)
    (if (i32.gt_u (local.get $n) (i32.const 2147483647)) (then (call $__fern_abort_alloc) (unreachable)))
    (local.set $n (i32.and (i32.add (local.get $n) (i32.const 7)) (i32.const -8)))
    (local.set $cls (call $__fern_capw (i32.shr_u (local.get $n) (i32.const 3))))
    (if (i32.lt_u (local.get $cls) (i32.const 65536)) (then
      (local.set $n (i32.shl (local.get $cls) (i32.const 3)))
      (local.set $head (i32.load (i32.add (i32.const 4520) (i32.mul (local.get $cls) (i32.const 4)))))
      (if (local.get $head) (then
        (i32.store (i32.add (i32.const 4520) (i32.mul (local.get $cls) (i32.const 4))) (i32.load (i32.add (local.get $head) (i32.const 4))))
        (return (local.get $head)))))
    (else (if (i32.le_u (local.get $n) (i32.const 1073741824)) (then
      (local.set $n (call $__fern_large_cap (local.get $n)))
      (local.set $cls (call $__fern_large_cls (local.get $n)))
      (local.set $head (i32.load (i32.add (i32.const 266664) (i32.mul (local.get $cls) (i32.const 4)))))
      (if (local.get $head) (then
        (i32.store (i32.add (i32.const 266664) (i32.mul (local.get $cls) (i32.const 4))) (i32.load (i32.add (local.get $head) (i32.const 4))))
        (return (local.get $head))))))))
    (if (i32.gt_u (memory.size) (global.get $__fern_heap_pages)) (then
      (if (i32.ge_u (memory.size) (i32.const 65536)) (then (call $__fern_abort_oom) (unreachable)))
      (global.set $heap (i32.shl (memory.size) (i32.const 16)))
      (global.set $__fern_heap_pages (memory.size))))
    (local.set $p (global.get $heap))
    (global.set $heap (i32.add (global.get $heap) (local.get $n)))
    (if (i32.lt_u (global.get $heap) (local.get $p)) (then (call $__fern_abort_oom) (unreachable)))
    (if (i32.gt_u (global.get $heap) (i32.mul (memory.size) (i32.const 65536)))
      (then (if (i32.eq (memory.grow (i32.div_u (i32.add (i32.sub (global.get $heap) (i32.mul (memory.size) (i32.const 65536))) (i32.const 65535)) (i32.const 65536))) (i32.const -1)) (then (call $__fern_abort_oom) (unreachable)))))
    (global.set $__fern_heap_pages (memory.size))
    (local.get $p))
  (func $__fern_large_cap (param $n i32) (result i32)
    (local $g i32)
    (if (i32.lt_u (local.get $n) (i32.const 524288)) (then (local.set $n (i32.const 524288))))
    (local.set $g (i32.shl (i32.const 1) (i32.sub (i32.const 29) (i32.clz (local.get $n)))))
    (i32.and (i32.sub (i32.add (local.get $n) (local.get $g)) (i32.const 1)) (i32.sub (i32.const 0) (local.get $g))))
  (func $__fern_large_cls (param $cap i32) (result i32)
    (local $s i32)
    (local.set $s (i32.sub (i32.const 29) (i32.clz (local.get $cap))))
    (i32.sub (i32.add (i32.shr_u (local.get $cap) (local.get $s)) (i32.shl (local.get $s) (i32.const 2))) (i32.const 72)))
  (func $__fern_large_push (param $base i32) (param $bytes i32)
    (local $slot i32)
    (if (i32.gt_u (local.get $bytes) (i32.const 1073741824)) (then (return)))
    (local.set $slot (i32.add (i32.const 266664) (i32.mul (call $__fern_large_cls (call $__fern_large_cap (local.get $bytes))) (i32.const 4))))
    (if (i32.eq (local.get $base) (i32.load (local.get $slot))) (then (call $__fern_abort_double_free) (unreachable)))
    (i32.store (i32.add (local.get $base) (i32.const 4)) (i32.load (local.get $slot)))
    (i32.store (local.get $slot) (local.get $base)))
  (func $__fern_account_entry (param $kind i32) (param $key i32) (result i32) (i32.const 0))
  (func $__fern_str_grow (param $a i32) (param $b i32) (result i32)
    (call $__fern_str_grow_bytes (local.get $a) (i32.add (local.get $b) (i32.const 4)) (i32.load (local.get $b))))
  (func $__fern_str_grow_range (param $a i32) (param $s i32) (param $lo i32) (param $hi i32) (result i32)
    (if (i32.or (i32.lt_s (local.get $lo) (i32.const 0)) (i32.or (i32.lt_s (local.get $hi) (local.get $lo)) (i32.gt_s (local.get $hi) (i32.load (local.get $s))))) (then (return (i32.const 0))))
    (call $__fern_str_grow_bytes (local.get $a) (i32.add (i32.add (local.get $s) (i32.const 4)) (local.get $lo)) (i32.sub (local.get $hi) (local.get $lo))))
  (func $__fern_str_grow_bytes (param $a i32) (param $src i32) (param $lb i32) (result i32)
    (local $la i32) (local $bsz i32) (local $cap i32)
    (if (i32.eqz (local.get $a)) (then (return (i32.const 0))))
    (if (i32.and (local.get $a) (i32.const 1)) (then (return (i32.const 0))))
    (if (i32.lt_u (local.get $a) (i32.const 274864)) (then (return (i32.const 0))))
    (if (i32.ne (i32.load (i32.sub (local.get $a) (i32.const 8))) (i32.const 1)) (then (return (i32.const 0))))
    (local.set $la (i32.load (local.get $a)))
    (if (i32.gt_u (i32.add (local.get $la) (local.get $lb)) (i32.const 1073741824)) (then (return (i32.const 0))))
    (local.set $bsz (i32.load (i32.sub (local.get $a) (i32.const 4))))
    (local.set $cap (call $__fern_capw (i32.shr_u (local.get $bsz) (i32.const 3))))
    (if (i32.lt_u (local.get $cap) (i32.const 65536))
      (then (local.set $cap (i32.shl (local.get $cap) (i32.const 3))))
      (else (if (i32.gt_u (local.get $bsz) (i32.const 1073741824))
        (then (local.set $cap (local.get $bsz)))
        (else (local.set $cap (call $__fern_large_cap (local.get $bsz)))))))
    (if (i32.gt_u (i32.and (i32.add (i32.add (local.get $la) (local.get $lb)) (i32.const 19)) (i32.const -8)) (local.get $cap)) (then (return (i32.const 0))))
    (memory.copy (i32.add (i32.add (local.get $a) (i32.const 4)) (local.get $la)) (local.get $src) (local.get $lb))
    (i32.store (local.get $a) (i32.add (local.get $la) (local.get $lb)))
    (i32.const 1))
  (func $__fern_str_grow_fresh (param $a i32) (param $b i32) (result i32)
    (call $__fern_str_grow_fresh_bytes (local.get $a) (i32.add (local.get $b) (i32.const 4)) (i32.load (local.get $b))))
  (func $__fern_str_grow_fresh_range (param $a i32) (param $s i32) (param $lo i32) (param $hi i32) (result i32)
    (if (i32.or (i32.lt_s (local.get $lo) (i32.const 0)) (i32.or (i32.lt_s (local.get $hi) (local.get $lo)) (i32.gt_s (local.get $hi) (i32.load (local.get $s))))) (then (call $__fern_abort_str) (unreachable)))
    (call $__fern_str_grow_fresh_bytes (local.get $a) (i32.add (i32.add (local.get $s) (i32.const 4)) (local.get $lo)) (i32.sub (local.get $hi) (local.get $lo))))
  (func $__fern_str_grow_fresh_bytes (param $a i32) (param $src i32) (param $lb i32) (result i32)
    (local $la i32) (local $need i32) (local $n i32) (local $w i32) (local $base i32)
    (local.set $la (i32.load (local.get $a)))
    (if (i32.gt_u (i32.add (local.get $la) (local.get $lb)) (i32.const 1073741824)) (then (call $__fern_abort_alloc) (unreachable)))
    (local.set $need (i32.and (i32.add (i32.add (local.get $la) (local.get $lb)) (i32.const 19)) (i32.const -8)))
    (local.set $n (i32.shl (i32.and (i32.add (local.get $la) (i32.const 19)) (i32.const -8)) (i32.const 1)))
    (if (i32.lt_u (local.get $n) (local.get $need)) (then (local.set $n (local.get $need))))
    (local.set $w (call $__fern_capw (i32.shr_u (local.get $n) (i32.const 3))))
    (if (i32.lt_u (local.get $w) (i32.const 65536))
      (then (local.set $n (i32.shl (local.get $w) (i32.const 3))))
      (else (if (i32.le_u (local.get $n) (i32.const 1073741824)) (then (local.set $n (call $__fern_large_cap (local.get $n)))))))
    (local.set $base (call $__fern_alloc (local.get $n)))
    (i32.store (local.get $base) (i32.const 1))
    (i32.store (i32.add (local.get $base) (i32.const 4)) (local.get $n))
    (i32.store (i32.add (local.get $base) (i32.const 8)) (i32.add (local.get $la) (local.get $lb)))
    (memory.copy (i32.add (local.get $base) (i32.const 12)) (i32.add (local.get $a) (i32.const 4)) (local.get $la))
    (memory.copy (i32.add (i32.add (local.get $base) (i32.const 12)) (local.get $la)) (local.get $src) (local.get $lb))
    (i32.add (local.get $base) (i32.const 8)))
  (func $__fern_raw_free (param $base i32) (param $bytes i32)
    (local $cls i32) (local $slot i32)
    (if (i32.eqz (local.get $base)) (then (return)))
    (if (i32.lt_u (local.get $base) (i32.const 274864)) (then (call $__fern_abort_free_range) (unreachable)))
    (if (i32.or (i32.gt_u (local.get $base) (global.get $heap)) (i32.and (i32.eq (local.get $base) (global.get $heap)) (i32.ne (local.get $bytes) (i32.const 0)))) (then (call $__fern_abort_free_range) (unreachable)))
    (local.set $bytes (i32.and (i32.add (local.get $bytes) (i32.const 7)) (i32.const -8)))
    (if (i32.lt_u (local.get $bytes) (i32.const 8)) (then (return)))
    (local.set $cls (call $__fern_capw (i32.shr_u (local.get $bytes) (i32.const 3))))
    (if (i32.lt_u (local.get $cls) (i32.const 65536)) (then
      (local.set $slot (i32.add (i32.const 4520) (i32.mul (local.get $cls) (i32.const 4))))
      (if (i32.eq (local.get $base) (i32.load (local.get $slot))) (then (call $__fern_abort_double_free) (unreachable)))
      (i32.store (i32.add (local.get $base) (i32.const 4)) (i32.load (local.get $slot)))
      (i32.store (local.get $slot) (local.get $base))
      (return)))
    (call $__fern_large_push (local.get $base) (local.get $bytes)))
  (func $__fern_arr_box (param $eb i32) (result i32)
    (local $base i32) (local $n i32)
    (local.set $n (i32.and (i32.add (i32.add (i32.const 16) (local.get $eb)) (i32.const 7)) (i32.const -8)))
    (local.set $base (call $__fern_alloc (local.get $n)))
    (i32.store (local.get $base) (i32.const 1))
    (i32.store (i32.add (local.get $base) (i32.const 4)) (local.get $n))
    (i32.add (local.get $base) (i32.const 8)))
  (func $__fern_arr_elems (param $n i32) (param $stride i32) (result i32)
    (local $b i64)
    (local.set $b (i64.mul (i64.extend_i32_u (local.get $n)) (i64.extend_i32_u (local.get $stride))))
    (if (i64.gt_u (local.get $b) (i64.const 2147483631)) (then (call $__fern_abort_alloc) (unreachable)))
    (call $__fern_arr_box (i32.wrap_i64 (local.get $b))))
  (func $__fern_str_box (param $p i32) (result i32)
    (local $base i32) (local $n i32)
    (local.set $n (i32.and (i32.add (i32.add (i32.const 8) (local.get $p)) (i32.const 7)) (i32.const -8)))
    (local.set $base (call $__fern_alloc (local.get $n)))
    (i32.store (local.get $base) (i32.const 1))
    (i32.store (i32.add (local.get $base) (i32.const 4)) (local.get $n))
    (i32.add (local.get $base) (i32.const 8)))
  (func $__fern_alloc_reuse (param $t i32) (param $nf i32) (result i32)
    (local $want i32) (local $base i32) (local $cls i32)
    (local.set $want (i32.add (i32.const 8) (i32.mul (local.get $nf) (i32.const 8))))
    (if (i32.eqz (local.get $t)) (then
      (return (call $__fern_str_box (i32.mul (local.get $nf) (i32.const 8))))))
    (local.set $base (i32.sub (local.get $t) (i32.const 8)))
    (if (i32.eq (i32.load (i32.add (local.get $base) (i32.const 4))) (local.get $want)) (then
      (return (local.get $t))))
    (local.set $cls (call $__fern_capw (i32.shr_u (i32.load (i32.add (local.get $base) (i32.const 4))) (i32.const 3))))
    (i32.store (local.get $base) (i32.const 0))
    (if (i32.lt_u (local.get $cls) (i32.const 65536)) (then
      (i32.store (i32.add (local.get $base) (i32.const 4)) (i32.load (i32.add (i32.const 4520) (i32.mul (local.get $cls) (i32.const 4)))))
      (i32.store (i32.add (i32.const 4520) (i32.mul (local.get $cls) (i32.const 4))) (local.get $base)))
    (else (call $__fern_large_push (local.get $base) (i32.load (i32.add (local.get $base) (i32.const 4))))))
    (call $__fern_str_box (i32.mul (local.get $nf) (i32.const 8))))
  (func $__fern_arr_dec (param $a i32) (result i32)
    (local $base i32) (local $rc i32) (local $cls i32)
    (if (i32.eqz (local.get $a)) (then (return (local.get $a))))
    (if (i32.and (local.get $a) (i32.const 1)) (then (return (local.get $a))))
    (if (i32.lt_u (local.get $a) (i32.const 274864)) (then (return (local.get $a))))
    (local.set $base (i32.sub (local.get $a) (i32.const 8)))
    (local.set $rc (i32.load (local.get $base)))
    (if (i32.lt_s (local.get $rc) (i32.const 0)) (then (return (local.get $a))))
    (if (i32.gt_s (local.get $rc) (i32.const 1)) (then
      (i32.store (local.get $base) (i32.sub (local.get $rc) (i32.const 1)))
      (return (local.get $a))))
    (if (i32.le_s (local.get $rc) (i32.const 0)) (then
      (global.set $__fern_rc_underflow (i32.add (global.get $__fern_rc_underflow) (i32.const 1)))
      (return (local.get $a))))
    (local.set $cls (call $__fern_capw (i32.shr_u (i32.load (i32.add (local.get $base) (i32.const 4))) (i32.const 3))))
    (i32.store (local.get $base) (i32.const 0))
    (if (i32.lt_u (local.get $cls) (i32.const 65536)) (then
      (i32.store (i32.add (local.get $base) (i32.const 4)) (i32.load (i32.add (i32.const 4520) (i32.mul (local.get $cls) (i32.const 4)))))
      (i32.store (i32.add (i32.const 4520) (i32.mul (local.get $cls) (i32.const 4))) (local.get $base)))
    (else (call $__fern_large_push (local.get $base) (i32.load (i32.add (local.get $base) (i32.const 4))))))
    (local.get $a))
  (func $__fern_arr_dec_ptr (param $a i32) (result i32)
    (local $i i32) (local $n i32)
    (if (i32.eqz (local.get $a)) (then (return (local.get $a))))
    (if (i32.and (local.get $a) (i32.const 1)) (then (return (local.get $a))))
    (if (i32.lt_u (local.get $a) (i32.const 274864)) (then (return (local.get $a))))
    (if (i32.eq (i32.load (i32.sub (local.get $a) (i32.const 8))) (i32.const 1)) (then
      (local.set $n (i32.load (local.get $a)))
      (local.set $i (i32.const 0))
      (block $adp_done (loop $adp_lp
        (br_if $adp_done (i32.ge_u (local.get $i) (local.get $n)))
        (drop (call $__fern_arr_dec (i32.load (i32.add (i32.add (local.get $a) (i32.const 8)) (i32.mul (local.get $i) (i32.const 4))))))
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $adp_lp))))) 
    (call $__fern_arr_dec (local.get $a)))
  (func $__fern_oob_abort (result i32) (call $__fern_abort_arr) (unreachable))
  (func $__fern_slice_abort (result i32) (call $__fern_abort_slice) (unreachable))
  (func $__alloc (param $n i32) (result i32)
    (call $__fern_alloc (local.get $n)))
  (func $__free (param $p i32) (result i32)
    (local.get $p))
  (func $__load_i32 (param $a i32) (result i32)
    (i32.load (local.get $a)))
  (func $__store_i32 (param $a i32) (param $v i32) (result i32)
    (i32.store (local.get $a) (local.get $v))
    (local.get $a))
  (func $__fern_rc_inc (param $p i32) (result i32)
    (local $rc i32)
    (local $base i32)
    (if (i32.eqz (local.get $p)) (then (return (local.get $p))))
    (if (i32.and (local.get $p) (i32.const 1)) (then (return (local.get $p))))
    (if (i32.lt_u (local.get $p) (i32.const 274864)) (then (return (local.get $p))))
    (local.set $base (i32.and (local.get $p) (i32.const -3)))
    (local.set $rc (i32.load (i32.sub (local.get $base) (i32.const 8))))
    (if (i32.lt_s (local.get $rc) (i32.const 0)) (then (return (local.get $p))))
    (i32.store (i32.sub (local.get $base) (i32.const 8)) (i32.add (local.get $rc) (i32.const 1)))
    (local.get $p))
  (func $__fern_rc_dec (param $p i32) (result i32)
    (local $rc i32)
    (if (i32.eqz (local.get $p)) (then (return (local.get $p))))
    (if (i32.and (local.get $p) (i32.const 1)) (then (return (local.get $p))))
    (if (i32.lt_u (local.get $p) (i32.const 274864)) (then (return (local.get $p))))
    (local.set $rc (i32.load (i32.sub (local.get $p) (i32.const 8))))
    (if (i32.lt_s (local.get $rc) (i32.const 0)) (then (return (local.get $p))))
    (if (i32.le_s (local.get $rc) (i32.const 0))
      (then (global.set $__fern_rc_underflow (i32.add (global.get $__fern_rc_underflow) (i32.const 1)))))
    (i32.store (i32.sub (local.get $p) (i32.const 8)) (i32.sub (local.get $rc) (i32.const 1)))
    (local.get $p))
  (func $__fern_rc_is_unique (param $p i32) (result i32)
    (local $rc i32)
    (if (i32.eqz (local.get $p)) (then (return (i32.const 0))))
    (if (i32.and (local.get $p) (i32.const 1)) (then (return (i32.const 0))))
    (if (i32.lt_u (local.get $p) (i32.const 274864)) (then (return (i32.const 0))))
    (local.set $p (i32.and (local.get $p) (i32.const -3)))
    (local.set $rc (i32.load (i32.sub (local.get $p) (i32.const 8))))
    (if (i32.lt_s (local.get $rc) (i32.const 0)) (then (return (i32.const 0))))
    (if (i32.eq (local.get $rc) (i32.const 1)) (then (return (i32.const 1))))
    (i32.const 0))
  (func $__fern_arr_inc_elems (param $a i32) (result i32)
    (local $i i32) (local $n i32)
    (if (i32.eqz (local.get $a)) (then (return (local.get $a))))
    (if (i32.and (local.get $a) (i32.const 1)) (then (return (local.get $a))))
    (if (i32.lt_u (local.get $a) (i32.const 274864)) (then (return (local.get $a))))
    (if (i32.lt_s (i32.load (i32.sub (local.get $a) (i32.const 8))) (i32.const 0)) (then (return (local.get $a))))
    (local.set $n (i32.load (local.get $a)))
    (local.set $i (i32.const 0))
    (block $aie_done (loop $aie_lp
      (br_if $aie_done (i32.ge_u (local.get $i) (local.get $n)))
      (drop (call $__fern_rc_inc (i32.load (i32.add (i32.add (local.get $a) (i32.const 8)) (i32.mul (local.get $i) (i32.const 4))))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $aie_lp)))
    (local.get $a))
  (func $__fern_arr_own_elems (param $d i32) (param $s i32) (result i32)
    (drop (call $__fern_arr_inc_elems (local.get $s)))
    (local.get $d))
  (func $__fern_rc_underflow_count (result i32)
    (global.get $__fern_rc_underflow))
  (func $__fern_buf_new (param $cap i32) (result i32)
    (local $h i32)
    (if (i32.lt_u (local.get $cap) (i32.const 16)) (then (local.set $cap (i32.const 16))))
    (local.set $h (call $__fern_str_box (i32.const 16)))
    (i32.store (local.get $h) (call $__fern_str_box (i32.add (i32.const 4) (local.get $cap))))
    (i32.store (i32.add (local.get $h) (i32.const 4)) (i32.const 0))
    (i32.store (i32.add (local.get $h) (i32.const 8)) (local.get $cap))
    (i32.store (i32.add (local.get $h) (i32.const 12)) (local.get $cap))
    (local.get $h))
  (func $__fern_buf_reserve (param $h i32) (param $need i32)
    (local $ncap i32) (local $np i32) (local $i i32) (local $len i32) (local $old i32)
    (local.set $ncap (i32.load (i32.add (local.get $h) (i32.const 8))))
    (if (i32.eqz (local.get $ncap)) (then (local.set $ncap (i32.load (i32.add (local.get $h) (i32.const 12))))))
    (if (i32.eqz (local.get $ncap)) (then (local.set $ncap (i32.const 64))))
    (block $gd (loop $gl (br_if $gd (i32.ge_u (local.get $ncap) (local.get $need))) (local.set $ncap (i32.mul (local.get $ncap) (i32.const 2))) (br $gl)))
    (local.set $np (call $__fern_str_box (i32.add (i32.const 4) (local.get $ncap))))
    (local.set $old (i32.load (local.get $h)))
    (local.set $len (i32.load (i32.add (local.get $h) (i32.const 4))))
    (local.set $i (i32.const 0))
    (block $cd (loop $cl (br_if $cd (i32.ge_u (local.get $i) (local.get $len)))
      (i32.store8 (i32.add (i32.add (local.get $np) (i32.const 4)) (local.get $i)) (i32.load8_u (i32.add (i32.add (local.get $old) (i32.const 4)) (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1))) (br $cl)))
    (if (local.get $old) (then (drop (call $__fern_arr_dec (local.get $old)))))
    (i32.store (local.get $h) (local.get $np))
    (i32.store (i32.add (local.get $h) (i32.const 8)) (local.get $ncap)))
  (func $__fern_buf_push (param $h i32) (param $s i32)
    (local $sl i32) (local $i i32) (local $d i32) (local $len i32)
    (local.set $sl (i32.load (local.get $s)))
    (if (i32.eqz (local.get $sl)) (then (return)))
    (local.set $len (i32.load (i32.add (local.get $h) (i32.const 4))))
    (if (i32.gt_u (i32.add (local.get $len) (local.get $sl)) (i32.load (i32.add (local.get $h) (i32.const 8))))
      (then (call $__fern_buf_reserve (local.get $h) (i32.add (local.get $len) (local.get $sl)))))
    (local.set $d (i32.add (i32.add (i32.load (local.get $h)) (i32.const 4)) (local.get $len)))
    (local.set $i (i32.const 0))
    (block $ad (loop $al (br_if $ad (i32.ge_u (local.get $i) (local.get $sl)))
      (i32.store8 (i32.add (local.get $d) (local.get $i)) (i32.load8_u (i32.add (i32.add (local.get $s) (i32.const 4)) (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1))) (br $al)))
    (i32.store (i32.add (local.get $h) (i32.const 4)) (i32.add (local.get $len) (local.get $sl))))
  (func $__fern_buf_push_byte (param $h i32) (param $x i32)
    (local $len i32)
    (local.set $len (i32.load (i32.add (local.get $h) (i32.const 4))))
    (if (i32.gt_u (i32.add (local.get $len) (i32.const 1)) (i32.load (i32.add (local.get $h) (i32.const 8))))
      (then (call $__fern_buf_reserve (local.get $h) (i32.add (local.get $len) (i32.const 1)))))
    (i32.store8 (i32.add (i32.add (i32.load (local.get $h)) (i32.const 4)) (local.get $len)) (local.get $x))
    (i32.store (i32.add (local.get $h) (i32.const 4)) (i32.add (local.get $len) (i32.const 1))))
  (func $__fern_buf_push_decimal (param $h i32) (param $v i64)
    (local $n i32) (local $len i32) (local $p i32) (local $t i64)
    (local.set $n (i32.const 1)) (local.set $t (local.get $v))
    (block $cd (loop $cl (br_if $cd (i64.lt_u (local.get $t) (i64.const 10)))
      (local.set $t (i64.div_u (local.get $t) (i64.const 10))) (local.set $n (i32.add (local.get $n) (i32.const 1))) (br $cl)))
    (local.set $len (i32.load (i32.add (local.get $h) (i32.const 4))))
    (if (i32.gt_u (i32.add (local.get $len) (local.get $n)) (i32.load (i32.add (local.get $h) (i32.const 8))))
      (then (call $__fern_buf_reserve (local.get $h) (i32.add (local.get $len) (local.get $n)))))
    (local.set $p (i32.add (i32.add (i32.add (i32.load (local.get $h)) (i32.const 4)) (local.get $len)) (local.get $n)))
    (loop $dl
      (local.set $p (i32.sub (local.get $p) (i32.const 1)))
      (i32.store8 (local.get $p) (i32.add (i32.wrap_i64 (i64.rem_u (local.get $v) (i64.const 10))) (i32.const 48)))
      (local.set $v (i64.div_u (local.get $v) (i64.const 10)))
      (br_if $dl (i64.ne (local.get $v) (i64.const 0))))
    (i32.store (i32.add (local.get $h) (i32.const 4)) (i32.add (local.get $len) (local.get $n))))
  ;; Positive width is valid; negative width consumes one maximal subpart.
  (func $__fern_buf_text_part (param $p i32) (param $left i32) (result i32)
    (local $lead i32) (local $width i32) (local $used i32) (local $next i32)
    (local.set $lead (i32.load8_u (local.get $p)))
    (if (i32.lt_u (local.get $lead) (i32.const 128)) (then (return (i32.const 1))))
    (if (i32.and (i32.ge_u (local.get $lead) (i32.const 194)) (i32.le_u (local.get $lead) (i32.const 223))) (then (local.set $width (i32.const 2))))
    (if (i32.and (i32.ge_u (local.get $lead) (i32.const 224)) (i32.le_u (local.get $lead) (i32.const 239))) (then (local.set $width (i32.const 3))))
    (if (i32.and (i32.ge_u (local.get $lead) (i32.const 240)) (i32.le_u (local.get $lead) (i32.const 244))) (then (local.set $width (i32.const 4))))
    (local.set $used (i32.const 1))
    (block $done (loop $scan
      (br_if $done (i32.ge_u (local.get $used) (local.get $width)))
      (br_if $done (i32.ge_u (local.get $used) (local.get $left)))
      (local.set $next (i32.load8_u (i32.add (local.get $p) (local.get $used))))
      (br_if $done (i32.or (i32.lt_u (local.get $next) (i32.const 128)) (i32.gt_u (local.get $next) (i32.const 191))))
      (if (i32.eq (local.get $used) (i32.const 1)) (then
        (br_if $done (i32.and (i32.eq (local.get $lead) (i32.const 224)) (i32.lt_u (local.get $next) (i32.const 160))))
        (br_if $done (i32.and (i32.eq (local.get $lead) (i32.const 237)) (i32.gt_u (local.get $next) (i32.const 159))))
        (br_if $done (i32.and (i32.eq (local.get $lead) (i32.const 240)) (i32.lt_u (local.get $next) (i32.const 144))))
        (br_if $done (i32.and (i32.eq (local.get $lead) (i32.const 244)) (i32.gt_u (local.get $next) (i32.const 143))))))
      (local.set $used (i32.add (local.get $used) (i32.const 1)))
      (br $scan)))
    (if (i32.eq (local.get $used) (local.get $width)) (then (return (local.get $used))))
    (i32.sub (i32.const 0) (local.get $used)))
  (func $__fern_buf_take (param $h i32) (result i32)
    (local $n i32) (local $src i32) (local $i i32) (local $part i32)
    (local $total i64) (local $changed i32) (local $box i32) (local $out i32)
    (local $start i32) (local $written i32)
    (local.set $n (i32.load offset=4 (local.get $h)))
    (local.set $src (i32.add (i32.load (local.get $h)) (i32.const 4)))
    (local.set $total (i64.extend_i32_u (local.get $n)))
    (block $counted (loop $count
      (br_if $counted (i32.ge_u (local.get $i) (local.get $n)))
      (if (i32.ge_u (i32.sub (local.get $n) (local.get $i)) (i32.const 8)) (then
        (if (i64.eqz (i64.and (i64.load (i32.add (local.get $src) (local.get $i))) (i64.const -9187201950435737472))) (then
          (local.set $i (i32.add (local.get $i) (i32.const 8))) (br $count)))))
      (local.set $part (call $__fern_buf_text_part (i32.add (local.get $src) (local.get $i)) (i32.sub (local.get $n) (local.get $i))))
      (if (i32.lt_s (local.get $part) (i32.const 0)) (then
        (local.set $total (i64.add (local.get $total) (i64.extend_i32_s (i32.add (i32.const 3) (local.get $part)))))
        (local.set $changed (i32.const 1))
        (local.set $i (i32.sub (local.get $i) (local.get $part))))
        (else (local.set $i (i32.add (local.get $i) (local.get $part)))))
      (br $count)))
    (if (i64.gt_u (local.get $total) (i64.const 2147483643)) (then (call $__fern_abort_alloc) (unreachable)))
    (local.set $box (call $__fern_str_box (i32.add (i32.wrap_i64 (local.get $total)) (i32.const 4))))
    (i32.store (local.get $box) (i32.wrap_i64 (local.get $total)))
    (local.set $out (i32.add (local.get $box) (i32.const 4)))
    (if (i32.eqz (local.get $changed)) (then
      (memory.copy (local.get $out) (local.get $src) (local.get $n)))
      (else
        (local.set $i (i32.const 0))
        (block $copied (loop $copy
          (br_if $copied (i32.ge_u (local.get $i) (local.get $n)))
          (if (i32.ge_u (i32.sub (local.get $n) (local.get $i)) (i32.const 8)) (then
            (if (i64.eqz (i64.and (i64.load (i32.add (local.get $src) (local.get $i))) (i64.const -9187201950435737472))) (then
              (local.set $i (i32.add (local.get $i) (i32.const 8))) (br $copy)))))
          (local.set $part (call $__fern_buf_text_part (i32.add (local.get $src) (local.get $i)) (i32.sub (local.get $n) (local.get $i))))
          (if (i32.lt_s (local.get $part) (i32.const 0)) (then
            (memory.copy (i32.add (local.get $out) (local.get $written)) (i32.add (local.get $src) (local.get $start)) (i32.sub (local.get $i) (local.get $start)))
            (local.set $written (i32.add (local.get $written) (i32.sub (local.get $i) (local.get $start))))
            (i32.store8 (i32.add (local.get $out) (local.get $written)) (i32.const 239))
            (i32.store8 offset=1 (i32.add (local.get $out) (local.get $written)) (i32.const 191))
            (i32.store8 offset=2 (i32.add (local.get $out) (local.get $written)) (i32.const 189))
            (local.set $written (i32.add (local.get $written) (i32.const 3)))
            (local.set $i (i32.sub (local.get $i) (local.get $part)))
            (local.set $start (local.get $i)))
            (else (local.set $i (i32.add (local.get $i) (local.get $part)))))
          (br $copy)))
        (memory.copy (i32.add (local.get $out) (local.get $written)) (i32.add (local.get $src) (local.get $start)) (i32.sub (local.get $n) (local.get $start)))))
    (i32.store offset=4 (local.get $h) (i32.const 0))
    (local.get $box))
  (func $__fern_buf_free (param $h i32)
    (if (i32.eqz (local.get $h)) (then (return)))
    (if (i32.load (local.get $h)) (then (drop (call $__fern_arr_dec (i32.load (local.get $h))))))
    (drop (call $__fern_arr_dec (local.get $h))))
  (func $__fern_idiv (param $a i32) (param $b i32) (result i32)
    (local $safe i32)
    (local.set $safe (select (i32.const 1) (local.get $b) (i32.or (i32.eqz (local.get $b)) (i32.and (i32.eq (local.get $a) (i32.const -2147483648)) (i32.eq (local.get $b) (i32.const -1))))))
    (select (i32.const 0) (i32.div_s (local.get $a) (local.get $safe)) (i32.eqz (local.get $b))))
  (func $__fern_irem (param $a i32) (param $b i32) (result i32)
    (local $safe i32)
    (local.set $safe (select (i32.const 1) (local.get $b) (i32.or (i32.eqz (local.get $b)) (i32.and (i32.eq (local.get $a) (i32.const -2147483648)) (i32.eq (local.get $b) (i32.const -1))))))
    (select (local.get $a) (i32.rem_s (local.get $a) (local.get $safe)) (i32.eqz (local.get $b))))
  (func $__fern_idiv64 (param $a i64) (param $b i64) (result i64)
    (local $safe i64)
    (local.set $safe (select (i64.const 1) (local.get $b) (i32.or (i64.eqz (local.get $b)) (i32.and (i64.eq (local.get $a) (i64.const -9223372036854775808)) (i64.eq (local.get $b) (i64.const -1))))))
    (select (i64.const 0) (i64.div_s (local.get $a) (local.get $safe)) (i64.eqz (local.get $b))))
  (func $__fern_irem64 (param $a i64) (param $b i64) (result i64)
    (local $safe i64)
    (local.set $safe (select (i64.const 1) (local.get $b) (i32.or (i64.eqz (local.get $b)) (i32.and (i64.eq (local.get $a) (i64.const -9223372036854775808)) (i64.eq (local.get $b) (i64.const -1))))))
    (select (local.get $a) (i64.rem_s (local.get $a) (local.get $safe)) (i64.eqz (local.get $b))))
  (func $__fern_udiv (param $a i32) (param $b i32) (result i32)
    (local $safe i32)
    (local.set $safe (select (i32.const 1) (local.get $b) (i32.eqz (local.get $b))))
    (select (i32.const 0) (i32.div_u (local.get $a) (local.get $safe)) (i32.eqz (local.get $b))))
  (func $__fern_urem (param $a i32) (param $b i32) (result i32)
    (local $safe i32)
    (local.set $safe (select (i32.const 1) (local.get $b) (i32.eqz (local.get $b))))
    (select (local.get $a) (i32.rem_u (local.get $a) (local.get $safe)) (i32.eqz (local.get $b))))
  (func $__fern_udiv64 (param $a i64) (param $b i64) (result i64)
    (local $safe i64)
    (local.set $safe (select (i64.const 1) (local.get $b) (i64.eqz (local.get $b))))
    (select (i64.const 0) (i64.div_u (local.get $a) (local.get $safe)) (i64.eqz (local.get $b))))
  (func $__fern_urem64 (param $a i64) (param $b i64) (result i64)
    (local $safe i64)
    (local.set $safe (select (i64.const 1) (local.get $b) (i64.eqz (local.get $b))))
    (select (local.get $a) (i64.rem_u (local.get $a) (local.get $safe)) (i64.eqz (local.get $b))))
  (func $__fern_strcat (param $a i32) (param $b i32) (result i32)
    (local $la i32) (local $lb i32) (local $pa i32) (local $pb i32) (local $p i32) (local $i i32)
    (local.set $la (i32.load (i32.add (local.get $a) (i32.mul (i32.and (local.get $a) (i32.const 1)) (i32.const 3)))))
    (local.set $pa (if (result i32) (i32.and (local.get $a) (i32.const 1)) (then (i32.load (i32.sub (local.get $a) (i32.const 1)))) (else (i32.add (local.get $a) (i32.const 4)))))
    (if (i32.lt_s (local.get $la) (i32.const 0)) (then (local.set $pa (i32.load (i32.add (local.get $a) (i32.const 4)))) (local.set $la (i32.and (local.get $la) (i32.const 2147483647)))))
    (local.set $lb (i32.load (i32.add (local.get $b) (i32.mul (i32.and (local.get $b) (i32.const 1)) (i32.const 3)))))
    (local.set $pb (if (result i32) (i32.and (local.get $b) (i32.const 1)) (then (i32.load (i32.sub (local.get $b) (i32.const 1)))) (else (i32.add (local.get $b) (i32.const 4)))))
    (if (i32.lt_s (local.get $lb) (i32.const 0)) (then (local.set $pb (i32.load (i32.add (local.get $b) (i32.const 4)))) (local.set $lb (i32.and (local.get $lb) (i32.const 2147483647)))))
    (local.set $p (call $__fern_str_box (i32.add (i32.const 4) (i32.add (local.get $la) (local.get $lb)))))
    (i32.store (local.get $p) (i32.add (local.get $la) (local.get $lb)))
    (local.set $i (i32.const 0))
    (block $da (loop $ca
      (br_if $da (i32.ge_u (local.get $i) (local.get $la)))
      (i32.store8 (i32.add (i32.add (local.get $p) (i32.const 4)) (local.get $i)) (i32.load8_u (i32.add (local.get $pa) (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $ca)))
    (local.set $i (i32.const 0))
    (block $db (loop $cb
      (br_if $db (i32.ge_u (local.get $i) (local.get $lb)))
      (i32.store8 (i32.add (i32.add (i32.add (local.get $p) (i32.const 4)) (local.get $la)) (local.get $i)) (i32.load8_u (i32.add (local.get $pb) (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $cb)))
    (local.get $p))
  (func $__fern_substr (param $s i32) (param $start i32) (param $end i32) (result i32)
    (local $len i32) (local $p i32) (local $i i32)
    (if (i32.gt_u (local.get $end) (i32.load (local.get $s))) (then (call $__fern_abort_str) (unreachable)))
    (if (i32.gt_u (local.get $start) (local.get $end)) (then (call $__fern_abort_str) (unreachable)))
    (local.set $len (i32.sub (local.get $end) (local.get $start)))
    (local.set $p (call $__fern_str_box (i32.add (i32.const 4) (local.get $len))))
    (i32.store (local.get $p) (local.get $len))
    (local.set $i (i32.const 0))
    (block $d (loop $c
      (br_if $d (i32.ge_s (local.get $i) (local.get $len)))
      (i32.store8 (i32.add (i32.add (local.get $p) (i32.const 4)) (local.get $i)) (i32.load8_u (i32.add (i32.add (local.get $s) (i32.const 4)) (i32.add (local.get $start) (local.get $i)))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $c)))
    (local.get $p))
  (func $__fern_str_borrow (param $data i32) (param $len i32) (result i32)
    (local $p i32)
    (local.set $p (call $__fern_str_box (i32.const 8)))
    (i32.store (local.get $p) (i32.or (local.get $len) (i32.const -2147483648)))
    (i32.store (i32.add (local.get $p) (i32.const 4)) (local.get $data))
    (local.get $p))
  (func $__fern_memchr (param $s i32) (param $byte i32) (param $from i32) (result i32)
    (local $len i32) (local $i i32) (local $m i32) (local $splat v128)
    (if (i32.or (i32.lt_s (local.get $byte) (i32.const 0)) (i32.gt_s (local.get $byte) (i32.const 255))) (then (return (i32.const -1))))
    (local.set $len (i32.load (local.get $s)))
    (local.set $i (local.get $from))
    (if (i32.lt_s (local.get $i) (i32.const 0)) (then (local.set $i (i32.const 0))))
    (local.set $splat (i8x16.splat (local.get $byte)))
    (block $vd (loop $vc
      (br_if $vd (i32.lt_s (i32.sub (local.get $len) (local.get $i)) (i32.const 16)))
      (local.set $m (i8x16.bitmask (i8x16.eq (v128.load (i32.add (i32.add (local.get $s) (i32.const 4)) (local.get $i))) (local.get $splat))))
      (if (i32.ne (local.get $m) (i32.const 0)) (then (return (i32.add (local.get $i) (i32.ctz (local.get $m))))))
      (local.set $i (i32.add (local.get $i) (i32.const 16)))
      (br $vc)))
    (block $d (loop $c
      (br_if $d (i32.ge_s (local.get $i) (local.get $len)))
      (if (i32.eq (i32.load8_u (i32.add (i32.add (local.get $s) (i32.const 4)) (local.get $i))) (local.get $byte)) (then (return (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $c)))
    (i32.const -1))
  (func $__fern_mismatch_bytes (param $a i32) (param $ao i32) (param $b i32) (param $bo i32) (param $n i32) (result i32)
    (local $na i32) (local $nb i32) (local $pa i32) (local $pb i32) (local $i i32) (local $m i32)
    (local.set $na (i32.load (local.get $a)))
    (local.set $pa (i32.add (local.get $a) (i32.const 8)))
    (local.set $nb (i32.load (local.get $b)))
    (local.set $pb (i32.add (local.get $b) (i32.const 8)))
    (if (i32.lt_s (local.get $ao) (i32.const 0)) (then (local.set $ao (i32.const 0))))
    (if (i32.gt_s (local.get $ao) (local.get $na)) (then (local.set $ao (local.get $na))))
    (if (i32.lt_s (local.get $bo) (i32.const 0)) (then (local.set $bo (i32.const 0))))
    (if (i32.gt_s (local.get $bo) (local.get $nb)) (then (local.set $bo (local.get $nb))))
    (if (i32.gt_s (local.get $n) (i32.sub (local.get $na) (local.get $ao))) (then (local.set $n (i32.sub (local.get $na) (local.get $ao)))))
    (if (i32.gt_s (local.get $n) (i32.sub (local.get $nb) (local.get $bo))) (then (local.set $n (i32.sub (local.get $nb) (local.get $bo)))))
    (if (i32.lt_s (local.get $n) (i32.const 0)) (then (local.set $n (i32.const 0))))
    (local.set $pa (i32.add (local.get $pa) (local.get $ao)))
    (local.set $pb (i32.add (local.get $pb) (local.get $bo)))
    (block $vd (loop $vc
      (br_if $vd (i32.lt_s (i32.sub (local.get $n) (local.get $i)) (i32.const 16)))
      (local.set $m (i8x16.bitmask (i8x16.eq (v128.load (i32.add (local.get $pa) (local.get $i))) (v128.load (i32.add (local.get $pb) (local.get $i))))))
      (if (i32.ne (local.get $m) (i32.const 65535)) (then (return (i32.add (local.get $i) (i32.ctz (i32.xor (local.get $m) (i32.const 65535)))))))
      (local.set $i (i32.add (local.get $i) (i32.const 16)))
      (br $vc)))
    (block $d (loop $c
      (br_if $d (i32.ge_s (local.get $i) (local.get $n)))
      (if (i32.ne (i32.load8_u (i32.add (local.get $pa) (local.get $i))) (i32.load8_u (i32.add (local.get $pb) (local.get $i)))) (then (return (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $c)))
    (local.get $n))
  (func $__fern_mismatch_bytes_str (param $a i32) (param $ao i32) (param $b i32) (param $bo i32) (param $n i32) (result i32)
    (local $na i32) (local $nb i32) (local $pa i32) (local $pb i32) (local $i i32) (local $m i32)
    (local.set $na (i32.load (local.get $a)))
    (local.set $pa (i32.add (local.get $a) (i32.const 8)))
    (local.set $nb (i32.load (i32.add (local.get $b) (i32.mul (i32.and (local.get $b) (i32.const 1)) (i32.const 3)))))
    (local.set $pb (if (result i32) (i32.and (local.get $b) (i32.const 1)) (then (i32.load (i32.sub (local.get $b) (i32.const 1)))) (else (i32.add (local.get $b) (i32.const 4)))))
    (if (i32.lt_s (local.get $nb) (i32.const 0)) (then (local.set $pb (i32.load (i32.add (local.get $b) (i32.const 4)))) (local.set $nb (i32.and (local.get $nb) (i32.const 2147483647)))))
    (if (i32.lt_s (local.get $ao) (i32.const 0)) (then (local.set $ao (i32.const 0))))
    (if (i32.gt_s (local.get $ao) (local.get $na)) (then (local.set $ao (local.get $na))))
    (if (i32.lt_s (local.get $bo) (i32.const 0)) (then (local.set $bo (i32.const 0))))
    (if (i32.gt_s (local.get $bo) (local.get $nb)) (then (local.set $bo (local.get $nb))))
    (if (i32.gt_s (local.get $n) (i32.sub (local.get $na) (local.get $ao))) (then (local.set $n (i32.sub (local.get $na) (local.get $ao)))))
    (if (i32.gt_s (local.get $n) (i32.sub (local.get $nb) (local.get $bo))) (then (local.set $n (i32.sub (local.get $nb) (local.get $bo)))))
    (if (i32.lt_s (local.get $n) (i32.const 0)) (then (local.set $n (i32.const 0))))
    (local.set $pa (i32.add (local.get $pa) (local.get $ao)))
    (local.set $pb (i32.add (local.get $pb) (local.get $bo)))
    (block $vd (loop $vc
      (br_if $vd (i32.lt_s (i32.sub (local.get $n) (local.get $i)) (i32.const 16)))
      (local.set $m (i8x16.bitmask (i8x16.eq (v128.load (i32.add (local.get $pa) (local.get $i))) (v128.load (i32.add (local.get $pb) (local.get $i))))))
      (if (i32.ne (local.get $m) (i32.const 65535)) (then (return (i32.add (local.get $i) (i32.ctz (i32.xor (local.get $m) (i32.const 65535)))))))
      (local.set $i (i32.add (local.get $i) (i32.const 16)))
      (br $vc)))
    (block $d (loop $c
      (br_if $d (i32.ge_s (local.get $i) (local.get $n)))
      (if (i32.ne (i32.load8_u (i32.add (local.get $pa) (local.get $i))) (i32.load8_u (i32.add (local.get $pb) (local.get $i)))) (then (return (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $c)))
    (local.get $n))
  (func $__fern_mismatch (param $a i32) (param $ao i32) (param $b i32) (param $bo i32) (param $n i32) (result i32)
    (local $na i32) (local $nb i32) (local $pa i32) (local $pb i32) (local $i i32) (local $m i32)
    (local.set $na (i32.load (i32.add (local.get $a) (i32.mul (i32.and (local.get $a) (i32.const 1)) (i32.const 3)))))
    (local.set $pa (if (result i32) (i32.and (local.get $a) (i32.const 1)) (then (i32.load (i32.sub (local.get $a) (i32.const 1)))) (else (i32.add (local.get $a) (i32.const 4)))))
    (if (i32.lt_s (local.get $na) (i32.const 0)) (then (local.set $pa (i32.load (i32.add (local.get $a) (i32.const 4)))) (local.set $na (i32.and (local.get $na) (i32.const 2147483647)))))
    (local.set $nb (i32.load (i32.add (local.get $b) (i32.mul (i32.and (local.get $b) (i32.const 1)) (i32.const 3)))))
    (local.set $pb (if (result i32) (i32.and (local.get $b) (i32.const 1)) (then (i32.load (i32.sub (local.get $b) (i32.const 1)))) (else (i32.add (local.get $b) (i32.const 4)))))
    (if (i32.lt_s (local.get $nb) (i32.const 0)) (then (local.set $pb (i32.load (i32.add (local.get $b) (i32.const 4)))) (local.set $nb (i32.and (local.get $nb) (i32.const 2147483647)))))
    (if (i32.lt_s (local.get $ao) (i32.const 0)) (then (local.set $ao (i32.const 0))))
    (if (i32.gt_s (local.get $ao) (local.get $na)) (then (local.set $ao (local.get $na))))
    (if (i32.lt_s (local.get $bo) (i32.const 0)) (then (local.set $bo (i32.const 0))))
    (if (i32.gt_s (local.get $bo) (local.get $nb)) (then (local.set $bo (local.get $nb))))
    (if (i32.gt_s (local.get $n) (i32.sub (local.get $na) (local.get $ao))) (then (local.set $n (i32.sub (local.get $na) (local.get $ao)))))
    (if (i32.gt_s (local.get $n) (i32.sub (local.get $nb) (local.get $bo))) (then (local.set $n (i32.sub (local.get $nb) (local.get $bo)))))
    (if (i32.lt_s (local.get $n) (i32.const 0)) (then (local.set $n (i32.const 0))))
    (local.set $pa (i32.add (local.get $pa) (local.get $ao)))
    (local.set $pb (i32.add (local.get $pb) (local.get $bo)))
    (block $vd (loop $vc
      (br_if $vd (i32.lt_s (i32.sub (local.get $n) (local.get $i)) (i32.const 16)))
      (local.set $m (i8x16.bitmask (i8x16.eq (v128.load (i32.add (local.get $pa) (local.get $i))) (v128.load (i32.add (local.get $pb) (local.get $i))))))
      (if (i32.ne (local.get $m) (i32.const 65535)) (then (return (i32.add (local.get $i) (i32.ctz (i32.xor (local.get $m) (i32.const 65535)))))))
      (local.set $i (i32.add (local.get $i) (i32.const 16)))
      (br $vc)))
    (block $d (loop $c
      (br_if $d (i32.ge_s (local.get $i) (local.get $n)))
      (if (i32.ne (i32.load8_u (i32.add (local.get $pa) (local.get $i))) (i32.load8_u (i32.add (local.get $pb) (local.get $i)))) (then (return (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $c)))
    (local.get $n))
  (func $__fern_ascii_run (param $s i32) (param $from i32) (result i32)
    (local $len i32) (local $i i32) (local $m i32)
    (local.set $len (i32.load (local.get $s)))
    (local.set $i (local.get $from))
    (if (i32.lt_s (local.get $i) (i32.const 0)) (then (local.set $i (i32.const 0))))
    (block $vd (loop $vc
      (br_if $vd (i32.lt_s (i32.sub (local.get $len) (local.get $i)) (i32.const 16)))
      (local.set $m (i8x16.bitmask (v128.load (i32.add (i32.add (local.get $s) (i32.const 4)) (local.get $i)))))
      (if (i32.ne (local.get $m) (i32.const 0)) (then (return (i32.add (local.get $i) (i32.ctz (local.get $m))))))
      (local.set $i (i32.add (local.get $i) (i32.const 16)))
      (br $vc)))
    (block $d (loop $c
      (br_if $d (i32.ge_s (local.get $i) (local.get $len)))
      (if (i32.ge_u (i32.load8_u (i32.add (i32.add (local.get $s) (i32.const 4)) (local.get $i))) (i32.const 128)) (then (return (local.get $i))))
      (local.set $i (i32.add (local.get $i) (i32.const 1)))
      (br $c)))
    (local.get $len))
  (func $__fern_arr_push (param $a i32) (param $v i32) (result i32)
    (local $len i32) (local $cap i32) (local $na i32) (local $ncap i32) (local $rc i32)
    (local.set $len (i32.load (local.get $a)))
    (local.set $cap (i32.load (i32.add (local.get $a) (i32.const 4))))
    (local.set $rc (i32.load (i32.sub (local.get $a) (i32.const 8))))
    (if (i32.and (i32.or (i32.eq (local.get $rc) (i32.const 1)) (i32.lt_s (local.get $rc) (i32.const 0))) (i32.lt_s (local.get $len) (local.get $cap))) (then
      (i32.store (i32.add (i32.add (local.get $a) (i32.const 8)) (i32.mul (local.get $len) (i32.const 4))) (local.get $v))
      (i32.store (local.get $a) (i32.add (local.get $len) (i32.const 1)))
      (return (local.get $a))))
    (local.set $ncap (local.get $cap))
    (if (i32.lt_s (local.get $len) (local.get $cap)) (then
      (i32.store (i32.const 20) (i32.add (i32.load (i32.const 20)) (i32.const 1)))
      (i64.store (i32.const 24) (i64.add (i64.load (i32.const 24)) (i64.extend_i32_u (i32.mul (local.get $len) (i32.const 4)))))))
    (if (i32.ge_s (local.get $len) (local.get $cap)) (then
      (local.set $ncap (i32.const 4))
      (if (i32.gt_s (local.get $cap) (i32.const 0)) (then (local.set $ncap (i32.mul (local.get $cap) (i32.const 2)))))))
    (local.set $na (call $__fern_arr_elems (local.get $ncap) (i32.const 4)))
    (i32.store (local.get $na) (i32.add (local.get $len) (i32.const 1)))
    (i32.store (i32.add (local.get $na) (i32.const 4)) (local.get $ncap))
    (memory.copy (i32.add (local.get $na) (i32.const 8)) (i32.add (local.get $a) (i32.const 8)) (i32.mul (local.get $len) (i32.const 4)))
    (i32.store (i32.add (i32.add (local.get $na) (i32.const 8)) (i32.mul (local.get $len) (i32.const 4))) (local.get $v))
    (local.get $na))
  (func $__fern_str_split (param $s i32) (param $sep i32) (result i32)
    (local $sl i32) (local $sepl i32) (local $i i32) (local $start i32) (local $arr i32) (local $piece i32) (local $j i32) (local $match i32)
    (local.set $sl (i32.load (local.get $s)))
    (local.set $sepl (i32.load (local.get $sep)))
    (local.set $arr (call $__fern_arr_box (i32.const 0)))
    (i32.store (local.get $arr) (i32.const 0))
    (i32.store (i32.add (local.get $arr) (i32.const 4)) (i32.const 0))
    (if (i32.eqz (local.get $sepl)) (then
      (local.set $i (i32.const 0))
      (block $d0 (loop $c0
        (br_if $d0 (i32.ge_s (local.get $i) (local.get $sl)))
        (local.set $j (call $__fern_utf8_step (local.get $s) (local.get $i) (local.get $sl)))
        (local.set $piece (call $__fern_substr (local.get $s) (local.get $i) (i32.add (local.get $i) (local.get $j))))
        (local.set $arr (call $__fern_arr_push_owned (local.get $arr) (local.get $piece)))
        (local.set $i (i32.add (local.get $i) (local.get $j)))
        (br $c0)))
      (return (local.get $arr))))
    (local.set $start (i32.const 0))
    (local.set $i (i32.const 0))
    (block $d (loop $c
      (br_if $d (i32.gt_s (local.get $i) (i32.sub (local.get $sl) (local.get $sepl))))
      (local.set $match (i32.const 1))
      (local.set $j (i32.const 0))
      (block $dm (loop $cm
        (br_if $dm (i32.ge_s (local.get $j) (local.get $sepl)))
        (if (i32.ne (i32.load8_u (i32.add (i32.add (local.get $s) (i32.const 4)) (i32.add (local.get $i) (local.get $j)))) (i32.load8_u (i32.add (i32.add (local.get $sep) (i32.const 4)) (local.get $j)))) (then (local.set $match (i32.const 0)) (br $dm)))
        (local.set $j (i32.add (local.get $j) (i32.const 1)))
        (br $cm)))
      (if (local.get $match) (then
        (local.set $piece (call $__fern_substr (local.get $s) (local.get $start) (local.get $i)))
        (local.set $arr (call $__fern_arr_push_owned (local.get $arr) (local.get $piece)))
        (local.set $i (i32.add (local.get $i) (local.get $sepl)))
        (local.set $start (local.get $i)))
      (else (local.set $i (i32.add (local.get $i) (i32.const 1)))))
      (br $c)))
    (local.set $piece (call $__fern_substr (local.get $s) (local.get $start) (local.get $sl)))
    (local.set $arr (call $__fern_arr_push_owned (local.get $arr) (local.get $piece)))
    (local.get $arr))
  (func $__fern_bytes_range (param $v i32) (param $from i32) (param $to i32) (result i32)
    (local $n i32) (local $p i32) (local $m i32) (local $r i32)
    (if (i32.and (local.get $v) (i32.const 2)) (then (if (i32.and (local.get $v) (i32.const 1))
      (then (local.set $p (i32.load (i32.sub (local.get $v) (i32.const 3)))) (local.set $n (i32.load (i32.add (local.get $v) (i32.const 1)))))
      (else (local.set $p (i32.add (local.get $v) (i32.const 2))) (local.set $n (i32.load (i32.sub (local.get $v) (i32.const 2)))) (if (i32.lt_s (local.get $n) (i32.const 0)) (then (local.set $p (i32.load (i32.add (local.get $v) (i32.const 2)))) (local.set $n (i32.and (local.get $n) (i32.const 2147483647))))))))
    (else (local.set $p (i32.add (local.get $v) (i32.const 8))) (local.set $n (i32.load (local.get $v)))))
    (if (i32.lt_s (local.get $from) (i32.const 0)) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.lt_s (local.get $to) (local.get $from)) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.gt_s (local.get $to) (local.get $n)) (then (call $__fern_abort_slice) (unreachable)))
    (local.set $m (i32.sub (local.get $to) (local.get $from)))
    (if (i32.eqz (local.get $m)) (then (return (i32.const 3368))))
    (local.set $r (call $__fern_arr_elems (local.get $m) (i32.const 1)))
    (i32.store (local.get $r) (local.get $m))
    (i32.store offset=4 (local.get $r) (local.get $m))
    (memory.copy (i32.add (local.get $r) (i32.const 8)) (i32.add (local.get $p) (local.get $from)) (local.get $m))
    (local.get $r))
  (func $__fern_bytes_into (param $dst i32) (param $at i32) (param $v i32) (param $from i32) (param $m i32) (result i32)
    (local $n i32) (local $p i32) (local $dn i32) (local $r i32)
    (if (i32.and (local.get $v) (i32.const 2)) (then (if (i32.and (local.get $v) (i32.const 1))
      (then (local.set $p (i32.load (i32.sub (local.get $v) (i32.const 3)))) (local.set $n (i32.load (i32.add (local.get $v) (i32.const 1)))))
      (else (local.set $p (i32.add (local.get $v) (i32.const 2))) (local.set $n (i32.load (i32.sub (local.get $v) (i32.const 2)))) (if (i32.lt_s (local.get $n) (i32.const 0)) (then (local.set $p (i32.load (i32.add (local.get $v) (i32.const 2)))) (local.set $n (i32.and (local.get $n) (i32.const 2147483647))))))))
    (else (local.set $p (i32.add (local.get $v) (i32.const 8))) (local.set $n (i32.load (local.get $v)))))
    (local.set $dn (i32.load (local.get $dst)))
    (if (i32.lt_s (local.get $m) (i32.const 0)) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.lt_s (local.get $at) (i32.const 0)) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.lt_s (local.get $from) (i32.const 0)) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.gt_s (local.get $at) (i32.sub (local.get $dn) (local.get $m))) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.gt_s (local.get $from) (i32.sub (local.get $n) (local.get $m))) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.eqz (local.get $m)) (then (return (local.get $dst))))
    (if (i32.eqz (call $__fern_rc_is_unique (local.get $dst))) (then
      (local.set $r (call $__fern_arr_elems (local.get $dn) (i32.const 1)))
      (i32.store (local.get $r) (local.get $dn))
      (i32.store offset=4 (local.get $r) (local.get $dn))
      (memory.copy (i32.add (local.get $r) (i32.const 8)) (i32.add (local.get $dst) (i32.const 8)) (local.get $dn))
      (drop (call $__fern_arr_dec (local.get $dst)))
      (local.set $dst (local.get $r))))
    (memory.copy (i32.add (i32.add (local.get $dst) (i32.const 8)) (local.get $at)) (i32.add (local.get $p) (local.get $from)) (local.get $m))
    (local.get $dst))
  (func $__fern_arr_slice_u8 (param $a i32) (param $start i32) (param $end i32) (result i32)
    (local $n i32) (local $na i32)
    (if (i32.gt_u (local.get $end) (i32.load (local.get $a))) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.gt_u (local.get $start) (local.get $end)) (then (call $__fern_abort_slice) (unreachable)))
    (local.set $n (i32.sub (local.get $end) (local.get $start)))
    (local.set $na (call $__fern_arr_elems (local.get $n) (i32.const 1)))
    (i32.store (local.get $na) (local.get $n))
    (i32.store offset=4 (local.get $na) (local.get $n))
    (memory.copy (i32.add (local.get $na) (i32.const 8)) (i32.add (i32.add (local.get $a) (i32.const 8)) (local.get $start)) (local.get $n))
    (local.get $na))
  (func $__fern_arr_push_owned (param $a i32) (param $v i32) (result i32)
    (local $na i32) (local $rc i32)
    (local.set $na (call $__fern_arr_push (local.get $a) (local.get $v)))
    (if (i32.and (i32.ne (local.get $na) (local.get $a)) (i32.and (i32.ge_u (local.get $a) (i32.const 274864)) (i32.eqz (i32.and (local.get $a) (i32.const 1))))) (then
      (if (i32.eq (i32.load (i32.sub (local.get $a) (i32.const 8))) (i32.const 1)) (then
        (drop (call $__fern_arr_dec (local.get $a)))))))
    (local.get $na))
  (func $__fern_arr_push_u8 (param $a i32) (param $v i32) (result i32)
    (local $len i32) (local $cap i32) (local $na i32) (local $ncap i32) (local $rc i32)
    (local.set $len (i32.load (local.get $a)))
    (local.set $cap (i32.load (i32.add (local.get $a) (i32.const 4))))
    (local.set $rc (i32.load (i32.sub (local.get $a) (i32.const 8))))
    (if (i32.and (i32.or (i32.eq (local.get $rc) (i32.const 1)) (i32.lt_s (local.get $rc) (i32.const 0))) (i32.lt_s (local.get $len) (local.get $cap))) (then
      (i32.store8 (i32.add (i32.add (local.get $a) (i32.const 8)) (i32.mul (local.get $len) (i32.const 1))) (local.get $v))
      (i32.store (local.get $a) (i32.add (local.get $len) (i32.const 1)))
      (return (local.get $a))))
    (local.set $ncap (local.get $cap))
    (if (i32.lt_s (local.get $len) (local.get $cap)) (then
      (i32.store (i32.const 20) (i32.add (i32.load (i32.const 20)) (i32.const 1)))
      (i64.store (i32.const 24) (i64.add (i64.load (i32.const 24)) (i64.extend_i32_u (i32.mul (local.get $len) (i32.const 1)))))))
    (if (i32.ge_s (local.get $len) (local.get $cap)) (then
      (local.set $ncap (i32.const 4))
      (if (i32.gt_s (local.get $cap) (i32.const 0)) (then (local.set $ncap (i32.mul (local.get $cap) (i32.const 2)))))))
    (local.set $na (call $__fern_arr_elems (local.get $ncap) (i32.const 1)))
    (i32.store (local.get $na) (i32.add (local.get $len) (i32.const 1)))
    (i32.store (i32.add (local.get $na) (i32.const 4)) (local.get $ncap))
    (memory.copy (i32.add (local.get $na) (i32.const 8)) (i32.add (local.get $a) (i32.const 8)) (i32.mul (local.get $len) (i32.const 1)))
    (i32.store8 (i32.add (i32.add (local.get $na) (i32.const 8)) (i32.mul (local.get $len) (i32.const 1))) (local.get $v))
    (local.get $na))
  (func $__fern_arr_push_owned_u8 (param $a i32) (param $v i32) (result i32)
    (local $na i32)
    (local.set $na (call $__fern_arr_push_u8 (local.get $a) (local.get $v)))
    (if (i32.and (i32.ne (local.get $na) (local.get $a)) (i32.and (i32.ge_u (local.get $a) (i32.const 274864)) (i32.eqz (i32.and (local.get $a) (i32.const 1))))) (then
      (if (i32.eq (i32.load (i32.sub (local.get $a) (i32.const 8))) (i32.const 1)) (then
        (drop (call $__fern_arr_dec (local.get $a)))))))
    (local.get $na))
  (func $__fern_str_bytes (param $s i32) (result i32)
    (local $n i32) (local $arr i32)
    (local.set $n (i32.load (local.get $s)))
    (local.set $arr (call $__fern_arr_elems (local.get $n) (i32.const 1)))
    (i32.store (local.get $arr) (local.get $n))
    (i32.store (i32.add (local.get $arr) (i32.const 4)) (local.get $n))
    (memory.copy (i32.add (local.get $arr) (i32.const 8)) (i32.add (local.get $s) (i32.const 4)) (local.get $n))
    (local.get $arr))
  (func $__fern_string_from_bytes (param $arr i32) (result i32)
    (local $n i32) (local $s i32)
    (local.set $n (i32.load (local.get $arr)))
    (local.set $s (call $__fern_str_box (i32.add (i32.const 4) (local.get $n))))
    (i32.store (local.get $s) (local.get $n))
    (memory.copy (i32.add (local.get $s) (i32.const 4)) (i32.add (local.get $arr) (i32.const 8)) (local.get $n))
    (local.get $s))
  (func $__fern_string_from_bytes_range (param $arr i32) (param $from i32) (param $end i32) (result i32)
    (local $n i32) (local $s i32)
    (if (i32.gt_u (local.get $end) (i32.load (local.get $arr))) (then (call $__fern_abort_slice) (unreachable)))
    (if (i32.gt_u (local.get $from) (local.get $end)) (then (call $__fern_abort_slice) (unreachable)))
    (local.set $n (i32.sub (local.get $end) (local.get $from)))
    (local.set $s (call $__fern_str_box (i32.add (i32.const 4) (local.get $n))))
    (i32.store (local.get $s) (local.get $n))
    (memory.copy (i32.add (local.get $s) (i32.const 4)) (i32.add (i32.add (local.get $arr) (i32.const 8)) (local.get $from)) (local.get $n))
    (local.get $s))
  (func $http____find_crlf (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    local.get 0
    i32.const 13
    local.get 1
    call $__fern_memchr_bytes
    local.set 3
    end
    loop
    block
    block
    block
    block
    local.get 3
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 5
    end
    local.get 3
    i32.const 1
    i32.add
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 4
    local.get 0
    local.get 4
    local.set 9
    local.tee 5
    i32.load
    local.get 9
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 5
    local.get 9
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 4
    local.get 4
    i32.const 10
    i32.eq
    br_if 4
    end
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 4
    local.get 0
    i32.const 13
    local.get 4
    call $__fern_memchr_bytes
    local.set 3
    br 0
    end
    end
    i32.const -1
    return
    end
    local.get 3
    return
    i32.const 0)
  (func $http____bytes_string (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    local.get 1
    local.get 2
    call $__fern_string_from_bytes_range
    return
    i32.const 0)
  (func $http____shared_string (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    local.get 3
    i32.load
    local.set 4
    local.get 2
    local.get 1
    i32.sub
    local.set 5
    local.get 4
    local.get 5
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 3
    i32.load
    local.set 4
    local.get 0
    local.get 1
    local.get 3
    i32.const 0
    local.get 4
    call $__fern_mismatch_bytes_str
    local.set 4
    local.get 3
    i32.load
    local.set 5
    local.get 4
    local.get 5
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 3
    call $__fern_rc_inc
    drop
    local.get 3
    return
    end
    end
    local.get 0
    local.get 1
    local.get 2
    call $__fern_string_from_bytes_range
    return
    i32.const 0)
  (func $http____token_is (param i32) (param i32) (result i32)
    (local i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.load
    local.set 2
    local.get 0
    i32.const 0
    local.get 2
    local.get 1
    call $http____token_at
    return
    i32.const 0)
  (func $http____token_at (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    local.set 4
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 4
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 0
    local.get 4
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 5
    end
    local.get 5
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 13
    br 1
    end
    local.get 5
    i32.const 9
    i32.eq
    local.set 13
    end
    local.get 13
    i32.eqz
    br_if 2
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 4
    br 0
    end
    end
    local.get 2
    local.set 6
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 6
    local.get 4
    i32.gt_s
    i32.eqz
    br_if 7
    end
    local.get 6
    i32.const 1
    i32.sub
    local.set 17
    local.get 0
    local.get 17
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 7
    end
    local.get 7
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 14
    br 1
    end
    local.get 7
    i32.const 9
    i32.eq
    local.set 14
    end
    local.get 14
    i32.eqz
    br_if 2
    end
    local.get 6
    i32.const 1
    i32.sub
    local.set 6
    br 0
    end
    end
    local.get 6
    local.get 4
    i32.sub
    local.set 17
    local.get 3
    i32.load
    local.set 18
    local.get 17
    local.get 18
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 0
    return
    end
    end
    i32.const 0
    local.set 8
    end
    local.get 3
    i32.load
    local.set 17
    local.get 3
    i32.const 4
    i32.add
    local.set 18
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 17
    local.set 19
    local.get 8
    local.get 19
    i32.lt_s
    i32.eqz
    br_if 14
    end
    local.get 4
    local.get 8
    i32.add
    local.set 19
    local.get 0
    local.get 19
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 9
    end
    local.get 9
    local.set 15
    local.get 15
    i32.const 65
    i32.ge_s
    i32.eqz
    br_if 2
    end
    local.get 15
    i32.const 90
    i32.le_s
    i32.eqz
    br_if 1
    end
    local.get 15
    i32.const 32
    i32.add
    local.set 10
    br 1
    end
    local.get 15
    local.set 10
    end
    local.get 18
    local.get 8
    i32.add
    i32.load8_u
    local.set 11
    end
    local.get 11
    local.set 16
    local.get 16
    i32.const 65
    i32.ge_s
    i32.eqz
    br_if 2
    end
    local.get 16
    i32.const 90
    i32.le_s
    i32.eqz
    br_if 1
    end
    local.get 16
    i32.const 32
    i32.add
    local.set 12
    br 1
    end
    local.get 16
    local.set 12
    end
    local.get 10
    local.get 12
    i32.ne
    br_if 4
    end
    end
    local.get 8
    i32.const 1
    i32.add
    local.set 8
    br 0
    end
    end
    i32.const 1
    return
    end
    i32.const 0
    return
    i32.const 0)
  (func $http____leading_fields (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    local.set 7
    local.get 7
    i32.const 0
    local.set 3
    local.set 2
    end
    loop
    block
    local.get 3
    local.get 1
    i32.lt_s
    if
    else
    local.get 0
    call $__sem_release_HeaderMap
    drop
    br 3
    end
    end
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.get 3
    local.set 14
    local.tee 10
    i32.load
    local.get 14
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 10
    local.get 14
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 7
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.get 3
    local.set 14
    local.tee 10
    i32.load
    local.get 14
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 10
    local.get 14
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 8
    local.get 2
    call $__fern_rc_is_unique
    if
    local.get 2
    local.set 5
    else
    i32.const 0
    local.set 5
    end
    local.get 2
    i32.const 8
    i32.add
    i32.load
    local.set 9
    local.get 5
    i32.const 0
    i32.eq
    if
    local.get 9
    call $__fern_rc_inc
    drop
    end
    local.get 7
    call $__fern_rc_inc
    drop
    local.get 9
    call $__fern_rc_is_unique
    if
    local.get 9
    local.get 7
    call $__fern_arr_push_owned
    local.set 6
    else
    local.get 9
    local.get 7
    call $__fern_arr_push
    local.set 6
    local.get 9
    call $__fern_arr_inc_elems
    drop
    local.get 9
    call $__fern_arr_dec
    drop
    end
    local.get 6
    local.set 7
    local.get 2
    i32.const 16
    i32.add
    i32.load
    local.set 9
    local.get 5
    i32.const 0
    i32.eq
    if
    local.get 9
    call $__fern_rc_inc
    drop
    end
    local.get 8
    call $__fern_rc_inc
    drop
    local.get 9
    call $__fern_rc_is_unique
    if
    local.get 9
    local.get 8
    call $__fern_arr_push_owned
    local.set 6
    else
    local.get 9
    local.get 8
    call $__fern_arr_push
    local.set 6
    local.get 9
    call $__fern_arr_inc_elems
    drop
    local.get 9
    call $__fern_arr_dec
    drop
    end
    local.get 6
    local.set 8
    local.get 5
    i32.const 0
    i32.eq
    if
    local.get 5
    i32.const 3
    call $__fern_alloc_reuse
    local.tee 4
    local.tee 10
    local.get 10
    global.get $__tid$HeaderMap
    i32.store
    drop
    else
    local.get 5
    local.set 4
    end
    local.get 5
    i32.const 0
    i32.ne
    if
    else
    local.get 2
    call $__sem_release_HeaderMap
    drop
    end
    i32.const 0
    local.set 2
    local.get 4
    local.get 7
    local.set 11
    i32.const 8
    i32.add
    local.get 11
    i32.store
    local.get 4
    local.get 8
    local.set 11
    i32.const 16
    i32.add
    local.get 11
    i32.store
    local.get 3
    i32.const 1
    i32.add
    local.set 7
    local.get 4
    local.get 7
    local.set 3
    local.set 2
    br 0
    end
    end
    local.get 2
    return
    i32.const 0)
  (func $http____crlf_terminated (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    local.set 3
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    end
    local.get 0
    i32.const 13
    local.get 3
    call $__fern_memchr_bytes
    local.set 4
    local.get 0
    i32.const 10
    local.get 3
    call $__fern_memchr_bytes
    local.set 5
    local.get 4
    i32.const 0
    i32.lt_s
    br_if 10
    end
    local.get 4
    local.get 2
    i32.ge_s
    br_if 9
    end
    end
    local.get 5
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 5
    local.get 4
    i32.lt_s
    br_if 10
    end
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 7
    local.get 0
    i32.load
    local.set 8
    local.get 7
    local.get 8
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 7
    local.get 0
    local.get 7
    local.set 13
    local.tee 9
    i32.load
    local.get 13
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 9
    local.get 13
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 7
    local.get 7
    i32.const 10
    i32.ne
    br_if 8
    end
    end
    local.get 4
    i32.const 2
    i32.add
    local.set 3
    br 0
    end
    end
    local.get 5
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 6
    br 1
    end
    local.get 5
    local.get 2
    i32.ge_s
    local.set 6
    end
    local.get 6
    return
    end
    i32.const 0
    return
    end
    i32.const 0
    return
    i32.const 0)
  (func $http____field_at (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    local.get 2
    local.set 3
    end
    loop
    block
    block
    block
    block
    local.get 0
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 4
    local.get 3
    local.get 4
    i32.lt_s
    i32.eqz
    br_if 5
    end
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.get 3
    local.set 10
    local.tee 6
    i32.load
    local.get 10
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 6
    local.get 10
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    i32.load
    local.set 4
    local.get 1
    i32.load
    local.set 5
    local.get 4
    local.get 5
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.get 3
    local.set 10
    local.tee 6
    i32.load
    local.get 10
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 6
    local.get 10
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.get 1
    call $string.eq_ignore_ascii_case
    br_if 4
    end
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 3
    br 0
    end
    end
    i32.const -1
    return
    end
    local.get 3
    return
    i32.const 0)
  (func $http____kind_if (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    block
    block
    block
    local.get 0
    local.get 1
    call $string.eq_ignore_ascii_case
    i32.eqz
    br_if 1
    end
    local.get 2
    return
    end
    end
    i32.const 0
    return
    i32.const 0)
  (func $http____token_end (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    block
    block
    global.get $__cagg_base
    i32.const 56
    i32.add
    local.set 4
    local.get 0
    local.get 1
    local.get 4
    call $__fern_scan_set_bytes
    local.tee 3
    local.get 2
    i32.gt_s
    i32.eqz
    br_if 1
    end
    local.get 2
    return
    end
    local.get 3
    return
    i32.const 0)
  (func $http____target_start (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 10
    i32.const 1
    i32.and
    if (result i32)
    local.get 10
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 10
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 10
    i32.const 4
    i32.add
    i32.load
    else
    local.get 10
    i32.const 4
    i32.add
    end
    end
    local.set 5
    local.get 0
    i32.const -2
    i32.add
    local.tee 10
    local.get 10
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 6
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 5
    i32.const 0
    local.set 6
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 6
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    i32.const 1
    i32.add
    local.set 8
    local.get 2
    local.get 8
    i32.eq
    i32.eqz
    br_if 5
    end
    local.get 0
    local.get 1
    local.set 7
    drop
    local.get 7
    local.get 6
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 5
    local.get 7
    i32.add
    i32.load8_u
    local.set 8
    local.get 8
    i32.const 42
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 3
    i32.eqz
    br_if 1
    end
    i32.const -1
    return
    end
    end
    i32.const -2
    return
    end
    end
    local.get 2
    local.get 1
    i32.gt_s
    i32.eqz
    br_if 2
    end
    local.get 0
    local.get 1
    local.set 7
    drop
    local.get 7
    local.get 6
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 5
    local.get 7
    i32.add
    i32.load8_u
    local.set 8
    local.get 8
    i32.const 47
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 1
    return
    end
    end
    local.get 0
    local.get 1
    local.get 2
    call $http____absolute_form_path
    local.set 4
    local.get 4
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const -2
    return
    end
    local.get 4
    return
    i32.const 0)
  (func $http____path_end (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 9
    i32.const 1
    i32.and
    if (result i32)
    local.get 9
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 9
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 9
    i32.const 4
    i32.add
    i32.load
    else
    local.get 9
    i32.const 4
    i32.add
    end
    end
    local.set 5
    local.get 0
    i32.const -2
    i32.add
    local.tee 9
    local.get 9
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 6
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 5
    i32.const 0
    local.set 6
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 6
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    local.set 4
    end
    loop
    block
    block
    block
    local.get 4
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 0
    local.get 4
    local.set 7
    drop
    local.get 7
    local.get 6
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 5
    local.get 7
    i32.add
    i32.load8_u
    i32.const 63
    i32.eq
    br_if 4
    end
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 4
    br 0
    end
    end
    i32.const -1
    local.set 3
    br 1
    end
    local.get 4
    local.set 3
    end
    local.get 3
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 2
    return
    end
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 7
    local.get 0
    local.get 7
    local.get 2
    call $http____query_ok
    i32.eqz
    br_if 1
    end
    local.get 3
    return
    end
    i32.const -1
    return
    i32.const 0)
  (func $http____absolute_form_path (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 12
    i32.const 1
    i32.and
    if (result i32)
    local.get 12
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 12
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 12
    i32.const 4
    i32.add
    i32.load
    else
    local.get 12
    i32.const 4
    i32.add
    end
    end
    local.set 8
    local.get 0
    i32.const -2
    i32.add
    local.tee 12
    local.get 12
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 9
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 8
    i32.const 0
    local.set 9
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 9
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    i32.const -1
    local.set 3
    global.get $__str_base
    i32.const 0
    i32.add
    local.set 10
    local.get 0
    local.get 1
    local.get 2
    local.get 10
    call $http____prefix_ci
    i32.eqz
    br_if 1
    end
    local.get 1
    i32.const 7
    i32.add
    local.set 4
    br 1
    end
    local.get 3
    local.set 4
    end
    global.get $__str_base
    i32.const 12
    i32.add
    local.set 10
    local.get 0
    local.get 1
    local.get 2
    local.get 10
    call $http____prefix_ci
    i32.eqz
    br_if 1
    end
    local.get 1
    i32.const 8
    i32.add
    local.set 5
    br 1
    end
    local.get 4
    local.set 5
    end
    local.get 5
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const -1
    return
    end
    local.get 5
    local.set 6
    end
    loop
    block
    block
    block
    block
    block
    local.get 6
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 6
    end
    local.get 0
    local.get 6
    local.set 10
    drop
    local.get 10
    local.get 9
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 8
    local.get 10
    i32.add
    i32.load8_u
    local.set 7
    local.get 7
    i32.const 47
    i32.ne
    i32.eqz
    br_if 5
    end
    local.get 7
    i32.const 63
    i32.ne
    i32.eqz
    br_if 4
    end
    local.get 7
    call $http____is_pchar
    i32.eqz
    br_if 5
    end
    end
    local.get 6
    i32.const 1
    i32.add
    local.set 6
    br 0
    end
    end
    local.get 6
    local.get 5
    i32.eq
    i32.eqz
    br_if 2
    end
    i32.const -1
    return
    end
    i32.const -1
    return
    end
    local.get 6
    return
    i32.const 0)
  (func $http____prefix_ci (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 14
    i32.const 1
    i32.and
    if (result i32)
    local.get 14
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 14
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 14
    i32.const 4
    i32.add
    i32.load
    else
    local.get 14
    i32.const 4
    i32.add
    end
    end
    local.set 8
    local.get 0
    i32.const -2
    i32.add
    local.tee 14
    local.get 14
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 9
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 8
    i32.const 0
    local.set 9
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 9
    end
    end
    block
    block
    block
    block
    block
    block
    local.get 2
    local.get 1
    i32.sub
    local.set 10
    local.get 3
    i32.load
    local.set 11
    local.get 10
    local.get 11
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    return
    end
    end
    i32.const 0
    local.set 4
    end
    local.get 3
    i32.load
    local.set 10
    local.get 3
    i32.const 4
    i32.add
    local.set 11
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 10
    local.set 12
    local.get 4
    local.get 12
    i32.lt_s
    i32.eqz
    br_if 9
    end
    local.get 1
    local.get 4
    i32.add
    local.set 12
    local.get 0
    local.get 12
    local.set 12
    drop
    local.get 12
    local.get 9
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 8
    local.get 12
    i32.add
    i32.load8_u
    local.set 5
    end
    local.get 5
    local.set 7
    local.get 7
    i32.const 65
    i32.ge_s
    i32.eqz
    br_if 2
    end
    local.get 7
    i32.const 90
    i32.le_s
    i32.eqz
    br_if 1
    end
    local.get 7
    i32.const 32
    i32.add
    local.set 6
    br 1
    end
    local.get 7
    local.set 6
    end
    local.get 11
    local.get 4
    i32.add
    i32.load8_u
    local.set 12
    local.get 6
    local.get 12
    i32.ne
    br_if 4
    end
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 4
    br 0
    end
    end
    i32.const 1
    return
    end
    i32.const 0
    return
    i32.const 0)
  (func $http____is_pchar (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    local.set 1
    end
    local.get 1
    i32.const 97
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 1
    i32.const 122
    i32.le_s
    local.set 6
    br 1
    end
    i32.const 0
    local.set 6
    end
    local.get 6
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 7
    br 3
    end
    local.get 1
    i32.const 65
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 1
    i32.const 90
    i32.le_s
    local.set 7
    br 1
    end
    i32.const 0
    local.set 7
    end
    local.get 7
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 8
    br 3
    end
    local.get 1
    i32.const 48
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 1
    i32.const 57
    i32.le_s
    local.set 8
    br 1
    end
    i32.const 0
    local.set 8
    end
    local.get 8
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 9
    br 1
    end
    local.get 1
    i32.const 45
    i32.eq
    local.set 9
    end
    local.get 9
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 10
    br 1
    end
    local.get 1
    i32.const 46
    i32.eq
    local.set 10
    end
    local.get 10
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 11
    br 1
    end
    local.get 1
    i32.const 95
    i32.eq
    local.set 11
    end
    local.get 11
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 12
    br 1
    end
    local.get 1
    i32.const 126
    i32.eq
    local.set 12
    end
    local.get 12
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 2
    br 5
    end
    end
    global.get $__str_base
    i32.const 24
    i32.add
    local.set 13
    i32.const 0
    local.set 14
    end
    local.get 13
    i32.load
    local.set 15
    local.get 13
    i32.const 4
    i32.add
    local.set 16
    loop
    block
    block
    block
    local.get 15
    local.set 17
    local.get 14
    local.get 17
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 16
    local.get 14
    i32.add
    i32.load8_u
    local.get 1
    i32.eq
    br_if 4
    end
    end
    local.get 14
    i32.const 1
    i32.add
    local.set 14
    br 0
    end
    end
    i32.const 0
    local.set 2
    br 1
    end
    i32.const 1
    local.set 2
    end
    local.get 2
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 3
    br 1
    end
    local.get 1
    i32.const 58
    i32.eq
    local.set 3
    end
    local.get 3
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 4
    br 1
    end
    local.get 1
    i32.const 64
    i32.eq
    local.set 4
    end
    local.get 4
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 5
    br 1
    end
    local.get 1
    i32.const 37
    i32.eq
    local.set 5
    end
    local.get 5
    return
    i32.const 0)
  (func $http____query_ok (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 10
    i32.const 1
    i32.and
    if (result i32)
    local.get 10
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 10
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 10
    i32.const 4
    i32.add
    i32.load
    else
    local.get 10
    i32.const 4
    i32.add
    end
    end
    local.set 6
    local.get 0
    i32.const -2
    i32.add
    local.tee 10
    local.get 10
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 7
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 6
    i32.const 0
    local.set 7
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 7
    end
    end
    block
    block
    block
    block
    local.get 1
    local.set 3
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 3
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 11
    end
    local.get 0
    local.get 3
    local.set 8
    drop
    local.get 8
    local.get 7
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 6
    local.get 8
    i32.add
    i32.load8_u
    local.set 4
    local.get 4
    i32.const 37
    i32.eq
    i32.eqz
    br_if 3
    end
    local.get 0
    local.get 3
    local.get 2
    call $http____pct_byte
    local.set 8
    local.get 8
    i32.const 0
    i32.lt_s
    br_if 10
    end
    end
    local.get 3
    i32.const 3
    i32.add
    local.set 5
    br 5
    end
    local.get 4
    call $http____is_pchar
    br_if 2
    end
    local.get 4
    i32.const 47
    i32.ne
    i32.eqz
    br_if 1
    end
    local.get 4
    i32.const 63
    i32.ne
    br_if 6
    end
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 5
    end
    local.get 5
    local.set 3
    br 0
    end
    end
    i32.const 1
    return
    end
    i32.const 0
    return
    end
    i32.const 0
    return
    i32.const 0)
  (func $http____pct_byte (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 12
    i32.const 1
    i32.and
    if (result i32)
    local.get 12
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 12
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 12
    i32.const 4
    i32.add
    i32.load
    else
    local.get 12
    i32.const 4
    i32.add
    end
    end
    local.set 7
    local.get 0
    i32.const -2
    i32.add
    local.tee 12
    local.get 12
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 8
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 7
    i32.const 0
    local.set 8
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 8
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    i32.const 2
    i32.add
    local.get 2
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const -1
    return
    end
    end
    local.get 1
    i32.const 1
    i32.add
    local.set 10
    local.get 0
    local.get 10
    local.set 9
    drop
    local.get 9
    local.get 8
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 7
    local.get 9
    i32.add
    i32.load8_u
    local.set 3
    end
    local.get 3
    i32.const 48
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 3
    i32.const 57
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 3
    local.set 10
    local.get 10
    i32.const 48
    i32.sub
    local.set 4
    br 10
    end
    end
    local.get 3
    i32.const 97
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 3
    i32.const 102
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 3
    local.set 10
    local.get 10
    i32.const 87
    i32.sub
    local.set 4
    br 6
    end
    end
    local.get 3
    i32.const 65
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 3
    i32.const 70
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 3
    local.set 10
    local.get 10
    i32.const 55
    i32.sub
    local.set 4
    br 2
    end
    end
    i32.const -1
    local.set 4
    end
    local.get 1
    i32.const 2
    i32.add
    local.set 10
    local.get 0
    local.get 10
    local.set 9
    drop
    local.get 9
    local.get 8
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 7
    local.get 9
    i32.add
    i32.load8_u
    local.set 5
    end
    local.get 5
    i32.const 48
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 5
    i32.const 57
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 5
    local.set 10
    local.get 10
    i32.const 48
    i32.sub
    local.set 6
    br 10
    end
    end
    local.get 5
    i32.const 97
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 5
    i32.const 102
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 5
    local.set 10
    local.get 10
    i32.const 87
    i32.sub
    local.set 6
    br 6
    end
    end
    local.get 5
    i32.const 65
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 5
    i32.const 70
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 5
    local.set 10
    local.get 10
    i32.const 55
    i32.sub
    local.set 6
    br 2
    end
    end
    i32.const -1
    local.set 6
    end
    local.get 4
    i32.const 0
    i32.lt_s
    br_if 1
    end
    local.get 6
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const -1
    return
    end
    end
    local.get 4
    i32.const 4
    i32.shl
    local.get 6
    i32.add
    return
    i32.const 0)
  (func $http____plain_path (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 16
    i32.const 1
    i32.and
    if (result i32)
    local.get 16
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 16
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 16
    i32.const 4
    i32.add
    i32.load
    else
    local.get 16
    i32.const 4
    i32.add
    end
    end
    local.set 11
    local.get 0
    i32.const -2
    i32.add
    local.tee 16
    local.get 16
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 12
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 11
    i32.const 0
    local.set 12
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 12
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    i32.const 1
    i32.add
    local.get 1
    local.set 4
    local.set 3
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 4
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 17
    end
    local.get 0
    local.get 4
    local.set 13
    drop
    local.get 13
    local.get 12
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 11
    local.get 13
    i32.add
    i32.load8_u
    local.set 5
    local.get 5
    i32.const 47
    i32.eq
    i32.eqz
    br_if 7
    end
    local.get 4
    local.get 1
    i32.gt_s
    i32.eqz
    br_if 11
    end
    end
    local.get 4
    local.get 3
    i32.sub
    local.set 9
    local.get 9
    i32.const 1
    i32.lt_s
    br_if 3
    end
    local.get 9
    i32.const 2
    i32.gt_s
    br_if 2
    end
    local.get 0
    local.get 3
    local.set 13
    drop
    local.get 13
    local.get 12
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 11
    local.get 13
    i32.add
    i32.load8_u
    local.set 14
    local.get 14
    i32.const 46
    i32.ne
    br_if 1
    end
    local.get 4
    i32.const 1
    i32.sub
    local.set 14
    local.get 0
    local.get 14
    local.set 13
    drop
    local.get 13
    local.get 12
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 11
    local.get 13
    i32.add
    i32.load8_u
    local.set 14
    local.get 14
    i32.const 46
    i32.ne
    i32.eqz
    br_if 4
    end
    i32.const 0
    local.set 6
    br 4
    end
    local.get 5
    i32.const 37
    i32.eq
    br_if 15
    end
    local.get 5
    call $http____is_pchar
    i32.eqz
    br_if 14
    end
    local.get 3
    local.set 7
    br 4
    end
    local.get 9
    local.set 6
    end
    local.get 6
    i32.const 0
    i32.gt_s
    br_if 10
    end
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 7
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 14
    local.get 7
    local.get 14
    local.set 4
    local.set 3
    br 0
    end
    end
    end
    local.get 2
    local.get 3
    i32.sub
    local.set 10
    local.get 10
    i32.const 1
    i32.lt_s
    br_if 3
    end
    local.get 10
    i32.const 2
    i32.gt_s
    br_if 2
    end
    local.get 0
    local.get 3
    local.set 13
    drop
    local.get 13
    local.get 12
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 11
    local.get 13
    i32.add
    i32.load8_u
    local.set 14
    local.get 14
    i32.const 46
    i32.ne
    br_if 1
    end
    local.get 2
    i32.const 1
    i32.sub
    local.set 14
    local.get 0
    local.get 14
    local.set 13
    drop
    local.get 13
    local.get 12
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 11
    local.get 13
    i32.add
    i32.load8_u
    local.set 14
    local.get 14
    i32.const 46
    i32.ne
    i32.eqz
    br_if 3
    end
    i32.const 0
    local.set 8
    br 3
    end
    i32.const 0
    return
    end
    i32.const 0
    return
    end
    local.get 10
    local.set 8
    end
    local.get 8
    i32.const 0
    i32.eq
    return
    i32.const 0)
  (func $http____decoded_path (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 43
    i32.const 1
    i32.and
    if (result i32)
    local.get 43
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 43
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 43
    i32.const 4
    i32.add
    i32.load
    else
    local.get 43
    i32.const 4
    i32.add
    end
    end
    local.set 35
    local.get 0
    i32.const -2
    i32.add
    local.tee 43
    local.get 43
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 36
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 35
    i32.const 0
    local.set 36
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 36
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    global.get $__cagg_base
    i32.const 328
    i32.add
    local.set 40
    local.get 1
    i32.const 1
    i32.add
    local.set 41
    local.get 40
    i32.const 0
    i32.const 0
    i32.const 0
    local.get 41
    local.set 8
    local.set 7
    local.set 6
    local.set 5
    local.set 4
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 8
    local.get 2
    i32.le_s
    i32.eqz
    br_if 33
    end
    i32.const 47
    local.set 9
    end
    local.get 4
    i32.load
    local.set 40
    local.get 5
    local.get 40
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 4
    call $__fern_rc_is_unique
    if
    local.get 4
    local.set 34
    else
    local.get 4
    call $__fern_arr_dec
    drop
    local.get 4
    i32.const 0
    local.get 4
    i32.load
    call $__fern_arr_slice_u8
    local.set 34
    end
    local.get 34
    local.get 5
    i32.const 47
    local.set 43
    local.set 46
    local.tee 42
    i32.load
    local.get 46
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 42
    local.get 46
    i32.const 8
    i32.add
    i32.add
    local.get 43
    i32.store8
    local.get 34
    local.set 10
    br 2
    end
    end
    local.get 4
    call $__fern_rc_is_unique
    if
    local.get 4
    local.get 9
    call $__fern_arr_push_owned_u8
    local.set 34
    else
    local.get 4
    local.get 9
    call $__fern_arr_push_u8
    local.set 34
    local.get 4
    call $__fern_arr_dec
    drop
    end
    local.get 34
    local.set 10
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 40
    local.get 10
    local.get 40
    local.get 7
    local.get 8
    local.set 14
    local.set 13
    local.set 12
    local.set 11
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 14
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 18
    end
    local.get 0
    local.get 14
    local.set 39
    drop
    local.get 39
    local.get 36
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 35
    local.get 39
    i32.add
    i32.load8_u
    local.set 15
    local.get 15
    i32.const 47
    i32.ne
    i32.eqz
    br_if 17
    end
    local.get 0
    local.get 14
    local.get 2
    call $http____path_byte
    local.set 16
    local.get 16
    i32.const 0
    i32.lt_s
    if
    local.get 11
    call $__fern_arr_dec
    drop
    br 46
    else
    end
    end
    end
    local.get 13
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 17
    br 1
    end
    local.get 16
    i32.const 128
    i32.ge_s
    local.set 17
    end
    local.get 16
    i32.const 255
    i32.and
    local.set 18
    end
    local.get 11
    i32.load
    local.set 40
    local.get 12
    local.get 40
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 11
    call $__fern_rc_is_unique
    if
    local.get 11
    local.set 34
    else
    local.get 11
    call $__fern_arr_dec
    drop
    local.get 11
    i32.const 0
    local.get 11
    i32.load
    call $__fern_arr_slice_u8
    local.set 34
    end
    local.get 34
    local.get 12
    local.get 18
    local.set 43
    local.set 46
    local.tee 42
    i32.load
    local.get 46
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 42
    local.get 46
    i32.const 8
    i32.add
    i32.add
    local.get 43
    i32.store8
    local.get 34
    local.set 19
    br 2
    end
    end
    local.get 11
    call $__fern_rc_is_unique
    if
    local.get 11
    local.get 18
    call $__fern_arr_push_owned_u8
    local.set 34
    else
    local.get 11
    local.get 18
    call $__fern_arr_push_u8
    local.set 34
    local.get 11
    call $__fern_arr_dec
    drop
    end
    local.get 34
    local.set 19
    end
    local.get 12
    i32.const 1
    i32.add
    local.set 20
    end
    local.get 15
    i32.const 37
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 3
    local.set 21
    br 2
    end
    end
    i32.const 1
    local.set 21
    end
    local.get 14
    local.get 21
    i32.add
    local.set 40
    local.get 19
    local.get 20
    local.get 17
    local.get 40
    local.set 14
    local.set 13
    local.set 12
    local.set 11
    br 0
    end
    end
    local.get 14
    local.get 2
    i32.eq
    local.set 22
    local.get 11
    local.tee 23
    i32.const 2
    i32.and
    if
    local.get 23
    i32.const -2
    i32.add
    local.tee 43
    i32.const 1
    i32.and
    if (result i32)
    local.get 43
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 43
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 43
    i32.const 4
    i32.add
    i32.load
    else
    local.get 43
    i32.const 4
    i32.add
    end
    end
    local.set 37
    local.get 23
    i32.const -2
    i32.add
    local.tee 43
    local.get 43
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 38
    else
    local.get 23
    i32.const 8
    i32.add
    local.set 37
    i32.const 0
    local.set 38
    local.get 23
    i32.const 0
    i32.ne
    if
    local.get 23
    i32.load
    local.set 38
    end
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 24
    end
    local.get 12
    local.get 24
    i32.sub
    local.set 29
    local.get 29
    i32.const 1
    i32.lt_s
    br_if 3
    end
    local.get 29
    i32.const 2
    i32.gt_s
    br_if 2
    end
    local.get 23
    local.get 24
    local.set 39
    drop
    local.get 39
    local.get 38
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 37
    local.get 39
    i32.add
    i32.load8_u
    local.set 40
    local.get 40
    i32.const 46
    i32.ne
    br_if 1
    end
    local.get 12
    i32.const 1
    i32.sub
    local.set 40
    local.get 23
    local.get 40
    local.set 39
    drop
    local.get 39
    local.get 38
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 37
    local.get 39
    i32.add
    i32.load8_u
    local.set 40
    local.get 40
    i32.const 46
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 25
    br 1
    end
    local.get 29
    local.set 25
    end
    local.get 25
    i32.const 0
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 12
    i32.const 0
    local.set 28
    local.set 27
    br 15
    end
    end
    local.get 25
    i32.const 1
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 5
    local.set 26
    br 10
    end
    end
    local.get 5
    i32.const 0
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.set 26
    br 7
    end
    end
    local.get 5
    i32.const 1
    i32.sub
    local.set 30
    end
    loop
    block
    local.get 11
    local.get 30
    local.set 46
    local.tee 42
    i32.load
    local.get 46
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 42
    local.get 46
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 40
    local.get 40
    i32.const 47
    i32.ne
    i32.eqz
    br_if 2
    end
    local.get 30
    i32.const 1
    i32.sub
    local.set 30
    br 0
    end
    end
    local.get 13
    i32.eqz
    br_if 1
    end
    local.get 11
    local.get 30
    local.get 5
    call $__fern_string_from_bytes_range
    local.tee 40
    call $utf8__is_valid
    local.set 41
    local.get 40
    call $__fern_arr_dec
    drop
    local.get 41
    i32.eqz
    br_if 1
    end
    local.get 30
    local.set 26
    br 1
    end
    i32.const -1
    local.set 26
    end
    local.get 26
    i32.const 0
    i32.lt_s
    if
    local.get 11
    call $__fern_arr_dec
    drop
    br 8
    else
    end
    end
    local.get 26
    local.get 22
    local.set 28
    local.set 27
    end
    local.get 14
    i32.const 1
    i32.add
    local.set 40
    local.get 11
    local.get 27
    local.get 28
    local.get 13
    local.get 40
    local.set 8
    local.set 7
    local.set 6
    local.set 5
    local.set 4
    br 0
    end
    end
    local.get 4
    local.get 5
    local.get 6
    local.get 7
    local.get 0
    local.get 2
    local.get 3
    call $http____finished_path
    local.set 40
    global.get $__fern_ret_word
    local.set 31
    local.get 4
    call $__fern_arr_dec
    drop
    local.get 31
    local.set 31
    local.get 40
    i32.const 0
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 31
    local.set 32
    end
    local.get 32
    global.set $__fern_ret_word
    i32.const 0
    drop
    i32.const 0
    return
    end
    i32.const 400
    global.set $__fern_ret_word
    i32.const 0
    drop
    i32.const 1
    return
    end
    i32.const 400
    global.set $__fern_ret_word
    i32.const 0
    drop
    i32.const 1
    return
    end
    local.get 31
    local.set 33
    end
    local.get 33
    global.set $__fern_ret_word
    i32.const 0
    drop
    i32.const 1
    return
    i32.const 0)
  (func $http____path_byte (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 9
    i32.const 1
    i32.and
    if (result i32)
    local.get 9
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 9
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 9
    i32.const 4
    i32.add
    i32.load
    else
    local.get 9
    i32.const 4
    i32.add
    end
    end
    local.set 5
    local.get 0
    i32.const -2
    i32.add
    local.tee 9
    local.get 9
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 6
    else
    local.get 0
    i32.const 8
    i32.add
    local.set 5
    i32.const 0
    local.set 6
    local.get 0
    i32.const 0
    i32.ne
    if
    local.get 0
    i32.load
    local.set 6
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    local.get 1
    local.set 7
    drop
    local.get 7
    local.get 6
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 5
    local.get 7
    i32.add
    i32.load8_u
    local.set 3
    local.get 3
    i32.const 37
    i32.eq
    i32.eqz
    br_if 6
    end
    local.get 0
    local.get 1
    local.get 2
    call $http____pct_byte
    local.set 4
    local.get 4
    i32.const 0
    i32.le_s
    br_if 3
    end
    local.get 4
    i32.const 47
    i32.eq
    br_if 2
    end
    local.get 4
    i32.const 63
    i32.eq
    br_if 1
    end
    local.get 4
    i32.const 35
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const -1
    return
    end
    local.get 4
    return
    end
    end
    local.get 3
    i32.const 255
    i32.and
    call $http____is_pchar
    i32.eqz
    br_if 1
    end
    local.get 3
    return
    end
    i32.const -1
    return
    i32.const 0)
  (func $http____finished_path (param i32) (param i32) (param i32) (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    local.get 4
    i32.const 2
    i32.and
    if
    local.get 4
    i32.const -2
    i32.add
    local.tee 21
    i32.const 1
    i32.and
    if (result i32)
    local.get 21
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 21
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 21
    i32.const 4
    i32.add
    i32.load
    else
    local.get 21
    i32.const 4
    i32.add
    end
    end
    local.set 16
    local.get 4
    i32.const -2
    i32.add
    local.tee 21
    local.get 21
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    local.set 17
    else
    local.get 4
    i32.const 8
    i32.add
    local.set 16
    i32.const 0
    local.set 17
    local.get 4
    i32.const 0
    i32.ne
    if
    local.get 4
    i32.load
    local.set 17
    end
    end
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    i32.const 0
    i32.eq
    br_if 1
    end
    local.get 2
    i32.eqz
    br_if 3
    end
    i32.const 47
    local.set 7
    end
    local.get 0
    i32.load
    local.set 18
    local.get 1
    local.get 18
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    local.set 15
    else
    local.get 0
    i32.const 0
    local.get 0
    i32.load
    call $__fern_arr_slice_u8
    local.set 15
    end
    local.get 15
    local.get 1
    i32.const 47
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 15
    local.set 8
    br 3
    end
    local.get 0
    local.get 1
    local.get 5
    local.set 11
    local.set 10
    local.set 9
    br 3
    end
    end
    local.get 0
    local.get 7
    call $__fern_arr_push_u8
    local.tee 15
    local.set 8
    end
    local.get 1
    i32.const 1
    i32.add
    local.set 18
    local.get 8
    local.get 18
    local.get 5
    local.set 11
    local.set 10
    local.set 9
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 11
    local.get 6
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 4
    local.get 11
    local.set 18
    drop
    local.get 18
    local.get 17
    i32.ge_u
    if
    call $__fern_oob_abort
    drop
    end
    local.get 16
    local.get 18
    i32.add
    i32.load8_u
    local.set 12
    end
    local.get 9
    i32.load
    local.set 18
    local.get 10
    local.get 18
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 9
    local.get 0
    i32.eq
    if
    local.get 9
    call $__fern_rc_is_unique
    if
    local.get 9
    local.set 15
    else
    local.get 9
    i32.const 0
    local.get 9
    i32.load
    call $__fern_arr_slice_u8
    local.set 15
    end
    else
    local.get 9
    call $__fern_rc_is_unique
    if
    local.get 9
    local.set 15
    else
    local.get 9
    call $__fern_arr_dec
    drop
    local.get 9
    i32.const 0
    local.get 9
    i32.load
    call $__fern_arr_slice_u8
    local.set 15
    end
    end
    local.get 15
    local.get 10
    local.get 12
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 15
    local.set 13
    br 2
    end
    end
    local.get 9
    local.get 0
    i32.eq
    if
    local.get 9
    local.get 12
    call $__fern_arr_push_u8
    local.set 15
    else
    local.get 9
    local.get 12
    call $__fern_arr_push_owned_u8
    local.set 15
    end
    local.get 15
    local.set 13
    end
    local.get 10
    i32.const 1
    i32.add
    local.set 18
    local.get 11
    i32.const 1
    i32.add
    local.set 19
    local.get 13
    local.get 18
    local.get 19
    local.set 11
    local.set 10
    local.set 9
    br 0
    end
    end
    local.get 9
    i32.const 0
    local.get 10
    call $__fern_string_from_bytes_range
    local.set 14
    local.get 9
    local.get 0
    i32.ne
    if
    local.get 9
    call $__fern_arr_dec
    drop
    end
    local.get 3
    i32.eqz
    br_if 1
    end
    local.get 14
    call $utf8__is_valid
    if
    else
    local.get 14
    call $__fern_arr_dec
    drop
    br 3
    end
    end
    end
    local.get 14
    global.set $__fern_ret_word
    i32.const 0
    drop
    i32.const 0
    return
    end
    i32.const 400
    global.set $__fern_ret_word
    i32.const 0
    drop
    i32.const 1
    return
    i32.const 0)
  (func $http__serialize_response_to (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 2
    call $__fern_rc_inc
    drop
    local.get 0
    local.get 1
    local.get 2
    local.get 3
    local.set 14
    local.set 13
    local.set 12
    local.set 11
    end
    loop
    block
    block
    local.get 13
    i32.const 24
    i32.add
    i32.load
    call $http__fields_ok
    if
    else
    local.get 13
    call $__sem_release_HttpResponse
    drop
    br 2
    end
    end
    local.get 13
    i32.const 32
    i32.add
    i32.load
    local.set 31
    local.get 13
    call $__fern_rc_is_unique
    local.tee 30
    if
    local.get 13
    i32.const 0
    local.set 35
    i32.const 32
    i32.add
    local.get 35
    i32.store
    end
    local.get 30
    i32.const 0
    i32.eq
    if
    local.get 31
    call $__fern_rc_inc
    drop
    end
    local.get 31
    call $http__fields_ok
    local.set 32
    local.get 31
    call $__sem_release_HeaderMap
    drop
    local.get 32
    if
    br 3
    else
    local.get 13
    call $__sem_release_HttpResponse
    drop
    end
    end
    global.get $__cagg_base
    i32.const 344
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    drop
    global.get $__cagg_base
    i32.const 368
    i32.add
    drop
    global.get $__cagg_base
    i32.const 384
    i32.add
    local.set 31
    local.get 11
    local.get 12
    local.get 31
    local.get 14
    local.set 14
    local.set 13
    local.set 12
    local.set 11
    br 0
    end
    end
    end
    local.get 13
    i32.const 8
    i32.add
    i32.load
    local.set 4
    end
    local.get 4
    i32.const 200
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 15
    br 1
    end
    local.get 4
    i32.const 204
    i32.eq
    local.set 15
    end
    local.get 15
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 16
    br 1
    end
    local.get 4
    i32.const 304
    i32.eq
    local.set 16
    end
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 5
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 6
    local.get 16
    i32.eqz
    br_if 1
    end
    local.get 5
    local.get 6
    local.set 8
    local.set 7
    br 4
    end
    end
    local.get 13
    i32.const 16
    i32.add
    i32.load
    local.set 27
    local.get 13
    call $__fern_rc_is_unique
    local.tee 30
    if
    local.get 13
    i32.const 0
    local.set 35
    i32.const 16
    i32.add
    local.get 35
    i32.store
    end
    local.get 30
    i32.const 0
    i32.eq
    if
    local.get 27
    call $__fern_rc_inc
    drop
    end
    local.get 27
    i32.load
    global.get $__tid$Body$BodyText
    i32.eq
    if
    else
    local.get 13
    call $__sem_release_HttpResponse
    drop
    local.get 27
    call $__sem_release_Body
    drop
    br 45
    end
    end
    local.get 27
    call $__fern_rc_is_unique
    if
    local.get 27
    local.set 29
    else
    i32.const 0
    local.set 29
    end
    local.get 27
    i32.const 8
    i32.add
    i32.load
    local.set 28
    local.get 29
    i32.const 0
    i32.eq
    if
    local.get 28
    call $__fern_rc_inc
    drop
    end
    local.get 29
    i32.const 0
    i32.ne
    if
    local.get 27
    call $__fern_arr_dec
    drop
    else
    local.get 27
    call $__sem_release_Body
    drop
    end
    end
    global.get $__str_base
    i32.const 44
    i32.add
    local.set 31
    local.get 28
    i32.load
    call $int__int_to_string
    local.set 32
    local.get 31
    local.get 32
    call $__fern_strcat
    local.set 31
    local.get 32
    call $__fern_arr_dec
    drop
    global.get $__str_base
    i32.const 64
    i32.add
    local.set 32
    local.get 31
    local.get 32
    call $__fern_str_grow
    if
    local.get 31
    local.set 30
    else
    local.get 31
    local.get 32
    call $__fern_str_grow_fresh
    local.set 30
    local.get 31
    call $__fern_arr_dec
    drop
    end
    local.get 30
    local.get 28
    local.set 8
    local.set 7
    end
    i32.const 256
    call $__fern_buf_new
    local.set 9
    end
    end
    global.get $__str_base
    i32.const 72
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 4
    i64.extend_i32_s
    local.set 17
    end
    local.get 17
    i64.const 0
    i64.lt_s
    i32.eqz
    br_if 1
    end
    local.get 9
    i32.const 45
    call $__fern_buf_push_byte
    i32.const 0
    drop
    local.get 17
    local.set 33
    i64.const 0
    local.get 33
    i64.sub
    local.set 33
    local.get 9
    local.get 33
    call $__fern_buf_push_decimal
    i32.const 0
    drop
    br 2
    end
    end
    local.get 17
    local.set 33
    local.get 9
    local.get 33
    call $__fern_buf_push_decimal
    i32.const 0
    drop
    end
    global.get $__str_base
    i32.const 88
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    end
    end
    global.get $__cagg_base
    i32.const 440
    i32.add
    local.set 23
    global.get $__cagg_base
    i32.const 656
    i32.add
    local.set 24
    i32.const 0
    local.set 25
    end
    loop
    block
    block
    block
    local.get 23
    i32.load
    local.set 31
    local.get 25
    local.get 31
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 23
    local.get 25
    local.set 38
    local.get 38
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.get 4
    i32.eq
    br_if 4
    end
    end
    local.get 25
    i32.const 1
    i32.add
    local.set 25
    br 0
    end
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 22
    br 1
    end
    local.get 24
    local.get 25
    local.set 38
    local.tee 34
    i32.load
    local.get 38
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 34
    local.get 38
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 31
    call $__fern_rc_inc
    drop
    local.get 31
    local.set 22
    end
    local.get 22
    i32.load
    local.set 31
    local.get 31
    i32.const 0
    i32.eq
    if
    local.get 22
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    global.get $__str_base
    i32.const 1140
    i32.add
    local.set 18
    br 1
    end
    local.get 22
    local.set 18
    end
    local.get 9
    local.get 18
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 18
    call $__fern_arr_dec
    drop
    global.get $__str_base
    i32.const 64
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    i32.const 0
    local.set 19
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 13
    i32.const 24
    i32.add
    i32.load
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 31
    local.get 19
    local.get 31
    i32.lt_s
    if
    else
    local.get 13
    call $__sem_release_HttpResponse
    drop
    br 8
    end
    end
    local.get 13
    i32.const 24
    i32.add
    i32.load
    local.tee 20
    i32.const 8
    i32.add
    i32.load
    local.get 19
    local.set 38
    local.get 38
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 21
    global.get $__str_base
    i32.const 1152
    i32.add
    local.set 31
    local.get 21
    local.get 31
    call $string.eq_ignore_ascii_case
    br_if 2
    end
    global.get $__str_base
    i32.const 1172
    i32.add
    local.set 31
    local.get 21
    local.get 31
    call $string.eq_ignore_ascii_case
    br_if 1
    end
    global.get $__str_base
    i32.const 1188
    i32.add
    local.set 31
    local.get 21
    local.get 31
    call $string.eq_ignore_ascii_case
    i32.eqz
    br_if 1
    end
    br 1
    end
    local.get 20
    i32.const 8
    i32.add
    i32.load
    local.get 19
    local.set 38
    local.get 38
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    global.get $__str_base
    i32.const 1212
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 20
    i32.const 16
    i32.add
    i32.load
    local.get 19
    local.set 38
    local.tee 34
    i32.load
    local.get 38
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 34
    local.get 38
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    global.get $__str_base
    i32.const 64
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    end
    local.get 19
    i32.const 1
    i32.add
    local.set 19
    br 0
    end
    end
    end
    local.get 9
    local.get 7
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 7
    call $__fern_arr_dec
    drop
    end
    local.get 4
    i32.const 101
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 1220
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    br 14
    end
    end
    end
    local.get 14
    i32.eqz
    br_if 4
    end
    end
    end
    local.get 12
    i32.load
    local.set 31
    local.get 31
    i32.const 8
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 12
    i32.const 4
    i32.add
    i32.const 7
    i32.add
    i32.load8_u
    local.set 31
    local.get 31
    i32.const 48
    i32.eq
    local.set 26
    br 2
    end
    global.get $__str_base
    i32.const 1248
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    br 5
    end
    i32.const 0
    local.set 26
    end
    local.get 26
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 1276
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    br 2
    end
    end
    global.get $__str_base
    i32.const 64
    i32.add
    local.set 31
    local.get 9
    local.get 31
    call $__fern_buf_push
    i32.const 0
    drop
    end
    end
    end
    local.get 9
    call $__fern_buf_take
    local.set 10
    local.get 9
    call $__fern_buf_free
    i32.const 0
    drop
    local.get 16
    if
    local.get 8
    call $__fern_arr_dec
    drop
    br 2
    else
    end
    end
    global.get $__str_base
    i32.const 1308
    i32.add
    local.set 31
    i32.const 0
    local.set 30
    local.get 11
    i32.load
    i32.const 4
    i32.eq
    if
    local.get 11
    local.get 31
    call $__fern_streq
    local.set 30
    end
    local.get 30
    if
    local.get 8
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    local.get 10
    return
    end
    end
    local.get 10
    local.get 8
    call $__fern_str_grow
    if
    local.get 10
    local.set 30
    else
    local.get 10
    local.get 8
    call $__fern_str_grow_fresh
    local.set 30
    local.get 10
    call $__fern_arr_dec
    drop
    end
    local.get 30
    local.set 31
    local.get 8
    call $__fern_arr_dec
    drop
    local.get 31
    return
    end
    i32.const 134
    call $__fern_proc_exit
    i32.const 0
    i32.const 0
    return
    i32.const 0)
  (func $HttpResponse.body_text_lossy (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    block
    block
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.tee 1
    i32.load
    global.get $__tid$Body$BodyText
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 1
    i32.const 8
    i32.add
    i32.load
    local.tee 2
    call $__fern_rc_inc
    drop
    local.get 2
    return
    end
    i32.const 134
    call $__fern_proc_exit
    i32.const 0
    i32.const 0
    return
    i32.const 0)
  (func $http____lists_token (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    local.get 0
    i32.load
    local.set 2
    i32.const 0
    local.set 3
    end
    loop
    block
    block
    block
    block
    block
    local.get 3
    local.get 2
    i32.le_s
    i32.eqz
    br_if 6
    end
    local.get 3
    local.set 4
    end
    loop
    block
    block
    local.get 4
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 3
    end
    local.get 0
    local.get 4
    local.set 10
    local.tee 6
    i32.load
    local.get 10
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 6
    local.get 10
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 5
    local.get 5
    i32.const 44
    i32.ne
    i32.eqz
    br_if 2
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 4
    br 0
    end
    end
    local.get 0
    local.get 3
    local.get 4
    local.get 1
    call $http____token_at
    br_if 4
    end
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 3
    br 0
    end
    end
    i32.const 0
    return
    end
    i32.const 1
    return
    i32.const 0)
  (func $http__fields_ok (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    i32.const 0
    local.set 1
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 4
    local.get 1
    local.get 4
    i32.lt_s
    i32.eqz
    br_if 10
    end
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.get 1
    local.set 10
    local.get 10
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 2
    end
    end
    local.get 2
    i32.load
    local.set 4
    local.get 4
    i32.const 0
    i32.gt_s
    i32.eqz
    br_if 1
    end
    global.get $__cagg_base
    i32.const 56
    i32.add
    local.set 4
    local.get 2
    i32.const 0
    local.get 4
    call $__fern_scan_set
    local.set 4
    local.get 2
    i32.load
    local.set 5
    local.get 4
    local.get 5
    i32.eq
    local.set 3
    br 1
    end
    i32.const 0
    local.set 3
    end
    local.get 3
    i32.eqz
    br_if 5
    end
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.get 1
    local.set 10
    local.tee 6
    i32.load
    local.get 10
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 6
    local.get 10
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 4
    global.get $__cagg_base
    i32.const 872
    i32.add
    local.set 5
    local.get 4
    i32.const 0
    local.get 5
    call $__fern_scan_set
    local.set 5
    local.get 4
    i32.load
    local.set 4
    local.get 5
    local.get 4
    i32.eq
    i32.eqz
    br_if 4
    end
    end
    local.get 1
    i32.const 1
    i32.add
    local.set 1
    br 0
    end
    end
    i32.const 1
    return
    end
    i32.const 0
    return
    i32.const 0)
  (func $__map_fnv_str_seeded (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    i32.const 2166136261
    local.set 8
    local.get 1
    local.set 9
    local.get 8
    local.get 9
    i32.xor
    local.set 8
    i32.const 16777619
    local.set 2
    local.get 0
    i32.load
    local.set 3
    local.get 8
    i32.const 0
    local.set 5
    local.set 4
    end
    loop
    block
    local.get 5
    i32.const 4
    i32.add
    local.get 3
    i32.le_s
    i32.eqz
    br_if 2
    end
    local.get 5
    i32.const 3
    i32.add
    local.set 8
    local.get 5
    i32.const 31
    i32.shr_s
    local.set 9
    local.get 8
    local.get 9
    i32.or
    local.set 8
    local.get 0
    local.get 8
    local.set 14
    local.tee 10
    i32.load
    local.get 14
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    i32.const 0
    drop
    local.get 0
    i32.const 4
    i32.add
    local.get 5
    i32.add
    i32.load8_u
    drop
    local.get 5
    i32.const 1
    i32.add
    local.set 8
    local.get 0
    i32.const 4
    i32.add
    local.get 8
    i32.add
    i32.load8_u
    drop
    local.get 5
    i32.const 2
    i32.add
    local.set 8
    local.get 0
    i32.const 4
    i32.add
    local.get 8
    i32.add
    i32.load8_u
    drop
    local.get 5
    i32.const 3
    i32.add
    local.set 8
    local.get 0
    i32.const 4
    i32.add
    local.get 8
    i32.add
    i32.load8_u
    drop
    local.get 5
    local.set 8
    local.get 0
    i32.const 4
    i32.add
    local.set 9
    local.get 8
    i64.extend_i32_s
    i32.wrap_i64
    local.set 8
    local.get 9
    local.get 8
    i32.add
    i32.load
    local.set 8
    local.get 4
    local.get 8
    i32.xor
    i32.const 16777619
    i32.mul
    local.set 8
    local.get 5
    i32.const 4
    i32.add
    local.set 9
    local.get 8
    local.get 9
    local.set 5
    local.set 4
    br 0
    end
    end
    local.get 4
    local.get 5
    local.set 7
    local.set 6
    end
    loop
    block
    local.get 7
    local.get 3
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 0
    local.get 7
    local.set 14
    local.tee 10
    i32.load
    local.get 14
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 10
    local.get 14
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 8
    local.get 6
    local.get 8
    i32.xor
    local.get 2
    i32.mul
    local.set 8
    local.get 7
    i32.const 1
    i32.add
    local.set 9
    local.get 8
    local.get 9
    local.set 7
    local.set 6
    br 0
    end
    end
    local.get 6
    i32.const 16
    i32.shr_u
    local.set 8
    local.get 6
    local.get 8
    i32.xor
    local.set 8
    i32.const 2246822507
    local.set 9
    local.get 8
    local.get 9
    i32.mul
    local.set 8
    local.get 8
    i32.const 13
    i32.shr_u
    local.set 9
    local.get 8
    local.get 9
    i32.xor
    local.set 8
    i32.const 3266489909
    local.set 9
    local.get 8
    local.get 9
    i32.mul
    local.set 8
    local.get 8
    i32.const 16
    i32.shr_u
    local.set 9
    local.get 8
    local.get 9
    i32.xor
    return
    i32.const 0)
  (func $string____str_maxsuf (param i32) (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    i32.const -1
    i32.const 0
    i32.const 1
    i32.const 1
    local.set 8
    local.set 7
    local.set 6
    local.set 5
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 6
    local.get 7
    i32.add
    local.get 1
    i32.lt_s
    i32.eqz
    br_if 12
    end
    local.get 6
    local.get 7
    i32.add
    local.set 17
    local.get 4
    local.get 17
    i32.mul
    local.set 17
    local.get 3
    local.get 17
    i32.add
    local.set 17
    local.get 0
    local.get 17
    local.set 23
    local.tee 19
    i32.load
    local.get 23
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 19
    local.get 23
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 9
    local.get 5
    local.get 7
    i32.add
    local.set 17
    local.get 4
    local.get 17
    i32.mul
    local.set 17
    local.get 3
    local.get 17
    i32.add
    local.set 17
    local.get 0
    local.get 17
    local.set 23
    local.tee 19
    i32.load
    local.get 23
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 19
    local.get 23
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 10
    local.get 2
    i32.eqz
    br_if 1
    end
    local.get 10
    local.get 9
    local.set 12
    local.set 11
    br 1
    end
    local.get 9
    local.get 10
    local.set 12
    local.set 11
    end
    local.get 11
    local.get 12
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 6
    local.get 7
    i32.add
    local.set 17
    local.get 17
    local.get 5
    i32.sub
    local.set 18
    local.get 5
    local.get 17
    i32.const 1
    local.get 18
    local.set 16
    local.set 15
    local.set 14
    local.set 13
    br 5
    end
    local.get 11
    local.get 12
    i32.eq
    i32.eqz
    br_if 3
    end
    local.get 7
    local.get 8
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 6
    local.get 8
    i32.add
    local.set 17
    local.get 5
    local.get 17
    i32.const 1
    local.get 8
    local.set 16
    local.set 15
    local.set 14
    local.set 13
    br 2
    end
    local.get 7
    i32.const 1
    i32.add
    local.set 17
    local.get 5
    local.get 6
    local.get 17
    local.get 8
    local.set 16
    local.set 15
    local.set 14
    local.set 13
    br 1
    end
    local.get 6
    i32.const 1
    i32.add
    local.set 17
    local.get 6
    local.get 17
    i32.const 1
    i32.const 1
    local.set 16
    local.set 15
    local.set 14
    local.set 13
    end
    local.get 13
    local.get 14
    local.get 15
    local.get 16
    local.set 8
    local.set 7
    local.set 6
    local.set 5
    br 0
    end
    end
    local.get 8
    global.set $__fern_ret_word
    i32.const 0
    drop
    local.get 5
    return
    i32.const 0)
  (func $string____str_two_way (param i32) (param i32) (param i32) (param i32) (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    end
    local.get 3
    i32.const 3
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 3
    i32.const 1
    i32.sub
    local.set 29
    local.get 29
    i32.const 1
    local.set 24
    local.set 23
    br 5
    end
    end
    local.get 2
    local.get 3
    i32.const 0
    local.get 6
    local.get 7
    call $string____str_maxsuf
    local.set 25
    global.get $__fern_ret_word
    local.set 29
    local.get 29
    local.tee 29
    local.set 26
    local.get 2
    local.get 3
    i32.const 1
    local.get 6
    local.get 7
    call $string____str_maxsuf
    local.set 27
    global.get $__fern_ret_word
    local.set 29
    local.get 29
    local.tee 29
    local.set 28
    local.get 27
    local.get 25
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 25
    i32.const 1
    i32.add
    local.get 26
    local.set 24
    local.set 23
    br 2
    end
    end
    local.get 27
    i32.const 1
    i32.add
    local.get 28
    local.set 24
    local.set 23
    end
    local.get 1
    local.get 3
    i32.sub
    local.set 8
    end
    i32.const 0
    local.set 22
    end
    loop
    block
    block
    block
    local.get 22
    local.get 23
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 24
    local.get 22
    i32.add
    local.set 29
    local.get 7
    local.get 29
    i32.mul
    local.set 29
    local.get 6
    local.get 29
    i32.add
    local.set 29
    local.get 2
    local.get 29
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 29
    local.get 7
    local.get 22
    i32.mul
    local.set 30
    local.get 6
    local.get 30
    i32.add
    local.set 30
    local.get 2
    local.get 30
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 30
    local.get 29
    local.get 30
    i32.ne
    br_if 4
    end
    end
    local.get 22
    i32.const 1
    i32.add
    local.set 22
    br 0
    end
    end
    i32.const 1
    local.set 9
    br 1
    end
    i32.const 0
    local.set 9
    end
    local.get 9
    i32.eqz
    br_if 4
    end
    local.get 4
    i32.const 0
    local.set 11
    local.set 10
    end
    local.get 3
    local.get 24
    i32.sub
    local.set 29
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 10
    local.get 8
    i32.le_s
    i32.eqz
    br_if 13
    end
    local.get 11
    local.get 23
    i32.gt_s
    i32.eqz
    br_if 1
    end
    local.get 11
    local.set 12
    br 1
    end
    local.get 23
    local.set 12
    end
    loop
    block
    block
    local.get 12
    local.get 3
    i32.lt_s
    i32.eqz
    br_if 3
    end
    local.get 7
    local.get 12
    i32.mul
    local.set 30
    local.get 6
    local.get 30
    i32.add
    local.set 30
    local.get 2
    local.get 30
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 30
    local.get 12
    local.get 10
    i32.add
    local.set 31
    local.get 7
    local.get 31
    i32.mul
    local.set 31
    local.get 5
    local.get 31
    i32.add
    local.set 31
    local.get 0
    local.get 31
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 31
    local.get 30
    local.get 31
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 12
    i32.const 1
    i32.add
    local.set 12
    br 0
    end
    end
    local.get 12
    local.get 3
    i32.ge_s
    i32.eqz
    br_if 5
    end
    local.get 23
    i32.const 1
    i32.sub
    local.set 13
    end
    loop
    block
    block
    local.get 13
    local.get 11
    i32.ge_s
    i32.eqz
    br_if 3
    end
    local.get 7
    local.get 13
    i32.mul
    local.set 30
    local.get 6
    local.get 30
    i32.add
    local.set 30
    local.get 2
    local.get 30
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 30
    local.get 13
    local.get 10
    i32.add
    local.set 31
    local.get 7
    local.get 31
    i32.mul
    local.set 31
    local.get 5
    local.get 31
    i32.add
    local.set 31
    local.get 0
    local.get 31
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 31
    local.get 30
    local.get 31
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 13
    i32.const 1
    i32.sub
    local.set 13
    br 0
    end
    end
    local.get 13
    local.get 11
    i32.lt_s
    br_if 6
    end
    end
    local.get 10
    local.get 24
    i32.add
    local.set 30
    local.get 30
    local.get 29
    local.set 15
    local.set 14
    br 1
    end
    local.get 12
    local.get 23
    i32.sub
    local.set 30
    local.get 10
    local.get 30
    i32.add
    local.set 30
    local.get 30
    i32.const 1
    i32.add
    local.set 30
    local.get 30
    i32.const 0
    local.set 15
    local.set 14
    end
    local.get 14
    local.get 15
    local.set 11
    local.set 10
    br 0
    end
    end
    i32.const -1
    return
    end
    local.get 10
    return
    end
    end
    local.get 3
    local.get 23
    i32.sub
    local.get 23
    i32.gt_s
    i32.eqz
    br_if 1
    end
    local.get 3
    local.get 23
    i32.sub
    local.set 16
    br 1
    end
    local.get 23
    local.set 16
    end
    local.get 16
    i32.const 1
    i32.add
    local.set 17
    local.get 4
    local.set 18
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 18
    local.get 8
    i32.le_s
    i32.eqz
    br_if 11
    end
    local.get 23
    local.set 19
    end
    loop
    block
    block
    local.get 19
    local.get 3
    i32.lt_s
    i32.eqz
    br_if 3
    end
    local.get 7
    local.get 19
    i32.mul
    local.set 29
    local.get 6
    local.get 29
    i32.add
    local.set 29
    local.get 2
    local.get 29
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 29
    local.get 19
    local.get 18
    i32.add
    local.set 30
    local.get 7
    local.get 30
    i32.mul
    local.set 30
    local.get 5
    local.get 30
    i32.add
    local.set 30
    local.get 0
    local.get 30
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 30
    local.get 29
    local.get 30
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 19
    i32.const 1
    i32.add
    local.set 19
    br 0
    end
    end
    local.get 19
    local.get 3
    i32.ge_s
    i32.eqz
    br_if 5
    end
    local.get 23
    i32.const 1
    i32.sub
    local.set 20
    end
    loop
    block
    block
    local.get 20
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 3
    end
    local.get 7
    local.get 20
    i32.mul
    local.set 29
    local.get 6
    local.get 29
    i32.add
    local.set 29
    local.get 2
    local.get 29
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 29
    local.get 20
    local.get 18
    i32.add
    local.set 30
    local.get 7
    local.get 30
    i32.mul
    local.set 30
    local.get 5
    local.get 30
    i32.add
    local.set 30
    local.get 0
    local.get 30
    local.set 36
    local.tee 32
    i32.load
    local.get 36
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 32
    local.get 36
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 30
    local.get 29
    local.get 30
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 20
    i32.const 1
    i32.sub
    local.set 20
    br 0
    end
    end
    local.get 20
    i32.const 0
    i32.lt_s
    br_if 6
    end
    end
    local.get 18
    local.get 17
    i32.add
    local.set 21
    br 1
    end
    local.get 19
    local.get 23
    i32.sub
    local.set 29
    local.get 18
    local.get 29
    i32.add
    local.set 29
    local.get 29
    i32.const 1
    i32.add
    local.set 21
    end
    local.get 21
    local.set 18
    br 0
    end
    end
    i32.const -1
    return
    end
    local.get 18
    return
    i32.const 0)
  (func $string____str_find_from (param i32) (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 4
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 5
    br 1
    end
    local.get 4
    local.set 5
    end
    local.get 3
    i32.const 0
    i32.eq
    i32.eqz
    br_if 3
    end
    local.get 5
    local.get 1
    i32.gt_s
    i32.eqz
    br_if 1
    end
    local.get 1
    return
    end
    local.get 5
    return
    end
    end
    local.get 1
    local.get 5
    i32.sub
    local.set 9
    local.get 3
    local.get 9
    i32.gt_s
    i32.eqz
    br_if 1
    end
    i32.const -1
    return
    end
    end
    local.get 3
    i32.const 1
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 2
    i32.const 0
    local.set 16
    local.tee 12
    i32.load
    local.get 16
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 12
    local.get 16
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 9
    local.get 0
    local.get 9
    local.get 5
    call $__fern_memchr
    return
    end
    end
    local.get 3
    i32.const 4
    i32.le_s
    i32.eqz
    br_if 3
    end
    local.get 5
    local.set 7
    end
    local.get 1
    local.get 3
    i32.sub
    local.set 9
    loop
    block
    block
    block
    block
    block
    local.get 7
    local.get 9
    i32.le_s
    i32.eqz
    br_if 6
    end
    i32.const 0
    local.set 8
    end
    loop
    block
    block
    local.get 8
    local.get 3
    i32.lt_s
    i32.eqz
    br_if 3
    end
    local.get 7
    local.get 8
    i32.add
    local.set 10
    local.get 0
    local.get 10
    local.set 16
    local.tee 12
    i32.load
    local.get 16
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 12
    local.get 16
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 10
    local.get 2
    local.get 8
    local.set 16
    local.tee 12
    i32.load
    local.get 16
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 12
    local.get 16
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 11
    local.get 10
    local.get 11
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 8
    i32.const 1
    i32.add
    local.set 8
    br 0
    end
    end
    local.get 8
    local.get 3
    i32.eq
    br_if 6
    end
    end
    local.get 7
    i32.const 1
    i32.add
    local.set 7
    br 0
    end
    end
    i32.const -1
    local.set 6
    br 3
    end
    end
    local.get 0
    local.get 1
    local.get 2
    local.get 3
    local.get 5
    i32.const 0
    i32.const 0
    i32.const 1
    call $string____str_two_way
    return
    end
    local.get 7
    local.set 6
    end
    local.get 6
    return
    i32.const 0)
  (func $string.split (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.load
    local.set 2
    local.get 1
    i32.load
    local.set 3
    global.get $__cagg_base
    i32.const 8
    i32.add
    local.set 4
    local.get 3
    i32.const 0
    i32.eq
    i32.eqz
    br_if 4
    end
    end
    local.get 0
    i32.load
    local.set 8
    global.get $__cagg_base
    i32.const 8
    i32.add
    local.set 11
    local.get 11
    i32.const 0
    local.set 10
    local.set 9
    end
    loop
    block
    local.get 10
    local.get 8
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 0
    local.get 10
    local.get 8
    call $utf8_scalar__step
    local.set 11
    local.get 10
    local.get 11
    i32.add
    local.set 12
    local.get 0
    local.get 10
    local.get 12
    call $__fern_substr
    local.set 12
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 13
    local.get 12
    local.get 13
    call $__fern_strcat
    local.set 13
    local.get 12
    call $__fern_arr_dec
    drop
    local.get 9
    local.get 13
    call $__fern_arr_push_owned
    local.set 12
    local.get 10
    local.get 11
    i32.add
    local.set 11
    local.get 12
    local.get 11
    local.set 10
    local.set 9
    br 0
    end
    end
    local.get 9
    return
    end
    end
    local.get 0
    local.get 2
    local.get 1
    local.get 3
    i32.const 0
    call $string____str_find_from
    local.set 11
    local.get 4
    i32.const 0
    local.get 11
    local.set 7
    local.set 6
    local.set 5
    end
    loop
    block
    local.get 7
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 2
    end
    local.get 0
    local.get 6
    local.get 7
    call $__fern_substr
    local.set 11
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 12
    local.get 11
    local.get 12
    call $__fern_strcat
    local.set 12
    local.get 11
    call $__fern_arr_dec
    drop
    local.get 5
    local.get 12
    call $__fern_arr_push_owned
    local.set 11
    local.get 7
    local.get 3
    i32.add
    local.set 12
    local.get 0
    local.get 2
    local.get 1
    local.get 3
    local.get 12
    call $string____str_find_from
    local.set 13
    local.get 11
    local.get 12
    local.get 13
    local.set 7
    local.set 6
    local.set 5
    br 0
    end
    end
    local.get 0
    local.get 6
    local.get 2
    call $__fern_substr
    local.set 11
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 12
    local.get 11
    local.get 12
    call $__fern_strcat
    local.set 12
    local.get 11
    call $__fern_arr_dec
    drop
    local.get 5
    local.get 12
    call $__fern_arr_push_owned
    return
    i32.const 0)
  (func $string.eq_ignore_ascii_case (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.load
    local.set 2
    local.get 1
    i32.load
    local.set 6
    local.get 2
    local.get 6
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 0
    return
    end
    end
    i32.const 0
    local.set 3
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 3
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 0
    i32.const 4
    i32.add
    local.get 3
    i32.add
    i32.load8_u
    local.set 4
    local.get 1
    local.get 3
    local.set 11
    local.tee 7
    i32.load
    local.get 11
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 7
    local.get 11
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 6
    local.get 4
    local.get 6
    i32.xor
    local.set 5
    local.get 5
    i32.const 0
    i32.ne
    i32.eqz
    br_if 3
    end
    local.get 5
    i32.const 32
    i32.ne
    br_if 6
    end
    local.get 4
    i32.const 32
    i32.or
    local.set 6
    local.get 6
    i32.const 97
    i32.lt_s
    br_if 5
    end
    local.get 4
    i32.const 32
    i32.or
    local.set 6
    local.get 6
    i32.const 122
    i32.gt_s
    br_if 4
    end
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 3
    br 0
    end
    end
    i32.const 1
    return
    end
    i32.const 0
    return
    i32.const 0)
  (func $io_buffered__BufBlock.drop (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 8
    i32.add
    i32.load
    call $__fern_buf_free
    i32.const 0
    drop
    i32.const 0
    return
    i32.const 0)
  (func $json__JsonError.eq (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.set 5
    local.get 1
    i32.const 8
    i32.add
    i32.load
    local.set 6
    local.get 5
    local.get 6
    call $__fern_streq
    i32.eqz
    br_if 1
    end
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.set 5
    local.get 1
    i32.const 16
    i32.add
    i32.load
    local.set 6
    local.get 5
    local.get 6
    i32.eq
    local.set 2
    br 1
    end
    i32.const 0
    local.set 2
    end
    local.get 2
    i32.eqz
    br_if 1
    end
    local.get 0
    i32.const 24
    i32.add
    i32.load
    local.set 5
    local.get 1
    i32.const 24
    i32.add
    i32.load
    local.set 6
    local.get 5
    local.get 6
    i32.eq
    local.set 3
    br 1
    end
    i32.const 0
    local.set 3
    end
    local.get 3
    i32.eqz
    br_if 1
    end
    local.get 0
    i32.const 32
    i32.add
    i32.load
    local.set 5
    local.get 1
    i32.const 32
    i32.add
    i32.load
    local.set 6
    local.get 5
    local.get 6
    i32.eq
    local.set 4
    br 1
    end
    i32.const 0
    local.set 4
    end
    local.get 4
    return
    i32.const 0)
  (func $utf8__is_valid (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    end
    local.get 0
    i32.load
    local.set 2
    i32.const 0
    local.set 3
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 3
    local.get 2
    i32.lt_s
    i32.eqz
    br_if 49
    end
    local.get 0
    local.get 3
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 4
    local.get 4
    i32.const 128
    i32.lt_s
    i32.eqz
    br_if 3
    end
    local.get 0
    local.get 3
    call $__fern_ascii_run
    local.tee 5
    local.get 2
    i32.ge_s
    br_if 48
    end
    end
    local.get 0
    local.get 5
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 17
    local.get 5
    local.get 17
    local.set 7
    local.set 6
    br 1
    end
    local.get 3
    local.get 4
    local.set 7
    local.set 6
    end
    local.get 7
    i32.const 192
    i32.lt_s
    br_if 45
    end
    local.get 7
    i32.const 224
    i32.lt_s
    i32.eqz
    br_if 8
    end
    local.get 6
    i32.const 1
    i32.add
    local.get 2
    i32.ge_s
    br_if 44
    end
    end
    local.get 6
    i32.const 1
    i32.add
    local.set 17
    local.get 0
    local.get 17
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 8
    local.get 8
    i32.const 128
    i32.lt_s
    br_if 43
    end
    local.get 8
    i32.const 192
    i32.ge_s
    br_if 42
    end
    end
    local.get 7
    i32.const 192
    i32.sub
    local.set 17
    local.get 17
    i32.const 6
    i32.shl
    local.set 17
    local.get 8
    i32.const 128
    i32.sub
    local.set 18
    local.get 17
    local.get 18
    i32.or
    local.set 17
    local.get 17
    i32.const 128
    i32.lt_s
    br_if 41
    end
    end
    local.get 6
    i32.const 2
    i32.add
    local.set 16
    br 32
    end
    local.get 7
    i32.const 240
    i32.lt_s
    i32.eqz
    br_if 14
    end
    local.get 6
    i32.const 2
    i32.add
    local.get 2
    i32.ge_s
    br_if 38
    end
    end
    local.get 6
    i32.const 1
    i32.add
    local.set 17
    local.get 6
    i32.const 1
    i32.add
    local.set 18
    local.get 18
    i32.const 1
    i32.add
    local.set 19
    local.get 18
    i32.const 31
    i32.shr_s
    local.set 18
    local.get 19
    local.get 18
    i32.or
    local.set 18
    local.get 0
    local.get 18
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    i32.const 0
    drop
    local.get 0
    i32.const 4
    i32.add
    local.get 17
    i32.add
    i32.load8_u
    local.set 9
    local.get 6
    i32.const 2
    i32.add
    local.set 17
    local.get 0
    i32.const 4
    i32.add
    local.get 17
    i32.add
    i32.load8_u
    local.set 10
    local.get 9
    i32.const 128
    i32.lt_s
    br_if 37
    end
    local.get 9
    i32.const 192
    i32.ge_s
    br_if 36
    end
    end
    local.get 10
    i32.const 128
    i32.lt_s
    br_if 35
    end
    local.get 10
    i32.const 192
    i32.ge_s
    br_if 34
    end
    end
    local.get 7
    i32.const 224
    i32.sub
    local.set 17
    local.get 17
    i32.const 12
    i32.shl
    local.set 17
    local.get 9
    i32.const 128
    i32.sub
    local.set 18
    local.get 18
    i32.const 6
    i32.shl
    local.set 18
    local.get 17
    local.get 18
    i32.or
    local.set 17
    local.get 10
    i32.const 128
    i32.sub
    local.set 18
    local.get 17
    local.get 18
    i32.or
    local.set 11
    local.get 11
    i32.const 2048
    i32.lt_s
    br_if 33
    end
    end
    local.get 11
    i32.const 55296
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 11
    i32.const 57343
    i32.le_s
    br_if 31
    end
    end
    local.get 6
    i32.const 3
    i32.add
    local.set 16
    br 17
    end
    local.get 7
    i32.const 248
    i32.lt_s
    i32.eqz
    br_if 35
    end
    local.get 6
    i32.const 3
    i32.add
    local.get 2
    i32.ge_s
    br_if 28
    end
    end
    local.get 6
    i32.const 1
    i32.add
    local.set 17
    local.get 6
    i32.const 1
    i32.add
    local.set 18
    local.get 18
    i32.const 2
    i32.add
    local.set 19
    local.get 18
    i32.const 31
    i32.shr_s
    local.set 18
    local.get 19
    local.get 18
    i32.or
    local.set 18
    local.get 0
    local.get 18
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    i32.const 0
    drop
    local.get 0
    i32.const 4
    i32.add
    local.get 17
    i32.add
    i32.load8_u
    local.set 12
    local.get 6
    i32.const 2
    i32.add
    local.set 17
    local.get 0
    i32.const 4
    i32.add
    local.get 17
    i32.add
    i32.load8_u
    local.set 13
    local.get 6
    i32.const 3
    i32.add
    local.set 17
    local.get 0
    i32.const 4
    i32.add
    local.get 17
    i32.add
    i32.load8_u
    local.set 14
    local.get 12
    i32.const 128
    i32.lt_s
    br_if 27
    end
    local.get 12
    i32.const 192
    i32.ge_s
    br_if 26
    end
    end
    local.get 13
    i32.const 128
    i32.lt_s
    br_if 25
    end
    local.get 13
    i32.const 192
    i32.ge_s
    br_if 24
    end
    end
    local.get 14
    i32.const 128
    i32.lt_s
    br_if 23
    end
    local.get 14
    i32.const 192
    i32.ge_s
    br_if 22
    end
    end
    local.get 7
    i32.const 240
    i32.sub
    local.set 17
    local.get 17
    i32.const 18
    i32.shl
    local.set 17
    local.get 12
    i32.const 128
    i32.sub
    local.set 18
    local.get 18
    i32.const 12
    i32.shl
    local.set 18
    local.get 17
    local.get 18
    i32.or
    local.set 17
    local.get 13
    i32.const 128
    i32.sub
    local.set 18
    local.get 18
    i32.const 6
    i32.shl
    local.set 18
    local.get 17
    local.get 18
    i32.or
    local.set 17
    local.get 14
    i32.const 128
    i32.sub
    local.set 18
    local.get 17
    local.get 18
    i32.or
    local.set 15
    local.get 15
    i32.const 65536
    i32.lt_s
    br_if 21
    end
    end
    local.get 15
    i32.const 1114111
    i32.gt_s
    br_if 20
    end
    end
    local.get 6
    i32.const 4
    i32.add
    local.set 16
    end
    local.get 16
    local.set 3
    br 0
    end
    end
    local.get 2
    local.set 1
    br 17
    end
    local.get 2
    local.set 1
    br 16
    end
    local.get 6
    local.set 1
    br 15
    end
    local.get 6
    local.set 1
    br 14
    end
    local.get 6
    local.set 1
    br 13
    end
    local.get 6
    local.set 1
    br 12
    end
    local.get 6
    local.set 1
    br 11
    end
    local.get 6
    local.set 1
    br 10
    end
    local.get 6
    local.set 1
    br 9
    end
    local.get 6
    local.set 1
    br 8
    end
    local.get 6
    local.set 1
    br 7
    end
    local.get 6
    local.set 1
    br 6
    end
    local.get 6
    local.set 1
    br 5
    end
    local.get 6
    local.set 1
    br 4
    end
    local.get 6
    local.set 1
    br 3
    end
    local.get 6
    local.set 1
    br 2
    end
    local.get 6
    local.set 1
    br 1
    end
    local.get 6
    local.set 1
    end
    local.get 0
    i32.load
    local.set 17
    local.get 1
    local.get 17
    i32.eq
    return
    i32.const 0)
  (func $__primitive_i32_to_string (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $int__int_to_string
    return
    i32.const 0)
  (func $__primitive_i64_to_string (param i64) (result i32)
    (local i64 i32 i32 f64 i64 i32)
    block
    block
    block
    local.get 0
    i64.const 0
    i64.lt_s
    i32.eqz
    br_if 1
    end
    i64.const 0
    local.get 0
    i64.sub
    local.set 1
    local.get 1
    i32.const 1
    call $int____int_to_string_u64
    return
    end
    end
    local.get 0
    i32.const 0
    call $int____int_to_string_u64
    return
    i32.const 0)
  (func $int__int_to_string (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 2
    end
    local.get 0
    i32.const 100
    i32.lt_s
    i32.eqz
    br_if 1
    end
    global.get $__cagg_base
    i32.const 1016
    i32.add
    local.get 0
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 15
    call $__fern_rc_inc
    drop
    local.get 15
    return
    end
    end
    i32.const 0
    local.set 1
    local.get 0
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.get 0
    i32.sub
    i32.const 1
    local.set 3
    local.set 2
    br 1
    end
    local.get 0
    local.get 1
    local.set 3
    local.set 2
    end
    local.get 2
    local.set 4
    end
    local.get 4
    i32.const 10
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 5
    br 26
    end
    end
    local.get 4
    i32.const 100
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 2
    local.set 5
    br 23
    end
    end
    local.get 4
    i32.const 1000
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 3
    local.set 5
    br 20
    end
    end
    local.get 4
    i32.const 10000
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 4
    local.set 5
    br 17
    end
    end
    local.get 4
    i32.const 100000
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 5
    local.set 5
    br 14
    end
    end
    local.get 4
    i32.const 1000000
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 6
    local.set 5
    br 11
    end
    end
    local.get 4
    i32.const 10000000
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 7
    local.set 5
    br 8
    end
    end
    local.get 4
    i32.const 100000000
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 8
    local.set 5
    br 5
    end
    end
    local.get 4
    i32.const 1000000000
    i32.lt_u
    i32.eqz
    br_if 1
    end
    i32.const 9
    local.set 5
    br 2
    end
    end
    i32.const 10
    local.set 5
    end
    local.get 3
    i32.eqz
    br_if 1
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 6
    br 1
    end
    local.get 5
    local.set 6
    end
    local.get 6
    local.set 21
    local.get 21
    i32.eqz
    if (result i32)
    global.get $__cagg_base
    i32.const 328
    i32.add
    else
    local.get 21
    i32.const 1
    call $__fern_arr_elems
    local.set 20
    local.get 20
    local.get 21
    i32.store
    local.get 20
    i32.const 4
    i32.add
    local.get 21
    i32.store
    local.get 20
    i32.const 8
    i32.add
    i32.const 0
    local.get 21
    memory.fill
    local.get 20
    end
    local.set 15
    global.get $__str_base
    i32.const 2116
    i32.add
    local.set 13
    local.get 4
    local.get 15
    local.get 6
    local.set 9
    local.set 8
    local.set 7
    end
    loop
    block
    local.get 7
    i32.const 100
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 7
    i32.const 100
    call $__fern_udiv
    local.tee 15
    i32.const 100
    i32.mul
    local.set 16
    local.get 7
    local.get 16
    i32.sub
    local.set 16
    local.get 15
    local.set 15
    local.get 9
    i32.const 2
    i32.sub
    local.set 17
    local.get 16
    i32.const 1
    i32.shl
    local.set 18
    local.get 13
    local.get 18
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 18
    local.get 8
    local.tee 14
    local.get 17
    local.get 18
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 14
    local.set 18
    local.get 17
    i32.const 1
    i32.add
    local.set 19
    local.get 16
    i32.const 1
    i32.shl
    local.set 16
    local.get 16
    i32.const 1
    i32.add
    local.set 16
    local.get 13
    local.get 16
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 16
    local.get 18
    local.tee 14
    local.get 19
    local.get 16
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 14
    local.set 16
    local.get 15
    local.get 16
    local.get 17
    local.set 9
    local.set 8
    local.set 7
    br 0
    end
    end
    local.get 7
    local.set 10
    local.get 7
    i32.const 10
    i32.ge_u
    i32.eqz
    br_if 1
    end
    local.get 9
    i32.const 2
    i32.sub
    local.set 15
    local.get 10
    i32.const 1
    i32.shl
    local.set 16
    local.get 13
    local.get 16
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 16
    local.get 8
    local.tee 14
    local.get 15
    local.get 16
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 14
    local.set 16
    local.get 15
    i32.const 1
    i32.add
    local.set 15
    local.get 10
    i32.const 1
    i32.shl
    local.set 17
    local.get 17
    i32.const 1
    i32.add
    local.set 17
    local.get 13
    local.get 17
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 17
    local.get 16
    local.tee 14
    local.get 15
    local.get 17
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 14
    local.set 11
    br 1
    end
    local.get 9
    i32.const 1
    i32.sub
    local.set 15
    local.get 10
    i32.const 48
    i32.add
    i32.const 255
    i32.and
    local.set 16
    local.get 8
    local.tee 14
    local.get 15
    local.get 16
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 14
    local.set 11
    end
    local.get 3
    i32.eqz
    br_if 1
    end
    local.get 11
    local.tee 14
    i32.const 0
    i32.const 45
    local.set 21
    local.set 24
    local.tee 20
    i32.load
    local.get 24
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 20
    local.get 24
    i32.const 8
    i32.add
    i32.add
    local.get 21
    i32.store8
    local.get 14
    local.set 12
    br 1
    end
    local.get 11
    local.set 12
    end
    local.get 12
    call $__fern_string_from_bytes
    local.set 15
    local.get 12
    call $__fern_arr_dec
    drop
    local.get 15
    return
    i32.const 0)
  (func $int____int_to_string_u64 (param i64) (param i32) (result i32)
    (local i64 i32 i64 i32 i32 i64 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    local.set 2
    i32.const 1
    local.get 2
    local.set 4
    local.set 3
    end
    loop
    block
    local.get 4
    i64.const 100
    i64.ge_u
    i32.eqz
    br_if 2
    end
    local.get 3
    i32.const 2
    i32.add
    local.set 15
    local.get 4
    i64.const 100
    call $__fern_udiv64
    local.set 16
    local.get 15
    local.get 16
    local.set 4
    local.set 3
    br 0
    end
    end
    local.get 4
    i64.const 10
    i64.ge_u
    i32.eqz
    br_if 1
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 5
    br 1
    end
    local.get 3
    local.set 5
    end
    local.get 1
    i32.const 0
    i32.ne
    i32.eqz
    br_if 1
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 6
    br 1
    end
    local.get 5
    local.set 6
    end
    local.get 6
    local.set 22
    local.get 22
    i32.eqz
    if (result i32)
    global.get $__cagg_base
    i32.const 328
    i32.add
    else
    local.get 22
    i32.const 1
    call $__fern_arr_elems
    local.set 21
    local.get 21
    local.get 22
    i32.store
    local.get 21
    i32.const 4
    i32.add
    local.get 22
    i32.store
    local.get 21
    i32.const 8
    i32.add
    i32.const 0
    local.get 22
    memory.fill
    local.get 21
    end
    local.set 15
    global.get $__str_base
    i32.const 2116
    i32.add
    local.set 13
    local.get 2
    local.get 15
    local.get 6
    local.set 9
    local.set 8
    local.set 7
    end
    loop
    block
    local.get 7
    i64.const 100
    i64.ge_u
    i32.eqz
    br_if 2
    end
    local.get 7
    i64.const 100
    call $__fern_udiv64
    local.tee 16
    i64.const 100
    i64.mul
    local.set 17
    local.get 7
    local.get 17
    i64.sub
    i32.wrap_i64
    local.set 15
    local.get 16
    local.set 16
    local.get 9
    i32.const 2
    i32.sub
    local.set 18
    local.get 15
    i32.const 1
    i32.shl
    local.set 19
    local.get 13
    local.get 19
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 19
    local.get 8
    local.tee 14
    local.get 18
    local.get 19
    local.set 22
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 8
    i32.add
    i32.add
    local.get 22
    i32.store8
    local.get 14
    local.set 19
    local.get 18
    i32.const 1
    i32.add
    local.set 20
    local.get 15
    i32.const 1
    i32.shl
    local.set 15
    local.get 15
    i32.const 1
    i32.add
    local.set 15
    local.get 13
    local.get 15
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 15
    local.get 19
    local.tee 14
    local.get 20
    local.get 15
    local.set 22
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 8
    i32.add
    i32.add
    local.get 22
    i32.store8
    local.get 14
    local.set 15
    local.get 16
    local.get 15
    local.get 18
    local.set 9
    local.set 8
    local.set 7
    br 0
    end
    end
    local.get 7
    i32.wrap_i64
    local.set 10
    local.get 7
    i64.const 10
    i64.ge_u
    i32.eqz
    br_if 1
    end
    local.get 9
    i32.const 2
    i32.sub
    local.set 15
    local.get 10
    i32.const 1
    i32.shl
    local.set 18
    local.get 13
    local.get 18
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 18
    local.get 8
    local.tee 14
    local.get 15
    local.get 18
    local.set 22
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 8
    i32.add
    i32.add
    local.get 22
    i32.store8
    local.get 14
    local.set 18
    local.get 15
    i32.const 1
    i32.add
    local.set 15
    local.get 10
    i32.const 1
    i32.shl
    local.set 19
    local.get 19
    i32.const 1
    i32.add
    local.set 19
    local.get 13
    local.get 19
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 19
    local.get 18
    local.tee 14
    local.get 15
    local.get 19
    local.set 22
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 8
    i32.add
    i32.add
    local.get 22
    i32.store8
    local.get 14
    local.set 11
    br 1
    end
    local.get 9
    i32.const 1
    i32.sub
    local.set 15
    local.get 10
    i32.const 48
    i32.add
    i32.const 255
    i32.and
    local.set 18
    local.get 8
    local.tee 14
    local.get 15
    local.get 18
    local.set 22
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 8
    i32.add
    i32.add
    local.get 22
    i32.store8
    local.get 14
    local.set 11
    end
    local.get 1
    i32.const 0
    i32.ne
    i32.eqz
    br_if 1
    end
    local.get 11
    local.tee 14
    i32.const 0
    i32.const 45
    local.set 22
    local.set 25
    local.tee 21
    i32.load
    local.get 25
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 21
    local.get 25
    i32.const 8
    i32.add
    i32.add
    local.get 22
    i32.store8
    local.get 14
    local.set 12
    br 1
    end
    local.get 11
    local.set 12
    end
    local.get 12
    call $__fern_string_from_bytes
    local.set 15
    local.get 12
    call $__fern_arr_dec
    drop
    local.get 15
    return
    i32.const 0)
  (func $utf8_scalar__step (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    local.get 1
    local.set 16
    local.tee 12
    i32.load
    local.get 16
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 12
    local.get 16
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 3
    end
    local.get 3
    i32.const 128
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 4
    br 14
    end
    end
    local.get 3
    i32.const 194
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 4
    br 11
    end
    end
    local.get 3
    i32.const 224
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 2
    local.set 4
    br 8
    end
    end
    local.get 3
    i32.const 240
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 3
    local.set 4
    br 5
    end
    end
    local.get 3
    i32.const 245
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 4
    local.set 4
    br 2
    end
    end
    i32.const 0
    local.set 4
    end
    local.get 4
    i32.const 1
    i32.le_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    local.get 1
    i32.const 1
    i32.add
    local.get 2
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    local.get 1
    i32.const 1
    i32.add
    local.set 11
    local.get 0
    local.get 11
    local.set 16
    local.tee 12
    i32.load
    local.get 16
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 12
    local.get 16
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 5
    end
    local.get 3
    i32.const 224
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 160
    local.set 6
    br 5
    end
    end
    local.get 3
    i32.const 240
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 144
    local.set 6
    br 2
    end
    end
    i32.const 128
    local.set 6
    end
    local.get 5
    local.get 6
    i32.lt_s
    br_if 9
    end
    end
    local.get 3
    i32.const 237
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 159
    local.set 7
    br 5
    end
    end
    local.get 3
    i32.const 244
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 143
    local.set 7
    br 2
    end
    end
    i32.const 191
    local.set 7
    end
    local.get 5
    local.get 7
    i32.gt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 2
    local.set 8
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 8
    local.get 4
    i32.lt_s
    i32.eqz
    br_if 10
    end
    local.get 1
    local.get 8
    i32.add
    local.get 2
    i32.ge_s
    br_if 10
    end
    end
    local.get 1
    local.get 8
    i32.add
    local.set 11
    local.get 0
    local.get 11
    local.set 16
    local.tee 12
    i32.load
    local.get 16
    i32.le_u
    if
      call $__fern_abort_str
      unreachable
    end
    local.get 12
    local.get 16
    i32.const 4
    i32.add
    i32.add
    i32.load8_u
    local.set 9
    end
    local.get 9
    i32.const 128
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 9
    i32.const 192
    i32.lt_s
    local.set 10
    br 1
    end
    i32.const 0
    local.set 10
    end
    local.get 10
    i32.eqz
    br_if 5
    end
    end
    local.get 8
    i32.const 1
    i32.add
    local.set 8
    br 0
    end
    end
    local.get 4
    return
    end
    local.get 8
    return
    end
    local.get 8
    return
    i32.const 0)
  (func $deflate____ReadPhase.eq (param i32) (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadHeader
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 1
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadHeader
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    end
    local.get 0
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadStored
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 1
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadStored
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    end
    local.get 0
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadCodes
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 1
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadCodes
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    end
    local.get 0
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadCopy
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 1
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadCopy
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    end
    end
    local.get 1
    i32.load
    global.get $__tid$deflate____ReadPhase$deflate__ReadEnd
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    i32.const 0)
  (func $codec__DecodeErrorKind.eq (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidByte
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.set 2
    local.get 1
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidByte
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 1
    i32.const 8
    i32.add
    i32.load
    local.set 3
    local.get 2
    local.get 3
    i32.eq
    return
    end
    end
    i32.const 0
    return
    end
    local.get 0
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidLength
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 1
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidLength
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    end
    local.get 0
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidPadding
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 1
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidPadding
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    end
    end
    local.get 1
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__NonZeroTrailingBits
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 0
    return
    i32.const 0)
  (func $codec__DecodeError.eq (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.set 7
    local.get 1
    i32.const 8
    i32.add
    i32.load
    local.set 8
    local.get 7
    local.get 8
    call $__fern_streq
    i32.eqz
    br_if 1
    end
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.set 7
    local.get 1
    i32.const 16
    i32.add
    i32.load
    local.set 8
    local.get 7
    local.get 8
    i32.eq
    local.set 2
    br 1
    end
    i32.const 0
    local.set 2
    end
    local.get 2
    i32.eqz
    br_if 4
    end
    local.get 0
    i32.const 24
    i32.add
    i32.load
    local.set 3
    local.get 1
    i32.const 24
    i32.add
    i32.load
    local.set 4
    end
    local.get 3
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidByte
    i32.eq
    i32.eqz
    br_if 5
    end
    local.get 3
    i32.const 8
    i32.add
    i32.load
    local.set 6
    local.get 4
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidByte
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 4
    i32.const 8
    i32.add
    i32.load
    local.set 7
    local.get 6
    local.get 7
    i32.eq
    local.set 5
    br 18
    end
    i32.const 0
    local.set 5
    br 17
    end
    end
    i32.const 0
    local.set 5
    br 15
    end
    local.get 3
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidLength
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 4
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidLength
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 5
    br 12
    end
    end
    i32.const 0
    local.set 5
    br 10
    end
    local.get 3
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidPadding
    i32.eq
    i32.eqz
    br_if 4
    end
    local.get 4
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__InvalidPadding
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 5
    br 7
    end
    end
    i32.const 0
    local.set 5
    br 5
    end
    end
    local.get 4
    i32.load
    global.get $__tid$codec__DecodeErrorKind$codec__NonZeroTrailingBits
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 5
    br 2
    end
    end
    i32.const 0
    local.set 5
    end
    local.get 5
    return
    i32.const 0)
  (func $main (result i32)
    (local i32 i64 i32 i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    global.get $__str_base
    i32.const 2320
    i32.add
    local.set 0
    i64.const 0
    i32.const 0
    local.set 2
    local.set 1
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 2
    i32.const 4000
    i32.lt_s
    i32.eqz
    br_if 355
    end
    end
    local.get 0
    call $__fern_str_bytes
    local.set 26
    end
    i32.const 0
    local.set 200
    i32.const 1
    local.set 201
    i32.const 0
    local.set 202
    end
    i32.const 1
    local.set 197
    i32.const 0
    local.set 198
    i32.const 0
    local.set 199
    i32.const 8192
    local.set 28
    i32.const 32768
    local.set 29
    i32.const 100
    local.set 30
    i32.const 1048576
    local.set 31
    i32.const 0
    local.set 27
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 32
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 33
    global.get $__cagg_base
    i32.const 328
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    local.set 34
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    end
    end
    local.get 26
    i32.load
    local.set 279
    i32.const 1
    local.get 279
    i32.lt_s
    i32.eqz
    br_if 3
    end
    local.get 26
    i32.const 0
    local.set 288
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 13
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 26
    i32.const 1
    local.set 288
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 2
    local.set 35
    br 1
    end
    local.get 27
    local.set 35
    end
    local.get 26
    i32.load
    local.set 279
    local.get 35
    local.get 279
    i32.ge_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    br 354
    else
    end
    end
    end
    end
    local.get 26
    i32.load
    local.set 53
    local.get 35
    local.get 28
    i32.add
    local.set 279
    local.get 279
    i32.const 2
    i32.add
    local.set 54
    local.get 35
    local.get 29
    i32.add
    local.set 279
    local.get 279
    i32.const 4
    i32.add
    local.tee 55
    local.get 53
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 55
    local.set 56
    br 1
    end
    local.get 53
    local.set 56
    end
    i32.const -1
    local.set 57
    i32.const -1
    local.set 58
    i32.const 0
    local.set 59
    i32.const 0
    local.set 60
    global.get $__cagg_base
    i32.const 1432
    i32.add
    local.set 279
    local.get 26
    local.get 35
    local.get 279
    call $__fern_scan_set_bytes
    local.set 61
    end
    local.get 61
    local.get 56
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const -1
    i32.const 0
    local.get 35
    i32.const 0
    local.get 35
    local.get 61
    i32.const 2
    local.set 68
    local.set 67
    local.set 66
    local.set 65
    local.set 64
    local.set 63
    local.set 62
    br 10
    end
    end
    local.get 26
    local.get 61
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.eq
    br_if 2
    end
    local.get 61
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    i32.load
    local.set 280
    local.get 279
    local.get 280
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 61
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.ne
    i32.eqz
    br_if 1
    end
    local.get 57
    local.get 59
    local.get 35
    local.get 60
    local.get 35
    local.get 61
    i32.const 1
    local.set 68
    local.set 67
    local.set 66
    local.set 65
    local.set 64
    local.set 63
    local.set 62
    br 5
    end
    end
    local.get 61
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    i32.load
    local.set 280
    local.get 279
    local.get 280
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 57
    local.get 59
    local.get 35
    local.get 60
    local.get 35
    local.get 61
    i32.const 2
    local.set 68
    local.set 67
    local.set 66
    local.set 65
    local.set 64
    local.set 63
    local.set 62
    br 2
    end
    end
    local.get 57
    local.get 59
    local.get 35
    local.get 60
    local.get 35
    local.get 61
    i32.const 0
    local.set 68
    local.set 67
    local.set 66
    local.set 65
    local.set 64
    local.set 63
    local.set 62
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 68
    i32.const 2
    i32.ne
    if
    else
    local.get 62
    local.get 58
    local.set 81
    local.set 80
    br 32
    end
    end
    local.get 68
    i32.const 1
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 67
    i32.const 1
    i32.add
    local.set 279
    local.get 62
    i32.const 1
    local.get 279
    i32.const 0
    local.get 279
    local.set 77
    local.set 76
    local.set 75
    local.set 74
    local.set 73
    br 10
    end
    local.get 62
    i32.const -1
    i32.eq
    i32.eqz
    br_if 3
    end
    local.get 67
    i32.const 1
    i32.add
    local.set 69
    end
    local.get 69
    local.get 54
    i32.ge_s
    i32.eqz
    br_if 2
    end
    i32.const -2
    local.set 70
    br 2
    end
    local.get 62
    local.set 70
    br 1
    end
    local.get 67
    local.set 70
    end
    local.get 67
    local.get 64
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 65
    br_if 17
    end
    end
    local.get 67
    i32.const 2
    i32.add
    local.set 279
    local.get 70
    local.get 63
    local.get 279
    i32.const 1
    local.get 279
    local.set 77
    local.set 76
    local.set 75
    local.set 74
    local.set 73
    end
    global.get $__cagg_base
    i32.const 1432
    i32.add
    local.set 279
    local.get 26
    local.get 77
    local.get 279
    call $__fern_scan_set_bytes
    local.set 78
    end
    local.get 78
    local.get 56
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const 2
    local.set 79
    br 10
    end
    end
    local.get 26
    local.get 78
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.eq
    br_if 2
    end
    local.get 78
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    i32.load
    local.set 280
    local.get 279
    local.get 280
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 78
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 79
    br 5
    end
    end
    local.get 78
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    i32.load
    local.set 280
    local.get 279
    local.get 280
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const 2
    local.set 79
    br 2
    end
    end
    i32.const 0
    local.set 79
    end
    local.get 73
    local.get 74
    local.get 75
    local.get 76
    local.get 77
    local.get 78
    local.get 79
    local.set 68
    local.set 67
    local.set 66
    local.set 65
    local.set 64
    local.set 63
    local.set 62
    br 0
    end
    end
    local.get 67
    i32.const 2
    i32.sub
    local.set 71
    local.get 67
    i32.const 1
    i32.add
    local.set 72
    end
    local.get 72
    local.get 55
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 70
    i32.const -2
    local.set 81
    local.set 80
    br 1
    end
    local.get 70
    local.get 71
    local.set 81
    local.set 80
    end
    local.get 80
    i32.const -1
    i32.eq
    i32.eqz
    br_if 5
    end
    end
    local.get 26
    i32.load
    local.set 84
    local.get 54
    local.get 56
    i32.gt_s
    i32.eqz
    br_if 9
    end
    local.get 56
    local.get 84
    i32.lt_s
    i32.eqz
    br_if 8
    end
    local.get 54
    local.get 84
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 54
    local.set 85
    br 2
    end
    local.get 80
    local.set 82
    br 10
    end
    local.get 84
    local.set 85
    end
    local.get 26
    local.get 66
    local.get 85
    call $http____find_crlf
    local.set 86
    local.get 86
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 86
    local.set 82
    br 7
    end
    end
    br 1
    end
    end
    local.get 84
    local.get 54
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const -2
    local.set 82
    br 2
    end
    end
    i32.const -1
    local.set 82
    end
    local.get 81
    i32.const -1
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 53
    local.get 55
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const -2
    local.set 83
    br 1
    end
    local.get 81
    local.set 83
    end
    end
    end
    local.get 82
    i32.const -2
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 414
    local.set 36
    br 8
    end
    end
    local.get 83
    i32.const -2
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 431
    local.set 36
    br 5
    end
    end
    local.get 63
    i32.eqz
    br_if 1
    end
    i32.const 400
    local.set 36
    br 2
    end
    end
    i32.const 0
    local.set 36
    end
    local.get 36
    i32.const 0
    i32.ne
    if
    local.get 26
    call $__fern_arr_dec
    drop
    br 298
    else
    end
    end
    end
    i32.const -1
    local.set 37
    i32.const -1
    local.set 38
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 39
    local.get 82
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 5
    end
    end
    local.get 26
    local.get 35
    local.get 82
    call $http____token_end
    local.tee 112
    local.get 35
    i32.eq
    br_if 2
    end
    local.get 112
    local.get 82
    i32.ge_s
    br_if 1
    end
    local.get 26
    local.get 112
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 32
    i32.ne
    i32.eqz
    br_if 2
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 279
    i32.const 400
    i32.const -1
    i32.const -1
    local.get 279
    local.set 132
    local.set 130
    local.set 128
    local.set 126
    br 59
    end
    local.get 37
    local.get 38
    local.get 39
    local.set 131
    local.set 129
    local.set 127
    br 60
    end
    end
    local.get 112
    i32.const 1
    i32.add
    local.set 113
    end
    local.get 26
    i32.const 32
    local.get 113
    call $__fern_memchr_bytes
    local.tee 119
    local.get 82
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 119
    local.set 114
    br 2
    end
    end
    i32.const -1
    local.set 114
    end
    local.get 114
    i32.const 0
    i32.lt_s
    br_if 1
    end
    local.get 112
    i32.const 1
    i32.add
    local.set 279
    local.get 114
    local.get 279
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 279
    i32.const 400
    i32.const -1
    i32.const -1
    local.get 279
    local.set 132
    local.set 130
    local.set 128
    local.set 126
    br 49
    end
    end
    local.get 114
    i32.const 1
    i32.add
    local.set 115
    end
    local.get 82
    local.get 115
    i32.sub
    local.set 279
    local.get 279
    i32.const 8
    i32.ne
    br_if 1
    end
    local.get 26
    local.set 279
    global.get $__cagg_base
    i32.const 1464
    i32.add
    local.set 280
    local.get 279
    local.get 115
    local.get 280
    i32.const 0
    i32.const 5
    call $__sem_byte_view_mismatch
    local.set 279
    local.get 279
    i32.const 5
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 400
    local.set 116
    br 18
    end
    end
    local.get 115
    i32.const 5
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 122
    end
    local.get 122
    i32.const 48
    i32.ge_u
    i32.eqz
    br_if 1
    end
    local.get 122
    i32.const 57
    i32.le_u
    local.set 124
    br 1
    end
    i32.const 0
    local.set 124
    end
    local.get 124
    i32.eqz
    br_if 9
    end
    local.get 115
    i32.const 6
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 46
    i32.ne
    br_if 8
    end
    local.get 115
    i32.const 7
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 123
    end
    local.get 123
    i32.const 48
    i32.ge_u
    i32.eqz
    br_if 1
    end
    local.get 123
    i32.const 57
    i32.le_u
    local.set 125
    br 1
    end
    i32.const 0
    local.set 125
    end
    local.get 125
    i32.eqz
    br_if 3
    end
    end
    local.get 115
    i32.const 5
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 49
    i32.ne
    i32.eqz
    br_if 2
    end
    i32.const 505
    local.set 116
    br 3
    end
    i32.const 400
    local.set 116
    br 2
    end
    end
    i32.const 0
    local.set 116
    end
    local.get 116
    i32.const 0
    i32.ne
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 279
    local.get 116
    i32.const -1
    i32.const -1
    local.get 279
    local.set 132
    local.set 130
    local.set 128
    local.set 126
    br 24
    end
    end
    local.get 112
    i32.const 1
    i32.add
    local.set 117
    local.get 112
    local.get 35
    i32.sub
    local.set 279
    local.get 279
    i32.const 7
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 2400
    i32.add
    local.set 279
    local.get 279
    i32.load
    local.set 280
    local.get 26
    local.get 35
    local.get 279
    i32.const 0
    local.get 280
    call $__fern_mismatch_bytes_str
    local.set 280
    local.get 279
    i32.load
    local.set 279
    local.get 280
    local.get 279
    i32.eq
    local.set 118
    br 1
    end
    i32.const 0
    local.set 118
    end
    end
    local.get 26
    local.get 117
    local.get 114
    local.get 118
    call $http____target_start
    local.set 120
    local.get 120
    i32.const -2
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 400
    local.set 269
    br 15
    end
    end
    local.get 120
    i32.const -1
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 2412
    i32.add
    local.set 268
    br 10
    end
    end
    local.get 26
    local.get 120
    local.get 114
    call $http____path_end
    local.set 121
    local.get 121
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 400
    local.set 269
    br 9
    end
    end
    local.get 120
    local.get 121
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 26
    local.get 120
    local.get 121
    call $http____plain_path
    i32.eqz
    br_if 1
    end
    local.get 26
    local.get 120
    local.get 114
    local.get 33
    call $http____shared_string
    local.set 268
    br 3
    end
    end
    local.get 26
    local.get 120
    local.get 121
    local.get 114
    call $http____decoded_path
    local.set 279
    global.get $__fern_ret_word
    local.set 265
    local.get 265
    local.set 265
    local.get 279
    i32.const 0
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 265
    local.set 268
    end
    i32.const 0
    local.get 112
    local.get 114
    local.get 268
    local.set 132
    local.set 130
    local.set 128
    local.set 126
    br 3
    end
    local.get 265
    local.set 269
    end
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 279
    local.get 269
    i32.const -1
    i32.const -1
    local.get 279
    local.set 132
    local.set 130
    local.set 128
    local.set 126
    end
    local.get 126
    i32.const 0
    i32.ne
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 132
    call $__fern_arr_dec
    drop
    br 232
    else
    end
    end
    local.get 128
    local.get 130
    local.get 132
    local.set 131
    local.set 129
    local.set 127
    end
    local.get 82
    i32.const 0
    i32.lt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    br 231
    else
    end
    end
    local.get 83
    i32.const 0
    i32.lt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    br 230
    else
    end
    end
    end
    local.get 83
    i32.const 4
    i32.add
    local.get 35
    i32.sub
    local.set 40
    local.get 82
    i32.const 2
    i32.add
    local.tee 41
    local.get 83
    i32.gt_s
    i32.eqz
    br_if 1
    end
    local.get 83
    local.set 42
    br 1
    end
    local.get 41
    local.set 42
    end
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    end
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    local.set 279
    local.get 279
    i32.const 1
    i32.const 0
    local.get 42
    local.set 206
    local.set 205
    local.set 204
    local.set 203
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 206
    local.get 83
    i32.lt_s
    i32.eqz
    br_if 56
    end
    end
    local.get 26
    local.get 206
    local.get 83
    call $http____token_end
    local.tee 218
    local.get 206
    i32.eq
    br_if 2
    end
    local.get 218
    local.get 83
    i32.ge_s
    br_if 1
    end
    local.get 26
    local.get 218
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 58
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.get 83
    local.set 233
    local.set 232
    br 13
    end
    end
    local.get 218
    i32.const 1
    i32.add
    local.set 219
    end
    local.get 26
    i32.const 13
    local.get 219
    call $__fern_memchr_bytes
    local.set 231
    local.get 231
    i32.const 0
    i32.lt_s
    br_if 1
    end
    local.get 231
    local.get 83
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 83
    local.set 220
    br 5
    end
    end
    local.get 231
    i32.const 1
    i32.add
    local.get 83
    i32.ge_s
    br_if 1
    end
    local.get 231
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.set 220
    br 1
    end
    local.get 231
    local.set 220
    end
    local.get 220
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.get 83
    local.set 233
    local.set 232
    br 1
    end
    local.get 218
    local.get 220
    local.set 233
    local.set 232
    end
    local.get 232
    i32.const 0
    i32.lt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 203
    call $__sem_release_HeaderMap
    drop
    br 272
    else
    end
    end
    end
    local.get 205
    i32.const 1
    i32.add
    local.tee 207
    local.get 30
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 203
    call $__sem_release_HeaderMap
    drop
    br 271
    else
    end
    end
    end
    local.get 207
    i32.const 1
    i32.sub
    local.set 208
    local.get 204
    i32.eqz
    br_if 5
    end
    local.get 34
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 208
    local.get 279
    i32.ge_s
    i32.eqz
    br_if 4
    end
    local.get 208
    i32.const 0
    i32.gt_s
    if
    local.get 203
    call $__sem_release_HeaderMap
    drop
    else
    br 2
    end
    end
    local.get 34
    call $__fern_rc_inc
    drop
    local.get 34
    local.get 208
    call $http____leading_fields
    local.set 209
    br 1
    end
    local.get 203
    local.set 209
    end
    local.get 209
    i32.const 0
    local.set 211
    local.set 210
    br 1
    end
    local.get 203
    local.get 204
    local.set 211
    local.set 210
    end
    i32.const -1
    local.set 212
    local.get 211
    i32.eqz
    br_if 1
    end
    local.get 208
    local.set 213
    br 1
    end
    local.get 212
    local.set 213
    end
    local.get 232
    i32.const 1
    i32.add
    local.set 221
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 221
    local.get 233
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 26
    local.get 221
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 222
    end
    local.get 222
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 227
    br 1
    end
    local.get 222
    i32.const 9
    i32.eq
    local.set 227
    end
    local.get 227
    i32.eqz
    br_if 2
    end
    local.get 221
    i32.const 1
    i32.add
    local.set 221
    br 0
    end
    end
    local.get 233
    local.set 223
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 223
    local.get 221
    i32.gt_s
    i32.eqz
    br_if 7
    end
    local.get 223
    i32.const 1
    i32.sub
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 224
    end
    local.get 224
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 228
    br 1
    end
    local.get 224
    i32.const 9
    i32.eq
    local.set 228
    end
    local.get 228
    i32.eqz
    br_if 2
    end
    local.get 223
    i32.const 1
    i32.sub
    local.set 223
    br 0
    end
    end
    local.get 213
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 3
    end
    local.get 34
    i32.const 16
    i32.add
    i32.load
    local.get 213
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 223
    local.get 221
    i32.sub
    local.set 280
    local.get 279
    local.get 280
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 34
    i32.const 16
    i32.add
    i32.load
    local.tee 225
    local.get 213
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 279
    i32.load
    local.set 280
    local.get 26
    local.get 221
    local.get 279
    i32.const 0
    local.get 280
    call $__fern_mismatch_bytes_str
    local.set 280
    local.get 279
    i32.load
    local.set 279
    local.get 280
    local.get 279
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 225
    local.get 213
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 279
    call $__fern_rc_inc
    drop
    local.get 279
    local.set 272
    br 5
    end
    end
    global.get $__cagg_base
    i32.const 872
    i32.add
    local.set 279
    local.get 26
    local.get 221
    local.get 279
    call $__fern_scan_set_bytes
    local.get 223
    i32.lt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 210
    call $__sem_release_HeaderMap
    drop
    br 251
    else
    end
    end
    end
    local.get 26
    local.get 221
    local.get 223
    call $http____bytes_string
    local.tee 226
    call $utf8__is_valid
    if
    else
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 210
    call $__sem_release_HeaderMap
    drop
    local.get 226
    call $__fern_arr_dec
    drop
    br 250
    end
    end
    local.get 226
    local.set 272
    end
    local.get 211
    i32.eqz
    br_if 6
    end
    local.get 34
    i32.const 8
    i32.add
    i32.load
    local.get 208
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 26
    local.get 206
    local.get 232
    local.get 279
    call $http____shared_string
    local.tee 214
    local.get 279
    call $__fern_streq
    i32.eqz
    br_if 1
    end
    local.get 34
    i32.const 16
    i32.add
    i32.load
    local.get 208
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 272
    local.get 279
    call $__fern_streq
    local.set 215
    br 1
    end
    i32.const 0
    local.set 215
    end
    local.get 215
    if
    local.get 214
    call $__fern_arr_dec
    drop
    local.get 272
    call $__fern_arr_dec
    drop
    else
    local.get 210
    call $__sem_release_HeaderMap
    drop
    br 2
    end
    end
    local.get 210
    local.get 215
    local.set 217
    local.set 216
    br 2
    end
    local.get 34
    call $__fern_rc_inc
    drop
    local.get 34
    local.get 208
    call $http____leading_fields
    local.tee 279
    call $__fern_rc_is_unique
    if
    local.get 279
    local.set 276
    else
    i32.const 0
    local.set 276
    end
    local.get 279
    i32.const 8
    i32.add
    i32.load
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 280
    call $__fern_rc_inc
    drop
    end
    local.get 280
    call $__fern_rc_is_unique
    if
    local.get 280
    local.get 214
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 280
    local.get 214
    call $__fern_arr_push
    local.set 277
    local.get 280
    call $__fern_arr_inc_elems
    drop
    local.get 280
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 280
    local.get 279
    i32.const 16
    i32.add
    i32.load
    local.set 281
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 281
    call $__fern_rc_inc
    drop
    end
    local.get 281
    call $__fern_rc_is_unique
    if
    local.get 281
    local.get 272
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 281
    local.get 272
    call $__fern_arr_push
    local.set 277
    local.get 281
    call $__fern_arr_inc_elems
    drop
    local.get 281
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 281
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 276
    i32.const 3
    call $__fern_alloc_reuse
    local.tee 229
    local.tee 284
    local.get 284
    global.get $__tid$HeaderMap
    i32.store
    drop
    else
    local.get 276
    local.set 229
    end
    local.get 276
    i32.const 0
    i32.ne
    if
    else
    local.get 279
    call $__sem_release_HeaderMap
    drop
    end
    i32.const 0
    local.set 279
    local.get 229
    local.get 280
    local.set 285
    i32.const 8
    i32.add
    local.get 285
    i32.store
    local.get 229
    local.get 281
    local.set 285
    i32.const 16
    i32.add
    local.get 285
    i32.store
    local.get 229
    local.get 215
    local.set 217
    local.set 216
    br 1
    end
    local.get 26
    local.get 206
    local.get 232
    call $http____bytes_string
    local.set 279
    local.get 210
    call $__fern_rc_is_unique
    if
    local.get 210
    local.set 276
    else
    i32.const 0
    local.set 276
    end
    local.get 210
    i32.const 8
    i32.add
    i32.load
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 280
    call $__fern_rc_inc
    drop
    end
    local.get 280
    call $__fern_rc_is_unique
    if
    local.get 280
    local.get 279
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 280
    local.get 279
    call $__fern_arr_push
    local.set 277
    local.get 280
    call $__fern_arr_inc_elems
    drop
    local.get 280
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 279
    local.get 210
    i32.const 16
    i32.add
    i32.load
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 280
    call $__fern_rc_inc
    drop
    end
    local.get 280
    call $__fern_rc_is_unique
    if
    local.get 280
    local.get 272
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 280
    local.get 272
    call $__fern_arr_push
    local.set 277
    local.get 280
    call $__fern_arr_inc_elems
    drop
    local.get 280
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 276
    i32.const 3
    call $__fern_alloc_reuse
    local.tee 230
    local.tee 284
    local.get 284
    global.get $__tid$HeaderMap
    i32.store
    drop
    else
    local.get 276
    local.set 230
    end
    local.get 276
    i32.const 0
    i32.ne
    if
    else
    local.get 210
    call $__sem_release_HeaderMap
    drop
    end
    i32.const 0
    local.set 210
    local.get 230
    local.get 279
    local.set 285
    i32.const 8
    i32.add
    local.get 285
    i32.store
    local.get 230
    local.get 280
    local.set 285
    i32.const 16
    i32.add
    local.get 285
    i32.store
    local.get 230
    local.get 211
    local.set 217
    local.set 216
    end
    end
    local.get 233
    i32.const 2
    i32.add
    local.set 279
    local.get 216
    local.get 217
    local.get 207
    local.get 279
    local.set 206
    local.set 205
    local.set 204
    local.set 203
    br 0
    end
    end
    local.get 204
    i32.eqz
    br_if 2
    end
    local.get 34
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 205
    local.get 279
    i32.eq
    if
    local.get 203
    call $__sem_release_HeaderMap
    drop
    else
    br 2
    end
    end
    local.get 34
    local.set 273
    br 4
    end
    end
    local.get 204
    if
    local.get 203
    call $__sem_release_HeaderMap
    drop
    else
    br 2
    end
    end
    local.get 34
    local.get 205
    call $http____leading_fields
    local.set 273
    br 1
    end
    local.get 203
    local.set 273
    end
    end
    local.get 129
    i32.const 1
    i32.add
    local.set 43
    end
    local.get 43
    i32.const 7
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 48
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 2420
    i32.add
    local.set 44
    br 2
    end
    end
    global.get $__str_base
    i32.const 2432
    i32.add
    local.set 44
    end
    end
    i32.const -1
    i32.const -1
    i32.const -1
    i32.const -1
    i32.const -1
    i32.const 0
    local.set 99
    local.set 98
    local.set 97
    local.set 96
    local.set 95
    local.set 94
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 273
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 99
    local.get 279
    i32.lt_s
    i32.eqz
    br_if 48
    end
    local.get 273
    i32.const 8
    i32.add
    i32.load
    local.get 99
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 100
    end
    local.get 100
    i32.load
    local.set 107
    local.get 107
    i32.const 4
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 2444
    i32.add
    local.set 279
    local.get 100
    local.get 279
    i32.const 3
    call $http____kind_if
    local.set 101
    br 14
    end
    end
    local.get 107
    i32.const 6
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 2452
    i32.add
    local.set 279
    local.get 100
    local.get 279
    i32.const 4
    call $http____kind_if
    local.set 101
    br 11
    end
    end
    local.get 107
    i32.const 10
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 1172
    i32.add
    local.set 279
    local.get 100
    local.get 279
    i32.const 5
    call $http____kind_if
    local.set 101
    br 8
    end
    end
    local.get 107
    i32.const 14
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 1152
    i32.add
    local.set 279
    local.get 100
    local.get 279
    i32.const 1
    call $http____kind_if
    local.set 101
    br 5
    end
    end
    local.get 107
    i32.const 17
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 1188
    i32.add
    local.set 279
    local.get 100
    local.get 279
    i32.const 2
    call $http____kind_if
    local.set 101
    br 2
    end
    end
    i32.const 0
    local.set 101
    end
    local.get 101
    i32.const 1
    i32.eq
    i32.eqz
    br_if 3
    end
    end
    local.get 94
    i32.const -1
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 99
    local.set 102
    br 3
    end
    local.get 94
    local.set 102
    br 2
    end
    end
    i32.const -2
    local.set 102
    end
    local.get 101
    i32.const 2
    i32.eq
    i32.eqz
    br_if 3
    end
    end
    local.get 95
    i32.const -1
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 99
    local.set 103
    br 3
    end
    local.get 95
    local.set 103
    br 2
    end
    end
    i32.const -2
    local.set 103
    end
    local.get 101
    i32.const 3
    i32.eq
    i32.eqz
    br_if 3
    end
    end
    local.get 96
    i32.const -1
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 99
    local.set 104
    br 3
    end
    local.get 96
    local.set 104
    br 2
    end
    end
    i32.const -2
    local.set 104
    end
    local.get 101
    i32.const 4
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 97
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 99
    local.set 105
    br 1
    end
    local.get 97
    local.set 105
    end
    local.get 101
    i32.const 5
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 98
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    local.get 99
    local.set 106
    br 1
    end
    local.get 98
    local.set 106
    end
    local.get 99
    i32.const 1
    i32.add
    local.set 279
    local.get 102
    local.get 103
    local.get 104
    local.get 105
    local.get 106
    local.get 279
    local.set 99
    local.set 98
    local.set 97
    local.set 96
    local.set 95
    local.set 94
    br 0
    end
    end
    end
    end
    local.get 97
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 45
    br 4
    end
    local.get 97
    local.set 52
    end
    loop
    block
    block
    block
    local.get 52
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 4
    end
    local.get 273
    i32.const 16
    i32.add
    i32.load
    local.get 52
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    global.get $__str_base
    i32.const 2464
    i32.add
    local.set 280
    local.get 279
    local.get 280
    call $http____token_is
    i32.eqz
    br_if 4
    end
    end
    global.get $__str_base
    i32.const 2452
    i32.add
    local.set 279
    local.get 52
    i32.const 1
    i32.add
    local.set 280
    local.get 273
    local.get 279
    local.get 280
    call $http____field_at
    local.set 52
    br 0
    end
    end
    i32.const 1
    local.set 45
    br 1
    end
    i32.const 417
    local.set 45
    end
    end
    end
    local.get 96
    i32.const -1
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 2432
    i32.add
    local.set 279
    i32.const 0
    local.set 277
    local.get 44
    i32.load
    i32.const 8
    i32.eq
    if
    local.get 44
    local.get 279
    call $__fern_streq
    local.set 277
    end
    local.get 277
    i32.eqz
    local.set 108
    br 8
    end
    end
    local.get 96
    i32.const -2
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 108
    br 5
    end
    end
    local.get 273
    i32.const 16
    i32.add
    i32.load
    local.get 96
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 109
    i32.const 0
    local.set 110
    end
    local.get 109
    i32.load
    local.set 279
    local.get 109
    i32.const 4
    i32.add
    local.set 280
    loop
    block
    block
    block
    block
    local.get 279
    local.set 281
    local.get 110
    local.get 281
    i32.lt_s
    i32.eqz
    br_if 5
    end
    local.get 280
    local.get 110
    i32.add
    i32.load8_u
    local.set 111
    local.get 111
    i32.const 33
    i32.lt_s
    br_if 5
    end
    local.get 111
    i32.const 126
    i32.gt_s
    br_if 4
    end
    end
    local.get 110
    i32.const 1
    i32.add
    local.set 110
    br 0
    end
    end
    i32.const 1
    local.set 108
    br 1
    end
    i32.const 0
    local.set 108
    end
    local.get 108
    i32.eqz
    br_if 3
    end
    end
    local.get 45
    i32.const 417
    i32.eq
    i32.eqz
    br_if 2
    end
    i32.const 417
    local.set 46
    br 3
    end
    i32.const 400
    local.set 46
    br 2
    end
    end
    i32.const 0
    local.set 46
    end
    local.get 46
    i32.const 0
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 180
    else
    end
    end
    end
    end
    local.get 95
    i32.const -1
    i32.eq
    i32.eqz
    br_if 3
    end
    end
    local.get 94
    i32.const -1
    i32.eq
    i32.eqz
    br_if 11
    end
    local.get 197
    i32.const 0
    local.set 267
    local.set 266
    br 18
    end
    end
    local.get 94
    i32.const -1
    i32.ne
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 173
    else
    end
    end
    local.get 95
    i32.const -2
    i32.eq
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 172
    else
    end
    end
    end
    local.get 273
    i32.const 16
    i32.add
    i32.load
    local.get 95
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    global.get $__str_base
    i32.const 2480
    i32.add
    local.set 280
    local.get 279
    local.get 280
    call $__fern_str_split
    local.tee 87
    i32.load
    local.set 279
    local.get 279
    i32.const 1
    i32.sub
    local.set 279
    local.get 87
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    global.get $__str_base
    i32.const 2488
    i32.add
    local.set 280
    local.get 279
    local.get 280
    call $http____token_is
    if
    else
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 87
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 277
    block
    loop
    local.get 277
    local.get 87
    i32.load
    i32.ge_s
    br_if 1
    local.get 87
    local.get 277
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 278
    call $__fern_arr_dec
    drop
    local.get 277
    i32.const 1
    i32.add
    local.set 277
    br 0
    end
    end
    end
    local.get 87
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 171
    end
    end
    end
    i32.const 0
    local.set 88
    end
    loop
    block
    block
    block
    local.get 88
    i32.const 1
    i32.add
    local.set 279
    local.get 87
    i32.load
    local.set 280
    local.get 279
    local.get 280
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 87
    local.get 88
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    global.get $__str_base
    i32.const 2488
    i32.add
    local.set 280
    local.get 279
    local.get 280
    call $http____token_is
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 87
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 277
    block
    loop
    local.get 277
    local.get 87
    i32.load
    i32.ge_s
    br_if 1
    local.get 87
    local.get 277
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 278
    call $__fern_arr_dec
    drop
    local.get 277
    i32.const 1
    i32.add
    local.set 277
    br 0
    end
    end
    end
    local.get 87
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 172
    else
    end
    end
    end
    local.get 88
    i32.const 1
    i32.add
    local.set 88
    br 0
    end
    end
    local.get 87
    i32.load
    local.set 279
    local.get 87
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 277
    block
    loop
    local.get 277
    local.get 87
    i32.load
    i32.ge_s
    br_if 1
    local.get 87
    local.get 277
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 278
    call $__fern_arr_dec
    drop
    local.get 277
    i32.const 1
    i32.add
    local.set 277
    br 0
    end
    end
    end
    local.get 87
    call $__fern_arr_dec
    drop
    local.get 279
    i32.const 1
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 169
    else
    end
    end
    local.get 198
    local.get 199
    local.set 267
    local.set 266
    br 8
    end
    end
    local.get 94
    i32.const -2
    i32.eq
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 167
    else
    end
    end
    end
    local.get 273
    i32.const 16
    i32.add
    i32.load
    local.get 94
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 89
    i32.load
    local.set 279
    local.get 279
    i32.const 0
    i32.eq
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 166
    else
    end
    end
    end
    i32.const 0
    i32.const 0
    local.set 91
    local.set 90
    end
    local.get 89
    i32.load
    local.set 279
    local.get 89
    i32.const 4
    i32.add
    local.set 280
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 279
    local.set 281
    local.get 91
    local.get 281
    i32.lt_s
    i32.eqz
    br_if 9
    end
    local.get 280
    local.get 91
    i32.add
    i32.load8_u
    local.set 92
    local.get 92
    i32.const 48
    i32.lt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 172
    else
    end
    end
    local.get 92
    i32.const 57
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 171
    else
    end
    end
    end
    local.get 92
    i32.const 48
    i32.sub
    local.set 93
    local.get 90
    i32.const 214748364
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 170
    else
    end
    end
    local.get 90
    i32.const 214748364
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 93
    i32.const 7
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 168
    else
    end
    end
    end
    local.get 90
    i32.const 10
    i32.mul
    local.get 93
    i32.add
    local.set 281
    local.get 91
    i32.const 1
    i32.add
    local.set 282
    local.get 281
    local.get 282
    local.set 91
    local.set 90
    br 0
    end
    end
    local.get 197
    local.get 90
    local.set 267
    local.set 266
    end
    end
    local.get 26
    local.get 35
    local.get 127
    local.get 32
    call $http____shared_string
    call $__fern_arr_dec
    drop
    local.get 35
    local.get 40
    i32.add
    local.get 27
    i32.sub
    local.set 47
    end
    local.get 98
    i32.const 0
    local.set 49
    local.set 48
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    local.get 48
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 8
    end
    local.get 273
    i32.const 16
    i32.add
    i32.load
    local.tee 50
    local.get 48
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    global.get $__str_base
    i32.const 2500
    i32.add
    local.set 280
    local.get 279
    local.get 280
    call $http____lists_token
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 51
    br 1
    end
    local.get 49
    local.set 51
    end
    local.get 50
    local.get 48
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    global.get $__str_base
    i32.const 2512
    i32.add
    local.set 280
    local.get 279
    local.get 280
    call $http____lists_token
    i32.eqz
    br_if 1
    end
    br 1
    end
    end
    global.get $__str_base
    i32.const 1172
    i32.add
    local.set 279
    local.get 48
    i32.const 1
    i32.add
    local.set 280
    local.get 273
    local.get 279
    local.get 280
    call $http____field_at
    local.get 51
    local.set 49
    local.set 48
    br 0
    end
    end
    local.get 49
    i32.eqz
    br_if 1
    end
    br 5
    end
    end
    global.get $__str_base
    i32.const 2420
    i32.add
    local.set 279
    i32.const 0
    local.set 277
    local.get 44
    i32.load
    i32.const 8
    i32.eq
    if
    local.get 44
    local.get 279
    call $__fern_streq
    local.set 277
    end
    local.get 277
    i32.eqz
    br_if 1
    end
    br 2
    end
    end
    end
    end
    global.get $__cagg_base
    i32.const 328
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    local.get 266
    i32.eqz
    br_if 7
    end
    local.get 267
    local.get 31
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    i32.const 413
    local.set 196
    br 70
    end
    end
    local.get 47
    local.get 267
    i32.add
    local.set 279
    local.get 26
    i32.load
    local.set 280
    local.get 279
    local.get 280
    i32.gt_s
    if
    local.get 26
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    i32.const 1
    local.set 196
    br 67
    end
    end
    local.get 26
    local.set 279
    local.get 47
    local.get 267
    i32.add
    local.set 280
    local.get 279
    local.get 47
    local.get 280
    call $__fern_bytes_range
    local.set 279
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 279
    call $__fern_arr_dec
    drop
    local.get 47
    local.get 267
    i32.add
    drop
    i32.const 2
    local.set 196
    br 65
    end
    end
    global.get $__str_base
    i32.const 2432
    i32.add
    local.set 279
    i32.const 0
    local.set 277
    local.get 44
    i32.load
    i32.const 8
    i32.eq
    if
    local.get 44
    local.get 279
    call $__fern_streq
    local.set 277
    end
    local.get 277
    i32.eqz
    if
    local.get 26
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    i32.const 400
    local.set 196
    br 62
    end
    end
    end
    local.get 26
    i32.load
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    local.set 279
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    local.get 47
    local.get 29
    local.get 31
    local.get 279
    local.set 142
    local.set 141
    local.set 140
    local.set 139
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    end
    end
    local.get 26
    i32.load
    local.set 157
    local.get 139
    local.get 140
    i32.add
    local.tee 158
    local.get 157
    i32.gt_s
    i32.eqz
    br_if 1
    end
    local.get 157
    local.set 159
    br 1
    end
    local.get 158
    local.set 159
    end
    local.get 26
    local.get 139
    local.get 159
    call $http____find_crlf
    local.set 160
    local.get 160
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 160
    local.set 161
    br 1
    end
    local.get 159
    local.set 161
    end
    local.get 26
    local.get 139
    local.get 161
    call $http____crlf_terminated
    i32.eqz
    br_if 4
    end
    end
    local.get 160
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 5
    end
    local.get 139
    local.get 140
    i32.add
    local.set 279
    local.get 157
    local.get 279
    i32.ge_s
    i32.eqz
    br_if 2
    end
    i32.const 431
    i32.const 0
    i32.const 0
    local.set 194
    local.set 193
    local.set 192
    br 24
    end
    i32.const 400
    i32.const 0
    i32.const 0
    local.set 194
    local.set 193
    local.set 192
    br 23
    end
    end
    i32.const 1
    i32.const 0
    i32.const 0
    local.set 194
    local.set 193
    local.set 192
    br 21
    end
    end
    end
    i32.const 0
    local.get 139
    local.set 164
    local.set 163
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 164
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 33
    end
    local.get 26
    local.get 164
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 165
    end
    local.get 165
    i32.const 48
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 165
    i32.const 57
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 165
    local.set 279
    local.get 279
    i32.const 48
    i32.sub
    local.set 166
    br 10
    end
    end
    local.get 165
    i32.const 97
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 165
    i32.const 102
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 165
    local.set 279
    local.get 279
    i32.const 87
    i32.sub
    local.set 166
    br 6
    end
    end
    local.get 165
    i32.const 65
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 165
    i32.const 70
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 165
    local.set 279
    local.get 279
    i32.const 55
    i32.sub
    local.set 166
    br 2
    end
    end
    i32.const -1
    local.set 166
    end
    local.get 166
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 18
    end
    end
    local.get 165
    i32.const 48
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 165
    i32.const 57
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 165
    local.set 279
    local.get 279
    i32.const 48
    i32.sub
    local.set 167
    br 10
    end
    end
    local.get 165
    i32.const 97
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 165
    i32.const 102
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 165
    local.set 279
    local.get 279
    i32.const 87
    i32.sub
    local.set 167
    br 6
    end
    end
    local.get 165
    i32.const 65
    i32.ge_u
    i32.eqz
    br_if 2
    end
    local.get 165
    i32.const 70
    i32.le_u
    i32.eqz
    br_if 1
    end
    local.get 165
    local.set 279
    local.get 279
    i32.const 55
    i32.sub
    local.set 167
    br 2
    end
    end
    i32.const -1
    local.set 167
    end
    local.get 163
    i32.const 4
    i32.shl
    local.get 167
    i32.add
    local.get 141
    i32.gt_s
    br_if 5
    end
    end
    local.get 163
    i32.const 4
    i32.shl
    local.get 167
    i32.add
    local.set 279
    local.get 164
    i32.const 1
    i32.add
    local.set 280
    local.get 279
    local.get 280
    local.set 164
    local.set 163
    br 0
    end
    end
    local.get 164
    local.get 139
    i32.eq
    i32.eqz
    br_if 2
    end
    i32.const 400
    i32.const 0
    local.set 169
    local.set 168
    br 3
    end
    i32.const 413
    i32.const 0
    local.set 169
    local.set 168
    br 2
    end
    end
    i32.const 0
    local.get 163
    local.set 169
    local.set 168
    end
    local.get 168
    i32.const 0
    i32.ne
    i32.eqz
    br_if 1
    end
    local.get 168
    i32.const 0
    i32.const 0
    local.set 194
    local.set 193
    local.set 192
    br 10
    end
    local.get 164
    local.set 170
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 170
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 37
    end
    local.get 170
    local.set 180
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 180
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 26
    local.get 180
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 181
    end
    local.get 181
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 182
    br 1
    end
    local.get 181
    i32.const 9
    i32.eq
    local.set 182
    end
    local.get 182
    i32.eqz
    br_if 2
    end
    local.get 180
    i32.const 1
    i32.add
    local.set 180
    br 0
    end
    end
    end
    local.get 180
    local.get 160
    i32.ge_s
    br_if 34
    end
    local.get 26
    local.get 180
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 59
    i32.ne
    br_if 33
    end
    end
    local.get 180
    i32.const 1
    i32.add
    local.set 183
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 183
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 26
    local.get 183
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 184
    end
    local.get 184
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 185
    br 1
    end
    local.get 184
    i32.const 9
    i32.eq
    local.set 185
    end
    local.get 185
    i32.eqz
    br_if 2
    end
    local.get 183
    i32.const 1
    i32.add
    local.set 183
    br 0
    end
    end
    end
    local.get 26
    local.get 183
    local.get 160
    call $http____token_end
    local.tee 171
    local.get 183
    i32.eq
    br_if 29
    end
    local.get 171
    local.set 186
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 186
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 26
    local.get 186
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 187
    end
    local.get 187
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 188
    br 1
    end
    local.get 187
    i32.const 9
    i32.eq
    local.set 188
    end
    local.get 188
    i32.eqz
    br_if 2
    end
    local.get 186
    i32.const 1
    i32.add
    local.set 186
    br 0
    end
    end
    end
    local.get 186
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 26
    local.get 186
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 61
    i32.eq
    i32.eqz
    br_if 6
    end
    local.get 186
    i32.const 1
    i32.add
    local.set 189
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 189
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 26
    local.get 189
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 190
    end
    local.get 190
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 191
    br 1
    end
    local.get 190
    i32.const 9
    i32.eq
    local.set 191
    end
    local.get 191
    i32.eqz
    br_if 2
    end
    local.get 189
    i32.const 1
    i32.add
    local.set 189
    br 0
    end
    end
    end
    end
    local.get 189
    local.get 160
    i32.ge_s
    i32.eqz
    br_if 2
    end
    i32.const -1
    local.set 172
    br 12
    end
    local.get 171
    local.set 173
    br 13
    end
    end
    local.get 26
    local.get 189
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 34
    i32.ne
    i32.eqz
    br_if 3
    end
    local.get 26
    local.get 189
    local.get 160
    call $http____token_end
    local.tee 174
    local.get 189
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.set 172
    br 7
    end
    local.get 174
    local.set 172
    br 6
    end
    end
    local.get 189
    i32.const 1
    i32.add
    local.set 175
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 175
    local.get 160
    i32.lt_s
    i32.eqz
    br_if 16
    end
    local.get 26
    local.get 175
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 176
    local.get 176
    i32.const 34
    i32.eq
    br_if 16
    end
    end
    local.get 176
    i32.const 92
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 175
    i32.const 1
    i32.add
    local.set 177
    br 1
    end
    local.get 175
    local.set 177
    end
    local.get 177
    local.get 160
    i32.ge_s
    br_if 12
    end
    local.get 26
    local.get 177
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 178
    end
    local.get 178
    i32.const 9
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 179
    br 3
    end
    local.get 178
    i32.const 32
    i32.ge_u
    i32.eqz
    br_if 1
    end
    local.get 178
    i32.const 127
    i32.ne
    local.set 179
    br 1
    end
    i32.const 0
    local.set 179
    end
    local.get 179
    i32.eqz
    br_if 5
    end
    end
    local.get 177
    i32.const 1
    i32.add
    local.set 175
    br 0
    end
    end
    i32.const -1
    local.set 172
    br 2
    end
    local.get 175
    i32.const 1
    i32.add
    local.set 172
    br 1
    end
    i32.const -1
    local.set 172
    end
    local.get 172
    i32.const 0
    i32.lt_s
    br_if 6
    end
    local.get 172
    local.set 173
    end
    local.get 173
    local.set 170
    br 0
    end
    end
    i32.const 1
    local.set 162
    br 3
    end
    i32.const 0
    local.set 162
    br 2
    end
    i32.const 0
    local.set 162
    br 1
    end
    i32.const 0
    local.set 162
    end
    local.get 162
    i32.eqz
    br_if 2
    end
    end
    i32.const 2
    local.get 160
    local.get 169
    local.set 194
    local.set 193
    local.set 192
    br 1
    end
    i32.const 400
    i32.const 0
    i32.const 0
    local.set 194
    local.set 193
    local.set 192
    end
    local.get 192
    i32.const 2
    i32.ne
    br_if 24
    end
    end
    local.get 193
    i32.const 2
    i32.add
    local.tee 143
    local.get 139
    i32.sub
    local.set 279
    local.get 140
    local.get 279
    i32.sub
    local.set 279
    local.get 279
    i32.const 2
    i32.sub
    local.set 144
    local.get 144
    i32.const 0
    i32.lt_s
    br_if 23
    end
    end
    local.get 194
    i32.const 0
    i32.eq
    br_if 22
    end
    end
    local.get 143
    local.get 194
    i32.add
    local.set 146
    end
    local.get 26
    i32.load
    local.set 148
    local.get 146
    local.get 148
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 26
    local.get 146
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 13
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 147
    br 9
    end
    end
    local.get 146
    i32.const 1
    i32.add
    local.get 148
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 146
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 147
    br 5
    end
    end
    local.get 146
    i32.const 2
    i32.add
    local.get 148
    i32.gt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 147
    br 2
    end
    end
    i32.const 2
    local.set 147
    end
    local.get 147
    i32.const 0
    i32.eq
    br_if 10
    end
    end
    local.get 147
    i32.const 1
    i32.eq
    br_if 9
    end
    end
    local.get 142
    local.get 143
    call $__fern_arr_push_owned
    local.get 194
    call $__fern_arr_push_owned
    local.set 279
    local.get 141
    local.get 194
    i32.sub
    local.set 280
    local.get 143
    local.get 194
    i32.add
    local.set 281
    local.get 281
    i32.const 2
    i32.add
    local.get 144
    local.get 280
    local.get 279
    local.set 142
    local.set 141
    local.set 140
    local.set 139
    br 0
    end
    end
    local.get 192
    local.set 195
    br 48
    end
    i32.const 431
    local.set 195
    br 47
    end
    local.get 144
    i32.const 2
    i32.add
    local.set 145
    end
    local.get 26
    i32.load
    local.set 149
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    local.get 143
    local.get 145
    i32.add
    local.tee 150
    local.get 149
    i32.gt_s
    i32.eqz
    br_if 3
    end
    local.get 149
    local.set 151
    br 3
    end
    i32.const 400
    local.set 195
    br 43
    end
    i32.const 1
    local.set 195
    br 42
    end
    local.get 150
    local.set 151
    end
    local.get 143
    i32.const 2
    i32.sub
    local.set 152
    end
    local.get 26
    i32.const 13
    local.get 152
    call $__fern_memchr_bytes
    local.set 155
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 155
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 7
    end
    local.get 155
    i32.const 3
    i32.add
    local.get 151
    i32.lt_s
    i32.eqz
    br_if 6
    end
    local.get 155
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 155
    i32.const 2
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 13
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 155
    i32.const 3
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.eq
    br_if 4
    end
    end
    local.get 155
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    i32.const 13
    local.get 279
    call $__fern_memchr_bytes
    local.set 155
    br 0
    end
    end
    i32.const -1
    local.set 153
    br 1
    end
    local.get 155
    local.set 153
    end
    local.get 153
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 153
    local.set 154
    br 1
    end
    local.get 151
    local.set 154
    end
    local.get 154
    local.get 143
    i32.gt_s
    i32.eqz
    br_if 1
    end
    local.get 26
    local.get 143
    local.get 154
    call $http____crlf_terminated
    i32.eqz
    br_if 4
    end
    end
    local.get 153
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 5
    end
    local.get 143
    local.get 145
    i32.add
    local.set 279
    local.get 149
    local.get 279
    i32.ge_s
    i32.eqz
    br_if 2
    end
    i32.const 431
    local.set 195
    br 27
    end
    i32.const 400
    local.set 195
    br 26
    end
    end
    i32.const 1
    local.set 195
    br 24
    end
    end
    local.get 153
    local.get 143
    i32.gt_s
    i32.eqz
    br_if 6
    end
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    local.set 156
    end
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    local.set 279
    local.get 279
    i32.const 1
    i32.const 0
    local.get 143
    local.set 237
    local.set 236
    local.set 235
    local.set 234
    end
    loop
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 237
    local.get 153
    i32.lt_s
    if
    else
    local.get 234
    call $__sem_release_HeaderMap
    drop
    br 57
    end
    end
    end
    local.get 26
    local.get 237
    local.get 153
    call $http____token_end
    local.tee 249
    local.get 237
    i32.eq
    br_if 2
    end
    local.get 249
    local.get 153
    i32.ge_s
    br_if 1
    end
    local.get 26
    local.get 249
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 58
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.get 153
    local.set 264
    local.set 263
    br 13
    end
    end
    local.get 249
    i32.const 1
    i32.add
    local.set 250
    end
    local.get 26
    i32.const 13
    local.get 250
    call $__fern_memchr_bytes
    local.set 262
    local.get 262
    i32.const 0
    i32.lt_s
    br_if 1
    end
    local.get 262
    local.get 153
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 153
    local.set 251
    br 5
    end
    end
    local.get 262
    i32.const 1
    i32.add
    local.get 153
    i32.ge_s
    br_if 1
    end
    local.get 262
    i32.const 1
    i32.add
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 279
    local.get 279
    i32.const 10
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.set 251
    br 1
    end
    local.get 262
    local.set 251
    end
    local.get 251
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const -1
    local.get 153
    local.set 264
    local.set 263
    br 1
    end
    local.get 249
    local.get 251
    local.set 264
    local.set 263
    end
    local.get 263
    i32.const 0
    i32.lt_s
    if
    local.get 234
    call $__sem_release_HeaderMap
    drop
    br 42
    else
    end
    end
    end
    local.get 236
    i32.const 1
    i32.add
    local.tee 238
    local.get 30
    i32.gt_s
    if
    local.get 234
    call $__sem_release_HeaderMap
    drop
    br 41
    else
    end
    end
    end
    local.get 238
    i32.const 1
    i32.sub
    local.set 239
    local.get 235
    i32.eqz
    br_if 5
    end
    local.get 156
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 239
    local.get 279
    i32.ge_s
    i32.eqz
    br_if 4
    end
    local.get 239
    i32.const 0
    i32.gt_s
    if
    local.get 234
    call $__sem_release_HeaderMap
    drop
    else
    br 2
    end
    end
    local.get 156
    call $__fern_rc_inc
    drop
    local.get 156
    local.get 239
    call $http____leading_fields
    local.set 240
    br 1
    end
    local.get 234
    local.set 240
    end
    local.get 240
    i32.const 0
    local.set 242
    local.set 241
    br 1
    end
    local.get 234
    local.get 235
    local.set 242
    local.set 241
    end
    i32.const -1
    local.set 243
    local.get 242
    i32.eqz
    br_if 1
    end
    local.get 239
    local.set 244
    br 1
    end
    local.get 243
    local.set 244
    end
    local.get 263
    i32.const 1
    i32.add
    local.set 252
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 252
    local.get 264
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 26
    local.get 252
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 253
    end
    local.get 253
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 258
    br 1
    end
    local.get 253
    i32.const 9
    i32.eq
    local.set 258
    end
    local.get 258
    i32.eqz
    br_if 2
    end
    local.get 252
    i32.const 1
    i32.add
    local.set 252
    br 0
    end
    end
    local.get 264
    local.set 254
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 254
    local.get 252
    i32.gt_s
    i32.eqz
    br_if 7
    end
    local.get 254
    i32.const 1
    i32.sub
    local.set 279
    local.get 26
    local.get 279
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 8
    i32.add
    i32.add
    i32.load8_u
    local.set 255
    end
    local.get 255
    i32.const 32
    i32.eq
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 259
    br 1
    end
    local.get 255
    i32.const 9
    i32.eq
    local.set 259
    end
    local.get 259
    i32.eqz
    br_if 2
    end
    local.get 254
    i32.const 1
    i32.sub
    local.set 254
    br 0
    end
    end
    local.get 244
    i32.const 0
    i32.ge_s
    i32.eqz
    br_if 3
    end
    local.get 156
    i32.const 16
    i32.add
    i32.load
    local.get 244
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 254
    local.get 252
    i32.sub
    local.set 280
    local.get 279
    local.get 280
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 156
    i32.const 16
    i32.add
    i32.load
    local.tee 256
    local.get 244
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 279
    i32.load
    local.set 280
    local.get 26
    local.get 252
    local.get 279
    i32.const 0
    local.get 280
    call $__fern_mismatch_bytes_str
    local.set 280
    local.get 279
    i32.load
    local.set 279
    local.get 280
    local.get 279
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 256
    local.get 244
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 279
    call $__fern_rc_inc
    drop
    local.get 279
    local.set 274
    br 5
    end
    end
    global.get $__cagg_base
    i32.const 872
    i32.add
    local.set 279
    local.get 26
    local.get 252
    local.get 279
    call $__fern_scan_set_bytes
    local.get 254
    i32.lt_s
    if
    local.get 241
    call $__sem_release_HeaderMap
    drop
    br 28
    else
    end
    end
    end
    local.get 26
    local.get 252
    local.get 254
    call $http____bytes_string
    local.tee 257
    call $utf8__is_valid
    if
    else
    local.get 241
    call $__sem_release_HeaderMap
    drop
    local.get 257
    call $__fern_arr_dec
    drop
    br 27
    end
    end
    local.get 257
    local.set 274
    end
    local.get 242
    i32.eqz
    br_if 6
    end
    local.get 156
    i32.const 8
    i32.add
    i32.load
    local.get 239
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 26
    local.get 237
    local.get 263
    local.get 279
    call $http____shared_string
    local.tee 245
    local.get 279
    call $__fern_streq
    i32.eqz
    br_if 1
    end
    local.get 156
    i32.const 16
    i32.add
    i32.load
    local.get 239
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 274
    local.get 279
    call $__fern_streq
    local.set 246
    br 1
    end
    i32.const 0
    local.set 246
    end
    local.get 246
    if
    local.get 245
    call $__fern_arr_dec
    drop
    local.get 274
    call $__fern_arr_dec
    drop
    else
    local.get 241
    call $__sem_release_HeaderMap
    drop
    br 2
    end
    end
    local.get 241
    local.get 246
    local.set 248
    local.set 247
    br 2
    end
    local.get 156
    call $__fern_rc_inc
    drop
    local.get 156
    local.get 239
    call $http____leading_fields
    local.tee 279
    call $__fern_rc_is_unique
    if
    local.get 279
    local.set 276
    else
    i32.const 0
    local.set 276
    end
    local.get 279
    i32.const 8
    i32.add
    i32.load
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 280
    call $__fern_rc_inc
    drop
    end
    local.get 280
    call $__fern_rc_is_unique
    if
    local.get 280
    local.get 245
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 280
    local.get 245
    call $__fern_arr_push
    local.set 277
    local.get 280
    call $__fern_arr_inc_elems
    drop
    local.get 280
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 280
    local.get 279
    i32.const 16
    i32.add
    i32.load
    local.set 281
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 281
    call $__fern_rc_inc
    drop
    end
    local.get 281
    call $__fern_rc_is_unique
    if
    local.get 281
    local.get 274
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 281
    local.get 274
    call $__fern_arr_push
    local.set 277
    local.get 281
    call $__fern_arr_inc_elems
    drop
    local.get 281
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 281
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 276
    i32.const 3
    call $__fern_alloc_reuse
    local.tee 260
    local.tee 284
    local.get 284
    global.get $__tid$HeaderMap
    i32.store
    drop
    else
    local.get 276
    local.set 260
    end
    local.get 276
    i32.const 0
    i32.ne
    if
    else
    local.get 279
    call $__sem_release_HeaderMap
    drop
    end
    i32.const 0
    local.set 279
    local.get 260
    local.get 280
    local.set 285
    i32.const 8
    i32.add
    local.get 285
    i32.store
    local.get 260
    local.get 281
    local.set 285
    i32.const 16
    i32.add
    local.get 285
    i32.store
    local.get 260
    local.get 246
    local.set 248
    local.set 247
    br 1
    end
    local.get 26
    local.get 237
    local.get 263
    call $http____bytes_string
    local.set 279
    local.get 241
    call $__fern_rc_is_unique
    if
    local.get 241
    local.set 276
    else
    i32.const 0
    local.set 276
    end
    local.get 241
    i32.const 8
    i32.add
    i32.load
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 280
    call $__fern_rc_inc
    drop
    end
    local.get 280
    call $__fern_rc_is_unique
    if
    local.get 280
    local.get 279
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 280
    local.get 279
    call $__fern_arr_push
    local.set 277
    local.get 280
    call $__fern_arr_inc_elems
    drop
    local.get 280
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 279
    local.get 241
    i32.const 16
    i32.add
    i32.load
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 280
    call $__fern_rc_inc
    drop
    end
    local.get 280
    call $__fern_rc_is_unique
    if
    local.get 280
    local.get 274
    call $__fern_arr_push_owned
    local.set 277
    else
    local.get 280
    local.get 274
    call $__fern_arr_push
    local.set 277
    local.get 280
    call $__fern_arr_inc_elems
    drop
    local.get 280
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 276
    i32.const 3
    call $__fern_alloc_reuse
    local.tee 261
    local.tee 284
    local.get 284
    global.get $__tid$HeaderMap
    i32.store
    drop
    else
    local.get 276
    local.set 261
    end
    local.get 276
    i32.const 0
    i32.ne
    if
    else
    local.get 241
    call $__sem_release_HeaderMap
    drop
    end
    i32.const 0
    local.set 241
    local.get 261
    local.get 279
    local.set 285
    i32.const 8
    i32.add
    local.get 285
    i32.store
    local.get 261
    local.get 280
    local.set 285
    i32.const 16
    i32.add
    local.get 285
    i32.store
    local.get 261
    local.get 242
    local.set 248
    local.set 247
    end
    end
    local.get 264
    i32.const 2
    i32.add
    local.set 279
    local.get 247
    local.get 248
    local.get 238
    local.get 279
    local.set 237
    local.set 236
    local.set 235
    local.set 234
    br 0
    end
    end
    local.get 235
    i32.eqz
    br_if 5
    end
    local.get 156
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 236
    local.get 279
    i32.eq
    i32.eqz
    br_if 4
    end
    br 7
    end
    br 8
    end
    i32.const 400
    local.set 275
    br 12
    end
    i32.const 431
    local.set 275
    br 11
    end
    end
    local.get 235
    i32.eqz
    br_if 1
    end
    local.get 156
    local.get 236
    call $http____leading_fields
    call $__sem_release_HeaderMap
    drop
    br 1
    end
    end
    end
    end
    local.get 153
    i32.const 4
    i32.add
    drop
    i32.const 2
    local.set 195
    br 6
    end
    br 1
    end
    end
    end
    i32.const 400
    local.set 275
    end
    end
    local.get 275
    local.set 195
    end
    local.get 195
    i32.const 2
    i32.ne
    if
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 142
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    local.get 195
    local.set 196
    br 7
    end
    end
    i32.const 2
    local.set 133
    end
    i32.const 0
    i32.const 1
    local.set 135
    local.set 134
    end
    loop
    block
    local.get 142
    i32.load
    local.set 279
    local.get 135
    local.get 279
    i32.lt_s
    i32.eqz
    br_if 2
    end
    local.get 142
    local.get 135
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 134
    local.get 279
    i32.add
    local.set 279
    local.get 135
    i32.const 2
    i32.add
    local.set 280
    local.get 279
    local.get 280
    local.set 135
    local.set 134
    br 0
    end
    end
    local.get 134
    local.set 285
    local.get 285
    i32.eqz
    if (result i32)
    global.get $__cagg_base
    i32.const 328
    i32.add
    else
    local.get 285
    i32.const 1
    call $__fern_arr_elems
    local.set 284
    local.get 284
    local.get 285
    i32.store
    local.get 284
    i32.const 4
    i32.add
    local.get 285
    i32.store
    local.get 284
    i32.const 8
    i32.add
    i32.const 0
    local.get 285
    memory.fill
    local.get 284
    end
    local.set 279
    i32.const 0
    local.get 279
    i32.const 0
    local.set 138
    local.set 137
    local.set 136
    end
    loop
    block
    local.get 136
    i32.const 1
    i32.add
    local.set 279
    local.get 142
    i32.load
    local.set 280
    local.get 279
    local.get 280
    i32.lt_s
    if
    else
    local.get 26
    call $__fern_arr_dec
    drop
    local.get 137
    call $__fern_arr_dec
    drop
    local.get 142
    call $__fern_arr_dec
    drop
    br 3
    end
    end
    local.get 26
    local.set 279
    local.get 136
    i32.const 1
    i32.add
    local.set 280
    local.get 136
    i32.const 31
    i32.shr_s
    local.set 281
    local.get 280
    local.get 281
    i32.or
    local.set 280
    local.get 142
    local.get 280
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    i32.const 0
    drop
    local.get 142
    local.get 136
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 280
    local.get 136
    i32.const 1
    i32.add
    local.set 281
    local.get 142
    local.get 281
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 281
    local.get 137
    local.get 138
    local.get 279
    local.get 280
    local.get 281
    call $__fern_bytes_into
    local.set 279
    local.get 136
    i32.const 1
    i32.add
    local.set 280
    local.get 142
    local.get 280
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 280
    local.get 138
    local.get 280
    i32.add
    local.set 280
    local.get 136
    i32.const 2
    i32.add
    local.get 279
    local.get 280
    local.set 138
    local.set 137
    local.set 136
    br 0
    end
    end
    local.get 133
    local.set 196
    end
    local.get 196
    i32.const 2
    i32.ne
    if
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 273
    call $__sem_release_HeaderMap
    drop
    br 58
    else
    end
    end
    end
    end
    global.get $__str_base
    i32.const 2528
    i32.add
    local.get 131
    call $__fern_strcat
    local.set 279
    local.get 131
    call $__fern_arr_dec
    drop
    local.get 279
    i32.const 16
    call $__fern_str_box
    local.set 284
    local.get 284
    global.get $__tid$Body$BodyText
    i32.store
    local.set 285
    local.get 284
    i32.const 8
    i32.add
    local.get 285
    i32.store
    local.get 284
    local.set 279
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    local.set 280
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    local.set 281
    global.get $__cagg_base
    i32.const 368
    i32.add
    local.set 282
    i32.const 200
    local.get 279
    local.get 280
    local.get 281
    local.get 282
    i32.const 48
    call $__fern_str_box
    local.set 284
    local.get 284
    global.get $__tid$HttpResponse
    i32.store
    local.set 285
    local.get 284
    i32.const 40
    i32.add
    local.get 285
    i32.store
    local.set 285
    local.get 284
    i32.const 32
    i32.add
    local.get 285
    i32.store
    local.set 285
    local.get 284
    i32.const 24
    i32.add
    local.get 285
    i32.store
    local.set 285
    local.get 284
    i32.const 16
    i32.add
    local.get 285
    i32.store
    local.set 285
    local.get 284
    i32.const 8
    i32.add
    local.get 285
    i32.store
    local.get 284
    local.set 4
    end
    end
    global.get $__str_base
    i32.const 2540
    i32.add
    local.set 5
    i32.const 200
    local.get 4
    local.set 13
    local.set 25
    end
    loop
    block
    block
    local.get 13
    i32.const 24
    i32.add
    i32.load
    call $http__fields_ok
    if
    else
    local.get 13
    call $__sem_release_HttpResponse
    drop
    br 2
    end
    end
    local.get 13
    i32.const 32
    i32.add
    i32.load
    call $http__fields_ok
    if
    br 3
    else
    local.get 13
    call $__sem_release_HttpResponse
    drop
    end
    end
    global.get $__cagg_base
    i32.const 344
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 8
    i32.add
    drop
    global.get $__cagg_base
    i32.const 24
    i32.add
    drop
    global.get $__cagg_base
    i32.const 368
    i32.add
    drop
    global.get $__cagg_base
    i32.const 384
    i32.add
    local.set 279
    i32.const 500
    local.get 279
    local.set 13
    local.set 25
    br 0
    end
    end
    end
    end
    local.get 25
    i32.const 200
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 14
    br 1
    end
    local.get 25
    i32.const 204
    i32.eq
    local.set 14
    end
    local.get 14
    i32.eqz
    br_if 1
    end
    i32.const 1
    local.set 15
    br 1
    end
    local.get 25
    i32.const 304
    i32.eq
    local.set 15
    end
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 7
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 8
    local.get 15
    i32.eqz
    br_if 1
    end
    local.get 7
    local.get 8
    local.set 10
    local.set 9
    br 1
    end
    local.get 13
    call $HttpResponse.body_text_lossy
    local.set 279
    global.get $__str_base
    i32.const 44
    i32.add
    local.set 280
    local.get 279
    i32.load
    call $int__int_to_string
    local.set 281
    local.get 280
    local.get 281
    call $__fern_strcat
    local.set 280
    local.get 281
    call $__fern_arr_dec
    drop
    global.get $__str_base
    i32.const 64
    i32.add
    local.set 281
    local.get 280
    local.get 281
    call $__fern_str_grow
    if
    local.get 280
    local.set 277
    else
    local.get 280
    local.get 281
    call $__fern_str_grow_fresh
    local.set 277
    local.get 280
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.get 279
    local.set 10
    local.set 9
    end
    i32.const 256
    call $__fern_buf_new
    local.set 11
    end
    end
    global.get $__str_base
    i32.const 72
    i32.add
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 25
    i64.extend_i32_s
    local.set 16
    end
    local.get 16
    i64.const 0
    i64.lt_s
    i32.eqz
    br_if 1
    end
    local.get 11
    i32.const 45
    call $__fern_buf_push_byte
    i32.const 0
    drop
    local.get 16
    local.set 283
    i64.const 0
    local.get 283
    i64.sub
    local.set 283
    local.get 11
    local.get 283
    call $__fern_buf_push_decimal
    i32.const 0
    drop
    br 2
    end
    end
    local.get 16
    local.set 283
    local.get 11
    local.get 283
    call $__fern_buf_push_decimal
    i32.const 0
    drop
    end
    global.get $__str_base
    i32.const 88
    i32.add
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    end
    end
    global.get $__cagg_base
    i32.const 440
    i32.add
    local.set 22
    global.get $__cagg_base
    i32.const 656
    i32.add
    local.set 23
    i32.const 0
    local.set 24
    end
    loop
    block
    block
    block
    local.get 22
    i32.load
    local.set 279
    local.get 24
    local.get 279
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 22
    local.get 24
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.get 25
    i32.eq
    br_if 4
    end
    end
    local.get 24
    i32.const 1
    i32.add
    local.set 24
    br 0
    end
    end
    global.get $__str_base
    i32.const 40
    i32.add
    local.set 21
    br 1
    end
    local.get 23
    local.get 24
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 279
    call $__fern_rc_inc
    drop
    local.get 279
    local.set 21
    end
    local.get 21
    i32.load
    local.set 279
    local.get 279
    i32.const 0
    i32.eq
    if
    local.get 21
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    global.get $__str_base
    i32.const 1140
    i32.add
    local.set 17
    br 1
    end
    local.get 21
    local.set 17
    end
    local.get 11
    local.get 17
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 17
    call $__fern_arr_dec
    drop
    global.get $__str_base
    i32.const 64
    i32.add
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    i32.const 0
    local.set 18
    end
    loop
    block
    block
    block
    block
    block
    block
    local.get 13
    i32.const 24
    i32.add
    i32.load
    i32.const 8
    i32.add
    i32.load
    i32.load
    local.set 279
    local.get 18
    local.get 279
    i32.lt_s
    if
    else
    local.get 13
    call $__sem_release_HttpResponse
    drop
    br 8
    end
    end
    local.get 13
    i32.const 24
    i32.add
    i32.load
    local.tee 19
    i32.const 8
    i32.add
    i32.load
    local.get 18
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 20
    global.get $__str_base
    i32.const 1152
    i32.add
    local.set 279
    local.get 20
    local.get 279
    call $string.eq_ignore_ascii_case
    br_if 2
    end
    global.get $__str_base
    i32.const 1172
    i32.add
    local.set 279
    local.get 20
    local.get 279
    call $string.eq_ignore_ascii_case
    br_if 1
    end
    global.get $__str_base
    i32.const 1188
    i32.add
    local.set 279
    local.get 20
    local.get 279
    call $string.eq_ignore_ascii_case
    i32.eqz
    br_if 1
    end
    br 1
    end
    local.get 19
    i32.const 8
    i32.add
    i32.load
    local.get 18
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    global.get $__str_base
    i32.const 1212
    i32.add
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 19
    i32.const 16
    i32.add
    i32.load
    local.get 18
    local.set 288
    local.tee 284
    i32.load
    local.get 288
    i32.le_u
    if
      call $__fern_abort_arr
      unreachable
    end
    local.get 284
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    global.get $__str_base
    i32.const 64
    i32.add
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    end
    local.get 18
    i32.const 1
    i32.add
    local.set 18
    br 0
    end
    end
    end
    local.get 11
    local.get 9
    call $__fern_buf_push
    i32.const 0
    drop
    local.get 9
    call $__fern_arr_dec
    drop
    end
    local.get 25
    i32.const 101
    i32.eq
    i32.eqz
    br_if 1
    end
    global.get $__str_base
    i32.const 1220
    i32.add
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    br 5
    end
    end
    end
    end
    global.get $__str_base
    i32.const 1248
    i32.add
    local.set 279
    local.get 11
    local.get 279
    call $__fern_buf_push
    i32.const 0
    drop
    end
    end
    end
    local.get 11
    call $__fern_buf_take
    local.set 12
    local.get 11
    call $__fern_buf_free
    i32.const 0
    drop
    local.get 15
    if
    local.get 10
    call $__fern_arr_dec
    drop
    br 2
    else
    end
    end
    global.get $__str_base
    i32.const 1308
    i32.add
    local.set 279
    i32.const 0
    local.set 277
    local.get 5
    i32.load
    i32.const 4
    i32.eq
    if
    local.get 5
    local.get 279
    call $__fern_streq
    local.set 277
    end
    local.get 277
    if
    local.get 10
    call $__fern_arr_dec
    drop
    else
    br 2
    end
    end
    local.get 12
    local.set 6
    br 2
    end
    end
    local.get 12
    local.get 10
    call $__fern_str_grow
    if
    local.get 12
    local.set 277
    else
    local.get 12
    local.get 10
    call $__fern_str_grow_fresh
    local.set 277
    local.get 12
    call $__fern_arr_dec
    drop
    end
    local.get 277
    local.set 279
    local.get 10
    call $__fern_arr_dec
    drop
    local.get 279
    local.set 6
    end
    end
    end
    local.get 6
    i32.load
    local.set 279
    local.get 6
    call $__fern_arr_dec
    drop
    local.get 273
    call $__fern_rc_is_unique
    if
    local.get 273
    local.set 276
    else
    i32.const 0
    local.set 276
    end
    local.get 273
    i32.const 8
    i32.add
    i32.load
    local.set 280
    local.get 276
    i32.const 0
    i32.eq
    if
    local.get 280
    call $__fern_rc_inc
    drop
    end
    local.get 276
    i32.const 0
    i32.ne
    if
    local.get 273
    i32.const 16
    i32.add
    i32.load
    local.tee 277
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 278
    block
    loop
    local.get 278
    local.get 277
    i32.load
    i32.ge_s
    br_if 1
    local.get 277
    local.get 278
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    local.get 278
    i32.const 1
    i32.add
    local.set 278
    br 0
    end
    end
    end
    local.get 277
    call $__fern_arr_dec
    drop
    local.get 273
    call $__fern_arr_dec
    drop
    else
    local.get 273
    call $__sem_release_HeaderMap
    drop
    end
    local.get 280
    i32.load
    local.set 281
    local.get 280
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 277
    block
    loop
    local.get 277
    local.get 280
    i32.load
    i32.ge_s
    br_if 1
    local.get 280
    local.get 277
    local.set 288
    local.get 288
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    local.tee 278
    call $__fern_arr_dec
    drop
    local.get 277
    i32.const 1
    i32.add
    local.set 277
    br 0
    end
    end
    end
    local.get 280
    call $__fern_arr_dec
    drop
    local.get 279
    local.get 281
    i32.add
    i64.extend_i32_s
    local.set 283
    local.get 1
    local.get 283
    i64.add
    local.set 3
    end
    local.get 2
    i32.const 1
    i32.add
    local.set 279
    local.get 3
    local.get 279
    local.set 2
    local.set 1
    br 0
    end
    end
    local.get 1
    i64.const 97
    call $__fern_irem64
    i32.wrap_i64
    return
    end
    end
    local.get 196
    i32.const 400
    i32.ge_s
    i32.eqz
    br_if 1
    end
    local.get 200
    local.set 271
    br 31
    end
    end
    global.get $__str_base
    i32.const 2420
    i32.add
    local.set 279
    i32.const 0
    local.set 277
    local.get 44
    i32.load
    i32.const 8
    i32.eq
    if
    local.get 44
    local.get 279
    call $__fern_streq
    local.set 277
    end
    local.get 277
    i32.eqz
    i32.eqz
    br_if 2
    end
    local.get 45
    i32.const 1
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 201
    local.set 271
    br 27
    end
    br 29
    end
    i32.const 1
    local.set 270
    br 20
    end
    local.get 36
    local.set 270
    br 19
    end
    local.get 126
    local.set 270
    br 18
    end
    i32.const 1
    local.set 270
    br 17
    end
    local.get 46
    local.set 270
    br 16
    end
    i32.const 400
    local.set 270
    br 15
    end
    i32.const 400
    local.set 270
    br 14
    end
    i32.const 400
    local.set 270
    br 13
    end
    i32.const 501
    local.set 270
    br 12
    end
    br 3
    end
    br 2
    end
    br 1
    end
    end
    end
    i32.const 400
    local.set 270
    br 6
    end
    i32.const 400
    local.set 270
    br 5
    end
    i32.const 431
    local.set 270
    br 4
    end
    br 1
    end
    end
    end
    i32.const 400
    local.set 270
    end
    end
    end
    local.get 270
    i32.const 1
    i32.eq
    i32.eqz
    br_if 1
    end
    br 4
    end
    local.get 202
    local.set 271
    end
    local.get 271
    i32.eqz
    br_if 1
    end
    br 1
    end
    end
    end
    i32.const 100
    return
    i32.const 0)
  (func $__sem_drop_HeaderMap (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 2
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 1
    block
    loop
    local.get 1
    local.get 2
    i32.load
    i32.ge_s
    br_if 1
    local.get 2
    local.get 1
    local.set 7
    local.get 7
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    local.get 1
    i32.const 1
    i32.add
    local.set 1
    br 0
    end
    end
    end
    local.get 2
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.tee 2
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 1
    block
    loop
    local.get 1
    local.get 2
    i32.load
    i32.ge_s
    br_if 1
    local.get 2
    local.get 1
    local.set 7
    local.get 7
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    local.get 1
    i32.const 1
    i32.add
    local.set 1
    br 0
    end
    end
    end
    local.get 2
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_HeaderMap (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_HeaderMap
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_HttpResponse (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 16
    i32.add
    i32.load
    call $__sem_release_Body
    drop
    local.get 0
    i32.const 24
    i32.add
    i32.load
    call $__sem_release_HeaderMap
    drop
    local.get 0
    i32.const 32
    i32.add
    i32.load
    call $__sem_release_HeaderMap
    drop
    local.get 0
    i32.const 40
    i32.add
    i32.load
    call $__sem_release_Option$$fn$void
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_HttpResponse (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_HttpResponse
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_ByteStream (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 8
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 24
    i32.add
    i32.load
    call $__sem_release_Option$BodySource
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_ByteStream (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_ByteStream
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_ChunkProducer (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 8
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 24
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 32
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_ChunkProducer (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_ChunkProducer
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_BodySource (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 1
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.tee 1
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 2
    block
    loop
    local.get 2
    local.get 1
    i32.load
    i32.ge_s
    br_if 1
    local.get 1
    local.get 2
    local.set 7
    local.get 7
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    call $__sem_release_Option$StreamFault
    drop
    local.get 2
    i32.const 1
    i32.add
    local.set 2
    br 0
    end
    end
    end
    local.get 1
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 24
    i32.add
    i32.load
    local.tee 1
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_BodySource (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_BodySource
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_Body (param i32) (result i32)
    (local i32 i32 i32 i32 f64 i64 i32)
    local.get 0
    i32.load
    global.get $__tid$Body$BodyText
    i32.eq
    if
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 1
    call $__fern_arr_dec
    drop
    else
    local.get 0
    i32.load
    global.get $__tid$Body$BodyBytes
    i32.eq
    if
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 1
    call $__fern_arr_dec
    drop
    else
    local.get 0
    i32.load
    global.get $__tid$Body$BodyStream
    i32.eq
    if
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 1
    call $__sem_release_ByteStream
    drop
    else
    local.get 0
    i32.load
    global.get $__tid$Body$BodyFile
    i32.eq
    if
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 1
    call $__fern_arr_dec
    drop
    else
    local.get 0
    i32.load
    global.get $__tid$Body$BodyChunks
    i32.eq
    if
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 1
    call $__sem_release_ChunkProducer
    drop
    else
    local.get 0
    i32.load
    global.get $__tid$Body$BodyFileRanges
    i32.eq
    if
    local.get 0
    i32.const 8
    i32.add
    i32.load
    local.tee 1
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 16
    i32.add
    i32.load
    local.tee 1
    call $__fern_arr_dec
    drop
    local.get 0
    i32.const 24
    i32.add
    i32.load
    local.tee 1
    call $__fern_rc_is_unique
    if
    i32.const 0
    local.set 2
    block
    loop
    local.get 2
    local.get 1
    i32.load
    i32.ge_s
    br_if 1
    local.get 1
    local.get 2
    local.set 7
    local.get 7
    i32.const 4
    i32.mul
    i32.const 8
    i32.add
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    local.get 2
    i32.const 1
    i32.add
    local.set 2
    br 0
    end
    end
    end
    local.get 1
    call $__fern_arr_dec
    drop
    end
    end
    end
    end
    end
    end
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_Body (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_Body
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_Option$$fn$void (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.load
    i32.const 0
    i32.eq
    if
    local.get 0
    i32.const 4
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    end
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_Option$$fn$void (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_Option$$fn$void
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_Option$BodySource (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.load
    i32.const 0
    i32.eq
    if
    local.get 0
    i32.const 4
    i32.add
    i32.load
    call $__sem_release_BodySource
    drop
    end
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_Option$BodySource (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_Option$BodySource
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_drop_Option$StreamFault (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.load
    i32.const 0
    i32.eq
    if
    local.get 0
    i32.const 4
    i32.add
    i32.load
    call $__fern_arr_dec
    drop
    end
    i32.const 0
    return
    i32.const 0)
  (func $__sem_release_Option$StreamFault (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    call $__fern_rc_is_unique
    if
    local.get 0
    call $__sem_drop_Option$StreamFault
    drop
    end
    local.get 0
    call $__fern_arr_dec
    drop
    i32.const 0
    return
    i32.const 0)
  (func $__sem_view_len (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 2
    local.get 2
    i32.const 1
    i32.and
    i32.const 3
    i32.mul
    i32.add
    i32.load
    i32.const 2147483647
    i32.and
    return
    end
    local.get 0
    i32.load
    return
    i32.const 0)
  (func $__sem_view_data (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.tee 2
    i32.const 1
    i32.and
    if (result i32)
    local.get 2
    i32.const 1
    i32.sub
    i32.load
    else
    local.get 2
    i32.load
    i32.const 0
    i32.lt_s
    if (result i32)
    local.get 2
    i32.const 4
    i32.add
    i32.load
    else
    local.get 2
    i32.const 4
    i32.add
    end
    end
    return
    end
    local.get 0
    i32.const 8
    i32.add
    return
    i32.const 0)
  (func $__sem_byte_view_slice (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 1
    i32.const 0
    i32.lt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 2
    local.get 1
    i32.lt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 2
    local.get 0
    call $__sem_view_len
    i32.gt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 0
    call $__sem_view_data
    local.get 1
    i32.add
    local.get 2
    local.get 1
    i32.sub
    call $__fern_str_borrow
    i32.const 2
    i32.add
    return
    i32.const 0)
  (func $__sem_view_slice (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 1
    i32.const 0
    i32.lt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 2
    local.get 1
    i32.lt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 2
    local.get 0
    call $__sem_view_len
    i32.gt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 0
    call $__sem_view_data
    local.get 1
    i64.extend_i32_u
    i32.const 4
    i64.extend_i32_u
    i64.mul
    i32.wrap_i64
    i32.add
    local.get 2
    local.get 1
    i32.sub
    call $__fern_str_borrow
    i32.const 2
    i32.add
    return
    i32.const 0)
  (func $__sem_view_slice_wide (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 1
    i32.const 0
    i32.lt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 2
    local.get 1
    i32.lt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 2
    local.get 0
    call $__sem_view_len
    i32.gt_s
    if
    call $__fern_slice_abort
    drop
    end
    local.get 0
    call $__sem_view_data
    local.get 1
    i64.extend_i32_u
    i64.const 8
    i64.mul
    i32.wrap_i64
    i32.add
    local.get 2
    local.get 1
    i32.sub
    call $__fern_str_borrow
    i32.const 2
    i32.add
    return
    i32.const 0)
  (func $__sem_view_release (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    call $__fern_arr_dec
    return
    end
    local.get 0
    call $__fern_arr_dec
    return
    i32.const 0)
  (func $__sem_byte_view_string (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    global.get $__str_base
    i32.const 40
    i32.add
    call $__fern_strcat
    return
    end
    local.get 0
    call $__fern_string_from_bytes
    return
    i32.const 0)
  (func $__sem_byte_view_mismatch (param i32) (param i32) (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 f64 i64 i32)
    local.get 0
    i32.const 2
    i32.and
    if
    local.get 2
    i32.const 2
    i32.and
    if
    local.get 0
    i32.const -2
    i32.add
    local.get 1
    local.get 2
    i32.const -2
    i32.add
    local.get 3
    local.get 4
    call $__fern_mismatch
    return
    end
    local.get 2
    local.get 3
    local.get 0
    i32.const -2
    i32.add
    local.get 1
    local.get 4
    call $__fern_mismatch_bytes_str
    return
    end
    local.get 2
    i32.const 2
    i32.and
    if
    local.get 0
    local.get 1
    local.get 2
    i32.const -2
    i32.add
    local.get 3
    local.get 4
    call $__fern_mismatch_bytes_str
    return
    end
    local.get 0
    local.get 1
    local.get 2
    local.get 3
    local.get 4
    call $__fern_mismatch_bytes
    return
    i32.const 0)
  (func $__fern_streq (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.load
    local.set 2
    local.get 1
    i32.load
    local.set 4
    local.get 2
    local.get 4
    i32.ne
    i32.eqz
    br_if 1
    end
    i32.const 0
    return
    end
    end
    i32.const 0
    local.set 3
    end
    local.get 0
    i32.const 4
    i32.add
    local.set 4
    local.get 1
    i32.const 4
    i32.add
    local.set 5
    loop
    block
    block
    block
    local.get 3
    local.get 2
    i32.lt_u
    i32.eqz
    br_if 4
    end
    local.get 3
    i64.extend_i32_u
    i32.wrap_i64
    local.set 6
    local.get 4
    local.get 6
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.set 6
    local.get 3
    i64.extend_i32_u
    i32.wrap_i64
    local.set 7
    local.get 5
    local.get 7
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.set 7
    local.get 6
    local.get 7
    i32.ne
    br_if 4
    end
    end
    local.get 3
    i32.const 1
    i32.add
    local.set 3
    br 0
    end
    end
    i32.const 1
    return
    end
    i32.const 0
    return
    i32.const 0)
  (func $__fern_utf8_step (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 0
    i32.const 4
    i32.add
    local.set 9
    local.get 1
    i64.extend_i32_s
    i32.wrap_i64
    local.set 10
    local.get 9
    local.get 10
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.set 3
    local.get 3
    i32.const 194
    i32.lt_s
    br_if 2
    end
    local.get 3
    i32.const 244
    i32.gt_s
    br_if 1
    end
    local.get 1
    i32.const 1
    i32.add
    local.get 2
    i32.ge_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    local.get 0
    i32.const 4
    i32.add
    local.set 9
    local.get 1
    i64.extend_i32_s
    i32.wrap_i64
    local.set 10
    local.get 9
    local.get 10
    i32.add
    local.set 9
    local.get 9
    i32.const 1
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.set 4
    local.get 4
    i32.const 128
    i32.lt_s
    br_if 1
    end
    local.get 4
    i32.const 191
    i32.gt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    local.get 3
    i32.const 224
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 2
    return
    end
    end
    local.get 3
    i32.const 224
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 4
    i32.const 160
    i32.lt_s
    br_if 2
    end
    local.get 3
    i32.const 237
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 4
    i32.const 159
    i32.gt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 3
    local.set 5
    local.get 3
    i32.const 240
    i32.ge_s
    i32.eqz
    br_if 7
    end
    local.get 3
    i32.const 240
    i32.eq
    i32.eqz
    br_if 1
    end
    local.get 4
    i32.const 144
    i32.lt_s
    br_if 2
    end
    local.get 3
    i32.const 244
    i32.eq
    i32.eqz
    br_if 2
    end
    local.get 4
    i32.const 143
    i32.gt_s
    i32.eqz
    br_if 1
    end
    i32.const 1
    return
    end
    end
    i32.const 4
    local.set 6
    br 1
    end
    local.get 5
    local.set 6
    end
    i32.const 2
    local.set 7
    end
    local.get 0
    i32.const 4
    i32.add
    local.set 9
    loop
    block
    block
    block
    block
    block
    block
    local.get 7
    local.get 6
    i32.lt_s
    i32.eqz
    br_if 7
    end
    local.get 1
    local.get 7
    i32.add
    local.get 2
    i32.ge_s
    br_if 7
    end
    end
    local.get 1
    i64.extend_i32_s
    i32.wrap_i64
    local.set 10
    local.get 9
    local.get 10
    i32.add
    local.set 10
    local.get 7
    i64.extend_i32_s
    i32.wrap_i64
    local.set 11
    local.get 10
    local.get 11
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.set 8
    local.get 8
    i32.const 128
    i32.lt_s
    br_if 6
    end
    local.get 8
    i32.const 191
    i32.gt_s
    br_if 5
    end
    end
    local.get 7
    i32.const 1
    i32.add
    local.set 7
    br 0
    end
    end
    local.get 6
    return
    end
    local.get 7
    return
    end
    local.get 7
    return
    i32.const 0)
  (func $__fern_memchr_bytes (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    block
    block
    block
    local.get 1
    local.set 5
    local.get 5
    i32.const 255
    i32.gt_u
    i32.eqz
    br_if 1
    end
    i32.const -1
    return
    end
    end
    local.get 0
    i32.load
    local.set 3
    local.get 2
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 4
    br 1
    end
    local.get 2
    local.set 4
    end
    local.get 0
    i32.const 8
    i32.add
    local.set 5
    loop
    block
    block
    block
    local.get 4
    local.get 3
    i32.lt_s
    i32.eqz
    br_if 4
    end
    local.get 4
    i64.extend_i32_s
    i32.wrap_i64
    local.set 6
    local.get 5
    local.get 6
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.get 1
    i32.eq
    br_if 4
    end
    end
    local.get 4
    i32.const 1
    i32.add
    local.set 4
    br 0
    end
    end
    i32.const -1
    return
    end
    local.get 4
    return
    i32.const 0)
  (func $__fern_scan_set (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    local.get 0
    i32.load
    local.set 3
    local.get 2
    i32.load
    local.set 4
    local.get 1
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 5
    br 1
    end
    local.get 1
    local.set 5
    end
    local.get 0
    i32.const 4
    i32.add
    local.set 7
    local.get 2
    i32.const 8
    i32.add
    local.set 8
    loop
    block
    block
    block
    block
    block
    local.get 5
    local.get 3
    i32.lt_s
    i32.eqz
    br_if 6
    end
    local.get 5
    i64.extend_i32_s
    i32.wrap_i64
    local.set 9
    local.get 7
    local.get 9
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.tee 6
    local.get 4
    i32.lt_u
    i32.eqz
    br_if 2
    end
    local.get 6
    i64.extend_i32_u
    i32.wrap_i64
    local.set 9
    local.get 8
    local.get 9
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.set 9
    local.get 9
    i32.const 0
    i32.eq
    i32.eqz
    br_if 5
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 5
    br 2
    end
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 5
    br 0
    end
    end
    local.get 3
    return
    end
    local.get 5
    return
    i32.const 0)
  (func $__fern_scan_set_bytes (param i32) (param i32) (param i32) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 f64 i64 i32)
    block
    block
    block
    block
    block
    local.get 0
    i32.load
    local.set 3
    local.get 2
    i32.load
    local.set 4
    local.get 1
    i32.const 0
    i32.lt_s
    i32.eqz
    br_if 1
    end
    i32.const 0
    local.set 5
    br 1
    end
    local.get 1
    local.set 5
    end
    local.get 0
    i32.const 8
    i32.add
    local.set 7
    local.get 2
    i32.const 8
    i32.add
    local.set 8
    loop
    block
    block
    block
    block
    block
    local.get 5
    local.get 3
    i32.lt_s
    i32.eqz
    br_if 6
    end
    local.get 5
    i64.extend_i32_s
    i32.wrap_i64
    local.set 9
    local.get 7
    local.get 9
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.tee 6
    local.get 4
    i32.lt_u
    i32.eqz
    br_if 2
    end
    local.get 6
    i64.extend_i32_u
    i32.wrap_i64
    local.set 9
    local.get 8
    local.get 9
    i32.add
    i32.const 0
    i32.add
    i32.load8_u
    local.set 9
    local.get 9
    i32.const 0
    i32.eq
    i32.eqz
    br_if 5
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 5
    br 2
    end
    end
    local.get 5
    i32.const 1
    i32.add
    local.set 5
    br 0
    end
    end
    local.get 3
    return
    end
    local.get 5
    return
    i32.const 0)
  (func $__fern_start (call $__fern_proc_exit (i32.and (call $main) (i32.const 255))))
  (export "main" (func $main))
  (export "_start" (func $__fern_start)))
