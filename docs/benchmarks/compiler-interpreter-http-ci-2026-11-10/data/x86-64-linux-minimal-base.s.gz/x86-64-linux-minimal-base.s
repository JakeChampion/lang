    .globl _start
    .text
__fn_http____find_crlf:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____find_crlf.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____find_crlf_0:
    movl $13, %edi
    movq %rsi, %rdx
    movq %rdi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L0
    xorq %rdx, %rdx
.L0:
    cmpq $255, %rcx
    ja .L4
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L8
.L6:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L7
    addq $32, %r9
    cmpq %r10, %r9
    jle .L6
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L8
.L7:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L5
.L8:
    vzeroupper
.L1:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L3
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L2
    addq $16, %rdx
    jmp .L1
.L2:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L5
.L3:
    cmpq %r8, %rdx
    jge .L4
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L9
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L4
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L4
    addq %r9, %rdx
    jmp .L5
.L9:
    cmpq %r8, %rdx
    jge .L4
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L5
    addq $1, %rdx
    jmp .L9
.L4:
    movq $-1, %rdx
.L5:
    movq %rdx, %rax
.Lssa_http____find_crlf_3:
.Lssa_http____find_crlf_4:
    cmpq $0, %rax
    jl .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_8:
    leaq 1(%rax), %rdi
    movslq %edi, %rdi
    cmpq %r12, %rdi
    jge .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_7:
    leal 1(%rax), %edi
    cmpq (%rbx), %rdi
    jae __fern_oob_abort.l3
    movzbl 8(%rbx,%rdi), %esi
    cmpq $10, %rsi
    je .Lssa_http____find_crlf_1
.Lssa_http____find_crlf_5:
    leaq 1(%rax), %rsi
    movslq %esi, %rsi
    movl $13, %edi
    movq %rsi, %rdx
    movq %rdi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L10
    xorq %rdx, %rdx
.L10:
    cmpq $255, %rcx
    ja .L14
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L18
.L16:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L17
    addq $32, %r9
    cmpq %r10, %r9
    jle .L16
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L18
.L17:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L15
.L18:
    vzeroupper
.L11:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L13
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L12
    addq $16, %rdx
    jmp .L11
.L12:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L15
.L13:
    cmpq %r8, %rdx
    jge .L14
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L19
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L14
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L14
    addq %r9, %rdx
    jmp .L15
.L19:
    cmpq %r8, %rdx
    jge .L14
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L15
    addq $1, %rdx
    jmp .L19
.L14:
    movq $-1, %rdx
.L15:
    movq %rdx, %rax
    cmpq $0, %rax
    jge .Lssa_http____find_crlf_8
.Lssa_http____find_crlf_2:
    movq $-1, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____find_crlf_1:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____shared_string:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____shared_string.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
    movq %r8, %r14
.Lssa_http____shared_string_0:
    movq 8(%r14), %rsi
    movq %r13, %rdi
    subq %r12, %rdi
    movslq %edi, %rdi
    cmpq %rdi, %rsi
    jne .Lssa_http____shared_string_1
.Lssa_http____shared_string_4:
    movq 8(%r14), %rdi
    xorl %esi, %esi
    movq %rdi, %r8
    movq %rsi, %rcx
    movq %r14, %rdx
    movq %r12, %rsi
    movq %rbx, %rax
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L20_aop
    xorq %rsi, %rsi
.L20_aop:
    cmpq %r9, %rsi
    jle .L20_aok
    movq %r9, %rsi
.L20_aok:
    cmpq $0, %rcx
    jge .L20_bop
    xorq %rcx, %rcx
.L20_bop:
    cmpq %r10, %rcx
    jle .L20_bok
    movq %r10, %rcx
.L20_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L20_na
    movq %r9, %r8
.L20_na:
    cmpq %r10, %r8
    jle .L20_nb
    movq %r10, %r8
.L20_nb:
    cmpq $0, %r8
    jge .L20_nok
    xorq %r8, %r8
.L20_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L20_vec
    cmpq $8, %r8
    jge .L20_w8
    cmpq $4, %r8
    jge .L20_w4
    cmpq $2, %r8
    jge .L20_w2
    jmp .L20_tail
.L20_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L20_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L20_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L20_done
.L20_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L20_done
.L20_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L20_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L20_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L20_done
.L20_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L20_done
.L20_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L20_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L20_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L20_done
.L20_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L20_done
.L20_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L20_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L20_hit
    addq $16, %rdx
    jmp .L20_vec
.L20_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L20_done
.L20_tail:
    cmpq %r8, %rdx
    jge .L20_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L20_th
    addq $1, %rdx
    jmp .L20_tail
.L20_th:
    movq %rdx, %rax
    jmp .L20_done
.L20_eq:
    movq %r8, %rax
.L20_done:
    movq 8(%r14), %rsi
    cmpq %rsi, %rax
    sete %al
    movzbq %al, %rax
.Lssa_http____shared_string_9:
    testq %rax, %rax
    jz .Lssa_http____shared_string_1
.Lssa_http____shared_string_3:
    pushq %r14
    call __fn___fern_rc_inc
    addq $8, %rsp
    movq %r14, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____shared_string_1:
    movq %rbx, %rax
    movq %r12, %rsi
    movq %r13, %rdi
    call __fn___fern_string_from_bytes_range_u8.r
.Lssa_http____shared_string_15:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____token_is:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_http____token_is.r:
.Lssa_http____token_is_0:
    movq 8(%rax), %rdi
    xorl %r8d, %r8d
    xchgq %r8, %rsi
    jmp __fn_http____token_at.r
    .cfi_endproc
__fn_http____token_at:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____token_at.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rdi, %r12
    movq %r8, %r13
.Lssa_http____token_at_0:
.Lssa_http____token_at_10:
    movq %rsi, %r14
.Lssa_http____token_at_11:
    cmpq %r12, %r14
    jge .Lssa_http____token_at_24
.Lssa_http____token_at_13:
    cmpq 8(%rbx), %r14
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r14), %eax
    call __fn_http____is_ows.r
    testq %rax, %rax
    jz .Lssa_http____token_at_24
.Lssa_http____token_at_12:
    addq $1, %r14
    cmpq %r12, %r14
    jl .Lssa_http____token_at_13
.Lssa_http____token_at_8:
.Lssa_http____token_at_24:
    cmpq %r14, %r12
    jle .Lssa_http____token_at_7
.Lssa_http____token_at_26:
    leaq -1(%r12), %rsi
    cmpq 8(%rbx), %rsi
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rsi), %eax
    call __fn_http____is_ows.r
    testq %rax, %rax
    jz .Lssa_http____token_at_7
.Lssa_http____token_at_25:
    subq $1, %r12
    cmpq %r14, %r12
    jg .Lssa_http____token_at_26
.Lssa_http____token_at_7:
    subq %r14, %r12
    movslq %r12d, %r12
    movq 8(%r13), %rsi
    cmpq %rsi, %r12
    je .Lssa_http____token_at_4
.Lssa_http____token_at_6:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____token_at_4:
.Lssa_http____token_at_3:
    movq 8(%r13), %r11
    movq %r11, -48(%rbp)
    movq 0(%r13), %r15
    xorl %r13d, %r13d
.Lssa_http____token_at_41:
    cmpq -48(%rbp), %r13
    jge .Lssa_http____token_at_2
.Lssa_http____token_at_44:
    leal (%r14,%r13), %esi
    cmpq 8(%rbx), %rsi
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rsi), %eax
    call __fn_http____ascii_lower.r
    movq %rax, %r12
    movzbl (%r15,%r13), %eax
    call __fn_http____ascii_lower.r
    cmpq %rax, %r12
    jne .Lssa_http____token_at_1
.Lssa_http____token_at_42:
    addq $1, %r13
    cmpq -48(%rbp), %r13
    jl .Lssa_http____token_at_44
.Lssa_http____token_at_2:
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____token_at_1:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____is_ows:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http____is_ows.r:
.Lssa_http____is_ows_0:
    movl $1, %esi
    movq %rax, %rdi
    cmpq $9, %rdi
    sete %dil
    movzbq %dil, %rdi
    cmpq $32, %rax
    movq %rsi, %rax
    cmovneq %rdi, %rax
    ret
    .cfi_endproc
__fn_http____ascii_lower:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http____ascii_lower.r:
.Lssa_http____ascii_lower_0:
    cmpq $65, %rax
    jl .Lssa_http____ascii_lower_1
.Lssa_http____ascii_lower_3:
    cmpq $90, %rax
    jg .Lssa_http____ascii_lower_1
.Lssa_http____ascii_lower_2:
    leaq 32(%rax), %rsi
    movslq %esi, %rsi
    movq %rsi, %rax
    ret
.Lssa_http____ascii_lower_1:
    ret
    .cfi_endproc
__fn_http____parse_header_bytes:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn_http____parse_header_bytes.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $120, %rsp
    movq %rax, %rbx
    movq %rdi, -48(%rbp)
    movq %r8, -56(%rbp)
    movq %r9, -64(%rbp)
.Lssa_http____parse_header_bytes_0:
    leaq .K1(%rip), %rax
.Lssa_http____parse_header_bytes_15:
    movq %rax, -72(%rbp)
    movq %rsi, -96(%rbp)
    movq $1, -80(%rbp)
    movq $0, -88(%rbp)
.Lssa_http____parse_header_bytes_16:
    movq -96(%rbp), %r11
    cmpq -48(%rbp), %r11
    jge .Lssa_http____parse_header_bytes_14
.Lssa_http____parse_header_bytes_70:
    leaq .K2(%rip), %rsi
    movq %rsi, %rdx
    movq -96(%rbp), %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L21
    xorq %rcx, %rcx
.L21:
    leaq .S1(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L24
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L22:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L28
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L23
    addq $32, %r9
    jmp .L22
.L28:
    cmpq %r10, %r9
    jg .L29
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L23
    addq $16, %r9
.L29:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L24
.L23:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L27
.L24:
    cmpq %r8, %rcx
    jge .L26
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L25
    addq $1, %rcx
    jmp .L24
.L25:
    pushq %rcx
    jmp .L27
.L26:
    pushq %r8
.L27:
    popq %rax
    cmpq -48(%rbp), %rax
    movq -48(%rbp), %r8
    cmovleq %rax, %r8
    cmpq -96(%rbp), %r8
    je .Lssa_http____parse_header_bytes_67
.Lssa_http____parse_header_bytes_69:
    cmpq -48(%rbp), %r8
    jge .Lssa_http____parse_header_bytes_67
.Lssa_http____parse_header_bytes_68:
    cmpq (%rbx), %r8
    jae __fern_oob_abort
    movzbl 8(%rbx,%r8), %esi
    cmpq $58, %rsi
    je .Lssa_http____parse_header_bytes_65
.Lssa_http____parse_header_bytes_67:
    movq -48(%rbp), %r15
    movq $-1, -104(%rbp)
    jmp .Lssa_http____parse_header_bytes_53
.Lssa_http____parse_header_bytes_65:
    leaq 1(%r8), %rsi
.Lssa_http____parse_header_bytes_64:
    movl $13, %edi
    movq %r8, -128(%rbp)
    movq %rsi, %rdx
    movq %rdi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L30
    xorq %rdx, %rdx
.L30:
    cmpq $255, %rcx
    ja .L34
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L38
.L36:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L37
    addq $32, %r9
    cmpq %r10, %r9
    jle .L36
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L38
.L37:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L35
.L38:
    vzeroupper
.L31:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L33
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L32
    addq $16, %rdx
    jmp .L31
.L32:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L35
.L33:
    cmpq %r8, %rdx
    jge .L34
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L39
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L34
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L34
    addq %r9, %rdx
    jmp .L35
.L39:
    cmpq %r8, %rdx
    jge .L34
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L35
    addq $1, %rdx
    jmp .L39
.L34:
    movq $-1, %rdx
.L35:
    movq %rdx, %rax
    movq -128(%rbp), %r8
    cmpq $0, %rax
    jl .Lssa_http____parse_header_bytes_62
.Lssa_http____parse_header_bytes_63:
    cmpq -48(%rbp), %rax
    jl .Lssa_http____parse_header_bytes_60
.Lssa_http____parse_header_bytes_62:
    movq -48(%rbp), %rax
    jmp .Lssa_http____parse_header_bytes_56
.Lssa_http____parse_header_bytes_60:
    leaq 1(%rax), %rdi
    cmpq -48(%rbp), %rdi
    jge .Lssa_http____parse_header_bytes_58
.Lssa_http____parse_header_bytes_59:
    leaq 1(%rax), %rdi
    cmpq (%rbx), %rdi
    jae __fern_oob_abort
    movzbl 8(%rbx,%rdi), %esi
    cmpq $10, %rsi
    je .Lssa_http____parse_header_bytes_56
.Lssa_http____parse_header_bytes_58:
    movq $-1, %rax
.Lssa_http____parse_header_bytes_57:
.Lssa_http____parse_header_bytes_56:
    cmpq $0, %rax
    jge .Lssa_http____parse_header_bytes_54
.Lssa_http____parse_header_bytes_55:
    movq -48(%rbp), %r15
    movq $-1, -104(%rbp)
    jmp .Lssa_http____parse_header_bytes_53
.Lssa_http____parse_header_bytes_54:
    movq %r8, -104(%rbp)
    movq %rax, %r15
.Lssa_http____parse_header_bytes_53:
    cmpq $0, -104(%rbp)
    jge .Lssa_http____parse_header_bytes_51
.Lssa_http____parse_header_bytes_121:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_http____parse_header_bytes_11
.Lssa_http____parse_header_bytes_51:
    movq -88(%rbp), %r8
    addq $1, %r8
    movslq %r8d, %r11
    movq %r11, -88(%rbp)
    cmpq -56(%rbp), %r11
    jle .Lssa_http____parse_header_bytes_49
.Lssa_http____parse_header_bytes_125:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_http____parse_header_bytes_10
.Lssa_http____parse_header_bytes_49:
    movq -88(%rbp), %r8
    subq $1, %r8
    movslq %r8d, %r11
    movq %r11, -112(%rbp)
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http____parse_header_bytes_42
.Lssa_http____parse_header_bytes_48:
    movq -64(%rbp), %r11
    movq 8(%r11), %r8
    movq 0(%r8), %rsi
    cmpq %rsi, -112(%rbp)
    jl .Lssa_http____parse_header_bytes_42
.Lssa_http____parse_header_bytes_47:
    cmpq $0, -112(%rbp)
    jle .Lssa_http____parse_header_bytes_44
.Lssa_http____parse_header_bytes_137:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_http____parse_header_bytes_46:
    movq -64(%rbp), %rax
    movq -112(%rbp), %rsi
    call __fn_http____leading_fields.r
    movq %rax, -72(%rbp)
.Lssa_http____parse_header_bytes_45:
.Lssa_http____parse_header_bytes_44:
    movq $0, -80(%rbp)
.Lssa_http____parse_header_bytes_43:
.Lssa_http____parse_header_bytes_42:
    movq $-1, %rsi
    movq -80(%rbp), %r11
    testq %r11, %r11
    movq -112(%rbp), %r11
    cmoveq %rsi, %r11
    movq %r11, -120(%rbp)
    movq -104(%rbp), %rsi
    addq $1, %rsi
    movslq %esi, %rsi
.Lssa_http____parse_header_bytes_38:
    movq %rsi, %r12
.Lssa_http____parse_header_bytes_148:
    cmpq %r15, %r12
    jge .Lssa_http____parse_header_bytes_36
.Lssa_http____parse_header_bytes_150:
    cmpq (%rbx), %r12
    jae __fern_oob_abort
    movzbl 8(%rbx,%r12), %eax
    call __fn_http____is_ows.r
    testq %rax, %rax
    jz .Lssa_http____parse_header_bytes_36
.Lssa_http____parse_header_bytes_149:
    addq $1, %r12
    cmpq %r15, %r12
    jl .Lssa_http____parse_header_bytes_150
.Lssa_http____parse_header_bytes_36:
    movq %r15, %r14
.Lssa_http____parse_header_bytes_161:
    cmpq %r12, %r14
    jle .Lssa_http____parse_header_bytes_35
.Lssa_http____parse_header_bytes_163:
    leaq -1(%r14), %rsi
    cmpq (%rbx), %rsi
    jae __fern_oob_abort
    movzbl 8(%rbx,%rsi), %eax
    call __fn_http____is_ows.r
    testq %rax, %rax
    jz .Lssa_http____parse_header_bytes_35
.Lssa_http____parse_header_bytes_162:
    subq $1, %r14
    cmpq %r12, %r14
    jg .Lssa_http____parse_header_bytes_163
.Lssa_http____parse_header_bytes_35:
    cmpq $0, -120(%rbp)
    jl .Lssa_http____parse_header_bytes_30
.Lssa_http____parse_header_bytes_34:
    movq -64(%rbp), %r11
    movq 16(%r11), %rsi
    movq -120(%rbp), %rcx
    cmpq (%rsi), %rcx
    jae __fern_oob_abort
    movq 8(%rsi,%rcx,8), %r8
    movq 8(%r8), %rsi
    movq %r14, %r8
    subq %r12, %r8
    movslq %r8d, %r8
    cmpq %r8, %rsi
    jne .Lssa_http____parse_header_bytes_30
.Lssa_http____parse_header_bytes_33:
    movq -64(%rbp), %r11
    movq 16(%r11), %r8
    movq -120(%rbp), %rcx
    cmpq (%r8), %rcx
    jae __fern_oob_abort
    movq 8(%r8,%rcx,8), %r9
    movq 8(%r9), %rsi
    xorl %edi, %edi
    movq %r8, -128(%rbp)
    movq %r9, -136(%rbp)
    movq %rsi, %r8
    movq %rdi, %rcx
    movq %r9, %rdx
    movq %r12, %rsi
    movq %rbx, %rax
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L40_aop
    xorq %rsi, %rsi
.L40_aop:
    cmpq %r9, %rsi
    jle .L40_aok
    movq %r9, %rsi
.L40_aok:
    cmpq $0, %rcx
    jge .L40_bop
    xorq %rcx, %rcx
.L40_bop:
    cmpq %r10, %rcx
    jle .L40_bok
    movq %r10, %rcx
.L40_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L40_na
    movq %r9, %r8
.L40_na:
    cmpq %r10, %r8
    jle .L40_nb
    movq %r10, %r8
.L40_nb:
    cmpq $0, %r8
    jge .L40_nok
    xorq %r8, %r8
.L40_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L40_vec
    cmpq $8, %r8
    jge .L40_w8
    cmpq $4, %r8
    jge .L40_w4
    cmpq $2, %r8
    jge .L40_w2
    jmp .L40_tail
.L40_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L40_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L40_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L40_done
.L40_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L40_done
.L40_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L40_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L40_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L40_done
.L40_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L40_done
.L40_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L40_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L40_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L40_done
.L40_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L40_done
.L40_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L40_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L40_hit
    addq $16, %rdx
    jmp .L40_vec
.L40_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L40_done
.L40_tail:
    cmpq %r8, %rdx
    jge .L40_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L40_th
    addq $1, %rdx
    jmp .L40_tail
.L40_th:
    movq %rdx, %rax
    jmp .L40_done
.L40_eq:
    movq %r8, %rax
.L40_done:
    movq -128(%rbp), %r8
    movq -136(%rbp), %r9
    movq 8(%r9), %rdi
    cmpq %rdi, %rax
    sete %al
    movzbq %al, %rax
.Lssa_http____parse_header_bytes_182:
    testq %rax, %rax
    jz .Lssa_http____parse_header_bytes_30
.Lssa_http____parse_header_bytes_32:
    movq -120(%rbp), %rcx
    cmpq (%r8), %rcx
    jae __fern_oob_abort
    movq 8(%r8,%rcx,8), %r13
    pushq %r13
    call __fn___fern_rc_inc
    addq $8, %rsp
    jmp .Lssa_http____parse_header_bytes_26
.Lssa_http____parse_header_bytes_30:
    leaq .K3(%rip), %r8
    movq %r8, %rdx
    movq %r12, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L41
    xorq %rcx, %rcx
.L41:
    leaq .S2(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L44
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L42:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L48
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L43
    addq $32, %r9
    jmp .L42
.L48:
    cmpq %r10, %r9
    jg .L49
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L43
    addq $16, %r9
.L49:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L44
.L43:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L47
.L44:
    cmpq %r8, %rcx
    jge .L46
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L45
    addq $1, %rcx
    jmp .L44
.L45:
    pushq %rcx
    jmp .L47
.L46:
    pushq %r8
.L47:
    popq %rax
    cmpq %r14, %rax
    jge .Lssa_http____parse_header_bytes_28
.Lssa_http____parse_header_bytes_189:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_http____parse_header_bytes_1
.Lssa_http____parse_header_bytes_28:
    movq %rbx, %rax
    movq %r12, %rsi
    movq %r14, %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r13
.Lssa_http____parse_header_bytes_193:
    movq %r13, %rax
    call __fn_utf8__is_valid.r
    testq %rax, %rax
    jnz .Lssa_http____parse_header_bytes_26
.Lssa_http____parse_header_bytes_196:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq %r13, %rax
    call __fn___fern_str_free.r
    jmp .Lssa_http____parse_header_bytes_1
.Lssa_http____parse_header_bytes_27:
.Lssa_http____parse_header_bytes_26:
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http____parse_header_bytes_19
.Lssa_http____parse_header_bytes_25:
    movq -64(%rbp), %r11
    movq 8(%r11), %r8
    movq -112(%rbp), %rcx
    cmpq (%r8), %rcx
    jae __fern_oob_abort
    movq 8(%r8,%rcx,8), %r14
    movq %rbx, %rax
    movq -96(%rbp), %rsi
    movq -104(%rbp), %rdi
    movq %r14, %r8
    call __fn_http____shared_string.r
    movq %rax, %r12
    movq 8(%r12), %rdx
    cmpq 8(%r14), %rdx
    jne .Lssa_http____parse_header_bytes_streqn423
    movq %r12, %rax
    movq %r14, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_http____parse_header_bytes_streqd423
.Lssa_http____parse_header_bytes_streqn423:
    xorl %eax, %eax
.Lssa_http____parse_header_bytes_streqd423:
    testq %rax, %rax
    jz .Lssa_http____parse_header_bytes_23
.Lssa_http____parse_header_bytes_24:
    movq -64(%rbp), %r11
    movq 16(%r11), %r8
    movq -112(%rbp), %rcx
    cmpq (%r8), %rcx
    jae __fern_oob_abort
    movq 8(%r8,%rcx,8), %rdi
    movq 8(%r13), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_http____parse_header_bytes_streqn426
    movq %r13, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_http____parse_header_bytes_streqd426
.Lssa_http____parse_header_bytes_streqn426:
    xorl %eax, %eax
.Lssa_http____parse_header_bytes_streqd426:
    movq %rax, %r14
    jmp .Lssa_http____parse_header_bytes_22
.Lssa_http____parse_header_bytes_23:
    xorl %r14d, %r14d
.Lssa_http____parse_header_bytes_22:
    testq %r14, %r14
    jz .Lssa_http____parse_header_bytes_209
.Lssa_http____parse_header_bytes_208:
    movq %r12, %rax
    call __fn___fern_str_free.r
    movq %r13, %rax
    call __fn___fern_str_free.r
    jmp .Lssa_http____parse_header_bytes_21
.Lssa_http____parse_header_bytes_209:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_http____parse_header_bytes_20
.Lssa_http____parse_header_bytes_21:
    movq %r14, -80(%rbp)
    jmp .Lssa_http____parse_header_bytes_17
.Lssa_http____parse_header_bytes_20:
    movq -64(%rbp), %rax
    movq -112(%rbp), %rsi
    call __fn_http____leading_fields.r
    movq %r12, %rsi
    movq %r13, %rdi
    call __fn_HeaderMap__append.r
    movq %rax, %r8
    movq %r8, -128(%rbp)
    movq %r12, %rax
    call __fn___fern_str_free.r
    movq -128(%rbp), %r8
    movq %r8, -128(%rbp)
    movq %r13, %rax
    call __fn___fern_str_free.r
    movq -128(%rbp), %r8
    movq %r8, -72(%rbp)
    movq %r14, -80(%rbp)
    jmp .Lssa_http____parse_header_bytes_17
.Lssa_http____parse_header_bytes_19:
    movq %rbx, %rax
    movq -96(%rbp), %rsi
    movq -104(%rbp), %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r14
.Lssa_http____parse_header_bytes_214:
    movq -72(%rbp), %rax
    movq %r14, %rsi
    movq %r13, %rdi
    call __fn_HeaderMap__append.r
    movq %rax, %r12
    movq %r14, %rax
    call __fn___fern_str_free.r
    movq %r13, %rax
    call __fn___fern_str_free.r
    movq %r12, -72(%rbp)
.Lssa_http____parse_header_bytes_18:
.Lssa_http____parse_header_bytes_17:
    addq $2, %r15
    movslq %r15d, %r11
    movq %r11, -96(%rbp)
    movq -96(%rbp), %r11
    cmpq -48(%rbp), %r11
    jl .Lssa_http____parse_header_bytes_70
.Lssa_http____parse_header_bytes_14:
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http____parse_header_bytes_8
.Lssa_http____parse_header_bytes_13:
    movq -64(%rbp), %r11
    movq 8(%r11), %r8
    movq 0(%r8), %rdi
    cmpq %rdi, -88(%rbp)
    jne .Lssa_http____parse_header_bytes_8
.Lssa_http____parse_header_bytes_222:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_http____parse_header_bytes_12:
    pushq -64(%rbp)
    call __fn___fern_rc_inc
    addq $8, %rsp
    movq -64(%rbp), %rdx
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_11:
    movl $400, %edi
    movq %rdi, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_10:
    movl $431, %edi
    movq %rdi, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_8:
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http____parse_header_bytes_5
.Lssa_http____parse_header_bytes_226:
    movq -72(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_http____parse_header_bytes_7:
    movq -64(%rbp), %rax
    movq -88(%rbp), %rsi
    call __fn_http____leading_fields.r
    movq %rax, %rdx
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_5:
    movq -72(%rbp), %rdx
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_1:
    movl $400, %edi
    movq %rdi, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____leading_fields:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_http____leading_fields.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_http____leading_fields_0:
    leaq .K1(%rip), %rax
.Lssa_http____leading_fields_2:
    xorl %r13d, %r13d
.Lssa_http____leading_fields_3:
    cmpq %r12, %r13
    jge .Lssa_http____leading_fields_1
.Lssa_http____leading_fields_4:
    movq 8(%rbx), %rsi
    cmpq (%rsi), %r13
    jae __fern_oob_abort.l3
    movq 8(%rsi,%r13,8), %rdi
    movq 16(%rbx), %rsi
    cmpq (%rsi), %r13
    jae __fern_oob_abort.l3
    movq 8(%rsi,%r13,8), %r8
    movq %rdi, %rsi
    movq %r8, %rdi
    call __fn_HeaderMap__append.r
    addq $1, %r13
    cmpq %r12, %r13
    jl .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_1:
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____crlf_terminated:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____crlf_terminated.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____crlf_terminated_0:
.Lssa_http____crlf_terminated_7:
    movq %rsi, %r13
.Lssa_http____crlf_terminated_8:
.Lssa_http____crlf_terminated_18:
    movl $13, %esi
    movq %r13, %rdx
    movq %rsi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L50
    xorq %rdx, %rdx
.L50:
    cmpq $255, %rcx
    ja .L54
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L58
.L56:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L57
    addq $32, %r9
    cmpq %r10, %r9
    jle .L56
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L58
.L57:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L55
.L58:
    vzeroupper
.L51:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L53
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L52
    addq $16, %rdx
    jmp .L51
.L52:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L55
.L53:
    cmpq %r8, %rdx
    jge .L54
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L59
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L54
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L54
    addq %r9, %rdx
    jmp .L55
.L59:
    cmpq %r8, %rdx
    jge .L54
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L55
    addq $1, %rdx
    jmp .L59
.L54:
    movq $-1, %rdx
.L55:
    movq %rdx, %r14
    movl $10, %esi
    movq %r13, %rdx
    movq %rsi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L60
    xorq %rdx, %rdx
.L60:
    cmpq $255, %rcx
    ja .L64
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L68
.L66:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L67
    addq $32, %r9
    cmpq %r10, %r9
    jle .L66
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L68
.L67:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L65
.L68:
    vzeroupper
.L61:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L63
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L62
    addq $16, %rdx
    jmp .L61
.L62:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L65
.L63:
    cmpq %r8, %rdx
    jge .L64
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L69
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L64
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L64
    addq %r9, %rdx
    jmp .L65
.L69:
    cmpq %r8, %rdx
    jge .L64
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L65
    addq $1, %rdx
    jmp .L69
.L64:
    movq $-1, %rdx
.L65:
    movq %rdx, %rax
    cmpq $0, %r14
    jl .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_17:
    cmpq %r12, %r14
    jge .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_15:
    cmpq $0, %rax
    jl .Lssa_http____crlf_terminated_12
.Lssa_http____crlf_terminated_14:
    cmpq %r14, %rax
    jl .Lssa_http____crlf_terminated_2
.Lssa_http____crlf_terminated_12:
    leaq 1(%r14), %rsi
    movq 0(%rbx), %rdi
    cmpq %rdi, %rsi
    jge .Lssa_http____crlf_terminated_9
.Lssa_http____crlf_terminated_11:
    leaq 1(%r14), %rdi
    cmpq (%rbx), %rdi
    jae __fern_oob_abort.l5
    movzbl 8(%rbx,%rdi), %esi
    cmpq $10, %rsi
    jne .Lssa_http____crlf_terminated_1
.Lssa_http____crlf_terminated_9:
    addq $2, %r14
    movslq %r14d, %r13
    jmp .Lssa_http____crlf_terminated_18
.Lssa_http____crlf_terminated_6:
    movl $1, %esi
    cmpq %rax, %r12
    setle %r12b
    movzbq %r12b, %r12
    cmpq $0, %rax
    movq %rsi, %rax
    cmovgeq %r12, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_2:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_1:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____line_break:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____line_break.r:
.Lssa_http____line_break_0:
    cmpq %rdi, %rsi
    jl .Lssa_http____line_break_9
.Lssa_http____line_break_11:
    movl $2, %eax
    ret
.Lssa_http____line_break_9:
    cmpq (%rax), %rsi
    jae __fern_oob_abort.l0
    movzbl 8(%rax,%rsi), %edi
    cmpq $10, %rdi
    je .Lssa_http____line_break_6
.Lssa_http____line_break_8:
    leaq 1(%rsi), %rdi
    movq 0(%rax), %r8
    cmpq %r8, %rdi
    jge .Lssa_http____line_break_4
.Lssa_http____line_break_7:
    leaq 1(%rsi), %r8
    cmpq (%rax), %r8
    jae __fern_oob_abort.l0
    movzbl 8(%rax,%r8), %edi
    cmpq $10, %rdi
    je .Lssa_http____line_break_4
.Lssa_http____line_break_6:
    movl $1, %eax
    ret
.Lssa_http____line_break_4:
    addq $1, %rsi
    movq 0(%rax), %rdi
    movl $2, %r8d
    xorl %r9d, %r9d
    cmpq %rdi, %rsi
    movq %r8, %rax
    cmovlq %r9, %rax
    ret
    .cfi_endproc
__fn_http____field_at:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____field_at.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_http____field_at_0:
.Lssa_http____field_at_3:
    movq %rdi, %r13
.Lssa_http____field_at_4:
    movq 8(%rbx), %rdi
    movq 0(%rdi), %rsi
    cmpq %rsi, %r13
    jge .Lssa_http____field_at_2
.Lssa_http____field_at_8:
    movq 8(%rbx), %rsi
    cmpq (%rsi), %r13
    jae __fern_oob_abort.l3
    movq 8(%rsi,%r13,8), %rdi
    movq 8(%rdi), %rsi
    movq 8(%r12), %rdi
    cmpq %rdi, %rsi
    jne .Lssa_http____field_at_5
.Lssa_http____field_at_7:
    movq 8(%rbx), %rdi
    cmpq (%rdi), %r13
    jae __fern_oob_abort.l3
    movq 8(%rdi,%r13,8), %rax
    movq %r12, %rsi
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http____field_at_1
.Lssa_http____field_at_5:
    addq $1, %r13
    jmp .Lssa_http____field_at_4
.Lssa_http____field_at_2:
    movq $-1, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____field_at_1:
    movq %r13, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____kind_if:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____kind_if.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rdi, %rbx
.Lssa_http____kind_if_0:
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jz .Lssa_http____kind_if_1
.Lssa_http____kind_if_3:
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____kind_if_1:
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____hex_digit:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http____hex_digit.r:
.Lssa_http____hex_digit_0:
    cmpq $48, %rax
    jb .Lssa_http____hex_digit_9
.Lssa_http____hex_digit_12:
    cmpq $57, %rax
    ja .Lssa_http____hex_digit_9
.Lssa_http____hex_digit_11:
    leaq -48(%rax), %rsi
    movslq %esi, %rsi
    movq %rsi, %rax
    ret
.Lssa_http____hex_digit_9:
    cmpq $97, %rax
    jb .Lssa_http____hex_digit_5
.Lssa_http____hex_digit_8:
    cmpq $102, %rax
    ja .Lssa_http____hex_digit_5
.Lssa_http____hex_digit_7:
    leaq -87(%rax), %rsi
    movslq %esi, %rsi
    movq %rsi, %rax
    ret
.Lssa_http____hex_digit_5:
    cmpq $65, %rax
    jb .Lssa_http____hex_digit_1
.Lssa_http____hex_digit_4:
    cmpq $70, %rax
    ja .Lssa_http____hex_digit_1
.Lssa_http____hex_digit_3:
    subq $55, %rax
    movslq %eax, %rax
    ret
.Lssa_http____hex_digit_1:
    movq $-1, %rax
    ret
    .cfi_endproc
__fn_http____bws_end:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____bws_end.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____bws_end_0:
.Lssa_http____bws_end_2:
    movq %rsi, %r13
.Lssa_http____bws_end_3:
    cmpq %r12, %r13
    jge .Lssa_http____bws_end_1
.Lssa_http____bws_end_5:
    cmpq (%rbx), %r13
    jae __fern_oob_abort.l3
    movzbl 8(%rbx,%r13), %eax
    call __fn_http____is_ows.r
    testq %rax, %rax
    jz .Lssa_http____bws_end_1
.Lssa_http____bws_end_4:
    addq $1, %r13
    cmpq %r12, %r13
    jl .Lssa_http____bws_end_5
.Lssa_http____bws_end_1:
    movq %r13, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____target_start:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____target_start.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
.Lssa_http____target_start_0:
    movq %rax, %r9
    andq $2, %r9
    testq %r9, %r9
    jz .Lssa_http____target_start_2
.Lssa_http____target_start_1:
    leaq -2(%rax), %r9
    movq 0(%r9), %r10
    movq 8(%r9), %rbx
    movq %rbx, %r9
    jmp .Lssa_http____target_start_3
.Lssa_http____target_start_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____target_start_5
.Lssa_http____target_start_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____target_start_3
.Lssa_http____target_start_5:
    xorl %r9d, %r9d
.Lssa_http____target_start_6:
.Lssa_http____target_start_3:
    leaq 1(%rsi), %rcx
    movslq %ecx, %rbx
    cmpq %rbx, %rdi
    jne .Lssa_http____target_start_13
.Lssa_http____target_start_19:
    movl %esi, %ebx
    cmpq %r9, %rbx
    jb .Lssa_http____target_start_26
.Lssa_http____target_start_24:
    call __fern_oob_abort.c
.Lssa_http____target_start_26:
    movzbl (%r10,%rbx), %r12d
    cmpq $42, %r12
    jne .Lssa_http____target_start_13
.Lssa_http____target_start_18:
    testq %r8, %r8
    jz .Lssa_http____target_start_15
.Lssa_http____target_start_17:
.Lssa_http____target_start_35:
    movq $-1, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____target_start_15:
.Lssa_http____target_start_37:
    movq $-2, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____target_start_13:
    cmpq %rsi, %rdi
    jle .Lssa_http____target_start_9
.Lssa_http____target_start_12:
    movl %esi, %r8d
    cmpq %r9, %r8
    jb .Lssa_http____target_start_45
.Lssa_http____target_start_43:
    call __fern_oob_abort.c
.Lssa_http____target_start_45:
    movzbl (%r10,%r8), %r9d
    cmpq $47, %r9
    jne .Lssa_http____target_start_9
.Lssa_http____target_start_11:
    movq %rsi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____target_start_9:
    call __fn_http____absolute_form_path.r
    cmpq $0, %rax
    jge .Lssa_http____target_start_7
.Lssa_http____target_start_8:
.Lssa_http____target_start_54:
    movq $-2, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____target_start_7:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____path_end:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____path_end.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____path_end_0:
    movl $63, %r8d
    movq %rbx, %rax
    movq %r12, %rdi
    call __fn_http____find_char.r
    movq %rax, %r13
    cmpq $0, %r13
    jge .Lssa_http____path_end_3
.Lssa_http____path_end_5:
    movq %r12, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____path_end_3:
    leaq 1(%r13), %r8
    movslq %r8d, %rsi
    movq %rbx, %rax
    movq %r12, %rdi
    call __fn_http____query_ok.r
    testq %rax, %rax
    jz .Lssa_http____path_end_1
.Lssa_http____path_end_2:
    movq %r13, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____path_end_1:
    movq $-1, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____absolute_form_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____absolute_form_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa_http____absolute_form_path_0:
    movq %rbx, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____absolute_form_path_2
.Lssa_http____absolute_form_path_1:
    leaq -2(%rbx), %rsi
    movq 0(%rsi), %rdi
    movq 8(%rsi), %r8
    movq %rdi, %r14
    movq %r8, %r15
    jmp .Lssa_http____absolute_form_path_3
.Lssa_http____absolute_form_path_2:
    leaq 8(%rbx), %r8
    cmpq $0, %rbx
    je .Lssa_http____absolute_form_path_5
.Lssa_http____absolute_form_path_4:
    movq 0(%rbx), %rdi
    jmp .Lssa_http____absolute_form_path_6
.Lssa_http____absolute_form_path_5:
    xorl %edi, %edi
.Lssa_http____absolute_form_path_6:
    movq %r8, %r14
    movq %rdi, %r15
.Lssa_http____absolute_form_path_3:
    leaq .SB3(%rip), %r8
    movq %rbx, %rax
    movq %r12, %rsi
    movq %r13, %rdi
    call __fn_http____prefix_ci.r
    testq %rax, %rax
    jz .Lssa_http____absolute_form_path_18
.Lssa_http____absolute_form_path_19:
    leaq 7(%r12), %r8
    movslq %r8d, %r8
    movq %r8, -48(%rbp)
    jmp .Lssa_http____absolute_form_path_17
.Lssa_http____absolute_form_path_18:
    movq $-1, -48(%rbp)
.Lssa_http____absolute_form_path_17:
    leaq .SB4(%rip), %r8
    movq %rbx, %rax
    movq %r12, %rsi
    movq %r13, %rdi
    call __fn_http____prefix_ci.r
    testq %rax, %rax
    jz .Lssa_http____absolute_form_path_14
.Lssa_http____absolute_form_path_16:
    addq $8, %r12
    movslq %r12d, %r12
    movq %r12, -48(%rbp)
.Lssa_http____absolute_form_path_15:
.Lssa_http____absolute_form_path_14:
    cmpq $0, -48(%rbp)
    jge .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_13:
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_11:
    movq -48(%rbp), %r12
.Lssa_http____absolute_form_path_34:
    cmpq %r13, %r12
    jge .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_39:
    movl %r12d, %r8d
    cmpq %r15, %r8
    jb .Lssa_http____absolute_form_path_46
.Lssa_http____absolute_form_path_44:
    call __fern_oob_abort
.Lssa_http____absolute_form_path_46:
    movzbl (%r14,%r8), %eax
    cmpq $47, %rax
    je .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_38:
    cmpq $63, %rax
    je .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_37:
    call __fn_http____is_pchar.r
    testq %rax, %rax
    jz .Lssa_http____absolute_form_path_8
.Lssa_http____absolute_form_path_35:
    addq $1, %r12
    cmpq %r13, %r12
    jl .Lssa_http____absolute_form_path_39
.Lssa_http____absolute_form_path_10:
    movq $-1, %r8
    cmpq -48(%rbp), %r12
    movq %r8, %rax
    cmovneq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_8:
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____prefix_ci:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____prefix_ci.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rsi, -48(%rbp)
.Lssa_http____prefix_ci_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____prefix_ci_2
.Lssa_http____prefix_ci_1:
    leaq -2(%rax), %rsi
    movq 0(%rsi), %r9
    movq 8(%rsi), %r10
    movq %r9, %r12
    movq %r10, %r13
    jmp .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____prefix_ci_5
.Lssa_http____prefix_ci_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____prefix_ci_6
.Lssa_http____prefix_ci_5:
    xorl %r9d, %r9d
.Lssa_http____prefix_ci_6:
    movq %r10, %r12
    movq %r9, %r13
.Lssa_http____prefix_ci_3:
    subq -48(%rbp), %rdi
    movslq %edi, %rdi
    movq 8(%r8), %r9
    cmpq %r9, %rdi
    jge .Lssa_http____prefix_ci_10
.Lssa_http____prefix_ci_12:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_10:
.Lssa_http____prefix_ci_9:
    movq 8(%r8), %r14
    movq 0(%r8), %r15
    xorl %ebx, %ebx
.Lssa_http____prefix_ci_17:
    cmpq %r14, %rbx
    jge .Lssa_http____prefix_ci_8
.Lssa_http____prefix_ci_20:
    movq -48(%rbp), %r8
    addl %ebx, %r8d
    cmpq %r13, %r8
    jb .Lssa_http____prefix_ci_27
.Lssa_http____prefix_ci_25:
    call __fern_oob_abort
.Lssa_http____prefix_ci_27:
    movzbl (%r12,%r8), %eax
    call __fn_http____ascii_lower.r
    movzbl (%r15,%rbx), %r8d
    cmpq %r8, %rax
    jne .Lssa_http____prefix_ci_7
.Lssa_http____prefix_ci_18:
    addq $1, %rbx
    cmpq %r14, %rbx
    jl .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_8:
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_7:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____find_char:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____find_char.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
.Lssa_http____find_char_0:
    movq %rax, %r9
    andq $2, %r9
    testq %r9, %r9
    jz .Lssa_http____find_char_2
.Lssa_http____find_char_1:
    leaq -2(%rax), %r9
    movq 0(%r9), %r10
    movq 8(%r9), %rbx
    movq %rbx, %r9
    jmp .Lssa_http____find_char_10
.Lssa_http____find_char_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____find_char_5
.Lssa_http____find_char_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____find_char_10
.Lssa_http____find_char_5:
    xorl %r9d, %r9d
.Lssa_http____find_char_6:
.Lssa_http____find_char_3:
.Lssa_http____find_char_9:
.Lssa_http____find_char_10:
    cmpq %rdi, %rsi
    jge .Lssa_http____find_char_8
.Lssa_http____find_char_13:
    movl %esi, %eax
    cmpq %r9, %rax
    jb .Lssa_http____find_char_20
.Lssa_http____find_char_18:
    call __fern_oob_abort
.Lssa_http____find_char_20:
    movzbl (%r10,%rax), %ebx
    cmpq %r8, %rbx
    je .Lssa_http____find_char_7
.Lssa_http____find_char_11:
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_http____find_char_13
.Lssa_http____find_char_8:
    movq $-1, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____find_char_7:
    movq %rsi, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____is_pchar:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http____is_pchar.r:
.Lssa_http____is_pchar_0:
.Lssa_http____is_pchar_42:
    cmpq $97, %rax
    jl .Lssa_http____is_pchar_37
.Lssa_http____is_pchar_41:
    cmpq $122, %rax
    jle .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_37:
    cmpq $65, %rax
    jl .Lssa_http____is_pchar_32
.Lssa_http____is_pchar_36:
    cmpq $90, %rax
    jle .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_32:
    cmpq $48, %rax
    jl .Lssa_http____is_pchar_27
.Lssa_http____is_pchar_31:
    cmpq $57, %rax
    jle .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_27:
    cmpq $45, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_24:
    cmpq $46, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_21:
    cmpq $95, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_18:
    cmpq $126, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_14:
    leaq .SB5(%rip), %rsi
.Lssa_http____is_pchar_13:
    movq 8(%rsi), %rdi
    movq 0(%rsi), %r8
    xorl %esi, %esi
.Lssa_http____is_pchar_93:
    cmpq %rdi, %rsi
    jge .Lssa_http____is_pchar_8
.Lssa_http____is_pchar_96:
    movzbl (%r8,%rsi), %r9d
    cmpq %rax, %r9
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_94:
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_http____is_pchar_96
.Lssa_http____is_pchar_8:
    cmpq $58, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_5:
    cmpq $64, %rax
    jne .Lssa_http____is_pchar_2
.Lssa_http____is_pchar_3:
    movl $1, %eax
    jmp .Lssa_http____is_pchar_1
.Lssa_http____is_pchar_2:
    cmpq $37, %rax
    sete %al
    movzbq %al, %rax
.Lssa_http____is_pchar_1:
    ret
    .cfi_endproc
__fn_http____query_ok:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____query_ok.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____query_ok_0:
    movq %rbx, %rdi
    andq $2, %rdi
    testq %rdi, %rdi
    jz .Lssa_http____query_ok_2
.Lssa_http____query_ok_1:
    leaq -2(%rbx), %rdi
    movq 0(%rdi), %r8
    movq 8(%rdi), %r9
    movq %r8, %r13
    movq %r9, %r14
    jmp .Lssa_http____query_ok_10
.Lssa_http____query_ok_2:
    leaq 8(%rbx), %r9
    cmpq $0, %rbx
    je .Lssa_http____query_ok_5
.Lssa_http____query_ok_4:
    movq 0(%rbx), %r8
    jmp .Lssa_http____query_ok_6
.Lssa_http____query_ok_5:
    xorl %r8d, %r8d
.Lssa_http____query_ok_6:
    movq %r9, %r13
    movq %r8, %r14
.Lssa_http____query_ok_3:
.Lssa_http____query_ok_10:
    movq %rsi, %r15
.Lssa_http____query_ok_11:
    cmpq %r12, %r15
    jge .Lssa_http____query_ok_9
.Lssa_http____query_ok_21:
    movl %r15d, %esi
    cmpq %r14, %rsi
    jb .Lssa_http____query_ok_28
.Lssa_http____query_ok_26:
    call __fern_oob_abort
.Lssa_http____query_ok_28:
    movzbl (%r13,%rsi), %r8d
    cmpq $37, %r8
    jne .Lssa_http____query_ok_17
.Lssa_http____query_ok_20:
    movq %r8, -48(%rbp)
    movq %rbx, %rax
    movq %r15, %rsi
    movq %r12, %rdi
    call __fn_http____pct_byte.r
    movq -48(%rbp), %r8
    cmpq $0, %rax
    jl .Lssa_http____query_ok_8
.Lssa_http____query_ok_18:
    leaq 3(%r15), %rsi
    movslq %esi, %rsi
    movq %rsi, %r15
    jmp .Lssa_http____query_ok_11
.Lssa_http____query_ok_17:
    movq %r8, -48(%rbp)
    movq %r8, %rax
    call __fn_http____is_pchar.r
    movq -48(%rbp), %r8
    testq %rax, %rax
    jnz .Lssa_http____query_ok_13
.Lssa_http____query_ok_16:
    cmpq $47, %r8
    je .Lssa_http____query_ok_13
.Lssa_http____query_ok_15:
    cmpq $63, %r8
    jne .Lssa_http____query_ok_7
.Lssa_http____query_ok_13:
    addq $1, %r15
.Lssa_http____query_ok_12:
    cmpq %r12, %r15
    jl .Lssa_http____query_ok_21
.Lssa_http____query_ok_9:
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____query_ok_8:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____query_ok_7:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____pct_byte:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____pct_byte.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rsi, %rbx
.Lssa_http____pct_byte_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____pct_byte_2
.Lssa_http____pct_byte_1:
    leaq -2(%rax), %rsi
    movq 0(%rsi), %r8
    movq 8(%rsi), %r9
    movq %r8, %r12
    movq %r9, %r13
    jmp .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_2:
    leaq 8(%rax), %r9
    cmpq $0, %rax
    je .Lssa_http____pct_byte_5
.Lssa_http____pct_byte_4:
    movq 0(%rax), %r8
    jmp .Lssa_http____pct_byte_6
.Lssa_http____pct_byte_5:
    xorl %r8d, %r8d
.Lssa_http____pct_byte_6:
    movq %r9, %r12
    movq %r8, %r13
.Lssa_http____pct_byte_3:
    leaq 2(%rbx), %r8
    movslq %r8d, %r8
    cmpq %rdi, %r8
    jl .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_13:
    movq $-1, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_11:
    leal 1(%rbx), %r8d
    cmpq %r13, %r8
    jb .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_18:
    call __fern_oob_abort.c
.Lssa_http____pct_byte_20:
    movzbl (%r12,%r8), %eax
    call __fn_http____hex_digit.r
    movq %rax, %r14
    addl $2, %ebx
    cmpq %r13, %rbx
    jb .Lssa_http____pct_byte_23
.Lssa_http____pct_byte_21:
    call __fern_oob_abort.c
.Lssa_http____pct_byte_23:
    movzbl (%r12,%rbx), %eax
    call __fn_http____hex_digit.r
    cmpq $0, %r14
    jl .Lssa_http____pct_byte_9
.Lssa_http____pct_byte_10:
    cmpq $0, %rax
    jge .Lssa_http____pct_byte_7
.Lssa_http____pct_byte_9:
    movq $-1, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_7:
    shlq $4, %r14
    addq %rax, %r14
    movslq %r14d, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____plain_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____plain_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa_http____plain_path_0:
    movq %rbx, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____plain_path_2
.Lssa_http____plain_path_1:
    leaq -2(%rbx), %rsi
    movq 0(%rsi), %rdi
    movq 8(%rsi), %r8
    movq %rdi, %r14
    movq %r8, %r15
    jmp .Lssa_http____plain_path_3
.Lssa_http____plain_path_2:
    leaq 8(%rbx), %r8
    cmpq $0, %rbx
    je .Lssa_http____plain_path_5
.Lssa_http____plain_path_4:
    movq 0(%rbx), %rdi
    jmp .Lssa_http____plain_path_6
.Lssa_http____plain_path_5:
    xorl %edi, %edi
.Lssa_http____plain_path_6:
    movq %r8, %r14
    movq %rdi, %r15
.Lssa_http____plain_path_3:
    leaq 1(%r12), %rdi
    movslq %edi, %rsi
.Lssa_http____plain_path_10:
    movq %rsi, %r8
    movq %r12, %r9
.Lssa_http____plain_path_11:
    cmpq %r13, %r9
    jge .Lssa_http____plain_path_9
.Lssa_http____plain_path_20:
    movl %r9d, %esi
    cmpq %r15, %rsi
    jb .Lssa_http____plain_path_27
.Lssa_http____plain_path_25:
    call __fern_oob_abort
.Lssa_http____plain_path_27:
    movzbl (%r14,%rsi), %r10d
    cmpq $47, %r10
    jne .Lssa_http____plain_path_15
.Lssa_http____plain_path_19:
    cmpq %r12, %r9
    jle .Lssa_http____plain_path_16
.Lssa_http____plain_path_18:
    movq %r8, -48(%rbp)
    movq %r9, -56(%rbp)
    movq %r10, -64(%rbp)
    movq %rbx, %rax
    movq %r8, %rsi
    movq %r9, %rdi
    call __fn_http____dot_segment.r
    movq -48(%rbp), %r8
    movq -56(%rbp), %r9
    movq -64(%rbp), %r10
    cmpq $0, %rax
    jg .Lssa_http____plain_path_8
.Lssa_http____plain_path_16:
    leaq 1(%r9), %rsi
    movq %rsi, %r8
    jmp .Lssa_http____plain_path_12
.Lssa_http____plain_path_15:
    cmpq $37, %r10
    je .Lssa_http____plain_path_7
.Lssa_http____plain_path_14:
    movq %r8, -48(%rbp)
    movq %r9, -56(%rbp)
    movq %r10, %rax
    call __fn_http____is_pchar.r
    movq -48(%rbp), %r8
    movq -56(%rbp), %r9
    testq %rax, %rax
    jz .Lssa_http____plain_path_7
.Lssa_http____plain_path_13:
.Lssa_http____plain_path_12:
    addq $1, %r9
    cmpq %r13, %r9
    jl .Lssa_http____plain_path_20
.Lssa_http____plain_path_9:
    movq %rbx, %rax
    movq %r8, %rsi
    movq %r13, %rdi
    call __fn_http____dot_segment.r
    cmpq $0, %rax
    sete %al
    movzbq %al, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____plain_path_8:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____plain_path_7:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____dot_segment:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____dot_segment.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_http____dot_segment_0:
    movq %rax, %r8
    andq $2, %r8
    testq %r8, %r8
    jz .Lssa_http____dot_segment_2
.Lssa_http____dot_segment_1:
    leaq -2(%rax), %r8
    movq 0(%r8), %r9
    movq 8(%r8), %r10
    xchgq %r9, %r10
    jmp .Lssa_http____dot_segment_3
.Lssa_http____dot_segment_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____dot_segment_5
.Lssa_http____dot_segment_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____dot_segment_3
.Lssa_http____dot_segment_5:
    xorl %r9d, %r9d
.Lssa_http____dot_segment_6:
.Lssa_http____dot_segment_3:
    movq %rdi, %r8
    subq %rsi, %r8
    movslq %r8d, %rax
    cmpq $1, %rax
    jl .Lssa_http____dot_segment_8
.Lssa_http____dot_segment_11:
    cmpq $2, %rax
    jg .Lssa_http____dot_segment_8
.Lssa_http____dot_segment_10:
    movl %esi, %esi
    cmpq %r9, %rsi
    jb .Lssa_http____dot_segment_22
.Lssa_http____dot_segment_20:
    call __fern_oob_abort
.Lssa_http____dot_segment_22:
    movzbl (%r10,%rsi), %r8d
    cmpq $46, %r8
    jne .Lssa_http____dot_segment_8
.Lssa_http____dot_segment_9:
    subl $1, %edi
    cmpq %r9, %rdi
    jb .Lssa_http____dot_segment_29
.Lssa_http____dot_segment_27:
    call __fern_oob_abort
.Lssa_http____dot_segment_29:
    movzbl (%r10,%rdi), %r9d
    cmpq $46, %r9
    je .Lssa_http____dot_segment_7
.Lssa_http____dot_segment_8:
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____dot_segment_7:
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____decoded_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____decoded_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $104, %rsp
    movq %rax, -48(%rbp)
    movq %rdi, -56(%rbp)
    movq %r8, -64(%rbp)
.Lssa_http____decoded_path_0:
    movq -48(%rbp), %rdi
    andq $2, %rdi
    testq %rdi, %rdi
    jz .Lssa_http____decoded_path_2
.Lssa_http____decoded_path_1:
    movq -48(%rbp), %rdi
    addq $-2, %rdi
    movq 0(%rdi), %r8
    movq 8(%rdi), %r9
    movq %r8, -72(%rbp)
    movq %r9, -80(%rbp)
    jmp .Lssa_http____decoded_path_3
.Lssa_http____decoded_path_2:
    movq -48(%rbp), %r9
    addq $8, %r9
    cmpq $0, -48(%rbp)
    je .Lssa_http____decoded_path_5
.Lssa_http____decoded_path_4:
    movq -48(%rbp), %r11
    movq 0(%r11), %r8
    jmp .Lssa_http____decoded_path_6
.Lssa_http____decoded_path_5:
    xorl %r8d, %r8d
.Lssa_http____decoded_path_6:
    movq %r9, -72(%rbp)
    movq %r8, -80(%rbp)
.Lssa_http____decoded_path_3:
    leaq .K4(%rip), %rax
    addq $1, %rsi
    movslq %esi, %rsi
.Lssa_http____decoded_path_14:
    movq %rax, -88(%rbp)
    movq %rsi, %rbx
    xorps %xmm2, %xmm2
    movups %xmm2, -104(%rbp)
    movq $0, -112(%rbp)
.Lssa_http____decoded_path_15:
    cmpq -56(%rbp), %rbx
    jg .Lssa_http____decoded_path_13
.Lssa_http____decoded_path_35:
    movl $47, %edi
    movq -88(%rbp), %rax
    movq -96(%rbp), %rsi
    call __fn_http____put_byte.r
    movq %rax, %r14
    movq -88(%rbp), %rax
    call __fn___fern_arr_dec.r
    movq -96(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %rsi
.Lssa_http____decoded_path_34:
    movq %rbx, %r13
    movq %rsi, %rbx
.Lssa_http____decoded_path_40:
    cmpq -56(%rbp), %r13
    jge .Lssa_http____decoded_path_33
.Lssa_http____decoded_path_52:
    movl %r13d, %esi
    cmpq -80(%rbp), %rsi
    jb .Lssa_http____decoded_path_59
.Lssa_http____decoded_path_57:
    call __fern_oob_abort
.Lssa_http____decoded_path_59:
    movq -72(%rbp), %r11
    movzbl (%r11,%rsi), %r12d
    cmpq $47, %r12
    je .Lssa_http____decoded_path_33
.Lssa_http____decoded_path_51:
    movq -48(%rbp), %rax
    movq %r13, %rsi
    movq -56(%rbp), %rdi
    call __fn_http____path_byte.r
    movq %rax, %r8
    cmpq $0, %r8
    jge .Lssa_http____decoded_path_49
.Lssa_http____decoded_path_64:
    movq %r8, -120(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -120(%rbp), %r8
    jmp .Lssa_http____decoded_path_10
.Lssa_http____decoded_path_49:
    movl $1, %esi
    movq %r8, %rdi
    cmpq $128, %rdi
    setge %dil
    movzbq %dil, %rdi
    movq -112(%rbp), %r11
    testq %r11, %r11
    movq %rsi, %r11
    cmoveq %rdi, %r11
    movq %r11, -112(%rbp)
    movq %r8, %rdi
    andq $255, %rdi
    movq %r14, %rax
    movq %rbx, %rsi
    call __fn_http____put_byte.r
    movq %rax, %r15
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    leaq 1(%rbx), %rdi
    movslq %edi, %rbx
.Lssa_http____decoded_path_45:
    movl $3, %edi
    movl $1, %r8d
    cmpq $37, %r12
    cmovneq %r8, %rdi
    addq %r13, %rdi
    movslq %edi, %r13
    movq %r15, %r14
    cmpq -56(%rbp), %r13
    jl .Lssa_http____decoded_path_52
.Lssa_http____decoded_path_33:
    movq %r13, %r15
    cmpq -56(%rbp), %r15
    sete %r15b
    movzbq %r15b, %r15
    movq -96(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %rsi
    movq %r14, %rax
    movq %rbx, %rdi
    call __fn_http____dot_segment.r
    cmpq $0, %rax
    jne .Lssa_http____decoded_path_30
.Lssa_http____decoded_path_32:
    movq %rbx, -96(%rbp)
    movq $0, -104(%rbp)
    jmp .Lssa_http____decoded_path_16
.Lssa_http____decoded_path_30:
    cmpq $1, %rax
    jne .Lssa_http____decoded_path_27
.Lssa_http____decoded_path_29:
    jmp .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_27:
    cmpq $0, -96(%rbp)
    jne .Lssa_http____decoded_path_24
.Lssa_http____decoded_path_26:
    movq $-1, -96(%rbp)
    jmp .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_24:
    movq -96(%rbp), %rsi
    subq $1, %rsi
    movslq %esi, %rsi
.Lssa_http____decoded_path_23:
    movq %rsi, %rbx
.Lssa_http____decoded_path_95:
    cmpq (%r14), %rbx
    jae __fern_oob_abort
    movzbl 8(%r14,%rbx), %esi
    cmpq $47, %rsi
    je .Lssa_http____decoded_path_22
.Lssa_http____decoded_path_96:
    leaq -1(%rbx), %rsi
    movslq %esi, %rbx
    jmp .Lssa_http____decoded_path_95
.Lssa_http____decoded_path_22:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http____decoded_path_20
.Lssa_http____decoded_path_21:
    movq %r14, %rax
    movq %rbx, %rsi
    movq -96(%rbp), %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r12
.Lssa_http____decoded_path_107:
    movq %r12, %rax
    call __fn_utf8__is_valid.r
    movq %rax, %r8
    movq %r8, -120(%rbp)
    movq %r12, %rax
    call __fn___fern_str_free.r
    movq -120(%rbp), %r8
    testq %r8, %r8
    jz .Lssa_http____decoded_path_19
.Lssa_http____decoded_path_20:
    movq %rbx, -96(%rbp)
    jmp .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_19:
    movq $-1, -96(%rbp)
.Lssa_http____decoded_path_18:
    cmpq $0, -96(%rbp)
    jge .Lssa_http____decoded_path_17
.Lssa_http____decoded_path_114:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_http____decoded_path_9
.Lssa_http____decoded_path_17:
    movq %r15, -104(%rbp)
.Lssa_http____decoded_path_16:
    addq $1, %r13
    movslq %r13d, %rbx
    movq %r14, -88(%rbp)
    cmpq -56(%rbp), %rbx
    jle .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_13:
    pushq -64(%rbp)
    pushq -56(%rbp)
    pushq -48(%rbp)
    pushq -112(%rbp)
    pushq -104(%rbp)
    pushq -96(%rbp)
    pushq -88(%rbp)
    call __fn_http____finished_path
    addq $56, %rsp
    movq %rax, %rbx
    movq %rdx, %r13
    movq -88(%rbp), %rax
    call __fn___fern_arr_dec.r
    cmpq $0, %rbx
    jne .Lssa_http____decoded_path_7
.Lssa_http____decoded_path_11:
    movq %r13, %rdx
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_10:
    movl $400, %r8d
    movq %r8, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_9:
    movl $400, %r8d
    movq %r8, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_7:
    movq %r13, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____path_byte:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____path_byte.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
.Lssa_http____path_byte_0:
    movq %rax, %r8
    andq $2, %r8
    testq %r8, %r8
    jz .Lssa_http____path_byte_2
.Lssa_http____path_byte_1:
    leaq -2(%rax), %r8
    movq 0(%r8), %r9
    movq 8(%r8), %r10
    xchgq %r9, %r10
    jmp .Lssa_http____path_byte_3
.Lssa_http____path_byte_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____path_byte_5
.Lssa_http____path_byte_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____path_byte_3
.Lssa_http____path_byte_5:
    xorl %r9d, %r9d
.Lssa_http____path_byte_6:
.Lssa_http____path_byte_3:
    movl %esi, %r8d
    cmpq %r9, %r8
    jb .Lssa_http____path_byte_19
.Lssa_http____path_byte_17:
    call __fern_oob_abort.c
.Lssa_http____path_byte_19:
    movzbl (%r10,%r8), %ebx
    cmpq $37, %rbx
    jne .Lssa_http____path_byte_9
.Lssa_http____path_byte_16:
    call __fn_http____pct_byte.r
    cmpq $0, %rax
    jle .Lssa_http____path_byte_12
.Lssa_http____path_byte_15:
    cmpq $47, %rax
    je .Lssa_http____path_byte_12
.Lssa_http____path_byte_14:
    cmpq $63, %rax
    je .Lssa_http____path_byte_12
.Lssa_http____path_byte_13:
    cmpq $35, %rax
    jne .Lssa_http____path_byte_11
.Lssa_http____path_byte_12:
    movq $-1, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____path_byte_11:
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____path_byte_9:
    movq %rbx, %rax
    call __fn_http____is_pchar.r
    testq %rax, %rax
    jz .Lssa_http____path_byte_7
.Lssa_http____path_byte_8:
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____path_byte_7:
    movq $-1, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____finished_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
    movq 48(%rsp), %r10
__fn_http____finished_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $72, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
    movq %r8, -56(%rbp)
    movq %r10, -64(%rbp)
    movq 64(%rbp), %r11
    movq %r11, -72(%rbp)
.Lssa_http____finished_path_0:
    movq %r9, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____finished_path_2
.Lssa_http____finished_path_1:
    leaq -2(%r9), %rsi
    movq 0(%rsi), %r8
    movq 8(%rsi), %r10
    movq %r8, -80(%rbp)
    movq %r10, %r14
    jmp .Lssa_http____finished_path_3
.Lssa_http____finished_path_2:
    leaq 8(%r9), %r10
    cmpq $0, %r9
    je .Lssa_http____finished_path_5
.Lssa_http____finished_path_4:
    movq 0(%r9), %r8
    jmp .Lssa_http____finished_path_6
.Lssa_http____finished_path_5:
    xorl %r8d, %r8d
.Lssa_http____finished_path_6:
    movq %r10, -80(%rbp)
    movq %r8, %r14
.Lssa_http____finished_path_3:
    cmpq $0, -48(%rbp)
    je .Lssa_http____finished_path_15
.Lssa_http____finished_path_16:
    testq %rdi, %rdi
    jz .Lssa_http____finished_path_14
.Lssa_http____finished_path_15:
    movl $47, %edi
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    call __fn_http____put_byte.r
    movq %rax, %r12
    cmpq %rbx, %r12
    jne .Lssa_http____finished_path_27
.Lssa_http____finished_path_25:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
.Lssa_http____finished_path_27:
    movq -48(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %rsi
    movq %rsi, -48(%rbp)
    jmp .Lssa_http____finished_path_12
.Lssa_http____finished_path_14:
    movq %rbx, %r12
.Lssa_http____finished_path_13:
.Lssa_http____finished_path_12:
    movq -48(%rbp), %r15
    movq -64(%rbp), %r13
.Lssa_http____finished_path_29:
    cmpq -72(%rbp), %r13
    jge .Lssa_http____finished_path_11
.Lssa_http____finished_path_30:
    movl %r13d, %esi
    cmpq %r14, %rsi
    jb .Lssa_http____finished_path_37
.Lssa_http____finished_path_35:
    call __fern_oob_abort
.Lssa_http____finished_path_37:
    movq -80(%rbp), %r11
    movzbl (%r11,%rsi), %edi
    movq %r12, %rax
    movq %r15, %rsi
    call __fn_http____put_byte.r
    movq %rax, %r8
    cmpq %rbx, %r8
    jne .Lssa_http____finished_path_40
.Lssa_http____finished_path_38:
    movq %r8, -88(%rbp)
    movq %r8, %rax
    call __fn___fern_arr_dec.r
    movq -88(%rbp), %r8
.Lssa_http____finished_path_40:
    cmpq %rbx, %r12
    je .Lssa_http____finished_path_43
.Lssa_http____finished_path_41:
    movq %r8, -88(%rbp)
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq -88(%rbp), %r8
.Lssa_http____finished_path_43:
    leaq 1(%r15), %rdi
    movslq %edi, %r15
    addq $1, %r13
    movq %r8, %r12
    cmpq -72(%rbp), %r13
    jl .Lssa_http____finished_path_30
.Lssa_http____finished_path_11:
    xorl %r8d, %r8d
    movq %r12, %rax
    movq %r8, %rsi
    movq %r15, %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r13
.Lssa_http____finished_path_46:
    cmpq %rbx, %r12
    je .Lssa_http____finished_path_50
.Lssa_http____finished_path_48:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
.Lssa_http____finished_path_50:
    movq -56(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http____finished_path_8
.Lssa_http____finished_path_10:
    movq %r13, %rax
    call __fn_utf8__is_valid.r
    testq %rax, %rax
    jnz .Lssa_http____finished_path_8
.Lssa_http____finished_path_56:
    movq %r13, %rax
    call __fn___fern_str_free.r
    jmp .Lssa_http____finished_path_7
.Lssa_http____finished_path_8:
    movq %r13, %rdx
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____finished_path_7:
    movl $400, %r8d
    movq %r8, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____put_byte:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____put_byte.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa_http____put_byte_0:
    movq 0(%rbx), %rsi
    cmpq %rsi, %r12
    jge .Lssa_http____put_byte_1
.Lssa_http____put_byte_3:
    testb $1, %bl
    jnz .Lssa_http____put_byte_uq3
    cmpq $0x10000, %rbx
    jb .Lssa_http____put_byte_uq3
    cmpl $1, -8(%rbx)
.Lssa_http____put_byte_uq3:
    jne .Lssa_http____put_byte_9
.Lssa_http____put_byte_8:
    movq %rbx, %r14
    jmp .Lssa_http____put_byte_10
.Lssa_http____put_byte_9:
    xorl %esi, %esi
    movq 0(%rbx), %rdi
    movq %rbx, %rax
    call __fn___fern_arr_slice_u8.r
    movq %rax, %r14
.Lssa_http____put_byte_10:
    cmpq (%r14), %r12
    jae __fern_oob_abort.l5
    movb %r13b, 8(%r14,%r12)
    cmpq %rbx, %r14
    jne .Lssa_http____put_byte_13
.Lssa_http____put_byte_11:
    pushq %r14
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_http____put_byte_13:
    movq %r14, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____put_byte_1:
    movq %rbx, %rdi
    movq %r13, %rsi
    movq (%rdi), %rdx
    movq -16(%rdi), %rcx
    shlq $3, %rcx
    cmpq %rcx, %rdx
    jge .Lssa_http____put_byte_apush19s
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lssa_http____put_byte_apush19o
    testl %ecx, %ecx
    jns .Lssa_http____put_byte_apush19s
.Lssa_http____put_byte_apush19o:
    movb %sil, 8(%rdi,%rdx)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_http____put_byte_apush19e
.Lssa_http____put_byte_apush19s:
    call __fern_arr_push_u8
.Lssa_http____put_byte_apush19e:
    movq %rax, %r14
    cmpq %rbx, %r14
    jne .Lssa_http____put_byte_16
.Lssa_http____put_byte_14:
    pushq %r14
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_http____put_byte_16:
    movq %r14, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____is_digit:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http____is_digit.r:
.Lssa_http____is_digit_0:
    movq %rax, %rsi
    cmpq $57, %rsi
    setbe %sil
    movzbq %sil, %rsi
    xorl %edi, %edi
    cmpq $48, %rax
    movq %rsi, %rax
    cmovbq %rdi, %rax
    ret
    .cfi_endproc
__fn_http__serialize_response_to:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http__serialize_response_to.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $56, %rsp
    movq %rax, -48(%rbp)
    movq %rsi, -56(%rbp)
    movq %rdi, %r13
    movq %r8, -64(%rbp)
.Lssa_http__serialize_response_to_0:
    pushq %r13
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_http__serialize_response_to_55:
.Lssa_http__serialize_response_to_56:
    movq 24(%r13), %rax
    call __fn_http__fields_ok.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_58
.Lssa_http__serialize_response_to_60:
    movq %r13, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_http__serialize_response_to_57
.Lssa_http__serialize_response_to_58:
    movq 32(%r13), %rax
    call __fn_http__fields_ok.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_53
.Lssa_http__serialize_response_to_64:
    movq %r13, %rax
    call __fn___sem_release_HttpResponse.r
.Lssa_http__serialize_response_to_57:
    leaq .K7(%rip), %r13
    jmp .Lssa_http__serialize_response_to_56
.Lssa_http__serialize_response_to_53:
    movq 8(%r13), %r11
    movq %r11, -72(%rbp)
.Lssa_http__serialize_response_to_52:
    cmpq $200, -72(%rbp)
    jl .Lssa_http__serialize_response_to_48
.Lssa_http__serialize_response_to_50:
    cmpq $204, -72(%rbp)
    jne .Lssa_http__serialize_response_to_47
.Lssa_http__serialize_response_to_48:
    movq $1, -80(%rbp)
    jmp .Lssa_http__serialize_response_to_45
.Lssa_http__serialize_response_to_47:
    movq -72(%rbp), %rsi
    cmpq $304, %rsi
    sete %sil
    movzbq %sil, %rsi
    movq %rsi, -80(%rbp)
.Lssa_http__serialize_response_to_46:
.Lssa_http__serialize_response_to_45:
    leaq .SB8(%rip), %rsi
    leaq .SB8(%rip), %rdi
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http__serialize_response_to_43
.Lssa_http__serialize_response_to_44:
    movq %rsi, -96(%rbp)
    movq %rdi, -88(%rbp)
    jmp .Lssa_http__serialize_response_to_42
.Lssa_http__serialize_response_to_43:
    movq %r13, %rax
    call __fn_HttpResponse__body_text_lossy.r
    movq %rax, -88(%rbp)
    leaq .SB9(%rip), %r12
    movq -88(%rbp), %r11
    movq 8(%r11), %rax
    call __fn_int__int_to_string.r
    movq %rax, %r14
    movq %r12, %rax
    movq %r14, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %rbx
    movq %r14, %rax
    call __fn___fern_str_free.r
    leaq .SB10(%rip), %r14
    pushq %rbx
    pushq %r14
    call __fn___fern_str_grow
    addq $16, %rsp
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_85
.Lssa_http__serialize_response_to_84:
    movq %rbx, %r12
    jmp .Lssa_http__serialize_response_to_86
.Lssa_http__serialize_response_to_85:
    pushq %rbx
    pushq %r14
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %r12
    movq %rbx, %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_86:
    movq %r12, -96(%rbp)
.Lssa_http__serialize_response_to_42:
    movl $256, %edi
    call __fern_buf_new
    movq %rax, %r14
.Lssa_http__serialize_response_to_40:
    leaq .SB11(%rip), %rdi
    movq %rdi, %rsi
    movq %r14, %rdi
    call __fern_buf_push
    movq -72(%rbp), %rbx
    movslq %ebx, %rbx
.Lssa_http__serialize_response_to_39:
    cmpq $0, %rbx
    jge .Lssa_http__serialize_response_to_36
.Lssa_http__serialize_response_to_38:
    movl $45, %edi
    movq %rdi, %rsi
    movq %r14, %rdi
    call __fern_buf_push_byte
    xorl %edi, %edi
    subq %rbx, %rdi
    movq %rdi, %rsi
    movq %r14, %rdi
    call __fern_buf_push_decimal
    jmp .Lssa_http__serialize_response_to_35
.Lssa_http__serialize_response_to_36:
    movq %r14, %rdi
    movq %rbx, %rsi
    call __fern_buf_push_decimal
.Lssa_http__serialize_response_to_35:
    leaq .SB12(%rip), %rdi
    movq %rdi, %rsi
    movq %r14, %rdi
    call __fern_buf_push
.Lssa_http__serialize_response_to_33:
    leaq .K8(%rip), %rdi
    leaq .K9(%rip), %rsi
.Lssa_http__serialize_response_to_32:
    xorl %r8d, %r8d
.Lssa_http__serialize_response_to_92:
    movq 0(%rdi), %r9
    cmpq %r9, %r8
    jge .Lssa_http__serialize_response_to_31
.Lssa_http__serialize_response_to_95:
    movq 8(%rdi,%r8,8), %r9
    cmpq -72(%rbp), %r9
    je .Lssa_http__serialize_response_to_30
.Lssa_http__serialize_response_to_93:
    addq $1, %r8
    jmp .Lssa_http__serialize_response_to_92
.Lssa_http__serialize_response_to_31:
    leaq .SB8(%rip), %rdi
    movq %rdi, %rbx
    jmp .Lssa_http__serialize_response_to_29
.Lssa_http__serialize_response_to_30:
    cmpq (%rsi), %r8
    jae __fern_oob_abort
    movq 8(%rsi,%r8,8), %rbx
    pushq %rbx
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_http__serialize_response_to_29:
    movq 8(%rbx), %r8
    cmpq $0, %r8
    jne .Lssa_http__serialize_response_to_26
.Lssa_http__serialize_response_to_107:
    movq %rbx, %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_28:
    leaq .SB63(%rip), %r8
    movq %r8, %rbx
.Lssa_http__serialize_response_to_27:
.Lssa_http__serialize_response_to_26:
    movq %r14, %rdi
    movq %rbx, %rsi
    call __fern_buf_push
    movq %rbx, %rax
    call __fn___fern_str_free.r
    leaq .SB10(%rip), %r8
    movq %r14, %rdi
    movq %r8, %rsi
    call __fern_buf_push
.Lssa_http__serialize_response_to_25:
    xorl %ebx, %ebx
.Lssa_http__serialize_response_to_112:
    movq 24(%r13), %r8
    movq 8(%r8), %rsi
    movq 0(%rsi), %r8
    cmpq %r8, %rbx
    jl .Lssa_http__serialize_response_to_118
.Lssa_http__serialize_response_to_120:
    movq %r13, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_http__serialize_response_to_23
.Lssa_http__serialize_response_to_118:
    movq 24(%r13), %r12
    movq 8(%r12), %r8
    movq 8(%r8,%rbx,8), %r15
    leaq .SB64(%rip), %rsi
    movq %r15, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_113
.Lssa_http__serialize_response_to_117:
    leaq .SB65(%rip), %rsi
    movq %r15, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_113
.Lssa_http__serialize_response_to_116:
    leaq .SB66(%rip), %rsi
    movq %r15, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_113
.Lssa_http__serialize_response_to_114:
    movq 8(%r12), %rsi
    movq 8(%rsi,%rbx,8), %r8
    movq %r14, %rdi
    movq %r8, %rsi
    call __fern_buf_push
    leaq .SB67(%rip), %r8
    movq %r14, %rdi
    movq %r8, %rsi
    call __fern_buf_push
    movq 16(%r12), %r8
    cmpq (%r8), %rbx
    jae __fern_oob_abort
    movq 8(%r8,%rbx,8), %rsi
    movq %r14, %rdi
    call __fern_buf_push
    leaq .SB10(%rip), %rsi
    movq %r14, %rdi
    call __fern_buf_push
.Lssa_http__serialize_response_to_113:
    addq $1, %rbx
    jmp .Lssa_http__serialize_response_to_112
.Lssa_http__serialize_response_to_23:
    movq %r14, %rdi
    movq -96(%rbp), %rsi
    call __fern_buf_push
    movq -96(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_22:
    cmpq $101, -72(%rbp)
    jne .Lssa_http__serialize_response_to_18
.Lssa_http__serialize_response_to_21:
    leaq .SB68(%rip), %rsi
    movq %r14, %rdi
    call __fern_buf_push
    jmp .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_18:
    movq -64(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http__serialize_response_to_13
.Lssa_http__serialize_response_to_15:
    movq -56(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_http__serialize_response_to_8
.Lssa_http__serialize_response_to_14:
    movq -56(%rbp), %r11
    movq 0(%r11), %rsi
    movzbl 7(%rsi), %r8d
    cmpq $48, %r8
    jne .Lssa_http__serialize_response_to_8
    jmp .Lssa_http__serialize_response_to_10
.Lssa_http__serialize_response_to_13:
    leaq .SB69(%rip), %r8
    movq %r14, %rdi
    movq %r8, %rsi
    call __fern_buf_push
    jmp .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_10:
    leaq .SB70(%rip), %r8
    movq %r14, %rdi
    movq %r8, %rsi
    call __fern_buf_push
    jmp .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_8:
    leaq .SB10(%rip), %r8
    movq %r14, %rdi
    movq %r8, %rsi
    call __fern_buf_push
.Lssa_http__serialize_response_to_5:
    movq %r14, %rdi
    call __fern_buf_take
    movq %rax, %rbx
    movq %r14, %rdi
    call __fern_buf_free
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http__serialize_response_to_4
.Lssa_http__serialize_response_to_158:
    movq -88(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_http__serialize_response_to_3
.Lssa_http__serialize_response_to_4:
    leaq .SB71(%rip), %r8
    movq -48(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $4, %rsi
    jne .Lssa_http__serialize_response_to_1
.Lssa_http__serialize_response_to_162:
    movq -48(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%r8), %rdx
    jne .Lssa_http__serialize_response_to_streqn449
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_http__serialize_response_to_streqn449
    movq %r11, %rax
    movq %r8, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_http__serialize_response_to_streqd449
.Lssa_http__serialize_response_to_streqn449:
    xorl %eax, %eax
.Lssa_http__serialize_response_to_streqd449:
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_1
.Lssa_http__serialize_response_to_165:
    movq -88(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_3:
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http__serialize_response_to_1:
    pushq %rbx
    pushq -88(%rbp)
    call __fn___fern_str_grow
    addq $16, %rsp
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_170
.Lssa_http__serialize_response_to_169:
    movq %rbx, %r14
    jmp .Lssa_http__serialize_response_to_171
.Lssa_http__serialize_response_to_170:
    pushq %rbx
    pushq -88(%rbp)
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %r14
    movq %rbx, %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_171:
    movq -88(%rbp), %rax
    call __fn___fern_str_free.r
    movq %r14, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_HttpResponse__body_text_lossy:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_HttpResponse__body_text_lossy.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
.Lssa_HttpResponse__body_text_lossy_0:
    movq 16(%rax), %rsi
    movq 0(%rsi), %rdi
    cmpq $.S7, %rdi
    jne .Lssa_HttpResponse__body_text_lossy_1
.Lssa_HttpResponse__body_text_lossy_2:
    movq 8(%rsi), %rbx
    pushq %rbx
    call __fn___fern_rc_inc
    addq $8, %rsp
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_HttpResponse__body_text_lossy_1:
    movl $134, %esi
    movq %rsi, %r11
    movq %r11, %rdi
    movq $231, %rax
    syscall
    xorl %eax, %eax
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____lists_token:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_http____lists_token.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_http____lists_token_0:
    movq 8(%rbx), %r13
.Lssa_http____lists_token_3:
    xorl %esi, %esi
.Lssa_http____lists_token_4:
    cmpq %r13, %rsi
    jg .Lssa_http____lists_token_2
.Lssa_http____lists_token_8:
    movq %rsi, %r14
.Lssa_http____lists_token_14:
    cmpq %r13, %r14
    jge .Lssa_http____lists_token_7
.Lssa_http____lists_token_16:
    cmpq 8(%rbx), %r14
    jae __fern_str_oob_abort.l5
    movq (%rbx), %rdx
    movzbl (%rdx,%r14), %edi
    cmpq $44, %rdi
    je .Lssa_http____lists_token_7
.Lssa_http____lists_token_15:
    addq $1, %r14
    cmpq %r13, %r14
    jl .Lssa_http____lists_token_16
.Lssa_http____lists_token_7:
    movq %rbx, %rax
    movq %r14, %rdi
    movq %r12, %r8
    call __fn_http____token_at.r
    testq %rax, %rax
    jnz .Lssa_http____lists_token_1
.Lssa_http____lists_token_5:
    addq $1, %r14
    movslq %r14d, %rsi
    cmpq %r13, %rsi
    jle .Lssa_http____lists_token_8
.Lssa_http____lists_token_2:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http____lists_token_1:
    movl $1, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http__fields_ok:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http__fields_ok.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
.Lssa_http__fields_ok_0:
.Lssa_http__fields_ok_3:
    xorl %r12d, %r12d
.Lssa_http__fields_ok_4:
    movq 8(%rbx), %rsi
    movq 0(%rsi), %rdi
    cmpq %rdi, %r12
    jge .Lssa_http__fields_ok_2
.Lssa_http__fields_ok_13:
    movq 8(%rbx), %rdi
    movq 8(%rdi,%r12,8), %r13
.Lssa_http__fields_ok_11:
    movq 8(%r13), %rdi
    cmpq $0, %rdi
    jle .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_10:
    leaq .K2(%rip), %rdi
    xorl %esi, %esi
    movq %rdi, %rdx
    movq %rsi, %rcx
    movq %r13, %rax
    movq 8(%rax), %r8
    movq (%rax), %rax
    testq %rcx, %rcx
    jns .L70
    xorq %rcx, %rcx
.L70:
    leaq .S1(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L73
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L71:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L77
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L72
    addq $32, %r9
    jmp .L71
.L77:
    cmpq %r10, %r9
    jg .L78
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L72
    addq $16, %r9
.L78:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L73
.L72:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L76
.L73:
    cmpq %r8, %rcx
    jge .L75
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L74
    addq $1, %rcx
    jmp .L73
.L74:
    pushq %rcx
    jmp .L76
.L75:
    pushq %r8
.L76:
    popq %rax
    movq 8(%r13), %rsi
    cmpq %rsi, %rax
    jne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_7:
    movq 16(%rbx), %rsi
    cmpq (%rsi), %r12
    jae __fern_oob_abort.l3
    movq 8(%rsi,%r12,8), %r13
    leaq .K3(%rip), %rsi
    xorl %edi, %edi
    movq %rsi, %rdx
    movq %rdi, %rcx
    movq %r13, %rax
    movq 8(%rax), %r8
    movq (%rax), %rax
    testq %rcx, %rcx
    jns .L79
    xorq %rcx, %rcx
.L79:
    leaq .S2(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L82
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L80:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L86
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L81
    addq $32, %r9
    jmp .L80
.L86:
    cmpq %r10, %r9
    jg .L87
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L81
    addq $16, %r9
.L87:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L82
.L81:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L85
.L82:
    cmpq %r8, %rcx
    jge .L84
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L83
    addq $1, %rcx
    jmp .L82
.L83:
    pushq %rcx
    jmp .L85
.L84:
    pushq %r8
.L85:
    popq %rax
    movq 8(%r13), %rdi
    cmpq %rdi, %rax
    jne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_5:
    addq $1, %r12
    jmp .Lssa_http__fields_ok_4
.Lssa_http__fields_ok_2:
    movl $1, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_http__fields_ok_1:
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_fnv_str_seeded:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_fnv_str_seeded.r:
.Lssa___map_fnv_str_seeded_0:
    movl $2166136261, %edi
    movl %esi, %esi
    xorq %rsi, %rdi
    movq 8(%rax), %rsi
.Lssa___map_fnv_str_seeded_4:
    xorl %r8d, %r8d
.Lssa___map_fnv_str_seeded_5:
    leaq 4(%r8), %r9
    movslq %r9d, %r9
    cmpq %rsi, %r9
    jg .Lssa___map_fnv_str_seeded_13
.Lssa___map_fnv_str_seeded_6:
    leaq 3(%r8), %r9
    movslq %r9d, %r9
    movq %r8, %r10
    sarq $31, %r10
    orq %r10, %r9
    cmpq 8(%rax), %r9
    jae __fern_str_oob_abort.l0
    movq 0(%rax), %r10
    addq %r8, %r10
    movslq (%r10), %r10
    xorq %rdi, %r10
    imull $16777619, %r10d, %edi
    leaq 4(%r8), %r10
    movslq %r10d, %r8
    jmp .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmpq %rsi, %r8
    jge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    cmpq 8(%rax), %r8
    jae __fern_str_oob_abort.l0
    movq (%rax), %rdx
    movzbl (%rdx,%r8), %r10d
    xorq %rdi, %r10
    imull $16777619, %r10d, %edi
    addq $1, %r8
    cmpq %rsi, %r8
    jl .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    movq %rdi, %r8
    shrq $16, %r8
    xorq %r8, %rdi
    movl $2246822507, %r8d
    imull %r8d, %edi
    movq %rdi, %r8
    shrq $13, %r8
    xorq %r8, %rdi
    movl $3266489909, %r8d
    imull %r8d, %edi
    movq %rdi, %r8
    shrq $16, %r8
    xorq %r8, %rdi
    movslq %edi, %rax
    ret
    .cfi_endproc
__fn_string____str_maxsuf:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn_string____str_maxsuf.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $24, %rsp
    movq %rax, -48(%rbp)
    movq %rsi, -56(%rbp)
.Lssa_string____str_maxsuf_0:
.Lssa_string____str_maxsuf_2:
    movq $-1, %rbx
    xorl %r10d, %r10d
    movl $1, %r12d
    movl $1, %r13d
.Lssa_string____str_maxsuf_3:
    leaq (%r10,%r12), %rcx
    movslq %ecx, %r14
    cmpq -56(%rbp), %r14
    jge .Lssa_string____str_maxsuf_1
.Lssa_string____str_maxsuf_16:
    leaq (%r10,%r12), %rcx
    imulq %r9, %rcx
    leal (%r8,%rcx), %r14d
    movq -48(%rbp), %r11
    cmpq 8(%r11), %r14
    jae __fern_str_oob_abort
    movq (%r11), %rdx
    movzbl (%rdx,%r14), %r15d
    leaq (%rbx,%r12), %rcx
    imulq %r9, %rcx
    leal (%r8,%rcx), %r14d
    cmpq 8(%r11), %r14
    jae __fern_str_oob_abort
    movq (%r11), %rdx
    movzbl (%rdx,%r14), %esi
    testq %rdi, %rdi
    movq %rsi, %r14
    cmoveq %r15, %r14
    testq %rdi, %rdi
    cmoveq %rsi, %r15
    cmpq %r15, %r14
    jge .Lssa_string____str_maxsuf_11
.Lssa_string____str_maxsuf_12:
    leaq (%r10,%r12), %rsi
    movslq %esi, %rsi
    movq %rsi, %rcx
    subq %rbx, %rcx
    movslq %ecx, %rax
    movq %rsi, %r10
    movq %rax, %r13
    movl $1, %r12d
    jmp .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_11:
    cmpq %r15, %r14
    jne .Lssa_string____str_maxsuf_6
.Lssa_string____str_maxsuf_10:
    cmpq %r13, %r12
    jne .Lssa_string____str_maxsuf_8
.Lssa_string____str_maxsuf_9:
    leaq (%r10,%r13), %rcx
    movslq %ecx, %rsi
    movq %rsi, %r10
    movl $1, %r12d
    jmp .Lssa_string____str_maxsuf_7
.Lssa_string____str_maxsuf_8:
    addq $1, %r12
    movslq %r12d, %r12
.Lssa_string____str_maxsuf_7:
    movq %r10, %rsi
    jmp .Lssa_string____str_maxsuf_5
.Lssa_string____str_maxsuf_6:
    leaq 1(%r10), %rsi
    movslq %esi, %rsi
    movq %r10, %rbx
    movl $1, %r12d
    movl $1, %r13d
.Lssa_string____str_maxsuf_5:
    movq %rsi, %r10
.Lssa_string____str_maxsuf_4:
    jmp .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_1:
    movq %r13, %rdx
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string____str_find_from:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn_string____str_find_from.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
    movq %rdi, %r13
    movq %r8, %r14
.Lssa_string____str_find_from_0:
    xorl %esi, %esi
    cmpq $0, %r9
    movq %rsi, %r15
    cmovgeq %r9, %r15
    cmpq $0, %r14
    jne .Lssa_string____str_find_from_41
.Lssa_string____str_find_from_45:
    cmpq -48(%rbp), %r15
    movq -48(%rbp), %rax
    cmovleq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_41:
    movq -48(%rbp), %rsi
    subq %r15, %rsi
    movslq %esi, %rsi
    cmpq %rsi, %r14
    jle .Lssa_string____str_find_from_38
.Lssa_string____str_find_from_40:
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_38:
    cmpq $1, %r14
    jne .Lssa_string____str_find_from_35
.Lssa_string____str_find_from_37:
    cmpq $0, 8(%r13)
    jbe __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl 0(%rdx), %esi
    movq %r15, %rdx
    movq %rsi, %rcx
    movq %rbx, %rax
    movq 8(%rax), %r8
    movq (%rax), %rax
    cmpq $0, %rdx
    jge .L88
    xorq %rdx, %rdx
.L88:
    cmpq $255, %rcx
    ja .L92
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L96
.L94:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L95
    addq $32, %r9
    cmpq %r10, %r9
    jle .L94
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L96
.L95:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L93
.L96:
    vzeroupper
.L89:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L91
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L90
    addq $16, %rdx
    jmp .L89
.L90:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L93
.L91:
    cmpq %r8, %rdx
    jge .L92
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L97
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L92
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L92
    addq %r9, %rdx
    jmp .L93
.L97:
    cmpq %r8, %rdx
    jge .L92
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L93
    addq $1, %rdx
    jmp .L97
.L92:
    movq $-1, %rdx
.L93:
    movq %rdx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_35:
    cmpq $4, %r14
    jg .Lssa_string____str_find_from_30
.Lssa_string____str_find_from_33:
    movq -48(%rbp), %rsi
    subq %r14, %rsi
    movslq %esi, %rsi
.Lssa_string____str_find_from_74:
    cmpq %rsi, %r15
    jg .Lssa_string____str_find_from_32
.Lssa_string____str_find_from_79:
.Lssa_string____str_find_from_78:
    xorl %r9d, %r9d
.Lssa_string____str_find_from_84:
    cmpq %r14, %r9
    jge .Lssa_string____str_find_from_77
.Lssa_string____str_find_from_86:
    leal (%r15,%r9), %edi
    cmpq 8(%rbx), %rdi
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rdi), %r8d
    cmpq 8(%r13), %r9
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r9), %edi
    cmpq %rdi, %r8
    jne .Lssa_string____str_find_from_77
.Lssa_string____str_find_from_85:
    addq $1, %r9
    cmpq %r14, %r9
    jl .Lssa_string____str_find_from_86
.Lssa_string____str_find_from_77:
    cmpq %r14, %r9
    je .Lssa_string____str_find_from_26
.Lssa_string____str_find_from_75:
    leaq 1(%r15), %r9
    movslq %r9d, %r15
    cmpq %rsi, %r15
    jle .Lssa_string____str_find_from_79
.Lssa_string____str_find_from_32:
    movq $-1, %rax
    jmp .Lssa_string____str_find_from_25
.Lssa_string____str_find_from_30:
    xorl %r11d, %r11d
    movq %r11, -56(%rbp)
    movl $1, %r11d
    movq %r11, -64(%rbp)
.Lssa_string____str_find_from_28:
    cmpq $3, %r14
    jge .Lssa_string____str_find_from_23
.Lssa_string____str_find_from_27:
    leaq -1(%r14), %r9
    movq %r9, %rdi
    movq $1, -72(%rbp)
    jmp .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_26:
    movq %r15, %rax
.Lssa_string____str_find_from_25:
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_23:
    xorl %edi, %edi
    movq %r13, %rax
    movq %r14, %rsi
    movq -56(%rbp), %r8
    movq -64(%rbp), %r9
    call __fn_string____str_maxsuf.r
    movq %rax, %r12
    movq %rdx, -72(%rbp)
    movl $1, %edi
    movq %r13, %rax
    movq %r14, %rsi
    movq -56(%rbp), %r8
    movq -64(%rbp), %r9
    call __fn_string____str_maxsuf.r
    movq %rax, -80(%rbp)
    movq %rdx, %rax
    cmpq %r12, -80(%rbp)
    jge .Lssa_string____str_find_from_20
.Lssa_string____str_find_from_22:
    addq $1, %r12
    movslq %r12d, %r12
    movq %r12, %rdi
    jmp .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_20:
    movq -80(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %rdi
    movq %rax, -72(%rbp)
.Lssa_string____str_find_from_19:
    movq -48(%rbp), %r9
    subq %r14, %r9
    movslq %r9d, %r11
    movq %r11, -48(%rbp)
.Lssa_string____str_find_from_18:
.Lssa_string____str_find_from_17:
    xorl %esi, %esi
.Lssa_string____str_find_from_114:
    cmpq %rdi, %rsi
    jge .Lssa_string____str_find_from_13
.Lssa_string____str_find_from_117:
    movq -72(%rbp), %r8
    addl %esi, %r8d
    cmpq 8(%r13), %r8
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r8), %r10d
    movl %esi, %r8d
    cmpq 8(%r13), %r8
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r8), %r12d
    cmpq %r12, %r10
    jne .Lssa_string____str_find_from_8
.Lssa_string____str_find_from_115:
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_string____str_find_from_117
.Lssa_string____str_find_from_13:
.Lssa_string____str_find_from_12:
    movq %r14, %rsi
    subq -72(%rbp), %rsi
    movslq %esi, %r11
    movq %r11, -56(%rbp)
    xorl %r8d, %r8d
.Lssa_string____str_find_from_133:
    cmpq -48(%rbp), %r15
    jg .Lssa_string____str_find_from_11
.Lssa_string____str_find_from_145:
    cmpq %rdi, %r8
    movq %r8, %r10
    cmovleq %rdi, %r10
.Lssa_string____str_find_from_155:
    cmpq %r14, %r10
    jge .Lssa_string____str_find_from_141
.Lssa_string____str_find_from_157:
    movl %r10d, %r12d
    cmpq 8(%r13), %r12
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r12), %esi
    leal (%r10,%r15), %r12d
    cmpq 8(%rbx), %r12
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r12), %r9d
    cmpq %r9, %rsi
    jne .Lssa_string____str_find_from_141
.Lssa_string____str_find_from_156:
    addq $1, %r10
    cmpq %r14, %r10
    jl .Lssa_string____str_find_from_157
.Lssa_string____str_find_from_141:
    cmpq %r14, %r10
    jl .Lssa_string____str_find_from_135
.Lssa_string____str_find_from_140:
    leaq -1(%rdi), %r9
    movslq %r9d, %r9
.Lssa_string____str_find_from_139:
.Lssa_string____str_find_from_172:
    cmpq %r8, %r9
    jl .Lssa_string____str_find_from_138
.Lssa_string____str_find_from_174:
    cmpq 8(%r13), %r9
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r9), %esi
    leal (%r9,%r15), %r12d
    cmpq 8(%rbx), %r12
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r12), %eax
    cmpq %rax, %rsi
    jne .Lssa_string____str_find_from_138
.Lssa_string____str_find_from_173:
    leaq -1(%r9), %rsi
    movslq %esi, %r9
    cmpq %r8, %r9
    jge .Lssa_string____str_find_from_174
.Lssa_string____str_find_from_138:
    cmpq %r8, %r9
    jl .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_136:
    movq %r15, %r9
    addq -72(%rbp), %r9
    movslq %r9d, %r9
    movq %r9, %r15
    movq -56(%rbp), %r8
    jmp .Lssa_string____str_find_from_133
.Lssa_string____str_find_from_135:
    subq %rdi, %r10
    addq %r15, %r10
    addq $1, %r10
    movslq %r10d, %r10
    movq %r10, %r15
    xorl %r8d, %r8d
.Lssa_string____str_find_from_134:
    cmpq -48(%rbp), %r15
    jle .Lssa_string____str_find_from_145
.Lssa_string____str_find_from_11:
    movq $-1, %r15
.Lssa_string____str_find_from_10:
    jmp .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_8:
    movq %r14, %r8
    subq %rdi, %r8
    movslq %r8d, %r8
    movq %r14, %r10
    subq %rdi, %r10
    cmpq %rdi, %r8
    cmovleq %rdi, %r10
    addq $1, %r10
.Lssa_string____str_find_from_4:
.Lssa_string____str_find_from_199:
    cmpq -48(%rbp), %r15
    jg .Lssa_string____str_find_from_3
.Lssa_string____str_find_from_208:
    movq %rdi, %r8
.Lssa_string____str_find_from_214:
    cmpq %r14, %r8
    jge .Lssa_string____str_find_from_207
.Lssa_string____str_find_from_216:
    movl %r8d, %r9d
    cmpq 8(%r13), %r9
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r9), %esi
    leal (%r8,%r15), %r9d
    cmpq 8(%rbx), %r9
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r9), %eax
    cmpq %rax, %rsi
    jne .Lssa_string____str_find_from_207
.Lssa_string____str_find_from_215:
    addq $1, %r8
    cmpq %r14, %r8
    jl .Lssa_string____str_find_from_216
.Lssa_string____str_find_from_207:
    cmpq %r14, %r8
    jl .Lssa_string____str_find_from_201
.Lssa_string____str_find_from_206:
    leaq -1(%rdi), %r9
    movslq %r9d, %r9
.Lssa_string____str_find_from_205:
.Lssa_string____str_find_from_231:
    cmpq $0, %r9
    jl .Lssa_string____str_find_from_204
.Lssa_string____str_find_from_233:
    cmpq 8(%r13), %r9
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r9), %esi
    leal (%r9,%r15), %eax
    cmpq 8(%rbx), %rax
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rax), %r12d
    cmpq %r12, %rsi
    jne .Lssa_string____str_find_from_204
.Lssa_string____str_find_from_232:
    leaq -1(%r9), %rsi
    movslq %esi, %r9
    cmpq $0, %r9
    jge .Lssa_string____str_find_from_233
.Lssa_string____str_find_from_204:
    cmpq $0, %r9
    jl .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_202:
    leaq (%r15,%r10), %r9
    movslq %r9d, %r9
    movq %r9, %r15
    jmp .Lssa_string____str_find_from_199
.Lssa_string____str_find_from_201:
    subq %rdi, %r8
    addq %r15, %r8
    addq $1, %r8
    movslq %r8d, %r8
    movq %r8, %r15
.Lssa_string____str_find_from_200:
    cmpq -48(%rbp), %r15
    jle .Lssa_string____str_find_from_208
.Lssa_string____str_find_from_3:
    movq $-1, %r15
.Lssa_string____str_find_from_2:
.Lssa_string____str_find_from_1:
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string__split:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_string__split.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $152, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa_string__split_0:
    movq 8(%rbx), %r11
    movq %r11, -56(%rbp)
    movq -48(%rbp), %r11
    movq 8(%r11), %r11
    movq %r11, -64(%rbp)
    leaq .K0(%rip), %r11
    movq %r11, -72(%rbp)
    cmpq $0, -64(%rbp)
    jne .Lssa_string__split_3
.Lssa_string__split_7:
    movq 8(%rbx), %r11
    movq %r11, -80(%rbp)
    leaq .K0(%rip), %rdi
.Lssa_string__split_6:
    movq %rdi, %r12
    xorl %r13d, %r13d
.Lssa_string__split_13:
    cmpq -80(%rbp), %r13
    jge .Lssa_string__split_5
.Lssa_string__split_14:
    movq %rbx, %rax
    movq %r13, %rsi
    movq -80(%rbp), %rdi
    call __fn_utf8_scalar__step.r
    addq %r13, %rax
    movslq %eax, %r14
    movq %rbx, %rdx
    movq %r13, %rcx
    movq %r14, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -104(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r15
    leaq .SB8(%rip), %rdi
    movq %r15, %rax
    movq %rdi, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r13
    pushq %r15
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r12, %rdi
    movq %r13, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_string__split_apush73s
.Lssa_string__split_apush73o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_string__split_apush73e
.Lssa_string__split_apush73s:
    call __fern_arr_push_owned
.Lssa_string__split_apush73e:
    movq %rax, %r12
    movq %r14, %r13
    cmpq -80(%rbp), %r13
    jl .Lssa_string__split_14
.Lssa_string__split_5:
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string__split_3:
    xorl %r9d, %r9d
    movq %rbx, %rax
    movq -56(%rbp), %rsi
    movq -48(%rbp), %rdi
    movq -64(%rbp), %r8
    call __fn_string____str_find_from.r
.Lssa_string__split_2:
    movq -72(%rbp), %r12
    movq %rax, %r13
    xorl %r9d, %r9d
.Lssa_string__split_21:
    cmpq $0, %r13
    jl .Lssa_string__split_1
.Lssa_string__split_22:
    movq %rbx, %rdx
    movq %r9, %rcx
    movq %r13, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -128(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r14
    leaq .SB8(%rip), %rdi
    movq %r14, %rax
    movq %rdi, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r15
    pushq %r14
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r12, %rdi
    movq %r15, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_string__split_apush94s
.Lssa_string__split_apush94o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_string__split_apush94e
.Lssa_string__split_apush94s:
    movq %r9, -160(%rbp)
    call __fern_arr_push_owned
    movq -160(%rbp), %r9
.Lssa_string__split_apush94e:
    movq %rax, %r12
    addq -64(%rbp), %r13
    movslq %r13d, %r13
    movq %rbx, %rax
    movq -56(%rbp), %rsi
    movq -48(%rbp), %rdi
    movq -64(%rbp), %r8
    movq %r13, %r9
    call __fn_string____str_find_from.r
    movq %r13, %r9
    movq %rax, %r13
    cmpq $0, %r13
    jge .Lssa_string__split_22
.Lssa_string__split_1:
    movq %rbx, %rdx
    movq %r9, %rcx
    movq -56(%rbp), %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -152(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r13
    leaq .SB8(%rip), %r9
    movq %r13, %rax
    movq %r9, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %rbx
    pushq %r13
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r12, %rdi
    movq %rbx, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_string__split_apush102s
.Lssa_string__split_apush102o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_string__split_apush102e
.Lssa_string__split_apush102s:
    call __fern_arr_push_owned
.Lssa_string__split_apush102e:
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string__eq_ignore_ascii_case:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_string__eq_ignore_ascii_case.r:
.Lssa_string__eq_ignore_ascii_case_0:
    movq 8(%rax), %rdi
    movq 8(%rsi), %r8
    cmpq %r8, %rdi
    je .Lssa_string__eq_ignore_ascii_case_4
.Lssa_string__eq_ignore_ascii_case_6:
    xorl %eax, %eax
    ret
.Lssa_string__eq_ignore_ascii_case_4:
.Lssa_string__eq_ignore_ascii_case_3:
    xorl %r8d, %r8d
.Lssa_string__eq_ignore_ascii_case_11:
    cmpq %rdi, %r8
    jge .Lssa_string__eq_ignore_ascii_case_2
.Lssa_string__eq_ignore_ascii_case_17:
    movq 0(%rax), %r9
    movzbl (%r9,%r8), %r10d
    cmpq 8(%rsi), %r8
    jae __fern_str_oob_abort.l0
    movq (%rsi), %rdx
    movzbl (%rdx,%r8), %r9d
    xorq %r10, %r9
    cmpq $0, %r9
    je .Lssa_string__eq_ignore_ascii_case_12
.Lssa_string__eq_ignore_ascii_case_16:
    cmpq $32, %r9
    jne .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_15:
    movq %r10, %r9
    orq $32, %r9
    cmpq $97, %r9
    jl .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_14:
    orq $32, %r10
    cmpq $122, %r10
    jg .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_12:
    addq $1, %r8
    cmpq %rdi, %r8
    jl .Lssa_string__eq_ignore_ascii_case_17
.Lssa_string__eq_ignore_ascii_case_2:
    movl $1, %eax
    ret
.Lssa_string__eq_ignore_ascii_case_1:
    xorl %eax, %eax
    ret
    .cfi_endproc
__fn_HeaderMap__append:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_HeaderMap__append.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, -48(%rbp)
.Lssa_HeaderMap__append_0:
    testb $1, %bl
    jnz .Lssa_HeaderMap__append_uq0
    cmpq $0x10000, %rbx
    jb .Lssa_HeaderMap__append_uq0
    cmpl $1, -8(%rbx)
.Lssa_HeaderMap__append_uq0:
    jne .Lssa_HeaderMap__append_2
.Lssa_HeaderMap__append_1:
    movq %rbx, %r14
    jmp .Lssa_HeaderMap__append_3
.Lssa_HeaderMap__append_2:
    xorl %r14d, %r14d
.Lssa_HeaderMap__append_3:
    movq 8(%rbx), %r15
    cmpq $0, %r14
    jne .Lssa_HeaderMap__append_6
.Lssa_HeaderMap__append_4:
    pushq %r15
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_HeaderMap__append_6:
    pushq %r12
    call __fn___fern_rc_inc
    addq $8, %rsp
    testb $1, %r15b
    jnz .Lssa_HeaderMap__append_uq6
    cmpq $0x10000, %r15
    jb .Lssa_HeaderMap__append_uq6
    cmpl $1, -8(%r15)
.Lssa_HeaderMap__append_uq6:
    jne .Lssa_HeaderMap__append_8
.Lssa_HeaderMap__append_7:
    movq %r15, %rdi
    movq %r12, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_HeaderMap__append_apush20s
.Lssa_HeaderMap__append_apush20o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_HeaderMap__append_apush20e
.Lssa_HeaderMap__append_apush20s:
    call __fern_arr_push_owned
.Lssa_HeaderMap__append_apush20e:
    movq %rax, %r13
    jmp .Lssa_HeaderMap__append_9
.Lssa_HeaderMap__append_8:
    movq %r15, %rdi
    movq %r12, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_HeaderMap__append_apush21s
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lssa_HeaderMap__append_apush21o
    testl %ecx, %ecx
    jns .Lssa_HeaderMap__append_apush21s
.Lssa_HeaderMap__append_apush21o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_HeaderMap__append_apush21e
.Lssa_HeaderMap__append_apush21s:
    call __fern_arr_push
.Lssa_HeaderMap__append_apush21e:
    movq %rax, %r13
    movq %r15, %rax
    call __fn___fern_arr_inc_elems.r
    movq %r15, %rax
    call __fn___fern_arr_dec.r
.Lssa_HeaderMap__append_9:
    movq 16(%rbx), %r15
    cmpq $0, %r14
    jne .Lssa_HeaderMap__append_12
.Lssa_HeaderMap__append_10:
    pushq %r15
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_HeaderMap__append_12:
    pushq -48(%rbp)
    call __fn___fern_rc_inc
    addq $8, %rsp
    testb $1, %r15b
    jnz .Lssa_HeaderMap__append_uq12
    cmpq $0x10000, %r15
    jb .Lssa_HeaderMap__append_uq12
    cmpl $1, -8(%r15)
.Lssa_HeaderMap__append_uq12:
    jne .Lssa_HeaderMap__append_14
.Lssa_HeaderMap__append_13:
    movq %r15, %rdi
    movq -48(%rbp), %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_HeaderMap__append_apush31s
.Lssa_HeaderMap__append_apush31o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_HeaderMap__append_apush31e
.Lssa_HeaderMap__append_apush31s:
    call __fern_arr_push_owned
.Lssa_HeaderMap__append_apush31e:
    movq %rax, %r12
    jmp .Lssa_HeaderMap__append_15
.Lssa_HeaderMap__append_14:
    movq %r15, %rdi
    movq -48(%rbp), %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_HeaderMap__append_apush32s
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lssa_HeaderMap__append_apush32o
    testl %ecx, %ecx
    jns .Lssa_HeaderMap__append_apush32s
.Lssa_HeaderMap__append_apush32o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_HeaderMap__append_apush32e
.Lssa_HeaderMap__append_apush32s:
    call __fern_arr_push
.Lssa_HeaderMap__append_apush32e:
    movq %rax, %r12
    movq %r15, %rax
    call __fn___fern_arr_inc_elems.r
    movq %r15, %rax
    call __fn___fern_arr_dec.r
.Lssa_HeaderMap__append_15:
    cmpq $0, %r14
    jne .Lssa_HeaderMap__append_17
.Lssa_HeaderMap__append_16:
    movl $3, %esi
    movq %r14, %rax
    call __fn___fern_alloc_reuse.r
    leaq .S0(%rip), %rsi
    movq %rsi, 0(%rax)
    movq %rax, %r15
    jmp .Lssa_HeaderMap__append_18
.Lssa_HeaderMap__append_17:
    movq %r14, %r15
.Lssa_HeaderMap__append_18:
    cmpq $0, %r14
    jne .Lssa_HeaderMap__append_21
.Lssa_HeaderMap__append_20:
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_HeaderMap__append_21:
    movq %r13, 8(%r15)
    movq %r12, 16(%r15)
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_io_buffered__BufBlock__drop:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_io_buffered__BufBlock__drop.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa_io_buffered__BufBlock__drop_0:
    movq 8(%rax), %rsi
    movq %rsi, %rdi
    call __fern_buf_free
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_json__JsonError__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_json__JsonError__eq.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_json__JsonError__eq_0:
    movq 8(%rbx), %rsi
    movq 8(%r12), %rdi
    movq 8(%rsi), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_json__JsonError__eq_streqn22
    movq %rdi, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_json__JsonError__eq_streqd22
.Lssa_json__JsonError__eq_streqn22:
    xorl %eax, %eax
.Lssa_json__JsonError__eq_streqd22:
    testq %rax, %rax
    jz .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_9:
    movq 16(%rbx), %rdi
    movq 16(%r12), %rsi
    cmpq %rsi, %rdi
    jne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_6:
    movq 24(%rbx), %rsi
    movq 24(%r12), %rdi
    cmpq %rdi, %rsi
    jne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_3:
    movq 32(%rbx), %rdi
    movq 32(%r12), %rsi
    movq %rdi, %rax
    cmpq %rsi, %rax
    sete %al
    movzbq %al, %rax
    jmp .Lssa_json__JsonError__eq_1
.Lssa_json__JsonError__eq_2:
    xorl %eax, %eax
.Lssa_json__JsonError__eq_1:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_utf8__is_valid:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_utf8__is_valid.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
.Lssa_utf8__is_valid_0:
.Lssa_utf8__is_valid_21:
    movq 8(%rbx), %r12
.Lssa_utf8__is_valid_20:
    xorl %r13d, %r13d
.Lssa_utf8__is_valid_22:
    cmpq %r12, %r13
    jge .Lssa_utf8__is_valid_19
.Lssa_utf8__is_valid_70:
    cmpq 8(%rbx), %r13
    jae __fern_str_oob_abort.l5
    movq (%rbx), %rdx
    movzbl (%rdx,%r13), %r14d
    cmpq $128, %r14
    jge .Lssa_utf8__is_valid_65
.Lssa_utf8__is_valid_69:
    movq %r13, %rdx
    movq %rbx, %rax
    movq 8(%rax), %r8
    movq (%rax), %rax
    cmpq $0, %rdx
    jge .L98
    xorq %rdx, %rdx
.L98:
.L104:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $32, %r9
    jl .L106
    vmovdqu (%rax,%rdx), %ymm0
    vpmovmskb %ymm0, %r9d
    testl %r9d, %r9d
    jnz .L105
    addq $32, %rdx
    jmp .L104
.L105:
    vzeroupper
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L103
.L106:
    vzeroupper
.L99:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L101
    movdqu (%rax,%rdx), %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L100
    addq $16, %rdx
    jmp .L99
.L100:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L103
.L101:
    cmpq %r8, %rdx
    jge .L102
    movzbq (%rax,%rdx), %r9
    testq $128, %r9
    jnz .L103
    addq $1, %rdx
    jmp .L101
.L102:
    movq %r8, %rdx
.L103:
    movq %rdx, %rax
    cmpq %r12, %rax
    jge .Lssa_utf8__is_valid_18
.Lssa_utf8__is_valid_67:
    cmpq 8(%rbx), %rax
    jae __fern_str_oob_abort.l5
    movq (%rbx), %rdx
    movzbl (%rdx,%rax), %esi
    movq %rax, %r13
    movq %rsi, %r14
.Lssa_utf8__is_valid_66:
.Lssa_utf8__is_valid_65:
    cmpq $192, %r14
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_64:
    cmpq $224, %r14
    jge .Lssa_utf8__is_valid_55
.Lssa_utf8__is_valid_63:
    leaq 1(%r13), %rsi
    movslq %esi, %rsi
    cmpq %r12, %rsi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_61:
    leal 1(%r13), %esi
    cmpq 8(%rbx), %rsi
    jae __fern_str_oob_abort.l5
    movq (%rbx), %rdx
    movzbl (%rdx,%rsi), %edi
    cmpq $128, %rdi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_60:
    cmpq $192, %rdi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_58:
    leaq -192(%r14), %rsi
    shlq $6, %rsi
    movslq %esi, %rsi
    subq $128, %rdi
    movslq %edi, %rdi
    orq %rdi, %rsi
    cmpq $128, %rsi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_56:
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    movq %rsi, %r13
    jmp .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_55:
    cmpq $240, %r14
    jge .Lssa_utf8__is_valid_40
.Lssa_utf8__is_valid_54:
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    cmpq %r12, %rsi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_52:
    leaq 1(%r13), %rsi
    movslq %esi, %rsi
    leaq 1(%rsi), %rdi
    movslq %edi, %rdi
    movq %rsi, %r8
    sarq $31, %r8
    orq %r8, %rdi
    cmpq 8(%rbx), %rdi
    jae __fern_str_oob_abort.l5
    movq 0(%rbx), %r8
    movzbl (%r8,%rsi), %edi
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    movzbl (%r8,%rsi), %r9d
    cmpq $128, %rdi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_51:
    cmpq $192, %rdi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_49:
    cmpq $128, %r9
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_48:
    cmpq $192, %r9
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_46:
    leaq -224(%r14), %rsi
    shlq $12, %rsi
    movslq %esi, %rsi
    subq $128, %rdi
    shlq $6, %rdi
    movslq %edi, %rdi
    orq %rdi, %rsi
    subq $128, %r9
    movslq %r9d, %r9
    orq %r9, %rsi
    cmpq $2048, %rsi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_44:
    cmpq $55296, %rsi
    jl .Lssa_utf8__is_valid_41
.Lssa_utf8__is_valid_43:
    cmpq $57343, %rsi
    jle .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_41:
    leaq 3(%r13), %rsi
    movslq %esi, %rsi
    movq %rsi, %r13
    jmp .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_40:
    cmpq $248, %r14
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_39:
    leaq 3(%r13), %rsi
    movslq %esi, %rsi
    cmpq %r12, %rsi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_37:
    leaq 1(%r13), %rsi
    movslq %esi, %rsi
    leaq 2(%rsi), %r9
    movslq %r9d, %r9
    movq %rsi, %rdi
    sarq $31, %rdi
    orq %rdi, %r9
    cmpq 8(%rbx), %r9
    jae __fern_str_oob_abort.l5
    movq 0(%rbx), %rdi
    movzbl (%rdi,%rsi), %r9d
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    movzbl (%rdi,%rsi), %r8d
    leaq 3(%r13), %rsi
    movslq %esi, %rsi
    movzbl (%rdi,%rsi), %r10d
    cmpq $128, %r9
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_36:
    cmpq $192, %r9
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_34:
    cmpq $128, %r8
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_33:
    cmpq $192, %r8
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_31:
    cmpq $128, %r10
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_30:
    cmpq $192, %r10
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_28:
    subq $240, %r14
    shlq $18, %r14
    movslq %r14d, %r14
    subq $128, %r9
    shlq $12, %r9
    movslq %r9d, %r9
    orq %r9, %r14
    subq $128, %r8
    shlq $6, %r8
    movslq %r8d, %r8
    orq %r8, %r14
    subq $128, %r10
    movslq %r10d, %r10
    orq %r10, %r14
    cmpq $65536, %r14
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_26:
    cmpq $1114111, %r14
    jg .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_24:
    leaq 4(%r13), %r10
    movslq %r10d, %r10
    movq %r10, %r13
.Lssa_utf8__is_valid_23:
    cmpq %r12, %r13
    jl .Lssa_utf8__is_valid_70
.Lssa_utf8__is_valid_19:
    movq %r12, %r13
    jmp .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_18:
    movq %r12, %r13
.Lssa_utf8__is_valid_17:
.Lssa_utf8__is_valid_16:
.Lssa_utf8__is_valid_15:
.Lssa_utf8__is_valid_14:
.Lssa_utf8__is_valid_13:
.Lssa_utf8__is_valid_12:
.Lssa_utf8__is_valid_11:
.Lssa_utf8__is_valid_10:
.Lssa_utf8__is_valid_9:
.Lssa_utf8__is_valid_8:
.Lssa_utf8__is_valid_7:
.Lssa_utf8__is_valid_6:
.Lssa_utf8__is_valid_5:
.Lssa_utf8__is_valid_4:
.Lssa_utf8__is_valid_3:
.Lssa_utf8__is_valid_2:
.Lssa_utf8__is_valid_1:
    movq 8(%rbx), %r10
    movq %r13, %rax
    cmpq %r10, %rax
    sete %al
    movzbq %al, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___primitive_i32_to_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___primitive_i32_to_string.r:
.Lssa___primitive_i32_to_string_0:
    jmp __fn_int__int_to_string.r
    .cfi_endproc
__fn___primitive_i64_to_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___primitive_i64_to_string.r:
.Lssa___primitive_i64_to_string_0:
    cmpq $0, %rax
    jge .Lssa___primitive_i64_to_string_1
.Lssa___primitive_i64_to_string_3:
    xorl %esi, %esi
    subq %rax, %rsi
    movl $1, %edi
    movq %rsi, %rax
    movq %rdi, %rsi
    jmp __fn_int____int_to_string_u64.r
.Lssa___primitive_i64_to_string_1:
    xorl %esi, %esi
    jmp __fn_int____int_to_string_u64.r
    .cfi_endproc
__fn_int__int_to_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_int__int_to_string.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
.Lssa_int__int_to_string_0:
    cmpq $0, %rax
    jl .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_47:
    cmpq $100, %rax
    jge .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_46:
    leaq .K10(%rip), %rsi
    cmpq (%rsi), %rax
    jae __fern_oob_abort
    movq 8(%rsi,%rax,8), %rbx
    pushq %rbx
    call __fn___fern_rc_inc
    addq $8, %rsp
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_int__int_to_string_44:
    xorl %esi, %esi
    xorl %edi, %edi
    subq %rax, %rdi
    movl $1, %r8d
    cmpq $0, %rax
    cmovgeq %rax, %rdi
    movq %r8, %r11
    cmovgeq %rsi, %r11
    movq %r11, -48(%rbp)
    movl %edi, %r12d
.Lssa_int__int_to_string_40:
    cmpq $10, %r12
    jae .Lssa_int__int_to_string_37
.Lssa_int__int_to_string_39:
    movl $1, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_37:
    cmpq $100, %r12
    jae .Lssa_int__int_to_string_34
.Lssa_int__int_to_string_36:
    movl $2, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_34:
    cmpq $1000, %r12
    jae .Lssa_int__int_to_string_31
.Lssa_int__int_to_string_33:
    movl $3, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_31:
    cmpq $10000, %r12
    jae .Lssa_int__int_to_string_28
.Lssa_int__int_to_string_30:
    movl $4, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_28:
    cmpq $100000, %r12
    jae .Lssa_int__int_to_string_25
.Lssa_int__int_to_string_27:
    movl $5, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_25:
    cmpq $1000000, %r12
    jae .Lssa_int__int_to_string_22
.Lssa_int__int_to_string_24:
    movl $6, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_22:
    cmpq $10000000, %r12
    jae .Lssa_int__int_to_string_19
.Lssa_int__int_to_string_21:
    movl $7, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_19:
    cmpq $100000000, %r12
    jae .Lssa_int__int_to_string_16
.Lssa_int__int_to_string_18:
    movl $8, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_16:
    cmpq $1000000000, %r12
    jae .Lssa_int__int_to_string_13
.Lssa_int__int_to_string_15:
    movl $9, %edi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_13:
    movl $10, %edi
.Lssa_int__int_to_string_12:
    leaq 1(%rdi), %r8
    movslq %r8d, %r8
    movq -48(%rbp), %r11
    testq %r11, %r11
    movq %r8, %r13
    cmoveq %rdi, %r13
    movq %r13, %rdi
    call __fern_alloc_bytes
    movq %rax, %r14
    leaq .SB172(%rip), %r8
.Lssa_int__int_to_string_8:
.Lssa_int__int_to_string_113:
    cmpq $100, %r12
    jb .Lssa_int__int_to_string_7
.Lssa_int__int_to_string_114:
    movq %r12, %rax
    movl %eax, %ecx
    movl $1374389535, %eax
    mull %ecx
    shrl $5, %edx
    movl %edx, %eax
    movq %rax, %rdi
    imulq $100, %rdi, %rsi
    movq %r12, %r11
    subq %rsi, %r11
    movq %r11, %rsi
    leaq -2(%r13), %r9
    movslq %r9d, %r13
    shlq $1, %rsi
    movslq %esi, %rsi
    cmpq 8(%r8), %rsi
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%rsi), %r9d
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r13)
    leal 1(%r13), %r10d
    addl $1, %esi
    cmpq 8(%r8), %rsi
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%rsi), %r9d
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r10)
    movq %rdi, %r12
    cmpq $100, %r12
    jae .Lssa_int__int_to_string_114
.Lssa_int__int_to_string_7:
    cmpq $10, %r12
    jae .Lssa_int__int_to_string_6
.Lssa_int__int_to_string_122:
    movq %r8, %rax
    call __fn___fern_str_free.r
    jmp .Lssa_int__int_to_string_5
.Lssa_int__int_to_string_6:
    leaq -2(%r13), %rsi
    movslq %esi, %rsi
    movq %r12, %r9
    shlq $1, %r9
    movslq %r9d, %r9
    cmpq 8(%r8), %r9
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%r9), %r10d
    cmpq (%r14), %rsi
    jae __fern_oob_abort
    movb %r10b, 8(%r14,%rsi)
    leal 1(%rsi), %r15d
    addl $1, %r9d
    cmpq 8(%r8), %r9
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%r9), %ebx
    movq %r8, %rax
    call __fn___fern_str_free.r
    cmpq (%r14), %r15
    jae __fern_oob_abort
    movb %bl, 8(%r14,%r15)
    jmp .Lssa_int__int_to_string_4
.Lssa_int__int_to_string_5:
    subl $1, %r13d
    addq $48, %r12
    andq $255, %r12
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %r12b, 8(%r14,%r13)
.Lssa_int__int_to_string_4:
    movq -48(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_int__int_to_string_1
.Lssa_int__int_to_string_3:
    movl $45, %r9d
    cmpq $0, 0(%r14)
    jbe __fern_oob_abort
    movb %r9b, 8(%r14)
.Lssa_int__int_to_string_1:
    movq %r14, %rax
    call __fn___fern_string_from_bytes_u8.r
    movq %rax, %r12
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_int____int_to_string_u64:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_int____int_to_string_u64.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa_int____int_to_string_u64_0:
.Lssa_int____int_to_string_u64_16:
    movq %rbx, %rdi
    movl $1, %esi
.Lssa_int____int_to_string_u64_17:
    cmpq $100, %rdi
    jb .Lssa_int____int_to_string_u64_15
.Lssa_int____int_to_string_u64_18:
    leaq 2(%rsi), %r8
    movslq %r8d, %rsi
    movq %rdi, %rax
    movq %rax, %rcx
    movq %rcx, %rdx
    shrq $2, %rdx
    movabsq $2951479051793528259, %rax
    mulq %rdx
    shrq $2, %rdx
    movq %rdx, %rax
    movq %rax, %rdi
    cmpq $100, %rdi
    jae .Lssa_int____int_to_string_u64_18
.Lssa_int____int_to_string_u64_15:
    leaq 1(%rsi), %r8
    movslq %r8d, %r8
    cmpq $10, %rdi
    cmovbq %rsi, %r8
    leaq 1(%r8), %rsi
    movslq %esi, %rsi
    cmpq $0, -48(%rbp)
    movq %rsi, %r13
    cmoveq %r8, %r13
    movq %r13, %rdi
    call __fern_alloc_bytes
    movq %rax, %r14
    leaq .SB172(%rip), %rsi
.Lssa_int____int_to_string_u64_8:
.Lssa_int____int_to_string_u64_37:
    cmpq $100, %rbx
    jb .Lssa_int____int_to_string_u64_7
.Lssa_int____int_to_string_u64_38:
    movq %rbx, %rax
    movq %rax, %rcx
    movq %rcx, %rdx
    shrq $2, %rdx
    movabsq $2951479051793528259, %rax
    mulq %rdx
    shrq $2, %rdx
    movq %rdx, %rax
    movq %rax, %r8
    imulq $100, %r8, %rdi
    movq %rbx, %r11
    subq %rdi, %r11
    movq %r11, %rdi
    leaq -2(%r13), %r9
    movslq %r9d, %r13
    shlq $1, %rdi
    movslq %edi, %rdi
    cmpq 8(%rsi), %rdi
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%rdi), %r9d
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r13)
    leal 1(%r13), %r10d
    addl $1, %edi
    cmpq 8(%rsi), %rdi
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%rdi), %r9d
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r10)
    movq %r8, %rbx
    cmpq $100, %rbx
    jae .Lssa_int____int_to_string_u64_38
.Lssa_int____int_to_string_u64_7:
    cmpq $10, %rbx
    jae .Lssa_int____int_to_string_u64_6
.Lssa_int____int_to_string_u64_46:
    movq %rsi, %rax
    call __fn___fern_str_free.r
    jmp .Lssa_int____int_to_string_u64_5
.Lssa_int____int_to_string_u64_6:
    leaq -2(%r13), %rdi
    movslq %edi, %rdi
    movq %rbx, %r9
    shlq $1, %r9
    movslq %r9d, %r9
    cmpq 8(%rsi), %r9
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%r9), %r10d
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movb %r10b, 8(%r14,%rdi)
    leal 1(%rdi), %r15d
    addl $1, %r9d
    cmpq 8(%rsi), %r9
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%r9), %r12d
    movq %rsi, %rax
    call __fn___fern_str_free.r
    cmpq (%r14), %r15
    jae __fern_oob_abort
    movb %r12b, 8(%r14,%r15)
    jmp .Lssa_int____int_to_string_u64_4
.Lssa_int____int_to_string_u64_5:
    subl $1, %r13d
    addq $48, %rbx
    andq $255, %rbx
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %bl, 8(%r14,%r13)
.Lssa_int____int_to_string_u64_4:
    cmpq $0, -48(%rbp)
    je .Lssa_int____int_to_string_u64_1
.Lssa_int____int_to_string_u64_3:
    movl $45, %r9d
    cmpq $0, 0(%r14)
    jbe __fern_oob_abort
    movb %r9b, 8(%r14)
.Lssa_int____int_to_string_u64_1:
    movq %r14, %rax
    call __fn___fern_string_from_bytes_u8.r
    movq %rax, %rbx
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_utf8_scalar__expect:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_utf8_scalar__expect.r:
.Lssa_utf8_scalar__expect_0:
    cmpq $128, %rax
    jge .Lssa_utf8_scalar__expect_13
.Lssa_utf8_scalar__expect_15:
    movl $1, %eax
    ret
.Lssa_utf8_scalar__expect_13:
    cmpq $194, %rax
    jge .Lssa_utf8_scalar__expect_10
.Lssa_utf8_scalar__expect_12:
    xorl %eax, %eax
    ret
.Lssa_utf8_scalar__expect_10:
    cmpq $224, %rax
    jge .Lssa_utf8_scalar__expect_7
.Lssa_utf8_scalar__expect_9:
    movl $2, %eax
    ret
.Lssa_utf8_scalar__expect_7:
    cmpq $240, %rax
    jge .Lssa_utf8_scalar__expect_4
.Lssa_utf8_scalar__expect_6:
    movl $3, %eax
    ret
.Lssa_utf8_scalar__expect_4:
    movl $4, %esi
    xorl %edi, %edi
    cmpq $245, %rax
    movq %rsi, %rax
    cmovgeq %rdi, %rax
    ret
    .cfi_endproc
__fn_utf8_scalar__step:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_utf8_scalar__step.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa_utf8_scalar__step_0:
    cmpq 8(%rbx), %r12
    jae __fern_str_oob_abort.l5
    movq (%rbx), %rdx
    movzbl (%rdx,%r12), %r14d
    movq %r14, %rax
    call __fn_utf8_scalar__expect.r
    cmpq $1, %rax
    jg .Lssa_utf8_scalar__step_28
.Lssa_utf8_scalar__step_30:
    movl $1, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_28:
    leaq 1(%r12), %rsi
    movslq %esi, %rsi
    cmpq %r13, %rsi
    jl .Lssa_utf8_scalar__step_25
.Lssa_utf8_scalar__step_27:
    movl $1, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_25:
    leal 1(%r12), %esi
    cmpq 8(%rbx), %rsi
    jae __fern_str_oob_abort.l5
    movq (%rbx), %rdx
    movzbl (%rdx,%rsi), %edi
.Lssa_utf8_scalar__step_24:
    cmpq $224, %r14
    jne .Lssa_utf8_scalar__step_21
.Lssa_utf8_scalar__step_23:
    movl $160, %esi
    jmp .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_21:
    cmpq $240, %r14
    jne .Lssa_utf8_scalar__step_18
.Lssa_utf8_scalar__step_20:
    movl $144, %esi
    jmp .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_18:
    movl $128, %esi
.Lssa_utf8_scalar__step_17:
    cmpq %rsi, %rdi
    jl .Lssa_utf8_scalar__step_7
.Lssa_utf8_scalar__step_15:
    cmpq $237, %r14
    jne .Lssa_utf8_scalar__step_12
.Lssa_utf8_scalar__step_14:
    movl $159, %esi
    jmp .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_12:
    cmpq $244, %r14
    jne .Lssa_utf8_scalar__step_9
.Lssa_utf8_scalar__step_11:
    movl $143, %esi
    jmp .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_9:
    movl $191, %esi
.Lssa_utf8_scalar__step_8:
    cmpq %rsi, %rdi
    jle .Lssa_utf8_scalar__step_5
.Lssa_utf8_scalar__step_7:
    movl $1, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_5:
.Lssa_utf8_scalar__step_4:
    movl $2, %esi
.Lssa_utf8_scalar__step_67:
    cmpq %rax, %rsi
    jge .Lssa_utf8_scalar__step_3
.Lssa_utf8_scalar__step_76:
    leaq (%r12,%rsi), %rdi
    movslq %edi, %rdi
    cmpq %r13, %rdi
    jge .Lssa_utf8_scalar__step_2
.Lssa_utf8_scalar__step_74:
    leal (%r12,%rsi), %edi
    cmpq 8(%rbx), %rdi
    jae __fern_str_oob_abort.l5
    movq (%rbx), %rdx
    movzbl (%rdx,%rdi), %r8d
.Lssa_utf8_scalar__step_73:
    cmpq $128, %r8
    jl .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_72:
    cmpq $192, %r8
    jge .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_68:
    addq $1, %rsi
    cmpq %rax, %rsi
    jl .Lssa_utf8_scalar__step_76
.Lssa_utf8_scalar__step_3:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_2:
    movq %rsi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_1:
    movq %rsi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_deflate____ReadPhase__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_deflate____ReadPhase__eq.r:
.Lssa_deflate____ReadPhase__eq_0:
    movq 0(%rax), %rdi
    cmpq $.S173, %rdi
    jne .Lssa_deflate____ReadPhase__eq_20
.Lssa_deflate____ReadPhase__eq_24:
    movq 0(%rsi), %r8
    movl $1, %r9d
    xorl %r10d, %r10d
    cmpq $.S173, %r8
    movq %r9, %rax
    cmovneq %r10, %rax
    ret
.Lssa_deflate____ReadPhase__eq_20:
    cmpq $.S174, %rdi
    jne .Lssa_deflate____ReadPhase__eq_15
.Lssa_deflate____ReadPhase__eq_19:
    movq 0(%rsi), %r10
    movl $1, %r9d
    xorl %r8d, %r8d
    cmpq $.S174, %r10
    movq %r9, %rax
    cmovneq %r8, %rax
    ret
.Lssa_deflate____ReadPhase__eq_15:
    cmpq $.S175, %rdi
    jne .Lssa_deflate____ReadPhase__eq_10
.Lssa_deflate____ReadPhase__eq_14:
    movq 0(%rsi), %r8
    movl $1, %r9d
    xorl %r10d, %r10d
    cmpq $.S175, %r8
    movq %r9, %rax
    cmovneq %r10, %rax
    ret
.Lssa_deflate____ReadPhase__eq_10:
    cmpq $.S176, %rdi
    jne .Lssa_deflate____ReadPhase__eq_4
.Lssa_deflate____ReadPhase__eq_9:
    movq 0(%rsi), %r10
    movl $1, %r9d
    xorl %edi, %edi
    cmpq $.S176, %r10
    movq %r9, %rax
    cmovneq %rdi, %rax
    ret
.Lssa_deflate____ReadPhase__eq_4:
    movq 0(%rsi), %rdi
    movl $1, %esi
    xorl %r9d, %r9d
    cmpq $.S177, %rdi
    movq %rsi, %rax
    cmovneq %r9, %rax
    ret
    .cfi_endproc
__fn_codec__DecodeErrorKind__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_codec__DecodeErrorKind__eq.r:
.Lssa_codec__DecodeErrorKind__eq_0:
    movq 0(%rax), %rdi
    cmpq $.S178, %rdi
    jne .Lssa_codec__DecodeErrorKind__eq_15
.Lssa_codec__DecodeErrorKind__eq_19:
    movq 8(%rax), %r8
    movq 0(%rsi), %r9
    cmpq $.S178, %r9
    jne .Lssa_codec__DecodeErrorKind__eq_16
.Lssa_codec__DecodeErrorKind__eq_18:
    movq 8(%rsi), %r9
    movq %r8, %rax
    cmpq %r9, %rax
    sete %al
    movzbq %al, %rax
    ret
.Lssa_codec__DecodeErrorKind__eq_16:
    xorl %eax, %eax
    ret
.Lssa_codec__DecodeErrorKind__eq_15:
    cmpq $.S179, %rdi
    jne .Lssa_codec__DecodeErrorKind__eq_10
.Lssa_codec__DecodeErrorKind__eq_14:
    movq 0(%rsi), %r9
    movl $1, %r8d
    xorl %r10d, %r10d
    cmpq $.S179, %r9
    movq %r8, %rax
    cmovneq %r10, %rax
    ret
.Lssa_codec__DecodeErrorKind__eq_10:
    cmpq $.S180, %rdi
    jne .Lssa_codec__DecodeErrorKind__eq_4
.Lssa_codec__DecodeErrorKind__eq_9:
    movq 0(%rsi), %r10
    movl $1, %r8d
    xorl %edi, %edi
    cmpq $.S180, %r10
    movq %r8, %rax
    cmovneq %rdi, %rax
    ret
.Lssa_codec__DecodeErrorKind__eq_4:
    movq 0(%rsi), %rdi
    movl $1, %esi
    xorl %r8d, %r8d
    cmpq $.S181, %rdi
    movq %rsi, %rax
    cmovneq %r8, %rax
    ret
    .cfi_endproc
__fn_codec__DecodeError__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_codec__DecodeError__eq.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_codec__DecodeError__eq_0:
    movq 8(%rbx), %rsi
    movq 8(%r12), %rdi
    movq 8(%rsi), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_codec__DecodeError__eq_streqn17
    movq %rdi, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_codec__DecodeError__eq_streqd17
.Lssa_codec__DecodeError__eq_streqn17:
    xorl %eax, %eax
.Lssa_codec__DecodeError__eq_streqd17:
    testq %rax, %rax
    jz .Lssa_codec__DecodeError__eq_2
.Lssa_codec__DecodeError__eq_6:
    movq 16(%rbx), %rdi
    movq 16(%r12), %rsi
    cmpq %rsi, %rdi
    jne .Lssa_codec__DecodeError__eq_2
.Lssa_codec__DecodeError__eq_3:
    movq 24(%rbx), %rax
    movq 24(%r12), %rsi
    call __fn_codec__DecodeErrorKind__eq.r
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_2:
    xorl %eax, %eax
.Lssa_codec__DecodeError__eq_1:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_main:
    .cfi_startproc
__fn_main.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $152, %rsp
.Lssa_main_0:
    leaq .SB182(%rip), %r11
    movq %r11, -48(%rbp)
.Lssa_main_38:
    xorps %xmm2, %xmm2
    movups %xmm2, -64(%rbp)
.Lssa_main_39:
    cmpq $4000, -64(%rbp)
    jge .Lssa_main_37
.Lssa_main_348:
    pushq -48(%rbp)
    call __fn___fern_str_bytes_u8
    addq $8, %rsp
    movq %rax, %r14
.Lssa_main_346:
    movl $100, %r11d
    movq %r11, -72(%rbp)
    leaq .SB8(%rip), %r11
    movq %r11, -80(%rbp)
    leaq .SB8(%rip), %r11
    movq %r11, -88(%rbp)
    leaq .K1(%rip), %r11
    movq %r11, -96(%rbp)
.Lssa_main_344:
    movq 0(%r14), %rsi
    cmpq $1, %rsi
    jle .Lssa_main_340
.Lssa_main_343:
    movzbl 8(%r14), %esi
    cmpq $13, %rsi
    jne .Lssa_main_340
.Lssa_main_342:
    movzbl 9(%r14), %esi
    cmpq $10, %rsi
    jne .Lssa_main_340
.Lssa_main_341:
    movq $2, -104(%rbp)
    jmp .Lssa_main_339
.Lssa_main_340:
    movq $0, -104(%rbp)
.Lssa_main_339:
    movq 0(%r14), %r11
    movq %r11, -112(%rbp)
    movq -104(%rbp), %r11
    cmpq -112(%rbp), %r11
    jl .Lssa_main_336
.Lssa_main_367:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_1
.Lssa_main_336:
    movq -104(%rbp), %rsi
    addq $8192, %rsi
    addq $2, %rsi
    movslq %esi, %r11
    movq %r11, -120(%rbp)
    movq -104(%rbp), %rsi
    addq $32768, %rsi
    addq $4, %rsi
    movslq %esi, %r11
    movq %r11, -128(%rbp)
    cmpq -112(%rbp), %r11
    cmovgeq -112(%rbp), %r11
    movq %r11, -136(%rbp)
    leaq .K11(%rip), %rsi
    movq %rsi, %rdx
    movq -104(%rbp), %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L107
    xorq %rcx, %rcx
.L107:
    leaq .S183(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L110
    vpbroadcastb 352(%r11), %ymm2
    vpbroadcastb 353(%r11), %ymm3
.L108:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L114
    vmovdqu (%r9), %ymm0
    vpcmpeqb %ymm2, %ymm0, %ymm1
    vpcmpeqb %ymm3, %ymm0, %ymm8
    vpor %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L109
    addq $32, %r9
    jmp .L108
.L114:
    cmpq %r10, %r9
    jg .L115
    vmovdqu (%r9), %xmm0
    vpcmpeqb %xmm2, %xmm0, %xmm1
    vpcmpeqb %xmm3, %xmm0, %xmm8
    vpor %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L109
    addq $16, %r9
.L115:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L110
.L109:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L113
.L110:
    cmpq %r8, %rcx
    jge .L112
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L111
    addq $1, %rcx
    jmp .L110
.L111:
    pushq %rcx
    jmp .L113
.L112:
    pushq %r8
.L113:
    popq %rax
    movq %rax, %r12
    movq %r14, %rax
    movq %r12, %rsi
    movq -136(%rbp), %rdi
    call __fn_http____line_break.r
.Lssa_main_332:
    movq -104(%rbp), %rdi
    movq -104(%rbp), %r9
    movq %r12, %r10
    movq $-1, %rsi
    xorl %r8d, %r8d
    movq $0, -144(%rbp)
.Lssa_main_376:
    cmpq $2, %rax
    jne .Lssa_main_386
.Lssa_main_388:
    movq %rsi, %r13
    movq $-1, %r12
    jmp .Lssa_main_330
.Lssa_main_386:
    cmpq $1, %rax
    jne .Lssa_main_384
.Lssa_main_385:
    leaq 1(%r10), %rcx
    movslq %ecx, %rax
    movq %rsi, -152(%rbp)
    movq %rax, %rbx
    movq %rax, %r12
    movq $1, -144(%rbp)
    xorl %r15d, %r15d
    jmp .Lssa_main_377
.Lssa_main_384:
    cmpq $-1, %rsi
    jne .Lssa_main_381
.Lssa_main_383:
    leaq 1(%r10), %rcx
    movslq %ecx, %rax
    movq $-2, %r13
    cmpq -120(%rbp), %rax
    cmovlq %r10, %r13
    movq %r13, %rsi
.Lssa_main_382:
.Lssa_main_381:
    cmpq %rdi, %r10
    jne .Lssa_main_378
.Lssa_main_380:
    testq %r8, %r8
    jnz .Lssa_main_331
.Lssa_main_378:
    leaq 2(%r10), %r8
    movslq %r8d, %r8
    movq %rsi, -152(%rbp)
    movq %r8, %rbx
    movq %r8, %r12
    movl $1, %r15d
.Lssa_main_377:
    leaq .K11(%rip), %r8
    movq %r8, %rdx
    movq %r12, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L116
    xorq %rcx, %rcx
.L116:
    leaq .S183(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L119
    vpbroadcastb 352(%r11), %ymm2
    vpbroadcastb 353(%r11), %ymm3
.L117:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L123
    vmovdqu (%r9), %ymm0
    vpcmpeqb %ymm2, %ymm0, %ymm1
    vpcmpeqb %ymm3, %ymm0, %ymm8
    vpor %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L118
    addq $32, %r9
    jmp .L117
.L123:
    cmpq %r10, %r9
    jg .L124
    vmovdqu (%r9), %xmm0
    vpcmpeqb %xmm2, %xmm0, %xmm1
    vpcmpeqb %xmm3, %xmm0, %xmm8
    vpor %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L118
    addq $16, %r9
.L124:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L119
.L118:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L122
.L119:
    cmpq %r8, %rcx
    jge .L121
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L120
    addq $1, %rcx
    jmp .L119
.L120:
    pushq %rcx
    jmp .L122
.L121:
    pushq %r8
.L122:
    popq %rax
    movq %rax, %r13
    movq %r14, %rax
    movq %r13, %rsi
    movq -136(%rbp), %rdi
    call __fn_http____line_break.r
    movq -152(%rbp), %rsi
    movq %rbx, %rdi
    movq %r15, %r8
    movq %r12, %r9
    movq %r13, %r10
    cmpq $2, %rax
    je .Lssa_main_388
    jmp .Lssa_main_386
.Lssa_main_331:
    leaq -2(%r10), %r8
    movslq %r8d, %r8
    addq $1, %r10
    movslq %r10d, %r10
    movq $-2, %rdi
    cmpq -128(%rbp), %r10
    cmovlq %r8, %rdi
    movq %rsi, %r13
    movq %rdi, %r12
.Lssa_main_330:
    cmpq $-1, %r13
    jne .Lssa_main_313
.Lssa_main_328:
    movq 0(%r14), %r15
    movq -120(%rbp), %r11
    cmpq -136(%rbp), %r11
    jle .Lssa_main_317
.Lssa_main_327:
    cmpq %r15, -136(%rbp)
    jge .Lssa_main_317
.Lssa_main_326:
    cmpq %r15, -120(%rbp)
    movq -120(%rbp), %rdi
    cmovgeq %r15, %rdi
    movq %r14, %rax
    movq %r9, %rsi
    call __fn_http____find_crlf.r
    cmpq $0, %rax
    jl .Lssa_main_317
    jmp .Lssa_main_321
.Lssa_main_324:
    jmp .Lssa_main_313
.Lssa_main_321:
    movq %rax, %r13
    jmp .Lssa_main_313
.Lssa_main_317:
    cmpq -120(%rbp), %r15
    jl .Lssa_main_314
.Lssa_main_316:
    movq $-2, %r13
    jmp .Lssa_main_313
.Lssa_main_314:
    movq $-1, %r13
.Lssa_main_313:
    cmpq $-1, %r12
    jne .Lssa_main_307
.Lssa_main_312:
    movq -112(%rbp), %r11
    cmpq -128(%rbp), %r11
    jl .Lssa_main_307
.Lssa_main_311:
    movq $-2, %r12
.Lssa_main_310:
.Lssa_main_309:
.Lssa_main_307:
    cmpq $-2, %r13
    jne .Lssa_main_304
.Lssa_main_306:
    movl $414, %edi
    jmp .Lssa_main_297
.Lssa_main_304:
    cmpq $-2, %r12
    jne .Lssa_main_301
.Lssa_main_303:
    movl $431, %edi
    jmp .Lssa_main_297
.Lssa_main_301:
    movq -144(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_298
.Lssa_main_300:
    movl $400, %edi
    jmp .Lssa_main_297
.Lssa_main_298:
    xorl %edi, %edi
.Lssa_main_297:
    cmpq $0, %rdi
    je .Lssa_main_295
.Lssa_main_482:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_1
.Lssa_main_295:
    leaq .SB8(%rip), %r15
    cmpq $0, %r13
    jl .Lssa_main_289
.Lssa_main_293:
    leaq .K2(%rip), %rdi
    movq %rdi, %rdx
    movq -104(%rbp), %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L125
    xorq %rcx, %rcx
.L125:
    leaq .S1(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L128
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L126:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L132
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L127
    addq $32, %r9
    jmp .L126
.L132:
    cmpq %r10, %r9
    jg .L133
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L127
    addq $16, %r9
.L133:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L128
.L127:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L131
.L128:
    cmpq %r8, %rcx
    jge .L130
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L129
    addq $1, %rcx
    jmp .L128
.L129:
    pushq %rcx
    jmp .L131
.L130:
    pushq %r8
.L131:
    popq %rax
    cmpq %r13, %rax
    movq %r13, %rbx
    cmovleq %rax, %rbx
    cmpq -104(%rbp), %rbx
    je .Lssa_main_290
.Lssa_main_292:
    cmpq %r13, %rbx
    jge .Lssa_main_290
.Lssa_main_291:
    cmpq (%r14), %rbx
    jae __fern_oob_abort
    movzbl 8(%r14,%rbx), %edi
    cmpq $32, %rdi
    je .Lssa_main_287
.Lssa_main_290:
    leaq .SB8(%rip), %rdi
    movq %rdi, %r9
    movl $400, %eax
    movq $-1, %rbx
    movq $-1, %r15
    jmp .Lssa_main_238
.Lssa_main_289:
    movq %r15, -112(%rbp)
    movq $-1, -88(%rbp)
    movq $-1, %r15
    jmp .Lssa_main_236
.Lssa_main_287:
    leaq 1(%rbx), %rdi
.Lssa_main_286:
    movl $32, %r9d
    movq %rdi, %rdx
    movq %r9, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L134
    xorq %rdx, %rdx
.L134:
    cmpq $255, %rcx
    ja .L138
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L142
.L140:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L141
    addq $32, %r9
    cmpq %r10, %r9
    jle .L140
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L142
.L141:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L139
.L142:
    vzeroupper
.L135:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L137
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L136
    addq $16, %rdx
    jmp .L135
.L136:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L139
.L137:
    cmpq %r8, %rdx
    jge .L138
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L143
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L138
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L138
    addq %r9, %rdx
    jmp .L139
.L143:
    cmpq %r8, %rdx
    jge .L138
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L139
    addq $1, %rdx
    jmp .L143
.L138:
    movq $-1, %rdx
.L139:
    movq %rdx, %rax
    movq $-1, %r9
    cmpq %r13, %rax
    movq %rax, %r15
    cmovgeq %r9, %r15
    cmpq $0, %r15
    jl .Lssa_main_280
.Lssa_main_281:
    leaq 1(%rbx), %r9
    cmpq %r9, %r15
    jne .Lssa_main_278
.Lssa_main_280:
    leaq .SB8(%rip), %r9
    movl $400, %eax
    movq $-1, %rbx
    movq $-1, %r15
    jmp .Lssa_main_238
.Lssa_main_278:
    leaq 1(%r15), %r9
    movslq %r9d, %r9
.Lssa_main_277:
    movq %r13, %rdi
    subq %r9, %rdi
    movslq %edi, %rdi
    cmpq $8, %rdi
    jne .Lssa_main_275
.Lssa_main_276:
    leaq .K12(%rip), %rdi
    xorl %r8d, %r8d
    movl $5, %esi
    movq %r9, -160(%rbp)
    movq %r14, %rax
    xchgq %r9, %rsi
    call __fn___sem_byte_view_mismatch.r
    movq -160(%rbp), %r9
    cmpq $5, %rax
    je .Lssa_main_273
.Lssa_main_275:
    movl $400, %r8d
    jmp .Lssa_main_264
.Lssa_main_273:
    leal 5(%r9), %esi
    cmpq (%r14), %rsi
    jae __fern_oob_abort
    movzbl 8(%r14,%rsi), %eax
    movq %r9, -160(%rbp)
    call __fn_http____is_digit.r
    movq -160(%rbp), %r9
    testq %rax, %rax
    jz .Lssa_main_267
.Lssa_main_272:
    leal 6(%r9), %esi
    cmpq (%r14), %rsi
    jae __fern_oob_abort
    movzbl 8(%r14,%rsi), %r8d
    cmpq $46, %r8
    jne .Lssa_main_267
.Lssa_main_271:
    leal 7(%r9), %r8d
    cmpq (%r14), %r8
    jae __fern_oob_abort
    movzbl 8(%r14,%r8), %eax
    movq %r9, -160(%rbp)
    call __fn_http____is_digit.r
    movq -160(%rbp), %r9
    testq %rax, %rax
    jz .Lssa_main_267
.Lssa_main_269:
    addl $5, %r9d
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %r8d
    cmpq $49, %r8
    je .Lssa_main_265
.Lssa_main_268:
    movl $505, %r8d
    jmp .Lssa_main_264
.Lssa_main_267:
    movl $400, %r8d
    jmp .Lssa_main_264
.Lssa_main_265:
    xorl %r8d, %r8d
.Lssa_main_264:
    cmpq $0, %r8
    je .Lssa_main_261
.Lssa_main_263:
    leaq .SB8(%rip), %r9
    movq %r8, %rax
    movq $-1, %rbx
    movq $-1, %r15
    jmp .Lssa_main_238
.Lssa_main_261:
    leaq 1(%rbx), %r9
    movq %rbx, %r8
    subq -104(%rbp), %r8
    movslq %r8d, %r8
    cmpq $7, %r8
    jne .Lssa_main_259
.Lssa_main_260:
    leaq .SB184(%rip), %r8
    movq 8(%r8), %rsi
    xorl %edi, %edi
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %rdi, %rcx
    movq %r8, %rdx
    movq %r14, %rax
    movq %rsi, %r8
    movq -104(%rbp), %rsi
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L144_aop
    xorq %rsi, %rsi
.L144_aop:
    cmpq %r9, %rsi
    jle .L144_aok
    movq %r9, %rsi
.L144_aok:
    cmpq $0, %rcx
    jge .L144_bop
    xorq %rcx, %rcx
.L144_bop:
    cmpq %r10, %rcx
    jle .L144_bok
    movq %r10, %rcx
.L144_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L144_na
    movq %r9, %r8
.L144_na:
    cmpq %r10, %r8
    jle .L144_nb
    movq %r10, %r8
.L144_nb:
    cmpq $0, %r8
    jge .L144_nok
    xorq %r8, %r8
.L144_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L144_vec
    cmpq $8, %r8
    jge .L144_w8
    cmpq $4, %r8
    jge .L144_w4
    cmpq $2, %r8
    jge .L144_w2
    jmp .L144_tail
.L144_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L144_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L144_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L144_done
.L144_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L144_done
.L144_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L144_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L144_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L144_done
.L144_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L144_done
.L144_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L144_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L144_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L144_done
.L144_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L144_done
.L144_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L144_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L144_hit
    addq $16, %rdx
    jmp .L144_vec
.L144_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L144_done
.L144_tail:
    cmpq %r8, %rdx
    jge .L144_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L144_th
    addq $1, %rdx
    jmp .L144_tail
.L144_th:
    movq %rdx, %rax
    jmp .L144_done
.L144_eq:
    movq %r8, %rax
.L144_done:
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq 8(%r8), %rdi
    movq %rax, %r8
    cmpq %rdi, %r8
    sete %r8b
    movzbq %r8b, %r8
.Lssa_main_563:
    jmp .Lssa_main_257
.Lssa_main_259:
    xorl %r8d, %r8d
.Lssa_main_258:
.Lssa_main_257:
    movq %r14, %rax
    movq %r9, %rsi
    movq %r15, %rdi
    call __fn_http____target_start.r
    movq %rax, %r10
.Lssa_main_566:
    cmpq $-2, %r10
    jne .Lssa_main_254
.Lssa_main_256:
    movl $400, %eax
    jmp .Lssa_main_239
.Lssa_main_254:
.Lssa_main_573:
    cmpq $-1, %r10
    jne .Lssa_main_251
.Lssa_main_253:
    leaq .SB185(%rip), %r8
    movq %r8, %rax
    jmp .Lssa_main_242
.Lssa_main_251:
    movq %r10, -160(%rbp)
    movq %r14, %rax
    movq %r10, %rsi
    movq %r15, %rdi
    call __fn_http____path_end.r
    movq %rax, %r8
    movq -160(%rbp), %r10
    cmpq $0, %r8
    jge .Lssa_main_248
.Lssa_main_250:
    movl $400, %eax
    jmp .Lssa_main_239
.Lssa_main_248:
    cmpq %r8, %r10
    jge .Lssa_main_244
.Lssa_main_247:
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq %r14, %rax
    movq %r10, %rsi
    movq %r8, %rdi
    call __fn_http____plain_path.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    testq %rax, %rax
    jz .Lssa_main_244
.Lssa_main_246:
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq %r14, %rax
    movq %r10, %rsi
    movq %r15, %rdi
    movq -88(%rbp), %r8
    call __fn_http____shared_string.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    jmp .Lssa_main_242
.Lssa_main_244:
    movq %r14, %rax
    movq %r10, %rsi
    movq %r8, %rdi
    movq %r15, %r8
    call __fn_http____decoded_path.r
    movq %rax, %r9
    movq %r9, -160(%rbp)
    movq %rdx, %rax
    movq -160(%rbp), %r9
    cmpq $0, %r9
    jne .Lssa_main_239
.Lssa_main_243:
.Lssa_main_242:
    movq %rax, %r9
    xorl %eax, %eax
    jmp .Lssa_main_238
.Lssa_main_241:
.Lssa_main_240:
.Lssa_main_239:
    leaq .SB8(%rip), %r9
    movq $-1, %rbx
    movq $-1, %r15
.Lssa_main_238:
    cmpq $0, %rax
    je .Lssa_main_237
.Lssa_main_599:
    movq %r9, -160(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -160(%rbp), %r9
    movq %r9, -160(%rbp)
    movq %r9, %rax
    call __fn___fern_str_free.r
    movq -160(%rbp), %r9
    jmp .Lssa_main_1
.Lssa_main_237:
    movq %rbx, -88(%rbp)
    movq %r9, -112(%rbp)
.Lssa_main_236:
    cmpq $0, %r13
    jge .Lssa_main_235
.Lssa_main_603:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_main_1
.Lssa_main_235:
    cmpq $0, %r12
    jge .Lssa_main_233
.Lssa_main_607:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_main_1
.Lssa_main_233:
    leaq 4(%r12), %r9
    movq %r9, %r11
    subq -104(%rbp), %r11
    movq %r11, -120(%rbp)
    addq $2, %r13
    movslq %r13d, %r13
    cmpq %r12, %r13
    movq %r12, %rsi
    cmovleq %r13, %rsi
    movq %r14, %rax
    movq %r12, %rdi
    movq -72(%rbp), %r8
    movq -96(%rbp), %r9
    call __fn_http____parse_header_bytes.r
    movq %rax, %r13
    movq %rdx, -96(%rbp)
    cmpq $0, %r13
    je .Lssa_main_227
.Lssa_main_617:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_main_1
.Lssa_main_227:
    addq $1, %r15
.Lssa_main_226:
    addl $7, %r15d
    cmpq (%r14), %r15
    jae __fern_oob_abort
    movzbl 8(%r14,%r15), %esi
    cmpq $48, %rsi
    jne .Lssa_main_223
.Lssa_main_225:
    leaq .SB186(%rip), %rsi
    movq %rsi, -128(%rbp)
    jmp .Lssa_main_221
.Lssa_main_223:
    leaq .SB187(%rip), %rsi
    movq %rsi, -128(%rbp)
.Lssa_main_222:
.Lssa_main_221:
.Lssa_main_220:
    movq $-1, -136(%rbp)
    movq $-1, %r15
    movq $-1, %r13
    movq $-1, %r9
    movq $-1, -144(%rbp)
    xorl %r8d, %r8d
.Lssa_main_625:
    movq -96(%rbp), %r11
    movq 8(%r11), %rsi
    movq 0(%rsi), %r10
    cmpq %r10, %r8
    jge .Lssa_main_217
.Lssa_main_660:
    movq -96(%rbp), %r11
    movq 8(%r11), %r10
    movq 8(%r10,%r8,8), %rbx
.Lssa_main_659:
    movq 8(%rbx), %r10
    cmpq $4, %r10
    jne .Lssa_main_656
.Lssa_main_658:
    leaq .SB188(%rip), %rsi
    movl $3, %edi
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %r10, -176(%rbp)
    movq %rbx, %rax
    call __fn_http____kind_if.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq -176(%rbp), %r10
    jmp .Lssa_main_643
.Lssa_main_656:
    cmpq $6, %r10
    jne .Lssa_main_653
.Lssa_main_655:
    leaq .SB189(%rip), %rsi
    movl $4, %edi
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %r10, -176(%rbp)
    movq %rbx, %rax
    call __fn_http____kind_if.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq -176(%rbp), %r10
    jmp .Lssa_main_643
.Lssa_main_653:
    cmpq $10, %r10
    jne .Lssa_main_650
.Lssa_main_652:
    leaq .SB65(%rip), %rsi
    movl $5, %edi
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %r10, -176(%rbp)
    movq %rbx, %rax
    call __fn_http____kind_if.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq -176(%rbp), %r10
    jmp .Lssa_main_643
.Lssa_main_650:
    cmpq $14, %r10
    jne .Lssa_main_647
.Lssa_main_649:
    leaq .SB64(%rip), %rsi
    movl $1, %edi
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %r10, -176(%rbp)
    movq %rbx, %rax
    call __fn_http____kind_if.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq -176(%rbp), %r10
    jmp .Lssa_main_643
.Lssa_main_647:
    cmpq $17, %r10
    jne .Lssa_main_644
.Lssa_main_646:
    leaq .SB66(%rip), %rsi
    movl $2, %edi
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %rbx, %rax
    call __fn_http____kind_if.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    jmp .Lssa_main_643
.Lssa_main_644:
    xorl %eax, %eax
.Lssa_main_643:
    cmpq $1, %rax
    jne .Lssa_main_640
.Lssa_main_642:
    movq $-2, %rdi
    cmpq $-1, -136(%rbp)
    cmoveq %r8, %rdi
    movq %rdi, -136(%rbp)
.Lssa_main_641:
.Lssa_main_640:
    cmpq $2, %rax
    jne .Lssa_main_637
.Lssa_main_639:
    movq $-2, %rdi
    cmpq $-1, %r15
    cmoveq %r8, %rdi
    movq %rdi, %r15
.Lssa_main_638:
.Lssa_main_637:
    cmpq $3, %rax
    jne .Lssa_main_634
.Lssa_main_636:
    movq $-2, %rdi
    cmpq $-1, %r13
    cmoveq %r8, %rdi
    movq %rdi, %r13
.Lssa_main_635:
.Lssa_main_634:
    cmpq $4, %rax
    jne .Lssa_main_630
.Lssa_main_633:
    cmpq $0, %r9
    jge .Lssa_main_630
.Lssa_main_632:
    movq %r8, %r9
.Lssa_main_631:
.Lssa_main_630:
    cmpq $5, %rax
    jne .Lssa_main_626
.Lssa_main_629:
    cmpq $0, -144(%rbp)
    jge .Lssa_main_626
.Lssa_main_628:
    movq %r8, -144(%rbp)
.Lssa_main_627:
.Lssa_main_626:
    addq $1, %r8
    jmp .Lssa_main_625
.Lssa_main_217:
    cmpq $0, %r9
    jge .Lssa_main_214
.Lssa_main_216:
    xorl %ebx, %ebx
    jmp .Lssa_main_209
.Lssa_main_214:
    movq %r9, %rbx
.Lssa_main_760:
    cmpq $0, %rbx
    jl .Lssa_main_213
.Lssa_main_763:
    movq -96(%rbp), %r11
    movq 16(%r11), %r8
    cmpq (%r8), %rbx
    jae __fern_oob_abort
    movq 8(%r8,%rbx,8), %rax
    leaq .SB190(%rip), %rsi
    call __fn_http____token_is.r
    testq %rax, %rax
    jz .Lssa_main_212
.Lssa_main_761:
    leaq .SB189(%rip), %rsi
    addq $1, %rbx
    movslq %ebx, %rdi
    movq -96(%rbp), %rax
    call __fn_http____field_at.r
    movq %rax, %rbx
    cmpq $0, %rbx
    jge .Lssa_main_763
.Lssa_main_213:
    movl $1, %ebx
    jmp .Lssa_main_209
.Lssa_main_212:
    movl $417, %ebx
.Lssa_main_211:
.Lssa_main_209:
    cmpq $-1, %r13
    jne .Lssa_main_206
.Lssa_main_208:
    leaq .SB187(%rip), %rdi
    movq -128(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_main_780
.Lssa_main_779:
    movq -128(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_main_streqn2824
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn2824
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd2824
.Lssa_main_streqn2824:
    xorl %eax, %eax
.Lssa_main_streqd2824:
    jmp .Lssa_main_781
.Lssa_main_780:
    xorl %eax, %eax
.Lssa_main_781:
    testq %rax, %rax
    jnz .Lssa_main_195
    jmp .Lssa_main_197
.Lssa_main_206:
    cmpq $-2, %r13
    je .Lssa_main_195
.Lssa_main_203:
    movq -96(%rbp), %r11
    movq 16(%r11), %rdi
    cmpq (%rdi), %r13
    jae __fern_oob_abort
    movq 8(%rdi,%r13,8), %rsi
.Lssa_main_202:
    movq 8(%rsi), %rdi
    movq 0(%rsi), %r8
    xorl %esi, %esi
.Lssa_main_788:
    cmpq %rdi, %rsi
    jge .Lssa_main_197
.Lssa_main_792:
    movzbl (%r8,%rsi), %r9d
    cmpq $33, %r9
    jl .Lssa_main_195
.Lssa_main_791:
    cmpq $126, %r9
    jg .Lssa_main_195
.Lssa_main_789:
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_main_792
.Lssa_main_197:
    cmpq $417, %rbx
    jne .Lssa_main_193
.Lssa_main_196:
    movl $417, %esi
    jmp .Lssa_main_192
.Lssa_main_195:
    movl $400, %esi
    jmp .Lssa_main_192
.Lssa_main_193:
    xorl %esi, %esi
.Lssa_main_192:
    cmpq $0, %rsi
    jle .Lssa_main_189
.Lssa_main_818:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_189:
    cmpq $-1, %r15
    jne .Lssa_main_184
.Lssa_main_187:
    cmpq $-1, -136(%rbp)
    jne .Lssa_main_174
.Lssa_main_186:
    movq $1, -136(%rbp)
    movq $0, -152(%rbp)
    jmp .Lssa_main_166
.Lssa_main_184:
    cmpq $-1, -136(%rbp)
    je .Lssa_main_183
.Lssa_main_831:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_183:
    cmpq $-2, %r15
    jne .Lssa_main_181
.Lssa_main_835:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_181:
    movq -96(%rbp), %r11
    movq 16(%r11), %rsi
    cmpq (%rsi), %r15
    jae __fern_oob_abort
    movq 8(%rsi,%r15,8), %r8
    leaq .SB191(%rip), %rsi
    movq %r8, %rdi
    pushq %rsi
    pushq %rdi
    call __fn___fern_str_split
    addq $16, %rsp
    movq %rax, %r15
    movq 0(%r15), %rsi
    subl $1, %esi
    cmpq (%r15), %rsi
    jae __fern_oob_abort
    movq 8(%r15,%rsi,8), %rax
    leaq .SB192(%rip), %rsi
    call __fn_http____token_is.r
    testq %rax, %rax
    jnz .Lssa_main_179
.Lssa_main_840:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    testb $1, %r15b
    jnz .Lssa_main_uq840
    cmpq $0x10000, %r15
    jb .Lssa_main_uq840
    cmpl $1, -8(%r15)
.Lssa_main_uq840:
    jne .Lssa_main_844
.Lssa_main_842:
    xorl %ebx, %ebx
.Lssa_main_846:
    movq 0(%r15), %rsi
    cmpq %rsi, %rbx
    jge .Lssa_main_844
.Lssa_main_847:
    movq 8(%r15,%rbx,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %rbx
    jmp .Lssa_main_846
.Lssa_main_844:
    movq %r15, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_179:
.Lssa_main_178:
    xorl %ebx, %ebx
.Lssa_main_851:
    leaq 1(%rbx), %rsi
    movslq %esi, %rsi
    movq 0(%r15), %r11
    movq %r11, -152(%rbp)
    cmpq %r11, %rsi
    jge .Lssa_main_177
.Lssa_main_854:
    cmpq (%r15), %rbx
    jae __fern_oob_abort
    movq 8(%r15,%rbx,8), %rax
    leaq .SB192(%rip), %rsi
    call __fn_http____token_is.r
    testq %rax, %rax
    jz .Lssa_main_852
.Lssa_main_859:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    testb $1, %r15b
    jnz .Lssa_main_uq859
    cmpq $0x10000, %r15
    jb .Lssa_main_uq859
    cmpl $1, -8(%r15)
.Lssa_main_uq859:
    jne .Lssa_main_864
.Lssa_main_862:
    xorl %r13d, %r13d
.Lssa_main_866:
    movq 0(%r15), %rsi
    cmpq %rsi, %r13
    jge .Lssa_main_864
.Lssa_main_867:
    movq 8(%r15,%r13,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r13
    jmp .Lssa_main_866
.Lssa_main_864:
    movq %r15, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_852:
    addq $1, %rbx
    movslq %ebx, %rbx
    jmp .Lssa_main_851
.Lssa_main_177:
    testb $1, %r15b
    jnz .Lssa_main_uq177
    cmpq $0x10000, %r15
    jb .Lssa_main_uq177
    cmpl $1, -8(%r15)
.Lssa_main_uq177:
    jne .Lssa_main_875
.Lssa_main_873:
    xorl %ebx, %ebx
.Lssa_main_877:
    movq 0(%r15), %rsi
    cmpq %rsi, %rbx
    jge .Lssa_main_875
.Lssa_main_878:
    movq 8(%r15,%rbx,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %rbx
    jmp .Lssa_main_877
.Lssa_main_875:
    movq %r15, %rax
    call __fn___fern_arr_dec.r
    cmpq $1, -152(%rbp)
    jle .Lssa_main_176
.Lssa_main_881:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_176:
    movq $0, -136(%rbp)
    movq $0, -152(%rbp)
    jmp .Lssa_main_166
.Lssa_main_174:
    cmpq $-2, -136(%rbp)
    jne .Lssa_main_172
.Lssa_main_886:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_172:
    movq -96(%rbp), %r11
    movq 16(%r11), %rsi
    movq -136(%rbp), %rcx
    cmpq (%rsi), %rcx
    jae __fern_oob_abort
    movq 8(%rsi,%rcx,8), %rbx
    movq 8(%rbx), %rsi
    cmpq $0, %rsi
    jne .Lssa_main_170
.Lssa_main_890:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_170:
.Lssa_main_169:
    movq 8(%rbx), %r15
    movq 0(%rbx), %r13
    xorl %ebx, %ebx
    xorl %r8d, %r8d
.Lssa_main_894:
    cmpq %r15, %r8
    jge .Lssa_main_168
.Lssa_main_902:
    movzbl (%r13,%r8), %r9d
    cmpq $48, %r9
    jge .Lssa_main_901
.Lssa_main_907:
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    jmp .Lssa_main_1
.Lssa_main_901:
    cmpq $57, %r9
    jle .Lssa_main_899
.Lssa_main_911:
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
    jmp .Lssa_main_1
.Lssa_main_899:
    subq $48, %r9
    movslq %r9d, %r10
    cmpq $214748364, %rbx
    jle .Lssa_main_898
.Lssa_main_915:
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_898:
    cmpq $214748364, %rbx
    jne .Lssa_main_895
.Lssa_main_897:
    cmpq $7, %r10
    jle .Lssa_main_895
.Lssa_main_923:
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_895:
    imulq $10, %rbx, %r9
    addq %r10, %r9
    movslq %r9d, %rbx
    addq $1, %r8
    cmpq %r15, %r8
    jl .Lssa_main_902
.Lssa_main_168:
    movq %rbx, -152(%rbp)
    movq $1, -136(%rbp)
.Lssa_main_167:
.Lssa_main_166:
    movq %r14, %rax
    movq -104(%rbp), %rsi
    movq -88(%rbp), %rdi
    movq -80(%rbp), %r8
    call __fn_http____shared_string.r
    call __fn___fern_str_free.r
    movq -104(%rbp), %r8
    addq -120(%rbp), %r8
    movslq %r8d, %r15
.Lssa_main_165:
.Lssa_main_164:
    xorl %ebx, %ebx
.Lssa_main_929:
    cmpq $0, -144(%rbp)
    jl .Lssa_main_163
.Lssa_main_936:
    movq -96(%rbp), %r11
    movq 16(%r11), %r13
    movq -144(%rbp), %rcx
    cmpq (%r13), %rcx
    jae __fern_oob_abort
    movq 8(%r13,%rcx,8), %rax
    leaq .SB193(%rip), %rsi
    call __fn_http____lists_token.r
    testq %rax, %rax
    jz .Lssa_main_933
.Lssa_main_935:
    movl $1, %ebx
.Lssa_main_934:
.Lssa_main_933:
    movq -144(%rbp), %rcx
    cmpq (%r13), %rcx
    jae __fern_oob_abort
    movq 8(%r13,%rcx,8), %rax
    leaq .SB194(%rip), %rsi
    call __fn_http____lists_token.r
.Lssa_main_930:
    leaq .SB65(%rip), %rsi
    movq -144(%rbp), %r8
    addq $1, %r8
    movslq %r8d, %rdi
    movq -96(%rbp), %rax
    call __fn_http____field_at.r
    movq %rax, -144(%rbp)
    cmpq $0, -144(%rbp)
    jge .Lssa_main_936
.Lssa_main_163:
    testq %rbx, %rbx
    jnz .Lssa_main_155
.Lssa_main_160:
    leaq .SB186(%rip), %rdi
    movq -128(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_main_155
.Lssa_main_958:
    movq -128(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_main_streqn3088
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn3088
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd3088
.Lssa_main_streqn3088:
    xorl %eax, %eax
.Lssa_main_streqd3088:
.Lssa_main_155:
    movq -136(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_146
.Lssa_main_154:
    cmpq $1048576, -152(%rbp)
    jle .Lssa_main_151
.Lssa_main_970:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
.Lssa_main_153:
    movq $413, -72(%rbp)
    jmp .Lssa_main_95
.Lssa_main_151:
    movq %r15, %rsi
    addq -152(%rbp), %rsi
    movslq %esi, %rsi
    movq 0(%r14), %rdi
    cmpq %rdi, %rsi
    jle .Lssa_main_148
.Lssa_main_975:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
.Lssa_main_150:
    movq $1, -72(%rbp)
    jmp .Lssa_main_95
.Lssa_main_148:
    movq %r15, %rdi
    addq -152(%rbp), %rdi
    movslq %edi, %rdi
    pushq %r14
    pushq %r15
    pushq %rdi
    call __fn___fern_bytes_range
    addq $24, %rsp
    movq %rax, %rbx
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    movq $2, -72(%rbp)
    jmp .Lssa_main_95
.Lssa_main_146:
    leaq .SB187(%rip), %rdi
    movq -128(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_main_982
.Lssa_main_981:
    movq -128(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_main_streqn3117
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn3117
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd3117
.Lssa_main_streqn3117:
    xorl %eax, %eax
.Lssa_main_streqd3117:
    jmp .Lssa_main_983
.Lssa_main_982:
    xorl %eax, %eax
.Lssa_main_983:
    testq %rax, %rax
    jnz .Lssa_main_142
.Lssa_main_984:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
.Lssa_main_145:
    movq $400, -72(%rbp)
    jmp .Lssa_main_95
.Lssa_main_142:
    leaq .K0(%rip), %rdi
.Lssa_main_141:
    movq %r15, -80(%rbp)
    movq %rdi, -120(%rbp)
    movq $32768, -88(%rbp)
    movq $1048576, -104(%rbp)
.Lssa_main_989:
.Lssa_main_1048:
    movq 0(%r14), %r12
    movq -80(%rbp), %rdi
    addq -88(%rbp), %rdi
    movslq %edi, %rdi
    cmpq %r12, %rdi
    movq %r12, %rbx
    cmovleq %rdi, %rbx
    movq %r14, %rax
    movq -80(%rbp), %rsi
    movq %rbx, %rdi
    call __fn_http____find_crlf.r
    movq %rax, %r15
    cmpq $0, %r15
    movq %r15, %rdi
    cmovlq %rbx, %rdi
    movq %r14, %rax
    movq -80(%rbp), %rsi
    call __fn_http____crlf_terminated.r
    testq %rax, %rax
    jz .Lssa_main_1037
.Lssa_main_1040:
    cmpq $0, %r15
    jge .Lssa_main_1032
.Lssa_main_1039:
    movq -80(%rbp), %rdi
    addq -88(%rbp), %rdi
    movslq %edi, %rdi
    cmpq %rdi, %r12
    jl .Lssa_main_1035
.Lssa_main_1038:
    movl $431, %r8d
    xorl %r15d, %r15d
    xorl %r12d, %r12d
    jmp .Lssa_main_1013
.Lssa_main_1037:
    movl $400, %r8d
    xorl %r15d, %r15d
    xorl %r12d, %r12d
    jmp .Lssa_main_1013
.Lssa_main_1035:
    movl $1, %r8d
    xorl %r15d, %r15d
    xorl %r12d, %r12d
    jmp .Lssa_main_1013
.Lssa_main_1032:
.Lssa_main_1031:
    movq -80(%rbp), %rbx
    xorl %r12d, %r12d
.Lssa_main_1075:
    cmpq %r15, %rbx
    jge .Lssa_main_1030
.Lssa_main_1079:
    cmpq (%r14), %rbx
    jae __fern_oob_abort
    movzbl 8(%r14,%rbx), %r13d
    movq %r13, %rax
    call __fn_http____hex_digit.r
    cmpq $0, %rax
    jl .Lssa_main_1030
.Lssa_main_1078:
    movq %r13, %rax
    call __fn_http____hex_digit.r
    movq %r12, %rdi
    shlq $4, %rdi
    addq %rax, %rdi
    movslq %edi, %rdi
    cmpq -104(%rbp), %rdi
    jg .Lssa_main_1028
.Lssa_main_1076:
    movq %r12, %rdi
    shlq $4, %rdi
    addq %rax, %rdi
    movslq %edi, %r12
    addq $1, %rbx
    cmpq %r15, %rbx
    jl .Lssa_main_1079
.Lssa_main_1030:
    cmpq -80(%rbp), %rbx
    jne .Lssa_main_1026
.Lssa_main_1029:
    movl $400, %edi
    xorl %r12d, %r12d
    jmp .Lssa_main_1025
.Lssa_main_1028:
    movl $413, %edi
    xorl %r12d, %r12d
    jmp .Lssa_main_1025
.Lssa_main_1026:
    xorl %edi, %edi
.Lssa_main_1025:
    cmpq $0, %rdi
    je .Lssa_main_1105
.Lssa_main_1024:
    movq %rdi, %r8
    xorl %r15d, %r15d
    xorl %r12d, %r12d
    jmp .Lssa_main_1013
.Lssa_main_1022:
.Lssa_main_1105:
    cmpq %r15, %rbx
    jge .Lssa_main_1015
.Lssa_main_1130:
    movq %r14, %rax
    movq %rbx, %rsi
    movq %r15, %rdi
    call __fn_http____bws_end.r
    cmpq %r15, %rax
    jge .Lssa_main_1014
.Lssa_main_1129:
    cmpq (%r14), %rax
    jae __fern_oob_abort
    movzbl 8(%r14,%rax), %edi
    cmpq $59, %rdi
    jne .Lssa_main_1014
.Lssa_main_1127:
    leaq 1(%rax), %rsi
    movq %r14, %rax
    movq %r15, %rdi
    call __fn_http____bws_end.r
    movq %rax, %rbx
    leaq .K2(%rip), %rsi
    movq %rsi, %rdx
    movq %rbx, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L145
    xorq %rcx, %rcx
.L145:
    leaq .S1(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L148
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L146:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L152
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L147
    addq $32, %r9
    jmp .L146
.L152:
    cmpq %r10, %r9
    jg .L153
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L147
    addq $16, %r9
.L153:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L148
.L147:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L151
.L148:
    cmpq %r8, %rcx
    jge .L150
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L149
    addq $1, %rcx
    jmp .L148
.L149:
    pushq %rcx
    jmp .L151
.L150:
    pushq %r8
.L151:
    popq %rax
    cmpq %r15, %rax
    movq %r15, %r13
    cmovleq %rax, %r13
    cmpq %rbx, %r13
    je .Lssa_main_1014
.Lssa_main_1125:
    movq %r14, %rax
    movq %r13, %rsi
    movq %r15, %rdi
    call __fn_http____bws_end.r
    cmpq %r15, %rax
    jge .Lssa_main_1120
.Lssa_main_1124:
    cmpq (%r14), %rax
    jae __fern_oob_abort
    movzbl 8(%r14,%rax), %esi
    cmpq $61, %rsi
    jne .Lssa_main_1120
.Lssa_main_1123:
    leaq 1(%rax), %rsi
    movq %r14, %rax
    movq %r15, %rdi
    call __fn_http____bws_end.r
    movq %rax, %rbx
.Lssa_main_1122:
    cmpq %r15, %rbx
    jl .Lssa_main_1118
.Lssa_main_1121:
    movq $-1, %rax
    jmp .Lssa_main_1108
.Lssa_main_1120:
    movq %r13, %rbx
    jmp .Lssa_main_1105
.Lssa_main_1118:
    cmpq (%r14), %rbx
    jae __fern_oob_abort
    movzbl 8(%r14,%rbx), %esi
    cmpq $34, %rsi
    je .Lssa_main_1113
.Lssa_main_1117:
    leaq .K2(%rip), %rsi
    movq %rsi, %rdx
    movq %rbx, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L154
    xorq %rcx, %rcx
.L154:
    leaq .S1(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L157
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L155:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L161
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L156
    addq $32, %r9
    jmp .L155
.L161:
    cmpq %r10, %r9
    jg .L162
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L156
    addq $16, %r9
.L162:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L157
.L156:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L160
.L157:
    cmpq %r8, %rcx
    jge .L159
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L158
    addq $1, %rcx
    jmp .L157
.L158:
    pushq %rcx
    jmp .L160
.L159:
    pushq %r8
.L160:
    popq %rax
    cmpq %r15, %rax
    cmovgq %r15, %rax
    cmpq %rbx, %rax
    jne .Lssa_main_1108
.Lssa_main_1116:
    movq $-1, %rax
.Lssa_main_1115:
    jmp .Lssa_main_1108
.Lssa_main_1113:
    addq $1, %rbx
.Lssa_main_1112:
.Lssa_main_1189:
    cmpq %r15, %rbx
    jge .Lssa_main_1111
.Lssa_main_1204:
    cmpq (%r14), %rbx
    jae __fern_oob_abort
    movzbl 8(%r14,%rbx), %esi
    cmpq $34, %rsi
    je .Lssa_main_1110
.Lssa_main_1202:
    leaq 1(%rbx), %rdi
    cmpq $92, %rsi
    cmovneq %rbx, %rdi
    cmpq %r15, %rdi
    jge .Lssa_main_1109
.Lssa_main_1198:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %esi
.Lssa_main_1197:
    cmpq $9, %rsi
    je .Lssa_main_1190
.Lssa_main_1195:
    cmpq $32, %rsi
    jb .Lssa_main_1109
.Lssa_main_1194:
    cmpq $127, %rsi
    je .Lssa_main_1109
.Lssa_main_1190:
    leaq 1(%rdi), %rbx
    cmpq %r15, %rbx
    jl .Lssa_main_1204
.Lssa_main_1111:
    movq $-1, %rax
    jmp .Lssa_main_1108
.Lssa_main_1110:
    addq $1, %rbx
    movq %rbx, %rax
    jmp .Lssa_main_1108
.Lssa_main_1109:
    movq $-1, %rax
.Lssa_main_1108:
    cmpq $0, %rax
    jl .Lssa_main_1014
.Lssa_main_1107:
    movq %rax, %rbx
.Lssa_main_1106:
    cmpq %r15, %rbx
    jl .Lssa_main_1130
.Lssa_main_1015:
    movl $2, %r8d
    jmp .Lssa_main_1013
.Lssa_main_1014:
    movl $400, %r8d
    xorl %r15d, %r15d
    xorl %r12d, %r12d
.Lssa_main_1013:
    cmpq $2, %r8
    jne .Lssa_main_140
.Lssa_main_1011:
    addq $2, %r15
    movslq %r15d, %r15
    movq %r15, %rdi
    subq -80(%rbp), %rdi
    movq -88(%rbp), %r11
    subq %rdi, %r11
    movq %r11, %rdi
    subq $2, %rdi
    movslq %edi, %r9
    cmpq $0, %r9
    jl .Lssa_main_139
.Lssa_main_1009:
    cmpq $0, %r12
    je .Lssa_main_138
.Lssa_main_1007:
    leaq (%r15,%r12), %rdi
    movslq %edi, %rdi
.Lssa_main_1006:
    movq 0(%r14), %rsi
    cmpq %rsi, %rdi
    jge .Lssa_main_1002
.Lssa_main_1005:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %r10d
    cmpq $13, %r10
    je .Lssa_main_1002
.Lssa_main_1004:
    xorl %edi, %edi
    jmp .Lssa_main_994
.Lssa_main_1002:
    leaq 1(%rdi), %r10
    movslq %r10d, %r10
    cmpq %rsi, %r10
    jge .Lssa_main_998
.Lssa_main_1001:
    leal 1(%rdi), %r10d
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movzbl 8(%r14,%r10), %eax
    cmpq $10, %rax
    je .Lssa_main_998
.Lssa_main_1000:
    xorl %edi, %edi
    jmp .Lssa_main_994
.Lssa_main_998:
    addq $2, %rdi
    movslq %edi, %rdi
    cmpq %rsi, %rdi
    jle .Lssa_main_995
.Lssa_main_997:
    movl $1, %edi
    jmp .Lssa_main_994
.Lssa_main_995:
    movl $2, %edi
.Lssa_main_994:
    cmpq $0, %rdi
    je .Lssa_main_135
.Lssa_main_992:
    cmpq $1, %rdi
    je .Lssa_main_134
.Lssa_main_990:
    movq -120(%rbp), %rdi
    movq %r15, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_main_apush3512s
.Lssa_main_apush3512o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_main_apush3512e
.Lssa_main_apush3512s:
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    call __fern_arr_push_owned
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
.Lssa_main_apush3512e:
    movq %rax, %rdi
    movq %r12, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa_main_apush3513s
.Lssa_main_apush3513o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa_main_apush3513e
.Lssa_main_apush3513s:
    movq %r8, -160(%rbp)
    movq %r9, -168(%rbp)
    call __fern_arr_push_owned
    movq -160(%rbp), %r8
    movq -168(%rbp), %r9
.Lssa_main_apush3513e:
    movq %rax, -120(%rbp)
    movq -104(%rbp), %rdi
    subq %r12, %rdi
    movslq %edi, %r11
    movq %r11, -104(%rbp)
    addq %r15, %r12
    addq $2, %r12
    movslq %r12d, %r11
    movq %r11, -80(%rbp)
    movq %r9, -88(%rbp)
    jmp .Lssa_main_1048
.Lssa_main_140:
    movq %r8, %r15
    jmp .Lssa_main_104
.Lssa_main_139:
    movl $431, %r15d
    jmp .Lssa_main_104
.Lssa_main_138:
    leaq 2(%r9), %r12
.Lssa_main_137:
    movq 0(%r14), %rbx
    leaq (%r15,%r12), %r9
    movslq %r9d, %r9
    cmpq %rbx, %r9
    movq %rbx, %r13
    cmovleq %r9, %r13
    leaq -2(%r15), %r9
    movslq %r9d, %r9
    jmp .Lssa_main_131
.Lssa_main_135:
    movl $400, %r15d
    jmp .Lssa_main_104
.Lssa_main_134:
    movl $1, %r15d
    jmp .Lssa_main_104
.Lssa_main_131:
    movl $13, %r8d
    movq %r9, %rdx
    movq %r8, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L163
    xorq %rdx, %rdx
.L163:
    cmpq $255, %rcx
    ja .L167
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L171
.L169:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L170
    addq $32, %r9
    cmpq %r10, %r9
    jle .L169
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L171
.L170:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L168
.L171:
    vzeroupper
.L164:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L166
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L165
    addq $16, %rdx
    jmp .L164
.L165:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L168
.L166:
    cmpq %r8, %rdx
    jge .L167
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L172
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L167
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L167
    addq %r9, %rdx
    jmp .L168
.L172:
    cmpq %r8, %rdx
    jge .L167
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L168
    addq $1, %rdx
    jmp .L172
.L167:
    movq $-1, %rdx
.L168:
    movq %rdx, %rdi
.Lssa_main_130:
.Lssa_main_1308:
    cmpq $0, %rdi
    jl .Lssa_main_129
.Lssa_main_1314:
    leaq 3(%rdi), %r8
    movslq %r8d, %r8
    cmpq %r13, %r8
    jge .Lssa_main_129
.Lssa_main_1313:
    leal 1(%rdi), %r8d
    cmpq (%r14), %r8
    jae __fern_oob_abort
    movzbl 8(%r14,%r8), %r9d
    cmpq $10, %r9
    jne .Lssa_main_1309
.Lssa_main_1312:
    leal 2(%rdi), %r9d
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %r8d
    cmpq $13, %r8
    jne .Lssa_main_1309
.Lssa_main_1311:
    leal 3(%rdi), %r8d
    cmpq (%r14), %r8
    jae __fern_oob_abort
    movzbl 8(%r14,%r8), %r9d
    cmpq $10, %r9
    je .Lssa_main_128
.Lssa_main_1309:
    leaq 1(%rdi), %r9
    movslq %r9d, %r9
    movl $13, %r8d
    movq %r9, %rdx
    movq %r8, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L173
    xorq %rdx, %rdx
.L173:
    cmpq $255, %rcx
    ja .L177
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L181
.L179:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L180
    addq $32, %r9
    cmpq %r10, %r9
    jle .L179
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L181
.L180:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L178
.L181:
    vzeroupper
.L174:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L176
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L175
    addq $16, %rdx
    jmp .L174
.L175:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L178
.L176:
    cmpq %r8, %rdx
    jge .L177
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L182
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L177
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L177
    addq %r9, %rdx
    jmp .L178
.L182:
    cmpq %r8, %rdx
    jge .L177
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L178
    addq $1, %rdx
    jmp .L182
.L177:
    movq $-1, %rdx
.L178:
    movq %rdx, %rdi
    cmpq $0, %rdi
    jge .Lssa_main_1314
.Lssa_main_129:
    movq $-1, %r8
    jmp .Lssa_main_127
.Lssa_main_128:
    movq %rdi, %r8
.Lssa_main_127:
    cmpq $0, %r8
    movq %r8, %rdi
    cmovlq %r13, %rdi
    cmpq %r15, %rdi
    jle .Lssa_main_121
.Lssa_main_123:
    movq %r8, -160(%rbp)
    movq %r14, %rax
    movq %r15, %rsi
    call __fn_http____crlf_terminated.r
    movq -160(%rbp), %r8
    testq %rax, %rax
    jz .Lssa_main_118
.Lssa_main_121:
    cmpq $0, %r8
    jge .Lssa_main_114
.Lssa_main_120:
    addq %r15, %r12
    movslq %r12d, %r12
    cmpq %r12, %rbx
    jl .Lssa_main_116
.Lssa_main_119:
    movl $431, %r15d
    jmp .Lssa_main_104
.Lssa_main_118:
    movl $400, %r15d
    jmp .Lssa_main_104
.Lssa_main_116:
    movl $1, %r15d
    jmp .Lssa_main_104
.Lssa_main_114:
    cmpq %r15, %r8
    jle .Lssa_main_108
.Lssa_main_113:
    leaq .K1(%rip), %r9
    movq %r14, %rax
    movq %r15, %rsi
    movq %r8, %rdi
    movq -72(%rbp), %r8
    call __fn_http____parse_header_bytes.r
    movq %rax, %r12
    movq %rdx, %r15
    cmpq $0, %r12
    jne .Lssa_main_104
.Lssa_main_112:
    movq %r15, %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_main_108:
    movl $2, %r15d
.Lssa_main_105:
.Lssa_main_104:
    cmpq $2, %r15
    je .Lssa_main_101
.Lssa_main_1372:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -120(%rbp), %rax
    call __fn___fern_arr_dec.r
.Lssa_main_103:
    movq %r15, -72(%rbp)
    jmp .Lssa_main_95
.Lssa_main_101:
.Lssa_main_100:
.Lssa_main_99:
    xorl %edi, %edi
    movl $1, %r9d
.Lssa_main_1377:
    movq -120(%rbp), %r11
    movq 0(%r11), %r8
    cmpq %r8, %r9
    jge .Lssa_main_98
.Lssa_main_1378:
    movq -120(%rbp), %r11
    movq 8(%r11,%r9,8), %r8
    addq %rdi, %r8
    movslq %r8d, %rdi
    addq $2, %r9
    movslq %r9d, %r9
    jmp .Lssa_main_1377
.Lssa_main_98:
    call __fern_alloc_bytes
.Lssa_main_97:
    movq %rax, %r12
    xorl %r15d, %r15d
    xorl %ebx, %ebx
.Lssa_main_1385:
    leaq 1(%r15), %rdi
    movslq %edi, %rdi
    movq -120(%rbp), %r11
    movq 0(%r11), %r9
    cmpq %r9, %rdi
    jl .Lssa_main_1386
.Lssa_main_1388:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq -120(%rbp), %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_96
.Lssa_main_1386:
    leaq 1(%r15), %r9
    movslq %r9d, %r13
    movq %r15, %r9
    sarq $31, %r9
    orq %r13, %r9
    movq -120(%rbp), %r11
    cmpq (%r11), %r9
    jae __fern_oob_abort
    movq 8(%r11,%r15,8), %rdi
    movq 8(%r11,%r13,8), %r9
    pushq %r12
    pushq %rbx
    pushq %r14
    pushq %rdi
    pushq %r9
    call __fn___fern_bytes_into
    addq $40, %rsp
    movq %rax, %r12
    movq -120(%rbp), %r11
    cmpq (%r11), %r13
    jae __fern_oob_abort
    movq 8(%r11,%r13,8), %r9
    addq %r9, %rbx
    movslq %ebx, %rbx
    addq $2, %r15
    movslq %r15d, %r15
    jmp .Lssa_main_1385
.Lssa_main_96:
    movq $2, -72(%rbp)
.Lssa_main_95:
    cmpq $2, -72(%rbp)
    je .Lssa_main_92
.Lssa_main_1393:
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_35
.Lssa_main_92:
    leaq .SB195(%rip), %r9
    movq %r9, %rax
    movq -112(%rbp), %rsi
    call __fn___fern_str_concat.r
    movq %rax, %rbx
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
    movq $2, %rdi
    call __fern_arr_box
    movq %rax, %r12
    leaq .S7(%rip), %r9
    movq %r9, 0(%r12)
    movq %rbx, 8(%r12)
    leaq .K1(%rip), %rbx
    leaq .K1(%rip), %r14
    leaq .K6(%rip), %r13
    movl $200, %r15d
    movq $6, %rdi
    call __fern_arr_box
    leaq .S6(%rip), %rdi
    movq %rdi, 0(%rax)
    movq %r15, 8(%rax)
    movq %r12, 16(%rax)
    movq %rbx, 24(%rax)
    movq %r14, 32(%rax)
    movq %r13, 40(%rax)
.Lssa_main_90:
    leaq .SB196(%rip), %r11
    movq %r11, -80(%rbp)
.Lssa_main_89:
    movq %rax, %r14
    movq $200, -88(%rbp)
.Lssa_main_1397:
    movq 24(%r14), %rax
    call __fn_http__fields_ok.r
    testq %rax, %rax
    jnz .Lssa_main_1399
.Lssa_main_1401:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_main_1398
.Lssa_main_1399:
    movq 32(%r14), %rax
    call __fn_http__fields_ok.r
    testq %rax, %rax
    jnz .Lssa_main_86
.Lssa_main_1405:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
.Lssa_main_1398:
    leaq .K7(%rip), %r14
    movq $500, -88(%rbp)
    jmp .Lssa_main_1397
.Lssa_main_86:
    cmpq $200, -88(%rbp)
    jl .Lssa_main_82
.Lssa_main_84:
    cmpq $204, -88(%rbp)
    jne .Lssa_main_81
.Lssa_main_82:
    movq $1, -104(%rbp)
    jmp .Lssa_main_79
.Lssa_main_81:
    movq -88(%rbp), %r9
    cmpq $304, %r9
    sete %r9b
    movzbq %r9b, %r9
    movq %r9, -104(%rbp)
.Lssa_main_80:
.Lssa_main_79:
    leaq .SB8(%rip), %r9
    leaq .SB8(%rip), %rdi
    movq -104(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_77
.Lssa_main_78:
    movq %r9, -112(%rbp)
    movq %rdi, -120(%rbp)
    jmp .Lssa_main_76
.Lssa_main_77:
    movq %r14, %rax
    call __fn_HttpResponse__body_text_lossy.r
    movq %rax, %r15
    leaq .SB9(%rip), %r9
    movq 8(%r15), %rax
    movq %r9, -160(%rbp)
    call __fn_int__int_to_string.r
    movq %rax, %r8
    movq -160(%rbp), %r9
    movq %r8, -160(%rbp)
    movq %r9, %rax
    movq %r8, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r10
    movq -160(%rbp), %r8
    movq %r10, -160(%rbp)
    movq %r8, %rax
    call __fn___fern_str_free.r
    movq -160(%rbp), %r10
    leaq .SB10(%rip), %r8
    movq %r8, -160(%rbp)
    movq %r10, -168(%rbp)
    pushq %r10
    pushq %r8
    call __fn___fern_str_grow
    addq $16, %rsp
    movq -160(%rbp), %r8
    movq -168(%rbp), %r10
    testq %rax, %rax
    jz .Lssa_main_1426
.Lssa_main_1425:
    movq %r10, %r9
    jmp .Lssa_main_1427
.Lssa_main_1426:
    movq %r10, -160(%rbp)
    pushq %r10
    pushq %r8
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %r9
    movq -160(%rbp), %r10
    movq %r9, -160(%rbp)
    movq %r10, %rax
    call __fn___fern_str_free.r
    movq -160(%rbp), %r9
.Lssa_main_1427:
    movq %r9, -112(%rbp)
    movq %r15, -120(%rbp)
.Lssa_main_76:
    movl $256, %r9d
    movq %r9, %rdi
    call __fern_buf_new
    movq %rax, %r12
.Lssa_main_74:
    leaq .SB11(%rip), %r9
    movq %r12, %rdi
    movq %r9, %rsi
    call __fern_buf_push
.Lssa_main_73:
    cmpq $0, -88(%rbp)
    jge .Lssa_main_70
.Lssa_main_72:
    movl $45, %r9d
    movq %r12, %rdi
    movq %r9, %rsi
    call __fern_buf_push_byte
    xorl %r9d, %r9d
    subq -88(%rbp), %r9
    movq %r12, %rdi
    movq %r9, %rsi
    call __fern_buf_push_decimal
    jmp .Lssa_main_69
.Lssa_main_70:
    movq %r12, %rdi
    movq -88(%rbp), %rsi
    call __fern_buf_push_decimal
.Lssa_main_69:
    leaq .SB12(%rip), %r9
    movq %r12, %rdi
    movq %r9, %rsi
    call __fern_buf_push
.Lssa_main_67:
    leaq .K8(%rip), %r9
    leaq .K9(%rip), %r8
.Lssa_main_66:
    xorl %r10d, %r10d
.Lssa_main_1433:
    movq 0(%r9), %rdi
    cmpq %rdi, %r10
    jge .Lssa_main_65
.Lssa_main_1436:
    movq 8(%r9,%r10,8), %rdi
    cmpq -88(%rbp), %rdi
    je .Lssa_main_64
.Lssa_main_1434:
    addq $1, %r10
    jmp .Lssa_main_1433
.Lssa_main_65:
    leaq .SB8(%rip), %r9
    movq %r9, %r15
    jmp .Lssa_main_63
.Lssa_main_64:
    cmpq (%r8), %r10
    jae __fern_oob_abort
    movq 8(%r8,%r10,8), %r15
    pushq %r15
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_main_63:
    movq 8(%r15), %r10
    cmpq $0, %r10
    jne .Lssa_main_60
.Lssa_main_1448:
    movq %r15, %rax
    call __fn___fern_str_free.r
.Lssa_main_62:
    leaq .SB63(%rip), %r10
    movq %r10, %r15
.Lssa_main_61:
.Lssa_main_60:
    movq %r12, %rdi
    movq %r15, %rsi
    call __fern_buf_push
    movq %r15, %rax
    call __fn___fern_str_free.r
    leaq .SB10(%rip), %r10
    movq %r12, %rdi
    movq %r10, %rsi
    call __fern_buf_push
.Lssa_main_59:
    xorl %r15d, %r15d
.Lssa_main_1453:
    movq 24(%r14), %r10
    movq 8(%r10), %r8
    movq 0(%r8), %r10
    cmpq %r10, %r15
    jl .Lssa_main_1459
.Lssa_main_1461:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_main_57
.Lssa_main_1459:
    movq 24(%r14), %r13
    movq 8(%r13), %r10
    movq 8(%r10,%r15,8), %rbx
    leaq .SB64(%rip), %rsi
    movq %rbx, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_main_1454
.Lssa_main_1458:
    leaq .SB65(%rip), %rsi
    movq %rbx, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_main_1454
.Lssa_main_1457:
    leaq .SB66(%rip), %rsi
    movq %rbx, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_main_1454
.Lssa_main_1455:
    movq 8(%r13), %rsi
    movq 8(%rsi,%r15,8), %r10
    movq %r12, %rdi
    movq %r10, %rsi
    call __fern_buf_push
    leaq .SB67(%rip), %r10
    movq %r12, %rdi
    movq %r10, %rsi
    call __fern_buf_push
    movq 16(%r13), %r10
    cmpq (%r10), %r15
    jae __fern_oob_abort
    movq 8(%r10,%r15,8), %rsi
    movq %r12, %rdi
    call __fern_buf_push
    leaq .SB10(%rip), %rsi
    movq %r12, %rdi
    call __fern_buf_push
.Lssa_main_1454:
    addq $1, %r15
    jmp .Lssa_main_1453
.Lssa_main_57:
    movq %r12, %rdi
    movq -112(%rbp), %rsi
    call __fern_buf_push
    movq -112(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_main_56:
    cmpq $101, -88(%rbp)
    jne .Lssa_main_51
.Lssa_main_55:
    leaq .SB68(%rip), %rsi
    movq %r12, %rdi
    call __fern_buf_push
    jmp .Lssa_main_48
.Lssa_main_51:
    leaq .SB69(%rip), %rsi
    movq %r12, %rdi
    call __fern_buf_push
.Lssa_main_48:
    movq %r12, %rdi
    call __fern_buf_take
    movq %rax, %r15
    movq %r12, %rdi
    call __fern_buf_free
    movq -104(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_47
.Lssa_main_1484:
    movq -120(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_main_46
.Lssa_main_47:
    leaq .SB71(%rip), %rsi
    movq -80(%rbp), %r11
    movq 8(%r11), %r10
    cmpq $4, %r10
    jne .Lssa_main_44
.Lssa_main_1488:
    movq -80(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rsi), %rdx
    jne .Lssa_main_streqn4003
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn4003
    movq %r11, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd4003
.Lssa_main_streqn4003:
    xorl %eax, %eax
.Lssa_main_streqd4003:
    testq %rax, %rax
    jz .Lssa_main_44
.Lssa_main_1491:
    movq -120(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_main_46:
    movq %r15, %r12
    jmp .Lssa_main_41
.Lssa_main_44:
    pushq %r15
    pushq -120(%rbp)
    call __fn___fern_str_grow
    addq $16, %rsp
    testq %rax, %rax
    jz .Lssa_main_1497
.Lssa_main_1496:
    movq %r15, %r12
    jmp .Lssa_main_1498
.Lssa_main_1497:
    pushq %r15
    pushq -120(%rbp)
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %r12
    movq %r15, %rax
    call __fn___fern_str_free.r
.Lssa_main_1498:
    movq -120(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_main_43:
.Lssa_main_41:
    movq 8(%r12), %r15
    movq %r12, %rax
    call __fn___fern_str_free.r
    movq -96(%rbp), %r11
    testb $1, %r11b
    jnz .Lssa_main_uq41
    cmpq $0x10000, %r11
    jb .Lssa_main_uq41
    cmpl $1, -8(%r11)
.Lssa_main_uq41:
    jne .Lssa_main_1500
.Lssa_main_1499:
    movq -96(%rbp), %r12
    jmp .Lssa_main_1501
.Lssa_main_1500:
    xorl %r12d, %r12d
.Lssa_main_1501:
    movq -96(%rbp), %r11
    movq 8(%r11), %r14
    cmpq $0, %r12
    jne .Lssa_main_1504
.Lssa_main_1502:
    pushq %r14
    call __fn___fern_rc_inc
    addq $8, %rsp
.Lssa_main_1504:
    cmpq $0, %r12
    je .Lssa_main_1506
.Lssa_main_1505:
    movq -96(%rbp), %r11
    movq 16(%r11), %r12
    testb $1, %r12b
    jnz .Lssa_main_uq1505
    cmpq $0x10000, %r12
    jb .Lssa_main_uq1505
    cmpl $1, -8(%r12)
.Lssa_main_uq1505:
    jne .Lssa_main_1510
.Lssa_main_1508:
    xorl %r13d, %r13d
.Lssa_main_1512:
    movq 0(%r12), %rsi
    cmpq %rsi, %r13
    jge .Lssa_main_1510
.Lssa_main_1513:
    movq 8(%r12,%r13,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r13
    jmp .Lssa_main_1512
.Lssa_main_1510:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq -96(%rbp), %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_1507
.Lssa_main_1506:
    movq -96(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_main_1507:
    movq 0(%r14), %r13
    testb $1, %r14b
    jnz .Lssa_main_uq1507
    cmpq $0x10000, %r14
    jb .Lssa_main_uq1507
    cmpl $1, -8(%r14)
.Lssa_main_uq1507:
    jne .Lssa_main_1518
.Lssa_main_1516:
    xorl %r12d, %r12d
.Lssa_main_1520:
    movq 0(%r14), %rsi
    cmpq %rsi, %r12
    jge .Lssa_main_1518
.Lssa_main_1521:
    movq 8(%r14,%r12,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r12
    jmp .Lssa_main_1520
.Lssa_main_1518:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    addq %r13, %r15
    movslq %r15d, %r15
    addq %r15, -56(%rbp)
.Lssa_main_40:
    addq $1, -64(%rbp)
    cmpq $4000, -64(%rbp)
    jl .Lssa_main_348
.Lssa_main_37:
    movq -56(%rbp), %rax
    movq %rax, %rcx
    movabsq $-6275696437447579415, %rax
    imulq %rcx
    addq %rcx, %rdx
    sarq $6, %rdx
    movq %rdx, %rax
    shrq $63, %rdx
    addq %rdx, %rax
    imulq $97, %rax, %rax
    subq %rax, %rcx
    movq %rcx, %rax
    movq %rax, %rsi
    movslq %esi, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_main_35:
    cmpq $400, -72(%rbp)
    jge .Lssa_main_1
.Lssa_main_32:
    leaq .SB186(%rip), %rsi
    movq -128(%rbp), %r11
    movq 8(%r11), %r10
    cmpq $8, %r10
    jne .Lssa_main_1532
.Lssa_main_1531:
    movq -128(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rsi), %rdx
    jne .Lssa_main_streqn4075
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn4075
    movq %r11, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd4075
.Lssa_main_streqn4075:
    xorl %eax, %eax
.Lssa_main_streqd4075:
    jmp .Lssa_main_1533
.Lssa_main_1532:
    xorl %eax, %eax
.Lssa_main_1533:
    testq %rax, %rax
    jz .Lssa_main_1
.Lssa_main_31:
.Lssa_main_28:
.Lssa_main_27:
.Lssa_main_26:
.Lssa_main_25:
.Lssa_main_24:
.Lssa_main_23:
.Lssa_main_22:
.Lssa_main_21:
.Lssa_main_20:
.Lssa_main_14:
.Lssa_main_11:
.Lssa_main_10:
.Lssa_main_8:
.Lssa_main_1:
    movl $100, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_HeaderMap
.weak __fn___sem_drop_HeaderMap.r
__fn___sem_drop_HeaderMap:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_HeaderMap.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
.Lssa___sem_drop_HeaderMap_0:
    movq 8(%rbx), %r12
    testb $1, %r12b
    jnz .Lssa___sem_drop_HeaderMap_uq0
    cmpq $0x10000, %r12
    jb .Lssa___sem_drop_HeaderMap_uq0
    cmpl $1, -8(%r12)
.Lssa___sem_drop_HeaderMap_uq0:
    jne .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_1:
    xorl %r13d, %r13d
.Lssa___sem_drop_HeaderMap_5:
    movq 0(%r12), %rsi
    cmpq %rsi, %r13
    jge .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_6:
    movq 8(%r12,%r13,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r13
    jmp .Lssa___sem_drop_HeaderMap_5
.Lssa___sem_drop_HeaderMap_3:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq 16(%rbx), %r13
    testb $1, %r13b
    jnz .Lssa___sem_drop_HeaderMap_uq3
    cmpq $0x10000, %r13
    jb .Lssa___sem_drop_HeaderMap_uq3
    cmpl $1, -8(%r13)
.Lssa___sem_drop_HeaderMap_uq3:
    jne .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_9:
    xorl %ebx, %ebx
.Lssa___sem_drop_HeaderMap_13:
    movq 0(%r13), %rsi
    cmpq %rsi, %rbx
    jge .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_14:
    movq 8(%r13,%rbx,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %rbx
    jmp .Lssa___sem_drop_HeaderMap_13
.Lssa___sem_drop_HeaderMap_11:
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_HeaderMap
.weak __fn___sem_release_HeaderMap.r
__fn___sem_release_HeaderMap:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_HeaderMap.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_HeaderMap_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_HeaderMap_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_HeaderMap_release_slow
.Lssa___sem_release_HeaderMap_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_HeaderMap_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_HeaderMap_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_HeaderMap_release_body
    pushq %rax
    call __fn___sem_drop_HeaderMap.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_HeaderMap_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_HeaderMap_0:
    testb $1, %bl
    jnz .Lssa___sem_release_HeaderMap_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_HeaderMap_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_HeaderMap_uq0:
    jne .Lssa___sem_release_HeaderMap_3
.Lssa___sem_release_HeaderMap_1:
    movq %rbx, %rax
    call __fn___sem_drop_HeaderMap.r
.Lssa___sem_release_HeaderMap_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_HttpResponse
.weak __fn___sem_drop_HttpResponse.r
__fn___sem_drop_HttpResponse:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_HttpResponse.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_drop_HttpResponse_0:
    movq 16(%rbx), %rax
    call __fn___sem_release_Body.r
    movq 24(%rbx), %rax
    call __fn___sem_release_HeaderMap.r
    movq 32(%rbx), %rax
    call __fn___sem_release_HeaderMap.r
    movq 40(%rbx), %rax
    call __fn___sem_release_Option$$fn$void.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_HttpResponse
.weak __fn___sem_release_HttpResponse.r
__fn___sem_release_HttpResponse:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_HttpResponse.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_HttpResponse_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_HttpResponse_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_HttpResponse_release_slow
.Lssa___sem_release_HttpResponse_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_HttpResponse_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_HttpResponse_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_HttpResponse_release_body
    pushq %rax
    call __fn___sem_drop_HttpResponse.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_HttpResponse_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_HttpResponse_0:
    testb $1, %bl
    jnz .Lssa___sem_release_HttpResponse_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_HttpResponse_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_HttpResponse_uq0:
    jne .Lssa___sem_release_HttpResponse_3
.Lssa___sem_release_HttpResponse_1:
    movq %rbx, %rax
    call __fn___sem_drop_HttpResponse.r
.Lssa___sem_release_HttpResponse_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_ByteStream
.weak __fn___sem_drop_ByteStream.r
__fn___sem_drop_ByteStream:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_ByteStream.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_drop_ByteStream_0:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %rax
    call __fn___sem_release_Option$BodySource.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_ByteStream
.weak __fn___sem_release_ByteStream.r
__fn___sem_release_ByteStream:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_ByteStream.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_ByteStream_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_ByteStream_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_ByteStream_release_slow
.Lssa___sem_release_ByteStream_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_ByteStream_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_ByteStream_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_ByteStream_release_body
    pushq %rax
    call __fn___sem_drop_ByteStream.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_ByteStream_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_ByteStream_0:
    testb $1, %bl
    jnz .Lssa___sem_release_ByteStream_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_ByteStream_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_ByteStream_uq0:
    jne .Lssa___sem_release_ByteStream_3
.Lssa___sem_release_ByteStream_1:
    movq %rbx, %rax
    call __fn___sem_drop_ByteStream.r
.Lssa___sem_release_ByteStream_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_ChunkProducer
.weak __fn___sem_drop_ChunkProducer.r
__fn___sem_drop_ChunkProducer:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_ChunkProducer.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_drop_ChunkProducer_0:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 32(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_ChunkProducer
.weak __fn___sem_release_ChunkProducer.r
__fn___sem_release_ChunkProducer:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_ChunkProducer.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_ChunkProducer_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_ChunkProducer_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_ChunkProducer_release_slow
.Lssa___sem_release_ChunkProducer_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_ChunkProducer_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_ChunkProducer_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_ChunkProducer_release_body
    pushq %rax
    call __fn___sem_drop_ChunkProducer.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_ChunkProducer_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_ChunkProducer_0:
    testb $1, %bl
    jnz .Lssa___sem_release_ChunkProducer_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_ChunkProducer_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_ChunkProducer_uq0:
    jne .Lssa___sem_release_ChunkProducer_3
.Lssa___sem_release_ChunkProducer_1:
    movq %rbx, %rax
    call __fn___sem_drop_ChunkProducer.r
.Lssa___sem_release_ChunkProducer_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_BodySource
.weak __fn___sem_drop_BodySource.r
__fn___sem_drop_BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_BodySource.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
.Lssa___sem_drop_BodySource_0:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 16(%rbx), %r12
    testb $1, %r12b
    jnz .Lssa___sem_drop_BodySource_uq0
    cmpq $0x10000, %r12
    jb .Lssa___sem_drop_BodySource_uq0
    cmpl $1, -8(%r12)
.Lssa___sem_drop_BodySource_uq0:
    jne .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_1:
    xorl %r13d, %r13d
.Lssa___sem_drop_BodySource_5:
    movq 0(%r12), %rsi
    cmpq %rsi, %r13
    jge .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_6:
    movq 8(%r12,%r13,8), %rax
    call __fn___sem_release_Option$StreamFault.r
    addq $1, %r13
    jmp .Lssa___sem_drop_BodySource_5
.Lssa___sem_drop_BodySource_3:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_BodySource
.weak __fn___sem_release_BodySource.r
__fn___sem_release_BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_BodySource.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_BodySource_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_BodySource_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_BodySource_release_slow
.Lssa___sem_release_BodySource_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_BodySource_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_BodySource_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_BodySource_release_body
    pushq %rax
    call __fn___sem_drop_BodySource.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_BodySource_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_BodySource_0:
    testb $1, %bl
    jnz .Lssa___sem_release_BodySource_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_BodySource_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_BodySource_uq0:
    jne .Lssa___sem_release_BodySource_3
.Lssa___sem_release_BodySource_1:
    movq %rbx, %rax
    call __fn___sem_drop_BodySource.r
.Lssa___sem_release_BodySource_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Body
.weak __fn___sem_drop_Body.r
__fn___sem_drop_Body:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Body.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
.Lssa___sem_drop_Body_0:
    movq 0(%rbx), %rsi
    cmpq $.S7, %rsi
    jne .Lssa___sem_drop_Body_2
.Lssa___sem_drop_Body_1:
    movq 8(%rbx), %rdi
    movq %rdi, %rax
    call __fn___fern_str_free.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_2:
    cmpq $.S197, %rsi
    jne .Lssa___sem_drop_Body_5
.Lssa___sem_drop_Body_4:
    movq 8(%rbx), %rdi
    movq %rdi, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_5:
    cmpq $.S198, %rsi
    jne .Lssa___sem_drop_Body_8
.Lssa___sem_drop_Body_7:
    movq 8(%rbx), %rax
    call __fn___sem_release_ByteStream.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_8:
    cmpq $.S199, %rsi
    jne .Lssa___sem_drop_Body_11
.Lssa___sem_drop_Body_10:
    movq 8(%rbx), %rdi
    movq %rdi, %rax
    call __fn___fern_str_free.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_11:
    cmpq $.S200, %rsi
    jne .Lssa___sem_drop_Body_14
.Lssa___sem_drop_Body_13:
    movq 8(%rbx), %rax
    call __fn___sem_release_ChunkProducer.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_14:
    cmpq $.S201, %rsi
    jne .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_16:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    movq 16(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %r12
    testb $1, %r12b
    jnz .Lssa___sem_drop_Body_uq16
    cmpq $0x10000, %r12
    jb .Lssa___sem_drop_Body_uq16
    cmpl $1, -8(%r12)
.Lssa___sem_drop_Body_uq16:
    jne .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_19:
    xorl %ebx, %ebx
.Lssa___sem_drop_Body_23:
    movq 0(%r12), %rsi
    cmpq %rsi, %rbx
    jge .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_24:
    movq 8(%r12,%rbx,8), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    addq $1, %rbx
    jmp .Lssa___sem_drop_Body_23
.Lssa___sem_drop_Body_21:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
.Lssa___sem_drop_Body_3:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Body
.weak __fn___sem_release_Body.r
__fn___sem_release_Body:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Body.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_Body_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_Body_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_Body_release_slow
.Lssa___sem_release_Body_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_Body_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_Body_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_Body_release_body
    pushq %rax
    call __fn___sem_drop_Body.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_Body_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_Body_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Body_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Body_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_Body_uq0:
    jne .Lssa___sem_release_Body_3
.Lssa___sem_release_Body_1:
    movq %rbx, %rax
    call __fn___sem_drop_Body.r
.Lssa___sem_release_Body_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Option$$fn$void
.weak __fn___sem_drop_Option$$fn$void.r
__fn___sem_drop_Option$$fn$void:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Option$$fn$void.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___sem_drop_Option$$fn$void_0:
    movq 0(%rax), %rsi
    cmpq $0, %rsi
    jne .Lssa___sem_drop_Option$$fn$void_3
.Lssa___sem_drop_Option$$fn$void_1:
    movq 8(%rax), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$$fn$void_3:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Option$$fn$void
.weak __fn___sem_release_Option$$fn$void.r
__fn___sem_release_Option$$fn$void:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Option$$fn$void.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_Option$$fn$void_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_Option$$fn$void_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_Option$$fn$void_release_slow
.Lssa___sem_release_Option$$fn$void_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$$fn$void_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$$fn$void_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_Option$$fn$void_release_body
    pushq %rax
    call __fn___sem_drop_Option$$fn$void.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$$fn$void_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_Option$$fn$void_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Option$$fn$void_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Option$$fn$void_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_Option$$fn$void_uq0:
    jne .Lssa___sem_release_Option$$fn$void_3
.Lssa___sem_release_Option$$fn$void_1:
    movq %rbx, %rax
    call __fn___sem_drop_Option$$fn$void.r
.Lssa___sem_release_Option$$fn$void_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Option$BodySource
.weak __fn___sem_drop_Option$BodySource.r
__fn___sem_drop_Option$BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Option$BodySource.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___sem_drop_Option$BodySource_0:
    movq 0(%rax), %rsi
    cmpq $0, %rsi
    jne .Lssa___sem_drop_Option$BodySource_3
.Lssa___sem_drop_Option$BodySource_1:
    movq 8(%rax), %rsi
    movq %rsi, %rax
    call __fn___sem_release_BodySource.r
.Lssa___sem_drop_Option$BodySource_3:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Option$BodySource
.weak __fn___sem_release_Option$BodySource.r
__fn___sem_release_Option$BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Option$BodySource.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_Option$BodySource_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_Option$BodySource_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_Option$BodySource_release_slow
.Lssa___sem_release_Option$BodySource_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$BodySource_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$BodySource_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_Option$BodySource_release_body
    pushq %rax
    call __fn___sem_drop_Option$BodySource.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$BodySource_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_Option$BodySource_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Option$BodySource_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Option$BodySource_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_Option$BodySource_uq0:
    jne .Lssa___sem_release_Option$BodySource_3
.Lssa___sem_release_Option$BodySource_1:
    movq %rbx, %rax
    call __fn___sem_drop_Option$BodySource.r
.Lssa___sem_release_Option$BodySource_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Option$StreamFault
.weak __fn___sem_drop_Option$StreamFault.r
__fn___sem_drop_Option$StreamFault:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Option$StreamFault.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___sem_drop_Option$StreamFault_0:
    movq 0(%rax), %rsi
    cmpq $0, %rsi
    jne .Lssa___sem_drop_Option$StreamFault_3
.Lssa___sem_drop_Option$StreamFault_1:
    movq 8(%rax), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$StreamFault_3:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Option$StreamFault
.weak __fn___sem_release_Option$StreamFault.r
__fn___sem_release_Option$StreamFault:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Option$StreamFault.r:
    cmpq $0x10000, %rax
    jb .Lssa___sem_release_Option$StreamFault_release_kept
    cmpl $1, -8(%rax)
    jg .Lssa___sem_release_Option$StreamFault_release_dec
    cmpl $0, -8(%rax)
    jns .Lssa___sem_release_Option$StreamFault_release_slow
.Lssa___sem_release_Option$StreamFault_release_kept:
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$StreamFault_release_dec:
    subl $1, -8(%rax)
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$StreamFault_release_slow:
    cmpl $1, -8(%rax)
    jne .Lssa___sem_release_Option$StreamFault_release_body
    pushq %rax
    call __fn___sem_drop_Option$StreamFault.r
    movq (%rsp), %rax
    call __fn___fern_arr_dec.u
    popq %rax
    xorl %eax, %eax
    ret
.Lssa___sem_release_Option$StreamFault_release_body:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___sem_release_Option$StreamFault_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Option$StreamFault_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Option$StreamFault_uq0
    cmpl $1, -8(%rbx)
.Lssa___sem_release_Option$StreamFault_uq0:
    jne .Lssa___sem_release_Option$StreamFault_3
.Lssa___sem_release_Option$StreamFault_1:
    movq %rbx, %rax
    call __fn___sem_drop_Option$StreamFault.r
.Lssa___sem_release_Option$StreamFault_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_len
.weak __fn___sem_view_len.r
__fn___sem_view_len:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_view_len.r:
.Lssa___sem_view_len_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_view_len_3
.Lssa___sem_view_len_1:
    leaq -2(%rax), %rsi
    movq 8(%rsi), %rdi
    movq %rdi, %rax
    ret
.Lssa___sem_view_len_3:
    movq 0(%rax), %rdi
    movq %rdi, %rax
    ret
    .cfi_endproc
.weak __fn___sem_view_data
.weak __fn___sem_view_data.r
__fn___sem_view_data:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_view_data.r:
.Lssa___sem_view_data_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_view_data_3
.Lssa___sem_view_data_1:
    leaq -2(%rax), %rsi
    movq 0(%rsi), %rdi
    movq %rdi, %rax
    ret
.Lssa___sem_view_data_3:
    addq $8, %rax
    ret
    .cfi_endproc
.weak __fn___sem_byte_view_slice
.weak __fn___sem_byte_view_slice.r
__fn___sem_byte_view_slice:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___sem_byte_view_slice.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa___sem_byte_view_slice_0:
    cmpq $0, %r12
    jge .Lssa___sem_byte_view_slice_3
.Lssa___sem_byte_view_slice_1:
    call __fern_slice_abort.c
.Lssa___sem_byte_view_slice_3:
    cmpq %r12, %r13
    jge .Lssa___sem_byte_view_slice_6
.Lssa___sem_byte_view_slice_4:
    call __fern_slice_abort.c
.Lssa___sem_byte_view_slice_6:
    movq %rbx, %rax
    call __fn___sem_view_len.r
    cmpq %rax, %r13
    jle .Lssa___sem_byte_view_slice_9
.Lssa___sem_byte_view_slice_7:
    call __fern_slice_abort.c
.Lssa___sem_byte_view_slice_9:
    movq %rbx, %rax
    call __fn___sem_view_data.r
    addq %r12, %rax
    subq %r12, %r13
    pushq %rax
    pushq %r13
    call __fn___fern_str_borrow
    addq $16, %rsp
    addq $2, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_slice
.weak __fn___sem_view_slice.r
__fn___sem_view_slice:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___sem_view_slice.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa___sem_view_slice_0:
    cmpq $0, %r12
    jge .Lssa___sem_view_slice_3
.Lssa___sem_view_slice_1:
    call __fern_slice_abort.c
.Lssa___sem_view_slice_3:
    cmpq %r12, %r13
    jge .Lssa___sem_view_slice_6
.Lssa___sem_view_slice_4:
    call __fern_slice_abort.c
.Lssa___sem_view_slice_6:
    movq %rbx, %rax
    call __fn___sem_view_len.r
    cmpq %rax, %r13
    jle .Lssa___sem_view_slice_9
.Lssa___sem_view_slice_7:
    call __fern_slice_abort.c
.Lssa___sem_view_slice_9:
    movq %rbx, %rax
    call __fn___sem_view_data.r
    movl %r12d, %esi
    imulq $8, %rsi, %rsi
    addq %rsi, %rax
    subq %r12, %r13
    pushq %rax
    pushq %r13
    call __fn___fern_str_borrow
    addq $16, %rsp
    addq $2, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_slice_wide
.weak __fn___sem_view_slice_wide.r
__fn___sem_view_slice_wide:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___sem_view_slice_wide.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa___sem_view_slice_wide_0:
    cmpq $0, %r12
    jge .Lssa___sem_view_slice_wide_3
.Lssa___sem_view_slice_wide_1:
    call __fern_slice_abort.c
.Lssa___sem_view_slice_wide_3:
    cmpq %r12, %r13
    jge .Lssa___sem_view_slice_wide_6
.Lssa___sem_view_slice_wide_4:
    call __fern_slice_abort.c
.Lssa___sem_view_slice_wide_6:
    movq %rbx, %rax
    call __fn___sem_view_len.r
    cmpq %rax, %r13
    jle .Lssa___sem_view_slice_wide_9
.Lssa___sem_view_slice_wide_7:
    call __fern_slice_abort.c
.Lssa___sem_view_slice_wide_9:
    movq %rbx, %rax
    call __fn___sem_view_data.r
    movl %r12d, %esi
    imulq $8, %rsi, %rsi
    addq %rsi, %rax
    subq %r12, %r13
    pushq %rax
    pushq %r13
    call __fn___fern_str_borrow
    addq $16, %rsp
    addq $2, %rax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_release
.weak __fn___sem_view_release.r
__fn___sem_view_release:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_view_release.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___sem_view_release_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_view_release_3
.Lssa___sem_view_release_1:
    leaq -2(%rax), %rsi
    pushq %rsi
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %rax, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___sem_view_release_3:
    call __fn___fern_arr_dec.r
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_byte_view_string
.weak __fn___sem_byte_view_string.r
__fn___sem_byte_view_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_byte_view_string.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___sem_byte_view_string_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_byte_view_string_3
.Lssa___sem_byte_view_string_1:
    leaq -2(%rax), %rsi
    leaq .SB8(%rip), %rdi
    movq %rsi, %rax
    movq %rdi, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r8
    movq %r8, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_string_3:
    call __fn___fern_string_from_bytes_u8.r
    movq %rax, %r8
    movq %r8, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_byte_view_mismatch
.weak __fn___sem_byte_view_mismatch.r
__fn___sem_byte_view_mismatch:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn___sem_byte_view_mismatch.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___sem_byte_view_mismatch_0:
    movq %rax, %r10
    andq $2, %r10
    testq %r10, %r10
    jz .Lssa___sem_byte_view_mismatch_3
.Lssa___sem_byte_view_mismatch_1:
    movq %rdi, %r10
    andq $2, %r10
    testq %r10, %r10
    jz .Lssa___sem_byte_view_mismatch_6
.Lssa___sem_byte_view_mismatch_4:
    leaq -2(%rax), %r10
    leaq -2(%rdi), %rax
    movq %r8, %rcx
    movq %rax, %rdx
    movq %r10, %rax
    movq %r9, %r8
    movq 8(%rax), %r9
    movq (%rax), %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L183_aop
    xorq %rsi, %rsi
.L183_aop:
    cmpq %r9, %rsi
    jle .L183_aok
    movq %r9, %rsi
.L183_aok:
    cmpq $0, %rcx
    jge .L183_bop
    xorq %rcx, %rcx
.L183_bop:
    cmpq %r10, %rcx
    jle .L183_bok
    movq %r10, %rcx
.L183_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L183_na
    movq %r9, %r8
.L183_na:
    cmpq %r10, %r8
    jle .L183_nb
    movq %r10, %r8
.L183_nb:
    cmpq $0, %r8
    jge .L183_nok
    xorq %r8, %r8
.L183_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L183_vec
    cmpq $8, %r8
    jge .L183_w8
    cmpq $4, %r8
    jge .L183_w4
    cmpq $2, %r8
    jge .L183_w2
    jmp .L183_tail
.L183_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L183_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L183_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L183_done
.L183_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L183_done
.L183_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L183_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L183_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L183_done
.L183_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L183_done
.L183_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L183_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L183_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L183_done
.L183_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L183_done
.L183_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L183_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L183_hit
    addq $16, %rdx
    jmp .L183_vec
.L183_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L183_done
.L183_tail:
    cmpq %r8, %rdx
    jge .L183_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L183_th
    addq $1, %rdx
    jmp .L183_tail
.L183_th:
    movq %rdx, %rax
    jmp .L183_done
.L183_eq:
    movq %r8, %rax
.L183_done:
    movq %rax, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_6:
    leaq -2(%rax), %r10
    movq %rsi, %rcx
    movq %r10, %rdx
    movq %r8, %rsi
    movq %rdi, %rax
    movq %r9, %r8
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L184_aop
    xorq %rsi, %rsi
.L184_aop:
    cmpq %r9, %rsi
    jle .L184_aok
    movq %r9, %rsi
.L184_aok:
    cmpq $0, %rcx
    jge .L184_bop
    xorq %rcx, %rcx
.L184_bop:
    cmpq %r10, %rcx
    jle .L184_bok
    movq %r10, %rcx
.L184_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L184_na
    movq %r9, %r8
.L184_na:
    cmpq %r10, %r8
    jle .L184_nb
    movq %r10, %r8
.L184_nb:
    cmpq $0, %r8
    jge .L184_nok
    xorq %r8, %r8
.L184_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L184_vec
    cmpq $8, %r8
    jge .L184_w8
    cmpq $4, %r8
    jge .L184_w4
    cmpq $2, %r8
    jge .L184_w2
    jmp .L184_tail
.L184_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L184_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L184_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L184_done
.L184_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L184_done
.L184_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L184_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L184_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L184_done
.L184_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L184_done
.L184_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L184_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L184_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L184_done
.L184_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L184_done
.L184_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L184_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L184_hit
    addq $16, %rdx
    jmp .L184_vec
.L184_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L184_done
.L184_tail:
    cmpq %r8, %rdx
    jge .L184_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L184_th
    addq $1, %rdx
    jmp .L184_tail
.L184_th:
    movq %rdx, %rax
    jmp .L184_done
.L184_eq:
    movq %r8, %rax
.L184_done:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_3:
    movq %rdi, %r10
    andq $2, %r10
    testq %r10, %r10
    jz .Lssa___sem_byte_view_mismatch_9
.Lssa___sem_byte_view_mismatch_7:
    leaq -2(%rdi), %r10
    movq %r8, %rcx
    movq %r10, %rdx
    movq %r9, %r8
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L185_aop
    xorq %rsi, %rsi
.L185_aop:
    cmpq %r9, %rsi
    jle .L185_aok
    movq %r9, %rsi
.L185_aok:
    cmpq $0, %rcx
    jge .L185_bop
    xorq %rcx, %rcx
.L185_bop:
    cmpq %r10, %rcx
    jle .L185_bok
    movq %r10, %rcx
.L185_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L185_na
    movq %r9, %r8
.L185_na:
    cmpq %r10, %r8
    jle .L185_nb
    movq %r10, %r8
.L185_nb:
    cmpq $0, %r8
    jge .L185_nok
    xorq %r8, %r8
.L185_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L185_vec
    cmpq $8, %r8
    jge .L185_w8
    cmpq $4, %r8
    jge .L185_w4
    cmpq $2, %r8
    jge .L185_w2
    jmp .L185_tail
.L185_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L185_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L185_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L185_done
.L185_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L185_done
.L185_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L185_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L185_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L185_done
.L185_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L185_done
.L185_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L185_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L185_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L185_done
.L185_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L185_done
.L185_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L185_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L185_hit
    addq $16, %rdx
    jmp .L185_vec
.L185_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L185_done
.L185_tail:
    cmpq %r8, %rdx
    jge .L185_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L185_th
    addq $1, %rdx
    jmp .L185_tail
.L185_th:
    movq %rdx, %rax
    jmp .L185_done
.L185_eq:
    movq %r8, %rax
.L185_done:
    movq %rax, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_9:
    movq %r8, %rcx
    movq %rdi, %rdx
    movq %r9, %r8
    movq (%rax), %r9
    addq $8, %rax
    movq (%rdx), %r10
    addq $8, %rdx
    cmpq $0, %rsi
    jge .L186_aop
    xorq %rsi, %rsi
.L186_aop:
    cmpq %r9, %rsi
    jle .L186_aok
    movq %r9, %rsi
.L186_aok:
    cmpq $0, %rcx
    jge .L186_bop
    xorq %rcx, %rcx
.L186_bop:
    cmpq %r10, %rcx
    jle .L186_bok
    movq %r10, %rcx
.L186_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L186_na
    movq %r9, %r8
.L186_na:
    cmpq %r10, %r8
    jle .L186_nb
    movq %r10, %r8
.L186_nb:
    cmpq $0, %r8
    jge .L186_nok
    xorq %r8, %r8
.L186_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L186_vec
    cmpq $8, %r8
    jge .L186_w8
    cmpq $4, %r8
    jge .L186_w4
    cmpq $2, %r8
    jge .L186_w2
    jmp .L186_tail
.L186_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L186_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L186_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L186_done
.L186_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L186_done
.L186_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L186_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L186_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L186_done
.L186_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L186_done
.L186_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L186_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L186_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L186_done
.L186_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L186_done
.L186_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L186_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L186_hit
    addq $16, %rdx
    jmp .L186_vec
.L186_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L186_done
.L186_tail:
    cmpq %r8, %rdx
    jge .L186_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L186_th
    addq $1, %rdx
    jmp .L186_tail
.L186_th:
    movq %rdx, %rax
    jmp .L186_done
.L186_eq:
    movq %r8, %rax
.L186_done:
    movq %rax, %r10
    movq %r10, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
_start:
    xorl %edi, %edi
    movq $1073741824, %rsi
    movl $3, %edx
    movl $0x24022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $-4096, %rax
    ja .Lfern_stack_map_failed
    movq %rax, %rbx
    movq %rax, %rdi
    movq $1048576, %rsi
    xorl %edx, %edx
    movl $10, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_stack_guard_failed
    leaq 1073741808(%rbx), %rsp
    movq %rsp, __fern_stack_top(%rip)
    xorl %edi, %edi
    movq $65536, %rsi
    movl $3, %edx
    movl $0x24022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $-4096, %rax
    ja .Lfern_signal_stack_map_failed
    subq $32, %rsp
    movq %rax, (%rsp)
    movq $0, 8(%rsp)
    movq $65536, 16(%rsp)
    movq %rsp, %rdi
    xorl %esi, %esi
    movl $131, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_signal_stack_failed
    leaq __fern_segv(%rip), %rax
    movq %rax, (%rsp)
    movq $0x0c000004, 8(%rsp)
    call .Lfern_fault_install
    testq %rax, %rax
    jnz .Lfern_fault_handler_failed
    addq $32, %rsp
    pushq %rbp
    movq %rsp, %rbp
    call __fn_main
    movq %rax, %rdi
    movq $231, %rax
    syscall
    .section .rodata
.S0: .ascii "HeaderMap"
.S1: .ascii "\027\003\007\003\003\003\003\003\007\007\013\253/\253\013\217\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\001\000\000\000\000\000\001\001\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001"
.S2: .ascii "\003\003\003\003\003\003\003\003\003\002\003\003\003\003\003\203\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
.S3: .ascii "http://"
.S4: .ascii "https://"
.S5: .ascii "!$&'()*+,;="
.S6: .ascii "HttpResponse"
.S7: .ascii "Body$BodyText"
.S8: .ascii ""
.S9: .ascii "Content-Length: "
.S10: .ascii "\r\n"
.S11: .ascii "HTTP/1.1 "
.S12: .ascii " "
.S13: .ascii "Continue"
.S14: .ascii "Switching Protocols"
.S15: .ascii "OK"
.S16: .ascii "Created"
.S17: .ascii "Accepted"
.S18: .ascii "Non-Authoritative Information"
.S19: .ascii "No Content"
.S20: .ascii "Reset Content"
.S21: .ascii "Partial Content"
.S22: .ascii "Multiple Choices"
.S23: .ascii "Moved Permanently"
.S24: .ascii "Found"
.S25: .ascii "See Other"
.S26: .ascii "Not Modified"
.S27: .ascii "Use Proxy"
.S28: .ascii "Temporary Redirect"
.S29: .ascii "Permanent Redirect"
.S30: .ascii "Bad Request"
.S31: .ascii "Unauthorized"
.S32: .ascii "Payment Required"
.S33: .ascii "Forbidden"
.S34: .ascii "Not Found"
.S35: .ascii "Method Not Allowed"
.S36: .ascii "Not Acceptable"
.S37: .ascii "Proxy Authentication Required"
.S38: .ascii "Request Timeout"
.S39: .ascii "Conflict"
.S40: .ascii "Gone"
.S41: .ascii "Length Required"
.S42: .ascii "Precondition Failed"
.S43: .ascii "Payload Too Large"
.S44: .ascii "URI Too Long"
.S45: .ascii "Unsupported Media Type"
.S46: .ascii "Range Not Satisfiable"
.S47: .ascii "Expectation Failed"
.S48: .ascii "I'm a teapot"
.S49: .ascii "Misdirected Request"
.S50: .ascii "Unprocessable Entity"
.S51: .ascii "Too Early"
.S52: .ascii "Upgrade Required"
.S53: .ascii "Precondition Required"
.S54: .ascii "Too Many Requests"
.S55: .ascii "Request Header Fields Too Large"
.S56: .ascii "Internal Server Error"
.S57: .ascii "Not Implemented"
.S58: .ascii "Bad Gateway"
.S59: .ascii "Service Unavailable"
.S60: .ascii "Gateway Timeout"
.S61: .ascii "HTTP Version Not Supported"
.S62: .ascii "Network Authentication Required"
.S63: .ascii "Status"
.S64: .ascii "content-length"
.S65: .ascii "connection"
.S66: .ascii "transfer-encoding"
.S67: .ascii ": "
.S68: .ascii "Connection: Upgrade\r\n\r\n"
.S69: .ascii "Connection: close\r\n\r\n"
.S70: .ascii "Connection: keep-alive\r\n\r\n"
.S71: .ascii "HEAD"
.S72: .ascii "0"
.S73: .ascii "1"
.S74: .ascii "2"
.S75: .ascii "3"
.S76: .ascii "4"
.S77: .ascii "5"
.S78: .ascii "6"
.S79: .ascii "7"
.S80: .ascii "8"
.S81: .ascii "9"
.S82: .ascii "10"
.S83: .ascii "11"
.S84: .ascii "12"
.S85: .ascii "13"
.S86: .ascii "14"
.S87: .ascii "15"
.S88: .ascii "16"
.S89: .ascii "17"
.S90: .ascii "18"
.S91: .ascii "19"
.S92: .ascii "20"
.S93: .ascii "21"
.S94: .ascii "22"
.S95: .ascii "23"
.S96: .ascii "24"
.S97: .ascii "25"
.S98: .ascii "26"
.S99: .ascii "27"
.S100: .ascii "28"
.S101: .ascii "29"
.S102: .ascii "30"
.S103: .ascii "31"
.S104: .ascii "32"
.S105: .ascii "33"
.S106: .ascii "34"
.S107: .ascii "35"
.S108: .ascii "36"
.S109: .ascii "37"
.S110: .ascii "38"
.S111: .ascii "39"
.S112: .ascii "40"
.S113: .ascii "41"
.S114: .ascii "42"
.S115: .ascii "43"
.S116: .ascii "44"
.S117: .ascii "45"
.S118: .ascii "46"
.S119: .ascii "47"
.S120: .ascii "48"
.S121: .ascii "49"
.S122: .ascii "50"
.S123: .ascii "51"
.S124: .ascii "52"
.S125: .ascii "53"
.S126: .ascii "54"
.S127: .ascii "55"
.S128: .ascii "56"
.S129: .ascii "57"
.S130: .ascii "58"
.S131: .ascii "59"
.S132: .ascii "60"
.S133: .ascii "61"
.S134: .ascii "62"
.S135: .ascii "63"
.S136: .ascii "64"
.S137: .ascii "65"
.S138: .ascii "66"
.S139: .ascii "67"
.S140: .ascii "68"
.S141: .ascii "69"
.S142: .ascii "70"
.S143: .ascii "71"
.S144: .ascii "72"
.S145: .ascii "73"
.S146: .ascii "74"
.S147: .ascii "75"
.S148: .ascii "76"
.S149: .ascii "77"
.S150: .ascii "78"
.S151: .ascii "79"
.S152: .ascii "80"
.S153: .ascii "81"
.S154: .ascii "82"
.S155: .ascii "83"
.S156: .ascii "84"
.S157: .ascii "85"
.S158: .ascii "86"
.S159: .ascii "87"
.S160: .ascii "88"
.S161: .ascii "89"
.S162: .ascii "90"
.S163: .ascii "91"
.S164: .ascii "92"
.S165: .ascii "93"
.S166: .ascii "94"
.S167: .ascii "95"
.S168: .ascii "96"
.S169: .ascii "97"
.S170: .ascii "98"
.S171: .ascii "99"
.S172: .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
.S173: .ascii "deflate____ReadPhase$deflate__ReadHeader"
.S174: .ascii "deflate____ReadPhase$deflate__ReadStored"
.S175: .ascii "deflate____ReadPhase$deflate__ReadCodes"
.S176: .ascii "deflate____ReadPhase$deflate__ReadCopy"
.S177: .ascii "deflate____ReadPhase$deflate__ReadEnd"
.S178: .ascii "codec__DecodeErrorKind$codec__InvalidByte"
.S179: .ascii "codec__DecodeErrorKind$codec__InvalidLength"
.S180: .ascii "codec__DecodeErrorKind$codec__InvalidPadding"
.S181: .ascii "codec__DecodeErrorKind$codec__NonZeroTrailingBits"
.S182: .ascii "GET /hello HTTP/1.1\r\nHost: bench\r\nUser-Agent: perf-bench\r\nAccept: */*\r\n\r\n"
.S183: .ascii "\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\r"
.S184: .ascii "OPTIONS"
.S185: .ascii "*"
.S186: .ascii "HTTP/1.0"
.S187: .ascii "HTTP/1.1"
.S188: .ascii "host"
.S189: .ascii "expect"
.S190: .ascii "100-continue"
.S191: .ascii ","
.S192: .ascii "chunked"
.S193: .ascii "close"
.S194: .ascii "keep-alive"
.S195: .ascii "hello "
.S196: .ascii "GET"
.S197: .ascii "Body$BodyBytes"
.S198: .ascii "Body$BodyStream"
.S199: .ascii "Body$BodyFile"
.S200: .ascii "Body$BodyChunks"
.S201: .ascii "Body$BodyFileRanges"
    .section .data.rel.ro
    .balign 8
    .quad -1
.SB0:
    .quad .S0
    .quad 9
    .quad -1
.SB1:
    .quad .S1
    .quad 352
    .quad -1
.SB2:
    .quad .S2
    .quad 352
    .quad -1
.SB3:
    .quad .S3
    .quad 7
    .quad -1
.SB4:
    .quad .S4
    .quad 8
    .quad -1
.SB5:
    .quad .S5
    .quad 11
    .quad -1
.SB6:
    .quad .S6
    .quad 12
    .quad -1
.SB7:
    .quad .S7
    .quad 13
    .quad -1
.SB8:
    .quad .S8
    .quad 0
    .quad -1
.SB9:
    .quad .S9
    .quad 16
    .quad -1
.SB10:
    .quad .S10
    .quad 2
    .quad -1
.SB11:
    .quad .S11
    .quad 9
    .quad -1
.SB12:
    .quad .S12
    .quad 1
    .quad -1
.SB13:
    .quad .S13
    .quad 8
    .quad -1
.SB14:
    .quad .S14
    .quad 19
    .quad -1
.SB15:
    .quad .S15
    .quad 2
    .quad -1
.SB16:
    .quad .S16
    .quad 7
    .quad -1
.SB17:
    .quad .S17
    .quad 8
    .quad -1
.SB18:
    .quad .S18
    .quad 29
    .quad -1
.SB19:
    .quad .S19
    .quad 10
    .quad -1
.SB20:
    .quad .S20
    .quad 13
    .quad -1
.SB21:
    .quad .S21
    .quad 15
    .quad -1
.SB22:
    .quad .S22
    .quad 16
    .quad -1
.SB23:
    .quad .S23
    .quad 17
    .quad -1
.SB24:
    .quad .S24
    .quad 5
    .quad -1
.SB25:
    .quad .S25
    .quad 9
    .quad -1
.SB26:
    .quad .S26
    .quad 12
    .quad -1
.SB27:
    .quad .S27
    .quad 9
    .quad -1
.SB28:
    .quad .S28
    .quad 18
    .quad -1
.SB29:
    .quad .S29
    .quad 18
    .quad -1
.SB30:
    .quad .S30
    .quad 11
    .quad -1
.SB31:
    .quad .S31
    .quad 12
    .quad -1
.SB32:
    .quad .S32
    .quad 16
    .quad -1
.SB33:
    .quad .S33
    .quad 9
    .quad -1
.SB34:
    .quad .S34
    .quad 9
    .quad -1
.SB35:
    .quad .S35
    .quad 18
    .quad -1
.SB36:
    .quad .S36
    .quad 14
    .quad -1
.SB37:
    .quad .S37
    .quad 29
    .quad -1
.SB38:
    .quad .S38
    .quad 15
    .quad -1
.SB39:
    .quad .S39
    .quad 8
    .quad -1
.SB40:
    .quad .S40
    .quad 4
    .quad -1
.SB41:
    .quad .S41
    .quad 15
    .quad -1
.SB42:
    .quad .S42
    .quad 19
    .quad -1
.SB43:
    .quad .S43
    .quad 17
    .quad -1
.SB44:
    .quad .S44
    .quad 12
    .quad -1
.SB45:
    .quad .S45
    .quad 22
    .quad -1
.SB46:
    .quad .S46
    .quad 21
    .quad -1
.SB47:
    .quad .S47
    .quad 18
    .quad -1
.SB48:
    .quad .S48
    .quad 12
    .quad -1
.SB49:
    .quad .S49
    .quad 19
    .quad -1
.SB50:
    .quad .S50
    .quad 20
    .quad -1
.SB51:
    .quad .S51
    .quad 9
    .quad -1
.SB52:
    .quad .S52
    .quad 16
    .quad -1
.SB53:
    .quad .S53
    .quad 21
    .quad -1
.SB54:
    .quad .S54
    .quad 17
    .quad -1
.SB55:
    .quad .S55
    .quad 31
    .quad -1
.SB56:
    .quad .S56
    .quad 21
    .quad -1
.SB57:
    .quad .S57
    .quad 15
    .quad -1
.SB58:
    .quad .S58
    .quad 11
    .quad -1
.SB59:
    .quad .S59
    .quad 19
    .quad -1
.SB60:
    .quad .S60
    .quad 15
    .quad -1
.SB61:
    .quad .S61
    .quad 26
    .quad -1
.SB62:
    .quad .S62
    .quad 31
    .quad -1
.SB63:
    .quad .S63
    .quad 6
    .quad -1
.SB64:
    .quad .S64
    .quad 14
    .quad -1
.SB65:
    .quad .S65
    .quad 10
    .quad -1
.SB66:
    .quad .S66
    .quad 17
    .quad -1
.SB67:
    .quad .S67
    .quad 2
    .quad -1
.SB68:
    .quad .S68
    .quad 23
    .quad -1
.SB69:
    .quad .S69
    .quad 21
    .quad -1
.SB70:
    .quad .S70
    .quad 26
    .quad -1
.SB71:
    .quad .S71
    .quad 4
    .quad -1
.SB72:
    .quad .S72
    .quad 1
    .quad -1
.SB73:
    .quad .S73
    .quad 1
    .quad -1
.SB74:
    .quad .S74
    .quad 1
    .quad -1
.SB75:
    .quad .S75
    .quad 1
    .quad -1
.SB76:
    .quad .S76
    .quad 1
    .quad -1
.SB77:
    .quad .S77
    .quad 1
    .quad -1
.SB78:
    .quad .S78
    .quad 1
    .quad -1
.SB79:
    .quad .S79
    .quad 1
    .quad -1
.SB80:
    .quad .S80
    .quad 1
    .quad -1
.SB81:
    .quad .S81
    .quad 1
    .quad -1
.SB82:
    .quad .S82
    .quad 2
    .quad -1
.SB83:
    .quad .S83
    .quad 2
    .quad -1
.SB84:
    .quad .S84
    .quad 2
    .quad -1
.SB85:
    .quad .S85
    .quad 2
    .quad -1
.SB86:
    .quad .S86
    .quad 2
    .quad -1
.SB87:
    .quad .S87
    .quad 2
    .quad -1
.SB88:
    .quad .S88
    .quad 2
    .quad -1
.SB89:
    .quad .S89
    .quad 2
    .quad -1
.SB90:
    .quad .S90
    .quad 2
    .quad -1
.SB91:
    .quad .S91
    .quad 2
    .quad -1
.SB92:
    .quad .S92
    .quad 2
    .quad -1
.SB93:
    .quad .S93
    .quad 2
    .quad -1
.SB94:
    .quad .S94
    .quad 2
    .quad -1
.SB95:
    .quad .S95
    .quad 2
    .quad -1
.SB96:
    .quad .S96
    .quad 2
    .quad -1
.SB97:
    .quad .S97
    .quad 2
    .quad -1
.SB98:
    .quad .S98
    .quad 2
    .quad -1
.SB99:
    .quad .S99
    .quad 2
    .quad -1
.SB100:
    .quad .S100
    .quad 2
    .quad -1
.SB101:
    .quad .S101
    .quad 2
    .quad -1
.SB102:
    .quad .S102
    .quad 2
    .quad -1
.SB103:
    .quad .S103
    .quad 2
    .quad -1
.SB104:
    .quad .S104
    .quad 2
    .quad -1
.SB105:
    .quad .S105
    .quad 2
    .quad -1
.SB106:
    .quad .S106
    .quad 2
    .quad -1
.SB107:
    .quad .S107
    .quad 2
    .quad -1
.SB108:
    .quad .S108
    .quad 2
    .quad -1
.SB109:
    .quad .S109
    .quad 2
    .quad -1
.SB110:
    .quad .S110
    .quad 2
    .quad -1
.SB111:
    .quad .S111
    .quad 2
    .quad -1
.SB112:
    .quad .S112
    .quad 2
    .quad -1
.SB113:
    .quad .S113
    .quad 2
    .quad -1
.SB114:
    .quad .S114
    .quad 2
    .quad -1
.SB115:
    .quad .S115
    .quad 2
    .quad -1
.SB116:
    .quad .S116
    .quad 2
    .quad -1
.SB117:
    .quad .S117
    .quad 2
    .quad -1
.SB118:
    .quad .S118
    .quad 2
    .quad -1
.SB119:
    .quad .S119
    .quad 2
    .quad -1
.SB120:
    .quad .S120
    .quad 2
    .quad -1
.SB121:
    .quad .S121
    .quad 2
    .quad -1
.SB122:
    .quad .S122
    .quad 2
    .quad -1
.SB123:
    .quad .S123
    .quad 2
    .quad -1
.SB124:
    .quad .S124
    .quad 2
    .quad -1
.SB125:
    .quad .S125
    .quad 2
    .quad -1
.SB126:
    .quad .S126
    .quad 2
    .quad -1
.SB127:
    .quad .S127
    .quad 2
    .quad -1
.SB128:
    .quad .S128
    .quad 2
    .quad -1
.SB129:
    .quad .S129
    .quad 2
    .quad -1
.SB130:
    .quad .S130
    .quad 2
    .quad -1
.SB131:
    .quad .S131
    .quad 2
    .quad -1
.SB132:
    .quad .S132
    .quad 2
    .quad -1
.SB133:
    .quad .S133
    .quad 2
    .quad -1
.SB134:
    .quad .S134
    .quad 2
    .quad -1
.SB135:
    .quad .S135
    .quad 2
    .quad -1
.SB136:
    .quad .S136
    .quad 2
    .quad -1
.SB137:
    .quad .S137
    .quad 2
    .quad -1
.SB138:
    .quad .S138
    .quad 2
    .quad -1
.SB139:
    .quad .S139
    .quad 2
    .quad -1
.SB140:
    .quad .S140
    .quad 2
    .quad -1
.SB141:
    .quad .S141
    .quad 2
    .quad -1
.SB142:
    .quad .S142
    .quad 2
    .quad -1
.SB143:
    .quad .S143
    .quad 2
    .quad -1
.SB144:
    .quad .S144
    .quad 2
    .quad -1
.SB145:
    .quad .S145
    .quad 2
    .quad -1
.SB146:
    .quad .S146
    .quad 2
    .quad -1
.SB147:
    .quad .S147
    .quad 2
    .quad -1
.SB148:
    .quad .S148
    .quad 2
    .quad -1
.SB149:
    .quad .S149
    .quad 2
    .quad -1
.SB150:
    .quad .S150
    .quad 2
    .quad -1
.SB151:
    .quad .S151
    .quad 2
    .quad -1
.SB152:
    .quad .S152
    .quad 2
    .quad -1
.SB153:
    .quad .S153
    .quad 2
    .quad -1
.SB154:
    .quad .S154
    .quad 2
    .quad -1
.SB155:
    .quad .S155
    .quad 2
    .quad -1
.SB156:
    .quad .S156
    .quad 2
    .quad -1
.SB157:
    .quad .S157
    .quad 2
    .quad -1
.SB158:
    .quad .S158
    .quad 2
    .quad -1
.SB159:
    .quad .S159
    .quad 2
    .quad -1
.SB160:
    .quad .S160
    .quad 2
    .quad -1
.SB161:
    .quad .S161
    .quad 2
    .quad -1
.SB162:
    .quad .S162
    .quad 2
    .quad -1
.SB163:
    .quad .S163
    .quad 2
    .quad -1
.SB164:
    .quad .S164
    .quad 2
    .quad -1
.SB165:
    .quad .S165
    .quad 2
    .quad -1
.SB166:
    .quad .S166
    .quad 2
    .quad -1
.SB167:
    .quad .S167
    .quad 2
    .quad -1
.SB168:
    .quad .S168
    .quad 2
    .quad -1
.SB169:
    .quad .S169
    .quad 2
    .quad -1
.SB170:
    .quad .S170
    .quad 2
    .quad -1
.SB171:
    .quad .S171
    .quad 2
    .quad -1
.SB172:
    .quad .S172
    .quad 200
    .quad -1
.SB173:
    .quad .S173
    .quad 40
    .quad -1
.SB174:
    .quad .S174
    .quad 40
    .quad -1
.SB175:
    .quad .S175
    .quad 39
    .quad -1
.SB176:
    .quad .S176
    .quad 38
    .quad -1
.SB177:
    .quad .S177
    .quad 37
    .quad -1
.SB178:
    .quad .S178
    .quad 41
    .quad -1
.SB179:
    .quad .S179
    .quad 43
    .quad -1
.SB180:
    .quad .S180
    .quad 44
    .quad -1
.SB181:
    .quad .S181
    .quad 49
    .quad -1
.SB182:
    .quad .S182
    .quad 73
    .quad -1
.SB183:
    .quad .S183
    .quad 354
    .quad -1
.SB184:
    .quad .S184
    .quad 7
    .quad -1
.SB185:
    .quad .S185
    .quad 1
    .quad -1
.SB186:
    .quad .S186
    .quad 8
    .quad -1
.SB187:
    .quad .S187
    .quad 8
    .quad -1
.SB188:
    .quad .S188
    .quad 4
    .quad -1
.SB189:
    .quad .S189
    .quad 6
    .quad -1
.SB190:
    .quad .S190
    .quad 12
    .quad -1
.SB191:
    .quad .S191
    .quad 1
    .quad -1
.SB192:
    .quad .S192
    .quad 7
    .quad -1
.SB193:
    .quad .S193
    .quad 5
    .quad -1
.SB194:
    .quad .S194
    .quad 10
    .quad -1
.SB195:
    .quad .S195
    .quad 6
    .quad -1
.SB196:
    .quad .S196
    .quad 3
    .quad -1
.SB197:
    .quad .S197
    .quad 14
    .quad -1
.SB198:
    .quad .S198
    .quad 15
    .quad -1
.SB199:
    .quad .S199
    .quad 13
    .quad -1
.SB200:
    .quad .S200
    .quad 15
    .quad -1
.SB201:
    .quad .S201
    .quad 19
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.K0:
    .quad 0
    .quad 3
    .quad -1
.K1:
    .quad .S0
.K1_0:
    .quad .K0
.K1_1:
    .quad .K0
    .quad 0
    .quad -1
.K2:
    .quad 256
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    .balign 8
    .quad 0
    .quad -1
.K3:
    .quad 128
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K4:
    .quad 0
    .balign 8
    .quad 2
    .quad -1
.K5:
    .quad .S7
.K5_0:
    .quad .SB8
    .quad 2
    .quad -1
.K6:
    .quad 1
    .quad 0
    .quad 6
    .quad -1
.K7:
    .quad .S6
    .quad 500
.K7_1:
    .quad .K5
.K7_2:
    .quad .K1
.K7_3:
    .quad .K1
.K7_4:
    .quad .K6
    .quad 50
    .quad -1
.K8:
    .quad 50
    .quad 100
    .quad 101
    .quad 200
    .quad 201
    .quad 202
    .quad 203
    .quad 204
    .quad 205
    .quad 206
    .quad 300
    .quad 301
    .quad 302
    .quad 303
    .quad 304
    .quad 305
    .quad 307
    .quad 308
    .quad 400
    .quad 401
    .quad 402
    .quad 403
    .quad 404
    .quad 405
    .quad 406
    .quad 407
    .quad 408
    .quad 409
    .quad 410
    .quad 411
    .quad 412
    .quad 413
    .quad 414
    .quad 415
    .quad 416
    .quad 417
    .quad 418
    .quad 421
    .quad 422
    .quad 425
    .quad 426
    .quad 428
    .quad 429
    .quad 431
    .quad 500
    .quad 501
    .quad 502
    .quad 503
    .quad 504
    .quad 505
    .quad 511
    .quad 50
    .quad -1
.K9:
    .quad 50
.K9_0:
    .quad .SB13
.K9_1:
    .quad .SB14
.K9_2:
    .quad .SB15
.K9_3:
    .quad .SB16
.K9_4:
    .quad .SB17
.K9_5:
    .quad .SB18
.K9_6:
    .quad .SB19
.K9_7:
    .quad .SB20
.K9_8:
    .quad .SB21
.K9_9:
    .quad .SB22
.K9_10:
    .quad .SB23
.K9_11:
    .quad .SB24
.K9_12:
    .quad .SB25
.K9_13:
    .quad .SB26
.K9_14:
    .quad .SB27
.K9_15:
    .quad .SB28
.K9_16:
    .quad .SB29
.K9_17:
    .quad .SB30
.K9_18:
    .quad .SB31
.K9_19:
    .quad .SB32
.K9_20:
    .quad .SB33
.K9_21:
    .quad .SB34
.K9_22:
    .quad .SB35
.K9_23:
    .quad .SB36
.K9_24:
    .quad .SB37
.K9_25:
    .quad .SB38
.K9_26:
    .quad .SB39
.K9_27:
    .quad .SB40
.K9_28:
    .quad .SB41
.K9_29:
    .quad .SB42
.K9_30:
    .quad .SB43
.K9_31:
    .quad .SB44
.K9_32:
    .quad .SB45
.K9_33:
    .quad .SB46
.K9_34:
    .quad .SB47
.K9_35:
    .quad .SB48
.K9_36:
    .quad .SB49
.K9_37:
    .quad .SB50
.K9_38:
    .quad .SB51
.K9_39:
    .quad .SB52
.K9_40:
    .quad .SB53
.K9_41:
    .quad .SB54
.K9_42:
    .quad .SB55
.K9_43:
    .quad .SB56
.K9_44:
    .quad .SB57
.K9_45:
    .quad .SB58
.K9_46:
    .quad .SB59
.K9_47:
    .quad .SB60
.K9_48:
    .quad .SB61
.K9_49:
    .quad .SB62
    .quad 100
    .quad -1
.K10:
    .quad 100
.K10_0:
    .quad .SB72
.K10_1:
    .quad .SB73
.K10_2:
    .quad .SB74
.K10_3:
    .quad .SB75
.K10_4:
    .quad .SB76
.K10_5:
    .quad .SB77
.K10_6:
    .quad .SB78
.K10_7:
    .quad .SB79
.K10_8:
    .quad .SB80
.K10_9:
    .quad .SB81
.K10_10:
    .quad .SB82
.K10_11:
    .quad .SB83
.K10_12:
    .quad .SB84
.K10_13:
    .quad .SB85
.K10_14:
    .quad .SB86
.K10_15:
    .quad .SB87
.K10_16:
    .quad .SB88
.K10_17:
    .quad .SB89
.K10_18:
    .quad .SB90
.K10_19:
    .quad .SB91
.K10_20:
    .quad .SB92
.K10_21:
    .quad .SB93
.K10_22:
    .quad .SB94
.K10_23:
    .quad .SB95
.K10_24:
    .quad .SB96
.K10_25:
    .quad .SB97
.K10_26:
    .quad .SB98
.K10_27:
    .quad .SB99
.K10_28:
    .quad .SB100
.K10_29:
    .quad .SB101
.K10_30:
    .quad .SB102
.K10_31:
    .quad .SB103
.K10_32:
    .quad .SB104
.K10_33:
    .quad .SB105
.K10_34:
    .quad .SB106
.K10_35:
    .quad .SB107
.K10_36:
    .quad .SB108
.K10_37:
    .quad .SB109
.K10_38:
    .quad .SB110
.K10_39:
    .quad .SB111
.K10_40:
    .quad .SB112
.K10_41:
    .quad .SB113
.K10_42:
    .quad .SB114
.K10_43:
    .quad .SB115
.K10_44:
    .quad .SB116
.K10_45:
    .quad .SB117
.K10_46:
    .quad .SB118
.K10_47:
    .quad .SB119
.K10_48:
    .quad .SB120
.K10_49:
    .quad .SB121
.K10_50:
    .quad .SB122
.K10_51:
    .quad .SB123
.K10_52:
    .quad .SB124
.K10_53:
    .quad .SB125
.K10_54:
    .quad .SB126
.K10_55:
    .quad .SB127
.K10_56:
    .quad .SB128
.K10_57:
    .quad .SB129
.K10_58:
    .quad .SB130
.K10_59:
    .quad .SB131
.K10_60:
    .quad .SB132
.K10_61:
    .quad .SB133
.K10_62:
    .quad .SB134
.K10_63:
    .quad .SB135
.K10_64:
    .quad .SB136
.K10_65:
    .quad .SB137
.K10_66:
    .quad .SB138
.K10_67:
    .quad .SB139
.K10_68:
    .quad .SB140
.K10_69:
    .quad .SB141
.K10_70:
    .quad .SB142
.K10_71:
    .quad .SB143
.K10_72:
    .quad .SB144
.K10_73:
    .quad .SB145
.K10_74:
    .quad .SB146
.K10_75:
    .quad .SB147
.K10_76:
    .quad .SB148
.K10_77:
    .quad .SB149
.K10_78:
    .quad .SB150
.K10_79:
    .quad .SB151
.K10_80:
    .quad .SB152
.K10_81:
    .quad .SB153
.K10_82:
    .quad .SB154
.K10_83:
    .quad .SB155
.K10_84:
    .quad .SB156
.K10_85:
    .quad .SB157
.K10_86:
    .quad .SB158
.K10_87:
    .quad .SB159
.K10_88:
    .quad .SB160
.K10_89:
    .quad .SB161
.K10_90:
    .quad .SB162
.K10_91:
    .quad .SB163
.K10_92:
    .quad .SB164
.K10_93:
    .quad .SB165
.K10_94:
    .quad .SB166
.K10_95:
    .quad .SB167
.K10_96:
    .quad .SB168
.K10_97:
    .quad .SB169
.K10_98:
    .quad .SB170
.K10_99:
    .quad .SB171
    .quad 0
    .quad -1
.K11:
    .quad 14
    .byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K12:
    .quad 5
    .byte 72, 84, 84, 80, 47
    .balign 8
    .section .bss
    .align 8
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 8
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 8
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 8
__fern_rc_underflow: .quad 0
    .align 8
__fern_map_seed: .quad 0
    .align 8
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 8
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 8
__fern_freelist_shadow: .skip 524288
    .align 8
__fern_large_freelist_shadow: .skip 20480
    .section .text
__fern_alloc:
    addq $7, %rdi
    andq $-8, %rdi
    cmpq $2048, %rdi
    ja .Lalloc_full
    leaq __fern_freelist(%rip), %rax
    addq %rax, %rdi
    movq (%rdi), %rax
    testq %rax, %rax
    jz .Lalloc_fast_miss
    pushq (%rax)
    popq (%rdi)
    ret
.Lalloc_fast_miss:
    leaq __fern_freelist(%rip), %rax
    subq %rax, %rdi
    movq __fern_heap_ptr(%rip), %rax
    testq %rax, %rax
    jz .Lalloc_full
    addq %rax, %rdi
    cmpq __fern_heap_end(%rip), %rdi
    ja .Lalloc_oom
    movq %rdi, __fern_heap_ptr(%rip)
    ret
.Lalloc_full:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rcx
    pushq %rdx
    movq %rdi, %rcx
    shrq $3, %rcx
    cmpq $65536, %rcx
    jae .Lalloc_large
    cmpq $256, %rcx
    jbe .L187
    pushq %rcx
    call __fern_capw
    popq %rcx
.L187:
    leaq 0(,%rcx,8), %rdi
    leaq __fern_freelist(%rip), %rdx
    movq (%rdx,%rcx,8), %rax
    testq %rax, %rax
    jz .Lalloc_nofl
    movq (%rax), %rdi
    movq %rdi, (%rdx,%rcx,8)
    popq %rdx
    popq %rcx
    popq %rbp
    ret
.Lalloc_large:
    movabs $17179869184, %rax
    cmpq %rax, %rdi
    ja .Lalloc_nofl
    movq %rdi, %rax
    cmpq $524288, %rax
    jae .L188
    movl $524288, %eax
.L188:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    movq %rax, %rdi
    movq %rdx, %rax
    leaq __fern_large_freelist(%rip), %rdx
    movq (%rdx,%rax,8), %rcx
    testq %rcx, %rcx
    jz .Lalloc_nofl
    movq (%rcx), %rdi
    movq %rdi, (%rdx,%rax,8)
    movq %rcx, %rax
    popq %rdx
    popq %rcx
    popq %rbp
    ret
.Lalloc_nofl:
    popq %rdx
    popq %rcx
    movq __fern_heap_ptr(%rip), %rax
    testq %rax, %rax
    jne .Lalloc_inited
    pushq %rdi
    pushq %rsi
    pushq %rcx
    pushq %rdx
    pushq %r8
    pushq %r9
    pushq %r10
    pushq %r11
    movl $0x10000000, %edi
    movabs $17179869184, %rsi
    movl $3, %edx
    movl $0x4022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $0, %rax
    jl .Lalloc_map_fail
    movq %rax, __fern_heap_ptr(%rip)
    movq %rax, __fern_heap_base(%rip)
    movabs $17179869184, %rcx
    addq %rax, %rcx
    movq %rcx, __fern_heap_end(%rip)
    popq %r11
    popq %r10
    popq %r9
    popq %r8
    popq %rdx
    popq %rcx
    popq %rsi
    popq %rdi
.Lalloc_inited:
    movq __fern_heap_ptr(%rip), %rax
    addq %rax, %rdi
    jc __fern_alloc_size_abort
    cmpq __fern_heap_end(%rip), %rdi
    ja .Lalloc_oom
    movq %rdi, __fern_heap_ptr(%rip)
    popq %rbp
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .section .text
.Lalloc_oom:
    leaq .Lmsg_oom(%rip), %rsi
    movq $43, %rdx
    movq $125, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .section .text
.Lalloc_map_fail:
    negq %rax
    subq $96, %rsp
    leaq 96(%rsp), %rdi
    movl $10, %edx
    decq %rdi
    movb %dl, (%rdi)
    movl $41, %edx
    decq %rdi
    movb %dl, (%rdi)
    movl $10, %ecx
.Lmap_fail_digit:
    xorl %edx, %edx
    divq %rcx
    addl $48, %edx
    decq %rdi
    movb %dl, (%rdi)
    testq %rax, %rax
    jne .Lmap_fail_digit
    leaq .Lmsg_map_fail(%rip), %rsi
    addq $42, %rsi
    movl $42, %ecx
.Lmap_fail_copy:
    decq %rsi
    movb (%rsi), %dl
    decq %rdi
    movb %dl, (%rdi)
    decq %rcx
    jne .Lmap_fail_copy
    movq %rdi, %rsi
    leaq 96(%rsp), %rdx
    subq %rsi, %rdx
    movq $123, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .section .text
__fern_oob_abort:
    leaq .Lmsg_arr_oob(%rip), %rsi
    movq $31, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .section .text
__fern_str_oob_abort:
    leaq .Lmsg_str_oob(%rip), %rsi
    movq $32, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .section .text
__fern_slice_abort:
    leaq .Lmsg_slice(%rip), %rsi
    movq $32, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .section .text
__fern_alloc_size_abort:
    leaq .Lmsg_alloc_size(%rip), %rsi
    movq $35, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .section .text
.Lrawfree_bad:
    pushq (%rsp)
    pushq %rbp
    movq %rsp, %rbp
__fern_free_range_abort:
    leaq .Lmsg_free_range(%rip), %rsi
    movq $41, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .section .text
.Lrawfree_double:
    pushq (%rsp)
    pushq %rbp
    movq %rsp, %rbp
__fern_double_free_abort:
    leaq .Lmsg_double_free(%rip), %rsi
    movq $45, %rdx
    jmp __fern_abort_134
__fern_arr_box:
    cmpq $268435455, %rdi
    ja __fern_alloc_size_abort.c
    pushq %rdi
    leaq 24(,%rdi,8), %rdi
    cmpq $2048, %rdi
    ja .Larrbox_alloc
    leaq __fern_freelist(%rip), %rax
    addq %rax, %rdi
    movq (%rdi), %rax
    testq %rax, %rax
    jz .Larrbox_miss
    pushq (%rax)
    popq (%rdi)
.Larrbox_hdr:
    popq %rdi
    movq %rdi, (%rax)
    movq $1, 8(%rax)
    movq %rdi, 16(%rax)
    addq $16, %rax
    ret
.Larrbox_miss:
    leaq __fern_freelist(%rip), %rax
    subq %rax, %rdi
.Larrbox_alloc:
    call __fern_alloc
    jmp .Larrbox_hdr
__fern_str_box:
    pushq %rsi
    pushq %rdi
    movq $24, %rdi
    call __fern_alloc
    movq $1, (%rax)
    popq %rdi
    popq %rsi
    movq %rdi, 8(%rax)
    movq %rsi, 16(%rax)
    addq $8, %rax
    ret
__fern_str_box_hdr:
    leaq -24(%rdi), %rax
    movl $1, (%rax)
    movl $1934589965, 4(%rax)
    movq %rdi, 8(%rax)
    movq %rsi, 16(%rax)
    addq $8, %rax
    ret
__fn___fern_rc_inc:
    movq 8(%rsp), %rax
    testb $1, %al
    jnz .Lshrcinc_ret
    cmpq $0x10000, %rax
    jb .Lshrcinc_ret
    andq $-3, %rax
    movl -8(%rax), %ecx
    testl %ecx, %ecx
    js .Lshrcinc_ret
    addl $1, %ecx
    movl %ecx, -8(%rax)
.Lshrcinc_ret:
    movq 8(%rsp), %rax
    ret
__fn___fern_rc_underflow_count:
    movl __fern_rc_underflow(%rip), %eax
    ret
__fern_large_push:
    movabs $17179869184, %rax
    cmpq %rax, %rsi
    ja .Llpush_ret
    movq %rsi, %rax
    cmpq $524288, %rax
    jae .L189
    movl $524288, %eax
.L189:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    movq %rdx, %rax
    leaq __fern_large_freelist(%rip), %rdx
    movq (%rdx,%rax,8), %rcx
    cmpq %r8, %rcx
    je .Lrawfree_double
    movq %rcx, (%r8)
    movq %r8, (%rdx,%rax,8)
.Llpush_ret:
    ret
__fern_capw:
    pushq %rax
    pushq %rcx
    pushq %rdx
    movq 32(%rsp), %rax
    cmpq $256, %rax
    jbe .Lcapw_ret
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    cmpq $65536, %rax
    jb .Lcapw_store
    movl $65535, %eax
.Lcapw_store:
    movq %rax, 32(%rsp)
.Lcapw_ret:
    popq %rdx
    popq %rcx
    popq %rax
    ret
__fern_raw_free:
    testq %rdi, %rdi
    jz .Lrawfree_ret
    cmpq __fern_heap_base(%rip), %rdi
    jb .Lrawfree_bad
    cmpq __fern_heap_end(%rip), %rdi
    jae .Lrawfree_bad
    addq $7, %rsi
    andq $-8, %rsi
    cmpq $8, %rsi
    jb .Lrawfree_ret
    movq %rsi, %rcx
    shrq $3, %rcx
    cmpq $65536, %rcx
    jae .Lrawfree_large
    cmpq $256, %rcx
    jbe .L190
    pushq %rcx
    call __fern_capw
    popq %rcx
.L190:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rdx
    cmpq %rdi, %rdx
    je .Lrawfree_double
    movq %rdx, (%rdi)
    movq %rdi, (%r8,%rcx,8)
.Lrawfree_ret:
    ret
.Lrawfree_large:
    movq %rdi, %r8
    call __fern_large_push
    ret
__fn___fern_arr_dec:
    movq 8(%rsp), %rax
__fn___fern_arr_dec.r:
    cmpq $0x10000, %rax
    jb .Larrdec_ret
__fn___fern_arr_dec.u:
    movl -8(%rax), %ecx
    cmpl $1, %ecx
    jne .Larrdec_shared
    movl $0, -8(%rax)
    movl -16(%rax), %ecx
    addq $3, %rcx
    leaq -16(%rax), %rdx
    cmpq $256, %rcx
    ja .Larrdec_big
.Larrdec_push:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rdi
    movq %rdi, (%rdx)
    movq %rdx, (%r8,%rcx,8)
.Larrdec_ret:
    ret
.Larrdec_shared:
    testl %ecx, %ecx
    js .Larrdec_ret
    jg .Larrdec_dec
    incl __fern_rc_underflow(%rip)
    jmp .Larrdec_ret
.Larrdec_dec:
    subl $1, %ecx
    movl %ecx, -8(%rax)
    ret
.Larrdec_big:
    cmpq $65536, %rcx
    jae .Larrdec_large
    pushq %rcx
    call __fern_capw
    popq %rcx
    jmp .Larrdec_push
.Larrdec_large:
    leaq -16(%rax), %r8
    leaq 0(,%rcx,8), %rsi
    call __fern_large_push
    ret
__fn___fern_str_free:
    movq 8(%rsp), %rax
__fn___fern_str_free.r:
    testb $1, %al
    jnz .Lstrfree_ret
    cmpq $0x10000, %rax
    jb .Lstrfree_ret
__fn___fern_str_free.u:
    movl -8(%rax), %ecx
    cmpl $1, %ecx
    jne .Lstrfree_shared
    movl -4(%rax), %edx
    cmpl $1934589965, %edx
    je .Lstrfree_fused
    cmpl $1196576599, %edx
    je .Lstrfree_grown
    cmpl $1112494674, %edx
    je .Lstrfree_box
    movq (%rax), %rcx
    movq 8(%rax), %rdx
    movq __fern_heap_base(%rip), %rsi
    cmpq %rsi, %rcx
    jb .Lstrfree_box
    cmpq __fern_heap_end(%rip), %rcx
    jae .Lstrfree_box
    testq %rdx, %rdx
    jle .Lstrfree_box
    addq $7, %rdx
    shrq $3, %rdx
    cmpq $65536, %rdx
    jae .Lstrfree_large
    cmpq $256, %rdx
    jbe .L191
    pushq %rdx
    call __fern_capw
    popq %rdx
.L191:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rdx,8), %rsi
    movq %rsi, (%rcx)
    movq %rcx, (%r8,%rdx,8)
.Lstrfree_box:
    movl $0, -8(%rax)
    leaq -8(%rax), %rdx
    leaq __fern_freelist(%rip), %r8
    movq 24(%r8), %rsi
    movq %rsi, (%rdx)
    movq %rdx, 24(%r8)
    jmp .Lstrfree_ret
.Lstrfree_large:
    movq %rcx, %r8
    leaq 0(,%rdx,8), %rsi
    pushq %rax
    call __fern_large_push
    popq %rax
    jmp .Lstrfree_box
.Lstrfree_grown:
    movq -16(%rax), %rdx
    leaq -16(%rax), %rcx
    jmp .Lstrfree_block
.Lstrfree_fused:
    movq 8(%rax), %rdx
    addq $7, %rdx
    shrq $3, %rdx
    addq $3, %rdx
    leaq -8(%rax), %rcx
.Lstrfree_block:
    movl $0, -8(%rax)
    cmpq $256, %rdx
    ja .Lstrfree_fused_big
.Lstrfree_fused_push:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rdx,8), %rsi
    movq %rsi, (%rcx)
    movq %rcx, (%r8,%rdx,8)
    jmp .Lstrfree_ret
.Lstrfree_fused_big:
    cmpq $65536, %rdx
    jae .Lstrfree_fused_large
    pushq %rdx
    call __fern_capw
    popq %rdx
    jmp .Lstrfree_fused_push
.Lstrfree_fused_large:
    movq %rcx, %r8
    leaq 0(,%rdx,8), %rsi
    call __fern_large_push
    jmp .Lstrfree_ret
.Lstrfree_shared:
    testl %ecx, %ecx
    js .Lstrfree_ret
    je .Lstrfree_uf
    subl $1, %ecx
    movl %ecx, -8(%rax)
    ret
.Lstrfree_uf:
    incl __fern_rc_underflow(%rip)
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    movq 8(%rsp), %rax
    testb $1, %al
    jnz .Lstrvfree_ret
    cmpq $0x10000, %rax
    jb .Lstrvfree_ret
    movl -8(%rax), %ecx
    testl %ecx, %ecx
    js .Lstrvfree_view
    jmp __fn___fern_str_free
.Lstrvfree_view:
    leaq -8(%rax), %rdx
    movq __fern_heap_base(%rip), %rsi
    cmpq %rsi, %rdx
    jb .Lstrvfree_ret
    cmpq __fern_heap_end(%rip), %rdx
    jae .Lstrvfree_ret
    movl $0, -8(%rax)
    leaq __fern_freelist(%rip), %r8
    movq 24(%r8), %rsi
    movq %rsi, (%rdx)
    movq %rdx, 24(%r8)
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_str_arr_free.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
.Lssa___fern_str_arr_free_0:
    cmpq $65536, %rbx
    jb .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    leaq -8(%rbx), %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    movslq (%rbx), %r12
.Lssa___fern_str_arr_free_4:
    xorl %esi, %esi
.Lssa___fern_str_arr_free_15:
    cmpq %r12, %rsi
    jge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    leaq 1(%rsi), %r13
    movq (%rbx,%r13,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    movq %r13, %rsi
    cmpq %r12, %rsi
    jl .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___fern_rc_is_unique:
    movq 8(%rsp), %rcx
    movq $0, %rax
    testb $1, %cl
    jnz .Lshuniq_ret
    cmpq $0x10000, %rcx
    jb .Lshuniq_ret
    andq $-3, %rcx
    movl -8(%rcx), %edx
    testl %edx, %edx
    js .Lshuniq_ret
    cmpl $1, %edx
    jne .Lshuniq_ret
    movq $1, %rax
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    movq 8(%rsp), %rax
__fn___fern_arr_inc_elems.r:
    cmpq $0x10000, %rax
    jb .Laie_ret
    movl -8(%rax), %ecx
    testl %ecx, %ecx
    js .Laie_ret
    movq (%rax), %rsi
    xorl %edx, %edx
.Laie_loop:
    cmpq %rsi, %rdx
    jge .Laie_ret
    movq 8(%rax,%rdx,8), %rcx
    incq %rdx
    testb $1, %cl
    jnz .Laie_loop
    cmpq $0x10000, %rcx
    jb .Laie_loop
    andq $-3, %rcx
    movl -8(%rcx), %edi
    testl %edi, %edi
    js .Laie_loop
    addl $1, -8(%rcx)
    jmp .Laie_loop
.Laie_ret:
    ret
__fn___fern_str_grow:
    movq 16(%rsp), %r8
    movq 8(%rsp), %rdx
    movq 8(%rdx), %rsi
    movq (%rdx), %rdx
    jmp .Lsg_body
__fn___fern_str_grow_range:
    movq 32(%rsp), %r8
    movslq 16(%rsp), %rax
    movslq 8(%rsp), %rsi
    movq 24(%rsp), %rdx
    testq %rax, %rax
    js .Lsg_out
    cmpq 8(%rdx), %rsi
    jg .Lsg_out
    subq %rax, %rsi
    js .Lsg_out
    movq (%rdx), %rdx
    addq %rax, %rdx
    jmp .Lsg_body
.Lsg_out:
    xorl %eax, %eax
    ret
.Lsg_body:
    xorl %eax, %eax
    testb $1, %r8b
    jnz .Lsg_ret
    cmpq $0x10000, %r8
    jb .Lsg_ret
    movl -8(%r8), %ecx
    cmpl $1, %ecx
    jne .Lsg_ret
    movq 8(%r8), %rcx
    leaq (%rcx,%rsi), %rdi
    cmpq $0x7fffffff, %rdi
    ja .Lsg_ret
    cmpl $1196576599, -4(%r8)
    jne .Lsg_fused
    leaq 39(%rdi), %r10
    shrq $3, %r10
    cmpq -16(%r8), %r10
    ja .Lsg_ret
    jmp .Lsg_copy
.Lsg_fused:
    cmpl $1934589965, -4(%r8)
    jne .Lsg_ret
    leaq 31(%rcx), %r9
    shrq $3, %r9
    leaq 31(%rdi), %r10
    shrq $3, %r10
    cmpq %r9, %r10
    je .Lsg_copy
    cmpq $65536, %r9
    jae .Lsg_large
    pushq %r9
    call __fern_capw
    popq %r11
    cmpq %r11, %r10
    ja .Lsg_ret
    jmp .Lsg_fits
.Lsg_large:
    cmpq $0x8000000, %r10
    ja .Lsg_ret
    leaq 0(,%r9,8), %rax
    pushq %rcx
    pushq %rdx
    cmpq $524288, %rax
    jae .L192
    movl $524288, %eax
.L192:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    popq %rdx
    popq %rcx
    shrq $3, %rax
    cmpq %rax, %r10
    movl $0, %eax
    ja .Lsg_ret
.Lsg_fits:
.Lsg_copy:
    movq %rdi, 8(%r8)
    movq (%r8), %rdi
    addq %rcx, %rdi
    movq %rsi, %rcx
    movq %rdx, %rsi
    rep movsb
    movl $1, %eax
.Lsg_ret:
    ret
__fn___fern_str_grow_fresh:
    movq 16(%rsp), %r8
    movq 8(%rsp), %rdx
    movq 8(%rdx), %rsi
    movq (%rdx), %rdx
    jmp .Lsgf_body
__fn___fern_str_grow_fresh_range:
    movq 32(%rsp), %r8
    movslq 16(%rsp), %rax
    movslq 8(%rsp), %rsi
    movq 24(%rsp), %rdx
    testq %rax, %rax
    js __fern_slice_abort.c
    cmpq 8(%rdx), %rsi
    jg __fern_slice_abort.c
    subq %rax, %rsi
    js __fern_slice_abort.c
    movq (%rdx), %rdx
    addq %rax, %rdx
.Lsgf_body:
    movq 8(%r8), %rcx
    leaq (%rcx,%rsi), %rdi
    cmpq $0x7fffffff, %rdi
    ja __fern_alloc_size_abort.c
    leaq 39(%rdi), %r9
    shrq $3, %r9
    leaq 31(%rcx), %r10
    shrq $3, %r10
    addq %r10, %r10
    cmpq %r9, %r10
    jae .Lsgf_class
    movq %r9, %r10
.Lsgf_class:
    cmpq $65536, %r10
    jae .Lsgf_large
    pushq %r10
    call __fern_capw
    popq %r10
    jmp .Lsgf_alloc
.Lsgf_large:
    cmpq $0x8000000, %r10
    ja .Lsgf_alloc
    leaq 0(,%r10,8), %rax
    pushq %rcx
    pushq %rdx
    cmpq $524288, %rax
    jae .L193
    movl $524288, %eax
.L193:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    popq %rdx
    popq %rcx
    shrq $3, %rax
    movq %rax, %r10
.Lsgf_alloc:
    leaq 0(,%r10,8), %rdi
    call __fern_alloc
    movq %r10, (%rax)
    movl $1, 8(%rax)
    movl $1196576599, 12(%rax)
    leaq 32(%rax), %rdi
    movq %rdi, 16(%rax)
    leaq (%rcx,%rsi), %r9
    movq %r9, 24(%rax)
    movq %rsi, %r9
    movq (%r8), %rsi
    rep movsb
    movq %rdx, %rsi
    movq %r9, %rcx
    rep movsb
    addq $16, %rax
    ret
__fn___fern_str_borrow:
    movq $24, %rdi
    call __fern_alloc
    movl $1, (%rax)
    movl $1112494674, 4(%rax)
    movq 16(%rsp), %rcx
    movq %rcx, 8(%rax)
    movq 8(%rsp), %rcx
    movq %rcx, 16(%rax)
    addq $8, %rax
    ret
__fn___fern_alloc_reuse:
    movq 16(%rsp), %rax
    movq 8(%rsp), %rsi
__fn___fern_alloc_reuse.r:
    testq %rax, %rax
    jz .Lsarelo_fresh
    cmpq %rsi, -16(%rax)
    je .Lsarelo_ret
    pushq %rsi
    call __fn___fern_arr_dec.r
    popq %rsi
.Lsarelo_fresh:
    movq %rsi, %rdi
    jmp __fern_arr_box
.Lsarelo_ret:
    ret
__fern_memcpy:
    movq %rdi, %rax
    cmpq $8, %rdx
    jb .Lmcp_lt8
    cmpq $16, %rdx
    jb .Lmcp_8_15
    cmpq $32, %rdx
    jbe .Lmcp_16_32
    leaq -32(%rdi,%rdx), %r8
    leaq -32(%rsi,%rdx), %r9
.Lmcp_bulk:
    movdqu (%rsi), %xmm0
    movdqu 16(%rsi), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, 16(%rdi)
    addq $32, %rsi
    addq $32, %rdi
    cmpq %r8, %rdi
    jb .Lmcp_bulk
    movdqu (%r9), %xmm0
    movdqu 16(%r9), %xmm1
    movdqu %xmm0, (%r8)
    movdqu %xmm1, 16(%r8)
    ret
.Lmcp_16_32:
    movdqu (%rsi), %xmm0
    movdqu -16(%rsi,%rdx), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, -16(%rdi,%rdx)
    ret
.Lmcp_8_15:
    movq (%rsi), %r8
    movq -8(%rsi,%rdx), %r9
    movq %r8, (%rdi)
    movq %r9, -8(%rdi,%rdx)
    ret
.Lmcp_lt8:
    cmpq $4, %rdx
    jb .Lmcp_lt4
    movl (%rsi), %r8d
    movl -4(%rsi,%rdx), %r9d
    movl %r8d, (%rdi)
    movl %r9d, -4(%rdi,%rdx)
    ret
.Lmcp_lt4:
    testq %rdx, %rdx
    je .Lmcp_done
    movzbq (%rsi), %r8
    movzbq -1(%rsi,%rdx), %r9
    movb %r8b, (%rdi)
    movb %r9b, -1(%rdi,%rdx)
    cmpq $3, %rdx
    jb .Lmcp_done
    movzbq 1(%rsi), %r8
    movb %r8b, 1(%rdi)
.Lmcp_done:
    ret
__fern_buf_new:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rbx
    pushq %r12
    movq %rdi, %rbx
    cmpq $16, %rbx
    jae .Lbufnew_cap
    movq $16, %rbx
.Lbufnew_cap:
    movq $32, %rdi
    call __fern_alloc
    movq %rax, %r12
    movq %rbx, %rdi
    call __fern_alloc
    movq %rax, (%r12)
    movq $0, 8(%r12)
    movq %rbx, 16(%r12)
    movq %rbx, 24(%r12)
    movq %r12, %rax
    popq %r12
    popq %rbx
    popq %rbp
    ret
__fern_buf_reserve:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rdi, %rbx
    movq %rsi, %r12
    movq 16(%rbx), %r13
    testq %r13, %r13
    jnz .Lbufres_dbl
    movq 24(%rbx), %r13
    testq %r13, %r13
    jnz .Lbufres_dbl
    movq $64, %r13
.Lbufres_dbl:
    cmpq %r12, %r13
    jae .Lbufres_alloc
    addq %r13, %r13
    jmp .Lbufres_dbl
.Lbufres_alloc:
    movq %r13, %rdi
    call __fern_alloc
    movq %rax, %r14
    movq 8(%rbx), %rcx
    testq %rcx, %rcx
    jz .Lbufres_nocopy
    movq (%rbx), %rsi
    movq %r14, %rdx
    movq %rdx, %rdi
    movq %rcx, %rdx
    call __fern_memcpy
.Lbufres_nocopy:
    movq (%rbx), %rcx
    testq %rcx, %rcx
    jz .Lbufres_store
    movq 16(%rbx), %rdx
    addq $7, %rdx
    shrq $3, %rdx
    cmpq $65536, %rdx
    jae .Lbufres_old_large
    cmpq $256, %rdx
    jbe .L194
    pushq %rdx
    call __fern_capw
    popq %rdx
.L194:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rdx,8), %rsi
    movq %rsi, (%rcx)
    movq %rcx, (%r8,%rdx,8)
    jmp .Lbufres_old_done
.Lbufres_old_large:
    movq %rcx, %r8
    leaq 0(,%rdx,8), %rsi
    call __fern_large_push
.Lbufres_old_done:
.Lbufres_store:
    movq %r14, (%rbx)
    movq %r13, 16(%rbx)
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    ret
__fern_buf_push:
    movslq 8(%rsi), %rcx
    testq %rcx, %rcx
    jz .Lbufrange_done
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r8
    cmpq 16(%rdi), %r8
    ja .Lbufpush_grow
    movq %r8, 8(%rdi)
    movq (%rsi), %rsi
    movq (%rdi), %rdi
    addq %rax, %rdi
    jmp .Lbufrange_tail
.Lbufpush_grow:
    xorl %edx, %edx
    jmp .Lbufrange_grow
__fern_buf_push_range:
    movslq %edx, %rdx
    movslq %ecx, %rcx
    testq %rdx, %rdx
    js __fern_slice_abort.c
    cmpq 8(%rsi), %rcx
    jg __fern_slice_abort.c
    subq %rdx, %rcx
    js __fern_slice_abort.c
    jz .Lbufrange_done
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r8
    cmpq 16(%rdi), %r8
    ja .Lbufrange_grow
.Lbufrange_copy:
    movq %r8, 8(%rdi)
    movq (%rsi), %rsi
    addq %rdx, %rsi
    movq (%rdi), %rdi
    addq %rax, %rdi
.Lbufrange_tail:
    cmpq $8, %rcx
    jae .Lbufrange_c8
    cmpq $4, %rcx
    jae .Lbufrange_c4
    cmpq $2, %rcx
    jae .Lbufrange_c2
    movzbl (%rsi), %r8d
    movb %r8b, (%rdi)
    ret
.Lbufrange_c2:
    movzwl (%rsi), %r8d
    movzwl -2(%rsi,%rcx), %r9d
    movw %r8w, (%rdi)
    movw %r9w, -2(%rdi,%rcx)
    ret
.Lbufrange_c4:
    movl (%rsi), %r8d
    movl -4(%rsi,%rcx), %r9d
    movl %r8d, (%rdi)
    movl %r9d, -4(%rdi,%rcx)
    ret
.Lbufrange_c8:
    cmpq $16, %rcx
    ja .Lbufrange_long
    movq (%rsi), %r8
    movq -8(%rsi,%rcx), %r9
    movq %r8, (%rdi)
    movq %r9, -8(%rdi,%rcx)
    ret
.Lbufrange_long:
    movq %rcx, %rdx
    jmp __fern_memcpy
.Lbufrange_grow:
    pushq %rdi
    pushq %rsi
    pushq %rdx
    pushq %rcx
    subq $8, %rsp
    movq %r8, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %rcx
    popq %rdx
    popq %rsi
    popq %rdi
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r8
    jmp .Lbufrange_copy
.Lbufrange_done:
    ret
__fern_buf_push_byte:
    movq 8(%rdi), %rax
    leaq 1(%rax), %rcx
    cmpq 16(%rdi), %rcx
    ja .Lbufbyte_grow
.Lbufbyte_fits:
    movq (%rdi), %rdx
    movb %sil, (%rdx,%rax)
    movq %rcx, 8(%rdi)
    ret
.Lbufbyte_grow:
    pushq %rdi
    pushq %rsi
    subq $8, %rsp
    movq %rcx, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %rsi
    popq %rdi
    movq 8(%rdi), %rax
    leaq 1(%rax), %rcx
    jmp .Lbufbyte_fits
__fern_buf_push_u64:
    movq 8(%rdi), %rax
    leaq 8(%rax), %rcx
    cmpq 16(%rdi), %rcx
    ja .Lbufu64_grow
.Lbufu64_fits:
    movq (%rdi), %rdx
    movq %rsi, (%rdx,%rax)
    movq %rcx, 8(%rdi)
    ret
.Lbufu64_grow:
    pushq %rdi
    pushq %rsi
    subq $8, %rsp
    movq %rcx, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %rsi
    popq %rdi
    movq 8(%rdi), %rax
    leaq 8(%rax), %rcx
    jmp .Lbufu64_fits
__fern_buf_push_decimal:
    subq $40, %rsp
    leaq 32(%rsp), %r8
    movq %rsi, %rax
    leaq .Ldecimal_pairs(%rip), %r11
    movabsq $2951479051793528259, %r10
.Ldecimal_loop:
    cmpq $100, %rax
    jb .Ldecimal_tail
    movq %rax, %r9
    shrq $2, %rax
    mulq %r10
    shrq $2, %rdx
    imulq $100, %rdx, %rax
    subq %rax, %r9
    movzwl (%r11,%r9,2), %eax
    subq $2, %r8
    movw %ax, (%r8)
    movq %rdx, %rax
    jmp .Ldecimal_loop
.Ldecimal_tail:
    cmpq $10, %rax
    jb .Ldecimal_one
    movzwl (%r11,%rax,2), %eax
    subq $2, %r8
    movw %ax, (%r8)
    jmp .Ldecimal_copy
.Ldecimal_one:
    addl $48, %eax
    subq $1, %r8
    movb %al, (%r8)
.Ldecimal_copy:
    leaq 32(%rsp), %rcx
    subq %r8, %rcx
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r9
    cmpq 16(%rdi), %r9
    ja .Ldecimal_grow
.Ldecimal_fits:
    movq %r9, 8(%rdi)
    movq (%rdi), %rdx
    addq %rax, %rdx
    cmpq $8, %rcx
    jae .Ldecimal_c8
    cmpq $4, %rcx
    jae .Ldecimal_c4
    cmpq $2, %rcx
    jae .Ldecimal_c2
    movzbl (%r8), %eax
    movb %al, (%rdx)
    addq $40, %rsp
    ret
.Ldecimal_c2:
    movzwl (%r8), %eax
    movzwl -2(%r8,%rcx), %r9d
    movw %ax, (%rdx)
    movw %r9w, -2(%rdx,%rcx)
    addq $40, %rsp
    ret
.Ldecimal_c4:
    movl (%r8), %eax
    movl -4(%r8,%rcx), %r9d
    movl %eax, (%rdx)
    movl %r9d, -4(%rdx,%rcx)
    addq $40, %rsp
    ret
.Ldecimal_c8:
    movq (%r8), %rax
    movq 8(%r8), %r10
    movq -8(%r8,%rcx), %r9
    movq %rax, (%rdx)
    cmpq $16, %rcx
    jbe .Ldecimal_c8_tail
    movq %r10, 8(%rdx)
.Ldecimal_c8_tail:
    movq %r9, -8(%rdx,%rcx)
    addq $40, %rsp
    ret
.Ldecimal_grow:
    pushq %rdi
    pushq %rcx
    pushq %r8
    subq $8, %rsp
    movq %r9, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %r8
    popq %rcx
    popq %rdi
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r9
    jmp .Ldecimal_fits
    .section .rodata
.Ldecimal_pairs:
    .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
    .section .text
__fern_buf_len:
    movq 8(%rdi), %rax
    ret
__fern_buf_clear:
    movq $0, 8(%rdi)
    xorl %eax, %eax
    ret
__fern_buf_take:
    pushq %rdi
    call __fn___fern_buf_take_text
    addq $8, %rsp
    ret
__fn___fern_buf_text_part:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_buf_text_part.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
.Lssa___fern_buf_text_part_0:
    movzbl (%rax,%rsi), %r8d
    cmpq $128, %r8
    jge .Lssa___fern_buf_text_part_18
.Lssa___fern_buf_text_part_20:
    movl $1, %eax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_text_part_18:
    cmpq $194, %r8
    jl .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_17:
    cmpq $223, %r8
    jg .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_16:
    movl $2, %r9d
    jmp .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_15:
    cmpq $224, %r8
    jl .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_14:
    cmpq $239, %r8
    jg .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_13:
    movl $3, %r9d
    jmp .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_12:
    cmpq $240, %r8
    jl .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_11:
    cmpq $244, %r8
    jg .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_10:
    movl $4, %r9d
    jmp .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_9:
    xorl %r9d, %r9d
.Lssa___fern_buf_text_part_8:
.Lssa___fern_buf_text_part_7:
    subq %rsi, %rdi
    movslq %edi, %rdi
    movl $1, %r10d
.Lssa___fern_buf_text_part_52:
    cmpq %r9, %r10
    jge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_67:
    cmpq %rdi, %r10
    jge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_66:
    leaq (%rsi,%r10), %rcx
    movslq %ecx, %rbx
    movzbl (%rax,%rbx), %r12d
    cmpq $128, %r12
    jl .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_65:
    cmpq $191, %r12
    jg .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_63:
    cmpq $1, %r10
    jne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_62:
    cmpq $224, %r8
    jne .Lssa___fern_buf_text_part_60
.Lssa___fern_buf_text_part_61:
    cmpq $160, %r12
    jl .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_60:
    cmpq $237, %r8
    jne .Lssa___fern_buf_text_part_58
.Lssa___fern_buf_text_part_59:
    cmpq $159, %r12
    jg .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_58:
    cmpq $240, %r8
    jne .Lssa___fern_buf_text_part_56
.Lssa___fern_buf_text_part_57:
    cmpq $144, %r12
    jl .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_56:
    cmpq $244, %r8
    jne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_55:
    cmpq $143, %r12
    jg .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_53:
    addq $1, %r10
    cmpq %r9, %r10
    jl .Lssa___fern_buf_text_part_67
.Lssa___fern_buf_text_part_4:
    xorl %edi, %edi
    subq %r10, %rdi
    movslq %edi, %rdi
    cmpq %r9, %r10
    movq %r10, %rax
    cmovneq %rdi, %rax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___fern_buf_take_text:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_buf_take_text.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $72, %rsp
    movq %rax, -48(%rbp)
.Lssa___fern_buf_take_text_0:
    movq -48(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $0, %rsi
    jl .Lssa___fern_buf_take_text_16
.Lssa___fern_buf_take_text_17:
    cmpq $2147483647, %rsi
    jle .Lssa___fern_buf_take_text_14
.Lssa___fern_buf_take_text_16:
    movq $-1, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    xorl %edi, %edi
    movq %rax, %r11
    movq %rdi, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    movq %rax, %r8
    movq %r8, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_14:
    movslq %esi, %r12
    cmpq $0, %r12
    jne .Lssa___fern_buf_take_text_11
.Lssa___fern_buf_take_text_13:
    leaq .SB8(%rip), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_11:
    movq -48(%rbp), %r11
    movq 0(%r11), %r11
    movq %r11, -56(%rbp)
    movabsq $9259542123273814144, %r11
    movq %r11, -64(%rbp)
.Lssa___fern_buf_take_text_10:
    movq %rsi, %r15
    xorl %ebx, %ebx
    xorl %r14d, %r14d
.Lssa___fern_buf_take_text_30:
    cmpq %r12, %rbx
    jge .Lssa___fern_buf_take_text_9
.Lssa___fern_buf_take_text_40:
    movq %r12, %rsi
    subq %rbx, %rsi
    movslq %esi, %rsi
    cmpq $8, %rsi
    jl .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_39:
    movq -56(%rbp), %rsi
    addq %rbx, %rsi
    movq 0(%rsi), %r8
    andq -64(%rbp), %r8
    cmpq $0, %r8
    jne .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_38:
    leaq 8(%rbx), %r8
    movslq %r8d, %rbx
    cmpq %r12, %rbx
    jge .Lssa___fern_buf_take_text_9
    jmp .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_34:
    movq -56(%rbp), %rax
    movq %rbx, %rsi
    movq %r12, %rdi
    call __fn___fern_buf_text_part.r
    cmpq $0, %rax
    jge .Lssa___fern_buf_take_text_32
.Lssa___fern_buf_take_text_33:
    leaq 3(%rax), %r8
    movslq %r8d, %r8
    addq %r15, %r8
    movq %rbx, %rsi
    subq %rax, %rsi
    movslq %esi, %rsi
    movq %r8, %r15
    movq %rsi, %rbx
    movl $1, %r14d
    jmp .Lssa___fern_buf_take_text_30
.Lssa___fern_buf_take_text_32:
    addq %rax, %rbx
    movslq %ebx, %rbx
.Lssa___fern_buf_take_text_31:
    cmpq %r12, %rbx
    jl .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_9:
    cmpq $2147483647, %r15
    jle .Lssa___fern_buf_take_text_6
.Lssa___fern_buf_take_text_8:
    movq $-1, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    xorl %edi, %edi
    movq %rax, %r11
    movq %rdi, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    movq %rax, %rsi
    movq %rsi, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_6:
    movslq %r15d, %r11
    movq %r11, -72(%rbp)
    movq -72(%rbp), %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %rbx
    testq %r14, %r14
    jz .Lssa___fern_buf_take_text_2
.Lssa___fern_buf_take_text_5:
.Lssa___fern_buf_take_text_4:
    xorl %r14d, %r14d
    xorl %r15d, %r15d
    xorl %r13d, %r13d
.Lssa___fern_buf_take_text_70:
    cmpq %r12, %r14
    jge .Lssa___fern_buf_take_text_3
.Lssa___fern_buf_take_text_80:
    movq %r12, %rsi
    subq %r14, %rsi
    movslq %esi, %rsi
    cmpq $8, %rsi
    jl .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_79:
    movq -56(%rbp), %rsi
    addq %r14, %rsi
    movq 0(%rsi), %rdi
    andq -64(%rbp), %rdi
    cmpq $0, %rdi
    jne .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_78:
    leaq 8(%r14), %rdi
    movslq %edi, %r14
    cmpq %r12, %r14
    jge .Lssa___fern_buf_take_text_3
    jmp .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_74:
    movq -56(%rbp), %rax
    movq %r14, %rsi
    movq %r12, %rdi
    call __fn___fern_buf_text_part.r
    movq %rax, %r8
    cmpq $0, %r8
    jge .Lssa___fern_buf_take_text_72
.Lssa___fern_buf_take_text_73:
    movslq %r13d, %rdi
    addq %rbx, %rdi
    movq -56(%rbp), %rsi
    addq %r15, %rsi
    movq %r14, %r9
    subq %r15, %r9
    movslq %r9d, %r9
    movq %r8, -80(%rbp)
    movq %r9, -88(%rbp)
    movq %r9, %rdx
    call __fern_memcpy
    pushq $0
    popq %rax
    movq -80(%rbp), %r8
    movq -88(%rbp), %r9
    addq %r13, %r9
    movslq %r9d, %r9
    movl $239, %esi
    movb %sil, (%rbx,%r9)
    leaq 1(%r9), %rdi
    movslq %edi, %rdi
    movl $191, %esi
    movb %sil, (%rbx,%rdi)
    leaq 2(%r9), %r10
    movslq %r10d, %r10
    movl $189, %esi
    movb %sil, (%rbx,%r10)
    addq $3, %r9
    movq %r14, %rdi
    subq %r8, %rdi
    movslq %edi, %rdi
    movq %rdi, %r14
    movq %rdi, %r15
    movq %r9, %r13
    jmp .Lssa___fern_buf_take_text_70
.Lssa___fern_buf_take_text_72:
    addq %r8, %r14
    movslq %r14d, %r14
.Lssa___fern_buf_take_text_71:
    cmpq %r12, %r14
    jl .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_3:
    movslq %r13d, %r13
    addq %rbx, %r13
    movq -56(%rbp), %r8
    addq %r15, %r8
    movq %r12, %r11
    subq %r15, %r11
    movq %r11, %r15
    movslq %r15d, %r15
    movq %r15, %rdx
    movq %r8, %rsi
    movq %r13, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    jmp .Lssa___fern_buf_take_text_1
.Lssa___fern_buf_take_text_2:
    movq %r12, %rdx
    movq -56(%rbp), %rsi
    movq %rbx, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
.Lssa___fern_buf_take_text_1:
    xorl %r8d, %r8d
    movq -48(%rbp), %r11
    movq %r8, 8(%r11)
    movq %rbx, %r11
    movq -72(%rbp), %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fern_buf_free:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rbx
    pushq %r12
    movq %rdi, %rbx
    testq %rbx, %rbx
    jz .Lbuffree_ret
    movq (%rbx), %rcx
    testq %rcx, %rcx
    jz .Lbuffree_ctl
    movq 16(%rbx), %rdx
    addq $7, %rdx
    shrq $3, %rdx
    cmpq $65536, %rdx
    jae .Lbuffree_data_large
    cmpq $256, %rdx
    jbe .L195
    pushq %rdx
    call __fern_capw
    popq %rdx
.L195:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rdx,8), %rsi
    movq %rsi, (%rcx)
    movq %rcx, (%r8,%rdx,8)
    jmp .Lbuffree_data_done
.Lbuffree_data_large:
    movq %rcx, %r8
    leaq 0(,%rdx,8), %rsi
    call __fern_large_push
.Lbuffree_data_done:
.Lbuffree_ctl:
    movq %rbx, %rcx
    movq $4, %rdx
    cmpq $65536, %rdx
    jae .Lbuffree_ctlblk_large
    cmpq $256, %rdx
    jbe .L196
    pushq %rdx
    call __fern_capw
    popq %rdx
.L196:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rdx,8), %rsi
    movq %rsi, (%rcx)
    movq %rcx, (%r8,%rdx,8)
    jmp .Lbuffree_ctlblk_done
.Lbuffree_ctlblk_large:
    movq %rcx, %r8
    leaq 0(,%rdx,8), %rsi
    call __fern_large_push
.Lbuffree_ctlblk_done:
.Lbuffree_ret:
    popq %r12
    popq %rbx
    popq %rbp
    ret
__fern_arr_push:
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Larr_push_slow
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Larr_push_slow_ok
    testl %ecx, %ecx
    jns .Larr_push_slow
.Larr_push_slow_ok:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    ret
.Larr_push_slow:
    cmpq $0, (%rdi)
    jne .Larr_push_frame
    cmpq $0, -16(%rdi)
    jne .Larr_push_frame
    leaq __fern_freelist(%rip), %rcx
    movq 56(%rcx), %rax
    testq %rax, %rax
    jz .Larr_push_fresh
    movq (%rax), %rdx
    movq %rdx, 56(%rcx)
    movq $4, (%rax)
    movq $1, 8(%rax)
    movq $1, 16(%rax)
    movq %rsi, 24(%rax)
    addq $16, %rax
    ret
.Larr_push_fresh:
    pushq %rsi
    movl $4, %edi
    call __fern_arr_box
    popq %rsi
    movq $1, (%rax)
    movq %rsi, 8(%rax)
    ret
.Larr_push_frame:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    movq %rdi, %r12
    movq %rsi, %r13
    movq (%r12), %r14
    movq -16(%r12), %r15
    jmp .Larr_push_grow
    movl -8(%r12), %ecx
    cmpl $1, %ecx
    je .Larr_push_rc_ok
    testl %ecx, %ecx
    js .Larr_push_rc_ok
    jmp .Larr_push_grow
.Larr_push_rc_ok:
    cmpq %r15, %r14
    jge .Larr_push_grow
    movq %r14, %rcx
    incq %rcx
    movq %r13, (%r12,%rcx,8)
    incq %r14
    movq %r14, (%r12)
    movq %r12, %rax
    jmp .Larr_push_ret
.Larr_push_grow:
    movq %r15, %rcx
    cmpq %r15, %r14
    jl .Larr_push_shared_cliff
    cmpq $0, %rcx
    jne .Larr_push_dbl
    movq $4, %rcx
    jmp .Larr_push_cap
.Larr_push_shared_cliff:
    incq __fern_arr_push_shared(%rip)
    movq %r14, %rax
    shlq $3, %rax
    addq %rax, __fern_arr_push_copied(%rip)
    jmp .Larr_push_cap
.Larr_push_dbl:
    shlq $1, %rcx
.Larr_push_cap:
    leaq 1(%r14), %rax
    cmpq %rax, %rcx
    cmovbq %rax, %rcx
    movq %rcx, %r15
    movq %r15, %rdi
    call __fern_arr_box
    movq %r14, %rcx
    incq %rcx
    movq %rcx, (%rax)
    leaq 8(%r12), %rsi
    leaq 8(%rax), %rdi
    movq %r14, %rcx
    subq $8, %rcx
    jl .Larr_push_copy_lt8
.Larr_push_copy8:
    vmovdqu (%rsi), %ymm0
    vmovdqu 32(%rsi), %ymm1
    vmovdqu %ymm0, (%rdi)
    vmovdqu %ymm1, 32(%rdi)
    addq $64, %rsi
    addq $64, %rdi
    subq $8, %rcx
    jge .Larr_push_copy8
    vzeroupper
.Larr_push_copy_lt8:
    addq $8, %rcx
    cmpq $4, %rcx
    jl .Larr_push_copy1
    movdqu (%rsi), %xmm0
    movdqu 16(%rsi), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, 16(%rdi)
    addq $32, %rsi
    addq $32, %rdi
    subq $4, %rcx
.Larr_push_copy1:
    testq %rcx, %rcx
    jz .Larr_push_copy_done
.Larr_push_copy1_loop:
    movq (%rsi), %rdx
    movq %rdx, (%rdi)
    addq $8, %rsi
    addq $8, %rdi
    decq %rcx
    jnz .Larr_push_copy1_loop
.Larr_push_copy_done:
    movq %r14, %rcx
    incq %rcx
    movq %r13, (%rax,%rcx,8)
.Larr_push_ret:
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    leave
    ret
__fern_arr_push_owned:
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lapo_slow
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lapo_slow_ok
    testl %ecx, %ecx
    jns .Lapo_slow
.Lapo_slow_ok:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    ret
.Lapo_slow:
    movl -8(%rdi), %ecx
    testl %ecx, %ecx
    js .Larr_push_slow
    cmpl $1, %ecx
    jne .Larr_push_slow
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    movq %rdi, %r12
    movq %rsi, %r13
    movq (%r12), %r14
    movq -16(%r12), %r15
    leaq (%r15,%r15), %rcx
    testq %rcx, %rcx
    jnz .Lapo_cap
    movq $4, %rcx
.Lapo_cap:
    leaq 1(%r14), %rax
    cmpq %rax, %rcx
    cmovbq %rax, %rcx
    cmpq $268435455, %rcx
    ja __fern_alloc_size_abort
    leaq 24(,%rcx,8), %rdi
    cmpq $2048, %rdi
    ja .Lapo_alloc
    leaq __fern_freelist(%rip), %rax
    addq %rax, %rdi
    movq (%rdi), %rax
    testq %rax, %rax
    jz .Lapo_miss
    pushq (%rax)
    popq (%rdi)
.Lapo_box:
    movq %rcx, (%rax)
    movq $1, 8(%rax)
    addq $16, %rax
    leaq 1(%r14), %rcx
    movq %rcx, (%rax)
    leaq 8(%r12), %rsi
    leaq 8(%rax), %rdi
    movq %r14, %rcx
    subq $8, %rcx
    jl .Lapo_copy_lt8
.Lapo_copy8:
    vmovdqu (%rsi), %ymm0
    vmovdqu 32(%rsi), %ymm1
    vmovdqu %ymm0, (%rdi)
    vmovdqu %ymm1, 32(%rdi)
    addq $64, %rsi
    addq $64, %rdi
    subq $8, %rcx
    jge .Lapo_copy8
    vzeroupper
.Lapo_copy_lt8:
    addq $8, %rcx
    cmpq $4, %rcx
    jl .Lapo_copy1
    movdqu (%rsi), %xmm0
    movdqu 16(%rsi), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, 16(%rdi)
    addq $32, %rsi
    addq $32, %rdi
    subq $4, %rcx
.Lapo_copy1:
    testq %rcx, %rcx
    jz .Lapo_copy_done
.Lapo_copy1_loop:
    movq (%rsi), %rdx
    movq %rdx, (%rdi)
    addq $8, %rsi
    addq $8, %rdi
    decq %rcx
    jnz .Lapo_copy1_loop
.Lapo_copy_done:
    movq %r13, 8(%rax,%r14,8)
    leaq 3(%r15), %rcx
    cmpq $65536, %rcx
    jae .Lapo_large
    movl $0, -8(%r12)
    leaq -16(%r12), %rdx
    cmpq $256, %rcx
    jbe .L197
    pushq %rcx
    call __fern_capw
    popq %rcx
.L197:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rdi
    movq %rdi, (%rdx)
    movq %rdx, (%r8,%rcx,8)
.Lapo_ret:
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    leave
    ret
.Lapo_miss:
    leaq __fern_freelist(%rip), %rax
    subq %rax, %rdi
.Lapo_alloc:
    call __fern_alloc
    jmp .Lapo_box
.Lapo_large:
    movl $0, -8(%r12)
    leaq -16(%r12), %r8
    leaq 0(,%rcx,8), %rsi
    pushq %rax
    call __fern_large_push
    popq %rax
    jmp .Lapo_ret
__fern_arr_push_u8:
    movq (%rdi), %rdx
    movq -16(%rdi), %rcx
    shlq $3, %rcx
    cmpq %rcx, %rdx
    jge .Larr_push_u8_slow
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Larr_push_u8_slow_ok
    testl %ecx, %ecx
    jns .Larr_push_u8_slow
.Larr_push_u8_slow_ok:
    movb %sil, 8(%rdi,%rdx)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    ret
.Larr_push_u8_slow:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    movq %rdi, %r12
    movq %rsi, %r13
    movq (%r12), %r14
    movq -16(%r12), %r15
    jmp .Larr_push_u8_grow
    movl -8(%r12), %ecx
    cmpl $1, %ecx
    je .Larr_push_u8_rc_ok
    testl %ecx, %ecx
    js .Larr_push_u8_rc_ok
    jmp .Larr_push_u8_grow
.Larr_push_u8_rc_ok:
    movq %r15, %rcx
    shlq $3, %rcx
    cmpq %rcx, %r14
    jge .Larr_push_u8_grow
    movb %r13b, 8(%r12,%r14)
    incq %r14
    movq %r14, (%r12)
    movq %r12, %rax
    jmp .Larr_push_u8_ret
.Larr_push_u8_grow:
    movq %r15, %rcx
    movq %r15, %rax
    shlq $3, %rax
    cmpq %rax, %r14
    jl .Larr_push_u8_cliff
    testq %rcx, %rcx
    jne .Larr_push_u8_dbl
    movq $4, %rcx
    jmp .Larr_push_u8_cap
.Larr_push_u8_cliff:
    incq __fern_arr_push_shared(%rip)
    addq %r14, __fern_arr_push_copied(%rip)
    jmp .Larr_push_u8_cap
.Larr_push_u8_dbl:
    shlq $1, %rcx
.Larr_push_u8_cap:
    leaq 8(%r14), %rax
    shrq $3, %rax
    cmpq %rax, %rcx
    cmovbq %rax, %rcx
    movq %rcx, %rdi
    call __fern_arr_box
    leaq 1(%r14), %rcx
    movq %rcx, (%rax)
    leaq 8(%r12), %rsi
    leaq 8(%rax), %rdi
    movq %r14, %rcx
    rep movsb
    movb %r13b, 8(%rax,%r14)
.Larr_push_u8_ret:
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    leave
    ret
__fern_arr_push_owned_u8:
    movq (%rdi), %rdx
    movq -16(%rdi), %rcx
    shlq $3, %rcx
    cmpq %rcx, %rdx
    jge .Lapou_slow
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lapou_slow_ok
    testl %ecx, %ecx
    jns .Lapou_slow
.Lapou_slow_ok:
    movb %sil, 8(%rdi,%rdx)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    ret
.Lapou_slow:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    movq %rdi, %r12
    call .Larr_push_u8_slow
    cmpq %rax, %r12
    je .Lapou_ret
    cmpq $0x10000, %r12
    jb .Lapou_ret
    movl -8(%r12), %ecx
    testl %ecx, %ecx
    js .Lapou_ret
    cmpl $1, %ecx
    jne .Lapou_ret
    movl -16(%r12), %ecx
    addq $3, %rcx
    cmpq $65536, %rcx
    jae .Lapou_large
    movl $0, -8(%r12)
    leaq -16(%r12), %rdx
    cmpq $256, %rcx
    jbe .L198
    pushq %rcx
    call __fern_capw
    popq %rcx
.L198:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rdi
    movq %rdi, (%rdx)
    movq %rdx, (%r8,%rcx,8)
.Lapou_ret:
    popq %r13
    popq %r12
    leave
    ret
.Lapou_large:
    movl $0, -8(%r12)
    leaq -16(%r12), %r8
    leaq 0(,%rcx,8), %rsi
    pushq %rax
    call __fern_large_push
    popq %rax
    jmp .Lapou_ret
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .section .text
__fern_alloc_bytes:
    testl %edi, %edi
    js __fern_alloc_size_abort.c
    jz .Lfern_alloc_bytes_empty
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    movq %rdi, %r12
    leaq 7(%rdi), %rdi
    shrq $3, %rdi
    movq %rdi, %r13
    call __fern_arr_box
    movq %r12, (%rax)
    movq %rax, %rdx
    leaq 8(%rax), %rdi
    movq %r13, %rcx
    xorl %eax, %eax
    rep stosq
    movq %rdx, %rax
    popq %r13
    popq %r12
    popq %rbp
    ret
.Lfern_alloc_bytes_empty:
    leaq .Lfern_empty_bytes(%rip), %rax
    ret
    .text
    .section .bss
    .align 8
__fern_sig_sp: .quad 0
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
.Lmsg_illegal_instruction:
    .ascii "fern: illegal instruction\n"
.Lmsg_bus_error:
    .ascii "fern: bus error\n"
    .text
__fern_segv:
    cmpq $11, %rdi
    jne .Lfern_fatal_signal
    movq 16(%rsi), %rax
    movq __fern_stack_top(%rip), %rcx
    subq $1073741808, %rcx
    subq %rcx, %rax
    cmpq $1048576, %rax
    jae .Lfern_segv_other
.Lfern_segv_overflow:
    movq 168(%rdx), %rax
    movq 120(%rdx), %rcx
    subq $16, %rsp
    movq %rcx, (%rsp)
    movq %rax, 8(%rsp)
    movq %rsp, %rbp
    movq 160(%rdx), %rax
    movq %rax, __fern_bt_floor(%rip)
    leaq .Lmsg_stack_overflow(%rip), %rsi
    movq $21, %rdx
    movq $134, %rdi
    jmp __fern_report
.Lfern_segv_other:
    subq $32, %rsp
    movq $0, (%rsp)
    movq $0x04000000, 8(%rsp)
    call .Lfern_fault_install
    addq $32, %rsp
    ret
.Lfern_segv_restorer:
    movl $15, %eax
    syscall
.Lfern_fault_install:
    leaq .Lfern_segv_restorer(%rip), %rax
    movq %rax, 24(%rsp)
    movq $0x448, 32(%rsp)
    leaq 8(%rsp), %rsi
    xorl %edx, %edx
    movl $8, %r10d
    movl $11, %edi
    movl $13, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_fault_install_done
    movl $4, %edi
    movl $13, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_fault_install_done
    movl $7, %edi
    movl $13, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_fault_install_done
.Lfern_fault_install_done:
    ret
.Lfern_fatal_signal:
    movslq 8(%rsi), %rax
    testq %rax, %rax
    jle .Lfern_signal_sent
    movq %rsp, __fern_sig_sp(%rip)
    movq 168(%rdx), %rax
    movq 120(%rdx), %rcx
    subq $16, %rsp
    movq %rcx, (%rsp)
    movq %rax, 8(%rsp)
    movq %rsp, %rbp
    movq 160(%rdx), %rax
    movq %rax, __fern_bt_floor(%rip)
    leaq .Lmsg_illegal_instruction(%rip), %rsi
    movq $26, %rdx
    cmpq $4, %rdi
    je .Lfern_fatal_report
    leaq .Lmsg_bus_error(%rip), %rsi
    movq $16, %rdx
.Lfern_fatal_report:
    movq $-1, %rdi
    jmp __fern_report
.Lfern_signal_resume:
    movq __fern_sig_sp(%rip), %rsp
    jmp .Lfern_segv_other
.Lfern_signal_sent:
    addq $128, %rdi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_stack_map_failed_msg:
    .ascii "fern: could not map the stack\n"
    .text
.Lfern_stack_map_failed:
    leaq .Lfern_stack_map_failed_msg(%rip), %rsi
    movq $30, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    leaq .Lfern_stack_guard_failed_msg(%rip), %rsi
    movq $40, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    leaq .Lfern_signal_stack_map_failed_msg(%rip), %rsi
    movq $37, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    leaq .Lfern_signal_stack_failed_msg(%rip), %rsi
    movq $41, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    leaq .Lfern_fault_handler_failed_msg(%rip), %rsi
    movq $42, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=x86-64-linux profile=minimal harden=0 pie=0 sanitize=0 backtrace=0 size=1 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .section .bss
    .align 8
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .globl __fern_bt_floor
__fern_bt_floor: .quad 0
    .section .text
__fern_abort_134:
    movq $134, %rdi
__fern_report:
    movq %rdi, %r15
    movq $2, %rdi
    movq $1, %rax
    syscall
    testq %r15, %r15
    js .Lfern_signal_resume
    movq %r15, %rdi
    movq $231, %rax
    syscall
    .text
__fn___fern_str_eq:
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___fern_str_eq.r:
    cmpq %rsi, %rax
    jz .Lseq_yes
    movq 8(%rax), %rdx
    cmpq 8(%rsi), %rdx
    jnz .Lseq_no
    movq (%rax), %rcx
    movq (%rsi), %rsi
    cmpq %rsi, %rcx
    jz .Lseq_yes
    cmpq $8, %rdx
    jb .Lseq_short
    leaq -8(%rcx,%rdx), %r8
    leaq -8(%rsi,%rdx), %r9
.Lseq_word:
    movq (%rcx), %rax
    cmpq (%rsi), %rax
    jnz .Lseq_no
    addq $8, %rcx
    addq $8, %rsi
    cmpq %r8, %rcx
    jb .Lseq_word
    movq (%r8), %rax
    cmpq (%r9), %rax
    jnz .Lseq_no
    jmp .Lseq_yes
.Lseq_short:
    testq %rdx, %rdx
    jz .Lseq_yes
    cmpq $4, %rdx
    jb .Lseq_byte
    movl (%rcx), %eax
    cmpl (%rsi), %eax
    jnz .Lseq_no
    movl -4(%rcx,%rdx), %eax
    cmpl -4(%rsi,%rdx), %eax
    jnz .Lseq_no
    jmp .Lseq_yes
.Lseq_byte:
    movzbl (%rcx), %eax
    cmpb (%rsi), %al
    jnz .Lseq_no
    movzbl -1(%rcx,%rdx), %eax
    cmpb -1(%rsi,%rdx), %al
    jnz .Lseq_no
    cmpq $3, %rdx
    jb .Lseq_yes
    movzbl 1(%rcx), %eax
    cmpb 1(%rsi), %al
    jnz .Lseq_no
.Lseq_yes:
    movl $1, %eax
    ret
.Lseq_no:
    xorl %eax, %eax
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .text
__fn___fern_string_from_bytes_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_string_from_bytes_u8.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
.Lssa___fern_string_from_bytes_u8_0:
    movq 0(%rbx), %r12
    movq %r12, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort.l3
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %r13
    addq $8, %rbx
    movq %r12, %rdx
    movq %rbx, %rsi
    movq %r13, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r13, %r11
    movq %r12, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_string_from_bytes_range_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_string_from_bytes_range_u8.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa___fern_string_from_bytes_range_u8_0:
    movq 0(%rbx), %rsi
    xorl %r8d, %r8d
    movl $1, %r9d
    cmpq $0, %rdi
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rsi, %rdi
    cmovleq %r9, %r8
    movl $1, %r9d
    cmpq $0, %r12
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rdi, %r12
    cmovleq %r9, %r8
    cmpq $1, %r8
    jne .Lssa___fern_string_from_bytes_range_u8_1
.Lssa___fern_string_from_bytes_range_u8_3:
    call __fern_slice_abort.c
.Lssa___fern_string_from_bytes_range_u8_1:
    subq %r12, %rdi
    movslq %edi, %r13
    movq %r13, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort.l5
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %r14
    addq $8, %rbx
    movslq %r12d, %r12
    addq %r12, %rbx
    movq %r13, %rdx
    movq %rbx, %rsi
    movq %r14, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %r11
    movq %r13, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_str_bytes_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_str_bytes_u8.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
.Lssa___fern_str_bytes_u8_0:
    movq 8(%rbx), %r12
    movslq %r12d, %r13
    leaq 7(%r13), %rsi
    movq %rsi, %rax
    movq %rax, %rcx
    sarq $63, %rcx
    shrq $61, %rcx
    addq %rax, %rcx
    movq %rcx, %rax
    sarq $3, %rax
    movq %rax, %rdi
    movslq %edi, %rdi
    call __fern_arr_box
    movq %rax, %r14
    movq %r13, 0(%r14)
    leaq 8(%r14), %rdi
    movq 0(%rbx), %rsi
    movq %r12, %rdx
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_arr_slice_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_arr_slice_u8.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa___fern_arr_slice_u8_0:
    movq 0(%rbx), %rsi
    xorl %r8d, %r8d
    movl $1, %r9d
    cmpq $0, %rdi
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rsi, %rdi
    cmovleq %r9, %r8
    movl $1, %r9d
    cmpq $0, %r12
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rdi, %r12
    cmovleq %r9, %r8
    cmpq $1, %r8
    jne .Lssa___fern_arr_slice_u8_1
.Lssa___fern_arr_slice_u8_3:
    call __fern_slice_abort.c
.Lssa___fern_arr_slice_u8_1:
    subq %r12, %rdi
    movslq %edi, %r13
    leaq 7(%r13), %rdi
    movslq %edi, %rdi
    movq %rdi, %rax
    movl %eax, %ecx
    sarl $31, %ecx
    shrl $29, %ecx
    addl %eax, %ecx
    movl %ecx, %eax
    sarl $3, %eax
    cltq
    movq %rax, %r8
    movq %r8, %rdi
    call __fern_arr_box
    movq %rax, %r14
    movq %r13, 0(%r14)
    leaq 8(%r14), %r8
    addq $8, %rbx
    movslq %r12d, %r12
    addq %r12, %rbx
    movq %r13, %rdx
    movq %rbx, %rsi
    movq %r8, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_utf8_step:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_utf8_step.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
.Lssa___fern_utf8_step_0:
    cmpq 8(%rax), %rsi
    jae __fern_str_oob_abort.l2
    movq (%rax), %rdx
    movzbl (%rdx,%rsi), %r8d
    xorl %r9d, %r9d
    movl $1, %r10d
    cmpq $128, %r8
    cmovgeq %r9, %r10
    cmpq $194, %r8
    jl .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_41:
    cmpq $224, %r8
    jge .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_40:
    movl $2, %r10d
.Lssa___fern_utf8_step_39:
.Lssa___fern_utf8_step_38:
    cmpq $224, %r8
    jl .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_37:
    cmpq $240, %r8
    jge .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_36:
    movl $3, %r10d
.Lssa___fern_utf8_step_35:
.Lssa___fern_utf8_step_34:
    cmpq $240, %r8
    jl .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_33:
    cmpq $245, %r8
    jge .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_32:
    movl $4, %r10d
.Lssa___fern_utf8_step_31:
.Lssa___fern_utf8_step_30:
    cmpq $1, %r10
    jg .Lssa___fern_utf8_step_27
.Lssa___fern_utf8_step_29:
    movl $1, %eax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_27:
    leaq 1(%rsi), %r9
    movslq %r9d, %r9
    cmpq %rdi, %r9
    jl .Lssa___fern_utf8_step_24
.Lssa___fern_utf8_step_26:
    movl $1, %eax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_24:
    movl $128, %r9d
    movl $160, %ebx
    cmpq $224, %r8
    cmovneq %r9, %rbx
    movl $144, %r9d
    cmpq $240, %r8
    cmovneq %rbx, %r9
    movl $191, %ebx
    movl $159, %r12d
    cmpq $237, %r8
    cmovneq %rbx, %r12
    movl $143, %ebx
    cmpq $244, %r8
    cmovneq %r12, %rbx
    leal 1(%rsi), %r8d
    cmpq 8(%rax), %r8
    jae __fern_str_oob_abort.l2
    movq (%rax), %rdx
    movzbl (%rdx,%r8), %r12d
    cmpq %r9, %r12
    jge .Lssa___fern_utf8_step_9
.Lssa___fern_utf8_step_11:
    movl $1, %eax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_9:
    cmpq %rbx, %r12
    jle .Lssa___fern_utf8_step_6
.Lssa___fern_utf8_step_8:
    movl $1, %eax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_6:
.Lssa___fern_utf8_step_5:
    movl $2, %r8d
.Lssa___fern_utf8_step_113:
    cmpq %r10, %r8
    jge .Lssa___fern_utf8_step_4
.Lssa___fern_utf8_step_120:
    leaq (%rsi,%r8), %r9
    movslq %r9d, %r9
    cmpq %rdi, %r9
    jge .Lssa___fern_utf8_step_3
.Lssa___fern_utf8_step_118:
    leal (%rsi,%r8), %r9d
    cmpq 8(%rax), %r9
    jae __fern_str_oob_abort.l2
    movq (%rax), %rdx
    movzbl (%rdx,%r9), %r12d
    cmpq $128, %r12
    jl .Lssa___fern_utf8_step_2
.Lssa___fern_utf8_step_116:
    cmpq $191, %r12
    jg .Lssa___fern_utf8_step_1
.Lssa___fern_utf8_step_114:
    addq $1, %r8
    cmpq %r10, %r8
    jl .Lssa___fern_utf8_step_120
.Lssa___fern_utf8_step_4:
    movq %r10, %rax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_3:
    movq %r8, %rax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_2:
    movq %r8, %rax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_1:
    movq %r8, %rax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___fern_str_split:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___fern_str_split.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $136, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa___fern_str_split_0:
    movq 8(%rbx), %r11
    movq %r11, -56(%rbp)
    movq -48(%rbp), %r11
    movq 8(%r11), %r14
    leaq .K0(%rip), %r8
    cmpq $0, %r14
    jne .Lssa___fern_str_split_3
.Lssa___fern_str_split_7:
.Lssa___fern_str_split_6:
    movq %r8, -64(%rbp)
    xorl %r13d, %r13d
.Lssa___fern_str_split_12:
    cmpq -56(%rbp), %r13
    jge .Lssa___fern_str_split_5
.Lssa___fern_str_split_13:
    movq %rbx, %rax
    movq %r13, %rsi
    movq -56(%rbp), %rdi
    call __fn___fern_utf8_step.r
    addq %r13, %rax
    movslq %eax, %r15
    movq %rbx, %rdx
    movq %r13, %rcx
    movq %r15, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -88(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r12
    leaq .SB8(%rip), %rsi
    movq %r12, %rax
    call __fn___fern_str_concat.r
    movq %rax, %r13
    pushq %r12
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq -64(%rbp), %rdi
    movq %r13, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___fern_str_split_apush87s
.Lssa___fern_str_split_apush87o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___fern_str_split_apush87e
.Lssa___fern_str_split_apush87s:
    movq %r8, -144(%rbp)
    call __fern_arr_push_owned
    movq -144(%rbp), %r8
.Lssa___fern_str_split_apush87e:
    movq %rax, -64(%rbp)
    movq %r15, %r13
    cmpq -56(%rbp), %r13
    jl .Lssa___fern_str_split_13
.Lssa___fern_str_split_5:
    movq -64(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_str_split_3:
.Lssa___fern_str_split_2:
    movq %r8, %r13
    xorl %r15d, %r15d
    xorl %r12d, %r12d
.Lssa___fern_str_split_20:
    leaq (%r12,%r14), %r8
    movslq %r8d, %r8
    cmpq -56(%rbp), %r8
    jg .Lssa___fern_str_split_1
.Lssa___fern_str_split_26:
.Lssa___fern_str_split_25:
    xorl %r8d, %r8d
    movl $1, %esi
.Lssa___fern_str_split_31:
    cmpq %r14, %r8
    jge .Lssa___fern_str_split_24
.Lssa___fern_str_split_35:
    leal (%r12,%r8), %edi
    cmpq 8(%rbx), %rdi
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rdi), %r9d
    movq -48(%rbp), %r11
    movq 0(%r11), %rdi
    movzbl (%rdi,%r8), %r10d
    xorl %edi, %edi
    addq $1, %r8
    cmpq %r10, %r9
    cmovneq %r14, %r8
    cmovneq %rdi, %rsi
    cmpq %r14, %r8
    jl .Lssa___fern_str_split_35
.Lssa___fern_str_split_24:
    cmpq $1, %rsi
    jne .Lssa___fern_str_split_22
.Lssa___fern_str_split_23:
    movq %rbx, %rdx
    movq %r15, %rcx
    movq %r12, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -112(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r8
    leaq .SB8(%rip), %rsi
    movq %r8, -144(%rbp)
    movq %r8, %rax
    call __fn___fern_str_concat.r
    movq %rax, %r10
    movq -144(%rbp), %r8
    movq %r10, -144(%rbp)
    pushq %r8
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq -144(%rbp), %r10
    movq %r13, %rdi
    movq %r10, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___fern_str_split_apush142s
.Lssa___fern_str_split_apush142o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___fern_str_split_apush142e
.Lssa___fern_str_split_apush142s:
    call __fern_arr_push_owned
.Lssa___fern_str_split_apush142e:
    leaq (%r12,%r14), %r10
    movslq %r10d, %r10
    movq %rax, %r13
    movq %r10, %r15
    movq %r10, %r12
    jmp .Lssa___fern_str_split_20
.Lssa___fern_str_split_22:
    addq $1, %r12
    movslq %r12d, %r12
.Lssa___fern_str_split_21:
    jmp .Lssa___fern_str_split_20
.Lssa___fern_str_split_1:
    movq %rbx, %rdx
    movq %r15, %rcx
    movq -56(%rbp), %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -136(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r12
    leaq .SB8(%rip), %r10
    movq %r12, %rax
    movq %r10, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r15
    pushq %r12
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r13, %rdi
    movq %r15, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___fern_str_split_apush161s
.Lssa___fern_str_split_apush161o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___fern_str_split_apush161e
.Lssa___fern_str_split_apush161s:
    call __fern_arr_push_owned
.Lssa___fern_str_split_apush161e:
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_str_concat:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___fern_str_concat.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa___fern_str_concat_0:
    movq 8(%rbx), %r13
    movq -48(%rbp), %r11
    movq 8(%r11), %r14
    leaq (%r13,%r14), %rsi
    movslq %esi, %r15
    movq %r15, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %r12
    movq 0(%rbx), %rsi
    movq %r13, %rdx
    movq %r12, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movslq %r13d, %r13
    addq %r12, %r13
    movq -48(%rbp), %r11
    movq 0(%r11), %rsi
    movq %r14, %rdx
    movq %r13, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r12, %r11
    movq %r15, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_bytes_range:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_bytes_range.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rsi, %rbx
.Lssa___fern_bytes_range_0:
    testq $2, %rdi
    je .Lssa___fern_bytes_range_10
.Lssa___fern_bytes_range_11:
    leaq -2(%rdi), %rsi
    leaq 8(%rsi), %r8
    movslq (%r8), %r8
    movq 0(%rsi), %r9
    movq %r9, %r12
    movq %r8, %r9
    jmp .Lssa___fern_bytes_range_9
.Lssa___fern_bytes_range_10:
    movslq (%rdi), %r9
    addq $8, %rdi
    movq %rdi, %r12
.Lssa___fern_bytes_range_9:
    cmpq $0, %rbx
    jl .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_8:
    cmpq %rbx, %rax
    jl .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_7:
    cmpq %r9, %rax
    jle .Lssa___fern_bytes_range_4
.Lssa___fern_bytes_range_6:
    call __fern_slice_abort.c
.Lssa___fern_bytes_range_4:
    subq %rbx, %rax
    movslq %eax, %r13
    cmpq $0, %r13
    jne .Lssa___fern_bytes_range_1
.Lssa___fern_bytes_range_3:
    leaq .K0(%rip), %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___fern_bytes_range_1:
    leaq 7(%r13), %r9
    movslq %r9d, %r9
    movq %r9, %rax
    movl %eax, %ecx
    sarl $31, %ecx
    shrl $29, %ecx
    addl %eax, %ecx
    movl %ecx, %eax
    sarl $3, %eax
    cltq
    movq %rax, %rdi
    call __fern_arr_box
    movq %rax, %r14
    movq %r13, 0(%r14)
    leaq 8(%r14), %rdi
    movslq %ebx, %rbx
    addq %rbx, %r12
    movq %r13, %rdx
    movq %r12, %rsi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_bytes_into:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn___fern_bytes_into.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $24, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
    movq %r8, %r13
    movq %r9, %r14
.Lssa___fern_bytes_into_0:
    testq $2, %rdi
    je .Lssa___fern_bytes_into_15
.Lssa___fern_bytes_into_16:
    leaq -2(%rdi), %rsi
    leaq 8(%rsi), %r8
    movslq (%r8), %r8
    movq 0(%rsi), %r9
    movq %r9, -56(%rbp)
    movq %r8, %r9
    jmp .Lssa___fern_bytes_into_14
.Lssa___fern_bytes_into_15:
    movslq (%rdi), %r9
    addq $8, %rdi
    movq %rdi, -56(%rbp)
.Lssa___fern_bytes_into_14:
    movslq (%r14), %r15
    cmpq $0, %rbx
    jl .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_13:
    cmpq $0, %r13
    jl .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_12:
    cmpq $0, -48(%rbp)
    jl .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_11:
    movq %r15, %rdi
    subq %rbx, %rdi
    movslq %edi, %rdi
    cmpq %rdi, %r13
    jg .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_10:
    subq %rbx, %r9
    movslq %r9d, %r9
    cmpq %r9, -48(%rbp)
    jle .Lssa___fern_bytes_into_7
.Lssa___fern_bytes_into_9:
    call __fern_slice_abort
.Lssa___fern_bytes_into_7:
    cmpq $0, %rbx
    jne .Lssa___fern_bytes_into_4
.Lssa___fern_bytes_into_6:
    movq %r14, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_bytes_into_4:
    pushq %r14
    call __fn___fern_rc_is_unique
    addq $8, %rsp
    cmpq $0, %rax
    jne .Lssa___fern_bytes_into_1
.Lssa___fern_bytes_into_3:
    leaq 7(%r15), %r9
    movslq %r9d, %r9
    movq %r9, %rax
    movl %eax, %ecx
    sarl $31, %ecx
    shrl $29, %ecx
    addl %eax, %ecx
    movl %ecx, %eax
    sarl $3, %eax
    cltq
    movq %rax, %rdi
    call __fern_arr_box
    movq %rax, %r12
    movq %r15, 0(%r12)
    leaq 8(%r12), %rdi
    leaq 8(%r14), %r9
    movq %r15, %rdx
    movq %r9, %rsi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %r12, %r14
.Lssa___fern_bytes_into_2:
.Lssa___fern_bytes_into_1:
    leaq 8(%r14), %r9
    movslq %r13d, %r13
    addq %r13, %r9
    movq -48(%rbp), %rdi
    movslq %edi, %rdi
    addq -56(%rbp), %rdi
    movq %rbx, %rdx
    movq %rdi, %rsi
    movq %r9, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fern_oob_abort.l0:
    pushq 0(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_oob_abort
__fern_oob_abort.l3:
    pushq 24(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_oob_abort
__fern_oob_abort.l5:
    pushq 40(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_oob_abort
__fern_str_oob_abort.l0:
    pushq 0(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_str_oob_abort
__fern_str_oob_abort.l2:
    pushq 16(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_str_oob_abort
__fern_str_oob_abort.l5:
    pushq 40(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_str_oob_abort
__fern_alloc_size_abort.l3:
    pushq 24(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_alloc_size_abort
__fern_alloc_size_abort.l5:
    pushq 40(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_alloc_size_abort
__fern_oob_abort.c:
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_oob_abort
__fern_slice_abort.c:
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_slice_abort
__fern_alloc_size_abort.c:
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_alloc_size_abort
