    .globl _start
    .text
__fn_http____find_crlf:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____find_crlf.k:
__fn_http____find_crlf.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____find_crlf_0:
    mov x10, #13
    mov x2, x9
    mov x1, x10
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L0
    mov x2, #0
.L0:
    cmp x1, #255
    b.hi .L5
    cmp x2, x3
    b.ge .L5
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L2
.L1:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L7
    cmp x5, x8
    b.ls .L1
.L2:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L3
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L3
    sub x5, x5, #16
    b .L8
.L7:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L8
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L8:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L6
.L3:
    cmp x5, x6
    b.ge .L5
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L9
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L5
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L5
    add x5, x5, x4
    b .L4
.L9:
    cmp x5, x6
    b.ge .L5
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L4
    add x5, x5, #1
    b .L9
.L4:
    sub x2, x5, x0
    b .L6
.L5:
    mov x2, #-1
.L6:
    mov x0, x2
.Lssa_http____find_crlf_3:
.Lssa_http____find_crlf_4:
    cmp x0, #0
    b.lt .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_8:
    add x10, x0, #1
    sxtw x10, w10
    cmp x10, x20
    b.ge .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_7:
    add w10, w0, #1
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http____find_crlf_1
.Lssa_http____find_crlf_5:
    add x9, x0, #1
    sxtw x9, w9
    mov x10, #13
    mov x2, x9
    mov x1, x10
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L10
    mov x2, #0
.L10:
    cmp x1, #255
    b.hi .L15
    cmp x2, x3
    b.ge .L15
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L12
.L11:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L17
    cmp x5, x8
    b.ls .L11
.L12:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L13
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L13
    sub x5, x5, #16
    b .L18
.L17:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L18
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L18:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L16
.L13:
    cmp x5, x6
    b.ge .L15
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L19
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L15
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L15
    add x5, x5, x4
    b .L14
.L19:
    cmp x5, x6
    b.ge .L15
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L14
    add x5, x5, #1
    b .L19
.L14:
    sub x2, x5, x0
    b .L16
.L15:
    mov x2, #-1
.L16:
    mov x0, x2
    cmp x0, #0
    b.ge .Lssa_http____find_crlf_8
.Lssa_http____find_crlf_2:
    mov x10, #-1
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____find_crlf_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____shared_string:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____shared_string.k:
__fn_http____shared_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
.Lssa_http____shared_string_0:
    ldr x9, [x22, #8]
    sub x10, x21, x20
    sxtw x10, w10
    cmp x9, x10
    b.ne .Lssa_http____shared_string_1
.Lssa_http____shared_string_4:
    ldr x10, [x22, #8]
    mov x9, #0
    mov x4, x10
    mov x3, x9
    mov x2, x22
    mov x1, x20
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L20_aop
    mov x1, #0
.L20_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L20_bop
    mov x3, #0
.L20_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L20_nok
    mov x4, #0
.L20_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L20_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L20_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L20_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L20_vec
.L20_short:
    cmp x10, #8
    b.lt .L20_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L20_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L20_eq
    add x8, x8, x14
.L20_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_w4:
    cmp x10, #4
    b.lt .L20_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L20_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L20_eq
    add x8, x8, x14
.L20_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_w2:
    cmp x10, #2
    b.lt .L20_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L20_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L20_eq
    add x8, x8, x14
.L20_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_tail:
    cmp x8, x13
    b.ge .L20_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L20_th
    add x8, x8, #1
    add x9, x9, #1
    b .L20_tail
.L20_th:
    sub x2, x8, x12
    b .L20_done
.L20_eq:
    mov x2, x4
.L20_done:
    mov x0, x2
    ldr x9, [x22, #8]
    cmp x0, x9
    cset x0, eq
.Lssa_http____shared_string_9:
    cbz x0, .Lssa_http____shared_string_1
.Lssa_http____shared_string_3:
    str x22, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____shared_string_1:
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn___fern_string_from_bytes_range_u8.r
.Lssa_http____shared_string_15:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____token_is:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____token_is.k:
__fn_http____token_is.r:
.Lssa_http____token_is_0:
    ldr x10, [x0, #8]
    mov x11, #0
    mov x4, x11
    mov x11, x9
    mov x9, x4
    b __fn_http____token_at.r
    .cfi_endproc
    .ltorg
__fn_http____token_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____token_at.k:
__fn_http____token_at.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x10
    mov x21, x11
.Lssa_http____token_at_0:
.Lssa_http____token_at_10:
    mov x22, x9
.Lssa_http____token_at_11:
    cmp x22, x20
    b.ge .Lssa_http____token_at_24
.Lssa_http____token_at_13:
    ldr x6, [x19, #8]
    cmp x22, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w0, [x6, x22]
    bl __fn_http____is_ows.r
    cbz x0, .Lssa_http____token_at_24
.Lssa_http____token_at_12:
    add x22, x22, #1
    cmp x22, x20
    b.lt .Lssa_http____token_at_13
.Lssa_http____token_at_8:
.Lssa_http____token_at_24:
    cmp x20, x22
    b.le .Lssa_http____token_at_7
.Lssa_http____token_at_26:
    sub x9, x20, #1
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w0, [x6, x9]
    bl __fn_http____is_ows.r
    cbz x0, .Lssa_http____token_at_7
.Lssa_http____token_at_25:
    sub x20, x20, #1
    cmp x20, x22
    b.gt .Lssa_http____token_at_26
.Lssa_http____token_at_7:
    sub x20, x20, x22
    sxtw x20, w20
    ldr x9, [x21, #8]
    cmp x20, x9
    b.eq .Lssa_http____token_at_4
.Lssa_http____token_at_6:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____token_at_4:
.Lssa_http____token_at_3:
    ldr x20, [x21, #8]
    ldr x23, [x21, #0]
    mov x21, #0
.Lssa_http____token_at_41:
    cmp x21, x20
    b.ge .Lssa_http____token_at_2
.Lssa_http____token_at_44:
    add w9, w22, w21
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w0, [x6, x9]
    bl __fn_http____ascii_lower.r
    mov x24, x0
    ldrb w0, [x23, x21]
    bl __fn_http____ascii_lower.r
    cmp x24, x0
    b.ne .Lssa_http____token_at_1
.Lssa_http____token_at_42:
    add x21, x21, #1
    cmp x21, x20
    b.lt .Lssa_http____token_at_44
.Lssa_http____token_at_2:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____token_at_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____is_ows:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____is_ows.k:
__fn_http____is_ows.r:
.Lssa_http____is_ows_0:
    mov x9, #1
    cmp x0, #9
    cset x10, eq
    cmp x0, #32
    csel x0, x9, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn_http____ascii_lower:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____ascii_lower.k:
__fn_http____ascii_lower.r:
.Lssa_http____ascii_lower_0:
    cmp x0, #65
    b.lt .Lssa_http____ascii_lower_1
.Lssa_http____ascii_lower_3:
    cmp x0, #90
    b.gt .Lssa_http____ascii_lower_1
.Lssa_http____ascii_lower_2:
    add x9, x0, #32
    sxtw x9, w9
    mov x0, x9
    ret
.Lssa_http____ascii_lower_1:
    ret
    .cfi_endproc
    .ltorg
__fn_http____parse_header_bytes:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_http____parse_header_bytes.k:
__fn_http____parse_header_bytes.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #112
    mov x19, x0
    mov x20, x10
    str x11, [sp, #104]
    mov x22, x12
.Lssa_http____parse_header_bytes_0:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http____parse_header_bytes_15:
    mov x23, x0
    str x9, [sp, #80]
    mov x5, #1
    str x5, [sp, #96]
    str xzr, [sp, #88]
.Lssa_http____parse_header_bytes_16:
    ldr x4, [sp, #80]
    cmp x4, x20
    b.ge .Lssa_http____parse_header_bytes_14
.Lssa_http____parse_header_bytes_70:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    mov x2, x9
    ldr x1, [sp, #80]
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L21
    mov x1, #0
.L21:
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L24
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L22:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L23
    add x5, x5, #16
    cmp x5, x8
    b.ls .L22
    sub x1, x5, x0
    b .L24
.L23:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L25
.L24:
    add x10, x9, #96
.L28:
    cmp x1, x3
    b.ge .L26
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L25
    add x1, x1, #1
    b .L28
.L25:
    str x1, [sp, #-16]!
    b .L27
.L26:
    str x3, [sp, #-16]!
.L27:
    ldr x0, [sp], #16
    cmp x0, x20
    csel x27, x20, x0, gt
    ldr x5, [sp, #80]
    cmp x27, x5
    b.eq .Lssa_http____parse_header_bytes_67
.Lssa_http____parse_header_bytes_69:
    cmp x27, x20
    b.ge .Lssa_http____parse_header_bytes_67
.Lssa_http____parse_header_bytes_68:
    ldr x6, [x19]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x27
    ldrb w9, [x5, #8]
    cmp x9, #58
    b.eq .Lssa_http____parse_header_bytes_65
.Lssa_http____parse_header_bytes_67:
    mov x10, #-1
    str x10, [sp, #72]
    mov x28, x20
    b .Lssa_http____parse_header_bytes_53
.Lssa_http____parse_header_bytes_65:
    add x10, x27, #1
.Lssa_http____parse_header_bytes_64:
    mov x9, #13
    mov x2, x10
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L29
    mov x2, #0
.L29:
    cmp x1, #255
    b.hi .L34
    cmp x2, x3
    b.ge .L34
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L31
.L30:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L36
    cmp x5, x8
    b.ls .L30
.L31:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L32
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L32
    sub x5, x5, #16
    b .L37
.L36:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L37
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L37:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L35
.L32:
    cmp x5, x6
    b.ge .L34
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L38
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L34
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L34
    add x5, x5, x4
    b .L33
.L38:
    cmp x5, x6
    b.ge .L34
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L33
    add x5, x5, #1
    b .L38
.L33:
    sub x2, x5, x0
    b .L35
.L34:
    mov x2, #-1
.L35:
    mov x0, x2
    cmp x0, #0
    b.lt .Lssa_http____parse_header_bytes_62
.Lssa_http____parse_header_bytes_63:
    cmp x0, x20
    b.lt .Lssa_http____parse_header_bytes_60
.Lssa_http____parse_header_bytes_62:
    mov x0, x20
    b .Lssa_http____parse_header_bytes_56
.Lssa_http____parse_header_bytes_60:
    add x9, x0, #1
    cmp x9, x20
    b.ge .Lssa_http____parse_header_bytes_58
.Lssa_http____parse_header_bytes_59:
    add x9, x0, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http____parse_header_bytes_56
.Lssa_http____parse_header_bytes_58:
    mov x10, #-1
    mov x0, x10
.Lssa_http____parse_header_bytes_57:
.Lssa_http____parse_header_bytes_56:
    cmp x0, #0
    b.ge .Lssa_http____parse_header_bytes_54
.Lssa_http____parse_header_bytes_55:
    mov x10, #-1
    str x10, [sp, #72]
    mov x28, x20
    b .Lssa_http____parse_header_bytes_53
.Lssa_http____parse_header_bytes_54:
    str x27, [sp, #72]
    mov x28, x0
.Lssa_http____parse_header_bytes_53:
    ldr x4, [sp, #72]
    cmp x4, #0
    b.ge .Lssa_http____parse_header_bytes_51
.Lssa_http____parse_header_bytes_121:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http____parse_header_bytes_11
.Lssa_http____parse_header_bytes_51:
    ldr x4, [sp, #88]
    add x10, x4, #1
    sxtw x4, w10
    str x4, [sp, #88]
    ldr x5, [sp, #104]
    cmp x4, x5
    b.le .Lssa_http____parse_header_bytes_49
.Lssa_http____parse_header_bytes_125:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http____parse_header_bytes_10
.Lssa_http____parse_header_bytes_49:
    ldr x4, [sp, #88]
    sub x10, x4, #1
    sxtw x21, w10
    ldr x4, [sp, #96]
    cbz x4, .Lssa_http____parse_header_bytes_42
.Lssa_http____parse_header_bytes_48:
    ldr x10, [x22, #8]
    ldr x9, [x10, #0]
    cmp x21, x9
    b.lt .Lssa_http____parse_header_bytes_42
.Lssa_http____parse_header_bytes_47:
    cmp x21, #0
    b.le .Lssa_http____parse_header_bytes_44
.Lssa_http____parse_header_bytes_137:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http____parse_header_bytes_46:
    mov x0, x22
    mov x9, x21
    bl __fn_http____leading_fields.r
    mov x23, x0
.Lssa_http____parse_header_bytes_45:
.Lssa_http____parse_header_bytes_44:
    str xzr, [sp, #96]
.Lssa_http____parse_header_bytes_43:
.Lssa_http____parse_header_bytes_42:
    mov x9, #-1
    ldr x4, [sp, #96]
    cmp x4, #0
    csel x25, x21, x9, ne
    ldr x4, [sp, #72]
    add x9, x4, #1
    sxtw x9, w9
.Lssa_http____parse_header_bytes_38:
    mov x27, x9
.Lssa_http____parse_header_bytes_148:
    cmp x27, x28
    b.ge .Lssa_http____parse_header_bytes_36
.Lssa_http____parse_header_bytes_150:
    ldr x6, [x19]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x27
    ldrb w0, [x5, #8]
    bl __fn_http____is_ows.r
    cbz x0, .Lssa_http____parse_header_bytes_36
.Lssa_http____parse_header_bytes_149:
    add x27, x27, #1
    cmp x27, x28
    b.lt .Lssa_http____parse_header_bytes_150
.Lssa_http____parse_header_bytes_36:
    mov x26, x28
.Lssa_http____parse_header_bytes_161:
    cmp x26, x27
    b.le .Lssa_http____parse_header_bytes_35
.Lssa_http____parse_header_bytes_163:
    sub x9, x26, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w0, [x5, #8]
    bl __fn_http____is_ows.r
    cbz x0, .Lssa_http____parse_header_bytes_35
.Lssa_http____parse_header_bytes_162:
    sub x26, x26, #1
    cmp x26, x27
    b.gt .Lssa_http____parse_header_bytes_163
.Lssa_http____parse_header_bytes_35:
    cmp x25, #0
    b.lt .Lssa_http____parse_header_bytes_30
.Lssa_http____parse_header_bytes_34:
    ldr x9, [x22, #16]
    ldr x6, [x9]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x10, #8]
    sub x10, x26, x27
    sxtw x10, w10
    cmp x9, x10
    b.ne .Lssa_http____parse_header_bytes_30
.Lssa_http____parse_header_bytes_33:
    ldr x10, [x22, #16]
    ldr x6, [x10]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x9, [x10, x5, lsl #3]
    ldr x11, [x9, #8]
    mov x12, #0
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x4, x11
    mov x3, x12
    mov x2, x9
    mov x1, x27
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L39_aop
    mov x1, #0
.L39_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L39_bop
    mov x3, #0
.L39_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L39_nok
    mov x4, #0
.L39_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L39_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L39_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L39_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L39_done
.L39_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L39_vec
.L39_short:
    cmp x10, #8
    b.lt .L39_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L39_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L39_eq
    add x8, x8, x14
.L39_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L39_done
.L39_w4:
    cmp x10, #4
    b.lt .L39_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L39_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L39_eq
    add x8, x8, x14
.L39_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L39_done
.L39_w2:
    cmp x10, #2
    b.lt .L39_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L39_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L39_eq
    add x8, x8, x14
.L39_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L39_done
.L39_tail:
    cmp x8, x13
    b.ge .L39_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L39_th
    add x8, x8, #1
    add x9, x9, #1
    b .L39_tail
.L39_th:
    sub x2, x8, x12
    b .L39_done
.L39_eq:
    mov x2, x4
.L39_done:
    mov x0, x2
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [x9, #8]
    cmp x0, x12
    cset x0, eq
.Lssa_http____parse_header_bytes_182:
    cbz x0, .Lssa_http____parse_header_bytes_30
.Lssa_http____parse_header_bytes_32:
    ldr x6, [x10]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x24, [x10, x5, lsl #3]
    str x24, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    b .Lssa_http____parse_header_bytes_26
.Lssa_http____parse_header_bytes_30:
    adrp x10, .K3
    add x10, x10, :lo12:.K3
    mov x2, x10
    mov x1, x27
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L40
    mov x1, #0
.L40:
    adrp x9, .S2
    add x9, x9, :lo12:.S2
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L43
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L41:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L42
    add x5, x5, #16
    cmp x5, x8
    b.ls .L41
    sub x1, x5, x0
    b .L43
.L42:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L44
.L43:
    add x10, x9, #96
.L47:
    cmp x1, x3
    b.ge .L45
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L44
    add x1, x1, #1
    b .L47
.L44:
    str x1, [sp, #-16]!
    b .L46
.L45:
    str x3, [sp, #-16]!
.L46:
    ldr x0, [sp], #16
    cmp x0, x26
    b.ge .Lssa_http____parse_header_bytes_28
.Lssa_http____parse_header_bytes_189:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http____parse_header_bytes_1
.Lssa_http____parse_header_bytes_28:
    mov x0, x19
    mov x9, x27
    mov x10, x26
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x24, x0
.Lssa_http____parse_header_bytes_193:
    mov x0, x24
    bl __fn_utf8__is_valid.r
    cbnz x0, .Lssa_http____parse_header_bytes_26
.Lssa_http____parse_header_bytes_196:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    mov x0, x24
    bl __fn___fern_str_free.r
    b .Lssa_http____parse_header_bytes_1
.Lssa_http____parse_header_bytes_27:
.Lssa_http____parse_header_bytes_26:
    ldr x4, [sp, #96]
    cbz x4, .Lssa_http____parse_header_bytes_19
.Lssa_http____parse_header_bytes_25:
    ldr x10, [x22, #8]
    ldr x6, [x10]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x26, [x10, x5, lsl #3]
    mov x0, x19
    ldr x9, [sp, #80]
    ldr x10, [sp, #72]
    mov x11, x26
    bl __fn_http____shared_string.r
    mov x27, x0
    ldr x6, [x27, #8]
    ldr x7, [x26, #8]
    cmp x6, x7
    b.ne .Lssa_http____parse_header_bytes_streqn423
    mov x0, x27
    mov x9, x26
    bl __fn___fern_str_eq.r
    b .Lssa_http____parse_header_bytes_streqd423
.Lssa_http____parse_header_bytes_streqn423:
    mov x0, #0
.Lssa_http____parse_header_bytes_streqd423:
    cbz x0, .Lssa_http____parse_header_bytes_23
.Lssa_http____parse_header_bytes_24:
    ldr x10, [x22, #16]
    ldr x6, [x10]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x12, [x10, x5, lsl #3]
    ldr x6, [x24, #8]
    ldr x7, [x12, #8]
    cmp x6, x7
    b.ne .Lssa_http____parse_header_bytes_streqn426
    mov x0, x24
    mov x9, x12
    bl __fn___fern_str_eq.r
    b .Lssa_http____parse_header_bytes_streqd426
.Lssa_http____parse_header_bytes_streqn426:
    mov x0, #0
.Lssa_http____parse_header_bytes_streqd426:
    mov x26, x0
    b .Lssa_http____parse_header_bytes_22
.Lssa_http____parse_header_bytes_23:
    mov x26, #0
.Lssa_http____parse_header_bytes_22:
    cbz x26, .Lssa_http____parse_header_bytes_209
.Lssa_http____parse_header_bytes_208:
    mov x0, x27
    bl __fn___fern_str_free.r
    mov x0, x24
    bl __fn___fern_str_free.r
    b .Lssa_http____parse_header_bytes_21
.Lssa_http____parse_header_bytes_209:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http____parse_header_bytes_20
.Lssa_http____parse_header_bytes_21:
    str x26, [sp, #96]
    b .Lssa_http____parse_header_bytes_17
.Lssa_http____parse_header_bytes_20:
    mov x0, x22
    mov x9, x21
    bl __fn_http____leading_fields.r
    mov x9, x27
    mov x10, x24
    bl __fn_HeaderMap__append.r
    mov x21, x0
    mov x0, x27
    bl __fn___fern_str_free.r
    mov x0, x24
    bl __fn___fern_str_free.r
    mov x23, x21
    str x26, [sp, #96]
    b .Lssa_http____parse_header_bytes_17
.Lssa_http____parse_header_bytes_19:
    mov x0, x19
    ldr x9, [sp, #80]
    ldr x10, [sp, #72]
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x21, x0
.Lssa_http____parse_header_bytes_214:
    mov x0, x23
    mov x9, x21
    mov x10, x24
    bl __fn_HeaderMap__append.r
    mov x26, x0
    mov x0, x21
    bl __fn___fern_str_free.r
    mov x0, x24
    bl __fn___fern_str_free.r
    mov x23, x26
.Lssa_http____parse_header_bytes_18:
.Lssa_http____parse_header_bytes_17:
    add x28, x28, #2
    sxtw x4, w28
    str x4, [sp, #80]
    ldr x4, [sp, #80]
    cmp x4, x20
    b.lt .Lssa_http____parse_header_bytes_70
.Lssa_http____parse_header_bytes_14:
    ldr x4, [sp, #96]
    cbz x4, .Lssa_http____parse_header_bytes_8
.Lssa_http____parse_header_bytes_13:
    ldr x12, [x22, #8]
    ldr x10, [x12, #0]
    ldr x4, [sp, #88]
    cmp x4, x10
    b.ne .Lssa_http____parse_header_bytes_8
.Lssa_http____parse_header_bytes_222:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http____parse_header_bytes_12:
    str x22, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    mov x1, x22
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_11:
    mov x10, #400
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_10:
    mov x10, #431
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_8:
    ldr x4, [sp, #96]
    cbz x4, .Lssa_http____parse_header_bytes_5
.Lssa_http____parse_header_bytes_226:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http____parse_header_bytes_7:
    mov x0, x22
    ldr x9, [sp, #88]
    bl __fn_http____leading_fields.r
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_5:
    mov x1, x23
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____parse_header_bytes_1:
    mov x10, #400
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____leading_fields:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____leading_fields.k:
__fn_http____leading_fields.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____leading_fields_0:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http____leading_fields_2:
    mov x21, #0
.Lssa_http____leading_fields_3:
    cmp x21, x20
    b.ge .Lssa_http____leading_fields_1
.Lssa_http____leading_fields_4:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x19, #16]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x11, [x9, x5, lsl #3]
    mov x9, x10
    mov x10, x11
    bl __fn_HeaderMap__append.r
    add x21, x21, #1
    cmp x21, x20
    b.lt .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_1:
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____crlf_terminated:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____crlf_terminated.k:
__fn_http____crlf_terminated.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____crlf_terminated_0:
.Lssa_http____crlf_terminated_7:
    mov x21, x9
.Lssa_http____crlf_terminated_8:
.Lssa_http____crlf_terminated_18:
    mov x9, #13
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L48
    mov x2, #0
.L48:
    cmp x1, #255
    b.hi .L53
    cmp x2, x3
    b.ge .L53
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L50
.L49:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L55
    cmp x5, x8
    b.ls .L49
.L50:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L51
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L51
    sub x5, x5, #16
    b .L56
.L55:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L56
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L56:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L54
.L51:
    cmp x5, x6
    b.ge .L53
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L57
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L53
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L53
    add x5, x5, x4
    b .L52
.L57:
    cmp x5, x6
    b.ge .L53
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L52
    add x5, x5, #1
    b .L57
.L52:
    sub x2, x5, x0
    b .L54
.L53:
    mov x2, #-1
.L54:
    mov x22, x2
    mov x9, #10
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L58
    mov x2, #0
.L58:
    cmp x1, #255
    b.hi .L63
    cmp x2, x3
    b.ge .L63
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L60
.L59:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L65
    cmp x5, x8
    b.ls .L59
.L60:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L61
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L61
    sub x5, x5, #16
    b .L66
.L65:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L66
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L66:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L64
.L61:
    cmp x5, x6
    b.ge .L63
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L67
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L63
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L63
    add x5, x5, x4
    b .L62
.L67:
    cmp x5, x6
    b.ge .L63
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L62
    add x5, x5, #1
    b .L67
.L62:
    sub x2, x5, x0
    b .L64
.L63:
    mov x2, #-1
.L64:
    mov x0, x2
    cmp x22, #0
    b.lt .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_17:
    cmp x22, x20
    b.ge .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_15:
    cmp x0, #0
    b.lt .Lssa_http____crlf_terminated_12
.Lssa_http____crlf_terminated_14:
    cmp x0, x22
    b.lt .Lssa_http____crlf_terminated_2
.Lssa_http____crlf_terminated_12:
    add x9, x22, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http____crlf_terminated_9
.Lssa_http____crlf_terminated_11:
    add x10, x22, #1
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.ne .Lssa_http____crlf_terminated_1
.Lssa_http____crlf_terminated_9:
    add x22, x22, #2
    sxtw x21, w22
    b .Lssa_http____crlf_terminated_18
.Lssa_http____crlf_terminated_6:
    mov x9, #1
    cmp x0, x20
    cset x20, ge
    cmp x0, #0
    csel x0, x9, x20, lt
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_2:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____line_break:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____line_break.k:
__fn_http____line_break.r:
.Lssa_http____line_break_0:
    cmp x9, x10
    b.lt .Lssa_http____line_break_9
.Lssa_http____line_break_11:
    mov x0, #2
    ret
.Lssa_http____line_break_9:
    ldr x6, [x0]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort_leaf
1:
    add x5, x0, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http____line_break_6
.Lssa_http____line_break_8:
    add x10, x9, #1
    ldr x11, [x0, #0]
    cmp x10, x11
    b.ge .Lssa_http____line_break_4
.Lssa_http____line_break_7:
    add x11, x9, #1
    ldr x6, [x0]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort_leaf
1:
    add x5, x0, x11
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http____line_break_4
.Lssa_http____line_break_6:
    mov x0, #1
    ret
.Lssa_http____line_break_4:
    add x9, x9, #1
    ldr x10, [x0, #0]
    mov x11, #2
    mov x12, #0
    cmp x9, x10
    csel x0, x11, x12, ge
    ret
    .cfi_endproc
    .ltorg
__fn_http____field_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____field_at.k:
__fn_http____field_at.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____field_at_0:
.Lssa_http____field_at_3:
    mov x21, x10
.Lssa_http____field_at_4:
    ldr x10, [x19, #8]
    ldr x9, [x10, #0]
    cmp x21, x9
    b.ge .Lssa_http____field_at_2
.Lssa_http____field_at_8:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x10, #8]
    ldr x10, [x20, #8]
    cmp x9, x10
    b.ne .Lssa_http____field_at_5
.Lssa_http____field_at_7:
    ldr x10, [x19, #8]
    ldr x6, [x10]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x10, x5, lsl #3]
    mov x9, x20
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http____field_at_1
.Lssa_http____field_at_5:
    add x21, x21, #1
    b .Lssa_http____field_at_4
.Lssa_http____field_at_2:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____field_at_1:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____kind_if:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____kind_if.k:
__fn_http____kind_if.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x10
.Lssa_http____kind_if_0:
    bl __fn_string__eq_ignore_ascii_case.r
    cbz x0, .Lssa_http____kind_if_1
.Lssa_http____kind_if_3:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____kind_if_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____hex_digit:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____hex_digit.k:
__fn_http____hex_digit.r:
.Lssa_http____hex_digit_0:
    cmp x0, #48
    b.lo .Lssa_http____hex_digit_9
.Lssa_http____hex_digit_12:
    cmp x0, #57
    b.hi .Lssa_http____hex_digit_9
.Lssa_http____hex_digit_11:
    sub x9, x0, #48
    sxtw x9, w9
    mov x0, x9
    ret
.Lssa_http____hex_digit_9:
    cmp x0, #97
    b.lo .Lssa_http____hex_digit_5
.Lssa_http____hex_digit_8:
    cmp x0, #102
    b.hi .Lssa_http____hex_digit_5
.Lssa_http____hex_digit_7:
    sub x9, x0, #87
    sxtw x9, w9
    mov x0, x9
    ret
.Lssa_http____hex_digit_5:
    cmp x0, #65
    b.lo .Lssa_http____hex_digit_1
.Lssa_http____hex_digit_4:
    cmp x0, #70
    b.hi .Lssa_http____hex_digit_1
.Lssa_http____hex_digit_3:
    sub x0, x0, #55
    sxtw x0, w0
    ret
.Lssa_http____hex_digit_1:
    mov x0, #-1
    ret
    .cfi_endproc
    .ltorg
__fn_http____bws_end:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____bws_end.k:
__fn_http____bws_end.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____bws_end_0:
.Lssa_http____bws_end_2:
    mov x21, x9
.Lssa_http____bws_end_3:
    cmp x21, x20
    b.ge .Lssa_http____bws_end_1
.Lssa_http____bws_end_5:
    ldr x6, [x19]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x21
    ldrb w0, [x5, #8]
    bl __fn_http____is_ows.r
    cbz x0, .Lssa_http____bws_end_1
.Lssa_http____bws_end_4:
    add x21, x21, #1
    cmp x21, x20
    b.lt .Lssa_http____bws_end_5
.Lssa_http____bws_end_1:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____target_start:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____target_start.k:
__fn_http____target_start.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____target_start_0:
    mov x12, #2
    and x12, x0, x12
    cbz x12, .Lssa_http____target_start_2
.Lssa_http____target_start_1:
    mov x12, #-2
    add x12, x0, x12
    ldr x13, [x12, #0]
    ldr x14, [x12, #8]
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_http____target_start_3
.Lssa_http____target_start_2:
    add x14, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____target_start_5
.Lssa_http____target_start_4:
    ldr x13, [x0, #0]
    b .Lssa_http____target_start_3
.Lssa_http____target_start_5:
    mov x13, #0
.Lssa_http____target_start_6:
.Lssa_http____target_start_3:
    add x12, x9, #1
    sxtw x12, w12
    cmp x10, x12
    b.ne .Lssa_http____target_start_13
.Lssa_http____target_start_19:
    mov w12, w9
    cmp x12, x13
    b.lo .Lssa_http____target_start_26
.Lssa_http____target_start_24:
    bl __fern_oob_abort
.Lssa_http____target_start_26:
    ldrb w15, [x14, x12]
    cmp x15, #42
    b.ne .Lssa_http____target_start_13
.Lssa_http____target_start_18:
    cbz x11, .Lssa_http____target_start_15
.Lssa_http____target_start_17:
    mov x15, #-1
.Lssa_http____target_start_35:
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____target_start_15:
    mov x15, #-2
.Lssa_http____target_start_37:
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____target_start_13:
    cmp x10, x9
    b.le .Lssa_http____target_start_9
.Lssa_http____target_start_12:
    mov w15, w9
    cmp x15, x13
    b.lo .Lssa_http____target_start_45
.Lssa_http____target_start_43:
    bl __fern_oob_abort
.Lssa_http____target_start_45:
    ldrb w13, [x14, x15]
    cmp x13, #47
    b.ne .Lssa_http____target_start_9
.Lssa_http____target_start_11:
    mov x0, x9
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____target_start_9:
    bl __fn_http____absolute_form_path.r
    cmp x0, #0
    b.ge .Lssa_http____target_start_7
.Lssa_http____target_start_8:
    mov x10, #-2
.Lssa_http____target_start_54:
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____target_start_7:
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____path_end:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____path_end.k:
__fn_http____path_end.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____path_end_0:
    mov x11, #63
    mov x0, x19
    mov x10, x20
    bl __fn_http____find_char.r
    mov x21, x0
    cmp x21, #0
    b.ge .Lssa_http____path_end_3
.Lssa_http____path_end_5:
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_end_3:
    add x11, x21, #1
    sxtw x9, w11
    mov x0, x19
    mov x10, x20
    bl __fn_http____query_ok.r
    cbz x0, .Lssa_http____path_end_1
.Lssa_http____path_end_2:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_end_1:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____absolute_form_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____absolute_form_path.k:
__fn_http____absolute_form_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_http____absolute_form_path_0:
    mov x9, #2
    and x9, x19, x9
    cbz x9, .Lssa_http____absolute_form_path_2
.Lssa_http____absolute_form_path_1:
    mov x9, #-2
    add x9, x19, x9
    ldr x10, [x9, #0]
    ldr x11, [x9, #8]
    mov x22, x10
    mov x23, x11
    b .Lssa_http____absolute_form_path_3
.Lssa_http____absolute_form_path_2:
    add x11, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____absolute_form_path_5
.Lssa_http____absolute_form_path_4:
    ldr x10, [x19, #0]
    b .Lssa_http____absolute_form_path_6
.Lssa_http____absolute_form_path_5:
    mov x10, #0
.Lssa_http____absolute_form_path_6:
    mov x22, x11
    mov x23, x10
.Lssa_http____absolute_form_path_3:
    mov x24, #-1
    adrp x11, .SB3
    add x11, x11, :lo12:.SB3
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_17
.Lssa_http____absolute_form_path_19:
    add x11, x20, #7
    sxtw x11, w11
    mov x24, x11
.Lssa_http____absolute_form_path_18:
.Lssa_http____absolute_form_path_17:
    adrp x11, .SB4
    add x11, x11, :lo12:.SB4
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_14
.Lssa_http____absolute_form_path_16:
    add x20, x20, #8
    sxtw x20, w20
    mov x24, x20
.Lssa_http____absolute_form_path_15:
.Lssa_http____absolute_form_path_14:
    cmp x24, #0
    b.ge .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_13:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_11:
    mov x20, x24
.Lssa_http____absolute_form_path_34:
    cmp x20, x21
    b.ge .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_39:
    mov w11, w20
    cmp x11, x23
    b.lo .Lssa_http____absolute_form_path_46
.Lssa_http____absolute_form_path_44:
    bl __fern_oob_abort
.Lssa_http____absolute_form_path_46:
    ldrb w0, [x22, x11]
    cmp x0, #47
    b.eq .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_38:
    cmp x0, #63
    b.eq .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_37:
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____absolute_form_path_8
.Lssa_http____absolute_form_path_35:
    add x20, x20, #1
    cmp x20, x21
    b.lt .Lssa_http____absolute_form_path_39
.Lssa_http____absolute_form_path_10:
    mov x11, #-1
    cmp x20, x24
    csel x0, x11, x20, eq
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_8:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____prefix_ci:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____prefix_ci.k:
__fn_http____prefix_ci.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x9
.Lssa_http____prefix_ci_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa_http____prefix_ci_2
.Lssa_http____prefix_ci_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x12, [x9, #0]
    ldr x13, [x9, #8]
    mov x20, x12
    mov x21, x13
    b .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____prefix_ci_5
.Lssa_http____prefix_ci_4:
    ldr x12, [x0, #0]
    b .Lssa_http____prefix_ci_6
.Lssa_http____prefix_ci_5:
    mov x12, #0
.Lssa_http____prefix_ci_6:
    mov x20, x13
    mov x21, x12
.Lssa_http____prefix_ci_3:
    sub x10, x10, x19
    sxtw x10, w10
    ldr x12, [x11, #8]
    cmp x10, x12
    b.ge .Lssa_http____prefix_ci_10
.Lssa_http____prefix_ci_12:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_10:
.Lssa_http____prefix_ci_9:
    ldr x22, [x11, #8]
    ldr x23, [x11, #0]
    mov x24, #0
.Lssa_http____prefix_ci_17:
    cmp x24, x22
    b.ge .Lssa_http____prefix_ci_8
.Lssa_http____prefix_ci_20:
    add w11, w19, w24
    cmp x11, x21
    b.lo .Lssa_http____prefix_ci_27
.Lssa_http____prefix_ci_25:
    bl __fern_oob_abort
.Lssa_http____prefix_ci_27:
    ldrb w0, [x20, x11]
    bl __fn_http____ascii_lower.r
    ldrb w11, [x23, x24]
    cmp x0, x11
    b.ne .Lssa_http____prefix_ci_7
.Lssa_http____prefix_ci_18:
    add x24, x24, #1
    cmp x24, x22
    b.lt .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_8:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_7:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____find_char:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____find_char.k:
__fn_http____find_char.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____find_char_0:
    mov x12, #2
    and x12, x0, x12
    cbz x12, .Lssa_http____find_char_2
.Lssa_http____find_char_1:
    mov x12, #-2
    add x12, x0, x12
    ldr x13, [x12, #0]
    ldr x14, [x12, #8]
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_http____find_char_10
.Lssa_http____find_char_2:
    add x14, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____find_char_5
.Lssa_http____find_char_4:
    ldr x13, [x0, #0]
    b .Lssa_http____find_char_10
.Lssa_http____find_char_5:
    mov x13, #0
.Lssa_http____find_char_6:
.Lssa_http____find_char_3:
.Lssa_http____find_char_9:
.Lssa_http____find_char_10:
    cmp x9, x10
    b.ge .Lssa_http____find_char_8
.Lssa_http____find_char_13:
    mov w12, w9
    cmp x12, x13
    b.lo .Lssa_http____find_char_20
.Lssa_http____find_char_18:
    bl __fern_oob_abort
.Lssa_http____find_char_20:
    ldrb w15, [x14, x12]
    cmp x15, x11
    b.eq .Lssa_http____find_char_7
.Lssa_http____find_char_11:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____find_char_13
.Lssa_http____find_char_8:
    mov x0, #-1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____find_char_7:
    mov x0, x9
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____is_pchar:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____is_pchar.k:
__fn_http____is_pchar.r:
.Lssa_http____is_pchar_0:
.Lssa_http____is_pchar_42:
    cmp x0, #97
    b.lt .Lssa_http____is_pchar_37
.Lssa_http____is_pchar_41:
    cmp x0, #122
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_37:
    cmp x0, #65
    b.lt .Lssa_http____is_pchar_32
.Lssa_http____is_pchar_36:
    cmp x0, #90
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_32:
    cmp x0, #48
    b.lt .Lssa_http____is_pchar_27
.Lssa_http____is_pchar_31:
    cmp x0, #57
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_27:
    cmp x0, #45
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_24:
    cmp x0, #46
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_21:
    cmp x0, #95
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_18:
    cmp x0, #126
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_14:
    adrp x9, .SB5
    add x9, x9, :lo12:.SB5
.Lssa_http____is_pchar_13:
    ldr x10, [x9, #8]
    ldr x11, [x9, #0]
    mov x9, #0
.Lssa_http____is_pchar_93:
    cmp x9, x10
    b.ge .Lssa_http____is_pchar_8
.Lssa_http____is_pchar_96:
    ldrb w12, [x11, x9]
    cmp x12, x0
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_94:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____is_pchar_96
.Lssa_http____is_pchar_8:
    cmp x0, #58
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_5:
    cmp x0, #64
    b.ne .Lssa_http____is_pchar_2
.Lssa_http____is_pchar_3:
    mov x0, #1
    b .Lssa_http____is_pchar_1
.Lssa_http____is_pchar_2:
    cmp x0, #37
    cset x0, eq
.Lssa_http____is_pchar_1:
    ret
    .cfi_endproc
    .ltorg
__fn_http____query_ok:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____query_ok.k:
__fn_http____query_ok.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____query_ok_0:
    mov x10, #2
    and x10, x19, x10
    cbz x10, .Lssa_http____query_ok_2
.Lssa_http____query_ok_1:
    mov x10, #-2
    add x10, x19, x10
    ldr x11, [x10, #0]
    ldr x12, [x10, #8]
    mov x21, x11
    mov x22, x12
    b .Lssa_http____query_ok_10
.Lssa_http____query_ok_2:
    add x12, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____query_ok_5
.Lssa_http____query_ok_4:
    ldr x11, [x19, #0]
    b .Lssa_http____query_ok_6
.Lssa_http____query_ok_5:
    mov x11, #0
.Lssa_http____query_ok_6:
    mov x21, x12
    mov x22, x11
.Lssa_http____query_ok_3:
.Lssa_http____query_ok_10:
    mov x23, x9
.Lssa_http____query_ok_11:
    cmp x23, x20
    b.ge .Lssa_http____query_ok_9
.Lssa_http____query_ok_21:
    mov w9, w23
    cmp x9, x22
    b.lo .Lssa_http____query_ok_28
.Lssa_http____query_ok_26:
    bl __fern_oob_abort
.Lssa_http____query_ok_28:
    ldrb w24, [x21, x9]
    cmp x24, #37
    b.ne .Lssa_http____query_ok_17
.Lssa_http____query_ok_20:
    mov x0, x19
    mov x9, x23
    mov x10, x20
    bl __fn_http____pct_byte.r
    cmp x0, #0
    b.lt .Lssa_http____query_ok_8
.Lssa_http____query_ok_18:
    add x9, x23, #3
    sxtw x9, w9
    mov x23, x9
    b .Lssa_http____query_ok_11
.Lssa_http____query_ok_17:
    mov x0, x24
    bl __fn_http____is_pchar.r
    cbnz x0, .Lssa_http____query_ok_13
.Lssa_http____query_ok_16:
    cmp x24, #47
    b.eq .Lssa_http____query_ok_13
.Lssa_http____query_ok_15:
    cmp x24, #63
    b.ne .Lssa_http____query_ok_7
.Lssa_http____query_ok_13:
    add x23, x23, #1
.Lssa_http____query_ok_12:
    cmp x23, x20
    b.lt .Lssa_http____query_ok_21
.Lssa_http____query_ok_9:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_8:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_7:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____pct_byte:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____pct_byte.k:
__fn_http____pct_byte.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
.Lssa_http____pct_byte_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa_http____pct_byte_2
.Lssa_http____pct_byte_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x11, [x9, #0]
    ldr x12, [x9, #8]
    mov x20, x11
    mov x21, x12
    b .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_2:
    add x12, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____pct_byte_5
.Lssa_http____pct_byte_4:
    ldr x11, [x0, #0]
    b .Lssa_http____pct_byte_6
.Lssa_http____pct_byte_5:
    mov x11, #0
.Lssa_http____pct_byte_6:
    mov x20, x12
    mov x21, x11
.Lssa_http____pct_byte_3:
    add x11, x19, #2
    sxtw x11, w11
    cmp x11, x10
    b.lt .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_13:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_11:
    add w11, w19, #1
    cmp x11, x21
    b.lo .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_18:
    bl __fern_oob_abort
.Lssa_http____pct_byte_20:
    ldrb w0, [x20, x11]
    bl __fn_http____hex_digit.r
    mov x22, x0
    add w19, w19, #2
    cmp x19, x21
    b.lo .Lssa_http____pct_byte_23
.Lssa_http____pct_byte_21:
    bl __fern_oob_abort
.Lssa_http____pct_byte_23:
    ldrb w0, [x20, x19]
    bl __fn_http____hex_digit.r
    cmp x22, #0
    b.lt .Lssa_http____pct_byte_9
.Lssa_http____pct_byte_10:
    cmp x0, #0
    b.ge .Lssa_http____pct_byte_7
.Lssa_http____pct_byte_9:
    mov x11, #-1
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_7:
    lsl x22, x22, #4
    add x22, x22, x0
    sxtw x0, w22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____plain_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____plain_path.k:
__fn_http____plain_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_http____plain_path_0:
    mov x9, #2
    and x9, x19, x9
    cbz x9, .Lssa_http____plain_path_2
.Lssa_http____plain_path_1:
    mov x9, #-2
    add x9, x19, x9
    ldr x10, [x9, #0]
    ldr x11, [x9, #8]
    mov x22, x10
    mov x23, x11
    b .Lssa_http____plain_path_3
.Lssa_http____plain_path_2:
    add x11, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____plain_path_5
.Lssa_http____plain_path_4:
    ldr x10, [x19, #0]
    b .Lssa_http____plain_path_6
.Lssa_http____plain_path_5:
    mov x10, #0
.Lssa_http____plain_path_6:
    mov x22, x11
    mov x23, x10
.Lssa_http____plain_path_3:
    add x10, x20, #1
    sxtw x9, w10
.Lssa_http____plain_path_10:
    mov x24, x9
    mov x25, x20
.Lssa_http____plain_path_11:
    cmp x25, x21
    b.ge .Lssa_http____plain_path_9
.Lssa_http____plain_path_20:
    mov w9, w25
    cmp x9, x23
    b.lo .Lssa_http____plain_path_27
.Lssa_http____plain_path_25:
    bl __fern_oob_abort
.Lssa_http____plain_path_27:
    ldrb w26, [x22, x9]
    cmp x26, #47
    b.ne .Lssa_http____plain_path_15
.Lssa_http____plain_path_19:
    cmp x25, x20
    b.le .Lssa_http____plain_path_16
.Lssa_http____plain_path_18:
    mov x0, x19
    mov x9, x24
    mov x10, x25
    bl __fn_http____dot_segment.r
    cmp x0, #0
    b.gt .Lssa_http____plain_path_8
.Lssa_http____plain_path_16:
    add x9, x25, #1
    mov x24, x9
    b .Lssa_http____plain_path_12
.Lssa_http____plain_path_15:
    cmp x26, #37
    b.eq .Lssa_http____plain_path_7
.Lssa_http____plain_path_14:
    mov x0, x26
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____plain_path_7
.Lssa_http____plain_path_13:
.Lssa_http____plain_path_12:
    add x25, x25, #1
    cmp x25, x21
    b.lt .Lssa_http____plain_path_20
.Lssa_http____plain_path_9:
    mov x0, x19
    mov x9, x24
    mov x10, x21
    bl __fn_http____dot_segment.r
    cmp x0, #0
    cset x0, eq
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____plain_path_8:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____plain_path_7:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____dot_segment:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____dot_segment.k:
__fn_http____dot_segment.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____dot_segment_0:
    mov x11, #2
    and x11, x0, x11
    cbz x11, .Lssa_http____dot_segment_2
.Lssa_http____dot_segment_1:
    mov x11, #-2
    add x11, x0, x11
    ldr x12, [x11, #0]
    ldr x13, [x11, #8]
    mov x4, x12
    mov x12, x13
    mov x13, x4
    b .Lssa_http____dot_segment_3
.Lssa_http____dot_segment_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____dot_segment_5
.Lssa_http____dot_segment_4:
    ldr x12, [x0, #0]
    b .Lssa_http____dot_segment_3
.Lssa_http____dot_segment_5:
    mov x12, #0
.Lssa_http____dot_segment_6:
.Lssa_http____dot_segment_3:
    sub x11, x10, x9
    sxtw x0, w11
    cmp x0, #1
    b.lt .Lssa_http____dot_segment_8
.Lssa_http____dot_segment_11:
    cmp x0, #2
    b.gt .Lssa_http____dot_segment_8
.Lssa_http____dot_segment_10:
    mov w9, w9
    cmp x9, x12
    b.lo .Lssa_http____dot_segment_22
.Lssa_http____dot_segment_20:
    bl __fern_oob_abort
.Lssa_http____dot_segment_22:
    ldrb w11, [x13, x9]
    cmp x11, #46
    b.ne .Lssa_http____dot_segment_8
.Lssa_http____dot_segment_9:
    sub w10, w10, #1
    cmp x10, x12
    b.lo .Lssa_http____dot_segment_29
.Lssa_http____dot_segment_27:
    bl __fern_oob_abort
.Lssa_http____dot_segment_29:
    ldrb w12, [x13, x10]
    cmp x12, #46
    b.eq .Lssa_http____dot_segment_7
.Lssa_http____dot_segment_8:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____dot_segment_7:
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____decoded_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____decoded_path.k:
__fn_http____decoded_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #96
    str x0, [sp, #88]
    mov x20, x10
    str x11, [sp, #80]
.Lssa_http____decoded_path_0:
    mov x10, #2
    ldr x4, [sp, #88]
    and x10, x4, x10
    cbz x10, .Lssa_http____decoded_path_2
.Lssa_http____decoded_path_1:
    mov x10, #-2
    ldr x4, [sp, #88]
    add x10, x4, x10
    ldr x11, [x10, #0]
    ldr x12, [x10, #8]
    mov x22, x11
    mov x23, x12
    b .Lssa_http____decoded_path_3
.Lssa_http____decoded_path_2:
    ldr x4, [sp, #88]
    add x12, x4, #8
    cmp x4, #0
    b.eq .Lssa_http____decoded_path_5
.Lssa_http____decoded_path_4:
    ldr x4, [sp, #88]
    ldr x11, [x4, #0]
    b .Lssa_http____decoded_path_6
.Lssa_http____decoded_path_5:
    mov x11, #0
.Lssa_http____decoded_path_6:
    mov x22, x12
    mov x23, x11
.Lssa_http____decoded_path_3:
    adrp x0, .K4
    add x0, x0, :lo12:.K4
    add x9, x9, #1
    sxtw x9, w9
.Lssa_http____decoded_path_14:
    mov x24, x0
    mov x28, x9
    mov x25, #0
    mov x27, #0
    str xzr, [sp, #72]
.Lssa_http____decoded_path_15:
    cmp x28, x20
    b.gt .Lssa_http____decoded_path_13
.Lssa_http____decoded_path_35:
    mov x10, #47
    mov x0, x24
    mov x9, x25
    bl __fn_http____put_byte.r
    mov x21, x0
    mov x0, x24
    bl __fn___fern_arr_dec.r
    add x10, x25, #1
    sxtw x9, w10
.Lssa_http____decoded_path_34:
    mov x24, x21
    mov x21, x9
.Lssa_http____decoded_path_40:
    cmp x28, x20
    b.ge .Lssa_http____decoded_path_33
.Lssa_http____decoded_path_52:
    mov w9, w28
    cmp x9, x23
    b.lo .Lssa_http____decoded_path_59
.Lssa_http____decoded_path_57:
    bl __fern_oob_abort
.Lssa_http____decoded_path_59:
    ldrb w26, [x22, x9]
    cmp x26, #47
    b.eq .Lssa_http____decoded_path_33
.Lssa_http____decoded_path_51:
    ldr x0, [sp, #88]
    mov x9, x28
    mov x10, x20
    bl __fn_http____path_byte.r
    mov x9, x0
    cmp x9, #0
    b.ge .Lssa_http____decoded_path_49
.Lssa_http____decoded_path_64:
    str x9, [sp, #64]
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    b .Lssa_http____decoded_path_10
.Lssa_http____decoded_path_49:
    mov x10, #1
    cmp x9, #128
    cset x11, ge
    cmp x27, #0
    csel x27, x10, x11, ne
    and x10, x9, #255
    mov x0, x24
    mov x9, x21
    bl __fn_http____put_byte.r
    mov x19, x0
    mov x0, x24
    bl __fn___fern_arr_dec.r
    add x10, x21, #1
    sxtw x21, w10
.Lssa_http____decoded_path_45:
    mov x10, #3
    mov x9, #1
    cmp x26, #37
    csel x10, x10, x9, eq
    add x10, x28, x10
    sxtw x28, w10
    mov x24, x19
    cmp x28, x20
    b.lt .Lssa_http____decoded_path_52
.Lssa_http____decoded_path_33:
    cmp x28, x20
    cset x19, eq
    add x10, x25, #1
    sxtw x9, w10
    mov x0, x24
    mov x10, x21
    bl __fn_http____dot_segment.r
    cmp x0, #0
    b.ne .Lssa_http____decoded_path_30
.Lssa_http____decoded_path_32:
    mov x25, x21
    str xzr, [sp, #72]
    b .Lssa_http____decoded_path_16
.Lssa_http____decoded_path_30:
    cmp x0, #1
    b.ne .Lssa_http____decoded_path_27
.Lssa_http____decoded_path_29:
    b .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_27:
    cmp x25, #0
    b.ne .Lssa_http____decoded_path_24
.Lssa_http____decoded_path_26:
    mov x9, #-1
    mov x25, x9
    b .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_24:
    sub x9, x25, #1
    sxtw x9, w9
.Lssa_http____decoded_path_23:
    mov x21, x9
.Lssa_http____decoded_path_95:
    ldr x6, [x24]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, x21
    ldrb w9, [x5, #8]
    cmp x9, #47
    b.eq .Lssa_http____decoded_path_22
.Lssa_http____decoded_path_96:
    sub x9, x21, #1
    sxtw x21, w9
    b .Lssa_http____decoded_path_95
.Lssa_http____decoded_path_22:
    cbz x27, .Lssa_http____decoded_path_20
.Lssa_http____decoded_path_21:
    mov x0, x24
    mov x9, x21
    mov x10, x25
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x26, x0
.Lssa_http____decoded_path_107:
    mov x0, x26
    bl __fn_utf8__is_valid.r
    mov x9, x0
    str x9, [sp, #64]
    mov x0, x26
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    cbz x9, .Lssa_http____decoded_path_19
.Lssa_http____decoded_path_20:
    mov x25, x21
    b .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_19:
    mov x9, #-1
    mov x25, x9
.Lssa_http____decoded_path_18:
    cmp x25, #0
    b.ge .Lssa_http____decoded_path_17
.Lssa_http____decoded_path_114:
    mov x0, x24
    bl __fn___fern_arr_dec.r
    b .Lssa_http____decoded_path_9
.Lssa_http____decoded_path_17:
    str x19, [sp, #72]
.Lssa_http____decoded_path_16:
    add x28, x28, #1
    sxtw x28, w28
    cmp x28, x20
    b.le .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_13:
    mov x0, x24
    mov x9, x25
    ldr x10, [sp, #72]
    mov x11, x27
    ldr x12, [sp, #88]
    mov x13, x20
    ldr x14, [sp, #80]
    bl __fn_http____finished_path.r
    mov x28, x0
    mov x25, x1
    mov x0, x24
    bl __fn___fern_arr_dec.r
    cmp x28, #0
    b.ne .Lssa_http____decoded_path_7
.Lssa_http____decoded_path_11:
    mov x1, x25
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_10:
    mov x9, #400
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_9:
    mov x9, #400
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_7:
    mov x1, x25
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____path_byte:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____path_byte.k:
__fn_http____path_byte.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_http____path_byte_0:
    mov x11, #2
    and x11, x0, x11
    cbz x11, .Lssa_http____path_byte_2
.Lssa_http____path_byte_1:
    mov x11, #-2
    add x11, x0, x11
    ldr x12, [x11, #0]
    ldr x13, [x11, #8]
    mov x4, x12
    mov x12, x13
    mov x13, x4
    b .Lssa_http____path_byte_3
.Lssa_http____path_byte_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____path_byte_5
.Lssa_http____path_byte_4:
    ldr x12, [x0, #0]
    b .Lssa_http____path_byte_3
.Lssa_http____path_byte_5:
    mov x12, #0
.Lssa_http____path_byte_6:
.Lssa_http____path_byte_3:
    mov w11, w9
    cmp x11, x12
    b.lo .Lssa_http____path_byte_19
.Lssa_http____path_byte_17:
    bl __fern_oob_abort
.Lssa_http____path_byte_19:
    ldrb w19, [x13, x11]
    cmp x19, #37
    b.ne .Lssa_http____path_byte_9
.Lssa_http____path_byte_16:
    bl __fn_http____pct_byte.r
    cmp x0, #0
    b.le .Lssa_http____path_byte_12
.Lssa_http____path_byte_15:
    cmp x0, #47
    b.eq .Lssa_http____path_byte_12
.Lssa_http____path_byte_14:
    cmp x0, #63
    b.eq .Lssa_http____path_byte_12
.Lssa_http____path_byte_13:
    cmp x0, #35
    b.ne .Lssa_http____path_byte_11
.Lssa_http____path_byte_12:
    mov x10, #-1
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_byte_11:
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_byte_9:
    mov x0, x19
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____path_byte_7
.Lssa_http____path_byte_8:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_byte_7:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____finished_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
    ldr x13, [sp, #80]
    ldr x14, [sp, #96]
__fn_http____finished_path.k:
__fn_http____finished_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x11
    mov x22, x13
    mov x23, x14
.Lssa_http____finished_path_0:
    mov x9, #2
    and x9, x12, x9
    cbz x9, .Lssa_http____finished_path_2
.Lssa_http____finished_path_1:
    mov x9, #-2
    add x9, x12, x9
    ldr x11, [x9, #0]
    ldr x13, [x9, #8]
    mov x24, x11
    mov x25, x13
    b .Lssa_http____finished_path_3
.Lssa_http____finished_path_2:
    add x13, x12, #8
    cmp x12, #0
    b.eq .Lssa_http____finished_path_5
.Lssa_http____finished_path_4:
    ldr x11, [x12, #0]
    b .Lssa_http____finished_path_6
.Lssa_http____finished_path_5:
    mov x11, #0
.Lssa_http____finished_path_6:
    mov x24, x13
    mov x25, x11
.Lssa_http____finished_path_3:
    cmp x20, #0
    b.eq .Lssa_http____finished_path_15
.Lssa_http____finished_path_16:
    cbz x10, .Lssa_http____finished_path_14
.Lssa_http____finished_path_15:
    mov x10, #47
    mov x0, x19
    mov x9, x20
    bl __fn_http____put_byte.r
    mov x26, x0
    cmp x26, x19
    b.ne .Lssa_http____finished_path_27
.Lssa_http____finished_path_25:
    mov x0, x26
    bl __fn___fern_arr_dec.r
.Lssa_http____finished_path_27:
    add x10, x20, #1
    sxtw x9, w10
    mov x20, x9
    b .Lssa_http____finished_path_29
.Lssa_http____finished_path_14:
    mov x26, x19
.Lssa_http____finished_path_13:
.Lssa_http____finished_path_12:
.Lssa_http____finished_path_29:
    cmp x22, x23
    b.ge .Lssa_http____finished_path_11
.Lssa_http____finished_path_30:
    mov w9, w22
    cmp x9, x25
    b.lo .Lssa_http____finished_path_37
.Lssa_http____finished_path_35:
    bl __fern_oob_abort
.Lssa_http____finished_path_37:
    ldrb w10, [x24, x9]
    mov x0, x26
    mov x9, x20
    bl __fn_http____put_byte.r
    mov x27, x0
    cmp x27, x19
    b.ne .Lssa_http____finished_path_40
.Lssa_http____finished_path_38:
    mov x0, x27
    bl __fn___fern_arr_dec.r
.Lssa_http____finished_path_40:
    cmp x26, x19
    b.eq .Lssa_http____finished_path_43
.Lssa_http____finished_path_41:
    mov x0, x26
    bl __fn___fern_arr_dec.r
.Lssa_http____finished_path_43:
    add x10, x20, #1
    sxtw x20, w10
    add x22, x22, #1
    mov x26, x27
    cmp x22, x23
    b.lt .Lssa_http____finished_path_30
.Lssa_http____finished_path_11:
    mov x10, #0
    mov x0, x26
    mov x9, x10
    mov x10, x20
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x22, x0
.Lssa_http____finished_path_46:
    cmp x26, x19
    b.eq .Lssa_http____finished_path_50
.Lssa_http____finished_path_48:
    mov x0, x26
    bl __fn___fern_arr_dec.r
.Lssa_http____finished_path_50:
    cbz x21, .Lssa_http____finished_path_8
.Lssa_http____finished_path_10:
    mov x0, x22
    bl __fn_utf8__is_valid.r
    cbnz x0, .Lssa_http____finished_path_8
.Lssa_http____finished_path_56:
    mov x0, x22
    bl __fn___fern_str_free.r
    b .Lssa_http____finished_path_7
.Lssa_http____finished_path_8:
    mov x1, x22
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____finished_path_7:
    mov x10, #400
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____put_byte:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____put_byte.k:
__fn_http____put_byte.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_http____put_byte_0:
    ldr x9, [x19, #0]
    cmp x20, x9
    b.ge .Lssa_http____put_byte_1
.Lssa_http____put_byte_3:
    tst x19, #1
    b.ne .Lssa_http____put_byte_uq3
    cmp x19, #16, lsl #12
    b.lo .Lssa_http____put_byte_uq3
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_http____put_byte_uq3:
    b.ne .Lssa_http____put_byte_9
.Lssa_http____put_byte_8:
    mov x22, x19
    b .Lssa_http____put_byte_10
.Lssa_http____put_byte_9:
    mov x9, #0
    ldr x10, [x19, #0]
    mov x0, x19
    bl __fn___fern_arr_slice_u8.r
    mov x22, x0
.Lssa_http____put_byte_10:
    ldr x7, [x22]
    cmp x20, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x20
    strb w21, [x5, #8]
    cmp x22, x19
    b.ne .Lssa_http____put_byte_13
.Lssa_http____put_byte_11:
    str x22, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_http____put_byte_13:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____put_byte_1:
    mov x0, x19
    mov x1, x21
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http____put_byte_apush19s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http____put_byte_apush19o
    tbz w3, #31, .Lssa_http____put_byte_apush19s
.Lssa_http____put_byte_apush19o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http____put_byte_apush19e
.Lssa_http____put_byte_apush19s:
    bl __fern_arr_push_u8
.Lssa_http____put_byte_apush19e:
    mov x22, x0
    cmp x22, x19
    b.ne .Lssa_http____put_byte_16
.Lssa_http____put_byte_14:
    str x22, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_http____put_byte_16:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____is_digit:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____is_digit.k:
__fn_http____is_digit.r:
.Lssa_http____is_digit_0:
    cmp x0, #57
    cset x9, ls
    mov x10, #0
    cmp x0, #48
    csel x0, x9, x10, hs
    ret
    .cfi_endproc
    .ltorg
__fn_http__serialize_response_to:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http__serialize_response_to.k:
__fn_http__serialize_response_to.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #16
    str x0, [sp, #8]
    mov x20, x9
    mov x21, x10
    str x11, [sp, #0]
.Lssa_http__serialize_response_to_0:
    str x21, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_http__serialize_response_to_55:
.Lssa_http__serialize_response_to_56:
    ldr x0, [x21, #24]
    bl __fn_http__fields_ok.r
    cbnz x0, .Lssa_http__serialize_response_to_58
.Lssa_http__serialize_response_to_60:
    mov x0, x21
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_http__serialize_response_to_57
.Lssa_http__serialize_response_to_58:
    ldr x0, [x21, #32]
    bl __fn_http__fields_ok.r
    cbnz x0, .Lssa_http__serialize_response_to_53
.Lssa_http__serialize_response_to_64:
    mov x0, x21
    bl __fn___sem_release_HttpResponse.r
.Lssa_http__serialize_response_to_57:
    adrp x21, .K7
    add x21, x21, :lo12:.K7
    b .Lssa_http__serialize_response_to_56
.Lssa_http__serialize_response_to_53:
    ldr x23, [x21, #8]
.Lssa_http__serialize_response_to_52:
    cmp x23, #200
    b.lt .Lssa_http__serialize_response_to_48
.Lssa_http__serialize_response_to_50:
    cmp x23, #204
    b.ne .Lssa_http__serialize_response_to_47
.Lssa_http__serialize_response_to_48:
    mov x24, #1
    b .Lssa_http__serialize_response_to_45
.Lssa_http__serialize_response_to_47:
    cmp x23, #304
    cset x9, eq
    mov x24, x9
.Lssa_http__serialize_response_to_46:
.Lssa_http__serialize_response_to_45:
    adrp x9, .SB8
    add x9, x9, :lo12:.SB8
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    cbz x24, .Lssa_http__serialize_response_to_43
.Lssa_http__serialize_response_to_44:
    mov x26, x9
    mov x25, x10
    b .Lssa_http__serialize_response_to_42
.Lssa_http__serialize_response_to_43:
    mov x0, x21
    bl __fn_HttpResponse__body_text_lossy.r
    mov x25, x0
    adrp x26, .SB9
    add x26, x26, :lo12:.SB9
    ldr x0, [x25, #8]
    bl __fn_int__int_to_string.r
    mov x27, x0
    mov x0, x26
    mov x9, x27
    bl __fn___fern_str_concat.r
    mov x28, x0
    mov x0, x27
    bl __fn___fern_str_free.r
    adrp x27, .SB10
    add x27, x27, :lo12:.SB10
    str x28, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_http__serialize_response_to_85
.Lssa_http__serialize_response_to_84:
    mov x26, x28
    b .Lssa_http__serialize_response_to_42
.Lssa_http__serialize_response_to_85:
    str x28, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x26, x0
    mov x0, x28
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_86:
.Lssa_http__serialize_response_to_42:
    mov x10, #256
    mov x0, x10
    bl __fern_buf_new
    mov x27, x0
.Lssa_http__serialize_response_to_40:
    adrp x10, .SB11
    add x10, x10, :lo12:.SB11
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push
    sxtw x28, w23
.Lssa_http__serialize_response_to_39:
    cmp x28, #0
    b.ge .Lssa_http__serialize_response_to_36
.Lssa_http__serialize_response_to_38:
    mov x10, #45
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push_byte
    mov x10, #0
    sub x10, x10, x28
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push_decimal
    b .Lssa_http__serialize_response_to_35
.Lssa_http__serialize_response_to_36:
    mov x0, x27
    mov x1, x28
    bl __fern_buf_push_decimal
.Lssa_http__serialize_response_to_35:
    adrp x10, .SB12
    add x10, x10, :lo12:.SB12
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push
.Lssa_http__serialize_response_to_33:
    adrp x10, .K8
    add x10, x10, :lo12:.K8
    adrp x9, .K9
    add x9, x9, :lo12:.K9
.Lssa_http__serialize_response_to_32:
    mov x11, #0
.Lssa_http__serialize_response_to_92:
    ldr x12, [x10, #0]
    cmp x11, x12
    b.ge .Lssa_http__serialize_response_to_31
.Lssa_http__serialize_response_to_95:
    add x5, x11, #1
    ldr x12, [x10, x5, lsl #3]
    cmp x12, x23
    b.eq .Lssa_http__serialize_response_to_30
.Lssa_http__serialize_response_to_93:
    add x11, x11, #1
    b .Lssa_http__serialize_response_to_92
.Lssa_http__serialize_response_to_31:
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    mov x28, x10
    b .Lssa_http__serialize_response_to_29
.Lssa_http__serialize_response_to_30:
    ldr x6, [x9]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x28, [x9, x5, lsl #3]
    str x28, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_http__serialize_response_to_29:
    ldr x11, [x28, #8]
    cmp x11, #0
    b.ne .Lssa_http__serialize_response_to_26
.Lssa_http__serialize_response_to_107:
    mov x0, x28
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_28:
    adrp x11, .SB63
    add x11, x11, :lo12:.SB63
    mov x28, x11
.Lssa_http__serialize_response_to_27:
.Lssa_http__serialize_response_to_26:
    mov x0, x27
    mov x1, x28
    bl __fern_buf_push
    mov x0, x28
    bl __fn___fern_str_free.r
    adrp x11, .SB10
    add x11, x11, :lo12:.SB10
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
.Lssa_http__serialize_response_to_25:
    mov x28, #0
.Lssa_http__serialize_response_to_112:
    ldr x11, [x21, #24]
    ldr x9, [x11, #8]
    ldr x11, [x9, #0]
    cmp x28, x11
    b.lt .Lssa_http__serialize_response_to_118
.Lssa_http__serialize_response_to_120:
    mov x0, x21
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_http__serialize_response_to_23
.Lssa_http__serialize_response_to_118:
    ldr x22, [x21, #24]
    ldr x11, [x22, #8]
    add x5, x28, #1
    ldr x19, [x11, x5, lsl #3]
    adrp x9, .SB64
    add x9, x9, :lo12:.SB64
    mov x0, x19
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http__serialize_response_to_113
.Lssa_http__serialize_response_to_117:
    adrp x9, .SB65
    add x9, x9, :lo12:.SB65
    mov x0, x19
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http__serialize_response_to_113
.Lssa_http__serialize_response_to_116:
    adrp x9, .SB66
    add x9, x9, :lo12:.SB66
    mov x0, x19
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http__serialize_response_to_113
.Lssa_http__serialize_response_to_114:
    ldr x9, [x22, #8]
    add x5, x28, #1
    ldr x11, [x9, x5, lsl #3]
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    adrp x11, .SB67
    add x11, x11, :lo12:.SB67
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    ldr x11, [x22, #16]
    ldr x6, [x11]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x9, [x11, x5, lsl #3]
    mov x0, x27
    mov x1, x9
    bl __fern_buf_push
    adrp x9, .SB10
    add x9, x9, :lo12:.SB10
    mov x0, x27
    mov x1, x9
    bl __fern_buf_push
.Lssa_http__serialize_response_to_113:
    add x28, x28, #1
    b .Lssa_http__serialize_response_to_112
.Lssa_http__serialize_response_to_23:
    mov x0, x27
    mov x1, x26
    bl __fern_buf_push
    mov x0, x26
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_22:
    cmp x23, #101
    b.ne .Lssa_http__serialize_response_to_18
.Lssa_http__serialize_response_to_21:
    adrp x9, .SB68
    add x9, x9, :lo12:.SB68
    mov x0, x27
    mov x1, x9
    bl __fern_buf_push
    b .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_18:
    ldr x4, [sp, #0]
    cbz x4, .Lssa_http__serialize_response_to_13
.Lssa_http__serialize_response_to_15:
    ldr x9, [x20, #8]
    cmp x9, #8
    b.ne .Lssa_http__serialize_response_to_8
.Lssa_http__serialize_response_to_14:
    ldr x9, [x20, #0]
    ldrb w11, [x9, #7]
    cmp x11, #48
    b.ne .Lssa_http__serialize_response_to_8
    b .Lssa_http__serialize_response_to_10
.Lssa_http__serialize_response_to_13:
    adrp x11, .SB69
    add x11, x11, :lo12:.SB69
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    b .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_10:
    adrp x11, .SB70
    add x11, x11, :lo12:.SB70
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    b .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_8:
    adrp x11, .SB10
    add x11, x11, :lo12:.SB10
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
.Lssa_http__serialize_response_to_5:
    mov x0, x27
    bl __fern_buf_take
    mov x20, x0
    mov x0, x27
    bl __fern_buf_free
    cbz x24, .Lssa_http__serialize_response_to_4
.Lssa_http__serialize_response_to_158:
    mov x0, x25
    bl __fn___fern_str_free.r
    b .Lssa_http__serialize_response_to_3
.Lssa_http__serialize_response_to_4:
    adrp x11, .SB71
    add x11, x11, :lo12:.SB71
    ldr x4, [sp, #8]
    ldr x9, [x4, #8]
    cmp x9, #4
    b.ne .Lssa_http__serialize_response_to_1
.Lssa_http__serialize_response_to_162:
    ldr x4, [sp, #8]
    ldr x6, [x4, #8]
    ldr x7, [x11, #8]
    cmp x6, x7
    b.ne .Lssa_http__serialize_response_to_streqn449
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__serialize_response_to_streqn449
    ldr x0, [sp, #8]
    mov x9, x11
    bl __fn___fern_str_eq.r
    b .Lssa_http__serialize_response_to_streqd449
.Lssa_http__serialize_response_to_streqn449:
    mov x0, #0
.Lssa_http__serialize_response_to_streqd449:
    cbz x0, .Lssa_http__serialize_response_to_1
.Lssa_http__serialize_response_to_165:
    mov x0, x25
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_3:
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__serialize_response_to_1:
    str x20, [sp, #-16]!
    str x25, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_http__serialize_response_to_170
.Lssa_http__serialize_response_to_169:
    mov x27, x20
    b .Lssa_http__serialize_response_to_171
.Lssa_http__serialize_response_to_170:
    str x20, [sp, #-16]!
    str x25, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x27, x0
    mov x0, x20
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_171:
    mov x0, x25
    bl __fn___fern_str_free.r
    mov x0, x27
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_HttpResponse__body_text_lossy:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_HttpResponse__body_text_lossy.k:
__fn_HttpResponse__body_text_lossy.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_HttpResponse__body_text_lossy_0:
    ldr x9, [x0, #16]
    ldr x10, [x9, #0]
    adrp x11, .S7
    add x11, x11, :lo12:.S7
    cmp x10, x11
    b.ne .Lssa_HttpResponse__body_text_lossy_1
.Lssa_HttpResponse__body_text_lossy_2:
    ldr x19, [x9, #8]
    str x19, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_HttpResponse__body_text_lossy_1:
    mov x9, #134
    mov x0, x9
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____lists_token:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____lists_token.k:
__fn_http____lists_token.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____lists_token_0:
    ldr x21, [x19, #8]
.Lssa_http____lists_token_3:
    mov x9, #0
.Lssa_http____lists_token_4:
    cmp x9, x21
    b.gt .Lssa_http____lists_token_2
.Lssa_http____lists_token_8:
    mov x22, x9
.Lssa_http____lists_token_14:
    cmp x22, x21
    b.ge .Lssa_http____lists_token_7
.Lssa_http____lists_token_16:
    ldr x6, [x19, #8]
    cmp x22, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x22]
    cmp x10, #44
    b.eq .Lssa_http____lists_token_7
.Lssa_http____lists_token_15:
    add x22, x22, #1
    cmp x22, x21
    b.lt .Lssa_http____lists_token_16
.Lssa_http____lists_token_7:
    mov x0, x19
    mov x10, x22
    mov x11, x20
    bl __fn_http____token_at.r
    cbnz x0, .Lssa_http____lists_token_1
.Lssa_http____lists_token_5:
    add x22, x22, #1
    sxtw x9, w22
    cmp x9, x21
    b.le .Lssa_http____lists_token_8
.Lssa_http____lists_token_2:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____lists_token_1:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http__fields_ok:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http__fields_ok.k:
__fn_http__fields_ok.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa_http__fields_ok_0:
.Lssa_http__fields_ok_3:
    mov x20, #0
.Lssa_http__fields_ok_4:
    ldr x9, [x19, #8]
    ldr x10, [x9, #0]
    cmp x20, x10
    b.ge .Lssa_http__fields_ok_2
.Lssa_http__fields_ok_13:
    ldr x10, [x19, #8]
    add x5, x20, #1
    ldr x21, [x10, x5, lsl #3]
.Lssa_http__fields_ok_11:
    ldr x10, [x21, #8]
    cmp x10, #0
    b.le .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_10:
    adrp x10, .K2
    add x10, x10, :lo12:.K2
    mov x9, #0
    mov x2, x10
    mov x1, x9
    mov x0, x21
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x1, #0
    b.ge .L68
    mov x1, #0
.L68:
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L71
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L69:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L70
    add x5, x5, #16
    cmp x5, x8
    b.ls .L69
    sub x1, x5, x0
    b .L71
.L70:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L72
.L71:
    add x10, x9, #96
.L75:
    cmp x1, x3
    b.ge .L73
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L72
    add x1, x1, #1
    b .L75
.L72:
    str x1, [sp, #-16]!
    b .L74
.L73:
    str x3, [sp, #-16]!
.L74:
    ldr x0, [sp], #16
    ldr x9, [x21, #8]
    cmp x0, x9
    b.ne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_7:
    ldr x9, [x19, #16]
    ldr x6, [x9]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, #1
    ldr x21, [x9, x5, lsl #3]
    adrp x9, .K3
    add x9, x9, :lo12:.K3
    mov x10, #0
    mov x2, x9
    mov x1, x10
    mov x0, x21
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x1, #0
    b.ge .L76
    mov x1, #0
.L76:
    adrp x9, .S2
    add x9, x9, :lo12:.S2
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L79
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L77:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L78
    add x5, x5, #16
    cmp x5, x8
    b.ls .L77
    sub x1, x5, x0
    b .L79
.L78:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L80
.L79:
    add x10, x9, #96
.L83:
    cmp x1, x3
    b.ge .L81
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L80
    add x1, x1, #1
    b .L83
.L80:
    str x1, [sp, #-16]!
    b .L82
.L81:
    str x3, [sp, #-16]!
.L82:
    ldr x0, [sp], #16
    ldr x10, [x21, #8]
    cmp x0, x10
    b.ne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_5:
    add x20, x20, #1
    b .Lssa_http__fields_ok_4
.Lssa_http__fields_ok_2:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__fields_ok_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_fnv_str_seeded:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_fnv_str_seeded.k:
__fn___map_fnv_str_seeded.r:
.Lssa___map_fnv_str_seeded_0:
    ldr x10, =2166136261
    mov w9, w9
    eor x10, x10, x9
    ldr x9, =16777619
    ldr x11, [x0, #8]
.Lssa___map_fnv_str_seeded_4:
    mov x12, #0
.Lssa___map_fnv_str_seeded_5:
    add x13, x12, #4
    sxtw x13, w13
    cmp x13, x11
    b.gt .Lssa___map_fnv_str_seeded_13
.Lssa___map_fnv_str_seeded_6:
    add x13, x12, #3
    sxtw x13, w13
    asr x14, x12, #31
    orr x13, x13, x14
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x14, [x0, #0]
    add x14, x14, x12
    ldrsw x14, [x14]
    eor x14, x10, x14
    ldr x13, =16777619
    mul w10, w14, w13
    add x14, x12, #4
    sxtw x12, w14
    b .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmp x12, x11
    b.ge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
    eor x14, x10, x14
    mul w10, w14, w9
    add x12, x12, #1
    cmp x12, x11
    b.lt .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    lsr x12, x10, #16
    eor x10, x10, x12
    ldr x12, =2246822507
    mul w10, w10, w12
    lsr x12, x10, #13
    eor x10, x10, x12
    ldr x12, =3266489909
    mul w10, w10, w12
    lsr x12, x10, #16
    eor x10, x10, x12
    sxtw x0, w10
    ret
    .cfi_endproc
    .ltorg
__fn_string____str_maxsuf:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_maxsuf.k:
__fn_string____str_maxsuf.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_string____str_maxsuf_0:
    mov x13, #-1
.Lssa_string____str_maxsuf_2:
    mov x19, x13
    mov x13, #0
    mov x14, #1
    mov x15, #1
.Lssa_string____str_maxsuf_3:
    add x1, x13, x14
    sxtw x1, w1
    cmp x1, x9
    b.ge .Lssa_string____str_maxsuf_1
.Lssa_string____str_maxsuf_16:
    add x1, x13, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w2, [x6, x1]
    add x1, x19, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w3, [x6, x1]
    cmp x10, #0
    csel x1, x3, x2, ne
    cmp x10, #0
    csel x2, x2, x3, ne
    cmp x1, x2
    b.ge .Lssa_string____str_maxsuf_11
.Lssa_string____str_maxsuf_12:
    add x3, x13, x14
    sxtw x3, w3
    sub x8, x3, x19
    sxtw x8, w8
    mov x13, x3
    mov x15, x8
    mov x14, #1
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_11:
    cmp x1, x2
    b.ne .Lssa_string____str_maxsuf_6
.Lssa_string____str_maxsuf_10:
    cmp x14, x15
    b.ne .Lssa_string____str_maxsuf_8
.Lssa_string____str_maxsuf_9:
    add x8, x13, x15
    sxtw x8, w8
    mov x13, x8
    mov x14, #1
    b .Lssa_string____str_maxsuf_7
.Lssa_string____str_maxsuf_8:
    add x14, x14, #1
    sxtw x14, w14
.Lssa_string____str_maxsuf_7:
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_string____str_maxsuf_5
.Lssa_string____str_maxsuf_6:
    add x14, x13, #1
    sxtw x14, w14
    mov x19, x13
    mov x13, #1
    mov x15, #1
.Lssa_string____str_maxsuf_5:
    mov x4, x14
    mov x14, x13
    mov x13, x4
.Lssa_string____str_maxsuf_4:
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_1:
    mov x1, x15
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string____str_find_from:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_find_from.k:
__fn_string____str_find_from.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
.Lssa_string____str_find_from_0:
    mov x9, #0
    cmp x12, #0
    csel x23, x9, x12, lt
    cmp x22, #0
    b.ne .Lssa_string____str_find_from_41
.Lssa_string____str_find_from_45:
    cmp x23, x20
    csel x0, x20, x23, gt
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_41:
    sub x9, x20, x23
    sxtw x9, w9
    cmp x22, x9
    b.le .Lssa_string____str_find_from_38
.Lssa_string____str_find_from_40:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_38:
    cmp x22, #1
    b.ne .Lssa_string____str_find_from_35
.Lssa_string____str_find_from_37:
    ldr x6, [x21, #8]
    cmp x6, #0
    b.hi 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w9, [x6, #0]
    mov x2, x23
    mov x1, x9
    mov x0, x19
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L84
    mov x2, #0
.L84:
    cmp x1, #255
    b.hi .L89
    cmp x2, x3
    b.ge .L89
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L86
.L85:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L91
    cmp x5, x8
    b.ls .L85
.L86:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L87
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L87
    sub x5, x5, #16
    b .L92
.L91:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L92
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L92:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L90
.L87:
    cmp x5, x6
    b.ge .L89
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L93
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L89
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L89
    add x5, x5, x4
    b .L88
.L93:
    cmp x5, x6
    b.ge .L89
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L88
    add x5, x5, #1
    b .L93
.L88:
    sub x2, x5, x0
    b .L90
.L89:
    mov x2, #-1
.L90:
    mov x0, x2
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_35:
    cmp x22, #4
    b.gt .Lssa_string____str_find_from_30
.Lssa_string____str_find_from_33:
    sub x9, x20, x22
    sxtw x9, w9
.Lssa_string____str_find_from_74:
    cmp x23, x9
    b.gt .Lssa_string____str_find_from_32
.Lssa_string____str_find_from_79:
.Lssa_string____str_find_from_78:
    mov x12, #0
.Lssa_string____str_find_from_84:
    cmp x12, x22
    b.ge .Lssa_string____str_find_from_77
.Lssa_string____str_find_from_86:
    add w10, w23, w12
    ldr x6, [x19, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w11, [x6, x10]
    ldr x6, [x21, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w10, [x6, x12]
    cmp x11, x10
    b.ne .Lssa_string____str_find_from_77
.Lssa_string____str_find_from_85:
    add x12, x12, #1
    cmp x12, x22
    b.lt .Lssa_string____str_find_from_86
.Lssa_string____str_find_from_77:
    cmp x12, x22
    b.eq .Lssa_string____str_find_from_26
.Lssa_string____str_find_from_75:
    add x12, x23, #1
    sxtw x23, w12
    cmp x23, x9
    b.le .Lssa_string____str_find_from_79
.Lssa_string____str_find_from_32:
    mov x0, #-1
    b .Lssa_string____str_find_from_25
.Lssa_string____str_find_from_30:
    mov x24, #0
    mov x25, #1
.Lssa_string____str_find_from_28:
    cmp x22, #3
    b.ge .Lssa_string____str_find_from_23
.Lssa_string____str_find_from_27:
    sub x12, x22, #1
    mov x28, x12
    mov x0, #1
    b .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_26:
    mov x0, x23
.Lssa_string____str_find_from_25:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_23:
    mov x10, #0
    mov x0, x21
    mov x9, x22
    mov x11, x24
    mov x12, x25
    bl __fn_string____str_maxsuf.r
    mov x26, x0
    mov x27, x1
    mov x10, #1
    mov x0, x21
    mov x9, x22
    mov x11, x24
    mov x12, x25
    bl __fn_string____str_maxsuf.r
    mov x28, x0
    mov x0, x1
    cmp x28, x26
    b.ge .Lssa_string____str_find_from_20
.Lssa_string____str_find_from_22:
    add x26, x26, #1
    sxtw x26, w26
    mov x28, x26
    mov x0, x27
    b .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_20:
    add x28, x28, #1
    sxtw x28, w28
.Lssa_string____str_find_from_19:
    sub x20, x20, x22
    sxtw x20, w20
.Lssa_string____str_find_from_18:
.Lssa_string____str_find_from_17:
    mov x10, #0
.Lssa_string____str_find_from_114:
    cmp x10, x28
    b.ge .Lssa_string____str_find_from_13
.Lssa_string____str_find_from_117:
    add w12, w0, w10
    ldr x6, [x21, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w9, [x6, x12]
    mov w12, w10
    ldr x6, [x21, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w11, [x6, x12]
    cmp x9, x11
    b.ne .Lssa_string____str_find_from_8
.Lssa_string____str_find_from_115:
    add x10, x10, #1
    cmp x10, x28
    b.lt .Lssa_string____str_find_from_117
.Lssa_string____str_find_from_13:
.Lssa_string____str_find_from_12:
    sub x10, x22, x0
    sxtw x10, w10
    mov x11, #0
.Lssa_string____str_find_from_133:
    cmp x23, x20
    b.gt .Lssa_string____str_find_from_11
.Lssa_string____str_find_from_145:
    cmp x11, x28
    csel x12, x11, x28, gt
.Lssa_string____str_find_from_155:
    cmp x12, x22
    b.ge .Lssa_string____str_find_from_141
.Lssa_string____str_find_from_157:
    mov w9, w12
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w13, [x6, x9]
    add w9, w12, w23
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w14, [x6, x9]
    cmp x13, x14
    b.ne .Lssa_string____str_find_from_141
.Lssa_string____str_find_from_156:
    add x12, x12, #1
    cmp x12, x22
    b.lt .Lssa_string____str_find_from_157
.Lssa_string____str_find_from_141:
    cmp x12, x22
    b.lt .Lssa_string____str_find_from_135
.Lssa_string____str_find_from_140:
    sub x14, x28, #1
    sxtw x14, w14
.Lssa_string____str_find_from_139:
.Lssa_string____str_find_from_172:
    cmp x14, x11
    b.lt .Lssa_string____str_find_from_138
.Lssa_string____str_find_from_174:
    ldr x6, [x21, #8]
    cmp x14, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w9, [x6, x14]
    add w13, w14, w23
    ldr x6, [x19, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x13]
    cmp x9, x15
    b.ne .Lssa_string____str_find_from_138
.Lssa_string____str_find_from_173:
    sub x15, x14, #1
    sxtw x14, w15
    cmp x14, x11
    b.ge .Lssa_string____str_find_from_174
.Lssa_string____str_find_from_138:
    cmp x14, x11
    b.lt .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_136:
    add x14, x23, x0
    sxtw x14, w14
    mov x23, x14
    mov x11, x10
    b .Lssa_string____str_find_from_133
.Lssa_string____str_find_from_135:
    sub x12, x12, x28
    add x12, x23, x12
    add x12, x12, #1
    sxtw x12, w12
    mov x23, x12
    mov x11, #0
.Lssa_string____str_find_from_134:
    cmp x23, x20
    b.le .Lssa_string____str_find_from_145
.Lssa_string____str_find_from_11:
    mov x0, #-1
    mov x23, x0
.Lssa_string____str_find_from_10:
    b .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_8:
    sub x11, x22, x28
    sxtw x11, w11
    sub x10, x22, x28
    cmp x11, x28
    csel x10, x10, x28, gt
    add x10, x10, #1
.Lssa_string____str_find_from_4:
.Lssa_string____str_find_from_199:
    cmp x23, x20
    b.gt .Lssa_string____str_find_from_3
.Lssa_string____str_find_from_208:
    mov x11, x28
.Lssa_string____str_find_from_214:
    cmp x11, x22
    b.ge .Lssa_string____str_find_from_207
.Lssa_string____str_find_from_216:
    mov w12, w11
    ldr x6, [x21, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w14, [x6, x12]
    add w12, w11, w23
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x12]
    cmp x14, x15
    b.ne .Lssa_string____str_find_from_207
.Lssa_string____str_find_from_215:
    add x11, x11, #1
    cmp x11, x22
    b.lt .Lssa_string____str_find_from_216
.Lssa_string____str_find_from_207:
    cmp x11, x22
    b.lt .Lssa_string____str_find_from_201
.Lssa_string____str_find_from_206:
    sub x15, x28, #1
    sxtw x15, w15
.Lssa_string____str_find_from_205:
.Lssa_string____str_find_from_231:
    cmp x15, #0
    b.lt .Lssa_string____str_find_from_204
.Lssa_string____str_find_from_233:
    ldr x6, [x21, #8]
    cmp x15, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w12, [x6, x15]
    add w14, w15, w23
    ldr x6, [x19, #8]
    cmp x14, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w13, [x6, x14]
    cmp x12, x13
    b.ne .Lssa_string____str_find_from_204
.Lssa_string____str_find_from_232:
    sub x13, x15, #1
    sxtw x15, w13
    cmp x15, #0
    b.ge .Lssa_string____str_find_from_233
.Lssa_string____str_find_from_204:
    cmp x15, #0
    b.lt .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_202:
    add x15, x23, x10
    sxtw x15, w15
    mov x23, x15
    b .Lssa_string____str_find_from_199
.Lssa_string____str_find_from_201:
    sub x11, x11, x28
    add x11, x23, x11
    add x11, x11, #1
    sxtw x11, w11
    mov x23, x11
.Lssa_string____str_find_from_200:
    cmp x23, x20
    b.le .Lssa_string____str_find_from_208
.Lssa_string____str_find_from_3:
    mov x0, #-1
    mov x23, x0
.Lssa_string____str_find_from_2:
.Lssa_string____str_find_from_1:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__split.k:
__fn_string__split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #144
    mov x19, x0
    mov x20, x9
.Lssa_string__split_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    adrp x23, .K0
    add x23, x23, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa_string__split_3
.Lssa_string__split_7:
    ldr x24, [x19, #8]
    adrp x0, .K0
    add x0, x0, :lo12:.K0
.Lssa_string__split_6:
    mov x25, x0
    mov x26, #0
.Lssa_string__split_13:
    cmp x26, x24
    b.ge .Lssa_string__split_5
.Lssa_string__split_14:
    mov x0, x19
    mov x9, x26
    mov x10, x24
    bl __fn_utf8_scalar__step.r
    add x0, x26, x0
    sxtw x27, w0
    mov x0, x19
    mov x1, x26
    mov x2, x27
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x28, x0
    adrp x9, .SB8
    add x9, x9, :lo12:.SB8
    mov x0, x28
    bl __fn___fern_str_concat.r
    mov x26, x0
    str x28, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x25
    mov x1, x26
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush73s
.Lssa_string__split_apush73o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush73e
.Lssa_string__split_apush73s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush73e:
    mov x25, x0
    mov x26, x27
    cmp x26, x24
    b.lt .Lssa_string__split_14
.Lssa_string__split_5:
    mov x0, x25
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string__split_3:
    mov x12, #0
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    bl __fn_string____str_find_from.r
.Lssa_string__split_2:
    mov x25, x0
    mov x12, #0
.Lssa_string__split_21:
    cmp x25, #0
    b.lt .Lssa_string__split_1
.Lssa_string__split_22:
    mov x0, x19
    mov x1, x12
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x9, .SB8
    add x9, x9, :lo12:.SB8
    mov x0, x26
    bl __fn___fern_str_concat.r
    mov x27, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x27
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush94s
.Lssa_string__split_apush94o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush94e
.Lssa_string__split_apush94s:
    str x12, [sp, #64]
    bl __fern_arr_push_owned
    ldr x12, [sp, #64]
.Lssa_string__split_apush94e:
    mov x23, x0
    add x25, x25, x22
    sxtw x25, w25
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    mov x12, x25
    bl __fn_string____str_find_from.r
    mov x12, x25
    mov x25, x0
    cmp x25, #0
    b.ge .Lssa_string__split_22
.Lssa_string__split_1:
    mov x0, x19
    mov x1, x12
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x25, x0
    adrp x12, .SB8
    add x12, x12, :lo12:.SB8
    mov x0, x25
    mov x9, x12
    bl __fn___fern_str_concat.r
    mov x21, x0
    str x25, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x21
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush102s
.Lssa_string__split_apush102o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush102e
.Lssa_string__split_apush102s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush102e:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__eq_ignore_ascii_case:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__eq_ignore_ascii_case.k:
__fn_string__eq_ignore_ascii_case.r:
.Lssa_string__eq_ignore_ascii_case_0:
    ldr x10, [x0, #8]
    ldr x11, [x9, #8]
    cmp x10, x11
    b.eq .Lssa_string__eq_ignore_ascii_case_4
.Lssa_string__eq_ignore_ascii_case_6:
    mov x0, #0
    ret
.Lssa_string__eq_ignore_ascii_case_4:
.Lssa_string__eq_ignore_ascii_case_3:
    mov x11, #0
.Lssa_string__eq_ignore_ascii_case_11:
    cmp x11, x10
    b.ge .Lssa_string__eq_ignore_ascii_case_2
.Lssa_string__eq_ignore_ascii_case_17:
    ldr x12, [x0, #0]
    ldrb w13, [x12, x11]
    ldr x6, [x9, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x9]
    ldrb w12, [x6, x11]
    eor x12, x13, x12
    cmp x12, #0
    b.eq .Lssa_string__eq_ignore_ascii_case_12
.Lssa_string__eq_ignore_ascii_case_16:
    cmp x12, #32
    b.ne .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_15:
    mov x12, #32
    orr x12, x13, x12
    cmp x12, #97
    b.lt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_14:
    mov x12, #32
    orr x13, x13, x12
    cmp x13, #122
    b.gt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_12:
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_string__eq_ignore_ascii_case_17
.Lssa_string__eq_ignore_ascii_case_2:
    mov x0, #1
    ret
.Lssa_string__eq_ignore_ascii_case_1:
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn_HeaderMap__append:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_HeaderMap__append.k:
__fn_HeaderMap__append.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_HeaderMap__append_0:
    tst x19, #1
    b.ne .Lssa_HeaderMap__append_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa_HeaderMap__append_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_HeaderMap__append_uq0:
    b.ne .Lssa_HeaderMap__append_2
.Lssa_HeaderMap__append_1:
    mov x22, x19
    b .Lssa_HeaderMap__append_3
.Lssa_HeaderMap__append_2:
    mov x22, #0
.Lssa_HeaderMap__append_3:
    ldr x23, [x19, #8]
    cmp x22, #0
    b.ne .Lssa_HeaderMap__append_6
.Lssa_HeaderMap__append_4:
    str x23, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_HeaderMap__append_6:
    str x20, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    tst x23, #1
    b.ne .Lssa_HeaderMap__append_uq6
    cmp x23, #16, lsl #12
    b.lo .Lssa_HeaderMap__append_uq6
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_HeaderMap__append_uq6:
    b.ne .Lssa_HeaderMap__append_8
.Lssa_HeaderMap__append_7:
    mov x0, x23
    mov x1, x20
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_HeaderMap__append_apush20s
.Lssa_HeaderMap__append_apush20o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_HeaderMap__append_apush20e
.Lssa_HeaderMap__append_apush20s:
    bl __fern_arr_push_owned
.Lssa_HeaderMap__append_apush20e:
    mov x24, x0
    b .Lssa_HeaderMap__append_9
.Lssa_HeaderMap__append_8:
    mov x0, x23
    mov x1, x20
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_HeaderMap__append_apush21s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_HeaderMap__append_apush21o
    tbz w3, #31, .Lssa_HeaderMap__append_apush21s
.Lssa_HeaderMap__append_apush21o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_HeaderMap__append_apush21e
.Lssa_HeaderMap__append_apush21s:
    bl __fern_arr_push
.Lssa_HeaderMap__append_apush21e:
    mov x24, x0
    mov x0, x23
    bl __fn___fern_arr_inc_elems.r
    mov x0, x23
    bl __fn___fern_arr_dec.r
.Lssa_HeaderMap__append_9:
    ldr x23, [x19, #16]
    cmp x22, #0
    b.ne .Lssa_HeaderMap__append_12
.Lssa_HeaderMap__append_10:
    str x23, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_HeaderMap__append_12:
    str x21, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    tst x23, #1
    b.ne .Lssa_HeaderMap__append_uq12
    cmp x23, #16, lsl #12
    b.lo .Lssa_HeaderMap__append_uq12
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_HeaderMap__append_uq12:
    b.ne .Lssa_HeaderMap__append_14
.Lssa_HeaderMap__append_13:
    mov x0, x23
    mov x1, x21
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_HeaderMap__append_apush31s
.Lssa_HeaderMap__append_apush31o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_HeaderMap__append_apush31e
.Lssa_HeaderMap__append_apush31s:
    bl __fern_arr_push_owned
.Lssa_HeaderMap__append_apush31e:
    mov x20, x0
    b .Lssa_HeaderMap__append_15
.Lssa_HeaderMap__append_14:
    mov x0, x23
    mov x1, x21
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_HeaderMap__append_apush32s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_HeaderMap__append_apush32o
    tbz w3, #31, .Lssa_HeaderMap__append_apush32s
.Lssa_HeaderMap__append_apush32o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_HeaderMap__append_apush32e
.Lssa_HeaderMap__append_apush32s:
    bl __fern_arr_push
.Lssa_HeaderMap__append_apush32e:
    mov x20, x0
    mov x0, x23
    bl __fn___fern_arr_inc_elems.r
    mov x0, x23
    bl __fn___fern_arr_dec.r
.Lssa_HeaderMap__append_15:
    cmp x22, #0
    b.ne .Lssa_HeaderMap__append_17
.Lssa_HeaderMap__append_16:
    mov x9, #3
    str x22, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x9, .S0
    add x9, x9, :lo12:.S0
    str x9, [x0, #0]
    mov x23, x0
    b .Lssa_HeaderMap__append_18
.Lssa_HeaderMap__append_17:
    mov x23, x22
.Lssa_HeaderMap__append_18:
    cmp x22, #0
    b.ne .Lssa_HeaderMap__append_21
.Lssa_HeaderMap__append_20:
    mov x0, x19
    bl __fn___sem_release_HeaderMap.r
.Lssa_HeaderMap__append_21:
    str x24, [x23, #8]
    str x20, [x23, #16]
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_io_buffered__BufBlock__drop:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_io_buffered__BufBlock__drop.k:
__fn_io_buffered__BufBlock__drop.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_io_buffered__BufBlock__drop_0:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fern_buf_free
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_json__JsonError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_json__JsonError__eq.k:
__fn_json__JsonError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_json__JsonError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_json__JsonError__eq_streqn22
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_json__JsonError__eq_streqd22
.Lssa_json__JsonError__eq_streqn22:
    mov x0, #0
.Lssa_json__JsonError__eq_streqd22:
    cbz x0, .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_9:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_6:
    ldr x9, [x19, #24]
    ldr x10, [x20, #24]
    cmp x9, x10
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_3:
    ldr x10, [x19, #32]
    ldr x9, [x20, #32]
    cmp x10, x9
    cset x0, eq
    b .Lssa_json__JsonError__eq_1
.Lssa_json__JsonError__eq_2:
    mov x0, #0
.Lssa_json__JsonError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8__is_valid:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_utf8__is_valid.k:
__fn_utf8__is_valid.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa_utf8__is_valid_0:
.Lssa_utf8__is_valid_21:
    ldr x20, [x19, #8]
.Lssa_utf8__is_valid_20:
    mov x21, #0
.Lssa_utf8__is_valid_22:
    cmp x21, x20
    b.ge .Lssa_utf8__is_valid_19
.Lssa_utf8__is_valid_70:
    ldr x6, [x19, #8]
    cmp x21, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w22, [x6, x21]
    cmp x22, #128
    b.ge .Lssa_utf8__is_valid_65
.Lssa_utf8__is_valid_69:
    mov x2, x21
    mov x0, x19
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L94
    mov x2, #0
.L94:
    cmp x2, x3
    b.ge .L99
    add x5, x0, x2
    add x6, x0, x3
.L95:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L97
    ld1 {v0.16b}, [x5]
    cmlt v0.16b, v0.16b, #0
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L96
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L100
.L96:
    add x5, x5, #16
    b .L95
.L97:
    cmp x5, x6
    b.ge .L99
    ldrb w4, [x5]
    tbnz w4, #7, .L98
    add x5, x5, #1
    b .L97
.L98:
    sub x2, x5, x0
    b .L100
.L99:
    mov x2, x3
.L100:
    mov x0, x2
    cmp x0, x20
    b.ge .Lssa_utf8__is_valid_18
.Lssa_utf8__is_valid_67:
    ldr x6, [x19, #8]
    cmp x0, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w9, [x6, x0]
    mov x21, x0
    mov x22, x9
.Lssa_utf8__is_valid_66:
.Lssa_utf8__is_valid_65:
    cmp x22, #192
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_64:
    cmp x22, #224
    b.ge .Lssa_utf8__is_valid_55
.Lssa_utf8__is_valid_63:
    add x9, x21, #1
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_61:
    add w9, w21, #1
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_60:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_58:
    sub x9, x22, #192
    lsl x9, x9, #6
    sxtw x9, w9
    sub x10, x10, #128
    sxtw x10, w10
    orr x9, x9, x10
    cmp x9, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_56:
    add x9, x21, #2
    sxtw x9, w9
    mov x21, x9
    b .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_55:
    cmp x22, #240
    b.ge .Lssa_utf8__is_valid_40
.Lssa_utf8__is_valid_54:
    add x9, x21, #2
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_52:
    add x9, x21, #1
    sxtw x9, w9
    add x10, x9, #1
    sxtw x10, w10
    asr x11, x9, #31
    orr x10, x10, x11
    ldr x6, [x19, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x11, [x19, #0]
    ldrb w10, [x11, x9]
    add x9, x21, #2
    sxtw x9, w9
    ldrb w12, [x11, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_51:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_49:
    cmp x12, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_48:
    cmp x12, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_46:
    sub x9, x22, #224
    lsl x9, x9, #12
    sxtw x9, w9
    sub x10, x10, #128
    lsl x10, x10, #6
    sxtw x10, w10
    orr x9, x9, x10
    sub x12, x12, #128
    sxtw x12, w12
    orr x9, x9, x12
    cmp x9, #2048
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_44:
    mov x12, #55296
    cmp x9, x12
    b.lt .Lssa_utf8__is_valid_41
.Lssa_utf8__is_valid_43:
    mov x12, #57343
    cmp x9, x12
    b.le .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_41:
    add x12, x21, #3
    sxtw x12, w12
    mov x21, x12
    b .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_40:
    cmp x22, #248
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_39:
    add x12, x21, #3
    sxtw x12, w12
    cmp x12, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_37:
    add x12, x21, #1
    sxtw x12, w12
    add x9, x12, #2
    sxtw x9, w9
    asr x10, x12, #31
    orr x9, x9, x10
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x10, [x19, #0]
    ldrb w9, [x10, x12]
    add x12, x21, #2
    sxtw x12, w12
    ldrb w11, [x10, x12]
    add x12, x21, #3
    sxtw x12, w12
    ldrb w13, [x10, x12]
    cmp x9, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_36:
    cmp x9, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_34:
    cmp x11, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_33:
    cmp x11, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_31:
    cmp x13, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_30:
    cmp x13, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_28:
    sub x22, x22, #240
    lsl x22, x22, #18
    sxtw x22, w22
    sub x9, x9, #128
    lsl x9, x9, #12
    sxtw x9, w9
    orr x22, x22, x9
    sub x11, x11, #128
    lsl x11, x11, #6
    sxtw x11, w11
    orr x22, x22, x11
    sub x13, x13, #128
    sxtw x13, w13
    orr x22, x22, x13
    movz x13, #1, lsl #16
    cmp x22, x13
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_26:
    movn w13, #65519, lsl #16
    cmp x22, x13
    b.gt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_24:
    add x13, x21, #4
    sxtw x13, w13
    mov x21, x13
.Lssa_utf8__is_valid_23:
    cmp x21, x20
    b.lt .Lssa_utf8__is_valid_70
.Lssa_utf8__is_valid_19:
    mov x21, x20
    b .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_18:
    mov x21, x20
.Lssa_utf8__is_valid_17:
.Lssa_utf8__is_valid_16:
.Lssa_utf8__is_valid_15:
.Lssa_utf8__is_valid_14:
.Lssa_utf8__is_valid_13:
.Lssa_utf8__is_valid_12:
.Lssa_utf8__is_valid_11:
.Lssa_utf8__is_valid_10:
.Lssa_utf8__is_valid_9:
.Lssa_utf8__is_valid_8:
.Lssa_utf8__is_valid_7:
.Lssa_utf8__is_valid_6:
.Lssa_utf8__is_valid_5:
.Lssa_utf8__is_valid_4:
.Lssa_utf8__is_valid_3:
.Lssa_utf8__is_valid_2:
.Lssa_utf8__is_valid_1:
    ldr x13, [x19, #8]
    cmp x21, x13
    cset x0, eq
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___primitive_i32_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_i32_to_string.k:
__fn___primitive_i32_to_string.r:
.Lssa___primitive_i32_to_string_0:
    b __fn_int__int_to_string.r
    .cfi_endproc
    .ltorg
__fn___primitive_i64_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_i64_to_string.k:
__fn___primitive_i64_to_string.r:
.Lssa___primitive_i64_to_string_0:
    cmp x0, #0
    b.ge .Lssa___primitive_i64_to_string_1
.Lssa___primitive_i64_to_string_3:
    mov x9, #0
    sub x9, x9, x0
    mov x10, #1
    mov x0, x9
    mov x9, x10
    b __fn_int____int_to_string_u64.r
.Lssa___primitive_i64_to_string_1:
    mov x9, #0
    b __fn_int____int_to_string_u64.r
    .cfi_endproc
    .ltorg
__fn_int__int_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_int__int_to_string.k:
__fn_int__int_to_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
.Lssa_int__int_to_string_0:
    cmp x0, #0
    b.lt .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_47:
    cmp x0, #100
    b.ge .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_46:
    adrp x9, .K10
    add x9, x9, :lo12:.K10
    ldr x6, [x9]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x0, #1
    ldr x19, [x9, x5, lsl #3]
    str x19, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_int__int_to_string_44:
    mov x9, #0
    mov x10, #0
    sub x10, x10, x0
    mov x11, #1
    cmp x0, #0
    csel x10, x10, x0, lt
    csel x19, x11, x9, lt
    mov w20, w10
.Lssa_int__int_to_string_40:
    cmp x20, #10
    b.hs .Lssa_int__int_to_string_37
.Lssa_int__int_to_string_39:
    mov x10, #1
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_37:
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_34
.Lssa_int__int_to_string_36:
    mov x10, #2
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_34:
    cmp x20, #1000
    b.hs .Lssa_int__int_to_string_31
.Lssa_int__int_to_string_33:
    mov x10, #3
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_31:
    mov x10, #10000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_28
.Lssa_int__int_to_string_30:
    mov x10, #4
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_28:
    ldr x10, =100000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_25
.Lssa_int__int_to_string_27:
    mov x10, #5
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_25:
    ldr x10, =1000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_22
.Lssa_int__int_to_string_24:
    mov x10, #6
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_22:
    ldr x10, =10000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_19
.Lssa_int__int_to_string_21:
    mov x10, #7
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_19:
    ldr x10, =100000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_16
.Lssa_int__int_to_string_18:
    mov x10, #8
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_16:
    ldr x10, =1000000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_13
.Lssa_int__int_to_string_15:
    mov x10, #9
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_13:
    mov x10, #10
.Lssa_int__int_to_string_12:
    add x11, x10, #1
    sxtw x11, w11
    cmp x19, #0
    csel x21, x11, x10, ne
    mov x0, x21
    bl __fern_alloc_bytes
    mov x22, x0
    adrp x11, .SB172
    add x11, x11, :lo12:.SB172
.Lssa_int__int_to_string_8:
.Lssa_int__int_to_string_113:
    cmp x20, #100
    b.lo .Lssa_int__int_to_string_7
.Lssa_int__int_to_string_114:
    mov x4, x20
    ldr x5, =184467440737095517
    umulh x5, x4, x5
    mov x4, x5
    mov x10, x4
    mov x9, #100
    mul x9, x10, x9
    sub x9, x20, x9
    sub x12, x21, #2
    sxtw x21, w12
    lsl x9, x9, #1
    sxtw x9, w9
    ldr x6, [x11, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w12, [x6, x9]
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w12, [x5, #8]
    add w13, w21, #1
    add w9, w9, #1
    ldr x6, [x11, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w12, [x6, x9]
    ldr x7, [x22]
    cmp x13, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    strb w12, [x5, #8]
    mov x20, x10
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_114
.Lssa_int__int_to_string_7:
    cmp x20, #10
    b.hs .Lssa_int__int_to_string_6
.Lssa_int__int_to_string_122:
    mov x0, x11
    bl __fn___fern_str_free.r
    b .Lssa_int__int_to_string_5
.Lssa_int__int_to_string_6:
    sub x9, x21, #2
    sxtw x9, w9
    lsl x12, x20, #1
    sxtw x12, w12
    ldr x6, [x11, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w13, [x6, x12]
    ldr x7, [x22]
    cmp x9, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    strb w13, [x5, #8]
    add w23, w9, #1
    add w12, w12, #1
    ldr x6, [x11, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w24, [x6, x12]
    mov x0, x11
    bl __fn___fern_str_free.r
    ldr x7, [x22]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    strb w24, [x5, #8]
    b .Lssa_int__int_to_string_4
.Lssa_int__int_to_string_5:
    sub w21, w21, #1
    add x20, x20, #48
    and x20, x20, #255
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w20, [x5, #8]
.Lssa_int__int_to_string_4:
    cbz x19, .Lssa_int__int_to_string_1
.Lssa_int__int_to_string_3:
    mov x12, #45
    ldr x6, [x22, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    strb w12, [x22, #8]
.Lssa_int__int_to_string_1:
    mov x0, x22
    bl __fn___fern_string_from_bytes_u8.r
    mov x20, x0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_int____int_to_string_u64:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_int____int_to_string_u64.k:
__fn_int____int_to_string_u64.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_int____int_to_string_u64_0:
.Lssa_int____int_to_string_u64_16:
    mov x10, x19
    mov x9, #1
.Lssa_int____int_to_string_u64_17:
    cmp x10, #100
    b.lo .Lssa_int____int_to_string_u64_15
.Lssa_int____int_to_string_u64_18:
    add x11, x9, #2
    sxtw x9, w11
    mov x4, x10
    ldr x5, =2951479051793528259
    lsr x6, x4, #2
    umulh x5, x6, x5
    lsr x5, x5, #2
    mov x4, x5
    mov x10, x4
    cmp x10, #100
    b.hs .Lssa_int____int_to_string_u64_18
.Lssa_int____int_to_string_u64_15:
    add x11, x9, #1
    sxtw x11, w11
    cmp x10, #10
    csel x11, x11, x9, hs
    add x9, x11, #1
    sxtw x9, w9
    cmp x20, #0
    csel x21, x9, x11, ne
    mov x0, x21
    bl __fern_alloc_bytes
    mov x22, x0
    adrp x9, .SB172
    add x9, x9, :lo12:.SB172
.Lssa_int____int_to_string_u64_8:
.Lssa_int____int_to_string_u64_37:
    cmp x19, #100
    b.lo .Lssa_int____int_to_string_u64_7
.Lssa_int____int_to_string_u64_38:
    mov x4, x19
    ldr x5, =2951479051793528259
    lsr x6, x4, #2
    umulh x5, x6, x5
    lsr x5, x5, #2
    mov x4, x5
    mov x11, x4
    mov x10, #100
    mul x10, x11, x10
    sub x10, x19, x10
    sub x12, x21, #2
    sxtw x21, w12
    lsl x10, x10, #1
    sxtw x10, w10
    ldr x6, [x9, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w12, [x5, #8]
    add w13, w21, #1
    add w10, w10, #1
    ldr x6, [x9, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x13, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    strb w12, [x5, #8]
    mov x19, x11
    cmp x19, #100
    b.hs .Lssa_int____int_to_string_u64_38
.Lssa_int____int_to_string_u64_7:
    cmp x19, #10
    b.hs .Lssa_int____int_to_string_u64_6
.Lssa_int____int_to_string_u64_46:
    mov x0, x9
    bl __fn___fern_str_free.r
    b .Lssa_int____int_to_string_u64_5
.Lssa_int____int_to_string_u64_6:
    sub x10, x21, #2
    sxtw x10, w10
    lsl x12, x19, #1
    sxtw x12, w12
    ldr x6, [x9, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w13, [x6, x12]
    ldr x7, [x22]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    strb w13, [x5, #8]
    add w23, w10, #1
    add w12, w12, #1
    ldr x6, [x9, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w24, [x6, x12]
    mov x0, x9
    bl __fn___fern_str_free.r
    ldr x7, [x22]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    strb w24, [x5, #8]
    b .Lssa_int____int_to_string_u64_4
.Lssa_int____int_to_string_u64_5:
    sub w21, w21, #1
    add x19, x19, #48
    and x19, x19, #255
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w19, [x5, #8]
.Lssa_int____int_to_string_u64_4:
    cmp x20, #0
    b.eq .Lssa_int____int_to_string_u64_1
.Lssa_int____int_to_string_u64_3:
    mov x12, #45
    ldr x6, [x22, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    strb w12, [x22, #8]
.Lssa_int____int_to_string_u64_1:
    mov x0, x22
    bl __fn___fern_string_from_bytes_u8.r
    mov x19, x0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8_scalar__expect:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_utf8_scalar__expect.k:
__fn_utf8_scalar__expect.r:
.Lssa_utf8_scalar__expect_0:
    cmp x0, #128
    b.ge .Lssa_utf8_scalar__expect_13
.Lssa_utf8_scalar__expect_15:
    mov x0, #1
    ret
.Lssa_utf8_scalar__expect_13:
    cmp x0, #194
    b.ge .Lssa_utf8_scalar__expect_10
.Lssa_utf8_scalar__expect_12:
    mov x0, #0
    ret
.Lssa_utf8_scalar__expect_10:
    cmp x0, #224
    b.ge .Lssa_utf8_scalar__expect_7
.Lssa_utf8_scalar__expect_9:
    mov x0, #2
    ret
.Lssa_utf8_scalar__expect_7:
    cmp x0, #240
    b.ge .Lssa_utf8_scalar__expect_4
.Lssa_utf8_scalar__expect_6:
    mov x0, #3
    ret
.Lssa_utf8_scalar__expect_4:
    mov x9, #4
    mov x10, #0
    cmp x0, #245
    csel x0, x9, x10, lt
    ret
    .cfi_endproc
    .ltorg
__fn_utf8_scalar__step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_utf8_scalar__step.k:
__fn_utf8_scalar__step.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_utf8_scalar__step_0:
    ldr x6, [x19, #8]
    cmp x20, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w22, [x6, x20]
    mov x0, x22
    bl __fn_utf8_scalar__expect.r
    cmp x0, #1
    b.gt .Lssa_utf8_scalar__step_28
.Lssa_utf8_scalar__step_30:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_28:
    add x9, x20, #1
    sxtw x9, w9
    cmp x9, x21
    b.lt .Lssa_utf8_scalar__step_25
.Lssa_utf8_scalar__step_27:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_25:
    add w9, w20, #1
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x9]
.Lssa_utf8_scalar__step_24:
    cmp x22, #224
    b.ne .Lssa_utf8_scalar__step_21
.Lssa_utf8_scalar__step_23:
    mov x9, #160
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_21:
    cmp x22, #240
    b.ne .Lssa_utf8_scalar__step_18
.Lssa_utf8_scalar__step_20:
    mov x9, #144
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_18:
    mov x9, #128
.Lssa_utf8_scalar__step_17:
    cmp x10, x9
    b.lt .Lssa_utf8_scalar__step_7
.Lssa_utf8_scalar__step_15:
    cmp x22, #237
    b.ne .Lssa_utf8_scalar__step_12
.Lssa_utf8_scalar__step_14:
    mov x9, #159
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_12:
    cmp x22, #244
    b.ne .Lssa_utf8_scalar__step_9
.Lssa_utf8_scalar__step_11:
    mov x9, #143
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_9:
    mov x9, #191
.Lssa_utf8_scalar__step_8:
    cmp x10, x9
    b.le .Lssa_utf8_scalar__step_5
.Lssa_utf8_scalar__step_7:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_5:
.Lssa_utf8_scalar__step_4:
    mov x9, #2
.Lssa_utf8_scalar__step_67:
    cmp x9, x0
    b.ge .Lssa_utf8_scalar__step_3
.Lssa_utf8_scalar__step_76:
    add x10, x20, x9
    sxtw x10, w10
    cmp x10, x21
    b.ge .Lssa_utf8_scalar__step_2
.Lssa_utf8_scalar__step_74:
    add w10, w20, w9
    ldr x6, [x19, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w11, [x6, x10]
.Lssa_utf8_scalar__step_73:
    cmp x11, #128
    b.lt .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_72:
    cmp x11, #192
    b.ge .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_68:
    add x9, x9, #1
    cmp x9, x0
    b.lt .Lssa_utf8_scalar__step_76
.Lssa_utf8_scalar__step_3:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_2:
    mov x0, x9
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_1:
    mov x0, x9
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_deflate____ReadPhase__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_deflate____ReadPhase__eq.k:
__fn_deflate____ReadPhase__eq.r:
.Lssa_deflate____ReadPhase__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S173
    add x11, x11, :lo12:.S173
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_20
.Lssa_deflate____ReadPhase__eq_24:
    ldr x11, [x9, #0]
    adrp x12, .S173
    add x12, x12, :lo12:.S173
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_20:
    adrp x14, .S174
    add x14, x14, :lo12:.S174
    cmp x10, x14
    b.ne .Lssa_deflate____ReadPhase__eq_15
.Lssa_deflate____ReadPhase__eq_19:
    ldr x14, [x9, #0]
    adrp x13, .S174
    add x13, x13, :lo12:.S174
    mov x12, #1
    mov x11, #0
    cmp x14, x13
    csel x0, x12, x11, eq
    ret
.Lssa_deflate____ReadPhase__eq_15:
    adrp x11, .S175
    add x11, x11, :lo12:.S175
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_10
.Lssa_deflate____ReadPhase__eq_14:
    ldr x11, [x9, #0]
    adrp x12, .S175
    add x12, x12, :lo12:.S175
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_10:
    adrp x14, .S176
    add x14, x14, :lo12:.S176
    cmp x10, x14
    b.ne .Lssa_deflate____ReadPhase__eq_4
.Lssa_deflate____ReadPhase__eq_9:
    ldr x14, [x9, #0]
    adrp x10, .S176
    add x10, x10, :lo12:.S176
    mov x13, #1
    mov x12, #0
    cmp x14, x10
    csel x0, x13, x12, eq
    ret
.Lssa_deflate____ReadPhase__eq_4:
    ldr x12, [x9, #0]
    adrp x9, .S177
    add x9, x9, :lo12:.S177
    mov x13, #1
    mov x10, #0
    cmp x12, x9
    csel x0, x13, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeErrorKind__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeErrorKind__eq.k:
__fn_codec__DecodeErrorKind__eq.r:
.Lssa_codec__DecodeErrorKind__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S178
    add x11, x11, :lo12:.S178
    cmp x10, x11
    b.ne .Lssa_codec__DecodeErrorKind__eq_15
.Lssa_codec__DecodeErrorKind__eq_19:
    ldr x11, [x0, #8]
    ldr x12, [x9, #0]
    adrp x13, .S178
    add x13, x13, :lo12:.S178
    cmp x12, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_16
.Lssa_codec__DecodeErrorKind__eq_18:
    ldr x13, [x9, #8]
    cmp x11, x13
    cset x0, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_16:
    mov x0, #0
    ret
.Lssa_codec__DecodeErrorKind__eq_15:
    adrp x13, .S179
    add x13, x13, :lo12:.S179
    cmp x10, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_10
.Lssa_codec__DecodeErrorKind__eq_14:
    ldr x13, [x9, #0]
    adrp x11, .S179
    add x11, x11, :lo12:.S179
    mov x12, #1
    mov x14, #0
    cmp x13, x11
    csel x0, x12, x14, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_10:
    adrp x14, .S180
    add x14, x14, :lo12:.S180
    cmp x10, x14
    b.ne .Lssa_codec__DecodeErrorKind__eq_4
.Lssa_codec__DecodeErrorKind__eq_9:
    ldr x14, [x9, #0]
    adrp x10, .S180
    add x10, x10, :lo12:.S180
    mov x12, #1
    mov x11, #0
    cmp x14, x10
    csel x0, x12, x11, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_4:
    ldr x11, [x9, #0]
    adrp x9, .S181
    add x9, x9, :lo12:.S181
    mov x12, #1
    mov x10, #0
    cmp x11, x9
    csel x0, x12, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeError__eq.k:
__fn_codec__DecodeError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_codec__DecodeError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_codec__DecodeError__eq_streqn17
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_codec__DecodeError__eq_streqd17
.Lssa_codec__DecodeError__eq_streqn17:
    mov x0, #0
.Lssa_codec__DecodeError__eq_streqd17:
    cbz x0, .Lssa_codec__DecodeError__eq_2
.Lssa_codec__DecodeError__eq_6:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_codec__DecodeError__eq_2
.Lssa_codec__DecodeError__eq_3:
    ldr x0, [x19, #24]
    ldr x9, [x20, #24]
    bl __fn_codec__DecodeErrorKind__eq.r
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_2:
    mov x0, #0
.Lssa_codec__DecodeError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_main:
    .cfi_startproc
__fn_main.k:
__fn_main.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #160
.Lssa_main_0:
    adrp x4, .SB182
    add x4, x4, :lo12:.SB182
    str x4, [sp, #152]
.Lssa_main_38:
    stp xzr, xzr, [sp, #136]
.Lssa_main_39:
    ldr x4, [sp, #136]
    cmp x4, #4000
    b.ge .Lssa_main_37
.Lssa_main_348:
    ldr x4, [sp, #152]
    str x4, [sp, #-16]!
    bl __fn___fern_str_bytes_u8
    add sp, sp, #16
    mov x22, x0
.Lssa_main_346:
    mov x23, #8192
    mov x4, #32768
    str x4, [sp, #128]
    mov x4, #100
    str x4, [sp, #120]
    movz x4, #16, lsl #16
    str x4, [sp, #112]
    adrp x4, .SB8
    add x4, x4, :lo12:.SB8
    str x4, [sp, #104]
    adrp x4, .SB8
    add x4, x4, :lo12:.SB8
    str x4, [sp, #96]
    adrp x4, .K1
    add x4, x4, :lo12:.K1
    str x4, [sp, #88]
.Lssa_main_344:
    ldr x9, [x22, #0]
    cmp x9, #1
    b.le .Lssa_main_340
.Lssa_main_343:
    ldrb w9, [x22, #8]
    cmp x9, #13
    b.ne .Lssa_main_340
.Lssa_main_342:
    ldrb w9, [x22, #9]
    cmp x9, #10
    b.ne .Lssa_main_340
.Lssa_main_341:
    mov x20, #2
    b .Lssa_main_339
.Lssa_main_340:
    mov x20, #0
.Lssa_main_339:
    ldr x4, [x22, #0]
    str x4, [sp, #80]
    cmp x20, x4
    b.lt .Lssa_main_336
.Lssa_main_367:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    b .Lssa_main_1
.Lssa_main_336:
    add x23, x20, x23
    add x23, x23, #2
    sxtw x23, w23
    ldr x5, [sp, #128]
    add x9, x20, x5
    add x9, x9, #4
    sxtw x4, w9
    str x4, [sp, #72]
    ldr x5, [sp, #80]
    cmp x4, x5
    ldr x6, [sp, #80]
    csel x25, x4, x6, lt
    adrp x9, .K11
    add x9, x9, :lo12:.K11
    mov x2, x9
    mov x1, x20
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L101
    mov x1, #0
.L101:
    adrp x9, .S183
    add x9, x9, :lo12:.S183
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L104
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L102:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L103
    add x5, x5, #16
    cmp x5, x8
    b.ls .L102
    sub x1, x5, x0
    b .L104
.L103:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L105
.L104:
    add x10, x9, #96
.L108:
    cmp x1, x3
    b.ge .L106
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L105
    add x1, x1, #1
    b .L108
.L105:
    str x1, [sp, #-16]!
    b .L107
.L106:
    str x3, [sp, #-16]!
.L107:
    ldr x0, [sp], #16
    mov x24, x0
    mov x0, x22
    mov x9, x24
    mov x10, x25
    bl __fn_http____line_break.r
    mov x9, #-1
.Lssa_main_332:
    mov x10, x20
    mov x12, x20
    mov x13, x24
    mov x24, #0
    mov x11, #0
.Lssa_main_376:
    cmp x0, #2
    b.ne .Lssa_main_386
.Lssa_main_388:
    mov x14, #-1
    mov x21, x9
    mov x27, x14
    b .Lssa_main_330
.Lssa_main_386:
    cmp x0, #1
    b.ne .Lssa_main_384
.Lssa_main_385:
    add x14, x13, #1
    sxtw x14, w14
    mov x26, x9
    mov x19, x14
    mov x27, x14
    mov x24, #1
    mov x28, #0
    b .Lssa_main_377
.Lssa_main_384:
    mov x14, #-1
    cmp x9, x14
    b.ne .Lssa_main_381
.Lssa_main_383:
    add x14, x13, #1
    sxtw x14, w14
    mov x15, #-2
    cmp x14, x23
    csel x15, x15, x13, ge
    mov x9, x15
.Lssa_main_382:
.Lssa_main_381:
    cmp x13, x10
    b.ne .Lssa_main_378
.Lssa_main_380:
    cbnz x11, .Lssa_main_331
.Lssa_main_378:
    add x11, x13, #2
    sxtw x11, w11
    mov x26, x9
    mov x19, x11
    mov x27, x11
    mov x28, #1
.Lssa_main_377:
    adrp x11, .K11
    add x11, x11, :lo12:.K11
    mov x2, x11
    mov x1, x27
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L109
    mov x1, #0
.L109:
    adrp x9, .S183
    add x9, x9, :lo12:.S183
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L112
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L110:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L111
    add x5, x5, #16
    cmp x5, x8
    b.ls .L110
    sub x1, x5, x0
    b .L112
.L111:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L113
.L112:
    add x10, x9, #96
.L116:
    cmp x1, x3
    b.ge .L114
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L113
    add x1, x1, #1
    b .L116
.L113:
    str x1, [sp, #-16]!
    b .L115
.L114:
    str x3, [sp, #-16]!
.L115:
    ldr x0, [sp], #16
    mov x21, x0
    mov x0, x22
    mov x9, x21
    mov x10, x25
    bl __fn_http____line_break.r
    mov x9, x26
    mov x10, x19
    mov x11, x28
    mov x12, x27
    mov x13, x21
    cmp x0, #2
    b.eq .Lssa_main_388
    b .Lssa_main_386
.Lssa_main_331:
    sub x11, x13, #2
    sxtw x11, w11
    add x13, x13, #1
    sxtw x13, w13
    mov x10, #-2
    ldr x5, [sp, #72]
    cmp x13, x5
    csel x10, x10, x11, ge
    mov x21, x9
    mov x27, x10
.Lssa_main_330:
    mov x10, #-1
    cmp x21, x10
    b.ne .Lssa_main_324
.Lssa_main_328:
    ldr x28, [x22, #0]
    cmp x23, x25
    b.le .Lssa_main_317
.Lssa_main_327:
    cmp x25, x28
    b.ge .Lssa_main_317
.Lssa_main_326:
    cmp x23, x28
    csel x10, x23, x28, lt
    mov x0, x22
    mov x9, x12
    bl __fn_http____find_crlf.r
    cmp x0, #0
    b.lt .Lssa_main_317
    b .Lssa_main_321
.Lssa_main_324:
    mov x28, x21
    b .Lssa_main_313
.Lssa_main_321:
    mov x28, x0
    b .Lssa_main_313
.Lssa_main_317:
    cmp x28, x23
    b.lt .Lssa_main_314
.Lssa_main_316:
    mov x10, #-2
    mov x28, x10
    b .Lssa_main_313
.Lssa_main_314:
    mov x10, #-1
    mov x28, x10
.Lssa_main_313:
    mov x10, #-1
    cmp x27, x10
    b.ne .Lssa_main_307
.Lssa_main_312:
    ldr x4, [sp, #80]
    ldr x5, [sp, #72]
    cmp x4, x5
    b.lt .Lssa_main_307
.Lssa_main_311:
    mov x10, #-2
    mov x27, x10
.Lssa_main_310:
.Lssa_main_309:
.Lssa_main_307:
    mov x10, #-2
    cmp x28, x10
    b.ne .Lssa_main_304
.Lssa_main_306:
    mov x10, #414
    b .Lssa_main_297
.Lssa_main_304:
    mov x10, #-2
    cmp x27, x10
    b.ne .Lssa_main_301
.Lssa_main_303:
    mov x10, #431
    b .Lssa_main_297
.Lssa_main_301:
    cbz x24, .Lssa_main_298
.Lssa_main_300:
    mov x10, #400
    b .Lssa_main_297
.Lssa_main_298:
    mov x10, #0
.Lssa_main_297:
    cmp x10, #0
    b.eq .Lssa_main_295
.Lssa_main_482:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    b .Lssa_main_1
.Lssa_main_295:
    mov x24, #-1
    mov x21, #-1
    adrp x23, .SB8
    add x23, x23, :lo12:.SB8
    cmp x28, #0
    b.lt .Lssa_main_289
.Lssa_main_293:
    adrp x10, .K2
    add x10, x10, :lo12:.K2
    mov x2, x10
    mov x1, x20
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L117
    mov x1, #0
.L117:
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L120
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L118:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L119
    add x5, x5, #16
    cmp x5, x8
    b.ls .L118
    sub x1, x5, x0
    b .L120
.L119:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L121
.L120:
    add x10, x9, #96
.L124:
    cmp x1, x3
    b.ge .L122
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L121
    add x1, x1, #1
    b .L124
.L121:
    str x1, [sp, #-16]!
    b .L123
.L122:
    str x3, [sp, #-16]!
.L123:
    ldr x0, [sp], #16
    cmp x0, x28
    csel x25, x28, x0, gt
    cmp x25, x20
    b.eq .Lssa_main_290
.Lssa_main_292:
    cmp x25, x28
    b.ge .Lssa_main_290
.Lssa_main_291:
    ldr x6, [x22]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x25
    ldrb w10, [x5, #8]
    cmp x10, #32
    b.eq .Lssa_main_287
.Lssa_main_290:
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    mov x12, #-1
    mov x11, #-1
    mov x23, x12
    mov x25, x11
    mov x19, x10
    mov x0, #400
    b .Lssa_main_238
.Lssa_main_289:
    str x24, [sp, #96]
    mov x25, x21
    str x23, [sp, #80]
    b .Lssa_main_236
.Lssa_main_287:
    add x11, x25, #1
.Lssa_main_286:
    mov x12, #32
    mov x2, x11
    mov x1, x12
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L125
    mov x2, #0
.L125:
    cmp x1, #255
    b.hi .L130
    cmp x2, x3
    b.ge .L130
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L127
.L126:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L132
    cmp x5, x8
    b.ls .L126
.L127:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L128
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L128
    sub x5, x5, #16
    b .L133
.L132:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L133
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L133:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L131
.L128:
    cmp x5, x6
    b.ge .L130
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L134
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L130
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L130
    add x5, x5, x4
    b .L129
.L134:
    cmp x5, x6
    b.ge .L130
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L129
    add x5, x5, #1
    b .L134
.L129:
    sub x2, x5, x0
    b .L131
.L130:
    mov x2, #-1
.L131:
    mov x0, x2
    mov x12, #-1
    cmp x0, x28
    csel x23, x0, x12, lt
    cmp x23, #0
    b.lt .Lssa_main_280
.Lssa_main_281:
    add x12, x25, #1
    cmp x23, x12
    b.ne .Lssa_main_278
.Lssa_main_280:
    adrp x12, .SB8
    add x12, x12, :lo12:.SB8
    mov x10, #-1
    mov x11, #-1
    mov x23, x10
    mov x25, x11
    mov x19, x12
    mov x0, #400
    b .Lssa_main_238
.Lssa_main_278:
    add x11, x23, #1
    sxtw x21, w11
.Lssa_main_277:
    sub x11, x28, x21
    sxtw x11, w11
    cmp x11, #8
    b.ne .Lssa_main_275
.Lssa_main_276:
    adrp x10, .K12
    add x10, x10, :lo12:.K12
    mov x11, #0
    mov x12, #5
    mov x0, x22
    mov x9, x21
    bl __fn___sem_byte_view_mismatch.r
    cmp x0, #5
    b.eq .Lssa_main_273
.Lssa_main_275:
    mov x11, #400
    b .Lssa_main_264
.Lssa_main_273:
    add w12, w21, #5
    ldr x6, [x22]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x12
    ldrb w0, [x5, #8]
    bl __fn_http____is_digit.r
    cbz x0, .Lssa_main_267
.Lssa_main_272:
    add w12, w21, #6
    ldr x6, [x22]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x12
    ldrb w11, [x5, #8]
    cmp x11, #46
    b.ne .Lssa_main_267
.Lssa_main_271:
    add w11, w21, #7
    ldr x6, [x22]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    ldrb w0, [x5, #8]
    bl __fn_http____is_digit.r
    cbz x0, .Lssa_main_267
.Lssa_main_269:
    add w21, w21, #5
    ldr x6, [x22]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    ldrb w11, [x5, #8]
    cmp x11, #49
    b.eq .Lssa_main_265
.Lssa_main_268:
    mov x11, #505
    b .Lssa_main_264
.Lssa_main_267:
    mov x11, #400
    b .Lssa_main_264
.Lssa_main_265:
    mov x11, #0
.Lssa_main_264:
    cmp x11, #0
    b.eq .Lssa_main_261
.Lssa_main_263:
    adrp x12, .SB8
    add x12, x12, :lo12:.SB8
    mov x10, #-1
    mov x9, #-1
    mov x0, x11
    mov x23, x10
    mov x25, x9
    mov x19, x12
    b .Lssa_main_238
.Lssa_main_261:
    add x21, x25, #1
    sub x9, x25, x20
    sxtw x9, w9
    cmp x9, #7
    b.ne .Lssa_main_259
.Lssa_main_260:
    adrp x24, .SB184
    add x24, x24, :lo12:.SB184
    ldr x9, [x24, #8]
    mov x10, #0
    mov x4, x9
    mov x3, x10
    mov x2, x24
    mov x1, x20
    mov x0, x22
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L135_aop
    mov x1, #0
.L135_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L135_bop
    mov x3, #0
.L135_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L135_nok
    mov x4, #0
.L135_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L135_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L135_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L135_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L135_done
.L135_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L135_vec
.L135_short:
    cmp x10, #8
    b.lt .L135_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L135_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L135_eq
    add x8, x8, x14
.L135_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L135_done
.L135_w4:
    cmp x10, #4
    b.lt .L135_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L135_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L135_eq
    add x8, x8, x14
.L135_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L135_done
.L135_w2:
    cmp x10, #2
    b.lt .L135_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L135_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L135_eq
    add x8, x8, x14
.L135_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L135_done
.L135_tail:
    cmp x8, x13
    b.ge .L135_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L135_th
    add x8, x8, #1
    add x9, x9, #1
    b .L135_tail
.L135_th:
    sub x2, x8, x12
    b .L135_done
.L135_eq:
    mov x2, x4
.L135_done:
    mov x0, x2
    ldr x10, [x24, #8]
    cmp x0, x10
    cset x11, eq
.Lssa_main_563:
    b .Lssa_main_257
.Lssa_main_259:
    mov x11, #0
.Lssa_main_258:
.Lssa_main_257:
    mov x0, x22
    mov x9, x21
    mov x10, x23
    bl __fn_http____target_start.r
    mov x24, x0
    mov x11, #-2
.Lssa_main_566:
    cmp x24, x11
    b.ne .Lssa_main_254
.Lssa_main_256:
    mov x0, #400
    b .Lssa_main_239
.Lssa_main_254:
    mov x11, #-1
.Lssa_main_573:
    cmp x24, x11
    b.ne .Lssa_main_251
.Lssa_main_253:
    adrp x11, .SB185
    add x11, x11, :lo12:.SB185
    mov x0, x11
    b .Lssa_main_242
.Lssa_main_251:
    mov x0, x22
    mov x9, x24
    mov x10, x23
    bl __fn_http____path_end.r
    mov x21, x0
    cmp x21, #0
    b.ge .Lssa_main_248
.Lssa_main_250:
    mov x0, #400
    b .Lssa_main_239
.Lssa_main_248:
    cmp x24, x21
    b.ge .Lssa_main_244
.Lssa_main_247:
    mov x0, x22
    mov x9, x24
    mov x10, x21
    bl __fn_http____plain_path.r
    cbz x0, .Lssa_main_244
.Lssa_main_246:
    mov x0, x22
    mov x9, x24
    mov x10, x23
    ldr x11, [sp, #96]
    bl __fn_http____shared_string.r
    b .Lssa_main_242
.Lssa_main_244:
    mov x0, x22
    mov x9, x24
    mov x10, x21
    mov x11, x23
    bl __fn_http____decoded_path.r
    mov x19, x0
    mov x0, x1
    cmp x19, #0
    b.ne .Lssa_main_239
.Lssa_main_243:
.Lssa_main_242:
    mov x19, x0
    mov x4, x25
    mov x25, x23
    mov x23, x4
    mov x0, #0
    b .Lssa_main_238
.Lssa_main_241:
.Lssa_main_240:
.Lssa_main_239:
    adrp x11, .SB8
    add x11, x11, :lo12:.SB8
    mov x10, #-1
    mov x9, #-1
    mov x23, x10
    mov x25, x9
    mov x19, x11
.Lssa_main_238:
    cmp x0, #0
    b.eq .Lssa_main_237
.Lssa_main_599:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x19
    bl __fn___fern_str_free.r
    b .Lssa_main_1
.Lssa_main_237:
    str x23, [sp, #96]
    str x19, [sp, #80]
.Lssa_main_236:
    cmp x28, #0
    b.ge .Lssa_main_235
.Lssa_main_603:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    b .Lssa_main_1
.Lssa_main_235:
    cmp x27, #0
    b.ge .Lssa_main_233
.Lssa_main_607:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    b .Lssa_main_1
.Lssa_main_233:
    add x9, x27, #4
    sub x4, x9, x20
    str x4, [sp, #72]
    add x28, x28, #2
    sxtw x28, w28
    cmp x28, x27
    csel x9, x27, x28, gt
    mov x0, x22
    mov x10, x27
    ldr x11, [sp, #120]
    ldr x12, [sp, #88]
    bl __fn_http____parse_header_bytes.r
    mov x28, x0
    mov x27, x1
    cmp x28, #0
    b.eq .Lssa_main_227
.Lssa_main_617:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    b .Lssa_main_1
.Lssa_main_227:
    add x25, x25, #1
.Lssa_main_226:
    add w25, w25, #7
    ldr x6, [x22]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x25
    ldrb w9, [x5, #8]
    cmp x9, #48
    b.ne .Lssa_main_223
.Lssa_main_225:
    adrp x9, .SB186
    add x9, x9, :lo12:.SB186
    str x9, [sp, #88]
    b .Lssa_main_221
.Lssa_main_223:
    adrp x9, .SB187
    add x9, x9, :lo12:.SB187
    str x9, [sp, #88]
.Lssa_main_222:
.Lssa_main_221:
    mov x9, #-1
    mov x10, #-1
    mov x11, #-1
    mov x12, #-1
    b .Lssa_main_pool_405
    .ltorg
.Lssa_main_pool_405:
    mov x13, #-1
.Lssa_main_220:
    mov x28, x9
    mov x24, x10
    mov x26, x11
    mov x23, x13
    mov x13, x12
    mov x12, #0
.Lssa_main_625:
    ldr x11, [x27, #8]
    ldr x10, [x11, #0]
    cmp x12, x10
    b.ge .Lssa_main_217
.Lssa_main_660:
    ldr x10, [x27, #8]
    add x5, x12, #1
    ldr x11, [x10, x5, lsl #3]
.Lssa_main_659:
    ldr x10, [x11, #8]
    cmp x10, #4
    b.ne .Lssa_main_656
.Lssa_main_658:
    adrp x9, .SB188
    add x9, x9, :lo12:.SB188
    mov x15, #3
    str x10, [sp, #64]
    str x11, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    mov x0, x11
    mov x10, x15
    bl __fn_http____kind_if.r
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    b .Lssa_main_643
.Lssa_main_656:
    cmp x10, #6
    b.ne .Lssa_main_653
.Lssa_main_655:
    adrp x9, .SB189
    add x9, x9, :lo12:.SB189
    mov x15, #4
    str x10, [sp, #64]
    str x11, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    mov x0, x11
    mov x10, x15
    bl __fn_http____kind_if.r
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    b .Lssa_main_643
.Lssa_main_653:
    cmp x10, #10
    b.ne .Lssa_main_650
.Lssa_main_652:
    adrp x9, .SB65
    add x9, x9, :lo12:.SB65
    mov x15, #5
    str x10, [sp, #64]
    str x11, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    mov x0, x11
    mov x10, x15
    bl __fn_http____kind_if.r
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    b .Lssa_main_643
.Lssa_main_650:
    cmp x10, #14
    b.ne .Lssa_main_647
.Lssa_main_649:
    adrp x9, .SB64
    add x9, x9, :lo12:.SB64
    mov x15, #1
    str x10, [sp, #64]
    str x11, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    mov x0, x11
    mov x10, x15
    bl __fn_http____kind_if.r
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    b .Lssa_main_643
.Lssa_main_647:
    cmp x10, #17
    b.ne .Lssa_main_644
.Lssa_main_646:
    adrp x9, .SB66
    add x9, x9, :lo12:.SB66
    mov x10, #2
    str x12, [sp, #64]
    str x13, [sp, #56]
    mov x0, x11
    bl __fn_http____kind_if.r
    ldr x12, [sp, #64]
    ldr x13, [sp, #56]
    b .Lssa_main_643
.Lssa_main_644:
    mov x0, #0
.Lssa_main_643:
    cmp x0, #1
    b.ne .Lssa_main_640
.Lssa_main_642:
    mov x10, #-1
    mov x9, #-2
    cmp x28, x10
    csel x9, x12, x9, eq
    mov x28, x9
.Lssa_main_641:
.Lssa_main_640:
    cmp x0, #2
    b.ne .Lssa_main_637
.Lssa_main_639:
    mov x9, #-1
    mov x10, #-2
    cmp x24, x9
    csel x10, x12, x10, eq
    mov x24, x10
.Lssa_main_638:
.Lssa_main_637:
    cmp x0, #3
    b.ne .Lssa_main_634
.Lssa_main_636:
    mov x10, #-1
    mov x9, #-2
    cmp x26, x10
    csel x9, x12, x9, eq
    mov x26, x9
.Lssa_main_635:
.Lssa_main_634:
    cmp x0, #4
    b.ne .Lssa_main_630
.Lssa_main_633:
    cmp x13, #0
    b.ge .Lssa_main_630
.Lssa_main_632:
    mov x13, x12
.Lssa_main_631:
.Lssa_main_630:
    cmp x0, #5
    b.ne .Lssa_main_626
.Lssa_main_629:
    cmp x23, #0
    b.ge .Lssa_main_626
.Lssa_main_628:
    mov x23, x12
.Lssa_main_627:
.Lssa_main_626:
    add x12, x12, #1
    b .Lssa_main_625
.Lssa_main_217:
    cmp x13, #0
    b.ge .Lssa_main_214
.Lssa_main_216:
    mov x21, #0
    b .Lssa_main_209
.Lssa_main_214:
    mov x21, x13
.Lssa_main_760:
    cmp x21, #0
    b.lt .Lssa_main_213
.Lssa_main_763:
    ldr x12, [x27, #16]
    ldr x6, [x12]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x12, x5, lsl #3]
    adrp x9, .SB190
    add x9, x9, :lo12:.SB190
    bl __fn_http____token_is.r
    cbz x0, .Lssa_main_212
.Lssa_main_761:
    adrp x9, .SB189
    add x9, x9, :lo12:.SB189
    add x21, x21, #1
    sxtw x10, w21
    mov x0, x27
    bl __fn_http____field_at.r
    mov x21, x0
    cmp x21, #0
    b.ge .Lssa_main_763
.Lssa_main_213:
    mov x21, #1
    b .Lssa_main_209
.Lssa_main_212:
    mov x21, #417
.Lssa_main_211:
.Lssa_main_209:
    mov x10, #-1
    cmp x26, x10
    b.ne .Lssa_main_206
.Lssa_main_208:
    adrp x10, .SB187
    add x10, x10, :lo12:.SB187
    ldr x4, [sp, #88]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_main_780
.Lssa_main_779:
    ldr x4, [sp, #88]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn2824
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn2824
    ldr x0, [sp, #88]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd2824
.Lssa_main_streqn2824:
    mov x0, #0
.Lssa_main_streqd2824:
    b .Lssa_main_781
.Lssa_main_780:
    mov x0, #0
.Lssa_main_781:
    cbnz x0, .Lssa_main_195
    b .Lssa_main_197
.Lssa_main_206:
    mov x10, #-2
    cmp x26, x10
    b.eq .Lssa_main_195
.Lssa_main_203:
    ldr x10, [x27, #16]
    ldr x6, [x10]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    ldr x9, [x10, x5, lsl #3]
.Lssa_main_202:
    ldr x10, [x9, #8]
    ldr x12, [x9, #0]
    mov x9, #0
.Lssa_main_788:
    cmp x9, x10
    b.ge .Lssa_main_197
.Lssa_main_792:
    ldrb w13, [x12, x9]
    cmp x13, #33
    b.lt .Lssa_main_195
.Lssa_main_791:
    cmp x13, #126
    b.gt .Lssa_main_195
.Lssa_main_789:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_main_792
.Lssa_main_197:
    cmp x21, #417
    b.ne .Lssa_main_193
.Lssa_main_196:
    mov x9, #417
    b .Lssa_main_192
.Lssa_main_195:
    mov x9, #400
    b .Lssa_main_192
.Lssa_main_193:
    mov x9, #0
.Lssa_main_192:
    cmp x9, #0
    b.le .Lssa_main_189
.Lssa_main_818:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_189:
    mov x9, #-1
    cmp x24, x9
    b.ne .Lssa_main_184
.Lssa_main_187:
    mov x9, #-1
    cmp x28, x9
    b.ne .Lssa_main_174
.Lssa_main_186:
    mov x24, #1
    mov x21, #0
    b .Lssa_main_166
.Lssa_main_184:
    mov x9, #-1
    cmp x28, x9
    b.eq .Lssa_main_183
.Lssa_main_831:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_183:
    mov x9, #-2
    cmp x24, x9
    b.ne .Lssa_main_181
.Lssa_main_835:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_181:
    ldr x9, [x27, #16]
    ldr x6, [x9]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    ldr x12, [x9, x5, lsl #3]
    adrp x9, .SB191
    add x9, x9, :lo12:.SB191
    mov x1, x9
    mov x0, x12
    str x1, [sp, #-16]!
    str x0, [sp, #-16]!
    bl __fn___fern_str_split
    add sp, sp, #32
    mov x24, x0
    ldr x9, [x24, #0]
    sub w9, w9, #1
    ldr x6, [x24]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x0, [x24, x5, lsl #3]
    adrp x9, .SB192
    add x9, x9, :lo12:.SB192
    bl __fn_http____token_is.r
    cbnz x0, .Lssa_main_179
.Lssa_main_840:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    tst x24, #1
    b.ne .Lssa_main_uq840
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_uq840
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_main_uq840:
    b.ne .Lssa_main_844
.Lssa_main_842:
    mov x21, #0
.Lssa_main_846:
    ldr x9, [x24, #0]
    cmp x21, x9
    b.ge .Lssa_main_844
.Lssa_main_847:
    add x5, x21, #1
    ldr x9, [x24, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x21, x21, #1
    b .Lssa_main_846
.Lssa_main_844:
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_179:
.Lssa_main_178:
    mov x21, #0
.Lssa_main_851:
    add x9, x21, #1
    sxtw x9, w9
    ldr x26, [x24, #0]
    cmp x9, x26
    b.ge .Lssa_main_177
.Lssa_main_854:
    ldr x6, [x24]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x24, x5, lsl #3]
    adrp x9, .SB192
    add x9, x9, :lo12:.SB192
    bl __fn_http____token_is.r
    cbz x0, .Lssa_main_852
.Lssa_main_859:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    tst x24, #1
    b.ne .Lssa_main_uq859
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_uq859
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_main_uq859:
    b.ne .Lssa_main_864
.Lssa_main_862:
    mov x25, #0
.Lssa_main_866:
    ldr x9, [x24, #0]
    cmp x25, x9
    b.ge .Lssa_main_864
.Lssa_main_867:
    add x5, x25, #1
    ldr x9, [x24, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x25, x25, #1
    b .Lssa_main_866
.Lssa_main_864:
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_852:
    add x21, x21, #1
    sxtw x21, w21
    b .Lssa_main_851
.Lssa_main_177:
    tst x24, #1
    b.ne .Lssa_main_uq177
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_uq177
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_main_uq177:
    b.ne .Lssa_main_875
.Lssa_main_873:
    mov x21, #0
.Lssa_main_877:
    ldr x9, [x24, #0]
    cmp x21, x9
    b.ge .Lssa_main_875
.Lssa_main_878:
    add x5, x21, #1
    ldr x9, [x24, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x21, x21, #1
    b .Lssa_main_877
.Lssa_main_875:
    mov x0, x24
    bl __fn___fern_arr_dec.r
    cmp x26, #1
    b.le .Lssa_main_176
.Lssa_main_881:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_176:
    mov x24, #0
    mov x21, #0
    b .Lssa_main_166
.Lssa_main_174:
    mov x9, #-2
    cmp x28, x9
    b.ne .Lssa_main_172
.Lssa_main_886:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_172:
    ldr x9, [x27, #16]
    ldr x6, [x9]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x21, [x9, x5, lsl #3]
    ldr x9, [x21, #8]
    cmp x9, #0
    b.ne .Lssa_main_170
.Lssa_main_890:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_170:
.Lssa_main_169:
    ldr x28, [x21, #8]
    ldr x26, [x21, #0]
    mov x21, #0
    mov x24, #0
.Lssa_main_894:
    cmp x24, x28
    b.ge .Lssa_main_168
.Lssa_main_902:
    ldrb w25, [x26, x24]
    cmp x25, #48
    b.ge .Lssa_main_901
.Lssa_main_907:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_901:
    cmp x25, #57
    b.le .Lssa_main_899
.Lssa_main_911:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_899:
    sub x25, x25, #48
    sxtw x25, w25
    ldr x9, =214748364
    cmp x21, x9
    b.le .Lssa_main_898
.Lssa_main_915:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_898:
    ldr x9, =214748364
    cmp x21, x9
    b.ne .Lssa_main_895
.Lssa_main_897:
    cmp x25, #7
    b.le .Lssa_main_895
.Lssa_main_923:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_895:
    mov x9, #10
    mul x9, x21, x9
    add x9, x9, x25
    sxtw x21, w9
    add x24, x24, #1
    cmp x24, x28
    b.lt .Lssa_main_902
.Lssa_main_168:
    mov x24, #1
.Lssa_main_167:
.Lssa_main_166:
    mov x0, x22
    mov x9, x20
    ldr x10, [sp, #96]
    ldr x11, [sp, #104]
    bl __fn_http____shared_string.r
    bl __fn___fern_str_free.r
    ldr x5, [sp, #72]
    add x20, x20, x5
    sxtw x20, w20
.Lssa_main_165:
.Lssa_main_164:
    mov x26, #0
.Lssa_main_929:
    cmp x23, #0
    b.lt .Lssa_main_163
.Lssa_main_936:
    ldr x28, [x27, #16]
    ldr x6, [x28]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    ldr x0, [x28, x5, lsl #3]
    adrp x9, .SB193
    add x9, x9, :lo12:.SB193
    bl __fn_http____lists_token.r
    cbz x0, .Lssa_main_933
.Lssa_main_935:
    mov x26, #1
.Lssa_main_934:
.Lssa_main_933:
    ldr x6, [x28]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    ldr x0, [x28, x5, lsl #3]
    adrp x9, .SB194
    add x9, x9, :lo12:.SB194
    bl __fn_http____lists_token.r
.Lssa_main_930:
    adrp x9, .SB65
    add x9, x9, :lo12:.SB65
    add x23, x23, #1
    sxtw x10, w23
    mov x0, x27
    bl __fn_http____field_at.r
    mov x23, x0
    cmp x23, #0
    b.ge .Lssa_main_936
.Lssa_main_163:
    cbnz x26, .Lssa_main_155
.Lssa_main_160:
    adrp x10, .SB186
    add x10, x10, :lo12:.SB186
    ldr x4, [sp, #88]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_main_155
.Lssa_main_958:
    ldr x4, [sp, #88]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn3088
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn3088
    ldr x0, [sp, #88]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd3088
.Lssa_main_streqn3088:
    mov x0, #0
.Lssa_main_streqd3088:
.Lssa_main_155:
    cbz x24, .Lssa_main_146
.Lssa_main_154:
    ldr x5, [sp, #112]
    cmp x21, x5
    b.le .Lssa_main_151
.Lssa_main_970:
    mov x0, x22
    bl __fn___fern_arr_dec.r
.Lssa_main_153:
    mov x5, #413
    str x5, [sp, #128]
    b .Lssa_main_95
.Lssa_main_151:
    add x9, x20, x21
    sxtw x9, w9
    ldr x10, [x22, #0]
    cmp x9, x10
    b.le .Lssa_main_148
.Lssa_main_975:
    mov x0, x22
    bl __fn___fern_arr_dec.r
.Lssa_main_150:
    mov x5, #1
    str x5, [sp, #128]
    b .Lssa_main_95
.Lssa_main_148:
    add x21, x20, x21
    sxtw x21, w21
    str x22, [sp, #-16]!
    str x20, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_bytes_range
    add sp, sp, #48
    mov x24, x0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    b .Lssa_main_pool_837
    .ltorg
.Lssa_main_pool_837:
    mov x0, x24
    bl __fn___fern_arr_dec.r
    mov x5, #2
    str x5, [sp, #128]
    b .Lssa_main_95
.Lssa_main_146:
    adrp x10, .SB187
    add x10, x10, :lo12:.SB187
    ldr x4, [sp, #88]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_main_982
.Lssa_main_981:
    ldr x4, [sp, #88]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn3117
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn3117
    ldr x0, [sp, #88]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd3117
.Lssa_main_streqn3117:
    mov x0, #0
.Lssa_main_streqd3117:
    b .Lssa_main_983
.Lssa_main_982:
    mov x0, #0
.Lssa_main_983:
    cbnz x0, .Lssa_main_142
.Lssa_main_984:
    mov x0, x22
    bl __fn___fern_arr_dec.r
.Lssa_main_145:
    mov x5, #400
    str x5, [sp, #128]
    b .Lssa_main_95
.Lssa_main_142:
    adrp x10, .K0
    add x10, x10, :lo12:.K0
.Lssa_main_141:
    ldr x24, [sp, #128]
    ldr x21, [sp, #112]
    mov x23, x10
.Lssa_main_989:
.Lssa_main_1048:
    ldr x26, [x22, #0]
    add x10, x20, x24
    sxtw x10, w10
    cmp x10, x26
    csel x28, x26, x10, gt
    mov x0, x22
    mov x9, x20
    mov x10, x28
    bl __fn_http____find_crlf.r
    mov x25, x0
    cmp x25, #0
    csel x10, x25, x28, ge
    mov x0, x22
    mov x9, x20
    bl __fn_http____crlf_terminated.r
    cbz x0, .Lssa_main_1037
.Lssa_main_1040:
    cmp x25, #0
    b.ge .Lssa_main_1032
.Lssa_main_1039:
    add x10, x20, x24
    sxtw x10, w10
    cmp x26, x10
    b.lt .Lssa_main_1035
.Lssa_main_1038:
    mov x10, #431
    mov x25, #0
    mov x26, #0
    b .Lssa_main_1013
.Lssa_main_1037:
    mov x10, #400
    mov x25, #0
    mov x26, #0
    b .Lssa_main_1013
.Lssa_main_1035:
    mov x10, #1
    mov x25, #0
    mov x26, #0
    b .Lssa_main_1013
.Lssa_main_1032:
.Lssa_main_1031:
    mov x28, x20
    mov x26, #0
.Lssa_main_1075:
    cmp x28, x25
    b.ge .Lssa_main_1030
.Lssa_main_1079:
    ldr x6, [x22]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x28
    ldrb w19, [x5, #8]
    mov x0, x19
    bl __fn_http____hex_digit.r
    cmp x0, #0
    b.lt .Lssa_main_1030
.Lssa_main_1078:
    mov x0, x19
    bl __fn_http____hex_digit.r
    lsl x10, x26, #4
    add x10, x10, x0
    sxtw x10, w10
    cmp x10, x21
    b.gt .Lssa_main_1028
.Lssa_main_1076:
    lsl x10, x26, #4
    add x10, x10, x0
    sxtw x26, w10
    add x28, x28, #1
    cmp x28, x25
    b.lt .Lssa_main_1079
.Lssa_main_1030:
    cmp x28, x20
    b.ne .Lssa_main_1026
.Lssa_main_1029:
    mov x10, #400
    mov x26, #0
    b .Lssa_main_1025
.Lssa_main_1028:
    mov x10, #413
    mov x26, #0
    b .Lssa_main_1025
.Lssa_main_1026:
    mov x10, #0
.Lssa_main_1025:
    cmp x10, #0
    b.eq .Lssa_main_1105
.Lssa_main_1024:
    mov x25, #0
    mov x26, #0
    b .Lssa_main_1013
.Lssa_main_1022:
.Lssa_main_1105:
    cmp x28, x25
    b.ge .Lssa_main_1015
.Lssa_main_1130:
    mov x0, x22
    mov x9, x28
    mov x10, x25
    bl __fn_http____bws_end.r
    cmp x0, x25
    b.ge .Lssa_main_1014
.Lssa_main_1129:
    ldr x6, [x22]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x0
    ldrb w10, [x5, #8]
    cmp x10, #59
    b.ne .Lssa_main_1014
.Lssa_main_1127:
    add x9, x0, #1
    mov x0, x22
    mov x10, x25
    bl __fn_http____bws_end.r
    mov x28, x0
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    mov x2, x9
    mov x1, x28
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L136
    mov x1, #0
.L136:
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L139
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L137:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L138
    add x5, x5, #16
    cmp x5, x8
    b.ls .L137
    sub x1, x5, x0
    b .L139
.L138:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L140
.L139:
    add x10, x9, #96
.L143:
    cmp x1, x3
    b.ge .L141
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L140
    add x1, x1, #1
    b .L143
.L140:
    str x1, [sp, #-16]!
    b .L142
.L141:
    str x3, [sp, #-16]!
.L142:
    ldr x0, [sp], #16
    cmp x0, x25
    csel x19, x25, x0, gt
    cmp x19, x28
    b.eq .Lssa_main_1014
.Lssa_main_1125:
    mov x0, x22
    mov x9, x19
    mov x10, x25
    bl __fn_http____bws_end.r
    cmp x0, x25
    b.ge .Lssa_main_1120
.Lssa_main_1124:
    ldr x6, [x22]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x0
    ldrb w9, [x5, #8]
    cmp x9, #61
    b.ne .Lssa_main_1120
.Lssa_main_1123:
    add x9, x0, #1
    mov x0, x22
    mov x10, x25
    bl __fn_http____bws_end.r
    mov x28, x0
.Lssa_main_1122:
    cmp x28, x25
    b.lt .Lssa_main_1118
.Lssa_main_1121:
    mov x9, #-1
    mov x10, x9
    b .Lssa_main_1108
.Lssa_main_1120:
    mov x28, x19
    b .Lssa_main_1105
.Lssa_main_1118:
    ldr x6, [x22]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x28
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_main_1113
.Lssa_main_1117:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    mov x2, x9
    mov x1, x28
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L144
    mov x1, #0
.L144:
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L147
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L145:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L146
    add x5, x5, #16
    cmp x5, x8
    b.ls .L145
    sub x1, x5, x0
    b .L147
.L146:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L148
.L147:
    add x10, x9, #96
.L151:
    cmp x1, x3
    b.ge .L149
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L148
    add x1, x1, #1
    b .L151
.L148:
    str x1, [sp, #-16]!
    b .L150
.L149:
    str x3, [sp, #-16]!
.L150:
    ldr x0, [sp], #16
    cmp x0, x25
    csel x0, x25, x0, gt
    cmp x0, x28
    b.ne .Lssa_main_1115
.Lssa_main_1116:
    mov x9, #-1
    mov x10, x9
    b .Lssa_main_1108
.Lssa_main_1115:
    mov x10, x0
    b .Lssa_main_1108
.Lssa_main_1113:
    add x28, x28, #1
.Lssa_main_1112:
.Lssa_main_1189:
    cmp x28, x25
    b.ge .Lssa_main_1111
.Lssa_main_1204:
    ldr x6, [x22]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x28
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_main_1110
.Lssa_main_1202:
    add x10, x28, #1
    cmp x9, #92
    csel x10, x10, x28, eq
    cmp x10, x25
    b.ge .Lssa_main_1109
.Lssa_main_1198:
    ldr x6, [x22]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    ldrb w9, [x5, #8]
.Lssa_main_1197:
    cmp x9, #9
    b.eq .Lssa_main_1190
.Lssa_main_1195:
    cmp x9, #32
    b.lo .Lssa_main_1109
.Lssa_main_1194:
    cmp x9, #127
    b.eq .Lssa_main_1109
.Lssa_main_1190:
    add x28, x10, #1
    cmp x28, x25
    b.lt .Lssa_main_1204
.Lssa_main_1111:
    mov x10, #-1
    b .Lssa_main_1108
.Lssa_main_1110:
    add x28, x28, #1
    mov x10, x28
    b .Lssa_main_1108
.Lssa_main_1109:
    mov x10, #-1
.Lssa_main_1108:
    cmp x10, #0
    b.lt .Lssa_main_1014
.Lssa_main_1107:
    mov x28, x10
.Lssa_main_1106:
    cmp x28, x25
    b.lt .Lssa_main_1130
.Lssa_main_1015:
    mov x10, #2
    b .Lssa_main_1013
.Lssa_main_1014:
    mov x10, #400
    mov x25, #0
    mov x26, #0
.Lssa_main_1013:
    cmp x10, #2
    b.ne .Lssa_main_140
.Lssa_main_1011:
    add x25, x25, #2
    sxtw x25, w25
    sub x20, x25, x20
    sub x24, x24, x20
    sub x24, x24, #2
    sxtw x24, w24
    cmp x24, #0
    b.lt .Lssa_main_139
.Lssa_main_1009:
    cmp x26, #0
    b.eq .Lssa_main_138
.Lssa_main_1007:
    add x9, x25, x26
    sxtw x9, w9
.Lssa_main_1006:
    ldr x12, [x22, #0]
    cmp x9, x12
    b.ge .Lssa_main_1002
.Lssa_main_1005:
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w13, [x5, #8]
    cmp x13, #13
    b.eq .Lssa_main_1002
.Lssa_main_1004:
    mov x9, #0
    b .Lssa_main_994
.Lssa_main_1002:
    add x13, x9, #1
    sxtw x13, w13
    cmp x13, x12
    b.ge .Lssa_main_998
.Lssa_main_1001:
    add w13, w9, #1
    ldr x6, [x22]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    ldrb w11, [x5, #8]
    cmp x11, #10
    b.eq .Lssa_main_998
.Lssa_main_1000:
    mov x9, #0
    b .Lssa_main_994
.Lssa_main_998:
    add x9, x9, #2
    sxtw x9, w9
    cmp x9, x12
    b.le .Lssa_main_995
.Lssa_main_997:
    mov x9, #1
    b .Lssa_main_994
.Lssa_main_995:
    mov x9, #2
.Lssa_main_994:
    cmp x9, #0
    b.eq .Lssa_main_135
.Lssa_main_992:
    cmp x9, #1
    b.eq .Lssa_main_134
.Lssa_main_990:
    mov x0, x23
    mov x1, x25
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_main_apush3512s
.Lssa_main_apush3512o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_main_apush3512e
.Lssa_main_apush3512s:
    str x10, [sp, #64]
    bl __fern_arr_push_owned
    ldr x10, [sp, #64]
.Lssa_main_apush3512e:
    mov x1, x26
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_main_apush3513s
.Lssa_main_apush3513o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_main_apush3513e
.Lssa_main_apush3513s:
    str x10, [sp, #64]
    bl __fern_arr_push_owned
    ldr x10, [sp, #64]
.Lssa_main_apush3513e:
    mov x23, x0
    sub x21, x21, x26
    sxtw x21, w21
    add x26, x25, x26
    add x26, x26, #2
    sxtw x20, w26
    b .Lssa_main_1048
.Lssa_main_140:
    mov x21, x10
    b .Lssa_main_104
.Lssa_main_139:
    mov x21, #431
    b .Lssa_main_104
.Lssa_main_138:
    add x24, x24, #2
.Lssa_main_137:
    ldr x20, [x22, #0]
    add x10, x25, x24
    sxtw x10, w10
    cmp x10, x20
    csel x26, x20, x10, gt
    sub x10, x25, #2
    sxtw x10, w10
    b .Lssa_main_131
.Lssa_main_135:
    mov x21, #400
    b .Lssa_main_104
.Lssa_main_134:
    mov x21, #1
    b .Lssa_main_104
.Lssa_main_131:
    mov x9, #13
    mov x2, x10
    mov x1, x9
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L152
    mov x2, #0
.L152:
    cmp x1, #255
    b.hi .L157
    cmp x2, x3
    b.ge .L157
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L154
.L153:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L159
    cmp x5, x8
    b.ls .L153
.L154:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L155
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L155
    sub x5, x5, #16
    b .L160
.L159:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L160
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L160:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L158
.L155:
    cmp x5, x6
    b.ge .L157
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L161
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L157
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L157
    add x5, x5, x4
    b .L156
.L161:
    cmp x5, x6
    b.ge .L157
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L156
    add x5, x5, #1
    b .L161
.L156:
    sub x2, x5, x0
    b .L158
.L157:
    mov x2, #-1
.L158:
    mov x0, x2
.Lssa_main_130:
.Lssa_main_1308:
    cmp x0, #0
    b.lt .Lssa_main_129
.Lssa_main_1314:
    add x9, x0, #3
    sxtw x9, w9
    cmp x9, x26
    b.ge .Lssa_main_129
.Lssa_main_1313:
    add w9, w0, #1
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.ne .Lssa_main_1309
.Lssa_main_1312:
    add w10, w0, #2
    ldr x6, [x22]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    ldrb w9, [x5, #8]
    cmp x9, #13
    b.ne .Lssa_main_1309
.Lssa_main_1311:
    add w9, w0, #3
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_main_128
.Lssa_main_1309:
    add x10, x0, #1
    sxtw x10, w10
    mov x9, #13
    mov x2, x10
    mov x1, x9
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L162
    mov x2, #0
.L162:
    cmp x1, #255
    b.hi .L167
    cmp x2, x3
    b.ge .L167
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L164
.L163:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L169
    cmp x5, x8
    b.ls .L163
.L164:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L165
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L165
    sub x5, x5, #16
    b .L170
.L169:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L170
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L170:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L168
.L165:
    cmp x5, x6
    b.ge .L167
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L171
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L167
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L167
    add x5, x5, x4
    b .L166
.L171:
    cmp x5, x6
    b.ge .L167
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L166
    add x5, x5, #1
    b .L171
.L166:
    sub x2, x5, x0
    b .L168
.L167:
    mov x2, #-1
.L168:
    mov x0, x2
    cmp x0, #0
    b.ge .Lssa_main_1314
.Lssa_main_129:
    mov x10, #-1
    mov x21, x10
    b .Lssa_main_127
.Lssa_main_128:
    mov x21, x0
.Lssa_main_127:
    cmp x21, #0
    csel x10, x21, x26, ge
    cmp x10, x25
    b.le .Lssa_main_121
.Lssa_main_123:
    mov x0, x22
    mov x9, x25
    bl __fn_http____crlf_terminated.r
    cbz x0, .Lssa_main_118
.Lssa_main_121:
    cmp x21, #0
    b.ge .Lssa_main_114
.Lssa_main_120:
    add x24, x25, x24
    sxtw x24, w24
    cmp x20, x24
    b.lt .Lssa_main_116
.Lssa_main_119:
    mov x21, #431
    b .Lssa_main_104
.Lssa_main_118:
    mov x21, #400
    b .Lssa_main_104
.Lssa_main_116:
    mov x21, #1
    b .Lssa_main_104
.Lssa_main_114:
    cmp x21, x25
    b.le .Lssa_main_108
.Lssa_main_113:
    adrp x12, .K1
    add x12, x12, :lo12:.K1
    mov x0, x22
    mov x9, x25
    mov x10, x21
    ldr x11, [sp, #120]
    bl __fn_http____parse_header_bytes.r
    mov x24, x0
    mov x21, x1
    cmp x24, #0
    b.ne .Lssa_main_104
.Lssa_main_112:
    mov x0, x21
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_108:
    mov x21, #2
.Lssa_main_105:
.Lssa_main_104:
    cmp x21, #2
    b.eq .Lssa_main_101
.Lssa_main_1372:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x23
    bl __fn___fern_arr_dec.r
.Lssa_main_103:
    str x21, [sp, #128]
    b .Lssa_main_95
.Lssa_main_101:
.Lssa_main_100:
.Lssa_main_99:
    mov x12, #0
    mov x10, #1
.Lssa_main_1377:
    ldr x9, [x23, #0]
    cmp x10, x9
    b.ge .Lssa_main_98
.Lssa_main_1378:
    add x5, x10, #1
    ldr x9, [x23, x5, lsl #3]
    add x9, x12, x9
    sxtw x12, w9
    add x10, x10, #2
    sxtw x10, w10
    b .Lssa_main_1377
.Lssa_main_98:
    mov x0, x12
    bl __fern_alloc_bytes
.Lssa_main_97:
    mov x24, x0
    mov x21, #0
    mov x25, #0
.Lssa_main_1385:
    add x12, x21, #1
    sxtw x12, w12
    ldr x10, [x23, #0]
    cmp x12, x10
    b.lt .Lssa_main_1386
.Lssa_main_1388:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x24
    bl __fn___fern_arr_dec.r
    mov x0, x23
    bl __fn___fern_arr_dec.r
    b .Lssa_main_96
.Lssa_main_1386:
    add x10, x21, #1
    sxtw x20, w10
    asr x10, x21, #31
    orr x10, x20, x10
    ldr x6, [x23]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x12, [x23, x5, lsl #3]
    b .Lssa_main_pool_1258
    .ltorg
.Lssa_main_pool_1258:
    add x5, x20, #1
    ldr x10, [x23, x5, lsl #3]
    str x24, [sp, #-16]!
    str x25, [sp, #-16]!
    str x22, [sp, #-16]!
    str x12, [sp, #-16]!
    str x10, [sp, #-16]!
    bl __fn___fern_bytes_into
    add sp, sp, #80
    mov x24, x0
    ldr x6, [x23]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, #1
    ldr x10, [x23, x5, lsl #3]
    add x25, x25, x10
    sxtw x25, w25
    add x21, x21, #2
    sxtw x21, w21
    b .Lssa_main_1385
.Lssa_main_96:
    mov x5, #2
    str x5, [sp, #128]
.Lssa_main_95:
    ldr x4, [sp, #128]
    cmp x4, #2
    b.eq .Lssa_main_92
.Lssa_main_1393:
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_35
.Lssa_main_92:
    adrp x10, .SB195
    add x10, x10, :lo12:.SB195
    mov x0, x10
    ldr x9, [sp, #80]
    bl __fn___fern_str_concat.r
    mov x25, x0
    ldr x0, [sp, #80]
    bl __fn___fern_str_free.r
    mov x0, #2
    bl __fern_arr_box
    mov x24, x0
    adrp x10, .S7
    add x10, x10, :lo12:.S7
    str x10, [x24, #0]
    str x25, [x24, #8]
    adrp x25, .K1
    add x25, x25, :lo12:.K1
    adrp x23, .K1
    add x23, x23, :lo12:.K1
    adrp x22, .K6
    add x22, x22, :lo12:.K6
    mov x20, #200
    mov x0, #6
    bl __fern_arr_box
    adrp x12, .S6
    add x12, x12, :lo12:.S6
    str x12, [x0, #0]
    str x20, [x0, #8]
    str x24, [x0, #16]
    str x25, [x0, #24]
    str x23, [x0, #32]
    str x22, [x0, #40]
.Lssa_main_90:
    adrp x4, .SB196
    add x4, x4, :lo12:.SB196
    str x4, [sp, #120]
.Lssa_main_89:
    mov x23, x0
    mov x25, #200
.Lssa_main_1397:
    ldr x0, [x23, #24]
    bl __fn_http__fields_ok.r
    cbnz x0, .Lssa_main_1399
.Lssa_main_1401:
    mov x0, x23
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_main_1398
.Lssa_main_1399:
    ldr x0, [x23, #32]
    bl __fn_http__fields_ok.r
    cbnz x0, .Lssa_main_86
.Lssa_main_1405:
    mov x0, x23
    bl __fn___sem_release_HttpResponse.r
.Lssa_main_1398:
    adrp x23, .K7
    add x23, x23, :lo12:.K7
    mov x25, #500
    b .Lssa_main_1397
.Lssa_main_86:
    cmp x25, #200
    b.lt .Lssa_main_82
.Lssa_main_84:
    cmp x25, #204
    b.ne .Lssa_main_81
.Lssa_main_82:
    mov x24, #1
    b .Lssa_main_79
.Lssa_main_81:
    cmp x25, #304
    cset x10, eq
    mov x24, x10
.Lssa_main_80:
.Lssa_main_79:
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    adrp x12, .SB8
    add x12, x12, :lo12:.SB8
    cbz x24, .Lssa_main_77
.Lssa_main_78:
    mov x26, x10
    mov x20, x12
    b .Lssa_main_76
.Lssa_main_77:
    mov x0, x23
    bl __fn_HttpResponse__body_text_lossy.r
    mov x20, x0
    adrp x26, .SB9
    add x26, x26, :lo12:.SB9
    ldr x0, [x20, #8]
    bl __fn_int__int_to_string.r
    mov x28, x0
    mov x0, x26
    mov x9, x28
    bl __fn___fern_str_concat.r
    mov x19, x0
    mov x0, x28
    bl __fn___fern_str_free.r
    adrp x28, .SB10
    add x28, x28, :lo12:.SB10
    str x19, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_1426
.Lssa_main_1425:
    mov x26, x19
    b .Lssa_main_76
.Lssa_main_1426:
    str x19, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x26, x0
    mov x0, x19
    bl __fn___fern_str_free.r
.Lssa_main_1427:
.Lssa_main_76:
    mov x12, #256
    mov x0, x12
    bl __fern_buf_new
    mov x28, x0
.Lssa_main_74:
    adrp x12, .SB11
    add x12, x12, :lo12:.SB11
    mov x0, x28
    mov x1, x12
    bl __fern_buf_push
.Lssa_main_73:
    cmp x25, #0
    b.ge .Lssa_main_70
.Lssa_main_72:
    mov x12, #45
    mov x0, x28
    mov x1, x12
    bl __fern_buf_push_byte
    mov x12, #0
    sub x12, x12, x25
    mov x0, x28
    mov x1, x12
    bl __fern_buf_push_decimal
    b .Lssa_main_69
.Lssa_main_70:
    mov x0, x28
    mov x1, x25
    bl __fern_buf_push_decimal
.Lssa_main_69:
    adrp x12, .SB12
    add x12, x12, :lo12:.SB12
    mov x0, x28
    mov x1, x12
    bl __fern_buf_push
.Lssa_main_67:
    adrp x12, .K8
    add x12, x12, :lo12:.K8
    adrp x10, .K9
    add x10, x10, :lo12:.K9
.Lssa_main_66:
    mov x9, #0
.Lssa_main_1433:
    ldr x11, [x12, #0]
    cmp x9, x11
    b.ge .Lssa_main_65
.Lssa_main_1436:
    add x5, x9, #1
    ldr x11, [x12, x5, lsl #3]
    cmp x11, x25
    b.eq .Lssa_main_64
.Lssa_main_1434:
    add x9, x9, #1
    b .Lssa_main_1433
.Lssa_main_65:
    adrp x12, .SB8
    add x12, x12, :lo12:.SB8
    mov x19, x12
    b .Lssa_main_63
.Lssa_main_64:
    ldr x6, [x10]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x19, [x10, x5, lsl #3]
    str x19, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_main_63:
    ldr x9, [x19, #8]
    cmp x9, #0
    b.ne .Lssa_main_60
.Lssa_main_1448:
    mov x0, x19
    bl __fn___fern_str_free.r
.Lssa_main_62:
    adrp x9, .SB63
    add x9, x9, :lo12:.SB63
    mov x19, x9
.Lssa_main_61:
.Lssa_main_60:
    mov x0, x28
    mov x1, x19
    bl __fern_buf_push
    mov x0, x19
    bl __fn___fern_str_free.r
    adrp x9, .SB10
    add x9, x9, :lo12:.SB10
    mov x0, x28
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_59:
    mov x19, #0
.Lssa_main_1453:
    ldr x9, [x23, #24]
    ldr x10, [x9, #8]
    ldr x9, [x10, #0]
    cmp x19, x9
    b.lt .Lssa_main_1459
.Lssa_main_1461:
    mov x0, x23
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_main_57
.Lssa_main_1459:
    ldr x21, [x23, #24]
    ldr x9, [x21, #8]
    add x5, x19, #1
    ldr x22, [x9, x5, lsl #3]
    adrp x9, .SB64
    add x9, x9, :lo12:.SB64
    mov x0, x22
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_1454
.Lssa_main_1458:
    adrp x9, .SB65
    add x9, x9, :lo12:.SB65
    mov x0, x22
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_1454
.Lssa_main_1457:
    adrp x9, .SB66
    add x9, x9, :lo12:.SB66
    mov x0, x22
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_1454
.Lssa_main_1455:
    ldr x9, [x21, #8]
    add x5, x19, #1
    ldr x10, [x9, x5, lsl #3]
    mov x0, x28
    mov x1, x10
    bl __fern_buf_push
    adrp x10, .SB67
    add x10, x10, :lo12:.SB67
    mov x0, x28
    mov x1, x10
    bl __fern_buf_push
    ldr x10, [x21, #16]
    ldr x6, [x10]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x9, [x10, x5, lsl #3]
    mov x0, x28
    mov x1, x9
    bl __fern_buf_push
    adrp x9, .SB10
    add x9, x9, :lo12:.SB10
    mov x0, x28
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_1454:
    add x19, x19, #1
    b .Lssa_main_1453
.Lssa_main_57:
    mov x0, x28
    mov x1, x26
    bl __fern_buf_push
    mov x0, x26
    bl __fn___fern_str_free.r
.Lssa_main_56:
    cmp x25, #101
    b.ne .Lssa_main_51
.Lssa_main_55:
    adrp x9, .SB68
    add x9, x9, :lo12:.SB68
    mov x0, x28
    mov x1, x9
    bl __fern_buf_push
    b .Lssa_main_48
.Lssa_main_51:
    adrp x9, .SB69
    add x9, x9, :lo12:.SB69
    mov x0, x28
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_48:
    mov x0, x28
    bl __fern_buf_take
    mov x19, x0
    mov x0, x28
    bl __fern_buf_free
    cbz x24, .Lssa_main_47
.Lssa_main_1484:
    mov x0, x20
    bl __fn___fern_str_free.r
    b .Lssa_main_46
.Lssa_main_47:
    adrp x9, .SB71
    add x9, x9, :lo12:.SB71
    ldr x4, [sp, #120]
    ldr x10, [x4, #8]
    cmp x10, #4
    b.ne .Lssa_main_44
.Lssa_main_1488:
    ldr x4, [sp, #120]
    ldr x6, [x4, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn4003
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn4003
    ldr x0, [sp, #120]
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd4003
.Lssa_main_streqn4003:
    mov x0, #0
.Lssa_main_streqd4003:
    cbz x0, .Lssa_main_44
.Lssa_main_1491:
    mov x0, x20
    bl __fn___fern_str_free.r
.Lssa_main_46:
    mov x28, x19
    b .Lssa_main_41
.Lssa_main_44:
    str x19, [sp, #-16]!
    str x20, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_1497
.Lssa_main_1496:
    mov x28, x19
    b .Lssa_main_1498
.Lssa_main_1497:
    str x19, [sp, #-16]!
    str x20, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x28, x0
    mov x0, x19
    bl __fn___fern_str_free.r
.Lssa_main_1498:
    mov x0, x20
    bl __fn___fern_str_free.r
.Lssa_main_43:
.Lssa_main_41:
    ldr x20, [x28, #8]
    mov x0, x28
    bl __fn___fern_str_free.r
    tst x27, #1
    b.ne .Lssa_main_uq41
    cmp x27, #16, lsl #12
    b.lo .Lssa_main_uq41
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_main_uq41:
    b.ne .Lssa_main_1500
.Lssa_main_1499:
    mov x28, x27
    b .Lssa_main_1501
.Lssa_main_1500:
    mov x28, #0
.Lssa_main_1501:
    ldr x19, [x27, #8]
    cmp x28, #0
    b.ne .Lssa_main_1504
.Lssa_main_1502:
    str x19, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
.Lssa_main_1504:
    cmp x28, #0
    b.eq .Lssa_main_1506
.Lssa_main_1505:
    ldr x28, [x27, #16]
    tst x28, #1
    b.ne .Lssa_main_uq1505
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_uq1505
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_main_uq1505:
    b.ne .Lssa_main_1510
.Lssa_main_1508:
    mov x24, #0
.Lssa_main_1512:
    ldr x9, [x28, #0]
    cmp x24, x9
    b.ge .Lssa_main_1510
.Lssa_main_1513:
    add x5, x24, #1
    ldr x9, [x28, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x24, x24, #1
    b .Lssa_main_1512
.Lssa_main_1510:
    mov x0, x28
    bl __fn___fern_arr_dec.r
    mov x0, x27
    bl __fn___fern_arr_dec.r
    b .Lssa_main_1507
.Lssa_main_1506:
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_1507:
    ldr x24, [x19, #0]
    tst x19, #1
    b.ne .Lssa_main_uq1507
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_uq1507
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_main_uq1507:
    b.ne .Lssa_main_1518
.Lssa_main_1516:
    mov x28, #0
.Lssa_main_1520:
    ldr x9, [x19, #0]
    cmp x28, x9
    b.ge .Lssa_main_1518
.Lssa_main_1521:
    add x5, x28, #1
    ldr x9, [x19, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x28, x28, #1
    b .Lssa_main_1520
.Lssa_main_1518:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    add x20, x20, x24
    sxtw x20, w20
    ldr x4, [sp, #144]
    add x4, x4, x20
    str x4, [sp, #144]
.Lssa_main_40:
    ldr x4, [sp, #136]
    add x4, x4, #1
    str x4, [sp, #136]
    ldr x4, [sp, #136]
    cmp x4, #4000
    b.lt .Lssa_main_348
.Lssa_main_37:
    ldr x4, [sp, #144]
    ldr x5, =-6275696437447579415
    smulh x5, x4, x5
    add x5, x5, x4
    asr x5, x5, #6
    add x5, x5, x5, lsr #63
    mov x6, #97
    msub x4, x5, x6, x4
    mov x9, x4
    sxtw x0, w9
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_35:
    ldr x4, [sp, #128]
    cmp x4, #400
    b.ge .Lssa_main_1
.Lssa_main_32:
    adrp x9, .SB186
    add x9, x9, :lo12:.SB186
    ldr x4, [sp, #88]
    ldr x10, [x4, #8]
    cmp x10, #8
    b.ne .Lssa_main_1532
.Lssa_main_1531:
    ldr x4, [sp, #88]
    ldr x6, [x4, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn4075
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn4075
    ldr x0, [sp, #88]
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd4075
.Lssa_main_streqn4075:
    mov x0, #0
.Lssa_main_streqd4075:
    b .Lssa_main_1533
.Lssa_main_1532:
    mov x0, #0
.Lssa_main_1533:
    cbz x0, .Lssa_main_1
.Lssa_main_31:
.Lssa_main_28:
.Lssa_main_27:
.Lssa_main_26:
.Lssa_main_25:
.Lssa_main_24:
.Lssa_main_23:
.Lssa_main_22:
.Lssa_main_21:
.Lssa_main_20:
.Lssa_main_14:
.Lssa_main_11:
.Lssa_main_10:
.Lssa_main_8:
.Lssa_main_1:
    mov x0, #100
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HeaderMap
.weak __fn___sem_drop_HeaderMap.k
__fn___sem_drop_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HeaderMap.k:
__fn___sem_drop_HeaderMap.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HeaderMap_0:
    ldr x20, [x19, #8]
    tst x20, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq0
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq0:
    b.ne .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_1:
    mov x21, #0
.Lssa___sem_drop_HeaderMap_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_6:
    add x5, x21, #1
    ldr x9, [x20, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x21, x21, #1
    b .Lssa___sem_drop_HeaderMap_5
.Lssa___sem_drop_HeaderMap_3:
    mov x0, x20
    bl __fn___fern_arr_dec.r
    ldr x21, [x19, #16]
    tst x21, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq3
    cmp x21, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq3
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq3:
    b.ne .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_9:
    mov x19, #0
.Lssa___sem_drop_HeaderMap_13:
    ldr x9, [x21, #0]
    cmp x19, x9
    b.ge .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_14:
    add x5, x19, #1
    ldr x9, [x21, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x19, x19, #1
    b .Lssa___sem_drop_HeaderMap_13
.Lssa___sem_drop_HeaderMap_11:
    mov x0, x21
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HeaderMap
.weak __fn___sem_release_HeaderMap.k
__fn___sem_release_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HeaderMap.k:
__fn___sem_release_HeaderMap.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HeaderMap_release_dec
    tbz w5, #31, .Lssa___sem_release_HeaderMap_release_slow
.Lssa___sem_release_HeaderMap_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_HeaderMap_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_HeaderMap_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HeaderMap_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HeaderMap_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_HeaderMap_uq0:
    b.ne .Lssa___sem_release_HeaderMap_3
.Lssa___sem_release_HeaderMap_1:
    mov x0, x19
    bl __fn___sem_drop_HeaderMap.r
.Lssa___sem_release_HeaderMap_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HttpResponse
.weak __fn___sem_drop_HttpResponse.k
__fn___sem_drop_HttpResponse:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HttpResponse.k:
__fn___sem_drop_HttpResponse.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HttpResponse_0:
    ldr x0, [x19, #16]
    bl __fn___sem_release_Body.r
    ldr x0, [x19, #24]
    bl __fn___sem_release_HeaderMap.r
    ldr x0, [x19, #32]
    bl __fn___sem_release_HeaderMap.r
    ldr x0, [x19, #40]
    bl __fn___sem_release_Option$$fn$void.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HttpResponse
.weak __fn___sem_release_HttpResponse.k
__fn___sem_release_HttpResponse:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HttpResponse.k:
__fn___sem_release_HttpResponse.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_HttpResponse_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HttpResponse_release_dec
    tbz w5, #31, .Lssa___sem_release_HttpResponse_release_slow
.Lssa___sem_release_HttpResponse_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_HttpResponse_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_HttpResponse_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HttpResponse_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HttpResponse_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HttpResponse_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_HttpResponse_uq0:
    b.ne .Lssa___sem_release_HttpResponse_3
.Lssa___sem_release_HttpResponse_1:
    mov x0, x19
    bl __fn___sem_drop_HttpResponse.r
.Lssa___sem_release_HttpResponse_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ByteStream
.weak __fn___sem_drop_ByteStream.k
__fn___sem_drop_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ByteStream.k:
__fn___sem_drop_ByteStream.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_ByteStream_0:
    ldr x9, [x19, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x0, [x19, #24]
    bl __fn___sem_release_Option$BodySource.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ByteStream
.weak __fn___sem_release_ByteStream.k
__fn___sem_release_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ByteStream.k:
__fn___sem_release_ByteStream.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ByteStream_release_dec
    tbz w5, #31, .Lssa___sem_release_ByteStream_release_slow
.Lssa___sem_release_ByteStream_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_ByteStream_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_ByteStream_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ByteStream_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ByteStream_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_ByteStream_uq0:
    b.ne .Lssa___sem_release_ByteStream_3
.Lssa___sem_release_ByteStream_1:
    mov x0, x19
    bl __fn___sem_drop_ByteStream.r
.Lssa___sem_release_ByteStream_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ChunkProducer
.weak __fn___sem_drop_ChunkProducer.k
__fn___sem_drop_ChunkProducer:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ChunkProducer.k:
__fn___sem_drop_ChunkProducer.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_ChunkProducer_0:
    ldr x9, [x19, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x9, [x19, #24]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x9, [x19, #32]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ChunkProducer
.weak __fn___sem_release_ChunkProducer.k
__fn___sem_release_ChunkProducer:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ChunkProducer.k:
__fn___sem_release_ChunkProducer.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_ChunkProducer_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ChunkProducer_release_dec
    tbz w5, #31, .Lssa___sem_release_ChunkProducer_release_slow
.Lssa___sem_release_ChunkProducer_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_ChunkProducer_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_ChunkProducer_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ChunkProducer_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ChunkProducer_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ChunkProducer_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_ChunkProducer_uq0:
    b.ne .Lssa___sem_release_ChunkProducer_3
.Lssa___sem_release_ChunkProducer_1:
    mov x0, x19
    bl __fn___sem_drop_ChunkProducer.r
.Lssa___sem_release_ChunkProducer_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_BodySource
.weak __fn___sem_drop_BodySource.k
__fn___sem_drop_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_BodySource.k:
__fn___sem_drop_BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_BodySource_0:
    ldr x9, [x19, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x20, [x19, #16]
    tst x20, #1
    b.ne .Lssa___sem_drop_BodySource_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_uq0
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_BodySource_uq0:
    b.ne .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_1:
    mov x21, #0
.Lssa___sem_drop_BodySource_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_6:
    add x5, x21, #1
    ldr x0, [x20, x5, lsl #3]
    bl __fn___sem_release_Option$StreamFault.r
    add x21, x21, #1
    b .Lssa___sem_drop_BodySource_5
.Lssa___sem_drop_BodySource_3:
    mov x0, x20
    bl __fn___fern_arr_dec.r
    ldr x9, [x19, #24]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_BodySource
.weak __fn___sem_release_BodySource.k
__fn___sem_release_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_BodySource.k:
__fn___sem_release_BodySource.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_BodySource_release_dec
    tbz w5, #31, .Lssa___sem_release_BodySource_release_slow
.Lssa___sem_release_BodySource_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_BodySource_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_BodySource_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_BodySource_uq0:
    b.ne .Lssa___sem_release_BodySource_3
.Lssa___sem_release_BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_BodySource.r
.Lssa___sem_release_BodySource_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Body
.weak __fn___sem_drop_Body.k
__fn___sem_drop_Body:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Body.k:
__fn___sem_drop_Body.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_Body_0:
    ldr x9, [x19, #0]
    adrp x10, .S7
    add x10, x10, :lo12:.S7
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_2
.Lssa___sem_drop_Body_1:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_str_free.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_2:
    adrp x10, .S197
    add x10, x10, :lo12:.S197
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_5
.Lssa___sem_drop_Body_4:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_arr_dec.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_5:
    adrp x10, .S198
    add x10, x10, :lo12:.S198
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_8
.Lssa___sem_drop_Body_7:
    ldr x0, [x19, #8]
    bl __fn___sem_release_ByteStream.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_8:
    adrp x10, .S199
    add x10, x10, :lo12:.S199
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_11
.Lssa___sem_drop_Body_10:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_str_free.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_11:
    adrp x10, .S200
    add x10, x10, :lo12:.S200
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_14
.Lssa___sem_drop_Body_13:
    ldr x0, [x19, #8]
    bl __fn___sem_release_ChunkProducer.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_14:
    adrp x10, .S201
    add x10, x10, :lo12:.S201
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_16:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_str_free.r
    ldr x10, [x19, #16]
    mov x0, x10
    bl __fn___fern_arr_dec.r
    ldr x20, [x19, #24]
    tst x20, #1
    b.ne .Lssa___sem_drop_Body_uq16
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_Body_uq16
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_Body_uq16:
    b.ne .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_19:
    mov x19, #0
.Lssa___sem_drop_Body_23:
    ldr x10, [x20, #0]
    cmp x19, x10
    b.ge .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_24:
    add x5, x19, #1
    ldr x10, [x20, x5, lsl #3]
    mov x0, x10
    bl __fn___fern_arr_dec.r
    add x19, x19, #1
    b .Lssa___sem_drop_Body_23
.Lssa___sem_drop_Body_21:
    mov x0, x20
    bl __fn___fern_arr_dec.r
.Lssa___sem_drop_Body_3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Body
.weak __fn___sem_release_Body.k
__fn___sem_release_Body:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Body.k:
__fn___sem_release_Body.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Body_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Body_release_dec
    tbz w5, #31, .Lssa___sem_release_Body_release_slow
.Lssa___sem_release_Body_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Body_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Body_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Body_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Body_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Body_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Body_uq0:
    b.ne .Lssa___sem_release_Body_3
.Lssa___sem_release_Body_1:
    mov x0, x19
    bl __fn___sem_drop_Body.r
.Lssa___sem_release_Body_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$$fn$void
.weak __fn___sem_drop_Option$$fn$void.k
__fn___sem_drop_Option$$fn$void:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$$fn$void.k:
__fn___sem_drop_Option$$fn$void.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$$fn$void_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$$fn$void_3
.Lssa___sem_drop_Option$$fn$void_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$$fn$void_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$$fn$void
.weak __fn___sem_release_Option$$fn$void.k
__fn___sem_release_Option$$fn$void:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$$fn$void.k:
__fn___sem_release_Option$$fn$void.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Option$$fn$void_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$$fn$void_release_dec
    tbz w5, #31, .Lssa___sem_release_Option$$fn$void_release_slow
.Lssa___sem_release_Option$$fn$void_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Option$$fn$void_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Option$$fn$void_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$$fn$void_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$$fn$void_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$$fn$void_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Option$$fn$void_uq0:
    b.ne .Lssa___sem_release_Option$$fn$void_3
.Lssa___sem_release_Option$$fn$void_1:
    mov x0, x19
    bl __fn___sem_drop_Option$$fn$void.r
.Lssa___sem_release_Option$$fn$void_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$BodySource
.weak __fn___sem_drop_Option$BodySource.k
__fn___sem_drop_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$BodySource.k:
__fn___sem_drop_Option$BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$BodySource_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$BodySource_3
.Lssa___sem_drop_Option$BodySource_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___sem_release_BodySource.r
.Lssa___sem_drop_Option$BodySource_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$BodySource
.weak __fn___sem_release_Option$BodySource.k
__fn___sem_release_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$BodySource.k:
__fn___sem_release_Option$BodySource.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$BodySource_release_dec
    tbz w5, #31, .Lssa___sem_release_Option$BodySource_release_slow
.Lssa___sem_release_Option$BodySource_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Option$BodySource_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Option$BodySource_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Option$BodySource_uq0:
    b.ne .Lssa___sem_release_Option$BodySource_3
.Lssa___sem_release_Option$BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_Option$BodySource.r
.Lssa___sem_release_Option$BodySource_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$StreamFault
.weak __fn___sem_drop_Option$StreamFault.k
__fn___sem_drop_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$StreamFault.k:
__fn___sem_drop_Option$StreamFault.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$StreamFault_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$StreamFault_3
.Lssa___sem_drop_Option$StreamFault_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$StreamFault_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$StreamFault
.weak __fn___sem_release_Option$StreamFault.k
__fn___sem_release_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$StreamFault.k:
__fn___sem_release_Option$StreamFault.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$StreamFault_release_dec
    tbz w5, #31, .Lssa___sem_release_Option$StreamFault_release_slow
.Lssa___sem_release_Option$StreamFault_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Option$StreamFault_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Option$StreamFault_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$StreamFault_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$StreamFault_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Option$StreamFault_uq0:
    b.ne .Lssa___sem_release_Option$StreamFault_3
.Lssa___sem_release_Option$StreamFault_1:
    mov x0, x19
    bl __fn___sem_drop_Option$StreamFault.r
.Lssa___sem_release_Option$StreamFault_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_len
.weak __fn___sem_view_len.k
__fn___sem_view_len:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_len.k:
__fn___sem_view_len.r:
.Lssa___sem_view_len_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_len_3
.Lssa___sem_view_len_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #8]
    mov x0, x10
    ret
.Lssa___sem_view_len_3:
    ldr x10, [x0, #0]
    mov x0, x10
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_data
.weak __fn___sem_view_data.k
__fn___sem_view_data:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_data.k:
__fn___sem_view_data.r:
.Lssa___sem_view_data_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_data_3
.Lssa___sem_view_data_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #0]
    mov x0, x10
    ret
.Lssa___sem_view_data_3:
    add x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_slice
.weak __fn___sem_byte_view_slice.k
__fn___sem_byte_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_byte_view_slice.k:
__fn___sem_byte_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_byte_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_byte_view_slice_3
.Lssa___sem_byte_view_slice_1:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_byte_view_slice_6
.Lssa___sem_byte_view_slice_4:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_byte_view_slice_9
.Lssa___sem_byte_view_slice_7:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    add x0, x0, x20
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice
.weak __fn___sem_view_slice.k
__fn___sem_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice.k:
__fn___sem_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_3
.Lssa___sem_view_slice_1:
    bl __fern_slice_abort
.Lssa___sem_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_6
.Lssa___sem_view_slice_4:
    bl __fern_slice_abort
.Lssa___sem_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_9
.Lssa___sem_view_slice_7:
    bl __fern_slice_abort
.Lssa___sem_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice_wide
.weak __fn___sem_view_slice_wide.k
__fn___sem_view_slice_wide:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice_wide.k:
__fn___sem_view_slice_wide.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_wide_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_wide_3
.Lssa___sem_view_slice_wide_1:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_wide_6
.Lssa___sem_view_slice_wide_4:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_wide_9
.Lssa___sem_view_slice_wide_7:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_release
.weak __fn___sem_view_release.k
__fn___sem_view_release:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_release.k:
__fn___sem_view_release.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_view_release_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_release_3
.Lssa___sem_view_release_1:
    mov x9, #-2
    add x9, x0, x9
    str x9, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_view_release_3:
    bl __fn___fern_arr_dec.r
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_string
.weak __fn___sem_byte_view_string.k
__fn___sem_byte_view_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_byte_view_string.k:
__fn___sem_byte_view_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_string_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_byte_view_string_3
.Lssa___sem_byte_view_string_1:
    mov x9, #-2
    add x9, x0, x9
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_string_3:
    bl __fn___fern_string_from_bytes_u8.r
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_mismatch
.weak __fn___sem_byte_view_mismatch.k
__fn___sem_byte_view_mismatch:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___sem_byte_view_mismatch.k:
__fn___sem_byte_view_mismatch.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_mismatch_0:
    mov x13, #2
    and x13, x0, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_3
.Lssa___sem_byte_view_mismatch_1:
    mov x13, #2
    and x13, x10, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_6
.Lssa___sem_byte_view_mismatch_4:
    mov x13, #-2
    add x13, x0, x13
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    mov x0, x13
    ldr x5, [x0, #8]
    ldr x0, [x0]
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L172_aop
    mov x1, #0
.L172_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L172_bop
    mov x3, #0
.L172_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L172_nok
    mov x4, #0
.L172_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L172_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L172_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L172_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L172_done
.L172_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L172_vec
.L172_short:
    cmp x10, #8
    b.lt .L172_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L172_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L172_eq
    add x8, x8, x14
.L172_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L172_done
.L172_w4:
    cmp x10, #4
    b.lt .L172_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L172_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L172_eq
    add x8, x8, x14
.L172_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L172_done
.L172_w2:
    cmp x10, #2
    b.lt .L172_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L172_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L172_eq
    add x8, x8, x14
.L172_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L172_done
.L172_tail:
    cmp x8, x13
    b.ge .L172_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L172_th
    add x8, x8, #1
    add x9, x9, #1
    b .L172_tail
.L172_th:
    sub x2, x8, x12
    b .L172_done
.L172_eq:
    mov x2, x4
.L172_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_6:
    mov x15, #-2
    add x15, x0, x15
    mov x4, x12
    mov x3, x9
    mov x2, x15
    mov x1, x11
    mov x0, x10
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L173_aop
    mov x1, #0
.L173_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L173_bop
    mov x3, #0
.L173_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L173_nok
    mov x4, #0
.L173_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L173_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L173_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L173_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L173_done
.L173_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L173_vec
.L173_short:
    cmp x10, #8
    b.lt .L173_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L173_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L173_eq
    add x8, x8, x14
.L173_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L173_done
.L173_w4:
    cmp x10, #4
    b.lt .L173_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L173_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L173_eq
    add x8, x8, x14
.L173_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L173_done
.L173_w2:
    cmp x10, #2
    b.lt .L173_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L173_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L173_eq
    add x8, x8, x14
.L173_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L173_done
.L173_tail:
    cmp x8, x13
    b.ge .L173_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L173_th
    add x8, x8, #1
    add x9, x9, #1
    b .L173_tail
.L173_th:
    sub x2, x8, x12
    b .L173_done
.L173_eq:
    mov x2, x4
.L173_done:
    mov x14, x2
    mov x0, x14
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_3:
    mov x14, #2
    and x14, x10, x14
    cbz x14, .Lssa___sem_byte_view_mismatch_9
.Lssa___sem_byte_view_mismatch_7:
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L174_aop
    mov x1, #0
.L174_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L174_bop
    mov x3, #0
.L174_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L174_nok
    mov x4, #0
.L174_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L174_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L174_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L174_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L174_vec
.L174_short:
    cmp x10, #8
    b.lt .L174_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L174_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L174_eq
    add x8, x8, x14
.L174_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_w4:
    cmp x10, #4
    b.lt .L174_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L174_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L174_eq
    add x8, x8, x14
.L174_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_w2:
    cmp x10, #2
    b.lt .L174_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L174_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L174_eq
    add x8, x8, x14
.L174_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_tail:
    cmp x8, x13
    b.ge .L174_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L174_th
    add x8, x8, #1
    add x9, x9, #1
    b .L174_tail
.L174_th:
    sub x2, x8, x12
    b .L174_done
.L174_eq:
    mov x2, x4
.L174_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_9:
    mov x4, x12
    mov x3, x11
    mov x2, x10
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2]
    add x2, x2, #8
    cmp x1, #0
    b.ge .L175_aop
    mov x1, #0
.L175_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L175_bop
    mov x3, #0
.L175_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L175_nok
    mov x4, #0
.L175_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L175_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L175_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L175_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L175_vec
.L175_short:
    cmp x10, #8
    b.lt .L175_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L175_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L175_eq
    add x8, x8, x14
.L175_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_w4:
    cmp x10, #4
    b.lt .L175_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L175_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L175_eq
    add x8, x8, x14
.L175_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_w2:
    cmp x10, #2
    b.lt .L175_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L175_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L175_eq
    add x8, x8, x14
.L175_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_tail:
    cmp x8, x13
    b.ge .L175_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L175_th
    add x8, x8, #1
    add x9, x9, #1
    b .L175_tail
.L175_th:
    sub x2, x8, x12
    b .L175_done
.L175_eq:
    mov x2, x4
.L175_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
_start:
    adrp x9, .Lfern_relanchor
    add x9, x9, :lo12:.Lfern_relanchor
    ldr x10, [x9]
    sub x9, x9, x10
    cbz x9, .Lfern_reloc_done
    adrp x11, .Lfern_sbox_begin
    add x11, x11, :lo12:.Lfern_sbox_begin
    adrp x12, .Lfern_sbox_end
    add x12, x12, :lo12:.Lfern_sbox_end
.Lfern_sbox_loop:
    cmp x11, x12
    b.hs .Lfern_sbox_done
    ldr x13, [x11, #8]
    add x13, x13, x9
    str x13, [x11, #8]
    add x11, x11, #24
    b .Lfern_sbox_loop
.Lfern_sbox_done:
    adrp x11, .Lfern_cagg_begin
    add x11, x11, :lo12:.Lfern_cagg_begin
    adrp x12, .Lfern_cagg_end
    add x12, x12, :lo12:.Lfern_cagg_end
.Lfern_cagg_loop:
    cmp x11, x12
    b.hs .Lfern_cagg_done
    ldr x13, [x11, #16]
    add x13, x13, x9
    str x13, [x11, #16]
    ldr x14, [x11]
    add x11, x11, #16
    add x11, x11, x14, lsl #3
    b .Lfern_cagg_loop
.Lfern_cagg_done:
    adrp x11, .Lfern_cfn_begin
    add x11, x11, :lo12:.Lfern_cfn_begin
    adrp x12, .Lfern_cfn_end
    add x12, x12, :lo12:.Lfern_cfn_end
.Lfern_cfn_loop:
    cmp x11, x12
    b.hs .Lfern_cfn_done
    ldr x13, [x11, #24]
    add x13, x13, x9
    str x13, [x11, #24]
    add x11, x11, #32
    b .Lfern_cfn_loop
.Lfern_cfn_done:
    adrp x11, .Lfern_cref_begin
    add x11, x11, :lo12:.Lfern_cref_begin
    adrp x12, .Lfern_cref_end
    add x12, x12, :lo12:.Lfern_cref_end
.Lfern_cref_loop:
    cmp x11, x12
    b.hs .Lfern_reloc_done
    ldr x13, [x11]
    add x13, x13, x9
    ldr x14, [x13]
    add x14, x14, x9
    str x14, [x13]
    add x11, x11, #8
    b .Lfern_cref_loop
.Lfern_reloc_done:
    ldr x0, [sp]
    lsl x0, x0, #3
    add x0, x0, #16
    add x0, sp, x0
    adrp x1, __fern_envp
    add x1, x1, :lo12:__fern_envp
    str x0, [x1]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #30
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_stack_map_failed
    mov x19, x0
    mov x1, #1
    lsl x1, x1, #20
    mov x2, #0
    mov x8, #226
    svc #0
    cbnz x0, .Lfern_stack_guard_failed
    mov x9, #1
    lsl x9, x9, #30
    add x9, x19, x9
    sub sp, x9, #16
    mov x10, sp
    adrp x11, __fern_stack_top
    add x11, x11, :lo12:__fern_stack_top
    str x10, [x11]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #16
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_signal_stack_map_failed
    mov x9, #1
    lsl x9, x9, #16
    sub sp, sp, #32
    stp x0, xzr, [sp]
    str x9, [sp, #16]
    mov x0, sp
    mov x1, #0
    mov x8, #132
    svc #0
    cbnz x0, .Lfern_signal_stack_failed
    adrp x9, __fern_segv
    add x9, x9, :lo12:__fern_segv
    mov x10, #4
    movk x10, #0x800, lsl #16
    mov x11, #0x448
    stp x9, x10, [sp]
    stp xzr, x11, [sp, #16]
    bl .Lfern_fault_install
    cbnz x0, .Lfern_fault_handler_failed
    add sp, sp, #32
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    bl __fn_main
    mov x8, #94
    svc #0
__fn___fern_str_concat:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_concat.k:
__fn___fern_str_concat.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_concat_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    add x9, x21, x22
    sxtw x23, w9
    mov x0, x23
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    ldr x9, [x19, #0]
    mov x2, x21
    mov x1, x9
    mov x0, x24
    cbz x2, .Lssa___fern_str_concat_mcd18
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb18
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc18:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct18
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc18
.Lssa___fern_str_concat_mct18:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd18
.Lssa___fern_str_concat_mcb18:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb18
.Lssa___fern_str_concat_mcd18:
    mov x0, #0
    sxtw x21, w21
    add x21, x24, x21
    ldr x9, [x20, #0]
    mov x2, x22
    mov x1, x9
    mov x0, x21
    cbz x2, .Lssa___fern_str_concat_mcd34
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb34
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc34:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct34
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc34
.Lssa___fern_str_concat_mct34:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd34
.Lssa___fern_str_concat_mcb34:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb34
.Lssa___fern_str_concat_mcd34:
    mov x0, #0
    mov x0, x24
    mov x1, x23
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_eq:
    ldr x0, [sp]
    ldr x9, [sp, #16]
__fn___fern_str_eq.r:
    cmp x0, x9
    b.eq .Lseq_yes
    ldr x4, [x0, #8]
    ldr x5, [x9, #8]
    cmp x4, x5
    b.ne .Lseq_no
    ldr x2, [x0]
    ldr x3, [x9]
    cmp x2, x3
    b.eq .Lseq_yes
    add x6, x2, x4
    add x7, x3, x4
    cmp x4, #8
    b.lo .Lseq_short
    sub x6, x6, #8
    sub x7, x7, #8
.Lseq_word:
    ldr x0, [x2]
    ldr x1, [x3]
    cmp x0, x1
    b.ne .Lseq_no
    add x2, x2, #8
    add x3, x3, #8
    cmp x2, x6
    b.lo .Lseq_word
    ldr x0, [x6]
    ldr x1, [x7]
    cmp x0, x1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_short:
    cbz x4, .Lseq_yes
    cmp x4, #4
    b.lo .Lseq_byte
    ldr w0, [x2]
    ldr w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #4
    sub x7, x7, #4
    ldr w0, [x6]
    ldr w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_byte:
    ldrb w0, [x2]
    ldrb w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #1
    sub x7, x7, #1
    ldrb w0, [x6]
    ldrb w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    cmp x4, #3
    b.lo .Lseq_yes
    ldrb w0, [x2, #1]
    ldrb w1, [x3, #1]
    cmp w0, w1
    b.ne .Lseq_no
.Lseq_yes:
    mov x0, #1
    ret
.Lseq_no:
    mov x0, #0
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .bss
    .align 3
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 3
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 3
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 3
__fern_rc_underflow: .quad 0
    .align 3
__fern_map_seed: .quad 0
    .align 3
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 3
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 3
__fern_freelist_shadow: .skip 524288
    .align 3
__fern_large_freelist_shadow: .skip 20480
    .text
.globl __fern_capw
__fern_capw:
    stp x9, x10, [sp, #-32]!
    str x11, [sp, #16]
    ldr x9, [sp, #32]
    cmp x9, #256
    b.ls .Lcapw_ret
    clz x10, x9
    mov x11, #61
    sub x10, x11, x10
    mov x11, #1
    lsl x11, x11, x10
    add x9, x9, x11
    sub x9, x9, #1
    neg x11, x11
    and x9, x9, x11
    mov x10, #0x10000
    cmp x9, x10
    b.lo .Lcapw_store
    mov x9, #65535
.Lcapw_store:
    str x9, [sp, #32]
.Lcapw_ret:
    ldr x11, [sp, #16]
    ldp x9, x10, [sp], #32
    ret
.globl __fern_alloc
.type __fern_alloc, %function
__fern_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    add x0, x0, #7
    lsr x3, x0, #3
    lsl x0, x3, #3
    mov x2, #0x10000
    cmp x3, x2
    b.hs .Lalloc_large
    cmp x3, #256
    b.ls .L176
    str x3, [sp, #-16]!
    bl __fern_capw
    ldr x3, [sp], #16
.L176:
    lsl x0, x3, #3
    adrp x1, __fern_freelist
    add x1, x1, :lo12:__fern_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_large:
    mov x1, #1
    lsl x1, x1, #34
    cmp x0, x1
    b.hi .Lalloc_nofl
    mov x1, #1
    lsl x1, x1, #19
    cmp x0, x1
    csel x0, x1, x0, lo
    clz x1, x0
    mov x3, #61
    sub x3, x3, x1
    mov x1, #1
    lsl x1, x1, x3
    sub x1, x1, #1
    add x0, x0, x1
    bic x0, x0, x1
    clz x1, x0
    mov x3, #61
    sub x1, x3, x1
    lsr x3, x0, x1
    add x3, x3, x1, lsl #2
    sub x3, x3, #72
    adrp x1, __fern_large_freelist
    add x1, x1, :lo12:__fern_large_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_nofl:
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    ldr x2, [x1]
    cbnz x2, .Lalloc_inited
    stp x4, x5, [sp, #-16]!
    stp x8, x9, [sp, #-16]!
    mov x9, x0
    mov x0, #1
    lsl x0, x0, #28
    movz x1, #0
    movk x1, #4, lsl #32
    mov x2, #3
    mov x3, #0x4022
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    cmn x0, #0
    b.mi .Lalloc_map_fail
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    str x0, [x1]
    adrp x1, __fern_heap_base
    add x1, x1, :lo12:__fern_heap_base
    str x0, [x1]
    movz x2, #0
    movk x2, #4, lsl #32
    add x2, x0, x2
    adrp x3, __fern_heap_end
    add x3, x3, :lo12:__fern_heap_end
    str x2, [x3]
    mov x0, x9
    ldp x8, x9, [sp], #16
    ldp x4, x5, [sp], #16
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
.Lalloc_inited:
    ldr x2, [x1]
    adds x3, x2, x0
    b.cs __fern_alloc_size_abort
    str x4, [sp, #-16]!
    adrp x4, __fern_heap_end
    add x4, x4, :lo12:__fern_heap_end
    ldr x4, [x4]
    cmp x3, x4
    ldr x4, [sp], #16
    b.hi .Lalloc_oom
    str x3, [x1]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .text
.Lalloc_oom:
    adrp x1, .Lmsg_oom
    add x1, x1, :lo12:.Lmsg_oom
    mov x2, #43
    mov x0, #125
    b __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .text
.Lalloc_map_fail:
    neg x9, x0
    sub sp, sp, #96
    add x10, sp, #96
    mov x12, #10
    sub x10, x10, #1
    strb w12, [x10]
    mov x11, #41
    sub x10, x10, #1
    strb w11, [x10]
.Lmap_fail_digit:
    udiv x13, x9, x12
    msub x14, x13, x12, x9
    add x14, x14, #48
    sub x10, x10, #1
    strb w14, [x10]
    mov x9, x13
    cbnz x9, .Lmap_fail_digit
    adrp x15, .Lmsg_map_fail
    add x15, x15, :lo12:.Lmsg_map_fail
    add x15, x15, #42
    mov x11, #42
.Lmap_fail_copy:
    sub x15, x15, #1
    ldrb w14, [x15]
    sub x10, x10, #1
    strb w14, [x10]
    subs x11, x11, #1
    b.ne .Lmap_fail_copy
    mov x1, x10
    add x2, sp, #96
    sub x2, x2, x10
    mov x0, #123
    b __fern_report
.size __fern_alloc, .-__fern_alloc
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .text
__fern_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_oob_abort
.type __fern_oob_abort, %function
__fern_oob_abort:
    adrp x1, .Lmsg_arr_oob
    add x1, x1, :lo12:.Lmsg_arr_oob
    mov x2, #31
    b __fern_abort_134
.size __fern_oob_abort, .-__fern_oob_abort
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .text
__fern_str_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_str_oob_abort
.type __fern_str_oob_abort, %function
__fern_str_oob_abort:
    adrp x1, .Lmsg_str_oob
    add x1, x1, :lo12:.Lmsg_str_oob
    mov x2, #32
    b __fern_abort_134
.size __fern_str_oob_abort, .-__fern_str_oob_abort
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .text
__fern_slice_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_slice_abort
.type __fern_slice_abort, %function
__fern_slice_abort:
    adrp x1, .Lmsg_slice
    add x1, x1, :lo12:.Lmsg_slice
    mov x2, #32
    b __fern_abort_134
.size __fern_slice_abort, .-__fern_slice_abort
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .text
__fern_alloc_size_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_alloc_size_abort
.type __fern_alloc_size_abort, %function
__fern_alloc_size_abort:
    adrp x1, .Lmsg_alloc_size
    add x1, x1, :lo12:.Lmsg_alloc_size
    mov x2, #35
    b __fern_abort_134
.size __fern_alloc_size_abort, .-__fern_alloc_size_abort
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .text
.globl __fern_free_range_abort
.type __fern_free_range_abort, %function
__fern_free_range_abort:
    adrp x1, .Lmsg_free_range
    add x1, x1, :lo12:.Lmsg_free_range
    mov x2, #41
    b __fern_abort_134
.size __fern_free_range_abort, .-__fern_free_range_abort
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .text
__fern_double_free_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_double_free_abort
.type __fern_double_free_abort, %function
__fern_double_free_abort:
    adrp x1, .Lmsg_double_free
    add x1, x1, :lo12:.Lmsg_double_free
    mov x2, #45
    b __fern_abort_134
.size __fern_double_free_abort, .-__fern_double_free_abort
__fern_arr_box:
    movz x1, #65535
    movk x1, #4095, lsl #16
    cmp x0, x1
    b.ls .Larrbox_sized
    b __fern_alloc_size_abort_leaf
.Larrbox_sized:
    add x1, x0, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Larrbox_alloc
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    add x1, x2, x1
    ldr x2, [x1]
    cbz x2, .Larrbox_miss
    ldr x3, [x2]
    str x3, [x1]
    str x0, [x2]
    mov w3, #1
    str w3, [x2, #8]
    str x0, [x2, #16]
    add x0, x2, #16
    ret
.Larrbox_miss:
    add x1, x0, #3
    lsl x1, x1, #3
.Larrbox_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    mov x0, x1
    bl __fern_alloc
    ldr x1, [sp]
    str x1, [x0]
    mov w2, #1
    str w2, [x0, #8]
    str x1, [x0, #16]
    add x0, x0, #16
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
__fern_str_box:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x0, #24
    bl __fern_alloc
    mov x2, #1
    str x2, [x0]
    ldp x2, x3, [sp], #16
    str x2, [x0, #8]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fern_str_box_hdr:
    sub x2, x0, #24
    mov w3, #1
    str w3, [x2]
    mov w4, #32781
    movk w4, #29519, lsl #16
    stur w4, [x2, #4]
    str x0, [x2, #8]
    str x1, [x2, #16]
    add x0, x2, #8
    ret
.globl __fern_buf_new
.type __fern_buf_new, %function
__fern_buf_new:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cmp x19, #16
    b.hs .Lbufnew_cap
    mov x19, #16
.Lbufnew_cap:
    mov x0, #32
    bl __fern_alloc
    mov x20, x0
    mov x0, x19
    bl __fern_alloc
    str x0, [x20]
    str xzr, [x20, #8]
    str x19, [x20, #16]
    str x19, [x20, #24]
    mov x0, x20
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_new, .-__fern_buf_new
.globl __fern_buf_reserve
.type __fern_buf_reserve, %function
__fern_buf_reserve:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19, #16]
    cbnz x21, .Lbufres_dbl
    ldr x21, [x19, #24]
    cbnz x21, .Lbufres_dbl
    mov x21, #64
.Lbufres_dbl:
    cmp x21, x20
    b.hs .Lbufres_alloc
    lsl x21, x21, #1
    b .Lbufres_dbl
.Lbufres_alloc:
    mov x0, x21
    bl __fern_alloc
    mov x22, x0
    ldr x2, [x19, #8]
    cbz x2, .Lbufres_nocopy
    ldr x1, [x19]
    mov x3, x22
    cbz x2, .Lbufres_copy_d
    cmp x2, #8
    b.lo .Lbufres_copy_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x3, x2
    sub x11, x11, #8
.Lbufres_copy_w:
    cmp x3, x11
    b.hs .Lbufres_copy_t
    ldr x9, [x1], #8
    str x9, [x3], #8
    b .Lbufres_copy_w
.Lbufres_copy_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufres_copy_d
.Lbufres_copy_b:
    ldrb w9, [x1], #1
    strb w9, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufres_copy_b
.Lbufres_copy_d:
.Lbufres_nocopy:
    ldr x5, [x19]
    cbz x5, .Lbufres_store
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbufres_old_large
    cmp x6, #256
    b.ls .L177
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L177:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbufres_old_done
.Lbufres_old_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbufres_old_done:
.Lbufres_store:
    str x22, [x19]
    str x21, [x19, #16]
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_reserve, .-__fern_buf_reserve
.globl __fern_buf_push
.type __fern_buf_push, %function
__fern_buf_push:
    ldrsw x3, [x1, #8]
    cbz x3, .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufpush_grow
    str x5, [x0, #8]
    ldr x1, [x1]
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
    b .Lbufrange_tail
.Lbufpush_grow:
    mov x2, #0
    b .Lbufrange_grow
.size __fern_buf_push, .-__fern_buf_push
.globl __fern_buf_push_range
.type __fern_buf_push_range, %function
__fern_buf_push_range:
    sxtw x2, w2
    sxtw x3, w3
    tbz x2, #63, .Lbufrange_lo
    b __fern_slice_abort_leaf
.Lbufrange_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lbufrange_hi
    b __fern_slice_abort_leaf
.Lbufrange_hi:
    subs x3, x3, x2
    b.ge .Lbufrange_range
    b __fern_slice_abort_leaf
.Lbufrange_range:
    b.eq .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufrange_grow
.Lbufrange_copy:
    str x5, [x0, #8]
    ldr x1, [x1]
    add x1, x1, x2
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
.Lbufrange_tail:
    cbz x2, .Lbufrange_done
    cmp x2, #8
    b.lo .Lbufrange_loop_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x6, x2
    sub x11, x11, #8
.Lbufrange_loop_w:
    cmp x6, x11
    b.hs .Lbufrange_loop_t
    ldr x9, [x1], #8
    str x9, [x6], #8
    b .Lbufrange_loop_w
.Lbufrange_loop_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufrange_done
.Lbufrange_loop_b:
    ldrb w9, [x1], #1
    strb w9, [x6], #1
    sub x2, x2, #1
    cbnz x2, .Lbufrange_loop_b
.Lbufrange_done:
    ret
.Lbufrange_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    stp x2, x3, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x2, x3, [sp], #16
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, x3
    b .Lbufrange_copy
.size __fern_buf_push_range, .-__fern_buf_push_range
.globl __fern_buf_push_byte
.type __fern_buf_push_byte, %function
__fern_buf_push_byte:
    ldr x4, [x0, #8]
    add x5, x4, #1
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufbyte_grow
.Lbufbyte_fits:
    ldr x6, [x0]
    strb w1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufbyte_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #1
    b .Lbufbyte_fits
.size __fern_buf_push_byte, .-__fern_buf_push_byte
.globl __fern_buf_push_u64
.type __fern_buf_push_u64, %function
__fern_buf_push_u64:
    ldr x4, [x0, #8]
    add x5, x4, #8
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufu64_grow
.Lbufu64_fits:
    ldr x6, [x0]
    str x1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufu64_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #8
    b .Lbufu64_fits
.size __fern_buf_push_u64, .-__fern_buf_push_u64
.globl __fern_buf_push_decimal
.type __fern_buf_push_decimal, %function
__fern_buf_push_decimal:
    stp x29, x30, [sp, #-64]!
    mov x29, sp
    add x8, sp, #40
    adrp x11, .Ldecimal_pairs
    add x11, x11, :lo12:.Ldecimal_pairs
    mov x9, #0xf5c3
    movk x9, #0x5c28, lsl #16
    movk x9, #0xc28f, lsl #32
    movk x9, #0x28f5, lsl #48
    mov x12, #100
.Ldecimal_loop:
    cmp x1, #100
    b.lo .Ldecimal_tail
    lsr x10, x1, #2
    umulh x10, x10, x9
    lsr x10, x10, #2
    msub x13, x10, x12, x1
    ldrh w13, [x11, x13, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    mov x1, x10
    b .Ldecimal_loop
.Ldecimal_tail:
    cmp x1, #10
    b.lo .Ldecimal_one
    ldrh w13, [x11, x1, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    b .Ldecimal_copy
.Ldecimal_one:
    add w13, w1, #48
    sub x8, x8, #1
    strb w13, [x8]
.Ldecimal_copy:
    add x2, sp, #40
    sub x2, x2, x8
    ldr x3, [x0, #8]
    add x4, x3, x2
    ldr x5, [x0, #16]
    cmp x4, x5
    b.hi .Ldecimal_grow
.Ldecimal_fits:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x3
.Ldecimal_byte:
    ldrb w6, [x8], #1
    strb w6, [x5], #1
    subs x2, x2, #1
    b.ne .Ldecimal_byte
    ldp x29, x30, [sp], #64
    ret
.Ldecimal_grow:
    str x0, [sp, #40]
    stp x2, x8, [sp, #48]
    mov x1, x4
    bl __fern_buf_reserve
    ldr x0, [sp, #40]
    ldp x2, x8, [sp, #48]
    ldr x3, [x0, #8]
    add x4, x3, x2
    b .Ldecimal_fits
.size __fern_buf_push_decimal, .-__fern_buf_push_decimal
    .section .rodata
.Ldecimal_pairs:
    .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
    .text
.globl __fern_buf_len
.type __fern_buf_len, %function
__fern_buf_len:
    ldr x0, [x0, #8]
    ret
.size __fern_buf_len, .-__fern_buf_len
.globl __fern_buf_clear
.type __fern_buf_clear, %function
__fern_buf_clear:
    str xzr, [x0, #8]
    mov x0, #0
    ret
.size __fern_buf_clear, .-__fern_buf_clear
.globl __fern_buf_take
.type __fern_buf_take, %function
__fern_buf_take:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    bl __fn___fern_buf_take_text
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_take, .-__fern_buf_take
__fn___fern_buf_text_part:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_buf_text_part.k:
__fn___fern_buf_text_part.r:
.Lssa___fern_buf_text_part_0:
    ldrb w11, [x0, x9]
    cmp x11, #128
    b.ge .Lssa___fern_buf_text_part_18
.Lssa___fern_buf_text_part_20:
    mov x0, #1
    ret
.Lssa___fern_buf_text_part_18:
    cmp x11, #194
    b.lt .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_17:
    cmp x11, #223
    b.gt .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_16:
    mov x12, #2
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_15:
    cmp x11, #224
    b.lt .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_14:
    cmp x11, #239
    b.gt .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_13:
    mov x12, #3
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_12:
    cmp x11, #240
    b.lt .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_11:
    cmp x11, #244
    b.gt .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_10:
    mov x12, #4
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_9:
    mov x12, #0
.Lssa___fern_buf_text_part_8:
.Lssa___fern_buf_text_part_7:
    sub x10, x10, x9
    sxtw x10, w10
    mov x13, #1
.Lssa___fern_buf_text_part_52:
    cmp x13, x12
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_67:
    cmp x13, x10
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_66:
    add x14, x9, x13
    sxtw x14, w14
    ldrb w15, [x0, x14]
    cmp x15, #128
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_65:
    cmp x15, #191
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_63:
    cmp x13, #1
    b.ne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_62:
    cmp x11, #224
    b.ne .Lssa___fern_buf_text_part_60
.Lssa___fern_buf_text_part_61:
    cmp x15, #160
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_60:
    cmp x11, #237
    b.ne .Lssa___fern_buf_text_part_58
.Lssa___fern_buf_text_part_59:
    cmp x15, #159
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_58:
    cmp x11, #240
    b.ne .Lssa___fern_buf_text_part_56
.Lssa___fern_buf_text_part_57:
    cmp x15, #144
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_56:
    cmp x11, #244
    b.ne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_55:
    cmp x15, #143
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_53:
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___fern_buf_text_part_67
.Lssa___fern_buf_text_part_4:
    mov x10, #0
    sub x10, x10, x13
    sxtw x10, w10
    cmp x13, x12
    csel x0, x13, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn___fern_buf_take_text:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_buf_take_text.k:
__fn___fern_buf_take_text.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x0
.Lssa___fern_buf_take_text_0:
    ldr x9, [x19, #8]
    cmp x9, #0
    b.lt .Lssa___fern_buf_take_text_16
.Lssa___fern_buf_take_text_17:
    movn w10, #32768, lsl #16
    cmp x9, x10
    b.le .Lssa___fern_buf_take_text_14
.Lssa___fern_buf_take_text_16:
    mov x10, #-1
    mov x0, x10
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x10, #0
    mov x1, x10
    bl __fern_str_box_hdr
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_14:
    sxtw x20, w9
    cmp x20, #0
    b.ne .Lssa___fern_buf_take_text_11
.Lssa___fern_buf_take_text_13:
    adrp x0, .SB8
    add x0, x0, :lo12:.SB8
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_11:
    ldr x21, [x19, #0]
    ldr x22, =9259542123273814144
.Lssa___fern_buf_take_text_10:
    mov x23, x9
    mov x24, #0
    mov x25, #0
.Lssa___fern_buf_take_text_30:
    cmp x24, x20
    b.ge .Lssa___fern_buf_take_text_9
.Lssa___fern_buf_take_text_40:
    sub x9, x20, x24
    sxtw x9, w9
    cmp x9, #8
    b.lt .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_39:
    add x9, x21, x24
    ldr x11, [x9, #0]
    and x11, x11, x22
    cmp x11, #0
    b.ne .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_38:
    add x11, x24, #8
    sxtw x24, w11
    cmp x24, x20
    b.ge .Lssa___fern_buf_take_text_9
    b .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_34:
    mov x0, x21
    mov x9, x24
    mov x10, x20
    bl __fn___fern_buf_text_part.r
    cmp x0, #0
    b.ge .Lssa___fern_buf_take_text_32
.Lssa___fern_buf_take_text_33:
    add x11, x0, #3
    sxtw x11, w11
    add x11, x23, x11
    sub x9, x24, x0
    sxtw x9, w9
    mov x23, x11
    mov x24, x9
    mov x25, #1
    b .Lssa___fern_buf_take_text_30
.Lssa___fern_buf_take_text_32:
    add x24, x24, x0
    sxtw x24, w24
.Lssa___fern_buf_take_text_31:
    cmp x24, x20
    b.lt .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_9:
    movn w9, #32768, lsl #16
    cmp x23, x9
    b.le .Lssa___fern_buf_take_text_6
.Lssa___fern_buf_take_text_8:
    mov x9, #-1
    mov x0, x9
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x9, #0
    mov x1, x9
    bl __fern_str_box_hdr
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_6:
    sxtw x23, w23
    mov x0, x23
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    cbz x25, .Lssa___fern_buf_take_text_2
.Lssa___fern_buf_take_text_5:
.Lssa___fern_buf_take_text_4:
    mov x25, #0
    mov x26, #0
    mov x27, #0
.Lssa___fern_buf_take_text_70:
    cmp x25, x20
    b.ge .Lssa___fern_buf_take_text_3
.Lssa___fern_buf_take_text_80:
    sub x11, x20, x25
    sxtw x11, w11
    cmp x11, #8
    b.lt .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_79:
    add x11, x21, x25
    ldr x9, [x11, #0]
    and x9, x9, x22
    cmp x9, #0
    b.ne .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_78:
    add x9, x25, #8
    sxtw x25, w9
    cmp x25, x20
    b.ge .Lssa___fern_buf_take_text_3
    b .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_74:
    mov x0, x21
    mov x9, x25
    mov x10, x20
    bl __fn___fern_buf_text_part.r
    mov x28, x0
    cmp x28, #0
    b.ge .Lssa___fern_buf_take_text_72
.Lssa___fern_buf_take_text_73:
    sxtw x9, w27
    add x9, x24, x9
    add x11, x21, x26
    sub x10, x25, x26
    sxtw x10, w10
    str x10, [sp, #56]
    mov x2, x10
    mov x1, x11
    mov x0, x9
    cbz x2, .Lssa___fern_buf_take_text_mcd338
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb338
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc338:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct338
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc338
.Lssa___fern_buf_take_text_mct338:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd338
.Lssa___fern_buf_take_text_mcb338:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb338
.Lssa___fern_buf_take_text_mcd338:
    mov x0, #0
    ldr x10, [sp, #56]
    add x10, x27, x10
    sxtw x10, w10
    mov x11, #239
    strb w11, [x24, x10]
    add x9, x10, #1
    sxtw x9, w9
    mov x11, #191
    strb w11, [x24, x9]
    add x12, x10, #2
    sxtw x12, w12
    mov x11, #189
    strb w11, [x24, x12]
    add x10, x10, #3
    sub x9, x25, x28
    sxtw x9, w9
    mov x25, x9
    mov x26, x9
    mov x27, x10
    b .Lssa___fern_buf_take_text_70
.Lssa___fern_buf_take_text_72:
    add x25, x25, x28
    sxtw x25, w25
.Lssa___fern_buf_take_text_71:
    cmp x25, x20
    b.lt .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_3:
    sxtw x27, w27
    add x27, x24, x27
    add x9, x21, x26
    sub x26, x20, x26
    sxtw x26, w26
    mov x2, x26
    mov x1, x9
    mov x0, x27
    cbz x2, .Lssa___fern_buf_take_text_mcd435
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb435
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc435:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct435
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc435
.Lssa___fern_buf_take_text_mct435:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd435
.Lssa___fern_buf_take_text_mcb435:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb435
.Lssa___fern_buf_take_text_mcd435:
    mov x0, #0
    b .Lssa___fern_buf_take_text_1
.Lssa___fern_buf_take_text_2:
    mov x2, x20
    mov x1, x21
    mov x0, x24
    cbz x2, .Lssa___fern_buf_take_text_mcd442
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb442
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc442:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct442
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc442
.Lssa___fern_buf_take_text_mct442:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd442
.Lssa___fern_buf_take_text_mcb442:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb442
.Lssa___fern_buf_take_text_mcd442:
    mov x0, #0
.Lssa___fern_buf_take_text_1:
    mov x9, #0
    str x9, [x19, #8]
    mov x0, x24
    mov x1, x23
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.globl __fern_buf_free
.type __fern_buf_free, %function
__fern_buf_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cbz x19, .Lbuffree_ret
    ldr x5, [x19]
    cbz x5, .Lbuffree_ctl
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_data_large
    cmp x6, #256
    b.ls .L178
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L178:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbuffree_data_done
.Lbuffree_data_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbuffree_data_done:
.Lbuffree_ctl:
    mov x5, x19
    mov x6, #4
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_ctlblk_large
    cmp x6, #256
    b.ls .L179
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L179:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbuffree_ctlblk_done
.Lbuffree_ctlblk_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbuffree_ctlblk_done:
.Lbuffree_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_free, .-__fern_buf_free
__fn___alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    bl __fern_alloc
    ldp x29, x30, [sp], #16
    ret
__fn___free:
    ret
__fn___memset:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    ldr x2, [x29, #48]
    cbz x2, .Lfnmemset_done
.Lfnmemset_loop:
    strb w1, [x0], #1
    subs x2, x2, #1
    bne .Lfnmemset_loop
.Lfnmemset_done:
    ldp x29, x30, [sp], #16
    ret
__fn___load_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldrsw x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str w1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_i64:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str x1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___ptr_width:
    mov x0, #8
    ret
__fn___fern_rc_inc:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcinc_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcinc_ret
    and x0, x0, #0xfffffffffffffffd
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcinc_ret
    add w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcinc_ret:
    ldr x0, [sp]
    ret
__fn___fern_rc_dec:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcdec_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcdec_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcdec_ret
    cmp w1, #0
    bgt .Lshrcdec_dec
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w11, [x10]
    add w11, w11, #1
    str w11, [x10]
.Lshrcdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcdec_ret:
    ret
__fn___fern_rc_is_unique:
    ldr x2, [sp]
    mov x0, #0
    tbnz x2, #0, .Lshuniq_ret
    mov x9, #0x10000
    cmp x2, x9
    blo .Lshuniq_ret
    and x2, x2, #0xfffffffffffffffd
    ldur w3, [x2, #-8]
    tbnz w3, #31, .Lshuniq_ret
    cmp w3, #1
    bne .Lshuniq_ret
    mov x0, #1
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    ldr x0, [sp]
__fn___fern_arr_inc_elems.r:
    mov x9, #0x10000
    cmp x0, x9
    blo .Laie_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Laie_ret
    stp x19, x30, [sp, #-16]!
    stp x20, x21, [sp, #-16]!
    mov x19, x0
    ldr x20, [x19]
    mov x21, #0
.Laie_loop:
    cmp x21, x20
    bge .Laie_done
    add x9, x21, #1
    ldr x0, [x19, x9, lsl #3]
    str x0, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    add x21, x21, #1
    b .Laie_loop
.Laie_done:
    mov x0, x19
    ldp x20, x21, [sp], #16
    ldp x19, x30, [sp], #16
.Laie_ret:
    ret
__fn___fern_str_grow:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsg_body
__fn___fern_str_grow_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbnz x2, #63, .Lsg_no
    ldr x4, [x1, #8]
    cmp x3, x4
    b.gt .Lsg_no
    subs x3, x3, x2
    b.lt .Lsg_no
    ldr x1, [x1]
    add x1, x1, x2
.Lsg_body:
    tbnz x0, #0, .Lsg_no
    mov x9, #0x10000
    cmp x0, x9
    blo .Lsg_no
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.ne .Lsg_no
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbnz x9, .Lsg_no
    ldur w5, [x0, #-4]
    mov w6, #0x4F57
    movk w6, #0x4752, lsl #16
    cmp w5, w6
    b.ne .Lsg_fused
    add x6, x4, #39
    lsr x6, x6, #3
    ldur x7, [x0, #-16]
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_copy
.Lsg_fused:
    mov w6, #32781
    movk w6, #29519, lsl #16
    cmp w5, w6
    b.ne .Lsg_no
    add x5, x2, #31
    lsr x5, x5, #3
    add x6, x4, #31
    lsr x6, x6, #3
    cmp x6, x5
    b.eq .Lsg_copy
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lsg_large
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x7, x30, [sp], #16
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_fits
.Lsg_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsg_no
    lsl x7, x5, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x7, x7, #3
    cmp x6, x7
    b.hi .Lsg_no
.Lsg_fits:
.Lsg_copy:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsg_d
    cmp x3, #8
    b.lo .Lsg_b
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsg_w:
    cmp x5, x10
    b.hs .Lsg_t
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsg_w
.Lsg_t:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsg_d
.Lsg_b:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsg_b
.Lsg_d:
    mov x0, #1
    ret
.Lsg_no:
    mov x0, #0
    ret
__fn___fern_str_grow_fresh:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsgf_body
__fn___fern_str_grow_fresh_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbz x2, #63, .Lsgf_lo
    b __fern_slice_abort_leaf
.Lsgf_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lsgf_hi
    b __fern_slice_abort_leaf
.Lsgf_hi:
    subs x3, x3, x2
    b.ge .Lsgf_range
    b __fern_slice_abort_leaf
.Lsgf_range:
    ldr x1, [x1]
    add x1, x1, x2
.Lsgf_body:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbz x9, .Lsgf_sized
    b __fern_alloc_size_abort
.Lsgf_sized:
    add x5, x4, #39
    lsr x5, x5, #3
    add x6, x2, #31
    lsr x6, x6, #3
    lsl x6, x6, #1
    cmp x6, x5
    csel x6, x5, x6, lo
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lsgf_large
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
    b .Lsgf_alloc
.Lsgf_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsgf_alloc
    lsl x7, x6, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x6, x7, #3
.Lsgf_alloc:
    stp x0, x1, [sp, #-48]!
    stp x2, x3, [sp, #16]
    str x6, [sp, #32]
    lsl x0, x6, #3
    bl __fern_alloc
    ldr x6, [sp, #32]
    ldp x2, x3, [sp, #16]
    ldp x4, x1, [sp], #48
    str x6, [x0]
    mov w5, #1
    str w5, [x0, #8]
    mov w5, #0x4F57
    movk w5, #0x4752, lsl #16
    str w5, [x0, #12]
    add x5, x0, #32
    str x5, [x0, #16]
    add x6, x2, x3
    str x6, [x0, #24]
    ldr x6, [x4]
    cbz x2, .Lsgf_ad
    cmp x2, #8
    b.lo .Lsgf_ab
    add x9, x6, x2
    sub x9, x9, #8
    add x10, x5, x2
    sub x10, x10, #8
.Lsgf_aw:
    cmp x5, x10
    b.hs .Lsgf_at
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_aw
.Lsgf_at:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_ad
.Lsgf_ab:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x2, x2, #1
    cbnz x2, .Lsgf_ab
.Lsgf_ad:
    add x5, x0, #32
    ldr x2, [x0, #24]
    sub x2, x2, x3
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsgf_bd
    cmp x3, #8
    b.lo .Lsgf_bb
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsgf_bw:
    cmp x5, x10
    b.hs .Lsgf_bt
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_bw
.Lsgf_bt:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_bd
.Lsgf_bb:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsgf_bb
.Lsgf_bd:
    add x0, x0, #16
    ldp x29, x30, [sp], #16
    ret
__fn___fern_str_borrow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    mov x0, #24
    bl __fern_alloc
    mov w2, #1
    str w2, [x0]
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    stur w3, [x0, #4]
    ldr x2, [sp, #32]
    str x2, [x0, #8]
    ldr x3, [sp, #16]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fn___fern_alloc_reuse:
    ldr x0, [sp, #16]
    cbz x0, .Lsarelo_fresh
    ldr x1, [sp]
    ldur x2, [x0, #-16]
    cmp x2, x1
    beq .Lsarelo_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_arr_dec.r
    ldp x29, x30, [sp], #16
.Lsarelo_fresh:
    ldr x0, [sp]
    b __fern_arr_box
.Lsarelo_ret:
    ret
__fn___fern_rc_underflow_count:
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w0, [x10]
    ret
__fern_large_push:
    mov x3, #1
    lsl x3, x3, #34
    cmp x2, x3
    b.hi .Llpush_ret
    mov x3, #1
    lsl x3, x3, #19
    cmp x2, x3
    csel x2, x3, x2, lo
    clz x3, x2
    mov x4, #61
    sub x4, x4, x3
    mov x3, #1
    lsl x3, x3, x4
    sub x3, x3, #1
    add x2, x2, x3
    bic x2, x2, x3
    clz x3, x2
    mov x4, #61
    sub x3, x4, x3
    lsr x4, x2, x3
    add x4, x4, x3, lsl #2
    sub x4, x4, #72
    mov x2, x4
    adrp x3, __fern_large_freelist
    add x3, x3, :lo12:__fern_large_freelist
    ldr x4, [x3, x2, lsl #3]
    cmp x4, x1
    b.eq __fern_double_free_abort_leaf
    str x4, [x1]
    str x1, [x3, x2, lsl #3]
.Llpush_ret:
    ret
__fern_raw_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    cbz x0, .Lrawfree_done
    adrp x9, __fern_heap_base
    add x9, x9, :lo12:__fern_heap_base
    ldr x9, [x9]
    cmp x0, x9
    b.lo .Lrawfree_bad
    adrp x9, __fern_heap_end
    add x9, x9, :lo12:__fern_heap_end
    ldr x9, [x9]
    cmp x0, x9
    b.hs .Lrawfree_bad
    add x1, x1, #7
    lsr x5, x1, #3
    cbz x5, .Lrawfree_done
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lrawfree_b_large
    cmp x5, #256
    b.ls .L180
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x5, x30, [sp], #16
.L180:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x5, lsl #3]
    cmp x10, x0
    b.eq __fern_double_free_abort
    str x10, [x0]
    str x0, [x3, x5, lsl #3]
    b .Lrawfree_b_done
.Lrawfree_b_large:
    mov x1, x0
    lsl x2, x5, #3
    bl __fern_large_push
.Lrawfree_b_done:
.Lrawfree_done:
    ldp x29, x30, [sp], #16
    ret
.Lrawfree_bad:
    b __fern_free_range_abort
__fn___fern_arr_dec:
    ldr x0, [sp]
__fn___fern_arr_dec.r:
    cmp x0, #16, lsl #12
    blo .Larrdec_ret
__fn___fern_arr_dec.u:
    ldur w1, [x0, #-8]
    cmp w1, #1
    bne .Larrdec_shared
    stur wzr, [x0, #-8]
    ldur x1, [x0, #-16]
    add x1, x1, #3
    sub x2, x0, #16
    cmp x1, #256
    b.hi .Larrdec_big
.Larrdec_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Larrdec_ret:
    ret
.Larrdec_shared:
    tbnz w1, #31, .Larrdec_ret
    bgt .Larrdec_dec
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    ret
.Larrdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
    ret
.Larrdec_big:
    mov x9, #0x10000
    cmp x1, x9
    bhs .Larrdec_large
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
    b .Larrdec_push
.Larrdec_large:
    lsl x2, x1, #3
    sub x1, x0, #16
    b __fern_large_push
__fn___fern_str_free:
    ldr x0, [sp]
__fn___fern_str_free.r:
    tbnz x0, #0, .Lstrfree_ret
    cmp x0, #16, lsl #12
    blo .Lstrfree_ret
__fn___fern_str_free.u:
    mov x9, #0x10000
    ldur w4, [x0, #-8]
    cmp w4, #1
    bne .Lstrfree_shared
    ldur w2, [x0, #-4]
    mov w3, #32781
    movk w3, #29519, lsl #16
    cmp w2, w3
    beq .Lstrfree_fused
    mov w3, #0x4F57
    movk w3, #0x4752, lsl #16
    cmp w2, w3
    beq .Lstrfree_grown
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    cmp w2, w3
    beq .Lstrfree_box
    ldr x1, [x0]
    ldr x2, [x0, #8]
    cmp x1, x9
    blo .Lstrfree_box
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrfree_box
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrfree_box
    cmp x2, #0
    ble .Lstrfree_box
    add x2, x2, #7
    lsr x2, x2, #3
    cmp x2, x9
    bhs .Lstrfree_box
    cmp x2, #256
    b.ls .L181
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
.L181:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
.Lstrfree_box:
    stur wzr, [x0, #-8]
    sub x1, x0, #8
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
    b .Lstrfree_ret
.Lstrfree_grown:
    ldur x2, [x0, #-16]
    stur wzr, [x0, #-8]
    sub x1, x0, #16
    b .Lstrfree_block
.Lstrfree_fused:
    ldr x2, [x0, #8]
    add x2, x2, #7
    lsr x2, x2, #3
    add x2, x2, #3
    stur wzr, [x0, #-8]
    sub x1, x0, #8
.Lstrfree_block:
    cmp x2, #256
    b.hi .Lstrfree_fused_big
.Lstrfree_fused_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
    b .Lstrfree_ret
.Lstrfree_fused_big:
    cmp x2, x9
    bhs .Lstrfree_fused_large
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
    b .Lstrfree_fused_push
.Lstrfree_fused_large:
    lsl x2, x2, #3
    b __fern_large_push
.Lstrfree_shared:
    tbnz w4, #31, .Lstrfree_ret
    blt .Lstrfree_uf
    sub w4, w4, #1
    stur w4, [x0, #-8]
    ret
.Lstrfree_uf:
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    ldr x0, [sp]
    tbnz x0, #0, .Lstrvfree_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lstrvfree_ret
    ldur w4, [x0, #-8]
    tbnz w4, #31, .Lstrvfree_view
    b __fn___fern_str_free
.Lstrvfree_view:
    sub x1, x0, #8
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrvfree_ret
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrvfree_ret
    stur wzr, [x0, #-8]
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_arr_free.k:
__fn___fern_str_arr_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_arr_free_0:
    movz x9, #1, lsl #16
    cmp x19, x9
    b.lo .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    ldrsw x20, [x19]
.Lssa___fern_str_arr_free_4:
    mov x9, #0
.Lssa___fern_str_arr_free_15:
    cmp x9, x20
    b.ge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    add x21, x9, #1
    ldr x9, [x19, x21, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    mov x9, x21
    cmp x9, x20
    b.lt .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_drop_arr_ptr:
    ret
    .section .bss
    .align 8
__fern_envp: .quad 0
    .section .text
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_u8:
    .quad 0
    .text
.globl __fern_alloc_u8
.type __fern_alloc_u8, %function
__fern_alloc_u8:
    tbz w0, #31, .Lfern_alloc_u8_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_u8_sized:
    cbz w0, .Lfern_alloc_u8_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x0, x19
    bl __fern_arr_box
    add x2, x0, #8
    mov w1, w19
.Lfern_alloc_u8_zero:
    cbz x1, .Lfern_alloc_u8_done
    str xzr, [x2], #8
    sub x1, x1, #1
    b .Lfern_alloc_u8_zero
.Lfern_alloc_u8_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_u8_empty:
    adrp x0, .Lfern_empty_u8
    add x0, x0, :lo12:.Lfern_empty_u8
    ret
.size __fern_alloc_u8, .-__fern_alloc_u8
    .section .bss
    .align 8
__fern_sig_sp: .quad 0, 0
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
.Lmsg_illegal_instruction:
    .ascii "fern: illegal instruction\n"
.Lmsg_bus_error:
    .ascii "fern: bus error\n"
    .text
__fern_segv:
    cmp x0, #11
    b.ne .Lfern_fatal_signal
    ldr x9, [x1, #16]
    adrp x14, __fern_stack_top
    add x14, x14, :lo12:__fern_stack_top
    ldr x14, [x14]
    mov x15, #1
    lsl x15, x15, #30
    sub x14, x14, x15
    add x14, x14, #16
    sub x15, x9, x14
    mov x16, #1
    lsl x16, x16, #20
    cmp x15, x16
    b.hs .Lfern_segv_other
.Lfern_segv_overflow:
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_stack_overflow
    add x1, x1, :lo12:.Lmsg_stack_overflow
    mov x2, #21
    mov x0, #134
    b __fern_report
.Lfern_segv_other:
    stp x29, x30, [sp, #-16]!
    sub sp, sp, #32
    stp xzr, xzr, [sp]
    stp xzr, xzr, [sp, #16]
    bl .Lfern_fault_install
    add sp, sp, #32
    ldp x29, x30, [sp], #16
    ret
.Lfern_fault_install:
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x0, #11
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
    mov x0, #4
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
    mov x0, #7
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
.Lfern_fault_install_done:
    ret
.Lfern_fatal_signal:
    ldrsw x9, [x1, #8]
    cmp x9, #0
    b.le .Lfern_signal_sent
    mov x15, x0
    adrp x10, __fern_sig_sp
    add x10, x10, :lo12:__fern_sig_sp
    mov x9, sp
    str x9, [x10]
    str x30, [x10, #8]
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_illegal_instruction
    add x1, x1, :lo12:.Lmsg_illegal_instruction
    mov x2, #26
    cmp x15, #4
    b.eq .Lfern_fatal_report
    adrp x1, .Lmsg_bus_error
    add x1, x1, :lo12:.Lmsg_bus_error
    mov x2, #16
.Lfern_fatal_report:
    mov x0, #-1
    b __fern_report
.Lfern_signal_sent:
    add x0, x0, #128
    mov x8, #94
    svc #0
.Lfern_signal_resume:
    adrp x10, __fern_sig_sp
    add x10, x10, :lo12:__fern_sig_sp
    ldr x9, [x10]
    ldr x30, [x10, #8]
    mov sp, x9
    b .Lfern_segv_other
    .section .rodata
.Lfern_stack_map_failed_msg:
    .ascii "fern: could not map the stack\n"
    .text
.Lfern_stack_map_failed:
    adrp x1, .Lfern_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_stack_map_failed_msg
    mov x2, #30
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    adrp x1, .Lfern_stack_guard_failed_msg
    add x1, x1, :lo12:.Lfern_stack_guard_failed_msg
    mov x2, #40
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    adrp x1, .Lfern_signal_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_map_failed_msg
    mov x2, #37
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    adrp x1, .Lfern_signal_stack_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_failed_msg
    mov x2, #41
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    adrp x1, .Lfern_fault_handler_failed_msg
    add x1, x1, :lo12:.Lfern_fault_handler_failed_msg
    mov x2, #42
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=arm64-linux profile=minimal harden=0 pie=0 sanitize=0 backtrace=0 size=1 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .bss
    .align 3
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .align 3
__fern_bt_floor: .quad 0
    .text
.globl __fern_report
.type __fern_report, %function
__fern_abort_134:
    mov x0, #134
__fern_report:
    mov x19, x0
    mov x0, #2
    mov x8, #64
    svc #0
    tbnz x19, #63, .Lfern_signal_resume
    mov x0, x19
    mov x8, #94
    svc #0
.size __fern_report, .-__fern_report
__fern_arr_push:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Larr_push_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_slow_ok
    tbz w3, #31, .Larr_push_slow
.Larr_push_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Larr_push_slow:
    ldr x2, [x0]
    cbnz x2, .Larr_push_frame
    ldur x2, [x0, #-16]
    cbnz x2, .Larr_push_frame
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    ldr x3, [x2, #56]
    cbz x3, .Larr_push_fresh
    ldr x4, [x3]
    str x4, [x2, #56]
    mov x2, #4
    str x2, [x3]
    mov w2, #1
    str w2, [x3, #8]
    mov x2, #1
    str x2, [x3, #16]
    str x1, [x3, #24]
    add x0, x3, #16
    ret
.Larr_push_fresh:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x1, [sp, #-16]!
    mov x0, #4
    bl __fern_arr_box
    ldr x1, [sp], #16
    mov x2, #1
    str x2, [x0]
    str x1, [x0, #8]
    ldp x29, x30, [sp], #16
    ret
.Larr_push_frame:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_rc_ok
    tbnz w2, #31, .Larr_push_rc_ok
    b .Larr_push_grow
.Larr_push_rc_ok:
    cmp x21, x22
    b.ge .Larr_push_grow
    add x1, x21, #1
    str x20, [x19, x1, lsl #3]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_ret
.Larr_push_grow:
    mov x2, x22
    cmp x21, x22
    b.lt .Larr_push_shared_cliff
    cmp x22, #0
    b.ne .Larr_push_dbl
    mov x2, #4
    b .Larr_push_cap
.Larr_push_shared_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21, lsl #3
    str x4, [x3]
    b .Larr_push_cap
.Larr_push_dbl:
    lsl x2, x22, #1
.Larr_push_cap:
    add x9, x21, #1
    cmp x2, x9
    csel x2, x2, x9, hs
    mov x22, x2
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Larr_push_copy4:
    cmp x4, #4
    b.lt .Larr_push_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Larr_push_copy4
.Larr_push_copy1:
    cbz x4, .Larr_push_copy_done
.Larr_push_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Larr_push_copy1_loop
.Larr_push_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
.Larr_push_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lapo_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapo_slow_ok
    tbz w3, #31, .Lapo_slow
.Lapo_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Lapo_slow:
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.eq .Lapo_own
    b .Larr_push_slow
.Lapo_own:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    lsl x8, x22, #1
    cbnz x8, .Lapo_cap
    mov x8, #4
.Lapo_cap:
    add x9, x21, #1
    cmp x8, x9
    csel x8, x8, x9, hs
    movz x9, #65535
    movk x9, #4095, lsl #16
    cmp x8, x9
    b.ls .Lapo_sized
    b __fern_alloc_size_abort
.Lapo_sized:
    add x1, x8, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Lapo_alloc
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    add x1, x3, x1
    ldr x3, [x1]
    cbz x3, .Lapo_miss
    ldr x4, [x3]
    str x4, [x1]
.Lapo_box:
    str x8, [x3]
    mov w4, #1
    str w4, [x3, #8]
    add x0, x3, #16
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Lapo_copy4:
    cmp x4, #4
    b.lt .Lapo_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Lapo_copy4
.Lapo_copy1:
    cbz x4, .Lapo_copy_done
.Lapo_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Lapo_copy1_loop
.Lapo_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
    add x1, x22, #3
    mov x9, #0x10000
    cmp x1, x9
    b.hs .Lapo_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L182
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L182:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapo_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapo_miss:
    add x1, x8, #3
    lsl x1, x1, #3
.Lapo_alloc:
    mov x0, x1
    bl __fern_alloc
    mov x3, x0
    b .Lapo_box
.Lapo_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapo_ret
__fern_arr_push_u8:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Larr_push_u8_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_u8_slow_ok
    tbz w3, #31, .Larr_push_u8_slow
.Larr_push_u8_slow_ok:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    ret
.Larr_push_u8_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_u8_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_u8_rc_ok
    tbnz w2, #31, .Larr_push_u8_rc_ok
    b .Larr_push_u8_grow
.Larr_push_u8_rc_ok:
    lsl x2, x22, #3
    cmp x21, x2
    b.ge .Larr_push_u8_grow
    add x2, x19, x21
    strb w20, [x2, #8]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_u8_ret
.Larr_push_u8_grow:
    mov x2, x22
    lsl x3, x22, #3
    cmp x21, x3
    b.lt .Larr_push_u8_cliff
    cbnz x22, .Larr_push_u8_dbl
    mov x2, #4
    b .Larr_push_u8_cap
.Larr_push_u8_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21
    str x4, [x3]
    b .Larr_push_u8_cap
.Larr_push_u8_dbl:
    lsl x2, x22, #1
.Larr_push_u8_cap:
    add x3, x21, #8
    lsr x3, x3, #3
    cmp x2, x3
    csel x2, x2, x3, hs
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    add x4, x21, #7
    lsr x4, x4, #3
.Larr_push_u8_copy:
    cbz x4, .Larr_push_u8_copied
    ldr x5, [x2], #8
    str x5, [x3], #8
    sub x4, x4, #1
    b .Larr_push_u8_copy
.Larr_push_u8_copied:
    add x2, x0, x21
    strb w20, [x2, #8]
.Larr_push_u8_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned_u8:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lapou_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapou_slow_ok
    tbz w3, #31, .Lapou_slow
.Lapou_slow_ok:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    ret
.Lapou_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    bl .Larr_push_u8_slow
    cmp x0, x19
    beq .Lapou_ret
    mov x9, #0x10000
    cmp x19, x9
    blo .Lapou_ret
    ldur w1, [x19, #-8]
    tbnz w1, #31, .Lapou_ret
    cmp w1, #1
    bne .Lapou_ret
    ldur x1, [x19, #-16]
    add x1, x1, #3
    mov x9, #0x10000
    cmp x1, x9
    bhs .Lapou_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L183
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L183:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapou_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapou_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapou_ret
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .text
__fern_alloc_bytes:
    tbz w0, #31, .Lfern_alloc_bytes_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_bytes_sized:
    cbz w0, .Lfern_alloc_bytes_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    sxtw x19, w0
    add x0, x19, #7
    lsr x0, x0, #3
    mov x20, x0
    bl __fern_arr_box
    str x19, [x0]
    add x2, x0, #8
.Lfern_alloc_bytes_zero:
    cbz x20, .Lfern_alloc_bytes_done
    str xzr, [x2], #8
    sub x20, x20, #1
    b .Lfern_alloc_bytes_zero
.Lfern_alloc_bytes_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_bytes_empty:
    adrp x0, .Lfern_empty_bytes
    add x0, x0, :lo12:.Lfern_empty_bytes
    ret
__fn___fern_bytes_range:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_bytes_range.k:
__fn___fern_bytes_range.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
.Lssa___fern_bytes_range_0:
    mov x9, #2
    and x9, x10, x9
    cmp x9, #0
    b.eq .Lssa___fern_bytes_range_10
.Lssa___fern_bytes_range_11:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x20, x12
    mov x12, x11
    b .Lssa___fern_bytes_range_9
.Lssa___fern_bytes_range_10:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x20, x10
.Lssa___fern_bytes_range_9:
    cmp x19, #0
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_8:
    cmp x0, x19
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_7:
    cmp x0, x12
    b.le .Lssa___fern_bytes_range_4
.Lssa___fern_bytes_range_6:
    bl __fern_slice_abort
.Lssa___fern_bytes_range_4:
    sub x0, x0, x19
    sxtw x21, w0
    cmp x21, #0
    b.ne .Lssa___fern_bytes_range_1
.Lssa___fern_bytes_range_3:
    adrp x0, .K0
    add x0, x0, :lo12:.K0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_range_1:
    add x12, x21, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    sxtw x19, w19
    add x20, x20, x19
    mov x2, x21
    mov x1, x20
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_range_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_bytes_range_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_range_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_range_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_range_mc136
.Lssa___fern_bytes_range_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_range_mcd136
.Lssa___fern_bytes_range_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_range_mcb136
.Lssa___fern_bytes_range_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_bytes_into:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___fern_bytes_into.k:
__fn___fern_bytes_into.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    str x25, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x11
    mov x22, x12
.Lssa___fern_bytes_into_0:
    mov x9, #2
    and x9, x10, x9
    cmp x9, #0
    b.eq .Lssa___fern_bytes_into_15
.Lssa___fern_bytes_into_16:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x23, x12
    mov x12, x11
    b .Lssa___fern_bytes_into_14
.Lssa___fern_bytes_into_15:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x23, x10
.Lssa___fern_bytes_into_14:
    ldrsw x24, [x22]
    cmp x19, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_13:
    cmp x21, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_12:
    cmp x20, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_11:
    sub x10, x24, x19
    sxtw x10, w10
    cmp x21, x10
    b.gt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_10:
    sub x12, x12, x19
    sxtw x12, w12
    cmp x20, x12
    b.le .Lssa___fern_bytes_into_7
.Lssa___fern_bytes_into_9:
    bl __fern_slice_abort
.Lssa___fern_bytes_into_7:
    cmp x19, #0
    b.ne .Lssa___fern_bytes_into_4
.Lssa___fern_bytes_into_6:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_into_4:
    str x22, [sp, #-16]!
    bl __fn___fern_rc_is_unique
    add sp, sp, #16
    cmp x0, #0
    b.ne .Lssa___fern_bytes_into_1
.Lssa___fern_bytes_into_3:
    add x12, x24, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x25, x0
    str x24, [x25, #0]
    add x10, x25, #8
    add x12, x22, #8
    mov x2, x24
    mov x1, x12
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_into_mcd172
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb172
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc172:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct172
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc172
.Lssa___fern_bytes_into_mct172:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd172
.Lssa___fern_bytes_into_mcb172:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb172
.Lssa___fern_bytes_into_mcd172:
    mov x0, #0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x22, x25
.Lssa___fern_bytes_into_2:
.Lssa___fern_bytes_into_1:
    add x12, x22, #8
    sxtw x21, w21
    add x12, x12, x21
    sxtw x20, w20
    add x23, x23, x20
    mov x2, x19
    mov x1, x23
    mov x0, x12
    cbz x2, .Lssa___fern_bytes_into_mcd207
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb207
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc207:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct207
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc207
.Lssa___fern_bytes_into_mct207:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd207
.Lssa___fern_bytes_into_mcb207:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb207
.Lssa___fern_bytes_into_mcd207:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_utf8_step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_utf8_step.k:
__fn___fern_utf8_step.r:
.Lssa___fern_utf8_step_0:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x9]
    mov x12, #0
    mov x13, #1
    cmp x11, #128
    csel x13, x13, x12, lt
    cmp x11, #194
    b.lt .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_41:
    cmp x11, #224
    b.ge .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_40:
    mov x13, #2
.Lssa___fern_utf8_step_39:
.Lssa___fern_utf8_step_38:
    cmp x11, #224
    b.lt .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_37:
    cmp x11, #240
    b.ge .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_36:
    mov x13, #3
.Lssa___fern_utf8_step_35:
.Lssa___fern_utf8_step_34:
    cmp x11, #240
    b.lt .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_33:
    cmp x11, #245
    b.ge .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_32:
    mov x13, #4
.Lssa___fern_utf8_step_31:
.Lssa___fern_utf8_step_30:
    cmp x13, #1
    b.gt .Lssa___fern_utf8_step_27
.Lssa___fern_utf8_step_29:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_27:
    add x12, x9, #1
    sxtw x12, w12
    cmp x12, x10
    b.lt .Lssa___fern_utf8_step_24
.Lssa___fern_utf8_step_26:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_24:
    mov x12, #128
    mov x14, #160
    cmp x11, #224
    csel x14, x14, x12, eq
    mov x12, #144
    cmp x11, #240
    csel x12, x12, x14, eq
    mov x14, #191
    mov x15, #159
    cmp x11, #237
    csel x15, x15, x14, eq
    mov x14, #143
    cmp x11, #244
    csel x14, x14, x15, eq
    add w15, w9, #1
    ldr x6, [x0, #8]
    cmp x15, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x15]
    cmp x11, x12
    b.ge .Lssa___fern_utf8_step_9
.Lssa___fern_utf8_step_11:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_9:
    cmp x11, x14
    b.le .Lssa___fern_utf8_step_6
.Lssa___fern_utf8_step_8:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_6:
.Lssa___fern_utf8_step_5:
    mov x11, #2
.Lssa___fern_utf8_step_113:
    cmp x11, x13
    b.ge .Lssa___fern_utf8_step_4
.Lssa___fern_utf8_step_120:
    add x15, x9, x11
    sxtw x15, w15
    cmp x15, x10
    b.ge .Lssa___fern_utf8_step_3
.Lssa___fern_utf8_step_118:
    add w15, w9, w11
    ldr x6, [x0, #8]
    cmp x15, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x15]
    cmp x14, #128
    b.lt .Lssa___fern_utf8_step_2
.Lssa___fern_utf8_step_116:
    cmp x14, #191
    b.gt .Lssa___fern_utf8_step_1
.Lssa___fern_utf8_step_114:
    add x11, x11, #1
    cmp x11, x13
    b.lt .Lssa___fern_utf8_step_120
.Lssa___fern_utf8_step_4:
    mov x0, x13
    ret
.Lssa___fern_utf8_step_3:
    mov x0, x11
    ret
.Lssa___fern_utf8_step_2:
    mov x0, x11
    ret
.Lssa___fern_utf8_step_1:
    mov x0, x11
    ret
    .cfi_endproc
    .ltorg
__fn___fern_str_split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_split.k:
__fn___fern_str_split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    sub sp, sp, #144
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_split_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    adrp x9, .K0
    add x9, x9, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa___fern_str_split_3
.Lssa___fern_str_split_7:
.Lssa___fern_str_split_6:
    mov x23, x9
    mov x24, #0
.Lssa___fern_str_split_12:
    cmp x24, x21
    b.ge .Lssa___fern_str_split_5
.Lssa___fern_str_split_13:
    mov x0, x19
    mov x9, x24
    mov x10, x21
    bl __fn___fern_utf8_step.r
    add x0, x24, x0
    sxtw x25, w0
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    mov x0, x26
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x24, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush87s
.Lssa___fern_str_split_apush87o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush87e
.Lssa___fern_str_split_apush87s:
    str x9, [sp, #64]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
.Lssa___fern_str_split_apush87e:
    mov x23, x0
    mov x24, x25
    cmp x24, x21
    b.lt .Lssa___fern_str_split_13
.Lssa___fern_str_split_5:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_str_split_3:
.Lssa___fern_str_split_2:
    mov x23, x9
    mov x24, #0
    mov x25, #0
.Lssa___fern_str_split_20:
    add x9, x25, x22
    sxtw x9, w9
    cmp x9, x21
    b.gt .Lssa___fern_str_split_1
.Lssa___fern_str_split_26:
.Lssa___fern_str_split_25:
    mov x9, #0
    mov x10, #1
.Lssa___fern_str_split_31:
    cmp x9, x22
    b.ge .Lssa___fern_str_split_24
.Lssa___fern_str_split_35:
    add w11, w25, w9
    ldr x6, [x19, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w12, [x6, x11]
    ldr x11, [x20, #0]
    ldrb w13, [x11, x9]
    mov x11, #0
    add x9, x9, #1
    cmp x12, x13
    csel x9, x22, x9, ne
    csel x10, x11, x10, ne
    cmp x9, x22
    b.lt .Lssa___fern_str_split_35
.Lssa___fern_str_split_24:
    cmp x10, #1
    b.ne .Lssa___fern_str_split_22
.Lssa___fern_str_split_23:
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    mov x0, x26
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x27, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x27
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush142s
.Lssa___fern_str_split_apush142o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush142e
.Lssa___fern_str_split_apush142s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush142e:
    add x10, x25, x22
    sxtw x10, w10
    mov x23, x0
    mov x24, x10
    mov x25, x10
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_22:
    add x25, x25, #1
    sxtw x25, w25
.Lssa___fern_str_split_21:
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_1:
    mov x0, x19
    mov x1, x24
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x25, x0
    adrp x10, .SB8
    add x10, x10, :lo12:.SB8
    mov x0, x25
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x24, x0
    str x25, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush161s
.Lssa___fern_str_split_apush161o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush161e
.Lssa___fern_str_split_apush161s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush161e:
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_bytes_u8.k:
__fn___fern_str_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_bytes_u8_0:
    ldr x20, [x19, #8]
    sxtw x21, w20
    add x9, x21, #7
    mov x4, x9
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    sxtw x10, w10
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    ldr x9, [x19, #0]
    mov x2, x20
    mov x1, x9
    mov x0, x10
    cbz x2, .Lssa___fern_str_bytes_u8_mcd36
    cmp x2, #8
    b.lo .Lssa___fern_str_bytes_u8_mcb36
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_bytes_u8_mc36:
    cmp x0, x10
    b.hs .Lssa___fern_str_bytes_u8_mct36
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_bytes_u8_mc36
.Lssa___fern_str_bytes_u8_mct36:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_bytes_u8_mcd36
.Lssa___fern_str_bytes_u8_mcb36:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_bytes_u8_mcb36
.Lssa___fern_str_bytes_u8_mcd36:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_string_from_bytes_u8.k:
__fn___fern_string_from_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_string_from_bytes_u8_0:
    ldr x20, [x19, #0]
    mov x0, x20
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x21, x0
    add x19, x19, #8
    mov x2, x20
    mov x1, x19
    mov x0, x21
    cbz x2, .Lssa___fern_string_from_bytes_u8_mcd14
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_u8_mcb14
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_u8_mc14:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_u8_mct14
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_u8_mc14
.Lssa___fern_string_from_bytes_u8_mct14:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_u8_mcd14
.Lssa___fern_string_from_bytes_u8_mcb14:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_u8_mcb14
.Lssa___fern_string_from_bytes_u8_mcd14:
    mov x0, #0
    mov x0, x21
    mov x1, x20
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_range_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_string_from_bytes_range_u8.k:
__fn___fern_string_from_bytes_range_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_string_from_bytes_range_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x10, x9
    csel x11, x11, x12, gt
    mov x12, #1
    cmp x20, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x20, x10
    csel x11, x11, x12, gt
    cmp x11, #1
    b.ne .Lssa___fern_string_from_bytes_range_u8_1
.Lssa___fern_string_from_bytes_range_u8_3:
    bl __fern_slice_abort
.Lssa___fern_string_from_bytes_range_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    mov x0, x21
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x22, x0
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x22
    cbz x2, .Lssa___fern_string_from_bytes_range_u8_mcd117
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_range_u8_mcb117
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_range_u8_mc117:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_range_u8_mct117
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_range_u8_mc117
.Lssa___fern_string_from_bytes_range_u8_mct117:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_range_u8_mcd117
.Lssa___fern_string_from_bytes_range_u8_mcb117:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_range_u8_mcb117
.Lssa___fern_string_from_bytes_range_u8_mcd117:
    mov x0, #0
    mov x0, x22
    mov x1, x21
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_arr_slice_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_arr_slice_u8.k:
__fn___fern_arr_slice_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_arr_slice_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x10, x9
    csel x11, x11, x12, gt
    mov x12, #1
    cmp x20, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x20, x10
    csel x11, x11, x12, gt
    cmp x11, #1
    b.ne .Lssa___fern_arr_slice_u8_1
.Lssa___fern_arr_slice_u8_3:
    bl __fern_slice_abort
.Lssa___fern_arr_slice_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    add x10, x21, #7
    sxtw x10, w10
    mov x4, x10
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x11, x4
    mov x0, x11
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x11, x22, #8
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x11
    cbz x2, .Lssa___fern_arr_slice_u8_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_arr_slice_u8_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_arr_slice_u8_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_arr_slice_u8_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_arr_slice_u8_mc136
.Lssa___fern_arr_slice_u8_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_arr_slice_u8_mcd136
.Lssa___fern_arr_slice_u8_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_arr_slice_u8_mcb136
.Lssa___fern_arr_slice_u8_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
    .section .rodata
.S0: .ascii "HeaderMap"
.S1: .ascii "\027\003\007\003\003\003\003\003\007\007\013\253/\253\013\217\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\001\000\000\000\000\000\001\001\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001"
.S2: .ascii "\003\003\003\003\003\003\003\003\003\002\003\003\003\003\003\203\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
.S3: .ascii "http://"
.S4: .ascii "https://"
.S5: .ascii "!$&'()*+,;="
.S6: .ascii "HttpResponse"
.S7: .ascii "Body$BodyText"
.S8: .ascii ""
.S9: .ascii "Content-Length: "
.S10: .ascii "\r\n"
.S11: .ascii "HTTP/1.1 "
.S12: .ascii " "
.S13: .ascii "Continue"
.S14: .ascii "Switching Protocols"
.S15: .ascii "OK"
.S16: .ascii "Created"
.S17: .ascii "Accepted"
.S18: .ascii "Non-Authoritative Information"
.S19: .ascii "No Content"
.S20: .ascii "Reset Content"
.S21: .ascii "Partial Content"
.S22: .ascii "Multiple Choices"
.S23: .ascii "Moved Permanently"
.S24: .ascii "Found"
.S25: .ascii "See Other"
.S26: .ascii "Not Modified"
.S27: .ascii "Use Proxy"
.S28: .ascii "Temporary Redirect"
.S29: .ascii "Permanent Redirect"
.S30: .ascii "Bad Request"
.S31: .ascii "Unauthorized"
.S32: .ascii "Payment Required"
.S33: .ascii "Forbidden"
.S34: .ascii "Not Found"
.S35: .ascii "Method Not Allowed"
.S36: .ascii "Not Acceptable"
.S37: .ascii "Proxy Authentication Required"
.S38: .ascii "Request Timeout"
.S39: .ascii "Conflict"
.S40: .ascii "Gone"
.S41: .ascii "Length Required"
.S42: .ascii "Precondition Failed"
.S43: .ascii "Payload Too Large"
.S44: .ascii "URI Too Long"
.S45: .ascii "Unsupported Media Type"
.S46: .ascii "Range Not Satisfiable"
.S47: .ascii "Expectation Failed"
.S48: .ascii "I'm a teapot"
.S49: .ascii "Misdirected Request"
.S50: .ascii "Unprocessable Entity"
.S51: .ascii "Too Early"
.S52: .ascii "Upgrade Required"
.S53: .ascii "Precondition Required"
.S54: .ascii "Too Many Requests"
.S55: .ascii "Request Header Fields Too Large"
.S56: .ascii "Internal Server Error"
.S57: .ascii "Not Implemented"
.S58: .ascii "Bad Gateway"
.S59: .ascii "Service Unavailable"
.S60: .ascii "Gateway Timeout"
.S61: .ascii "HTTP Version Not Supported"
.S62: .ascii "Network Authentication Required"
.S63: .ascii "Status"
.S64: .ascii "content-length"
.S65: .ascii "connection"
.S66: .ascii "transfer-encoding"
.S67: .ascii ": "
.S68: .ascii "Connection: Upgrade\r\n\r\n"
.S69: .ascii "Connection: close\r\n\r\n"
.S70: .ascii "Connection: keep-alive\r\n\r\n"
.S71: .ascii "HEAD"
.S72: .ascii "0"
.S73: .ascii "1"
.S74: .ascii "2"
.S75: .ascii "3"
.S76: .ascii "4"
.S77: .ascii "5"
.S78: .ascii "6"
.S79: .ascii "7"
.S80: .ascii "8"
.S81: .ascii "9"
.S82: .ascii "10"
.S83: .ascii "11"
.S84: .ascii "12"
.S85: .ascii "13"
.S86: .ascii "14"
.S87: .ascii "15"
.S88: .ascii "16"
.S89: .ascii "17"
.S90: .ascii "18"
.S91: .ascii "19"
.S92: .ascii "20"
.S93: .ascii "21"
.S94: .ascii "22"
.S95: .ascii "23"
.S96: .ascii "24"
.S97: .ascii "25"
.S98: .ascii "26"
.S99: .ascii "27"
.S100: .ascii "28"
.S101: .ascii "29"
.S102: .ascii "30"
.S103: .ascii "31"
.S104: .ascii "32"
.S105: .ascii "33"
.S106: .ascii "34"
.S107: .ascii "35"
.S108: .ascii "36"
.S109: .ascii "37"
.S110: .ascii "38"
.S111: .ascii "39"
.S112: .ascii "40"
.S113: .ascii "41"
.S114: .ascii "42"
.S115: .ascii "43"
.S116: .ascii "44"
.S117: .ascii "45"
.S118: .ascii "46"
.S119: .ascii "47"
.S120: .ascii "48"
.S121: .ascii "49"
.S122: .ascii "50"
.S123: .ascii "51"
.S124: .ascii "52"
.S125: .ascii "53"
.S126: .ascii "54"
.S127: .ascii "55"
.S128: .ascii "56"
.S129: .ascii "57"
.S130: .ascii "58"
.S131: .ascii "59"
.S132: .ascii "60"
.S133: .ascii "61"
.S134: .ascii "62"
.S135: .ascii "63"
.S136: .ascii "64"
.S137: .ascii "65"
.S138: .ascii "66"
.S139: .ascii "67"
.S140: .ascii "68"
.S141: .ascii "69"
.S142: .ascii "70"
.S143: .ascii "71"
.S144: .ascii "72"
.S145: .ascii "73"
.S146: .ascii "74"
.S147: .ascii "75"
.S148: .ascii "76"
.S149: .ascii "77"
.S150: .ascii "78"
.S151: .ascii "79"
.S152: .ascii "80"
.S153: .ascii "81"
.S154: .ascii "82"
.S155: .ascii "83"
.S156: .ascii "84"
.S157: .ascii "85"
.S158: .ascii "86"
.S159: .ascii "87"
.S160: .ascii "88"
.S161: .ascii "89"
.S162: .ascii "90"
.S163: .ascii "91"
.S164: .ascii "92"
.S165: .ascii "93"
.S166: .ascii "94"
.S167: .ascii "95"
.S168: .ascii "96"
.S169: .ascii "97"
.S170: .ascii "98"
.S171: .ascii "99"
.S172: .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
.S173: .ascii "deflate____ReadPhase$deflate__ReadHeader"
.S174: .ascii "deflate____ReadPhase$deflate__ReadStored"
.S175: .ascii "deflate____ReadPhase$deflate__ReadCodes"
.S176: .ascii "deflate____ReadPhase$deflate__ReadCopy"
.S177: .ascii "deflate____ReadPhase$deflate__ReadEnd"
.S178: .ascii "codec__DecodeErrorKind$codec__InvalidByte"
.S179: .ascii "codec__DecodeErrorKind$codec__InvalidLength"
.S180: .ascii "codec__DecodeErrorKind$codec__InvalidPadding"
.S181: .ascii "codec__DecodeErrorKind$codec__NonZeroTrailingBits"
.S182: .ascii "GET /hello HTTP/1.1\r\nHost: bench\r\nUser-Agent: perf-bench\r\nAccept: */*\r\n\r\n"
.S183: .ascii "\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\r"
.S184: .ascii "OPTIONS"
.S185: .ascii "*"
.S186: .ascii "HTTP/1.0"
.S187: .ascii "HTTP/1.1"
.S188: .ascii "host"
.S189: .ascii "expect"
.S190: .ascii "100-continue"
.S191: .ascii ","
.S192: .ascii "chunked"
.S193: .ascii "close"
.S194: .ascii "keep-alive"
.S195: .ascii "hello "
.S196: .ascii "GET"
.S197: .ascii "Body$BodyBytes"
.S198: .ascii "Body$BodyStream"
.S199: .ascii "Body$BodyFile"
.S200: .ascii "Body$BodyChunks"
.S201: .ascii "Body$BodyFileRanges"
    .section .data
    .balign 8
.Lfern_relanchor:
    .quad .Lfern_relanchor
    .section .data.rel.ro
    .balign 8
.Lfern_sbox_begin:
    .section .data.rel.ro
    .balign 8
    .quad -1
.SB0:
    .quad .S0
    .quad 9
    .quad -1
.SB1:
    .quad .S1
    .quad 352
    .quad -1
.SB2:
    .quad .S2
    .quad 352
    .quad -1
.SB3:
    .quad .S3
    .quad 7
    .quad -1
.SB4:
    .quad .S4
    .quad 8
    .quad -1
.SB5:
    .quad .S5
    .quad 11
    .quad -1
.SB6:
    .quad .S6
    .quad 12
    .quad -1
.SB7:
    .quad .S7
    .quad 13
    .quad -1
.SB8:
    .quad .S8
    .quad 0
    .quad -1
.SB9:
    .quad .S9
    .quad 16
    .quad -1
.SB10:
    .quad .S10
    .quad 2
    .quad -1
.SB11:
    .quad .S11
    .quad 9
    .quad -1
.SB12:
    .quad .S12
    .quad 1
    .quad -1
.SB13:
    .quad .S13
    .quad 8
    .quad -1
.SB14:
    .quad .S14
    .quad 19
    .quad -1
.SB15:
    .quad .S15
    .quad 2
    .quad -1
.SB16:
    .quad .S16
    .quad 7
    .quad -1
.SB17:
    .quad .S17
    .quad 8
    .quad -1
.SB18:
    .quad .S18
    .quad 29
    .quad -1
.SB19:
    .quad .S19
    .quad 10
    .quad -1
.SB20:
    .quad .S20
    .quad 13
    .quad -1
.SB21:
    .quad .S21
    .quad 15
    .quad -1
.SB22:
    .quad .S22
    .quad 16
    .quad -1
.SB23:
    .quad .S23
    .quad 17
    .quad -1
.SB24:
    .quad .S24
    .quad 5
    .quad -1
.SB25:
    .quad .S25
    .quad 9
    .quad -1
.SB26:
    .quad .S26
    .quad 12
    .quad -1
.SB27:
    .quad .S27
    .quad 9
    .quad -1
.SB28:
    .quad .S28
    .quad 18
    .quad -1
.SB29:
    .quad .S29
    .quad 18
    .quad -1
.SB30:
    .quad .S30
    .quad 11
    .quad -1
.SB31:
    .quad .S31
    .quad 12
    .quad -1
.SB32:
    .quad .S32
    .quad 16
    .quad -1
.SB33:
    .quad .S33
    .quad 9
    .quad -1
.SB34:
    .quad .S34
    .quad 9
    .quad -1
.SB35:
    .quad .S35
    .quad 18
    .quad -1
.SB36:
    .quad .S36
    .quad 14
    .quad -1
.SB37:
    .quad .S37
    .quad 29
    .quad -1
.SB38:
    .quad .S38
    .quad 15
    .quad -1
.SB39:
    .quad .S39
    .quad 8
    .quad -1
.SB40:
    .quad .S40
    .quad 4
    .quad -1
.SB41:
    .quad .S41
    .quad 15
    .quad -1
.SB42:
    .quad .S42
    .quad 19
    .quad -1
.SB43:
    .quad .S43
    .quad 17
    .quad -1
.SB44:
    .quad .S44
    .quad 12
    .quad -1
.SB45:
    .quad .S45
    .quad 22
    .quad -1
.SB46:
    .quad .S46
    .quad 21
    .quad -1
.SB47:
    .quad .S47
    .quad 18
    .quad -1
.SB48:
    .quad .S48
    .quad 12
    .quad -1
.SB49:
    .quad .S49
    .quad 19
    .quad -1
.SB50:
    .quad .S50
    .quad 20
    .quad -1
.SB51:
    .quad .S51
    .quad 9
    .quad -1
.SB52:
    .quad .S52
    .quad 16
    .quad -1
.SB53:
    .quad .S53
    .quad 21
    .quad -1
.SB54:
    .quad .S54
    .quad 17
    .quad -1
.SB55:
    .quad .S55
    .quad 31
    .quad -1
.SB56:
    .quad .S56
    .quad 21
    .quad -1
.SB57:
    .quad .S57
    .quad 15
    .quad -1
.SB58:
    .quad .S58
    .quad 11
    .quad -1
.SB59:
    .quad .S59
    .quad 19
    .quad -1
.SB60:
    .quad .S60
    .quad 15
    .quad -1
.SB61:
    .quad .S61
    .quad 26
    .quad -1
.SB62:
    .quad .S62
    .quad 31
    .quad -1
.SB63:
    .quad .S63
    .quad 6
    .quad -1
.SB64:
    .quad .S64
    .quad 14
    .quad -1
.SB65:
    .quad .S65
    .quad 10
    .quad -1
.SB66:
    .quad .S66
    .quad 17
    .quad -1
.SB67:
    .quad .S67
    .quad 2
    .quad -1
.SB68:
    .quad .S68
    .quad 23
    .quad -1
.SB69:
    .quad .S69
    .quad 21
    .quad -1
.SB70:
    .quad .S70
    .quad 26
    .quad -1
.SB71:
    .quad .S71
    .quad 4
    .quad -1
.SB72:
    .quad .S72
    .quad 1
    .quad -1
.SB73:
    .quad .S73
    .quad 1
    .quad -1
.SB74:
    .quad .S74
    .quad 1
    .quad -1
.SB75:
    .quad .S75
    .quad 1
    .quad -1
.SB76:
    .quad .S76
    .quad 1
    .quad -1
.SB77:
    .quad .S77
    .quad 1
    .quad -1
.SB78:
    .quad .S78
    .quad 1
    .quad -1
.SB79:
    .quad .S79
    .quad 1
    .quad -1
.SB80:
    .quad .S80
    .quad 1
    .quad -1
.SB81:
    .quad .S81
    .quad 1
    .quad -1
.SB82:
    .quad .S82
    .quad 2
    .quad -1
.SB83:
    .quad .S83
    .quad 2
    .quad -1
.SB84:
    .quad .S84
    .quad 2
    .quad -1
.SB85:
    .quad .S85
    .quad 2
    .quad -1
.SB86:
    .quad .S86
    .quad 2
    .quad -1
.SB87:
    .quad .S87
    .quad 2
    .quad -1
.SB88:
    .quad .S88
    .quad 2
    .quad -1
.SB89:
    .quad .S89
    .quad 2
    .quad -1
.SB90:
    .quad .S90
    .quad 2
    .quad -1
.SB91:
    .quad .S91
    .quad 2
    .quad -1
.SB92:
    .quad .S92
    .quad 2
    .quad -1
.SB93:
    .quad .S93
    .quad 2
    .quad -1
.SB94:
    .quad .S94
    .quad 2
    .quad -1
.SB95:
    .quad .S95
    .quad 2
    .quad -1
.SB96:
    .quad .S96
    .quad 2
    .quad -1
.SB97:
    .quad .S97
    .quad 2
    .quad -1
.SB98:
    .quad .S98
    .quad 2
    .quad -1
.SB99:
    .quad .S99
    .quad 2
    .quad -1
.SB100:
    .quad .S100
    .quad 2
    .quad -1
.SB101:
    .quad .S101
    .quad 2
    .quad -1
.SB102:
    .quad .S102
    .quad 2
    .quad -1
.SB103:
    .quad .S103
    .quad 2
    .quad -1
.SB104:
    .quad .S104
    .quad 2
    .quad -1
.SB105:
    .quad .S105
    .quad 2
    .quad -1
.SB106:
    .quad .S106
    .quad 2
    .quad -1
.SB107:
    .quad .S107
    .quad 2
    .quad -1
.SB108:
    .quad .S108
    .quad 2
    .quad -1
.SB109:
    .quad .S109
    .quad 2
    .quad -1
.SB110:
    .quad .S110
    .quad 2
    .quad -1
.SB111:
    .quad .S111
    .quad 2
    .quad -1
.SB112:
    .quad .S112
    .quad 2
    .quad -1
.SB113:
    .quad .S113
    .quad 2
    .quad -1
.SB114:
    .quad .S114
    .quad 2
    .quad -1
.SB115:
    .quad .S115
    .quad 2
    .quad -1
.SB116:
    .quad .S116
    .quad 2
    .quad -1
.SB117:
    .quad .S117
    .quad 2
    .quad -1
.SB118:
    .quad .S118
    .quad 2
    .quad -1
.SB119:
    .quad .S119
    .quad 2
    .quad -1
.SB120:
    .quad .S120
    .quad 2
    .quad -1
.SB121:
    .quad .S121
    .quad 2
    .quad -1
.SB122:
    .quad .S122
    .quad 2
    .quad -1
.SB123:
    .quad .S123
    .quad 2
    .quad -1
.SB124:
    .quad .S124
    .quad 2
    .quad -1
.SB125:
    .quad .S125
    .quad 2
    .quad -1
.SB126:
    .quad .S126
    .quad 2
    .quad -1
.SB127:
    .quad .S127
    .quad 2
    .quad -1
.SB128:
    .quad .S128
    .quad 2
    .quad -1
.SB129:
    .quad .S129
    .quad 2
    .quad -1
.SB130:
    .quad .S130
    .quad 2
    .quad -1
.SB131:
    .quad .S131
    .quad 2
    .quad -1
.SB132:
    .quad .S132
    .quad 2
    .quad -1
.SB133:
    .quad .S133
    .quad 2
    .quad -1
.SB134:
    .quad .S134
    .quad 2
    .quad -1
.SB135:
    .quad .S135
    .quad 2
    .quad -1
.SB136:
    .quad .S136
    .quad 2
    .quad -1
.SB137:
    .quad .S137
    .quad 2
    .quad -1
.SB138:
    .quad .S138
    .quad 2
    .quad -1
.SB139:
    .quad .S139
    .quad 2
    .quad -1
.SB140:
    .quad .S140
    .quad 2
    .quad -1
.SB141:
    .quad .S141
    .quad 2
    .quad -1
.SB142:
    .quad .S142
    .quad 2
    .quad -1
.SB143:
    .quad .S143
    .quad 2
    .quad -1
.SB144:
    .quad .S144
    .quad 2
    .quad -1
.SB145:
    .quad .S145
    .quad 2
    .quad -1
.SB146:
    .quad .S146
    .quad 2
    .quad -1
.SB147:
    .quad .S147
    .quad 2
    .quad -1
.SB148:
    .quad .S148
    .quad 2
    .quad -1
.SB149:
    .quad .S149
    .quad 2
    .quad -1
.SB150:
    .quad .S150
    .quad 2
    .quad -1
.SB151:
    .quad .S151
    .quad 2
    .quad -1
.SB152:
    .quad .S152
    .quad 2
    .quad -1
.SB153:
    .quad .S153
    .quad 2
    .quad -1
.SB154:
    .quad .S154
    .quad 2
    .quad -1
.SB155:
    .quad .S155
    .quad 2
    .quad -1
.SB156:
    .quad .S156
    .quad 2
    .quad -1
.SB157:
    .quad .S157
    .quad 2
    .quad -1
.SB158:
    .quad .S158
    .quad 2
    .quad -1
.SB159:
    .quad .S159
    .quad 2
    .quad -1
.SB160:
    .quad .S160
    .quad 2
    .quad -1
.SB161:
    .quad .S161
    .quad 2
    .quad -1
.SB162:
    .quad .S162
    .quad 2
    .quad -1
.SB163:
    .quad .S163
    .quad 2
    .quad -1
.SB164:
    .quad .S164
    .quad 2
    .quad -1
.SB165:
    .quad .S165
    .quad 2
    .quad -1
.SB166:
    .quad .S166
    .quad 2
    .quad -1
.SB167:
    .quad .S167
    .quad 2
    .quad -1
.SB168:
    .quad .S168
    .quad 2
    .quad -1
.SB169:
    .quad .S169
    .quad 2
    .quad -1
.SB170:
    .quad .S170
    .quad 2
    .quad -1
.SB171:
    .quad .S171
    .quad 2
    .quad -1
.SB172:
    .quad .S172
    .quad 200
    .quad -1
.SB173:
    .quad .S173
    .quad 40
    .quad -1
.SB174:
    .quad .S174
    .quad 40
    .quad -1
.SB175:
    .quad .S175
    .quad 39
    .quad -1
.SB176:
    .quad .S176
    .quad 38
    .quad -1
.SB177:
    .quad .S177
    .quad 37
    .quad -1
.SB178:
    .quad .S178
    .quad 41
    .quad -1
.SB179:
    .quad .S179
    .quad 43
    .quad -1
.SB180:
    .quad .S180
    .quad 44
    .quad -1
.SB181:
    .quad .S181
    .quad 49
    .quad -1
.SB182:
    .quad .S182
    .quad 73
    .quad -1
.SB183:
    .quad .S183
    .quad 354
    .quad -1
.SB184:
    .quad .S184
    .quad 7
    .quad -1
.SB185:
    .quad .S185
    .quad 1
    .quad -1
.SB186:
    .quad .S186
    .quad 8
    .quad -1
.SB187:
    .quad .S187
    .quad 8
    .quad -1
.SB188:
    .quad .S188
    .quad 4
    .quad -1
.SB189:
    .quad .S189
    .quad 6
    .quad -1
.SB190:
    .quad .S190
    .quad 12
    .quad -1
.SB191:
    .quad .S191
    .quad 1
    .quad -1
.SB192:
    .quad .S192
    .quad 7
    .quad -1
.SB193:
    .quad .S193
    .quad 5
    .quad -1
.SB194:
    .quad .S194
    .quad 10
    .quad -1
.SB195:
    .quad .S195
    .quad 6
    .quad -1
.SB196:
    .quad .S196
    .quad 3
    .quad -1
.SB197:
    .quad .S197
    .quad 14
    .quad -1
.SB198:
    .quad .S198
    .quad 15
    .quad -1
.SB199:
    .quad .S199
    .quad 13
    .quad -1
.SB200:
    .quad .S200
    .quad 15
    .quad -1
.SB201:
    .quad .S201
    .quad 19
.Lfern_sbox_end:
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.K0:
    .quad 0
    .quad 0
    .quad -1
.K2:
    .quad 256
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    .balign 8
    .quad 0
    .quad -1
.K3:
    .quad 128
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K4:
    .quad 0
    .balign 8
    .quad 2
    .quad -1
.K6:
    .quad 1
    .quad 0
    .quad 50
    .quad -1
.K8:
    .quad 50
    .quad 100
    .quad 101
    .quad 200
    .quad 201
    .quad 202
    .quad 203
    .quad 204
    .quad 205
    .quad 206
    .quad 300
    .quad 301
    .quad 302
    .quad 303
    .quad 304
    .quad 305
    .quad 307
    .quad 308
    .quad 400
    .quad 401
    .quad 402
    .quad 403
    .quad 404
    .quad 405
    .quad 406
    .quad 407
    .quad 408
    .quad 409
    .quad 410
    .quad 411
    .quad 412
    .quad 413
    .quad 414
    .quad 415
    .quad 416
    .quad 417
    .quad 418
    .quad 421
    .quad 422
    .quad 425
    .quad 426
    .quad 428
    .quad 429
    .quad 431
    .quad 500
    .quad 501
    .quad 502
    .quad 503
    .quad 504
    .quad 505
    .quad 511
    .quad 50
    .quad -1
.K9:
    .quad 50
.K9_0:
    .quad .SB13
.K9_1:
    .quad .SB14
.K9_2:
    .quad .SB15
.K9_3:
    .quad .SB16
.K9_4:
    .quad .SB17
.K9_5:
    .quad .SB18
.K9_6:
    .quad .SB19
.K9_7:
    .quad .SB20
.K9_8:
    .quad .SB21
.K9_9:
    .quad .SB22
.K9_10:
    .quad .SB23
.K9_11:
    .quad .SB24
.K9_12:
    .quad .SB25
.K9_13:
    .quad .SB26
.K9_14:
    .quad .SB27
.K9_15:
    .quad .SB28
.K9_16:
    .quad .SB29
.K9_17:
    .quad .SB30
.K9_18:
    .quad .SB31
.K9_19:
    .quad .SB32
.K9_20:
    .quad .SB33
.K9_21:
    .quad .SB34
.K9_22:
    .quad .SB35
.K9_23:
    .quad .SB36
.K9_24:
    .quad .SB37
.K9_25:
    .quad .SB38
.K9_26:
    .quad .SB39
.K9_27:
    .quad .SB40
.K9_28:
    .quad .SB41
.K9_29:
    .quad .SB42
.K9_30:
    .quad .SB43
.K9_31:
    .quad .SB44
.K9_32:
    .quad .SB45
.K9_33:
    .quad .SB46
.K9_34:
    .quad .SB47
.K9_35:
    .quad .SB48
.K9_36:
    .quad .SB49
.K9_37:
    .quad .SB50
.K9_38:
    .quad .SB51
.K9_39:
    .quad .SB52
.K9_40:
    .quad .SB53
.K9_41:
    .quad .SB54
.K9_42:
    .quad .SB55
.K9_43:
    .quad .SB56
.K9_44:
    .quad .SB57
.K9_45:
    .quad .SB58
.K9_46:
    .quad .SB59
.K9_47:
    .quad .SB60
.K9_48:
    .quad .SB61
.K9_49:
    .quad .SB62
    .quad 100
    .quad -1
.K10:
    .quad 100
.K10_0:
    .quad .SB72
.K10_1:
    .quad .SB73
.K10_2:
    .quad .SB74
.K10_3:
    .quad .SB75
.K10_4:
    .quad .SB76
.K10_5:
    .quad .SB77
.K10_6:
    .quad .SB78
.K10_7:
    .quad .SB79
.K10_8:
    .quad .SB80
.K10_9:
    .quad .SB81
.K10_10:
    .quad .SB82
.K10_11:
    .quad .SB83
.K10_12:
    .quad .SB84
.K10_13:
    .quad .SB85
.K10_14:
    .quad .SB86
.K10_15:
    .quad .SB87
.K10_16:
    .quad .SB88
.K10_17:
    .quad .SB89
.K10_18:
    .quad .SB90
.K10_19:
    .quad .SB91
.K10_20:
    .quad .SB92
.K10_21:
    .quad .SB93
.K10_22:
    .quad .SB94
.K10_23:
    .quad .SB95
.K10_24:
    .quad .SB96
.K10_25:
    .quad .SB97
.K10_26:
    .quad .SB98
.K10_27:
    .quad .SB99
.K10_28:
    .quad .SB100
.K10_29:
    .quad .SB101
.K10_30:
    .quad .SB102
.K10_31:
    .quad .SB103
.K10_32:
    .quad .SB104
.K10_33:
    .quad .SB105
.K10_34:
    .quad .SB106
.K10_35:
    .quad .SB107
.K10_36:
    .quad .SB108
.K10_37:
    .quad .SB109
.K10_38:
    .quad .SB110
.K10_39:
    .quad .SB111
.K10_40:
    .quad .SB112
.K10_41:
    .quad .SB113
.K10_42:
    .quad .SB114
.K10_43:
    .quad .SB115
.K10_44:
    .quad .SB116
.K10_45:
    .quad .SB117
.K10_46:
    .quad .SB118
.K10_47:
    .quad .SB119
.K10_48:
    .quad .SB120
.K10_49:
    .quad .SB121
.K10_50:
    .quad .SB122
.K10_51:
    .quad .SB123
.K10_52:
    .quad .SB124
.K10_53:
    .quad .SB125
.K10_54:
    .quad .SB126
.K10_55:
    .quad .SB127
.K10_56:
    .quad .SB128
.K10_57:
    .quad .SB129
.K10_58:
    .quad .SB130
.K10_59:
    .quad .SB131
.K10_60:
    .quad .SB132
.K10_61:
    .quad .SB133
.K10_62:
    .quad .SB134
.K10_63:
    .quad .SB135
.K10_64:
    .quad .SB136
.K10_65:
    .quad .SB137
.K10_66:
    .quad .SB138
.K10_67:
    .quad .SB139
.K10_68:
    .quad .SB140
.K10_69:
    .quad .SB141
.K10_70:
    .quad .SB142
.K10_71:
    .quad .SB143
.K10_72:
    .quad .SB144
.K10_73:
    .quad .SB145
.K10_74:
    .quad .SB146
.K10_75:
    .quad .SB147
.K10_76:
    .quad .SB148
.K10_77:
    .quad .SB149
.K10_78:
    .quad .SB150
.K10_79:
    .quad .SB151
.K10_80:
    .quad .SB152
.K10_81:
    .quad .SB153
.K10_82:
    .quad .SB154
.K10_83:
    .quad .SB155
.K10_84:
    .quad .SB156
.K10_85:
    .quad .SB157
.K10_86:
    .quad .SB158
.K10_87:
    .quad .SB159
.K10_88:
    .quad .SB160
.K10_89:
    .quad .SB161
.K10_90:
    .quad .SB162
.K10_91:
    .quad .SB163
.K10_92:
    .quad .SB164
.K10_93:
    .quad .SB165
.K10_94:
    .quad .SB166
.K10_95:
    .quad .SB167
.K10_96:
    .quad .SB168
.K10_97:
    .quad .SB169
.K10_98:
    .quad .SB170
.K10_99:
    .quad .SB171
    .quad 0
    .quad -1
.K11:
    .quad 14
    .byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K12:
    .quad 5
    .byte 72, 84, 84, 80, 47
    .balign 8
    .section .data.rel.ro
    .balign 8
.Lfern_cagg_begin:
    .section .data.rel.ro
    .balign 8
    .quad 3
    .quad -1
.K1:
    .quad .S0
.K1_0:
    .quad .K0
.K1_1:
    .quad .K0
    .quad 2
    .quad -1
.K5:
    .quad .S7
.K5_0:
    .quad .SB8
    .quad 6
    .quad -1
.K7:
    .quad .S6
    .quad 500
.K7_1:
    .quad .K5
.K7_2:
    .quad .K1
.K7_3:
    .quad .K1
.K7_4:
    .quad .K6
.Lfern_cagg_end:
    .balign 8
.Lfern_cfn_begin:
.Lfern_cfn_end:
    .balign 8
.Lfern_cref_begin:
    .quad .K1_0
    .quad .K1_1
    .quad .K5_0
    .quad .K7_1
    .quad .K7_2
    .quad .K7_3
    .quad .K7_4
    .quad .K9_0
    .quad .K9_1
    .quad .K9_2
    .quad .K9_3
    .quad .K9_4
    .quad .K9_5
    .quad .K9_6
    .quad .K9_7
    .quad .K9_8
    .quad .K9_9
    .quad .K9_10
    .quad .K9_11
    .quad .K9_12
    .quad .K9_13
    .quad .K9_14
    .quad .K9_15
    .quad .K9_16
    .quad .K9_17
    .quad .K9_18
    .quad .K9_19
    .quad .K9_20
    .quad .K9_21
    .quad .K9_22
    .quad .K9_23
    .quad .K9_24
    .quad .K9_25
    .quad .K9_26
    .quad .K9_27
    .quad .K9_28
    .quad .K9_29
    .quad .K9_30
    .quad .K9_31
    .quad .K9_32
    .quad .K9_33
    .quad .K9_34
    .quad .K9_35
    .quad .K9_36
    .quad .K9_37
    .quad .K9_38
    .quad .K9_39
    .quad .K9_40
    .quad .K9_41
    .quad .K9_42
    .quad .K9_43
    .quad .K9_44
    .quad .K9_45
    .quad .K9_46
    .quad .K9_47
    .quad .K9_48
    .quad .K9_49
    .quad .K10_0
    .quad .K10_1
    .quad .K10_2
    .quad .K10_3
    .quad .K10_4
    .quad .K10_5
    .quad .K10_6
    .quad .K10_7
    .quad .K10_8
    .quad .K10_9
    .quad .K10_10
    .quad .K10_11
    .quad .K10_12
    .quad .K10_13
    .quad .K10_14
    .quad .K10_15
    .quad .K10_16
    .quad .K10_17
    .quad .K10_18
    .quad .K10_19
    .quad .K10_20
    .quad .K10_21
    .quad .K10_22
    .quad .K10_23
    .quad .K10_24
    .quad .K10_25
    .quad .K10_26
    .quad .K10_27
    .quad .K10_28
    .quad .K10_29
    .quad .K10_30
    .quad .K10_31
    .quad .K10_32
    .quad .K10_33
    .quad .K10_34
    .quad .K10_35
    .quad .K10_36
    .quad .K10_37
    .quad .K10_38
    .quad .K10_39
    .quad .K10_40
    .quad .K10_41
    .quad .K10_42
    .quad .K10_43
    .quad .K10_44
    .quad .K10_45
    .quad .K10_46
    .quad .K10_47
    .quad .K10_48
    .quad .K10_49
    .quad .K10_50
    .quad .K10_51
    .quad .K10_52
    .quad .K10_53
    .quad .K10_54
    .quad .K10_55
    .quad .K10_56
    .quad .K10_57
    .quad .K10_58
    .quad .K10_59
    .quad .K10_60
    .quad .K10_61
    .quad .K10_62
    .quad .K10_63
    .quad .K10_64
    .quad .K10_65
    .quad .K10_66
    .quad .K10_67
    .quad .K10_68
    .quad .K10_69
    .quad .K10_70
    .quad .K10_71
    .quad .K10_72
    .quad .K10_73
    .quad .K10_74
    .quad .K10_75
    .quad .K10_76
    .quad .K10_77
    .quad .K10_78
    .quad .K10_79
    .quad .K10_80
    .quad .K10_81
    .quad .K10_82
    .quad .K10_83
    .quad .K10_84
    .quad .K10_85
    .quad .K10_86
    .quad .K10_87
    .quad .K10_88
    .quad .K10_89
    .quad .K10_90
    .quad .K10_91
    .quad .K10_92
    .quad .K10_93
    .quad .K10_94
    .quad .K10_95
    .quad .K10_96
    .quad .K10_97
    .quad .K10_98
    .quad .K10_99
.Lfern_cref_end:
    .text
