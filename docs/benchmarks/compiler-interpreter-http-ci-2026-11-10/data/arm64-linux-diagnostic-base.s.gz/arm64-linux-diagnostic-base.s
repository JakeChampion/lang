    .file 1 "/workspace/lang-interpreter-map-main-base-20261110-0330/bench/http_hello.fern"
    .file 2 "stdlib://std/http.fern.md"
    .file 3 "stdlib://std/i32.fern.md"
    .file 4 "stdlib://core/map.fern.md"
    .file 5 "stdlib://std/string.fern.md"
    .file 6 "stdlib://std/headers.fern.md"
    .file 7 "stdlib://std/io_buffered.fern.md"
    .file 8 "stdlib://std/json.fern.md"
    .file 9 "stdlib://std/stream.fern.md"
    .file 10 "stdlib://core/error.fern.md"
    .file 11 "stdlib://std/platform.fern.md"
    .file 12 "stdlib://std/url.fern.md"
    .file 13 "stdlib://std/utf8.fern.md"
    .file 14 "stdlib://core/cmp.fern.md"
    .file 15 "stdlib://core/primitive_text.fern.md"
    .file 16 "stdlib://std/number_parse.fern.md"
    .file 17 "stdlib://core/int.fern.md"
    .file 18 "stdlib://core/ops.fern.md"
    .file 19 "stdlib://core/iter.fern.md"
    .file 20 "stdlib://core/utf8_scalar.fern.md"
    .file 21 "stdlib://std/bigint.fern.md"
    .file 22 "stdlib://std/array.fern.md"
    .file 23 "stdlib://core/mem.fern.md"
    .file 24 "stdlib://std/result.fern.md"
    .file 25 "stdlib://std/i64.fern.md"
    .file 26 "stdlib://std/u32.fern.md"
    .file 27 "stdlib://std/u64.fern.md"
    .file 28 "stdlib://std/f32.fern.md"
    .file 29 "stdlib://std/f64.fern.md"
    .file 30 "stdlib://std/fetch.fern.md"
    .file 31 "stdlib://std/http/cookie.fern.md"
    .file 32 "stdlib://std/async.fern.md"
    .file 33 "stdlib://std/time.fern.md"
    .file 34 "stdlib://std/clock.fern.md"
    .file 35 "stdlib://std/net.fern.md"
    .file 36 "stdlib://std/http/trace.fern.md"
    .file 37 "stdlib://core/f64_text.fern.md"
    .file 38 "stdlib://std/num.fern.md"
    .file 39 "stdlib://std/unicode.fern"
    .file 40 "stdlib://std/dns.fern.md"
    .file 41 "stdlib://std/errno.fern.md"
    .file 42 "stdlib://std/base64.fern.md"
    .file 43 "stdlib://std/brotli.fern.md"
    .file 44 "stdlib://std/deflate.fern.md"
    .file 45 "stdlib://std/zstd.fern.md"
    .file 46 "stdlib://std/wasi_http.fern.md"
    .file 47 "stdlib://std/tls.fern.md"
    .file 48 "stdlib://std/tls/client.fern.md"
    .file 49 "stdlib://std/tls/ktls.fern.md"
    .file 50 "stdlib://std/tls/verify.fern.md"
    .file 51 "stdlib://std/crypto.fern.md"
    .file 52 "stdlib://std/hex.fern.md"
    .file 53 "stdlib://std/envflag.fern.md"
    .file 54 "stdlib://std/http/h2.fern.md"
    .file 55 "stdlib://std/http/h3.fern.md"
    .file 56 "stdlib://std/http/h3q.fern.md"
    .file 57 "stdlib://std/quic/conn.fern.md"
    .file 58 "stdlib://std/publicsuffix.fern"
    .file 59 "stdlib://std/option.fern.md"
    .file 60 "stdlib://std/codec.fern.md"
    .file 61 "stdlib://std/brotli/dictionary.fern"
    .file 62 "stdlib://std/brotli/encoder.fern.md"
    .file 63 "stdlib://std/hash/crc32.fern.md"
    .file 64 "stdlib://std/hash.fern.md"
    .file 65 "stdlib://std/tls/handshake.fern.md"
    .file 66 "stdlib://std/tls/identity.fern.md"
    .file 67 "stdlib://std/tls/keyschedule.fern.md"
    .file 68 "stdlib://std/tls/message.fern.md"
    .file 69 "stdlib://std/tls/record.fern.md"
    .file 70 "stdlib://std/tls/x509.fern.md"
    .file 71 "stdlib://std/crypto/ed25519.fern.md"
    .file 72 "stdlib://std/crypto/ecdsa.fern.md"
    .file 73 "stdlib://std/crypto/sha2.fern.md"
    .file 74 "stdlib://std/crypto/rsa.fern.md"
    .file 75 "stdlib://std/tls/pem.fern.md"
    .file 76 "stdlib://std/http/hpack.fern.md"
    .file 77 "stdlib://std/http/h2/frame.fern.md"
    .file 78 "stdlib://std/quic/frames.fern.md"
    .file 79 "stdlib://std/http/qpack.fern.md"
    .file 80 "stdlib://std/quic/streams.fern.md"
    .file 81 "stdlib://std/quic/packet.fern.md"
    .file 82 "stdlib://std/quic/params.fern.md"
    .file 83 "stdlib://std/quic/recovery.fern.md"
    .file 84 "stdlib://std/tls/server.fern.md"
    .file 85 "stdlib://std/tls/keyshare.fern.md"
    .file 86 "stdlib://std/tls/tls12.fern.md"
    .file 87 "stdlib://std/tls/der.fern.md"
    .file 88 "stdlib://std/crypto/aead.fern.md"
    .file 89 "stdlib://std/crypto/aes_gcm.fern.md"
    .file 90 "stdlib://std/crypto/chacha20poly1305.fern.md"
    .file 91 "stdlib://std/crypto/field25519.fern.md"
    .file 92 "stdlib://std/crypto/montgomery.fern.md"
    .file 93 "stdlib://std/crypto/p256.fern.md"
    .file 94 "stdlib://std/http/huffman.fern.md"
    .file 95 "stdlib://std/crypto/mlkem768.fern.md"
    .file 96 "stdlib://std/crypto/x25519.fern.md"
    .globl _start
    .text
__fn_http____find_crlf:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____find_crlf.k:
__fn_http____find_crlf.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____find_crlf_0:
    .loc 2 682 3 prologue_end
    mov x10, #13
    mov x2, x9
    mov x1, x10
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L0
    mov x2, #0
.L0:
    cmp x1, #255
    b.hi .L5
    cmp x2, x3
    b.ge .L5
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L2
.L1:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L7
    cmp x5, x8
    b.ls .L1
.L2:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L3
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L3
    sub x5, x5, #16
    b .L8
.L7:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L8
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L8:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L6
.L3:
    cmp x5, x6
    b.ge .L5
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L9
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L5
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L5
    add x5, x5, x4
    b .L4
.L9:
    cmp x5, x6
    b.ge .L5
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L4
    add x5, x5, #1
    b .L9
.L4:
    sub x2, x5, x0
    b .L6
.L5:
    mov x2, #-1
.L6:
    mov x0, x2
.Lssa_http____find_crlf_3:
.Lssa_http____find_crlf_4:
    cmp x0, #0
    b.lt .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_8:
    add x10, x0, #1
    sxtw x10, w10
    cmp x10, x20
    b.ge .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_7:
    add w10, w0, #1
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http____find_crlf_1
.Lssa_http____find_crlf_5:
    .loc 2 687 7
    add x9, x0, #1
    sxtw x9, w9
    mov x10, #13
    mov x2, x9
    mov x1, x10
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L10
    mov x2, #0
.L10:
    cmp x1, #255
    b.hi .L15
    cmp x2, x3
    b.ge .L15
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L12
.L11:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L17
    cmp x5, x8
    b.ls .L11
.L12:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L13
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L13
    sub x5, x5, #16
    b .L18
.L17:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L18
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L18:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L16
.L13:
    cmp x5, x6
    b.ge .L15
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L19
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L15
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L15
    add x5, x5, x4
    b .L14
.L19:
    cmp x5, x6
    b.ge .L15
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L14
    add x5, x5, #1
    b .L19
.L14:
    sub x2, x5, x0
    b .L16
.L15:
    mov x2, #-1
.L16:
    mov x0, x2
    cmp x0, #0
    b.ge .Lssa_http____find_crlf_8
.Lssa_http____find_crlf_2:
    .loc 2 689 3
    mov x10, #-1
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____find_crlf_1:
    .loc 2 685 7
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____shared_string:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____shared_string.k:
__fn_http____shared_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
.Lssa_http____shared_string_0:
    ldr x9, [x22, #8]
    sub x10, x21, x20
    sxtw x10, w10
    cmp x9, x10
    b.ne .Lssa_http____shared_string_1
.Lssa_http____shared_string_4:
    .loc 2 2350 3 prologue_end
    ldr x10, [x22, #8]
    mov x9, #0
    mov x4, x10
    mov x3, x9
    mov x2, x22
    mov x1, x20
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L20_aop
    mov x1, #0
.L20_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L20_bop
    mov x3, #0
.L20_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L20_nok
    mov x4, #0
.L20_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L20_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L20_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L20_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L20_vec
.L20_short:
    cmp x10, #8
    b.lt .L20_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L20_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L20_eq
    add x8, x8, x14
.L20_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_w4:
    cmp x10, #4
    b.lt .L20_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L20_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L20_eq
    add x8, x8, x14
.L20_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_w2:
    cmp x10, #2
    b.lt .L20_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L20_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L20_eq
    add x8, x8, x14
.L20_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L20_done
.L20_tail:
    cmp x8, x13
    b.ge .L20_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L20_th
    add x8, x8, #1
    add x9, x9, #1
    b .L20_tail
.L20_th:
    sub x2, x8, x12
    b .L20_done
.L20_eq:
    mov x2, x4
.L20_done:
    mov x0, x2
    ldr x9, [x22, #8]
    cmp x0, x9
    b.ne .Lssa_http____shared_string_1
.Lssa_http____shared_string_3:
    tbnz x22, #0, .Lssa_http____shared_string_rcinc30
    cmp x22, #16, lsl #12
    b.lo .Lssa_http____shared_string_rcinc30
    ldur w5, [x22, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http____shared_string_rcinc30sl
    bl __fern_san_abort_uaf
.Lssa_http____shared_string_rcinc30sl:
    tbnz w5, #31, .Lssa_http____shared_string_rcinc30
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http____shared_string_rcinc30:
    .loc 2 719 5
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____shared_string_1:
    .loc 2 713 5
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn___fern_string_from_bytes_range_u8.r
    .loc 2 721 3
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____token_is:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____token_is.k:
__fn_http____token_is.r:
.Lssa_http____token_is_0:
    .loc 2 814 3 prologue_end
    ldr x10, [x0, #8]
    mov x11, #0
    mov x4, x11
    mov x11, x9
    mov x9, x4
    b __fn_http____token_at.r
    .cfi_endproc
    .ltorg
__fn_http____token_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____token_at.k:
__fn_http____token_at.r:
.Lssa_http____token_at_0:
.Lssa_http____token_at_10:
.Lssa_http____token_at_11:
    cmp x9, x10
    b.ge .Lssa_http____token_at_33
.Lssa_http____token_at_17:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w12, [x6, x9]
.Lssa_http____token_at_16:
    .loc 2 838 3 prologue_end
    cmp x12, #32
    b.eq .Lssa_http____token_at_12
.Lssa_http____token_at_14:
    cmp x12, #9
    b.ne .Lssa_http____token_at_33
.Lssa_http____token_at_12:
    .loc 2 819 10
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____token_at_17
.Lssa_http____token_at_8:
.Lssa_http____token_at_33:
    cmp x10, x9
    b.le .Lssa_http____token_at_7
.Lssa_http____token_at_39:
    sub x12, x10, #1
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w13, [x6, x12]
.Lssa_http____token_at_38:
    .loc 2 838 3
    cmp x13, #32
    b.eq .Lssa_http____token_at_34
.Lssa_http____token_at_36:
    cmp x13, #9
    b.ne .Lssa_http____token_at_7
.Lssa_http____token_at_34:
    .loc 2 822 9
    sub x10, x10, #1
    cmp x10, x9
    b.gt .Lssa_http____token_at_39
.Lssa_http____token_at_7:
    sub x10, x10, x9
    sxtw x10, w10
    ldr x13, [x11, #8]
    cmp x10, x13
    b.eq .Lssa_http____token_at_4
.Lssa_http____token_at_6:
    .loc 2 825 5
    mov x0, #0
    ret
.Lssa_http____token_at_4:
    .loc 2 827 3
.Lssa_http____token_at_3:
    ldr x13, [x11, #8]
    ldr x10, [x11, #0]
    mov x11, #0
.Lssa_http____token_at_59:
    cmp x11, x13
    b.ge .Lssa_http____token_at_2
.Lssa_http____token_at_72:
    add w12, w9, w11
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
.Lssa_http____token_at_71:
    cmp x14, #65
    b.lt .Lssa_http____token_at_67
.Lssa_http____token_at_70:
    cmp x14, #90
    b.gt .Lssa_http____token_at_67
.Lssa_http____token_at_69:
    .loc 2 844 5
    add x12, x14, #32
    sxtw x12, w12
    mov x14, x12
.Lssa_http____token_at_68:
.Lssa_http____token_at_67:
    ldrb w12, [x10, x11]
.Lssa_http____token_at_66:
    cmp x12, #65
    b.lt .Lssa_http____token_at_62
.Lssa_http____token_at_65:
    cmp x12, #90
    b.gt .Lssa_http____token_at_62
.Lssa_http____token_at_64:
    add x15, x12, #32
    sxtw x15, w15
    mov x12, x15
.Lssa_http____token_at_63:
.Lssa_http____token_at_62:
    cmp x14, x12
    b.ne .Lssa_http____token_at_1
.Lssa_http____token_at_60:
    .loc 2 832 7
    add x11, x11, #1
    cmp x11, x13
    b.lt .Lssa_http____token_at_72
.Lssa_http____token_at_2:
    .loc 2 834 3
    mov x0, #1
    ret
.Lssa_http____token_at_1:
    .loc 2 830 7
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn_http____leading_fields:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____leading_fields.k:
__fn_http____leading_fields.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x0
    mov x20, x9
.Lssa_http____leading_fields_0:
    .loc 6 90 3 prologue_end
    adrp x0, .K1
    add x0, x0, :lo12:.K1
    .loc 2 937 3
.Lssa_http____leading_fields_2:
    mov x21, x0
    mov x22, #0
.Lssa_http____leading_fields_3:
    cmp x22, x20
    b.lt .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_6:
    mov x0, x19
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http____leading_fields_1
.Lssa_http____leading_fields_4:
    .loc 2 939 9
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x22, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x19, #16]
    ldr x6, [x9]
    cmp x22, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    ldr x23, [x9, x5, lsl #3]
    tst x21, #1
    b.ne .Lssa_http____leading_fields_uq4
    cmp x21, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq4
    ldur w5, [x21, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____leading_fields_uq4us
    bl __fern_san_abort_uaf
.Lssa_http____leading_fields_uq4us:
    cmp w5, #1
.Lssa_http____leading_fields_uq4:
    b.ne .Lssa_http____leading_fields_10
.Lssa_http____leading_fields_9:
    mov x24, x21
    b .Lssa_http____leading_fields_11
.Lssa_http____leading_fields_10:
    mov x24, #0
.Lssa_http____leading_fields_11:
    .loc 6 301 3
    ldr x25, [x21, #8]
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_14
.Lssa_http____leading_fields_12:
    tbnz x25, #0, .Lssa_http____leading_fields_rcinc56
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc56
    ldur w5, [x25, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http____leading_fields_rcinc56sl
    bl __fern_san_abort_uaf
.Lssa_http____leading_fields_rcinc56sl:
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc56
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcinc56:
.Lssa_http____leading_fields_14:
    tbnz x10, #0, .Lssa_http____leading_fields_rcinc57
    cmp x10, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc57
    ldur w5, [x10, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http____leading_fields_rcinc57sl
    bl __fern_san_abort_uaf
.Lssa_http____leading_fields_rcinc57sl:
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc57
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_http____leading_fields_rcinc57:
    tst x25, #1
    b.ne .Lssa_http____leading_fields_uq14
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq14
    ldur w5, [x25, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____leading_fields_uq14us
    bl __fern_san_abort_uaf
.Lssa_http____leading_fields_uq14us:
    cmp w5, #1
.Lssa_http____leading_fields_uq14:
    b.ne .Lssa_http____leading_fields_16
.Lssa_http____leading_fields_15:
    mov x0, x25
    mov x1, x10
    str x10, [sp, #56]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
    mov x26, x0
    b .Lssa_http____leading_fields_17
.Lssa_http____leading_fields_16:
    mov x0, x25
    mov x1, x10
    bl __fern_arr_push
    mov x26, x0
    mov x0, x25
    bl __fn___fern_arr_inc_elems.r
    mov x0, x25
    bl __fn___fern_arr_dec.r
.Lssa_http____leading_fields_17:
    ldr x25, [x21, #16]
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_20
.Lssa_http____leading_fields_18:
    tbnz x25, #0, .Lssa_http____leading_fields_rcinc67
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc67
    ldur w5, [x25, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http____leading_fields_rcinc67sl
    bl __fern_san_abort_uaf
.Lssa_http____leading_fields_rcinc67sl:
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc67
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcinc67:
.Lssa_http____leading_fields_20:
    tbnz x23, #0, .Lssa_http____leading_fields_rcinc68
    cmp x23, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc68
    ldur w5, [x23, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http____leading_fields_rcinc68sl
    bl __fern_san_abort_uaf
.Lssa_http____leading_fields_rcinc68sl:
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc68
    add w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_http____leading_fields_rcinc68:
    tst x25, #1
    b.ne .Lssa_http____leading_fields_uq20
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq20
    ldur w5, [x25, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____leading_fields_uq20us
    bl __fern_san_abort_uaf
.Lssa_http____leading_fields_uq20us:
    cmp w5, #1
.Lssa_http____leading_fields_uq20:
    b.ne .Lssa_http____leading_fields_22
.Lssa_http____leading_fields_21:
    mov x0, x25
    mov x1, x23
    bl __fern_arr_push_owned
    mov x27, x0
    b .Lssa_http____leading_fields_23
.Lssa_http____leading_fields_22:
    mov x0, x25
    mov x1, x23
    bl __fern_arr_push
    mov x27, x0
    mov x0, x25
    bl __fn___fern_arr_inc_elems.r
    mov x0, x25
    bl __fn___fern_arr_dec.r
.Lssa_http____leading_fields_23:
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_25
.Lssa_http____leading_fields_24:
    mov x10, #3
    str x24, [sp, #-16]!
    str x10, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x10, .S0
    add x10, x10, :lo12:.S0
    str x10, [x0, #0]
    mov x25, x0
    b .Lssa_http____leading_fields_26
.Lssa_http____leading_fields_25:
    mov x25, x24
.Lssa_http____leading_fields_26:
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_29
.Lssa_http____leading_fields_28:
    mov x0, x21
    bl __fn___sem_release_HeaderMap.r
.Lssa_http____leading_fields_29:
    str x26, [x25, #8]
    str x27, [x25, #16]
    .loc 2 940 7
    add x22, x22, #1
    mov x21, x25
    cmp x22, x20
    b.ge .Lssa_http____leading_fields_6
    b .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_1:
    .loc 2 942 3
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____crlf_terminated:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____crlf_terminated.k:
__fn_http____crlf_terminated.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____crlf_terminated_0:
.Lssa_http____crlf_terminated_7:
    mov x21, x9
.Lssa_http____crlf_terminated_8:
.Lssa_http____crlf_terminated_18:
    .loc 2 953 5 prologue_end
    mov x9, #13
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L21
    mov x2, #0
.L21:
    cmp x1, #255
    b.hi .L26
    cmp x2, x3
    b.ge .L26
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L23
.L22:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L28
    cmp x5, x8
    b.ls .L22
.L23:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L24
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L24
    sub x5, x5, #16
    b .L29
.L28:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L29
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L29:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L27
.L24:
    cmp x5, x6
    b.ge .L26
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L30
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L26
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L26
    add x5, x5, x4
    b .L25
.L30:
    cmp x5, x6
    b.ge .L26
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L25
    add x5, x5, #1
    b .L30
.L25:
    sub x2, x5, x0
    b .L27
.L26:
    mov x2, #-1
.L27:
    mov x22, x2
    .loc 2 954 5
    mov x9, #10
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L31
    mov x2, #0
.L31:
    cmp x1, #255
    b.hi .L36
    cmp x2, x3
    b.ge .L36
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L33
.L32:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L38
    cmp x5, x8
    b.ls .L32
.L33:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L34
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L34
    sub x5, x5, #16
    b .L39
.L38:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L39
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L39:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L37
.L34:
    cmp x5, x6
    b.ge .L36
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L40
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L36
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L36
    add x5, x5, x4
    b .L35
.L40:
    cmp x5, x6
    b.ge .L36
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L35
    add x5, x5, #1
    b .L40
.L35:
    sub x2, x5, x0
    b .L37
.L36:
    mov x2, #-1
.L37:
    mov x0, x2
    cmp x22, #0
    b.lt .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_17:
    cmp x22, x20
    b.ge .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_15:
    cmp x0, #0
    b.lt .Lssa_http____crlf_terminated_12
.Lssa_http____crlf_terminated_14:
    cmp x0, x22
    b.lt .Lssa_http____crlf_terminated_2
.Lssa_http____crlf_terminated_12:
    add x9, x22, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http____crlf_terminated_9
.Lssa_http____crlf_terminated_11:
    add x10, x22, #1
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.ne .Lssa_http____crlf_terminated_1
.Lssa_http____crlf_terminated_9:
    .loc 2 964 7
    add x22, x22, #2
    sxtw x21, w22
    b .Lssa_http____crlf_terminated_18
.Lssa_http____crlf_terminated_6:
    .loc 2 956 7
    mov x9, #1
    cmp x0, x20
    cset x20, ge
    cmp x0, #0
    csel x0, x9, x20, lt
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_2:
    .loc 2 959 7
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_1:
    .loc 2 962 7
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____field_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____field_at.k:
__fn_http____field_at.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____field_at_0:
.Lssa_http____field_at_3:
    mov x21, x10
.Lssa_http____field_at_4:
    ldr x10, [x19, #8]
    ldr x9, [x10, #0]
    cmp x21, x9
    b.ge .Lssa_http____field_at_2
.Lssa_http____field_at_8:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x10, #8]
    ldr x10, [x20, #8]
    cmp x9, x10
    b.ne .Lssa_http____field_at_5
.Lssa_http____field_at_7:
    ldr x10, [x19, #8]
    ldr x6, [x10]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x10, x5, lsl #3]
    mov x9, x20
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http____field_at_1
.Lssa_http____field_at_5:
    .loc 2 1089 7 prologue_end
    add x21, x21, #1
    b .Lssa_http____field_at_4
.Lssa_http____field_at_2:
    .loc 2 1091 3
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____field_at_1:
    .loc 2 1087 7
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____kind_if:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____kind_if.k:
__fn_http____kind_if.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x10
.Lssa_http____kind_if_0:
    bl __fn_string__eq_ignore_ascii_case.r
    cbz x0, .Lssa_http____kind_if_1
.Lssa_http____kind_if_3:
    .loc 2 1152 5 prologue_end
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____kind_if_1:
    .loc 2 1154 3
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____target_start:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____target_start.k:
__fn_http____target_start.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____target_start_0:
    mov x12, #2
    and x12, x0, x12
    cbz x12, .Lssa_http____target_start_2
.Lssa_http____target_start_1:
    mov x12, #-2
    add x12, x0, x12
    ldr x13, [x12, #0]
    ldr x14, [x12, #8]
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_http____target_start_3
.Lssa_http____target_start_2:
    add x14, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____target_start_5
.Lssa_http____target_start_4:
    ldr x13, [x0, #0]
    b .Lssa_http____target_start_3
.Lssa_http____target_start_5:
    mov x13, #0
.Lssa_http____target_start_6:
.Lssa_http____target_start_3:
    add x12, x9, #1
    sxtw x12, w12
    cmp x10, x12
    b.ne .Lssa_http____target_start_13
.Lssa_http____target_start_19:
    mov w12, w9
    cmp x12, x13
    b.lo .Lssa_http____target_start_26
.Lssa_http____target_start_24:
    bl __fern_oob_abort
.Lssa_http____target_start_26:
    ldrb w15, [x14, x12]
    cmp x15, #42
    b.ne .Lssa_http____target_start_13
.Lssa_http____target_start_18:
    .loc 2 2056 7 prologue_end
    mov x15, #-1
    .loc 2 2058 5
    mov x12, #-2
    cmp x11, #0
    csel x15, x15, x12, ne
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____target_start_13:
    cmp x10, x9
    b.le .Lssa_http____target_start_9
.Lssa_http____target_start_12:
    mov w15, w9
    cmp x15, x13
    b.lo .Lssa_http____target_start_41
.Lssa_http____target_start_39:
    bl __fern_oob_abort
.Lssa_http____target_start_41:
    ldrb w13, [x14, x15]
    cmp x13, #47
    b.ne .Lssa_http____target_start_9
.Lssa_http____target_start_11:
    .loc 2 2061 5
    mov x0, x9
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____target_start_9:
    .loc 2 2063 3
    bl __fn_http____absolute_form_path.r
    .loc 2 2065 5
    mov x10, #-2
    cmp x0, #0
    csel x0, x10, x0, lt
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____path_end:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____path_end.k:
__fn_http____path_end.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_http____path_end_0:
    mov x11, #2
    and x11, x0, x11
    cbz x11, .Lssa_http____path_end_2
.Lssa_http____path_end_1:
    mov x11, #-2
    add x11, x0, x11
    ldr x12, [x11, #0]
    ldr x13, [x11, #8]
    mov x4, x12
    mov x12, x13
    mov x13, x4
    b .Lssa_http____path_end_16
.Lssa_http____path_end_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____path_end_5
.Lssa_http____path_end_4:
    ldr x12, [x0, #0]
    b .Lssa_http____path_end_16
.Lssa_http____path_end_5:
    mov x12, #0
.Lssa_http____path_end_6:
.Lssa_http____path_end_3:
.Lssa_http____path_end_15:
.Lssa_http____path_end_16:
    cmp x9, x10
    b.ge .Lssa_http____path_end_14
.Lssa_http____path_end_19:
    mov w11, w9
    cmp x11, x12
    b.lo .Lssa_http____path_end_26
.Lssa_http____path_end_24:
    bl __fern_oob_abort
.Lssa_http____path_end_26:
    ldrb w14, [x13, x11]
    .loc 2 2071 3 prologue_end
    cmp x14, #63
    b.eq .Lssa_http____path_end_13
.Lssa_http____path_end_17:
    .loc 2 2125 7
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____path_end_19
.Lssa_http____path_end_14:
    .loc 2 2127 3
    mov x12, #-1
    mov x19, x12
    b .Lssa_http____path_end_12
.Lssa_http____path_end_13:
    mov x19, x9
.Lssa_http____path_end_12:
    cmp x19, #0
    b.ge .Lssa_http____path_end_9
.Lssa_http____path_end_11:
    .loc 2 2073 5
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_end_9:
    add x12, x19, #1
    sxtw x9, w12
    bl __fn_http____query_ok.r
    cbz x0, .Lssa_http____path_end_7
.Lssa_http____path_end_8:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_end_7:
    .loc 2 2076 5
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____absolute_form_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____absolute_form_path.k:
__fn_http____absolute_form_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_http____absolute_form_path_0:
    mov x9, #2
    and x9, x19, x9
    cbz x9, .Lssa_http____absolute_form_path_2
.Lssa_http____absolute_form_path_1:
    mov x9, #-2
    add x9, x19, x9
    ldr x10, [x9, #0]
    ldr x11, [x9, #8]
    mov x22, x10
    mov x23, x11
    b .Lssa_http____absolute_form_path_3
.Lssa_http____absolute_form_path_2:
    add x11, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____absolute_form_path_5
.Lssa_http____absolute_form_path_4:
    ldr x10, [x19, #0]
    b .Lssa_http____absolute_form_path_6
.Lssa_http____absolute_form_path_5:
    mov x10, #0
.Lssa_http____absolute_form_path_6:
    mov x22, x11
    mov x23, x10
.Lssa_http____absolute_form_path_3:
    .loc 2 2082 3 prologue_end
    mov x24, #-1
    adrp x11, .SB1
    add x11, x11, :lo12:.SB1
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_17
.Lssa_http____absolute_form_path_19:
    .loc 2 2084 8
    add x11, x20, #7
    sxtw x11, w11
    mov x24, x11
.Lssa_http____absolute_form_path_18:
.Lssa_http____absolute_form_path_17:
    adrp x11, .SB2
    add x11, x11, :lo12:.SB2
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_14
.Lssa_http____absolute_form_path_16:
    .loc 2 2087 8
    add x20, x20, #8
    sxtw x20, w20
    mov x24, x20
.Lssa_http____absolute_form_path_15:
.Lssa_http____absolute_form_path_14:
    cmp x24, #0
    b.ge .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_13:
    .loc 2 2090 5
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_11:
    mov x20, x24
.Lssa_http____absolute_form_path_34:
    cmp x20, x21
    b.ge .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_39:
    mov w11, w20
    cmp x11, x23
    b.lo .Lssa_http____absolute_form_path_46
.Lssa_http____absolute_form_path_44:
    bl __fern_oob_abort
.Lssa_http____absolute_form_path_46:
    ldrb w0, [x22, x11]
    cmp x0, #47
    b.eq .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_38:
    cmp x0, #63
    b.eq .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_37:
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____absolute_form_path_8
.Lssa_http____absolute_form_path_35:
    .loc 2 2097 19
    add x20, x20, #1
    cmp x20, x21
    b.lt .Lssa_http____absolute_form_path_39
.Lssa_http____absolute_form_path_10:
    .loc 2 2100 5
    mov x11, #-1
    cmp x20, x24
    csel x0, x11, x20, eq
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_8:
    .loc 2 2095 7
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____prefix_ci:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____prefix_ci.k:
__fn_http____prefix_ci.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____prefix_ci_0:
    mov x12, #2
    and x12, x0, x12
    cbz x12, .Lssa_http____prefix_ci_2
.Lssa_http____prefix_ci_1:
    mov x12, #-2
    add x12, x0, x12
    ldr x13, [x12, #0]
    ldr x14, [x12, #8]
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_2:
    add x14, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____prefix_ci_5
.Lssa_http____prefix_ci_4:
    ldr x13, [x0, #0]
    b .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_5:
    mov x13, #0
.Lssa_http____prefix_ci_6:
.Lssa_http____prefix_ci_3:
    sub x10, x10, x9
    sxtw x10, w10
    ldr x12, [x11, #8]
    cmp x10, x12
    b.ge .Lssa_http____prefix_ci_10
.Lssa_http____prefix_ci_12:
    .loc 2 2107 5 prologue_end
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_10:
    .loc 2 2109 3
.Lssa_http____prefix_ci_9:
    ldr x12, [x11, #8]
    ldr x10, [x11, #0]
    mov x11, #0
.Lssa_http____prefix_ci_17:
    cmp x11, x12
    b.ge .Lssa_http____prefix_ci_8
.Lssa_http____prefix_ci_25:
    add w15, w9, w11
    cmp x15, x13
    b.lo .Lssa_http____prefix_ci_32
.Lssa_http____prefix_ci_30:
    bl __fern_oob_abort
.Lssa_http____prefix_ci_32:
    ldrb w1, [x14, x15]
.Lssa_http____prefix_ci_24:
    cmp x1, #65
    b.lt .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_23:
    cmp x1, #90
    b.gt .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_22:
    .loc 2 844 5
    add x15, x1, #32
    sxtw x15, w15
    mov x1, x15
.Lssa_http____prefix_ci_21:
.Lssa_http____prefix_ci_20:
    ldrb w15, [x10, x11]
    cmp x1, x15
    b.ne .Lssa_http____prefix_ci_7
.Lssa_http____prefix_ci_18:
    .loc 2 2114 7
    add x11, x11, #1
    cmp x11, x12
    b.lt .Lssa_http____prefix_ci_25
.Lssa_http____prefix_ci_8:
    .loc 2 2116 3
    mov x0, #1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_7:
    .loc 2 2112 7
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____is_pchar:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____is_pchar.k:
__fn_http____is_pchar.r:
.Lssa_http____is_pchar_0:
.Lssa_http____is_pchar_42:
    .loc 2 2136 3 prologue_end
    cmp x0, #97
    b.lt .Lssa_http____is_pchar_37
.Lssa_http____is_pchar_41:
    cmp x0, #122
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_37:
    cmp x0, #65
    b.lt .Lssa_http____is_pchar_32
.Lssa_http____is_pchar_36:
    cmp x0, #90
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_32:
    cmp x0, #48
    b.lt .Lssa_http____is_pchar_27
.Lssa_http____is_pchar_31:
    cmp x0, #57
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_27:
    cmp x0, #45
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_24:
    cmp x0, #46
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_21:
    cmp x0, #95
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_18:
    cmp x0, #126
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_14:
    .loc 2 2141 3
    adrp x9, .SB3
    add x9, x9, :lo12:.SB3
    .loc 2 2142 3
.Lssa_http____is_pchar_13:
    ldr x10, [x9, #8]
    ldr x11, [x9, #0]
    mov x9, #0
.Lssa_http____is_pchar_93:
    cmp x9, x10
    b.ge .Lssa_http____is_pchar_8
.Lssa_http____is_pchar_96:
    ldrb w12, [x11, x9]
    cmp x12, x0
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_94:
    .loc 2 2147 7
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____is_pchar_96
.Lssa_http____is_pchar_8:
    cmp x0, #58
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_5:
    cmp x0, #64
    b.ne .Lssa_http____is_pchar_2
.Lssa_http____is_pchar_3:
    mov x0, #1
    b .Lssa_http____is_pchar_1
.Lssa_http____is_pchar_2:
    cmp x0, #37
    cset x0, eq
.Lssa_http____is_pchar_1:
    ret
    .cfi_endproc
    .ltorg
__fn_http____query_ok:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____query_ok.k:
__fn_http____query_ok.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____query_ok_0:
    mov x10, #2
    and x10, x19, x10
    cbz x10, .Lssa_http____query_ok_2
.Lssa_http____query_ok_1:
    mov x10, #-2
    add x10, x19, x10
    ldr x11, [x10, #0]
    ldr x12, [x10, #8]
    mov x21, x11
    mov x22, x12
    b .Lssa_http____query_ok_10
.Lssa_http____query_ok_2:
    add x12, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____query_ok_5
.Lssa_http____query_ok_4:
    ldr x11, [x19, #0]
    b .Lssa_http____query_ok_6
.Lssa_http____query_ok_5:
    mov x11, #0
.Lssa_http____query_ok_6:
    mov x21, x12
    mov x22, x11
.Lssa_http____query_ok_3:
.Lssa_http____query_ok_10:
    mov x23, x9
.Lssa_http____query_ok_11:
    cmp x23, x20
    b.ge .Lssa_http____query_ok_9
.Lssa_http____query_ok_21:
    mov w9, w23
    cmp x9, x22
    b.lo .Lssa_http____query_ok_28
.Lssa_http____query_ok_26:
    bl __fern_oob_abort
.Lssa_http____query_ok_28:
    ldrb w24, [x21, x9]
    cmp x24, #37
    b.ne .Lssa_http____query_ok_17
.Lssa_http____query_ok_20:
    mov x0, x19
    mov x9, x23
    mov x10, x20
    bl __fn_http____pct_byte.r
    cmp x0, #0
    b.lt .Lssa_http____query_ok_8
.Lssa_http____query_ok_18:
    .loc 2 2160 9 prologue_end
    add x9, x23, #3
    sxtw x9, w9
    mov x23, x9
    b .Lssa_http____query_ok_11
.Lssa_http____query_ok_17:
    mov x0, x24
    bl __fn_http____is_pchar.r
    cbnz x0, .Lssa_http____query_ok_13
.Lssa_http____query_ok_16:
    cmp x24, #47
    b.eq .Lssa_http____query_ok_13
.Lssa_http____query_ok_15:
    cmp x24, #63
    b.ne .Lssa_http____query_ok_7
.Lssa_http____query_ok_13:
    .loc 2 2165 9
    add x23, x23, #1
.Lssa_http____query_ok_12:
    cmp x23, x20
    b.lt .Lssa_http____query_ok_21
.Lssa_http____query_ok_9:
    .loc 2 2168 3
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_8:
    .loc 2 2158 9
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_7:
    .loc 2 2163 9
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____pct_byte:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____pct_byte.k:
__fn_http____pct_byte.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____pct_byte_0:
    mov x11, #2
    and x11, x0, x11
    cbz x11, .Lssa_http____pct_byte_2
.Lssa_http____pct_byte_1:
    mov x11, #-2
    add x11, x0, x11
    ldr x12, [x11, #0]
    ldr x13, [x11, #8]
    mov x4, x12
    mov x12, x13
    mov x13, x4
    b .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____pct_byte_5
.Lssa_http____pct_byte_4:
    ldr x12, [x0, #0]
    b .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_5:
    mov x12, #0
.Lssa_http____pct_byte_6:
.Lssa_http____pct_byte_3:
    add x11, x9, #2
    sxtw x11, w11
    cmp x11, x10
    b.lt .Lssa_http____pct_byte_39
.Lssa_http____pct_byte_41:
    .loc 2 2173 5 prologue_end
    mov x0, #-1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_39:
    .loc 2 2175 3
    add w11, w9, #1
    cmp x11, x12
    b.lo .Lssa_http____pct_byte_48
.Lssa_http____pct_byte_46:
    bl __fern_oob_abort
.Lssa_http____pct_byte_48:
    ldrb w10, [x13, x11]
.Lssa_http____pct_byte_38:
    cmp x10, #48
    b.lo .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_37:
    cmp x10, #57
    b.hi .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_36:
    .loc 2 1250 5
    sub x11, x10, #48
    sxtw x11, w11
    mov x10, x11
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_34:
    cmp x10, #97
    b.lo .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_33:
    cmp x10, #102
    b.hi .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_32:
    .loc 2 1253 5
    sub x11, x10, #87
    sxtw x11, w11
    mov x10, x11
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_30:
    cmp x10, #65
    b.lo .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_29:
    cmp x10, #70
    b.hi .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_28:
    .loc 2 1256 5
    sub x10, x10, #55
    sxtw x10, w10
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_26:
    .loc 2 1258 3
    mov x10, #-1
.Lssa_http____pct_byte_25:
    .loc 2 2176 3
    add w9, w9, #2
    cmp x9, x12
    b.lo .Lssa_http____pct_byte_78
.Lssa_http____pct_byte_76:
    bl __fern_oob_abort
.Lssa_http____pct_byte_78:
    ldrb w12, [x13, x9]
.Lssa_http____pct_byte_24:
    cmp x12, #48
    b.lo .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_23:
    cmp x12, #57
    b.hi .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_22:
    .loc 2 1250 5
    sub x9, x12, #48
    sxtw x9, w9
    mov x12, x9
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_20:
    cmp x12, #97
    b.lo .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_19:
    cmp x12, #102
    b.hi .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_18:
    .loc 2 1253 5
    sub x9, x12, #87
    sxtw x9, w9
    mov x12, x9
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_16:
    cmp x12, #65
    b.lo .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_15:
    cmp x12, #70
    b.hi .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_14:
    .loc 2 1256 5
    sub x12, x12, #55
    sxtw x12, w12
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_12:
    .loc 2 1258 3
    mov x12, #-1
.Lssa_http____pct_byte_11:
    cmp x10, #0
    b.lt .Lssa_http____pct_byte_9
.Lssa_http____pct_byte_10:
    cmp x12, #0
    b.ge .Lssa_http____pct_byte_7
.Lssa_http____pct_byte_9:
    .loc 2 2178 5
    mov x0, #-1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_7:
    .loc 2 2180 3
    lsl x10, x10, #4
    add x10, x10, x12
    sxtw x0, w10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____plain_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____plain_path.k:
__fn_http____plain_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    str x25, [sp, #-16]!
    mov x19, x9
    mov x20, x10
.Lssa_http____plain_path_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa_http____plain_path_2
.Lssa_http____plain_path_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #0]
    ldr x11, [x9, #8]
    mov x21, x10
    mov x22, x11
    b .Lssa_http____plain_path_3
.Lssa_http____plain_path_2:
    add x11, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____plain_path_5
.Lssa_http____plain_path_4:
    ldr x10, [x0, #0]
    b .Lssa_http____plain_path_6
.Lssa_http____plain_path_5:
    mov x10, #0
.Lssa_http____plain_path_6:
    mov x21, x11
    mov x22, x10
.Lssa_http____plain_path_3:
    .loc 2 2189 3 prologue_end
    add x10, x19, #1
.Lssa_http____plain_path_17:
    mov x23, x10
    mov x24, x19
.Lssa_http____plain_path_18:
    cmp x24, x20
    b.ge .Lssa_http____plain_path_15
.Lssa_http____plain_path_34:
    mov w10, w24
    cmp x10, x22
    b.lo .Lssa_http____plain_path_41
.Lssa_http____plain_path_39:
    bl __fern_oob_abort
.Lssa_http____plain_path_41:
    ldrb w0, [x21, x10]
    cmp x0, #47
    b.ne .Lssa_http____plain_path_26
.Lssa_http____plain_path_33:
    cmp x24, x19
    b.le .Lssa_http____plain_path_20
.Lssa_http____plain_path_31:
    .loc 2 2207 3
    sub x10, x24, x23
    sxtw x25, w10
    cmp x25, #1
    b.lt .Lssa_http____plain_path_27
.Lssa_http____plain_path_30:
    cmp x25, #2
    b.gt .Lssa_http____plain_path_27
.Lssa_http____plain_path_29:
    mov w10, w23
    cmp x10, x22
    b.lo .Lssa_http____plain_path_60
.Lssa_http____plain_path_58:
    bl __fern_oob_abort
.Lssa_http____plain_path_60:
    ldrb w11, [x21, x10]
    cmp x11, #46
    b.ne .Lssa_http____plain_path_27
.Lssa_http____plain_path_28:
    sub w11, w24, #1
    cmp x11, x22
    b.lo .Lssa_http____plain_path_67
.Lssa_http____plain_path_65:
    bl __fern_oob_abort
.Lssa_http____plain_path_67:
    ldrb w10, [x21, x11]
    cmp x10, #46
    b.eq .Lssa_http____plain_path_22
.Lssa_http____plain_path_27:
    .loc 2 2209 5
    mov x25, #0
    b .Lssa_http____plain_path_22
.Lssa_http____plain_path_26:
    cmp x0, #37
    b.eq .Lssa_http____plain_path_9
.Lssa_http____plain_path_25:
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____plain_path_9
.Lssa_http____plain_path_24:
    b .Lssa_http____plain_path_19
.Lssa_http____plain_path_23:
.Lssa_http____plain_path_22:
    cmp x25, #0
    b.gt .Lssa_http____plain_path_10
.Lssa_http____plain_path_20:
    .loc 2 2197 11
    add x10, x24, #1
    mov x23, x10
.Lssa_http____plain_path_19:
    .loc 2 2201 7
    add x24, x24, #1
    cmp x24, x20
    b.lt .Lssa_http____plain_path_34
.Lssa_http____plain_path_15:
    .loc 2 2207 3
    sub x10, x20, x23
    sxtw x10, w10
    cmp x10, #1
    b.lt .Lssa_http____plain_path_11
.Lssa_http____plain_path_14:
    cmp x10, #2
    b.gt .Lssa_http____plain_path_11
.Lssa_http____plain_path_13:
    mov w23, w23
    cmp x23, x22
    b.lo .Lssa_http____plain_path_98
.Lssa_http____plain_path_96:
    bl __fern_oob_abort
.Lssa_http____plain_path_98:
    ldrb w11, [x21, x23]
    cmp x11, #46
    b.ne .Lssa_http____plain_path_11
.Lssa_http____plain_path_12:
    sub w20, w20, #1
    cmp x20, x22
    b.lo .Lssa_http____plain_path_105
.Lssa_http____plain_path_103:
    bl __fern_oob_abort
.Lssa_http____plain_path_105:
    ldrb w11, [x21, x20]
    cmp x11, #46
    b.eq .Lssa_http____plain_path_7
.Lssa_http____plain_path_11:
    .loc 2 2209 5
    mov x10, #0
    b .Lssa_http____plain_path_7
.Lssa_http____plain_path_10:
    .loc 2 2195 9
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____plain_path_9:
    .loc 2 2199 7
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____plain_path_8:
.Lssa_http____plain_path_7:
    .loc 2 2203 3
    cmp x10, #0
    cset x0, eq
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____decoded_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____decoded_path.k:
__fn_http____decoded_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #80
    mov x19, x0
    mov x20, x10
    str x11, [sp, #72]
.Lssa_http____decoded_path_0:
    mov x10, #2
    and x10, x19, x10
    cbz x10, .Lssa_http____decoded_path_2
.Lssa_http____decoded_path_1:
    mov x10, #-2
    add x10, x19, x10
    ldr x11, [x10, #0]
    ldr x12, [x10, #8]
    mov x22, x11
    mov x23, x12
    b .Lssa_http____decoded_path_3
.Lssa_http____decoded_path_2:
    add x12, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____decoded_path_5
.Lssa_http____decoded_path_4:
    ldr x11, [x19, #0]
    b .Lssa_http____decoded_path_6
.Lssa_http____decoded_path_5:
    mov x11, #0
.Lssa_http____decoded_path_6:
    mov x22, x12
    mov x23, x11
.Lssa_http____decoded_path_3:
    .loc 2 2215 3 prologue_end
    adrp x0, .K2
    add x0, x0, :lo12:.K2
    .loc 2 2219 3
    add x9, x9, #1
    sxtw x9, w9
    .loc 2 2216 3
    .loc 2 2217 3
    .loc 2 2218 3
.Lssa_http____decoded_path_14:
    mov x24, x0
    mov x28, x9
    mov x25, #0
    mov x27, #0
    str xzr, [sp, #64]
.Lssa_http____decoded_path_15:
    cmp x28, x20
    b.gt .Lssa_http____decoded_path_13
.Lssa_http____decoded_path_47:
    .loc 2 2222 9
    mov x9, #47
.Lssa_http____decoded_path_46:
    ldr x11, [x24, #0]
    cmp x25, x11
    b.ge .Lssa_http____decoded_path_43
.Lssa_http____decoded_path_45:
    .loc 2 2308 5
    tst x24, #1
    b.ne .Lssa_http____decoded_path_uq45
    cmp x24, #16, lsl #12
    b.lo .Lssa_http____decoded_path_uq45
    ldur w5, [x24, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____decoded_path_uq45us
    bl __fern_san_abort_uaf
.Lssa_http____decoded_path_uq45us:
    cmp w5, #1
.Lssa_http____decoded_path_uq45:
    b.ne .Lssa_http____decoded_path_57
.Lssa_http____decoded_path_56:
    b .Lssa_http____decoded_path_58
.Lssa_http____decoded_path_57:
    str x9, [sp, #56]
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #56]
    mov x11, #0
    ldr x12, [x24, #0]
    str x9, [sp, #56]
    mov x0, x24
    mov x9, x11
    mov x10, x12
    bl __fn___fern_arr_slice_u8.r
    ldr x9, [sp, #56]
    mov x24, x0
.Lssa_http____decoded_path_58:
    .loc 2 2222 9
    mov x12, #47
    .loc 2 2308 5
    ldr x7, [x24]
    cmp x25, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, x25
    strb w12, [x5, #8]
    mov x11, x24
    b .Lssa_http____decoded_path_42
.Lssa_http____decoded_path_43:
    .loc 2 2310 3
    tst x24, #1
    b.ne .Lssa_http____decoded_path_uq43
    cmp x24, #16, lsl #12
    b.lo .Lssa_http____decoded_path_uq43
    ldur w5, [x24, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____decoded_path_uq43us
    bl __fern_san_abort_uaf
.Lssa_http____decoded_path_uq43us:
    cmp w5, #1
.Lssa_http____decoded_path_uq43:
    b.ne .Lssa_http____decoded_path_61
.Lssa_http____decoded_path_60:
    mov x0, x24
    mov x1, x9
    str x9, [sp, #56]
    bl __fern_arr_push_owned_u8
    ldr x9, [sp, #56]
    mov x11, x0
    b .Lssa_http____decoded_path_42
.Lssa_http____decoded_path_61:
    mov x0, x24
    mov x1, x9
    bl __fern_arr_push_u8
    mov x11, x0
    str x11, [sp, #56]
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x11, [sp, #56]
.Lssa_http____decoded_path_62:
.Lssa_http____decoded_path_42:
    .loc 2 2223 7
    add x9, x25, #1
    sxtw x9, w9
.Lssa_http____decoded_path_41:
    mov x24, x11
    mov x21, x28
    mov x28, x9
.Lssa_http____decoded_path_63:
    cmp x21, x20
    b.ge .Lssa_http____decoded_path_40
.Lssa_http____decoded_path_80:
    mov w9, w21
    cmp x9, x23
    b.lo .Lssa_http____decoded_path_87
.Lssa_http____decoded_path_85:
    bl __fern_oob_abort
.Lssa_http____decoded_path_87:
    ldrb w26, [x22, x9]
    cmp x26, #47
    b.eq .Lssa_http____decoded_path_40
.Lssa_http____decoded_path_79:
    .loc 2 2225 7
    mov x0, x19
    mov x9, x21
    mov x10, x20
    bl __fn_http____path_byte.r
    mov x9, x0
    cmp x9, #0
    b.ge .Lssa_http____decoded_path_77
.Lssa_http____decoded_path_92:
    str x9, [sp, #56]
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #56]
    b .Lssa_http____decoded_path_10
.Lssa_http____decoded_path_77:
    mov x11, #1
    cmp x9, #128
    cset x12, ge
    cmp x27, #0
    csel x27, x11, x12, ne
    .loc 2 2230 11
    and x12, x9, #255
.Lssa_http____decoded_path_73:
    ldr x9, [x24, #0]
    cmp x28, x9
    b.ge .Lssa_http____decoded_path_70
.Lssa_http____decoded_path_72:
    .loc 2 2308 5
    tst x24, #1
    b.ne .Lssa_http____decoded_path_uq72
    cmp x24, #16, lsl #12
    b.lo .Lssa_http____decoded_path_uq72
    ldur w5, [x24, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____decoded_path_uq72us
    bl __fern_san_abort_uaf
.Lssa_http____decoded_path_uq72us:
    cmp w5, #1
.Lssa_http____decoded_path_uq72:
    b.ne .Lssa_http____decoded_path_106
.Lssa_http____decoded_path_105:
    b .Lssa_http____decoded_path_107
.Lssa_http____decoded_path_106:
    str x12, [sp, #56]
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x12, [sp, #56]
    mov x9, #0
    ldr x11, [x24, #0]
    str x12, [sp, #56]
    mov x0, x24
    mov x10, x11
    bl __fn___fern_arr_slice_u8.r
    ldr x12, [sp, #56]
    mov x24, x0
.Lssa_http____decoded_path_107:
    ldr x7, [x24]
    cmp x28, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, x28
    strb w12, [x5, #8]
    b .Lssa_http____decoded_path_69
.Lssa_http____decoded_path_70:
    .loc 2 2310 3
    tst x24, #1
    b.ne .Lssa_http____decoded_path_uq70
    cmp x24, #16, lsl #12
    b.lo .Lssa_http____decoded_path_uq70
    ldur w5, [x24, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____decoded_path_uq70us
    bl __fern_san_abort_uaf
.Lssa_http____decoded_path_uq70us:
    cmp w5, #1
.Lssa_http____decoded_path_uq70:
    b.ne .Lssa_http____decoded_path_110
.Lssa_http____decoded_path_109:
    mov x0, x24
    mov x1, x12
    str x12, [sp, #56]
    bl __fern_arr_push_owned_u8
    ldr x12, [sp, #56]
    mov x11, x0
    b .Lssa_http____decoded_path_111
.Lssa_http____decoded_path_110:
    mov x0, x24
    mov x1, x12
    bl __fern_arr_push_u8
    mov x11, x0
    str x11, [sp, #56]
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x11, [sp, #56]
.Lssa_http____decoded_path_111:
    mov x24, x11
.Lssa_http____decoded_path_69:
    .loc 2 2231 9
    add x11, x28, #1
    sxtw x28, w11
.Lssa_http____decoded_path_68:
    .loc 2 2266 5
    mov x11, #3
    .loc 2 2268 3
    mov x12, #1
    cmp x26, #37
    csel x11, x11, x12, eq
    .loc 2 2232 10
    add x11, x21, x11
    sxtw x21, w11
    cmp x21, x20
    b.lt .Lssa_http____decoded_path_80
.Lssa_http____decoded_path_40:
    .loc 2 2234 14
    cmp x21, x20
    cset x26, eq
    mov x11, #2
    and x11, x24, x11
    cbz x11, .Lssa_http____decoded_path_120
.Lssa_http____decoded_path_119:
    mov x11, #-2
    add x11, x24, x11
    ldr x12, [x11, #0]
    ldr x9, [x11, #8]
    mov x4, x12
    mov x12, x9
    mov x9, x4
    b .Lssa_http____decoded_path_121
.Lssa_http____decoded_path_120:
    add x9, x24, #8
    cmp x24, #0
    b.eq .Lssa_http____decoded_path_123
.Lssa_http____decoded_path_122:
    ldr x12, [x24, #0]
    b .Lssa_http____decoded_path_121
.Lssa_http____decoded_path_123:
    mov x12, #0
.Lssa_http____decoded_path_124:
.Lssa_http____decoded_path_121:
    .loc 2 2235 5
    add x11, x25, #1
.Lssa_http____decoded_path_39:
    .loc 2 2207 3
    sub x10, x28, x11
    sxtw x10, w10
    cmp x10, #1
    b.lt .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_38:
    cmp x10, #2
    b.gt .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_37:
    mov w11, w11
    cmp x11, x12
    b.lo .Lssa_http____decoded_path_135
.Lssa_http____decoded_path_133:
    bl __fern_oob_abort
.Lssa_http____decoded_path_135:
    ldrb w13, [x9, x11]
    cmp x13, #46
    b.ne .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_36:
    sub w13, w28, #1
    cmp x13, x12
    b.lo .Lssa_http____decoded_path_142
.Lssa_http____decoded_path_140:
    bl __fern_oob_abort
.Lssa_http____decoded_path_142:
    ldrb w12, [x9, x13]
    cmp x12, #46
    b.eq .Lssa_http____decoded_path_33
.Lssa_http____decoded_path_35:
    .loc 2 2209 5
    mov x10, #0
.Lssa_http____decoded_path_34:
.Lssa_http____decoded_path_33:
    cmp x10, #0
    b.ne .Lssa_http____decoded_path_30
.Lssa_http____decoded_path_32:
    .loc 2 2237 16
    mov x25, x28
    str xzr, [sp, #64]
    b .Lssa_http____decoded_path_16
.Lssa_http____decoded_path_30:
    cmp x10, #1
    b.ne .Lssa_http____decoded_path_27
.Lssa_http____decoded_path_29:
    b .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_27:
    cmp x25, #0
    b.ne .Lssa_http____decoded_path_24
.Lssa_http____decoded_path_26:
    .loc 2 2276 5
    mov x10, #-1
    mov x25, x10
    b .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_24:
    .loc 2 2278 3
    sub x10, x25, #1
    sxtw x10, w10
.Lssa_http____decoded_path_23:
    mov x28, x10
.Lssa_http____decoded_path_163:
    ldr x6, [x24]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, x28
    ldrb w10, [x5, #8]
    cmp x10, #47
    b.eq .Lssa_http____decoded_path_22
.Lssa_http____decoded_path_164:
    .loc 2 2280 10
    sub x10, x28, #1
    sxtw x28, w10
    b .Lssa_http____decoded_path_163
.Lssa_http____decoded_path_22:
    cbz x27, .Lssa_http____decoded_path_20
.Lssa_http____decoded_path_21:
    .loc 2 713 5
    mov x0, x24
    mov x9, x28
    mov x10, x25
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x10, x0
    str x10, [sp, #56]
    mov x0, x10
    bl __fn_utf8__is_valid.r
    mov x12, x0
    ldr x10, [sp, #56]
    str x12, [sp, #56]
    mov x0, x10
    bl __fn___fern_str_free.r
    ldr x12, [sp, #56]
    cbz x12, .Lssa_http____decoded_path_19
.Lssa_http____decoded_path_20:
    mov x25, x28
    b .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_19:
    .loc 2 2283 5
    mov x12, #-1
    mov x25, x12
.Lssa_http____decoded_path_18:
    cmp x25, #0
    b.ge .Lssa_http____decoded_path_17
.Lssa_http____decoded_path_180:
    mov x0, x24
    bl __fn___fern_arr_dec.r
    b .Lssa_http____decoded_path_9
.Lssa_http____decoded_path_17:
    str x26, [sp, #64]
.Lssa_http____decoded_path_16:
    .loc 2 2244 8
    add x21, x21, #1
    sxtw x28, w21
    cmp x28, x20
    b.le .Lssa_http____decoded_path_47
.Lssa_http____decoded_path_13:
    mov x0, x24
    mov x9, x25
    ldr x10, [sp, #64]
    mov x11, x27
    mov x12, x19
    mov x13, x20
    ldr x14, [sp, #72]
    bl __fn_http____finished_path.r
    mov x28, x0
    mov x25, x1
    mov x0, x24
    bl __fn___fern_arr_dec.r
    cmp x28, #0
    b.ne .Lssa_http____decoded_path_7
.Lssa_http____decoded_path_11:
    mov x1, x25
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_10:
    .loc 2 2227 9
    mov x12, #400
    mov x1, x12
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_9:
    .loc 2 2241 9
    mov x12, #400
    mov x1, x12
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_7:
    mov x1, x25
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____path_byte:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____path_byte.k:
__fn_http____path_byte.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_http____path_byte_0:
    mov x11, #2
    and x11, x0, x11
    cbz x11, .Lssa_http____path_byte_2
.Lssa_http____path_byte_1:
    mov x11, #-2
    add x11, x0, x11
    ldr x12, [x11, #0]
    ldr x13, [x11, #8]
    mov x4, x12
    mov x12, x13
    mov x13, x4
    b .Lssa_http____path_byte_3
.Lssa_http____path_byte_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____path_byte_5
.Lssa_http____path_byte_4:
    ldr x12, [x0, #0]
    b .Lssa_http____path_byte_3
.Lssa_http____path_byte_5:
    mov x12, #0
.Lssa_http____path_byte_6:
.Lssa_http____path_byte_3:
    mov w11, w9
    cmp x11, x12
    b.lo .Lssa_http____path_byte_19
.Lssa_http____path_byte_17:
    bl __fern_oob_abort
.Lssa_http____path_byte_19:
    ldrb w19, [x13, x11]
    cmp x19, #37
    b.ne .Lssa_http____path_byte_9
.Lssa_http____path_byte_16:
    .loc 2 2252 7 prologue_end
    bl __fn_http____pct_byte.r
    cmp x0, #0
    b.le .Lssa_http____path_byte_12
.Lssa_http____path_byte_15:
    cmp x0, #47
    b.eq .Lssa_http____path_byte_12
.Lssa_http____path_byte_14:
    cmp x0, #63
    b.eq .Lssa_http____path_byte_12
.Lssa_http____path_byte_13:
    cmp x0, #35
    b.ne .Lssa_http____path_byte_11
.Lssa_http____path_byte_12:
    .loc 2 2254 7
    mov x10, #-1
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_byte_11:
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_byte_9:
    mov x0, x19
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____path_byte_7
.Lssa_http____path_byte_8:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____path_byte_7:
    .loc 2 2259 5
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____finished_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
    ldr x13, [sp, #80]
    ldr x14, [sp, #96]
__fn_http____finished_path.k:
__fn_http____finished_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x11
    mov x22, x13
    mov x23, x14
.Lssa_http____finished_path_0:
    mov x9, #2
    and x9, x12, x9
    cbz x9, .Lssa_http____finished_path_2
.Lssa_http____finished_path_1:
    mov x9, #-2
    add x9, x12, x9
    ldr x11, [x9, #0]
    ldr x13, [x9, #8]
    mov x24, x11
    mov x25, x13
    b .Lssa_http____finished_path_3
.Lssa_http____finished_path_2:
    add x13, x12, #8
    cmp x12, #0
    b.eq .Lssa_http____finished_path_5
.Lssa_http____finished_path_4:
    ldr x11, [x12, #0]
    b .Lssa_http____finished_path_6
.Lssa_http____finished_path_5:
    mov x11, #0
.Lssa_http____finished_path_6:
    mov x24, x13
    mov x25, x11
.Lssa_http____finished_path_3:
    cmp x20, #0
    b.eq .Lssa_http____finished_path_20
.Lssa_http____finished_path_21:
    cbz x10, .Lssa_http____finished_path_17
.Lssa_http____finished_path_20:
    .loc 2 2290 9 prologue_end
    mov x10, #47
.Lssa_http____finished_path_19:
    ldr x11, [x19, #0]
    cmp x20, x11
    b.ge .Lssa_http____finished_path_15
.Lssa_http____finished_path_18:
    .loc 2 2308 5
    tst x19, #1
    b.ne .Lssa_http____finished_path_uq18
    cmp x19, #16, lsl #12
    b.lo .Lssa_http____finished_path_uq18
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____finished_path_uq18us
    bl __fern_san_abort_uaf
.Lssa_http____finished_path_uq18us:
    cmp w5, #1
.Lssa_http____finished_path_uq18:
    b.ne .Lssa_http____finished_path_35
.Lssa_http____finished_path_34:
    mov x0, x19
    b .Lssa_http____finished_path_36
.Lssa_http____finished_path_35:
    mov x11, #0
    ldr x13, [x19, #0]
    mov x0, x19
    mov x9, x11
    mov x10, x13
    bl __fn___fern_arr_slice_u8.r
.Lssa_http____finished_path_36:
    .loc 2 2290 9
    mov x13, #47
    .loc 2 2308 5
    ldr x7, [x0]
    cmp x20, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x0, x20
    strb w13, [x5, #8]
    b .Lssa_http____finished_path_14
.Lssa_http____finished_path_17:
    mov x0, x19
    b .Lssa_http____finished_path_12
.Lssa_http____finished_path_15:
    .loc 2 2310 3
    mov x0, x19
    mov x1, x10
    bl __fern_arr_push_u8
.Lssa_http____finished_path_14:
    .loc 2 2291 7
    add x20, x20, #1
    sxtw x20, w20
.Lssa_http____finished_path_13:
.Lssa_http____finished_path_12:
    mov x26, x22
    mov x22, x20
    mov x20, x0
.Lssa_http____finished_path_39:
    cmp x26, x23
    b.ge .Lssa_http____finished_path_11
.Lssa_http____finished_path_45:
    mov w10, w26
    cmp x10, x25
    b.lo .Lssa_http____finished_path_52
.Lssa_http____finished_path_50:
    bl __fern_oob_abort
.Lssa_http____finished_path_52:
    ldrb w27, [x24, x10]
.Lssa_http____finished_path_44:
    ldr x10, [x20, #0]
    cmp x22, x10
    b.ge .Lssa_http____finished_path_41
.Lssa_http____finished_path_43:
    .loc 2 2308 5
    cmp x20, x19
    b.ne .Lssa_http____finished_path_58
.Lssa_http____finished_path_57:
    tst x20, #1
    b.ne .Lssa_http____finished_path_uq57
    cmp x20, #16, lsl #12
    b.lo .Lssa_http____finished_path_uq57
    ldur w5, [x20, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____finished_path_uq57us
    bl __fern_san_abort_uaf
.Lssa_http____finished_path_uq57us:
    cmp w5, #1
.Lssa_http____finished_path_uq57:
    b.ne .Lssa_http____finished_path_61
.Lssa_http____finished_path_60:
    b .Lssa_http____finished_path_62
.Lssa_http____finished_path_61:
    mov x10, #0
    ldr x11, [x20, #0]
    mov x0, x20
    mov x9, x10
    mov x10, x11
    bl __fn___fern_arr_slice_u8.r
    mov x20, x0
.Lssa_http____finished_path_62:
    mov x10, x20
    b .Lssa_http____finished_path_59
.Lssa_http____finished_path_58:
    tst x20, #1
    b.ne .Lssa_http____finished_path_uq58
    cmp x20, #16, lsl #12
    b.lo .Lssa_http____finished_path_uq58
    ldur w5, [x20, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http____finished_path_uq58us
    bl __fern_san_abort_uaf
.Lssa_http____finished_path_uq58us:
    cmp w5, #1
.Lssa_http____finished_path_uq58:
    b.ne .Lssa_http____finished_path_64
.Lssa_http____finished_path_63:
    b .Lssa_http____finished_path_65
.Lssa_http____finished_path_64:
    mov x0, x20
    bl __fn___fern_arr_dec.r
    mov x11, #0
    ldr x10, [x20, #0]
    mov x0, x20
    mov x9, x11
    bl __fn___fern_arr_slice_u8.r
    mov x20, x0
.Lssa_http____finished_path_65:
    mov x10, x20
.Lssa_http____finished_path_59:
    ldr x7, [x10]
    cmp x22, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x10, x22
    strb w27, [x5, #8]
    mov x20, x10
    b .Lssa_http____finished_path_40
.Lssa_http____finished_path_41:
    .loc 2 2310 3
    cmp x20, x19
    b.ne .Lssa_http____finished_path_68
.Lssa_http____finished_path_67:
    mov x0, x20
    mov x1, x27
    bl __fern_arr_push_u8
    b .Lssa_http____finished_path_69
.Lssa_http____finished_path_68:
    mov x0, x20
    mov x1, x27
    bl __fern_arr_push_owned_u8
.Lssa_http____finished_path_69:
    mov x20, x0
.Lssa_http____finished_path_40:
    .loc 2 2296 7
    add x11, x22, #1
    sxtw x22, w11
    .loc 2 2297 7
    add x26, x26, #1
    cmp x26, x23
    b.lt .Lssa_http____finished_path_45
.Lssa_http____finished_path_11:
    .loc 2 2299 3
    mov x11, #0
    .loc 2 713 5
    mov x0, x20
    mov x9, x11
    mov x10, x22
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x26, x0
    cmp x20, x19
    b.eq .Lssa_http____finished_path_74
.Lssa_http____finished_path_72:
    mov x0, x20
    bl __fn___fern_arr_dec.r
.Lssa_http____finished_path_74:
    cbz x21, .Lssa_http____finished_path_8
.Lssa_http____finished_path_10:
    mov x0, x26
    bl __fn_utf8__is_valid.r
    cbnz x0, .Lssa_http____finished_path_8
.Lssa_http____finished_path_80:
    mov x0, x26
    bl __fn___fern_str_free.r
    b .Lssa_http____finished_path_7
.Lssa_http____finished_path_8:
    mov x1, x26
    .loc 2 2303 3
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____finished_path_7:
    .loc 2 2301 5
    mov x11, #400
    mov x1, x11
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http__serialize_response_to:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http__serialize_response_to.k:
__fn_http__serialize_response_to.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #16
    str x0, [sp, #8]
    mov x20, x9
    str x11, [sp, #0]
.Lssa_http__serialize_response_to_0:
    tbnz x10, #0, .Lssa_http__serialize_response_to_rcinc283
    cmp x10, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_rcinc283
    ldur w5, [x10, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http__serialize_response_to_rcinc283sl
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_rcinc283sl:
    tbnz w5, #31, .Lssa_http__serialize_response_to_rcinc283
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_http__serialize_response_to_rcinc283:
.Lssa_http__serialize_response_to_59:
    mov x22, x10
.Lssa_http__serialize_response_to_60:
    ldr x0, [x22, #24]
    bl __fn_http__fields_ok.r
    cbnz x0, .Lssa_http__serialize_response_to_62
.Lssa_http__serialize_response_to_64:
    mov x0, x22
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_http__serialize_response_to_61
.Lssa_http__serialize_response_to_62:
    ldr x23, [x22, #32]
    mov x6, #0
    tbnz x22, #0, .Lssa_http__serialize_response_to_rcuniq296
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_rcuniq296
    ldur w5, [x22, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http__serialize_response_to_rcuniq296us
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_rcuniq296us:
    cmp w5, #1
    b.ne .Lssa_http__serialize_response_to_rcuniq296
    mov x6, #1
.Lssa_http__serialize_response_to_rcuniq296:
    mov x0, x6
    cbz x0, .Lssa_http__serialize_response_to_69
.Lssa_http__serialize_response_to_67:
    mov x10, #0
    str x10, [x22, #32]
.Lssa_http__serialize_response_to_69:
    cmp x0, #0
    b.ne .Lssa_http__serialize_response_to_72
.Lssa_http__serialize_response_to_70:
    tbnz x23, #0, .Lssa_http__serialize_response_to_rcinc301
    cmp x23, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_rcinc301
    ldur w5, [x23, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http__serialize_response_to_rcinc301sl
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_rcinc301sl:
    tbnz w5, #31, .Lssa_http__serialize_response_to_rcinc301
    add w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_http__serialize_response_to_rcinc301:
.Lssa_http__serialize_response_to_72:
    mov x0, x23
    bl __fn_http__fields_ok.r
    mov x24, x0
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    cbnz x24, .Lssa_http__serialize_response_to_57
.Lssa_http__serialize_response_to_74:
    mov x0, x22
    bl __fn___sem_release_HttpResponse.r
.Lssa_http__serialize_response_to_61:
    .loc 2 271 3 prologue_end
    adrp x22, .K5
    add x22, x22, :lo12:.K5
    b .Lssa_http__serialize_response_to_60
.Lssa_http__serialize_response_to_57:
    .loc 2 2413 3
    ldr x24, [x22, #8]
.Lssa_http__serialize_response_to_56:
    .loc 2 2487 3
    cmp x24, #200
    b.lt .Lssa_http__serialize_response_to_52
.Lssa_http__serialize_response_to_54:
    cmp x24, #204
    b.ne .Lssa_http__serialize_response_to_51
.Lssa_http__serialize_response_to_52:
    mov x23, #1
    b .Lssa_http__serialize_response_to_49
.Lssa_http__serialize_response_to_51:
    cmp x24, #304
    cset x9, eq
    mov x23, x9
.Lssa_http__serialize_response_to_50:
.Lssa_http__serialize_response_to_49:
    .loc 2 2414 3
    adrp x9, .SB6
    add x9, x9, :lo12:.SB6
    .loc 2 2415 3
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    cbz x23, .Lssa_http__serialize_response_to_46
.Lssa_http__serialize_response_to_48:
    mov x25, x9
    mov x26, x10
    b .Lssa_http__serialize_response_to_43
.Lssa_http__serialize_response_to_46:
    .loc 2 2725 10
    ldr x25, [x22, #16]
    mov x6, #0
    tbnz x22, #0, .Lssa_http__serialize_response_to_rcuniq331
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_rcuniq331
    ldur w5, [x22, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http__serialize_response_to_rcuniq331us
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_rcuniq331us:
    cmp w5, #1
    b.ne .Lssa_http__serialize_response_to_rcuniq331
    mov x6, #1
.Lssa_http__serialize_response_to_rcuniq331:
    mov x0, x6
    cbz x0, .Lssa_http__serialize_response_to_96
.Lssa_http__serialize_response_to_94:
    mov x10, #0
    str x10, [x22, #16]
.Lssa_http__serialize_response_to_96:
    cmp x0, #0
    b.ne .Lssa_http__serialize_response_to_99
.Lssa_http__serialize_response_to_97:
    tbnz x25, #0, .Lssa_http__serialize_response_to_rcinc336
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_rcinc336
    ldur w5, [x25, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http__serialize_response_to_rcinc336sl
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_rcinc336sl:
    tbnz w5, #31, .Lssa_http__serialize_response_to_rcinc336
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__serialize_response_to_rcinc336:
.Lssa_http__serialize_response_to_99:
    ldr x9, [x25, #0]
    adrp x10, .S5
    add x10, x10, :lo12:.S5
    cmp x9, x10
    b.eq .Lssa_http__serialize_response_to_45
.Lssa_http__serialize_response_to_101:
    mov x0, x22
    bl __fn___sem_release_HttpResponse.r
    mov x0, x25
    bl __fn___sem_release_Body.r
    b .Lssa_http__serialize_response_to_1
.Lssa_http__serialize_response_to_45:
    tst x25, #1
    b.ne .Lssa_http__serialize_response_to_uq45
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_uq45
    ldur w5, [x25, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_http__serialize_response_to_uq45us
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_uq45us:
    cmp w5, #1
.Lssa_http__serialize_response_to_uq45:
    b.ne .Lssa_http__serialize_response_to_105
.Lssa_http__serialize_response_to_104:
    mov x10, x25
    b .Lssa_http__serialize_response_to_106
.Lssa_http__serialize_response_to_105:
    mov x10, #0
.Lssa_http__serialize_response_to_106:
    .loc 2 2417 10
    ldr x26, [x25, #8]
    cmp x10, #0
    b.ne .Lssa_http__serialize_response_to_109
.Lssa_http__serialize_response_to_107:
    tbnz x26, #0, .Lssa_http__serialize_response_to_rcinc348
    cmp x26, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_rcinc348
    ldur w5, [x26, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http__serialize_response_to_rcinc348sl
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_rcinc348sl:
    tbnz w5, #31, .Lssa_http__serialize_response_to_rcinc348
    add w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_http__serialize_response_to_rcinc348:
.Lssa_http__serialize_response_to_109:
    cmp x10, #0
    b.eq .Lssa_http__serialize_response_to_111
.Lssa_http__serialize_response_to_110:
    mov x0, x25
    bl __fn___fern_arr_dec.r
    b .Lssa_http__serialize_response_to_44
.Lssa_http__serialize_response_to_111:
    mov x0, x25
    bl __fn___sem_release_Body.r
.Lssa_http__serialize_response_to_44:
    .loc 2 2418 13
    adrp x25, .SB7
    add x25, x25, :lo12:.SB7
    ldr x0, [x26, #8]
    .loc 14 147 5
    bl __fn_int__int_to_string.r
    mov x27, x0
    .loc 2 2418 13
    mov x0, x25
    mov x9, x27
    bl __fn___fern_str_concat.r
    mov x28, x0
    mov x0, x27
    bl __fn___fern_str_free.r
    adrp x27, .SB8
    add x27, x27, :lo12:.SB8
    str x28, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_http__serialize_response_to_114
.Lssa_http__serialize_response_to_113:
    mov x25, x28
    b .Lssa_http__serialize_response_to_43
.Lssa_http__serialize_response_to_114:
    str x28, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x25, x0
    mov x0, x28
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_115:
.Lssa_http__serialize_response_to_43:
    .loc 2 2420 3
    mov x10, #256
    mov x0, x10
    bl __fern_buf_new
    mov x27, x0
.Lssa_http__serialize_response_to_41:
    adrp x10, .SB9
    add x10, x10, :lo12:.SB9
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push
    sxtw x28, w24
.Lssa_http__serialize_response_to_40:
    cmp x28, #0
    b.ge .Lssa_http__serialize_response_to_37
.Lssa_http__serialize_response_to_39:
    mov x10, #45
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push_byte
    mov x10, #0
    sub x10, x10, x28
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push_decimal
    b .Lssa_http__serialize_response_to_36
.Lssa_http__serialize_response_to_37:
    mov x0, x27
    mov x1, x28
    bl __fern_buf_push_decimal
.Lssa_http__serialize_response_to_36:
    adrp x10, .SB10
    add x10, x10, :lo12:.SB10
    mov x0, x27
    mov x1, x10
    bl __fern_buf_push
.Lssa_http__serialize_response_to_34:
    adrp x10, .K6
    add x10, x10, :lo12:.K6
    adrp x9, .K7
    add x9, x9, :lo12:.K7
.Lssa_http__serialize_response_to_33:
    mov x11, #0
.Lssa_http__serialize_response_to_121:
    ldr x12, [x10, #0]
    cmp x11, x12
    b.ge .Lssa_http__serialize_response_to_32
.Lssa_http__serialize_response_to_124:
    add x5, x11, #1
    ldr x12, [x10, x5, lsl #3]
    cmp x12, x24
    b.eq .Lssa_http__serialize_response_to_31
.Lssa_http__serialize_response_to_122:
    add x11, x11, #1
    b .Lssa_http__serialize_response_to_121
.Lssa_http__serialize_response_to_32:
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    b .Lssa_http__serialize_response_to_30
.Lssa_http__serialize_response_to_31:
    ldr x6, [x9]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x10, [x9, x5, lsl #3]
    tbnz x10, #0, .Lssa_http__serialize_response_to_rcinc401
    cmp x10, #16, lsl #12
    b.lo .Lssa_http__serialize_response_to_rcinc401
    ldur w5, [x10, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_http__serialize_response_to_rcinc401sl
    bl __fern_san_abort_uaf
.Lssa_http__serialize_response_to_rcinc401sl:
    tbnz w5, #31, .Lssa_http__serialize_response_to_rcinc401
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_http__serialize_response_to_rcinc401:
.Lssa_http__serialize_response_to_30:
    ldr x11, [x10, #8]
    cmp x11, #0
    b.ne .Lssa_http__serialize_response_to_28
.Lssa_http__serialize_response_to_136:
    mov x0, x10
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_29:
    adrp x11, .SB61
    add x11, x11, :lo12:.SB61
    mov x28, x11
    b .Lssa_http__serialize_response_to_27
.Lssa_http__serialize_response_to_28:
    mov x28, x10
.Lssa_http__serialize_response_to_27:
    mov x0, x27
    mov x1, x28
    bl __fern_buf_push
    mov x0, x28
    bl __fn___fern_str_free.r
    adrp x11, .SB8
    add x11, x11, :lo12:.SB8
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
.Lssa_http__serialize_response_to_26:
    mov x28, #0
.Lssa_http__serialize_response_to_141:
    ldr x11, [x22, #24]
    ldr x10, [x11, #8]
    ldr x11, [x10, #0]
    cmp x28, x11
    b.lt .Lssa_http__serialize_response_to_147
.Lssa_http__serialize_response_to_149:
    mov x0, x22
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_http__serialize_response_to_24
.Lssa_http__serialize_response_to_147:
    ldr x21, [x22, #24]
    ldr x11, [x21, #8]
    add x5, x28, #1
    ldr x19, [x11, x5, lsl #3]
    adrp x9, .SB62
    add x9, x9, :lo12:.SB62
    mov x0, x19
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http__serialize_response_to_142
.Lssa_http__serialize_response_to_146:
    adrp x9, .SB63
    add x9, x9, :lo12:.SB63
    mov x0, x19
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http__serialize_response_to_142
.Lssa_http__serialize_response_to_145:
    adrp x9, .SB64
    add x9, x9, :lo12:.SB64
    mov x0, x19
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http__serialize_response_to_142
.Lssa_http__serialize_response_to_143:
    ldr x9, [x21, #8]
    add x5, x28, #1
    ldr x11, [x9, x5, lsl #3]
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    adrp x11, .SB65
    add x11, x11, :lo12:.SB65
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    ldr x11, [x21, #16]
    ldr x6, [x11]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x9, [x11, x5, lsl #3]
    mov x0, x27
    mov x1, x9
    bl __fern_buf_push
    adrp x9, .SB8
    add x9, x9, :lo12:.SB8
    mov x0, x27
    mov x1, x9
    bl __fern_buf_push
.Lssa_http__serialize_response_to_142:
    add x28, x28, #1
    b .Lssa_http__serialize_response_to_141
.Lssa_http__serialize_response_to_24:
    mov x0, x27
    mov x1, x25
    bl __fern_buf_push
    mov x0, x25
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_23:
    cmp x24, #101
    b.ne .Lssa_http__serialize_response_to_19
.Lssa_http__serialize_response_to_22:
    adrp x9, .SB66
    add x9, x9, :lo12:.SB66
    mov x0, x27
    mov x1, x9
    bl __fern_buf_push
    b .Lssa_http__serialize_response_to_6
.Lssa_http__serialize_response_to_19:
    ldr x4, [sp, #0]
    cbz x4, .Lssa_http__serialize_response_to_14
.Lssa_http__serialize_response_to_16:
    ldr x9, [x20, #8]
    cmp x9, #8
    b.ne .Lssa_http__serialize_response_to_9
.Lssa_http__serialize_response_to_15:
    ldr x9, [x20, #0]
    ldrb w11, [x9, #7]
    cmp x11, #48
    b.ne .Lssa_http__serialize_response_to_9
    b .Lssa_http__serialize_response_to_11
.Lssa_http__serialize_response_to_14:
    adrp x11, .SB67
    add x11, x11, :lo12:.SB67
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    b .Lssa_http__serialize_response_to_6
.Lssa_http__serialize_response_to_11:
    adrp x11, .SB68
    add x11, x11, :lo12:.SB68
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
    b .Lssa_http__serialize_response_to_6
.Lssa_http__serialize_response_to_9:
    adrp x11, .SB8
    add x11, x11, :lo12:.SB8
    mov x0, x27
    mov x1, x11
    bl __fern_buf_push
.Lssa_http__serialize_response_to_6:
    .loc 2 2422 3
    mov x0, x27
    bl __fern_buf_take
    mov x20, x0
    mov x0, x27
    bl __fern_buf_free
    cbz x23, .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_187:
    mov x0, x26
    bl __fn___fern_str_free.r
    b .Lssa_http__serialize_response_to_4
.Lssa_http__serialize_response_to_5:
    adrp x11, .SB69
    add x11, x11, :lo12:.SB69
    ldr x4, [sp, #8]
    ldr x9, [x4, #8]
    cmp x9, #4
    b.ne .Lssa_http__serialize_response_to_2
.Lssa_http__serialize_response_to_191:
    ldr x4, [sp, #8]
    ldr x6, [x4, #8]
    ldr x7, [x11, #8]
    cmp x6, x7
    b.ne .Lssa_http__serialize_response_to_streqn492
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__serialize_response_to_streqn492
    ldr x0, [sp, #8]
    mov x9, x11
    bl __fn___fern_str_eq.r
    b .Lssa_http__serialize_response_to_streqd492
.Lssa_http__serialize_response_to_streqn492:
    mov x0, #0
.Lssa_http__serialize_response_to_streqd492:
    cbz x0, .Lssa_http__serialize_response_to_2
.Lssa_http__serialize_response_to_194:
    mov x0, x26
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_4:
    .loc 2 2425 5
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__serialize_response_to_2:
    .loc 2 2427 3
    str x20, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_http__serialize_response_to_199
.Lssa_http__serialize_response_to_198:
    mov x27, x20
    b .Lssa_http__serialize_response_to_200
.Lssa_http__serialize_response_to_199:
    str x20, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x27, x0
    mov x0, x20
    bl __fn___fern_str_free.r
.Lssa_http__serialize_response_to_200:
    mov x0, x26
    bl __fn___fern_str_free.r
    mov x0, x27
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__serialize_response_to_1:
    mov x11, #134
    mov x0, x11
    mov x19, x0
    bl __fern_lc_report_exit
    mov x0, x19
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_HttpResponse__body_text_lossy:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_HttpResponse__body_text_lossy.k:
__fn_HttpResponse__body_text_lossy.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_HttpResponse__body_text_lossy_0:
    .loc 2 2725 10 prologue_end
    ldr x9, [x0, #16]
    ldr x10, [x9, #0]
    adrp x11, .S5
    add x11, x11, :lo12:.S5
    cmp x10, x11
    b.ne .Lssa_HttpResponse__body_text_lossy_1
.Lssa_HttpResponse__body_text_lossy_2:
    ldr x0, [x9, #8]
    tbnz x0, #0, .Lssa_HttpResponse__body_text_lossy_rcinc12
    cmp x0, #16, lsl #12
    b.lo .Lssa_HttpResponse__body_text_lossy_rcinc12
    ldur w5, [x0, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_HttpResponse__body_text_lossy_rcinc12sl
    bl __fern_san_abort_uaf
.Lssa_HttpResponse__body_text_lossy_rcinc12sl:
    tbnz w5, #31, .Lssa_HttpResponse__body_text_lossy_rcinc12
    add w5, w5, #1
    stur w5, [x0, #-8]
.Lssa_HttpResponse__body_text_lossy_rcinc12:
    .loc 2 2726 5
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_HttpResponse__body_text_lossy_1:
    mov x9, #134
    mov x0, x9
    mov x19, x0
    bl __fern_lc_report_exit
    mov x0, x19
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____lists_token:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____lists_token.k:
__fn_http____lists_token.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____lists_token_0:
    .loc 2 3234 3 prologue_end
    ldr x21, [x19, #8]
    .loc 2 3233 3
.Lssa_http____lists_token_3:
    mov x9, #0
.Lssa_http____lists_token_4:
    cmp x9, x21
    b.gt .Lssa_http____lists_token_2
.Lssa_http____lists_token_8:
    mov x22, x9
.Lssa_http____lists_token_14:
    cmp x22, x21
    b.ge .Lssa_http____lists_token_7
.Lssa_http____lists_token_16:
    ldr x6, [x19, #8]
    cmp x22, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x22]
    cmp x10, #44
    b.eq .Lssa_http____lists_token_7
.Lssa_http____lists_token_15:
    .loc 2 3238 11
    add x22, x22, #1
    cmp x22, x21
    b.lt .Lssa_http____lists_token_16
.Lssa_http____lists_token_7:
    mov x0, x19
    mov x10, x22
    mov x11, x20
    bl __fn_http____token_at.r
    cbnz x0, .Lssa_http____lists_token_1
.Lssa_http____lists_token_5:
    .loc 2 3243 10
    add x22, x22, #1
    sxtw x9, w22
    cmp x9, x21
    b.le .Lssa_http____lists_token_8
.Lssa_http____lists_token_2:
    .loc 2 3245 3
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____lists_token_1:
    .loc 2 3241 7
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http__fields_ok:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http__fields_ok.k:
__fn_http__fields_ok.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa_http__fields_ok_0:
    .loc 2 3312 3 prologue_end
.Lssa_http__fields_ok_3:
    mov x20, #0
.Lssa_http__fields_ok_4:
    ldr x9, [x19, #8]
    ldr x10, [x9, #0]
    cmp x20, x10
    b.ge .Lssa_http__fields_ok_2
.Lssa_http__fields_ok_13:
    ldr x10, [x19, #8]
    add x5, x20, #1
    ldr x21, [x10, x5, lsl #3]
.Lssa_http__fields_ok_11:
    .loc 2 3274 3
    ldr x10, [x21, #8]
    cmp x10, #0
    b.le .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_10:
    adrp x10, .K8
    add x10, x10, :lo12:.K8
    mov x9, #0
    mov x2, x10
    mov x1, x9
    mov x0, x21
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x1, #0
    b.ge .L41
    mov x1, #0
.L41:
    adrp x9, .S70
    add x9, x9, :lo12:.S70
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L44
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L42:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L43
    add x5, x5, #16
    cmp x5, x8
    b.ls .L42
    sub x1, x5, x0
    b .L44
.L43:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L45
.L44:
    add x10, x9, #96
.L48:
    cmp x1, x3
    b.ge .L46
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L45
    add x1, x1, #1
    b .L48
.L45:
    str x1, [sp, #-16]!
    b .L47
.L46:
    str x3, [sp, #-16]!
.L47:
    ldr x0, [sp], #16
    ldr x9, [x21, #8]
    cmp x0, x9
    b.ne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_7:
    ldr x9, [x19, #16]
    ldr x6, [x9]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, #1
    ldr x21, [x9, x5, lsl #3]
    .loc 2 3323 3
    adrp x9, .K9
    add x9, x9, :lo12:.K9
    mov x10, #0
    mov x2, x9
    mov x1, x10
    mov x0, x21
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x1, #0
    b.ge .L49
    mov x1, #0
.L49:
    adrp x9, .S71
    add x9, x9, :lo12:.S71
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L52
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L50:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L51
    add x5, x5, #16
    cmp x5, x8
    b.ls .L50
    sub x1, x5, x0
    b .L52
.L51:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L53
.L52:
    add x10, x9, #96
.L56:
    cmp x1, x3
    b.ge .L54
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L53
    add x1, x1, #1
    b .L56
.L53:
    str x1, [sp, #-16]!
    b .L55
.L54:
    str x3, [sp, #-16]!
.L55:
    ldr x0, [sp], #16
    ldr x10, [x21, #8]
    cmp x0, x10
    b.ne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_5:
    .loc 2 3317 7
    add x20, x20, #1
    b .Lssa_http__fields_ok_4
.Lssa_http__fields_ok_2:
    .loc 2 3319 3
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__fields_ok_1:
    .loc 2 3315 7
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_fnv_str_seeded:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_fnv_str_seeded.k:
__fn___map_fnv_str_seeded.r:
.Lssa___map_fnv_str_seeded_0:
    .loc 4 157 3 prologue_end
    ldr x10, =2166136261
    mov w9, w9
    eor x10, x10, x9
    .loc 4 158 3
    ldr x9, =16777619
    .loc 4 159 3
    ldr x11, [x0, #8]
    .loc 4 160 3
.Lssa___map_fnv_str_seeded_4:
    mov x12, #0
.Lssa___map_fnv_str_seeded_5:
    add x13, x12, #4
    sxtw x13, w13
    cmp x13, x11
    b.gt .Lssa___map_fnv_str_seeded_13
.Lssa___map_fnv_str_seeded_6:
    .loc 4 162 5
    add x13, x12, #3
    sxtw x13, w13
    asr x14, x12, #31
    orr x13, x13, x14
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x14, [x0, #0]
    add x14, x14, x12
    ldrsw x14, [x14]
    .loc 4 166 7
    eor x14, x10, x14
    .loc 4 158 3
    ldr x13, =16777619
    .loc 4 166 7
    mul w10, w14, w13
    .loc 4 167 7
    add x14, x12, #4
    sxtw x12, w14
    b .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmp x12, x11
    b.ge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    .loc 4 170 7
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
    eor x14, x10, x14
    mul w10, w14, w9
    .loc 4 171 7
    add x12, x12, #1
    cmp x12, x11
    b.lt .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    .loc 4 173 5
    lsr x12, x10, #16
    eor x10, x10, x12
    .loc 4 174 5
    ldr x12, =2246822507
    mul w10, w10, w12
    .loc 4 175 5
    lsr x12, x10, #13
    eor x10, x10, x12
    .loc 4 176 5
    ldr x12, =3266489909
    mul w10, w10, w12
    .loc 4 177 5
    lsr x12, x10, #16
    eor x10, x10, x12
    .loc 4 178 3
    sxtw x0, w10
    ret
    .cfi_endproc
    .ltorg
__fn_string____str_maxsuf:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_maxsuf.k:
__fn_string____str_maxsuf.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_string____str_maxsuf_0:
    .loc 5 194 3 prologue_end
    mov x13, #-1
    .loc 5 195 3
    .loc 5 196 3
    .loc 5 197 3
.Lssa_string____str_maxsuf_2:
    mov x19, x13
    mov x13, #0
    mov x14, #1
    mov x15, #1
.Lssa_string____str_maxsuf_3:
    add x1, x13, x14
    sxtw x1, w1
    cmp x1, x9
    b.ge .Lssa_string____str_maxsuf_1
.Lssa_string____str_maxsuf_16:
    .loc 5 199 5
    add x1, x13, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w2, [x6, x1]
    .loc 5 200 5
    add x1, x19, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w3, [x6, x1]
    cmp x10, #0
    csel x1, x3, x2, ne
    cmp x10, #0
    csel x2, x2, x3, ne
    cmp x1, x2
    b.ge .Lssa_string____str_maxsuf_11
.Lssa_string____str_maxsuf_12:
    .loc 5 207 9
    add x3, x13, x14
    sxtw x3, w3
    .loc 5 209 9
    sub x8, x3, x19
    sxtw x8, w8
    .loc 5 208 9
    mov x13, x3
    mov x15, x8
    mov x14, #1
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_11:
    cmp x1, x2
    b.ne .Lssa_string____str_maxsuf_6
.Lssa_string____str_maxsuf_10:
    cmp x14, x15
    b.ne .Lssa_string____str_maxsuf_8
.Lssa_string____str_maxsuf_9:
    .loc 5 212 11
    add x8, x13, x15
    sxtw x8, w8
    .loc 5 213 11
    mov x13, x8
    mov x14, #1
    b .Lssa_string____str_maxsuf_7
.Lssa_string____str_maxsuf_8:
    .loc 5 215 11
    add x14, x14, #1
    sxtw x14, w14
.Lssa_string____str_maxsuf_7:
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_string____str_maxsuf_5
.Lssa_string____str_maxsuf_6:
    .loc 5 219 9
    add x14, x13, #1
    sxtw x14, w14
    .loc 5 220 9
    .loc 5 221 9
    mov x19, x13
    mov x13, #1
    mov x15, #1
.Lssa_string____str_maxsuf_5:
    mov x4, x14
    mov x14, x13
    mov x13, x4
.Lssa_string____str_maxsuf_4:
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_1:
    mov x1, x15
    .loc 5 224 3
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string____str_two_way:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
    ldr x13, [sp, #80]
    ldr x14, [sp, #96]
    ldr x15, [sp, #112]
__fn_string____str_two_way.k:
__fn_string____str_two_way.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #16
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
    str x12, [sp, #8]
    mov x24, x13
    mov x25, x14
    mov x26, x15
.Lssa_string____str_two_way_0:
.Lssa_string____str_two_way_25:
    cmp x22, #3
    b.ge .Lssa_string____str_two_way_22
.Lssa_string____str_two_way_24:
    .loc 5 229 5 prologue_end
    sub x9, x22, #1
    sxtw x9, w9
    mov x23, x9
    mov x0, #1
    b .Lssa_string____str_two_way_18
.Lssa_string____str_two_way_22:
    .loc 5 231 3
    mov x10, #0
    mov x0, x21
    mov x9, x22
    mov x11, x25
    mov x12, x26
    bl __fn_string____str_maxsuf.r
    mov x27, x0
    mov x28, x1
    .loc 5 232 3
    mov x10, #1
    mov x0, x21
    mov x9, x22
    mov x11, x25
    mov x12, x26
    bl __fn_string____str_maxsuf.r
    mov x23, x0
    mov x0, x1
    cmp x23, x27
    b.ge .Lssa_string____str_two_way_19
.Lssa_string____str_two_way_21:
    .loc 5 234 5
    add x27, x27, #1
    sxtw x27, w27
    mov x23, x27
    mov x0, x28
    b .Lssa_string____str_two_way_18
.Lssa_string____str_two_way_19:
    .loc 5 236 3
    add x23, x23, #1
    sxtw x23, w23
.Lssa_string____str_two_way_18:
    .loc 5 254 3
    sub x20, x20, x22
    sxtw x20, w20
.Lssa_string____str_two_way_17:
    .loc 5 240 3
.Lssa_string____str_two_way_16:
    mov x10, #0
.Lssa_string____str_two_way_36:
    cmp x10, x23
    b.ge .Lssa_string____str_two_way_12
.Lssa_string____str_two_way_39:
    add x9, x0, x10
    mul x9, x26, x9
    add w9, w25, w9
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w11, [x6, x9]
    mul x9, x26, x10
    add w9, w25, w9
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w12, [x6, x9]
    cmp x11, x12
    b.ne .Lssa_string____str_two_way_7
.Lssa_string____str_two_way_37:
    .loc 5 245 7
    add x10, x10, #1
    cmp x10, x23
    b.lt .Lssa_string____str_two_way_39
.Lssa_string____str_two_way_12:
    .loc 5 258 5
.Lssa_string____str_two_way_11:
    .loc 5 276 16
    sub x10, x22, x0
    sxtw x10, w10
    mov x12, #0
.Lssa_string____str_two_way_55:
    ldr x4, [sp, #8]
    cmp x4, x20
    b.gt .Lssa_string____str_two_way_10
.Lssa_string____str_two_way_67:
    cmp x12, x23
    csel x9, x12, x23, gt
.Lssa_string____str_two_way_77:
    cmp x9, x22
    b.ge .Lssa_string____str_two_way_63
.Lssa_string____str_two_way_79:
    mul x11, x26, x9
    add w11, w25, w11
    ldr x6, [x21, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w13, [x6, x11]
    ldr x5, [sp, #8]
    add x11, x9, x5
    mul x11, x26, x11
    add w11, w24, w11
    ldr x6, [x19, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w14, [x6, x11]
    cmp x13, x14
    b.ne .Lssa_string____str_two_way_63
.Lssa_string____str_two_way_78:
    .loc 5 265 11
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_string____str_two_way_79
.Lssa_string____str_two_way_63:
    cmp x9, x22
    b.lt .Lssa_string____str_two_way_57
.Lssa_string____str_two_way_62:
    .loc 5 268 11
    sub x14, x23, #1
    sxtw x14, w14
.Lssa_string____str_two_way_61:
.Lssa_string____str_two_way_94:
    cmp x14, x12
    b.lt .Lssa_string____str_two_way_60
.Lssa_string____str_two_way_96:
    mul x11, x26, x14
    add w11, w25, w11
    ldr x6, [x21, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w13, [x6, x11]
    ldr x5, [sp, #8]
    add x11, x14, x5
    mul x11, x26, x11
    add w11, w24, w11
    ldr x6, [x19, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x11]
    cmp x13, x15
    b.ne .Lssa_string____str_two_way_60
.Lssa_string____str_two_way_95:
    .loc 5 270 13
    sub x15, x14, #1
    sxtw x14, w15
    cmp x14, x12
    b.ge .Lssa_string____str_two_way_96
.Lssa_string____str_two_way_60:
    cmp x14, x12
    b.lt .Lssa_string____str_two_way_9
.Lssa_string____str_two_way_58:
    .loc 5 275 11
    ldr x4, [sp, #8]
    add x14, x4, x0
    sxtw x14, w14
    str x14, [sp, #8]
    mov x12, x10
    b .Lssa_string____str_two_way_55
.Lssa_string____str_two_way_57:
    .loc 5 278 11
    sub x9, x9, x23
    ldr x4, [sp, #8]
    add x9, x4, x9
    add x9, x9, #1
    sxtw x9, w9
    .loc 5 279 16
    str x9, [sp, #8]
    mov x12, #0
.Lssa_string____str_two_way_56:
    ldr x4, [sp, #8]
    cmp x4, x20
    b.le .Lssa_string____str_two_way_67
.Lssa_string____str_two_way_10:
    .loc 5 282 5
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_two_way_9:
    .loc 5 273 11
    ldr x0, [sp, #8]
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_two_way_7:
    sub x12, x22, x23
    sxtw x12, w12
    .loc 5 287 11
    sub x10, x22, x23
    cmp x12, x23
    csel x10, x10, x23, gt
    .loc 5 289 9
    add x10, x10, #1
.Lssa_string____str_two_way_3:
    ldr x0, [sp, #8]
.Lssa_string____str_two_way_119:
    cmp x0, x20
    b.gt .Lssa_string____str_two_way_2
.Lssa_string____str_two_way_128:
    mov x12, x23
.Lssa_string____str_two_way_134:
    cmp x12, x22
    b.ge .Lssa_string____str_two_way_127
.Lssa_string____str_two_way_136:
    mul x9, x26, x12
    add w9, w25, w9
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w14, [x6, x9]
    add x9, x12, x0
    mul x9, x26, x9
    add w9, w24, w9
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x9]
    cmp x14, x15
    b.ne .Lssa_string____str_two_way_127
.Lssa_string____str_two_way_135:
    .loc 5 293 9
    add x12, x12, #1
    cmp x12, x22
    b.lt .Lssa_string____str_two_way_136
.Lssa_string____str_two_way_127:
    cmp x12, x22
    b.lt .Lssa_string____str_two_way_121
.Lssa_string____str_two_way_126:
    .loc 5 296 9
    sub x15, x23, #1
    sxtw x15, w15
.Lssa_string____str_two_way_125:
.Lssa_string____str_two_way_151:
    cmp x15, #0
    b.lt .Lssa_string____str_two_way_124
.Lssa_string____str_two_way_153:
    mul x9, x26, x15
    add w9, w25, w9
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w14, [x6, x9]
    add x9, x15, x0
    mul x9, x26, x9
    add w9, w24, w9
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w11, [x6, x9]
    cmp x14, x11
    b.ne .Lssa_string____str_two_way_124
.Lssa_string____str_two_way_152:
    .loc 5 298 11
    sub x11, x15, #1
    sxtw x15, w11
    cmp x15, #0
    b.ge .Lssa_string____str_two_way_153
.Lssa_string____str_two_way_124:
    cmp x15, #0
    b.lt .Lssa_string____str_two_way_1
.Lssa_string____str_two_way_122:
    .loc 5 303 9
    add x15, x0, x10
    sxtw x15, w15
    mov x0, x15
    b .Lssa_string____str_two_way_119
.Lssa_string____str_two_way_121:
    .loc 5 305 9
    sub x12, x12, x23
    add x12, x0, x12
    add x12, x12, #1
    sxtw x12, w12
    mov x0, x12
.Lssa_string____str_two_way_120:
    cmp x0, x20
    b.le .Lssa_string____str_two_way_128
.Lssa_string____str_two_way_2:
    .loc 5 308 3
    mov x10, #-1
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_two_way_1:
    .loc 5 301 9
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string____str_find_from:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_find_from.k:
__fn_string____str_find_from.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_string____str_find_from_0:
    .loc 5 333 10 prologue_end
    mov x13, #0
    cmp x12, #0
    csel x12, x13, x12, lt
    cmp x11, #0
    b.ne .Lssa_string____str_find_from_14
.Lssa_string____str_find_from_18:
    cmp x12, x9
    csel x13, x9, x12, gt
    mov x0, x13
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_14:
    sub x13, x9, x12
    sxtw x13, w13
    cmp x11, x13
    b.le .Lssa_string____str_find_from_11
.Lssa_string____str_find_from_13:
    .loc 5 342 5
    mov x13, #-1
    mov x0, x13
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_11:
    cmp x11, #1
    b.ne .Lssa_string____str_find_from_8
.Lssa_string____str_find_from_10:
    .loc 5 345 5
    ldr x6, [x10, #8]
    cmp x6, #0
    b.hi 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x10]
    ldrb w13, [x6, #0]
    mov x2, x12
    mov x1, x13
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L57
    mov x2, #0
.L57:
    cmp x1, #255
    b.hi .L62
    cmp x2, x3
    b.ge .L62
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L59
.L58:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L64
    cmp x5, x8
    b.ls .L58
.L59:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L60
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L60
    sub x5, x5, #16
    b .L65
.L64:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L65
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L65:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L63
.L60:
    cmp x5, x6
    b.ge .L62
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L66
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L62
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L62
    add x5, x5, x4
    b .L61
.L66:
    cmp x5, x6
    b.ge .L62
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L61
    add x5, x5, #1
    b .L66
.L61:
    sub x2, x5, x0
    b .L63
.L62:
    mov x2, #-1
.L63:
    mov x14, x2
    mov x0, x14
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_8:
    cmp x11, #4
    b.gt .Lssa_string____str_find_from_3
.Lssa_string____str_find_from_6:
    sub x14, x9, x11
    sxtw x14, w14
.Lssa_string____str_find_from_47:
    cmp x12, x14
    b.gt .Lssa_string____str_find_from_5
.Lssa_string____str_find_from_52:
    .loc 5 318 5
.Lssa_string____str_find_from_51:
    mov x13, #0
.Lssa_string____str_find_from_57:
    cmp x13, x11
    b.ge .Lssa_string____str_find_from_50
.Lssa_string____str_find_from_59:
    add w15, w12, w13
    ldr x6, [x0, #8]
    cmp x15, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w1, [x6, x15]
    ldr x6, [x10, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x10]
    ldrb w15, [x6, x13]
    cmp x1, x15
    b.ne .Lssa_string____str_find_from_50
.Lssa_string____str_find_from_58:
    .loc 5 320 9
    add x13, x13, #1
    cmp x13, x11
    b.lt .Lssa_string____str_find_from_59
.Lssa_string____str_find_from_50:
    cmp x13, x11
    b.eq .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_48:
    .loc 5 325 7
    add x13, x12, #1
    sxtw x12, w13
    cmp x12, x14
    b.le .Lssa_string____str_find_from_52
.Lssa_string____str_find_from_5:
    .loc 5 327 3
    mov x13, #-1
    mov x12, x13
    b .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_3:
    .loc 5 350 3
    mov x13, #0
    mov x14, #0
    mov x15, #1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn_string____str_two_way.r
    .cfi_restore_state
.Lssa_string____str_find_from_2:
.Lssa_string____str_find_from_1:
    .loc 5 348 5
    mov x0, x12
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__split.k:
__fn_string__split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #144
    mov x19, x0
    mov x20, x9
.Lssa_string__split_0:
    .loc 5 1682 3 prologue_end
    ldr x21, [x19, #8]
    .loc 5 1683 3
    ldr x22, [x20, #8]
    .loc 5 1684 3
    adrp x23, .K0
    add x23, x23, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa_string__split_3
.Lssa_string__split_7:
    .loc 5 2386 3
    ldr x24, [x19, #8]
    .loc 5 2387 3
    adrp x0, .K0
    add x0, x0, :lo12:.K0
    .loc 5 2388 3
.Lssa_string__split_6:
    mov x25, x0
    mov x26, #0
.Lssa_string__split_13:
    cmp x26, x24
    b.ge .Lssa_string__split_5
.Lssa_string__split_14:
    .loc 5 2390 5
    mov x0, x19
    mov x9, x26
    mov x10, x24
    bl __fn_utf8_scalar__step.r
    .loc 5 2391 9
    add x0, x26, x0
    sxtw x27, w0
    mov x0, x19
    mov x1, x26
    mov x2, x27
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x28, x0
    adrp x9, .SB6
    add x9, x9, :lo12:.SB6
    mov x0, x28
    bl __fn___fern_str_concat.r
    mov x26, x0
    str x28, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x25
    mov x1, x26
    bl __fern_arr_push_owned
    mov x25, x0
    mov x26, x27
    cmp x26, x24
    b.lt .Lssa_string__split_14
.Lssa_string__split_5:
    mov x0, x25
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string__split_3:
    .loc 5 1688 3
    mov x12, #0
    .loc 5 1689 3
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    bl __fn_string____str_find_from.r
    .loc 5 1688 3
.Lssa_string__split_2:
    mov x25, x0
    mov x12, #0
.Lssa_string__split_21:
    cmp x25, #0
    b.lt .Lssa_string__split_1
.Lssa_string__split_22:
    .loc 5 1691 9
    mov x0, x19
    mov x1, x12
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x9, .SB6
    add x9, x9, :lo12:.SB6
    mov x0, x26
    bl __fn___fern_str_concat.r
    mov x27, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x27
    str x12, [sp, #64]
    bl __fern_arr_push_owned
    ldr x12, [sp, #64]
    mov x23, x0
    .loc 5 1692 11
    add x25, x25, x22
    sxtw x25, w25
    .loc 5 1693 9
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    mov x12, x25
    bl __fn_string____str_find_from.r
    mov x12, x25
    mov x25, x0
    cmp x25, #0
    b.ge .Lssa_string__split_22
.Lssa_string__split_1:
    .loc 5 1695 3
    mov x0, x19
    mov x1, x12
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x25, x0
    adrp x12, .SB6
    add x12, x12, :lo12:.SB6
    mov x0, x25
    mov x9, x12
    bl __fn___fern_str_concat.r
    mov x21, x0
    str x25, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x21
    bl __fern_arr_push_owned
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__eq_ignore_ascii_case:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__eq_ignore_ascii_case.k:
__fn_string__eq_ignore_ascii_case.r:
.Lssa_string__eq_ignore_ascii_case_0:
    .loc 5 1952 3 prologue_end
    ldr x10, [x0, #8]
    ldr x11, [x9, #8]
    cmp x10, x11
    b.eq .Lssa_string__eq_ignore_ascii_case_4
.Lssa_string__eq_ignore_ascii_case_6:
    .loc 5 1954 5
    mov x0, #0
    ret
.Lssa_string__eq_ignore_ascii_case_4:
.Lssa_string__eq_ignore_ascii_case_3:
    mov x11, #0
.Lssa_string__eq_ignore_ascii_case_11:
    cmp x11, x10
    b.ge .Lssa_string__eq_ignore_ascii_case_2
.Lssa_string__eq_ignore_ascii_case_17:
    .loc 5 1957 5
    ldr x12, [x0, #0]
    ldrb w13, [x12, x11]
    .loc 5 1958 5
    ldr x6, [x9, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x9]
    ldrb w12, [x6, x11]
    eor x12, x13, x12
    cmp x12, #0
    b.eq .Lssa_string__eq_ignore_ascii_case_12
.Lssa_string__eq_ignore_ascii_case_16:
    cmp x12, #32
    b.ne .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_15:
    mov x12, #32
    orr x12, x13, x12
    cmp x12, #97
    b.lt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_14:
    mov x12, #32
    orr x13, x13, x12
    cmp x13, #122
    b.gt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_12:
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_string__eq_ignore_ascii_case_17
.Lssa_string__eq_ignore_ascii_case_2:
    .loc 5 1963 3
    mov x0, #1
    ret
.Lssa_string__eq_ignore_ascii_case_1:
    .loc 5 1960 7
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn_io_buffered__BufBlock__drop:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_io_buffered__BufBlock__drop.k:
__fn_io_buffered__BufBlock__drop.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_io_buffered__BufBlock__drop_0:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fern_buf_free
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_json__JsonError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_json__JsonError__eq.k:
__fn_json__JsonError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_json__JsonError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_json__JsonError__eq_streqn22
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_json__JsonError__eq_streqd22
.Lssa_json__JsonError__eq_streqn22:
    mov x0, #0
.Lssa_json__JsonError__eq_streqd22:
    cbz x0, .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_9:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_6:
    ldr x9, [x19, #24]
    ldr x10, [x20, #24]
    cmp x9, x10
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_3:
    ldr x10, [x19, #32]
    ldr x9, [x20, #32]
    cmp x10, x9
    cset x0, eq
    b .Lssa_json__JsonError__eq_1
.Lssa_json__JsonError__eq_2:
    mov x0, #0
.Lssa_json__JsonError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8__is_valid:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_utf8__is_valid.k:
__fn_utf8__is_valid.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa_utf8__is_valid_0:
.Lssa_utf8__is_valid_21:
    .loc 13 155 3 prologue_end
    ldr x20, [x19, #8]
    .loc 13 156 3
.Lssa_utf8__is_valid_20:
    mov x21, #0
.Lssa_utf8__is_valid_22:
    cmp x21, x20
    b.ge .Lssa_utf8__is_valid_19
.Lssa_utf8__is_valid_70:
    .loc 13 158 5
    ldr x6, [x19, #8]
    cmp x21, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w22, [x6, x21]
    cmp x22, #128
    b.ge .Lssa_utf8__is_valid_65
.Lssa_utf8__is_valid_69:
    .loc 13 160 9
    mov x2, x21
    mov x0, x19
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L67
    mov x2, #0
.L67:
    cmp x2, x3
    b.ge .L72
    add x5, x0, x2
    add x6, x0, x3
.L68:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L70
    ld1 {v0.16b}, [x5]
    cmlt v0.16b, v0.16b, #0
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L69
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L73
.L69:
    add x5, x5, #16
    b .L68
.L70:
    cmp x5, x6
    b.ge .L72
    ldrb w4, [x5]
    tbnz w4, #7, .L71
    add x5, x5, #1
    b .L70
.L71:
    sub x2, x5, x0
    b .L73
.L72:
    mov x2, x3
.L73:
    mov x0, x2
    cmp x0, x20
    b.ge .Lssa_utf8__is_valid_18
.Lssa_utf8__is_valid_67:
    .loc 13 164 10
    ldr x6, [x19, #8]
    cmp x0, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w9, [x6, x0]
    mov x21, x0
    mov x22, x9
.Lssa_utf8__is_valid_66:
.Lssa_utf8__is_valid_65:
    cmp x22, #192
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_64:
    cmp x22, #224
    b.ge .Lssa_utf8__is_valid_55
.Lssa_utf8__is_valid_63:
    add x9, x21, #1
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_61:
    .loc 13 172 7
    add w9, w21, #1
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_60:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_58:
    sub x9, x22, #192
    lsl x9, x9, #6
    sxtw x9, w9
    sub x10, x10, #128
    sxtw x10, w10
    orr x9, x9, x10
    cmp x9, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_56:
    .loc 13 179 9
    add x9, x21, #2
    sxtw x9, w9
    mov x21, x9
    b .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_55:
    cmp x22, #240
    b.ge .Lssa_utf8__is_valid_40
.Lssa_utf8__is_valid_54:
    add x9, x21, #2
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_52:
    .loc 13 184 7
    add x9, x21, #1
    sxtw x9, w9
    add x10, x9, #1
    sxtw x10, w10
    asr x11, x9, #31
    orr x10, x10, x11
    ldr x6, [x19, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x11, [x19, #0]
    ldrb w10, [x11, x9]
    .loc 13 185 7
    add x9, x21, #2
    sxtw x9, w9
    ldrb w12, [x11, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_51:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_49:
    cmp x12, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_48:
    cmp x12, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_46:
    .loc 13 192 7
    sub x9, x22, #224
    lsl x9, x9, #12
    sxtw x9, w9
    sub x10, x10, #128
    lsl x10, x10, #6
    sxtw x10, w10
    orr x9, x9, x10
    sub x12, x12, #128
    sxtw x12, w12
    orr x9, x9, x12
    cmp x9, #2048
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_44:
    mov x12, #55296
    cmp x9, x12
    b.lt .Lssa_utf8__is_valid_41
.Lssa_utf8__is_valid_43:
    mov x12, #57343
    cmp x9, x12
    b.le .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_41:
    .loc 13 199 9
    add x12, x21, #3
    sxtw x12, w12
    mov x21, x12
    b .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_40:
    cmp x22, #248
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_39:
    add x12, x21, #3
    sxtw x12, w12
    cmp x12, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_37:
    .loc 13 204 7
    add x12, x21, #1
    sxtw x12, w12
    add x9, x12, #2
    sxtw x9, w9
    asr x10, x12, #31
    orr x9, x9, x10
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x10, [x19, #0]
    ldrb w9, [x10, x12]
    .loc 13 205 7
    add x12, x21, #2
    sxtw x12, w12
    ldrb w11, [x10, x12]
    .loc 13 206 7
    add x12, x21, #3
    sxtw x12, w12
    ldrb w13, [x10, x12]
    cmp x9, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_36:
    cmp x9, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_34:
    cmp x11, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_33:
    cmp x11, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_31:
    cmp x13, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_30:
    cmp x13, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_28:
    .loc 13 216 7
    sub x22, x22, #240
    lsl x22, x22, #18
    sxtw x22, w22
    sub x9, x9, #128
    lsl x9, x9, #12
    sxtw x9, w9
    orr x22, x22, x9
    sub x11, x11, #128
    lsl x11, x11, #6
    sxtw x11, w11
    orr x22, x22, x11
    sub x13, x13, #128
    sxtw x13, w13
    orr x22, x22, x13
    movz x13, #1, lsl #16
    cmp x22, x13
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_26:
    movn w13, #65519, lsl #16
    cmp x22, x13
    b.gt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_24:
    .loc 13 223 9
    add x13, x21, #4
    sxtw x13, w13
    mov x21, x13
.Lssa_utf8__is_valid_23:
    cmp x21, x20
    b.lt .Lssa_utf8__is_valid_70
.Lssa_utf8__is_valid_19:
    mov x21, x20
    b .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_18:
    mov x21, x20
.Lssa_utf8__is_valid_17:
.Lssa_utf8__is_valid_16:
.Lssa_utf8__is_valid_15:
.Lssa_utf8__is_valid_14:
.Lssa_utf8__is_valid_13:
.Lssa_utf8__is_valid_12:
.Lssa_utf8__is_valid_11:
.Lssa_utf8__is_valid_10:
.Lssa_utf8__is_valid_9:
.Lssa_utf8__is_valid_8:
.Lssa_utf8__is_valid_7:
.Lssa_utf8__is_valid_6:
.Lssa_utf8__is_valid_5:
.Lssa_utf8__is_valid_4:
.Lssa_utf8__is_valid_3:
.Lssa_utf8__is_valid_2:
.Lssa_utf8__is_valid_1:
    .loc 13 149 3
    ldr x13, [x19, #8]
    cmp x21, x13
    cset x0, eq
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___primitive_i32_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_i32_to_string.k:
__fn___primitive_i32_to_string.r:
.Lssa___primitive_i32_to_string_0:
    .loc 15 55 3 prologue_end
    b __fn_int__int_to_string.r
    .cfi_endproc
    .ltorg
__fn___primitive_i64_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_i64_to_string.k:
__fn___primitive_i64_to_string.r:
.Lssa___primitive_i64_to_string_0:
    cmp x0, #0
    b.ge .Lssa___primitive_i64_to_string_1
.Lssa___primitive_i64_to_string_3:
    .loc 15 74 5 prologue_end
    mov x9, #0
    sub x9, x9, x0
    mov x10, #1
    mov x0, x9
    mov x9, x10
    b __fn_int____int_to_string_u64.r
.Lssa___primitive_i64_to_string_1:
    .loc 15 76 3
    mov x9, #0
    b __fn_int____int_to_string_u64.r
    .cfi_endproc
    .ltorg
__fn_int__int_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_int__int_to_string.k:
__fn_int__int_to_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
.Lssa_int__int_to_string_0:
    cmp x0, #0
    b.lt .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_47:
    cmp x0, #100
    b.ge .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_46:
    .loc 17 104 5 prologue_end
    adrp x9, .K10
    add x9, x9, :lo12:.K10
    ldr x6, [x9]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x0, #1
    ldr x10, [x9, x5, lsl #3]
    tbnz x10, #0, .Lssa_int__int_to_string_rcinc220
    cmp x10, #16, lsl #12
    b.lo .Lssa_int__int_to_string_rcinc220
    ldur w5, [x10, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_int__int_to_string_rcinc220sl
    bl __fern_san_abort_uaf
.Lssa_int__int_to_string_rcinc220sl:
    tbnz w5, #31, .Lssa_int__int_to_string_rcinc220
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_int__int_to_string_rcinc220:
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_int__int_to_string_44:
    .loc 17 106 3
    mov x10, #0
    .loc 17 109 7
    mov x9, #0
    sub x9, x9, x0
    .loc 17 108 9
    mov x11, #1
    cmp x0, #0
    csel x9, x9, x0, lt
    csel x19, x11, x10, lt
    .loc 17 111 3
    mov w20, w9
.Lssa_int__int_to_string_40:
    cmp x20, #10
    b.hs .Lssa_int__int_to_string_37
.Lssa_int__int_to_string_39:
    .loc 17 68 5
    mov x9, #1
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_37:
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_34
.Lssa_int__int_to_string_36:
    .loc 17 71 5
    mov x9, #2
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_34:
    cmp x20, #1000
    b.hs .Lssa_int__int_to_string_31
.Lssa_int__int_to_string_33:
    .loc 17 74 5
    mov x9, #3
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_31:
    mov x9, #10000
    cmp x20, x9
    b.hs .Lssa_int__int_to_string_28
.Lssa_int__int_to_string_30:
    .loc 17 77 5
    mov x9, #4
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_28:
    ldr x9, =100000
    cmp x20, x9
    b.hs .Lssa_int__int_to_string_25
.Lssa_int__int_to_string_27:
    .loc 17 80 5
    mov x9, #5
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_25:
    ldr x9, =1000000
    cmp x20, x9
    b.hs .Lssa_int__int_to_string_22
.Lssa_int__int_to_string_24:
    .loc 17 83 5
    mov x9, #6
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_22:
    ldr x9, =10000000
    cmp x20, x9
    b.hs .Lssa_int__int_to_string_19
.Lssa_int__int_to_string_21:
    .loc 17 86 5
    mov x9, #7
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_19:
    ldr x9, =100000000
    cmp x20, x9
    b.hs .Lssa_int__int_to_string_16
.Lssa_int__int_to_string_18:
    .loc 17 89 5
    mov x9, #8
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_16:
    ldr x9, =1000000000
    cmp x20, x9
    b.hs .Lssa_int__int_to_string_13
.Lssa_int__int_to_string_15:
    .loc 17 92 5
    mov x9, #9
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_13:
    .loc 17 94 3
    mov x9, #10
.Lssa_int__int_to_string_12:
    .loc 17 115 11
    add x11, x9, #1
    sxtw x11, w11
    cmp x19, #0
    csel x21, x11, x9, ne
    .loc 17 117 3
    mov x0, x21
    bl __fern_alloc_bytes
    mov x22, x0
    .loc 17 63 3
    adrp x11, .SB172
    add x11, x11, :lo12:.SB172
.Lssa_int__int_to_string_8:
.Lssa_int__int_to_string_111:
    .loc 17 127 3
    cmp x20, #100
    b.lo .Lssa_int__int_to_string_7
.Lssa_int__int_to_string_112:
    .loc 17 121 5
    mov x4, x20
    ldr x5, =184467440737095517
    umulh x5, x4, x5
    mov x4, x5
    mov x9, x4
    mov x10, #100
    mul x10, x9, x10
    sub x10, x20, x10
    .loc 17 123 7
    sub x12, x21, #2
    sxtw x21, w12
    lsl x10, x10, #1
    .loc 17 124 9
    sxtw x10, w10
    ldr x6, [x11, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w12, [x5, #8]
    .loc 17 125 9
    add w13, w21, #1
    add w10, w10, #1
    ldr x6, [x11, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x13, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    strb w12, [x5, #8]
    mov x20, x9
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_112
.Lssa_int__int_to_string_7:
    cmp x20, #10
    b.lo .Lssa_int__int_to_string_5
.Lssa_int__int_to_string_6:
    .loc 17 129 7
    sub x10, x21, #2
    sxtw x10, w10
    lsl x12, x20, #1
    .loc 17 130 9
    sxtw x12, w12
    ldr x6, [x11, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w13, [x6, x12]
    ldr x7, [x22]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    strb w13, [x5, #8]
    .loc 17 131 9
    add w10, w10, #1
    add w12, w12, #1
    ldr x6, [x11, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x11]
    ldrb w9, [x6, x12]
    ldr x7, [x22]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    strb w9, [x5, #8]
    b .Lssa_int__int_to_string_4
.Lssa_int__int_to_string_5:
    .loc 17 133 7
    sub w21, w21, #1
    .loc 17 134 9
    add x20, x20, #48
    and x20, x20, #255
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w20, [x5, #8]
.Lssa_int__int_to_string_4:
    cbz x19, .Lssa_int__int_to_string_1
.Lssa_int__int_to_string_3:
    .loc 17 137 9
    mov x12, #45
    ldr x6, [x22, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    strb w12, [x22, #8]
.Lssa_int__int_to_string_1:
    .loc 17 140 5
    mov x0, x22
    bl __fn___fern_string_from_bytes_u8.r
    mov x20, x0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_int____int_to_string_u64:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_int____int_to_string_u64.k:
__fn_int____int_to_string_u64.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_int____int_to_string_u64_0:
    .loc 17 146 3 prologue_end
.Lssa_int____int_to_string_u64_16:
    mov x10, x19
    mov x9, #1
.Lssa_int____int_to_string_u64_17:
    cmp x10, #100
    b.lo .Lssa_int____int_to_string_u64_15
.Lssa_int____int_to_string_u64_18:
    .loc 17 149 10
    add x11, x9, #2
    sxtw x9, w11
    .loc 17 150 11
    mov x4, x10
    ldr x5, =2951479051793528259
    lsr x6, x4, #2
    umulh x5, x6, x5
    lsr x5, x5, #2
    mov x4, x5
    mov x10, x4
    cmp x10, #100
    b.hs .Lssa_int____int_to_string_u64_18
.Lssa_int____int_to_string_u64_15:
    .loc 17 153 10
    add x11, x9, #1
    sxtw x11, w11
    cmp x10, #10
    csel x11, x11, x9, hs
    .loc 17 157 11
    add x9, x11, #1
    sxtw x9, w9
    cmp x20, #0
    csel x21, x9, x11, ne
    .loc 17 159 3
    mov x0, x21
    bl __fern_alloc_bytes
    mov x22, x0
    .loc 17 63 3
    adrp x9, .SB172
    add x9, x9, :lo12:.SB172
.Lssa_int____int_to_string_u64_8:
.Lssa_int____int_to_string_u64_35:
    .loc 17 169 3
    cmp x19, #100
    b.lo .Lssa_int____int_to_string_u64_7
.Lssa_int____int_to_string_u64_36:
    .loc 17 163 5
    mov x4, x19
    ldr x5, =2951479051793528259
    lsr x6, x4, #2
    umulh x5, x6, x5
    lsr x5, x5, #2
    mov x4, x5
    mov x11, x4
    mov x10, #100
    mul x10, x11, x10
    sub x10, x19, x10
    .loc 17 165 7
    sub x12, x21, #2
    sxtw x21, w12
    lsl x10, x10, #1
    .loc 17 166 9
    sxtw x10, w10
    ldr x6, [x9, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w12, [x5, #8]
    .loc 17 167 9
    add w13, w21, #1
    add w10, w10, #1
    ldr x6, [x9, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x13, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    strb w12, [x5, #8]
    mov x19, x11
    cmp x19, #100
    b.hs .Lssa_int____int_to_string_u64_36
.Lssa_int____int_to_string_u64_7:
    cmp x19, #10
    b.lo .Lssa_int____int_to_string_u64_5
.Lssa_int____int_to_string_u64_6:
    .loc 17 171 7
    sub x10, x21, #2
    sxtw x10, w10
    lsl x12, x19, #1
    .loc 17 172 9
    sxtw x12, w12
    ldr x6, [x9, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w13, [x6, x12]
    ldr x7, [x22]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    strb w13, [x5, #8]
    .loc 17 173 9
    add w10, w10, #1
    add w12, w12, #1
    ldr x6, [x9, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w11, [x6, x12]
    ldr x7, [x22]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    strb w11, [x5, #8]
    b .Lssa_int____int_to_string_u64_4
.Lssa_int____int_to_string_u64_5:
    .loc 17 175 7
    sub w21, w21, #1
    .loc 17 176 9
    add x19, x19, #48
    and x19, x19, #255
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w19, [x5, #8]
.Lssa_int____int_to_string_u64_4:
    cmp x20, #0
    b.eq .Lssa_int____int_to_string_u64_1
.Lssa_int____int_to_string_u64_3:
    .loc 17 179 9
    mov x12, #45
    ldr x6, [x22, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    strb w12, [x22, #8]
.Lssa_int____int_to_string_u64_1:
    .loc 17 182 5
    mov x0, x22
    bl __fn___fern_string_from_bytes_u8.r
    mov x19, x0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8_scalar__step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_utf8_scalar__step.k:
__fn_utf8_scalar__step.r:
.Lssa_utf8_scalar__step_0:
    .loc 20 201 3 prologue_end
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x9]
.Lssa_utf8_scalar__step_47:
    cmp x11, #128
    b.ge .Lssa_utf8_scalar__step_44
.Lssa_utf8_scalar__step_46:
    .loc 20 163 5
    mov x12, #1
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_44:
    cmp x11, #194
    b.ge .Lssa_utf8_scalar__step_41
.Lssa_utf8_scalar__step_43:
    .loc 20 166 5
    mov x12, #0
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_41:
    cmp x11, #224
    b.ge .Lssa_utf8_scalar__step_38
.Lssa_utf8_scalar__step_40:
    .loc 20 169 5
    mov x12, #2
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_38:
    cmp x11, #240
    b.ge .Lssa_utf8_scalar__step_35
.Lssa_utf8_scalar__step_37:
    .loc 20 172 5
    mov x12, #3
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_35:
    cmp x11, #245
    b.ge .Lssa_utf8_scalar__step_32
.Lssa_utf8_scalar__step_34:
    .loc 20 175 5
    mov x12, #4
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_32:
    .loc 20 177 3
    mov x12, #0
.Lssa_utf8_scalar__step_31:
    cmp x12, #1
    b.gt .Lssa_utf8_scalar__step_28
.Lssa_utf8_scalar__step_30:
    .loc 20 204 5
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_28:
    add x13, x9, #1
    sxtw x13, w13
    cmp x13, x10
    b.lt .Lssa_utf8_scalar__step_25
.Lssa_utf8_scalar__step_27:
    .loc 20 207 5
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_25:
    .loc 20 209 3
    add w13, w9, #1
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x13]
.Lssa_utf8_scalar__step_24:
    cmp x11, #224
    b.ne .Lssa_utf8_scalar__step_21
.Lssa_utf8_scalar__step_23:
    .loc 20 182 5
    mov x13, #160
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_21:
    cmp x11, #240
    b.ne .Lssa_utf8_scalar__step_18
.Lssa_utf8_scalar__step_20:
    .loc 20 185 5
    mov x13, #144
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_18:
    .loc 20 187 3
    mov x13, #128
.Lssa_utf8_scalar__step_17:
    cmp x14, x13
    b.lt .Lssa_utf8_scalar__step_7
.Lssa_utf8_scalar__step_15:
    cmp x11, #237
    b.ne .Lssa_utf8_scalar__step_12
.Lssa_utf8_scalar__step_14:
    .loc 20 192 5
    mov x13, #159
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_12:
    cmp x11, #244
    b.ne .Lssa_utf8_scalar__step_9
.Lssa_utf8_scalar__step_11:
    .loc 20 195 5
    mov x13, #143
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_9:
    .loc 20 197 3
    mov x13, #191
.Lssa_utf8_scalar__step_8:
    cmp x14, x13
    b.le .Lssa_utf8_scalar__step_5
.Lssa_utf8_scalar__step_7:
    .loc 20 211 5
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_5:
    .loc 20 213 3
.Lssa_utf8_scalar__step_4:
    mov x13, #2
.Lssa_utf8_scalar__step_109:
    cmp x13, x12
    b.ge .Lssa_utf8_scalar__step_3
.Lssa_utf8_scalar__step_118:
    add x14, x9, x13
    sxtw x14, w14
    cmp x14, x10
    b.ge .Lssa_utf8_scalar__step_2
.Lssa_utf8_scalar__step_116:
    add w14, w9, w13
    ldr x6, [x0, #8]
    cmp x14, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x14]
.Lssa_utf8_scalar__step_115:
    .loc 20 158 3
    cmp x11, #128
    b.lt .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_114:
    cmp x11, #192
    b.ge .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_110:
    .loc 20 221 7
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa_utf8_scalar__step_118
.Lssa_utf8_scalar__step_3:
    .loc 20 223 3
    mov x0, x12
    ret
.Lssa_utf8_scalar__step_2:
    .loc 20 216 7
    mov x0, x13
    ret
.Lssa_utf8_scalar__step_1:
    .loc 20 219 7
    mov x0, x13
    ret
    .cfi_endproc
    .ltorg
__fn_deflate____ReadPhase__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_deflate____ReadPhase__eq.k:
__fn_deflate____ReadPhase__eq.r:
.Lssa_deflate____ReadPhase__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S173
    add x11, x11, :lo12:.S173
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_20
.Lssa_deflate____ReadPhase__eq_24:
    ldr x11, [x9, #0]
    adrp x12, .S173
    add x12, x12, :lo12:.S173
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_20:
    adrp x14, .S174
    add x14, x14, :lo12:.S174
    cmp x10, x14
    b.ne .Lssa_deflate____ReadPhase__eq_15
.Lssa_deflate____ReadPhase__eq_19:
    ldr x14, [x9, #0]
    adrp x13, .S174
    add x13, x13, :lo12:.S174
    mov x12, #1
    mov x11, #0
    cmp x14, x13
    csel x0, x12, x11, eq
    ret
.Lssa_deflate____ReadPhase__eq_15:
    adrp x11, .S175
    add x11, x11, :lo12:.S175
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_10
.Lssa_deflate____ReadPhase__eq_14:
    ldr x11, [x9, #0]
    adrp x12, .S175
    add x12, x12, :lo12:.S175
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_10:
    adrp x14, .S176
    add x14, x14, :lo12:.S176
    cmp x10, x14
    b.ne .Lssa_deflate____ReadPhase__eq_4
.Lssa_deflate____ReadPhase__eq_9:
    ldr x14, [x9, #0]
    adrp x10, .S176
    add x10, x10, :lo12:.S176
    mov x13, #1
    mov x12, #0
    cmp x14, x10
    csel x0, x13, x12, eq
    ret
.Lssa_deflate____ReadPhase__eq_4:
    ldr x12, [x9, #0]
    adrp x9, .S177
    add x9, x9, :lo12:.S177
    mov x13, #1
    mov x10, #0
    cmp x12, x9
    csel x0, x13, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeErrorKind__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeErrorKind__eq.k:
__fn_codec__DecodeErrorKind__eq.r:
.Lssa_codec__DecodeErrorKind__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S178
    add x11, x11, :lo12:.S178
    cmp x10, x11
    b.ne .Lssa_codec__DecodeErrorKind__eq_15
.Lssa_codec__DecodeErrorKind__eq_19:
    ldr x11, [x0, #8]
    ldr x12, [x9, #0]
    adrp x13, .S178
    add x13, x13, :lo12:.S178
    cmp x12, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_16
.Lssa_codec__DecodeErrorKind__eq_18:
    ldr x13, [x9, #8]
    cmp x11, x13
    cset x0, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_16:
    mov x0, #0
    ret
.Lssa_codec__DecodeErrorKind__eq_15:
    adrp x13, .S179
    add x13, x13, :lo12:.S179
    cmp x10, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_10
.Lssa_codec__DecodeErrorKind__eq_14:
    ldr x13, [x9, #0]
    adrp x11, .S179
    add x11, x11, :lo12:.S179
    mov x12, #1
    mov x14, #0
    cmp x13, x11
    csel x0, x12, x14, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_10:
    adrp x14, .S180
    add x14, x14, :lo12:.S180
    cmp x10, x14
    b.ne .Lssa_codec__DecodeErrorKind__eq_4
.Lssa_codec__DecodeErrorKind__eq_9:
    ldr x14, [x9, #0]
    adrp x10, .S180
    add x10, x10, :lo12:.S180
    mov x12, #1
    mov x11, #0
    cmp x14, x10
    csel x0, x12, x11, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_4:
    ldr x11, [x9, #0]
    adrp x9, .S181
    add x9, x9, :lo12:.S181
    mov x12, #1
    mov x10, #0
    cmp x11, x9
    csel x0, x12, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeError__eq.k:
__fn_codec__DecodeError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_codec__DecodeError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_codec__DecodeError__eq_streqn36
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_codec__DecodeError__eq_streqd36
.Lssa_codec__DecodeError__eq_streqn36:
    mov x0, #0
.Lssa_codec__DecodeError__eq_streqd36:
    cbz x0, .Lssa_codec__DecodeError__eq_19
.Lssa_codec__DecodeError__eq_26:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_codec__DecodeError__eq_19
.Lssa_codec__DecodeError__eq_23:
    ldr x9, [x19, #24]
    ldr x10, [x20, #24]
.Lssa_codec__DecodeError__eq_22:
    ldr x11, [x9, #0]
    adrp x12, .S178
    add x12, x12, :lo12:.S178
    cmp x11, x12
    b.ne .Lssa_codec__DecodeError__eq_16
.Lssa_codec__DecodeError__eq_21:
    ldr x12, [x9, #8]
    ldr x9, [x10, #0]
    adrp x13, .S178
    add x13, x13, :lo12:.S178
    cmp x9, x13
    b.ne .Lssa_codec__DecodeError__eq_17
.Lssa_codec__DecodeError__eq_20:
    ldr x13, [x10, #8]
    cmp x12, x13
    cset x0, eq
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_19:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_17:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_16:
    adrp x13, .S179
    add x13, x13, :lo12:.S179
    cmp x11, x13
    b.ne .Lssa_codec__DecodeError__eq_11
.Lssa_codec__DecodeError__eq_15:
    ldr x13, [x10, #0]
    adrp x12, .S179
    add x12, x12, :lo12:.S179
    cmp x13, x12
    b.ne .Lssa_codec__DecodeError__eq_12
.Lssa_codec__DecodeError__eq_14:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_12:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_11:
    adrp x12, .S180
    add x12, x12, :lo12:.S180
    cmp x11, x12
    b.ne .Lssa_codec__DecodeError__eq_5
.Lssa_codec__DecodeError__eq_10:
    ldr x12, [x10, #0]
    adrp x11, .S180
    add x11, x11, :lo12:.S180
    cmp x12, x11
    b.ne .Lssa_codec__DecodeError__eq_7
.Lssa_codec__DecodeError__eq_9:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_7:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_5:
    ldr x11, [x10, #0]
    adrp x10, .S181
    add x10, x10, :lo12:.S181
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_2
.Lssa_codec__DecodeError__eq_4:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_2:
    mov x0, #0
.Lssa_codec__DecodeError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_main:
    .cfi_startproc
__fn_main.k:
__fn_main.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #160
.Lssa_main_0:
    .loc 1 4 3 prologue_end
    adrp x4, .SB182
    add x4, x4, :lo12:.SB182
    str x4, [sp, #152]
    .loc 1 5 3
.Lssa_main_41:
    stp xzr, xzr, [sp, #136]
.Lssa_main_42:
    ldr x4, [sp, #136]
    cmp x4, #4000
    b.ge .Lssa_main_40
.Lssa_main_396:
    .loc 2 2380 3
    ldr x4, [sp, #152]
    str x4, [sp, #-16]!
    bl __fn___fern_str_bytes_u8
    add sp, sp, #16
    mov x22, x0
.Lssa_main_394:
    .loc 2 737 3
    mov x23, #8192
    mov x4, #32768
    str x4, [sp, #128]
    movz x4, #16, lsl #16
    str x4, [sp, #120]
    .loc 2 1789 3
    .loc 2 1805 3
    adrp x4, .SB6
    add x4, x4, :lo12:.SB6
    str x4, [sp, #112]
    adrp x4, .SB6
    add x4, x4, :lo12:.SB6
    str x4, [sp, #104]
    .loc 6 90 3
    adrp x28, .K1
    add x28, x28, :lo12:.K1
.Lssa_main_392:
    ldr x9, [x22, #0]
    cmp x9, #1
    b.le .Lssa_main_388
.Lssa_main_391:
    .loc 2 1789 3
    ldrb w9, [x22, #8]
    cmp x9, #13
    b.ne .Lssa_main_388
.Lssa_main_390:
    ldrb w9, [x22, #9]
    cmp x9, #10
    b.ne .Lssa_main_388
.Lssa_main_389:
    .loc 2 2315 5
    mov x5, #2
    str x5, [sp, #96]
    b .Lssa_main_387
.Lssa_main_388:
    str xzr, [sp, #96]
.Lssa_main_387:
    .loc 2 970 3
    ldr x4, [x22, #0]
    str x4, [sp, #88]
    ldr x4, [sp, #96]
    ldr x5, [sp, #88]
    cmp x4, x5
    b.lt .Lssa_main_384
.Lssa_main_415:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    b .Lssa_main_1
.Lssa_main_384:
    .loc 2 971 3
    ldr x4, [sp, #96]
    add x23, x4, x23
    add x23, x23, #2
    sxtw x23, w23
    .loc 2 972 3
    ldr x5, [sp, #128]
    add x9, x4, x5
    add x9, x9, #4
    sxtw x4, w9
    str x4, [sp, #80]
    ldr x5, [sp, #88]
    cmp x4, x5
    ldr x6, [sp, #88]
    csel x21, x4, x6, lt
    .loc 2 977 3
    mov x24, #-1
    .loc 2 978 3
    mov x25, #-1
    .loc 2 979 3
    .loc 2 981 3
    .loc 2 983 3
    adrp x9, .K11
    add x9, x9, :lo12:.K11
    mov x2, x9
    ldr x1, [sp, #96]
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L74
    mov x1, #0
.L74:
    adrp x9, .S183
    add x9, x9, :lo12:.S183
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L77
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L75:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L76
    add x5, x5, #16
    cmp x5, x8
    b.ls .L75
    sub x1, x5, x0
    b .L77
.L76:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L78
.L77:
    add x10, x9, #96
.L81:
    cmp x1, x3
    b.ge .L79
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L78
    add x1, x1, #1
    b .L81
.L78:
    str x1, [sp, #-16]!
    b .L80
.L79:
    str x3, [sp, #-16]!
.L80:
    ldr x0, [sp], #16
.Lssa_main_380:
    cmp x0, x21
    b.lt .Lssa_main_377
.Lssa_main_379:
    .loc 2 1017 5
    mov x10, #2
    b .Lssa_main_367
.Lssa_main_377:
    ldr x6, [x22]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x0
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_main_374
.Lssa_main_376:
    add x9, x0, #1
    ldr x10, [x22, #0]
    cmp x9, x10
    b.ge .Lssa_main_372
.Lssa_main_375:
    add x10, x0, #1
    ldr x6, [x22]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_main_372
.Lssa_main_374:
    .loc 2 1020 5
    mov x10, #1
    b .Lssa_main_367
.Lssa_main_372:
    add x9, x0, #1
    ldr x10, [x22, #0]
    cmp x9, x10
    b.lt .Lssa_main_369
.Lssa_main_371:
    .loc 2 1023 5
    mov x10, #2
    b .Lssa_main_367
.Lssa_main_369:
    .loc 2 1025 3
    mov x10, #0
.Lssa_main_368:
.Lssa_main_367:
    ldr x9, [sp, #96]
    ldr x12, [sp, #96]
    mov x13, x10
    mov x10, #0
    mov x11, #0
.Lssa_main_447:
    cmp x13, #2
    b.ne .Lssa_main_473
.Lssa_main_475:
    mov x19, x24
    mov x26, x25
    b .Lssa_main_362
.Lssa_main_473:
    cmp x13, #1
    b.ne .Lssa_main_471
.Lssa_main_472:
    .loc 2 989 9
    add x13, x0, #1
    sxtw x13, w13
    .loc 2 987 12
    .loc 2 988 18
    mov x20, x13
    mov x19, x13
    mov x27, #1
    mov x26, #0
    b .Lssa_main_461
.Lssa_main_471:
    mov x13, #-1
    cmp x24, x13
    b.ne .Lssa_main_467
.Lssa_main_470:
    .loc 2 993 20
    add x13, x0, #1
    sxtw x13, w13
.Lssa_main_469:
    cmp x13, x23
    b.lt .Lssa_main_466
.Lssa_main_468:
    .loc 2 1030 5
    mov x13, #-2
    b .Lssa_main_465
.Lssa_main_467:
    mov x13, x24
    b .Lssa_main_465
.Lssa_main_466:
    mov x13, x0
.Lssa_main_465:
    cmp x0, x9
    b.ne .Lssa_main_462
.Lssa_main_464:
    cbnz x11, .Lssa_main_366
.Lssa_main_462:
    .loc 2 1000 9
    add x11, x0, #2
    sxtw x11, w11
    .loc 2 999 18
    mov x24, x13
    mov x27, x10
    mov x20, x11
    mov x19, x11
    mov x26, #1
.Lssa_main_461:
    .loc 2 1003 7
    adrp x11, .K11
    add x11, x11, :lo12:.K11
    mov x2, x11
    mov x1, x19
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L82
    mov x1, #0
.L82:
    adrp x9, .S183
    add x9, x9, :lo12:.S183
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L85
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L83:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L84
    add x5, x5, #16
    cmp x5, x8
    b.ls .L83
    sub x1, x5, x0
    b .L85
.L84:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L86
.L85:
    add x10, x9, #96
.L89:
    cmp x1, x3
    b.ge .L87
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L86
    add x1, x1, #1
    b .L89
.L86:
    str x1, [sp, #-16]!
    b .L88
.L87:
    str x3, [sp, #-16]!
.L88:
    ldr x0, [sp], #16
.Lssa_main_460:
    cmp x0, x21
    b.lt .Lssa_main_457
.Lssa_main_459:
    .loc 2 1017 5
    mov x13, #2
    b .Lssa_main_448
.Lssa_main_457:
    ldr x6, [x22]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x0
    ldrb w11, [x5, #8]
    cmp x11, #10
    b.eq .Lssa_main_454
.Lssa_main_456:
    add x11, x0, #1
    ldr x9, [x22, #0]
    cmp x11, x9
    b.ge .Lssa_main_452
.Lssa_main_455:
    add x9, x0, #1
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w11, [x5, #8]
    cmp x11, #10
    b.eq .Lssa_main_452
.Lssa_main_454:
    .loc 2 1020 5
    mov x13, #1
    b .Lssa_main_448
.Lssa_main_452:
    add x11, x0, #1
    ldr x9, [x22, #0]
    cmp x11, x9
    b.lt .Lssa_main_449
.Lssa_main_451:
    .loc 2 1023 5
    mov x13, #2
    b .Lssa_main_448
.Lssa_main_449:
    .loc 2 1025 3
    mov x13, #0
.Lssa_main_448:
    mov x10, x27
    mov x9, x20
    mov x11, x26
    mov x12, x19
    cmp x13, #2
    b.eq .Lssa_main_475
    b .Lssa_main_473
.Lssa_main_366:
    .loc 2 996 21
    sub x9, x0, #2
    sxtw x9, w9
    add x0, x0, #1
    sxtw x0, w0
.Lssa_main_365:
    ldr x5, [sp, #80]
    cmp x0, x5
    b.lt .Lssa_main_363
.Lssa_main_364:
    .loc 2 1030 5
    mov x11, #-2
    mov x19, x13
    mov x26, x11
    b .Lssa_main_362
.Lssa_main_363:
    mov x19, x13
    mov x26, x9
.Lssa_main_362:
    mov x11, #-1
    cmp x19, x11
    b.ne .Lssa_main_356
.Lssa_main_360:
    .loc 2 1036 3
    ldr x20, [x22, #0]
    cmp x23, x21
    b.le .Lssa_main_349
.Lssa_main_359:
    cmp x21, x20
    b.ge .Lssa_main_349
.Lssa_main_358:
    cmp x23, x20
    csel x11, x23, x20, lt
    .loc 2 1042 5
    str x10, [sp, #64]
    mov x0, x22
    mov x9, x12
    mov x10, x11
    bl __fn_http____find_crlf.r
    ldr x10, [sp, #64]
    cmp x0, #0
    b.lt .Lssa_main_349
    b .Lssa_main_353
.Lssa_main_356:
    mov x20, x19
    b .Lssa_main_345
.Lssa_main_353:
    mov x20, x0
    b .Lssa_main_345
.Lssa_main_349:
    cmp x20, x23
    b.lt .Lssa_main_346
.Lssa_main_348:
    .loc 2 1048 5
    mov x11, #-2
    mov x20, x11
    b .Lssa_main_345
.Lssa_main_346:
    .loc 2 1050 3
    mov x11, #-1
    mov x20, x11
.Lssa_main_345:
    mov x11, #-1
    cmp x26, x11
    b.ne .Lssa_main_339
.Lssa_main_344:
    ldr x4, [sp, #88]
    ldr x5, [sp, #80]
    cmp x4, x5
    b.lt .Lssa_main_339
.Lssa_main_343:
    .loc 2 1010 17
    mov x11, #-2
    mov x26, x11
.Lssa_main_342:
.Lssa_main_341:
.Lssa_main_339:
    mov x11, #-2
    cmp x20, x11
    b.ne .Lssa_main_336
.Lssa_main_338:
    .loc 2 1965 5
    mov x11, #414
    b .Lssa_main_329
.Lssa_main_336:
    mov x11, #-2
    cmp x26, x11
    b.ne .Lssa_main_333
.Lssa_main_335:
    .loc 2 1968 5
    mov x11, #431
    b .Lssa_main_329
.Lssa_main_333:
    cbz x10, .Lssa_main_330
.Lssa_main_332:
    .loc 2 1971 5
    mov x11, #400
    b .Lssa_main_329
.Lssa_main_330:
    .loc 2 1973 3
    mov x11, #0
.Lssa_main_329:
    cmp x11, #0
    b.eq .Lssa_main_327
.Lssa_main_584:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    b .Lssa_main_1
.Lssa_main_327:
    .loc 2 1917 3
    mov x19, #-1
    mov x23, #-1
    adrp x21, .SB6
    add x21, x21, :lo12:.SB6
    cmp x20, #0
    b.lt .Lssa_main_321
.Lssa_main_325:
    .loc 2 1395 3
    adrp x11, .K8
    add x11, x11, :lo12:.K8
    mov x2, x11
    ldr x1, [sp, #96]
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L90
    mov x1, #0
.L90:
    adrp x9, .S70
    add x9, x9, :lo12:.S70
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L93
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L91:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L92
    add x5, x5, #16
    cmp x5, x8
    b.ls .L91
    sub x1, x5, x0
    b .L93
.L92:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L94
.L93:
    add x10, x9, #96
.L97:
    cmp x1, x3
    b.ge .L95
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L94
    add x1, x1, #1
    b .L97
.L94:
    str x1, [sp, #-16]!
    b .L96
.L95:
    str x3, [sp, #-16]!
.L96:
    ldr x0, [sp], #16
    cmp x0, x20
    csel x27, x20, x0, gt
    ldr x5, [sp, #96]
    cmp x27, x5
    b.eq .Lssa_main_322
.Lssa_main_324:
    cmp x27, x20
    b.ge .Lssa_main_322
.Lssa_main_323:
    ldr x6, [x22]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x27
    ldrb w11, [x5, #8]
    cmp x11, #32
    b.eq .Lssa_main_319
.Lssa_main_322:
    .loc 2 1761 5
    adrp x11, .SB6
    add x11, x11, :lo12:.SB6
    mov x10, #-1
    mov x12, #-1
    mov x21, x10
    mov x27, x12
    mov x24, x11
    mov x0, #400
    b .Lssa_main_262
.Lssa_main_321:
    str x19, [sp, #104]
    mov x27, x23
    str x21, [sp, #88]
    b .Lssa_main_260
.Lssa_main_319:
    .loc 2 1763 3
    add x12, x27, #1
.Lssa_main_318:
    mov x10, #32
    .loc 2 693 3
    mov x2, x12
    mov x1, x10
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L98
    mov x2, #0
.L98:
    cmp x1, #255
    b.hi .L103
    cmp x2, x3
    b.ge .L103
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L100
.L99:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L105
    cmp x5, x8
    b.ls .L99
.L100:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L101
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L101
    sub x5, x5, #16
    b .L106
.L105:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L106
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L106:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L104
.L101:
    cmp x5, x6
    b.ge .L103
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L107
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L103
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L103
    add x5, x5, x4
    b .L102
.L107:
    cmp x5, x6
    b.ge .L103
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L102
    add x5, x5, #1
    b .L107
.L102:
    sub x2, x5, x0
    b .L104
.L103:
    mov x2, #-1
.L104:
    mov x0, x2
    .loc 2 697 3
    mov x10, #-1
    cmp x0, x20
    csel x21, x0, x10, lt
    cmp x21, #0
    b.lt .Lssa_main_312
.Lssa_main_313:
    add x10, x27, #1
    cmp x21, x10
    b.ne .Lssa_main_310
.Lssa_main_312:
    .loc 2 1765 5
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    mov x12, #-1
    mov x11, #-1
    mov x21, x12
    mov x27, x11
    mov x24, x10
    mov x0, #400
    b .Lssa_main_262
.Lssa_main_310:
    .loc 2 1767 3
    add x11, x21, #1
    sxtw x23, w11
.Lssa_main_309:
    sub x11, x20, x23
    sxtw x11, w11
    cmp x11, #8
    b.ne .Lssa_main_307
.Lssa_main_308:
    adrp x10, .K12
    add x10, x10, :lo12:.K12
    mov x11, #0
    mov x12, #5
    mov x0, x22
    mov x9, x23
    bl __fn___sem_byte_view_mismatch.r
    cmp x0, #5
    b.eq .Lssa_main_305
.Lssa_main_307:
    .loc 2 2327 5
    mov x11, #400
    b .Lssa_main_288
.Lssa_main_305:
    add w12, w23, #5
    ldr x6, [x22]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x12
    ldrb w11, [x5, #8]
.Lssa_main_304:
    .loc 2 2346 3
    cmp x11, #48
    b.lo .Lssa_main_291
.Lssa_main_303:
    cmp x11, #57
    b.hi .Lssa_main_291
.Lssa_main_300:
    add w11, w23, #6
    ldr x6, [x22]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    ldrb w12, [x5, #8]
    cmp x12, #46
    b.ne .Lssa_main_291
.Lssa_main_299:
    add w12, w23, #7
    ldr x6, [x22]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x12
    ldrb w11, [x5, #8]
.Lssa_main_298:
    cmp x11, #48
    b.lo .Lssa_main_291
.Lssa_main_297:
    cmp x11, #57
    b.hi .Lssa_main_291
.Lssa_main_293:
    add w23, w23, #5
    ldr x6, [x22]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    ldrb w11, [x5, #8]
    cmp x11, #49
    b.eq .Lssa_main_289
.Lssa_main_292:
    .loc 2 2333 5
    mov x11, #505
    b .Lssa_main_288
.Lssa_main_291:
    .loc 2 2330 5
    mov x11, #400
    b .Lssa_main_288
.Lssa_main_289:
    .loc 2 2335 3
    mov x11, #0
.Lssa_main_288:
    cmp x11, #0
    b.eq .Lssa_main_285
.Lssa_main_287:
    .loc 2 1769 5
    adrp x12, .SB6
    add x12, x12, :lo12:.SB6
    mov x10, #-1
    mov x9, #-1
    mov x0, x11
    mov x21, x10
    mov x27, x9
    mov x24, x12
    b .Lssa_main_262
.Lssa_main_285:
    .loc 2 1771 3
    add x23, x27, #1
    ldr x5, [sp, #96]
    sub x9, x27, x5
    sxtw x9, w9
    cmp x9, #7
    b.ne .Lssa_main_283
.Lssa_main_284:
    adrp x19, .SB184
    add x19, x19, :lo12:.SB184
    .loc 2 2350 3
    ldr x9, [x19, #8]
    mov x10, #0
    mov x4, x9
    mov x3, x10
    mov x2, x19
    ldr x1, [sp, #96]
    mov x0, x22
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L108_aop
    mov x1, #0
.L108_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L108_bop
    mov x3, #0
.L108_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L108_nok
    mov x4, #0
.L108_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L108_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L108_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L108_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L108_done
.L108_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L108_vec
.L108_short:
    cmp x10, #8
    b.lt .L108_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L108_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L108_eq
    add x8, x8, x14
.L108_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L108_done
.L108_w4:
    cmp x10, #4
    b.lt .L108_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L108_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L108_eq
    add x8, x8, x14
.L108_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L108_done
.L108_w2:
    cmp x10, #2
    b.lt .L108_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L108_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L108_eq
    add x8, x8, x14
.L108_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L108_done
.L108_tail:
    cmp x8, x13
    b.ge .L108_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L108_th
    add x8, x8, #1
    add x9, x9, #1
    b .L108_tail
.L108_th:
    sub x2, x8, x12
    b .L108_done
.L108_eq:
    mov x2, x4
.L108_done:
    mov x0, x2
    ldr x10, [x19, #8]
    cmp x0, x10
    cset x11, eq
    b .Lssa_main_281
.Lssa_main_283:
    mov x11, #0
.Lssa_main_282:
.Lssa_main_281:
    .loc 2 2022 3
    mov x0, x22
    mov x9, x23
    mov x10, x21
    bl __fn_http____target_start.r
    mov x19, x0
    mov x11, #-2
    cmp x19, x11
    b.ne .Lssa_main_278
.Lssa_main_280:
    .loc 2 2024 5
    mov x0, #400
    b .Lssa_main_263
.Lssa_main_278:
    mov x11, #-1
    cmp x19, x11
    b.ne .Lssa_main_275
.Lssa_main_277:
    .loc 2 2027 5
    adrp x11, .SB185
    add x11, x11, :lo12:.SB185
    mov x0, x11
    b .Lssa_main_266
.Lssa_main_275:
    .loc 2 2029 3
    mov x0, x22
    mov x9, x19
    mov x10, x21
    bl __fn_http____path_end.r
    mov x23, x0
    cmp x23, #0
    b.ge .Lssa_main_272
.Lssa_main_274:
    .loc 2 2031 5
    mov x0, #400
    b .Lssa_main_263
.Lssa_main_272:
    cmp x19, x23
    b.ge .Lssa_main_268
.Lssa_main_271:
    mov x0, x22
    mov x9, x19
    mov x10, x23
    bl __fn_http____plain_path.r
    cbz x0, .Lssa_main_268
.Lssa_main_270:
    .loc 2 2034 5
    mov x0, x22
    mov x9, x19
    mov x10, x21
    ldr x11, [sp, #104]
    bl __fn_http____shared_string.r
    b .Lssa_main_266
.Lssa_main_268:
    mov x0, x22
    mov x9, x19
    mov x10, x23
    mov x11, x21
    bl __fn_http____decoded_path.r
    mov x24, x0
    mov x0, x1
    cmp x24, #0
    b.ne .Lssa_main_263
.Lssa_main_267:
.Lssa_main_266:
    .loc 2 1773 7
    mov x24, x0
    mov x4, x27
    mov x27, x21
    mov x21, x4
    mov x0, #0
    b .Lssa_main_262
.Lssa_main_265:
.Lssa_main_264:
.Lssa_main_263:
    .loc 2 1776 7
    adrp x11, .SB6
    add x11, x11, :lo12:.SB6
    mov x10, #-1
    mov x9, #-1
    mov x21, x10
    mov x27, x9
    mov x24, x11
.Lssa_main_262:
    cmp x0, #0
    b.eq .Lssa_main_261
.Lssa_main_705:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x24
    bl __fn___fern_str_free.r
    b .Lssa_main_1
.Lssa_main_261:
    str x21, [sp, #104]
    str x24, [sp, #88]
.Lssa_main_260:
    cmp x20, #0
    b.ge .Lssa_main_259
.Lssa_main_709:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    b .Lssa_main_pool_435
    .ltorg
.Lssa_main_pool_435:
    b .Lssa_main_1
.Lssa_main_259:
    cmp x26, #0
    b.ge .Lssa_main_257
.Lssa_main_713:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    b .Lssa_main_1
.Lssa_main_257:
    .loc 2 1930 3
    add x9, x26, #4
    ldr x5, [sp, #96]
    sub x4, x9, x5
    str x4, [sp, #80]
    .loc 2 1931 3
    add x20, x20, #2
    sxtw x20, w20
    cmp x20, x26
    csel x9, x26, x20, gt
.Lssa_main_253:
    .loc 6 90 3
    adrp x0, .K1
    add x0, x0, :lo12:.K1
    .loc 2 871 3
    .loc 2 872 3
.Lssa_main_252:
    mov x20, x0
    mov x21, x9
    mov x19, #1
    mov x25, #0
.Lssa_main_722:
    cmp x21, x26
    b.ge .Lssa_main_251
.Lssa_main_776:
    .loc 2 1395 3
    adrp x9, .K8
    add x9, x9, :lo12:.K8
    mov x2, x9
    mov x1, x21
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L109
    mov x1, #0
.L109:
    adrp x9, .S70
    add x9, x9, :lo12:.S70
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L112
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L110:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L111
    add x5, x5, #16
    cmp x5, x8
    b.ls .L110
    sub x1, x5, x0
    b .L112
.L111:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L113
.L112:
    add x10, x9, #96
.L116:
    cmp x1, x3
    b.ge .L114
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L113
    add x1, x1, #1
    b .L116
.L113:
    str x1, [sp, #-16]!
    b .L115
.L114:
    str x3, [sp, #-16]!
.L115:
    ldr x0, [sp], #16
    cmp x0, x26
    csel x10, x26, x0, gt
    cmp x10, x21
    b.eq .Lssa_main_773
.Lssa_main_775:
    cmp x10, x26
    b.ge .Lssa_main_773
.Lssa_main_774:
    ldr x6, [x22]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    ldrb w9, [x5, #8]
    cmp x9, #58
    b.eq .Lssa_main_771
.Lssa_main_773:
    .loc 2 926 5
    mov x9, #-1
    mov x10, x26
    b .Lssa_main_759
.Lssa_main_771:
    .loc 2 928 3
    add x9, x10, #1
.Lssa_main_770:
    .loc 2 701 3
    mov x11, #13
    str x10, [sp, #64]
    mov x2, x9
    mov x1, x11
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L117
    mov x2, #0
.L117:
    cmp x1, #255
    b.hi .L122
    cmp x2, x3
    b.ge .L122
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L119
.L118:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L124
    cmp x5, x8
    b.ls .L118
.L119:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L120
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L120
    sub x5, x5, #16
    b .L125
.L124:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L125
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L125:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L123
.L120:
    cmp x5, x6
    b.ge .L122
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L126
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L122
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L122
    add x5, x5, x4
    b .L121
.L126:
    cmp x5, x6
    b.ge .L122
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L121
    add x5, x5, #1
    b .L126
.L121:
    sub x2, x5, x0
    b .L123
.L122:
    mov x2, #-1
.L123:
    mov x0, x2
    ldr x10, [sp, #64]
    cmp x0, #0
    b.lt .Lssa_main_768
.Lssa_main_769:
    cmp x0, x26
    b.lt .Lssa_main_766
.Lssa_main_768:
    mov x0, x26
    b .Lssa_main_762
.Lssa_main_766:
    add x11, x0, #1
    cmp x11, x26
    b.ge .Lssa_main_764
.Lssa_main_765:
    add x11, x0, #1
    ldr x6, [x22]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_main_762
.Lssa_main_764:
    .loc 2 706 5
    mov x9, #-1
    mov x0, x9
.Lssa_main_763:
.Lssa_main_762:
    cmp x0, #0
    b.ge .Lssa_main_760
.Lssa_main_761:
    .loc 2 930 5
    mov x9, #-1
    mov x10, x26
    b .Lssa_main_759
.Lssa_main_760:
    mov x9, x10
    mov x10, x0
.Lssa_main_759:
    cmp x9, #0
    b.ge .Lssa_main_757
.Lssa_main_827:
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    str x9, [sp, #64]
    str x10, [sp, #56]
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    b .Lssa_main_1
.Lssa_main_757:
    .loc 2 881 11
    add x11, x25, #1
    sxtw x25, w11
    cmp x25, #100
    b.le .Lssa_main_755
.Lssa_main_831:
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    str x9, [sp, #64]
    str x10, [sp, #56]
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    b .Lssa_main_1
.Lssa_main_755:
    .loc 2 885 5
    sub x11, x25, #1
    sxtw x12, w11
    cbz x19, .Lssa_main_748
.Lssa_main_754:
    ldr x11, [x28, #8]
    ldr x13, [x11, #0]
    cmp x12, x13
    b.lt .Lssa_main_748
.Lssa_main_753:
    cmp x12, #0
    b.le .Lssa_main_750
.Lssa_main_843:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
.Lssa_main_752:
    tbnz x28, #0, .Lssa_main_rcinc3588
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcinc3588
    ldur w5, [x28, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc3588sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc3588sl:
    tbnz w5, #31, .Lssa_main_rcinc3588
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcinc3588:
    .loc 2 888 11
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    mov x0, x28
    mov x9, x12
    bl __fn_http____leading_fields.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    mov x20, x0
.Lssa_main_751:
.Lssa_main_750:
    .loc 2 890 12
    mov x19, #0
.Lssa_main_749:
.Lssa_main_748:
    .loc 2 892 5
    mov x13, #-1
    cmp x19, #0
    csel x13, x12, x13, ne
    .loc 2 896 5
    add x11, x9, #1
    sxtw x11, w11
.Lssa_main_744:
.Lssa_main_854:
    cmp x11, x10
    b.ge .Lssa_main_742
.Lssa_main_860:
    ldr x6, [x22]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    ldrb w14, [x5, #8]
.Lssa_main_859:
    .loc 2 838 3
    cmp x14, #32
    b.eq .Lssa_main_855
.Lssa_main_857:
    cmp x14, #9
    b.ne .Lssa_main_742
.Lssa_main_855:
    .loc 2 851 10
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_main_860
.Lssa_main_742:
    mov x14, x10
.Lssa_main_876:
    cmp x14, x11
    b.le .Lssa_main_741
.Lssa_main_882:
    sub x15, x14, #1
    ldr x6, [x22]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x15
    ldrb w1, [x5, #8]
.Lssa_main_881:
    .loc 2 838 3
    cmp x1, #32
    b.eq .Lssa_main_877
.Lssa_main_879:
    cmp x1, #9
    b.ne .Lssa_main_741
.Lssa_main_877:
    .loc 2 854 9
    sub x14, x14, #1
    cmp x14, x11
    b.gt .Lssa_main_882
.Lssa_main_741:
    cmp x13, #0
    b.lt .Lssa_main_736
.Lssa_main_740:
    ldr x1, [x28, #16]
    ldr x6, [x1]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x13, #1
    ldr x15, [x1, x5, lsl #3]
    ldr x1, [x15, #8]
    sub x15, x14, x11
    sxtw x15, w15
    cmp x1, x15
    b.ne .Lssa_main_736
.Lssa_main_739:
    ldr x15, [x28, #16]
    ldr x6, [x15]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x13, #1
    ldr x8, [x15, x5, lsl #3]
    .loc 2 2350 3
    ldr x1, [x8, #8]
    mov x2, #0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x4, x1
    mov x3, x2
    mov x2, x8
    mov x1, x11
    mov x0, x22
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L127_aop
    mov x1, #0
.L127_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L127_bop
    mov x3, #0
.L127_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L127_nok
    mov x4, #0
.L127_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L127_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L127_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L127_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L127_done
.L127_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L127_vec
.L127_short:
    cmp x10, #8
    b.lt .L127_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L127_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L127_eq
    add x8, x8, x14
.L127_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L127_done
.L127_w4:
    cmp x10, #4
    b.lt .L127_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L127_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L127_eq
    add x8, x8, x14
.L127_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L127_done
.L127_w2:
    cmp x10, #2
    b.lt .L127_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L127_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L127_eq
    add x8, x8, x14
.L127_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L127_done
.L127_tail:
    cmp x8, x13
    b.ge .L127_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L127_th
    add x8, x8, #1
    add x9, x9, #1
    b .L127_tail
.L127_th:
    sub x2, x8, x12
    b .L127_done
.L127_eq:
    mov x2, x4
.L127_done:
    mov x0, x2
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    ldr x2, [x8, #8]
    cmp x0, x2
    b.ne .Lssa_main_736
.Lssa_main_738:
    .loc 2 857 5
    ldr x6, [x15]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x13, #1
    ldr x2, [x15, x5, lsl #3]
    tbnz x2, #0, .Lssa_main_rcinc3655
    cmp x2, #16, lsl #12
    b.lo .Lssa_main_rcinc3655
    ldur w5, [x2, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc3655sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc3655sl:
    tbnz w5, #31, .Lssa_main_rcinc3655
    add w5, w5, #1
    stur w5, [x2, #-8]
.Lssa_main_rcinc3655:
    mov x15, x2
    b .Lssa_main_732
.Lssa_main_736:
    adrp x2, .K9
    add x2, x2, :lo12:.K9
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x1, x11
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L128
    mov x1, #0
.L128:
    adrp x9, .S71
    add x9, x9, :lo12:.S71
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L131
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L129:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L130
    add x5, x5, #16
    cmp x5, x8
    b.ls .L129
    sub x1, x5, x0
    b .L131
.L130:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L132
.L131:
    add x10, x9, #96
.L135:
    cmp x1, x3
    b.ge .L133
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L132
    add x1, x1, #1
    b .L135
.L132:
    str x1, [sp, #-16]!
    b .L134
.L133:
    str x3, [sp, #-16]!
.L134:
    ldr x0, [sp], #16
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    cmp x0, x14
    b.ge .Lssa_main_734
.Lssa_main_911:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    b .Lssa_main_1
.Lssa_main_734:
    .loc 2 713 5
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    mov x0, x22
    mov x9, x11
    mov x10, x14
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x15, x0
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
.Lssa_main_915:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x15, [sp, #40]
    mov x0, x15
    bl __fn_utf8__is_valid.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x15, [sp, #40]
    cbnz x0, .Lssa_main_732
.Lssa_main_918:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x15, [sp, #40]
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x15, [sp, #40]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x15, [sp, #40]
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x15, [sp, #40]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x15, [sp, #40]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x15, [sp, #40]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x15, [sp, #40]
    mov x0, x15
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x15, [sp, #40]
    b .Lssa_main_1
.Lssa_main_733:
.Lssa_main_732:
    cbz x19, .Lssa_main_725
.Lssa_main_731:
    .loc 2 899 11
    ldr x14, [x28, #8]
    ldr x6, [x14]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x11, [x14, x5, lsl #3]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x22
    mov x10, x9
    mov x9, x21
    bl __fn_http____shared_string.r
    mov x14, x0
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    .loc 2 900 16
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    ldr x6, [x14, #8]
    ldr x7, [x11, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn3693
    mov x0, x14
    mov x9, x11
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd3693
.Lssa_main_streqn3693:
    mov x0, #0
.Lssa_main_streqd3693:
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    cbz x0, .Lssa_main_729
.Lssa_main_730:
    ldr x11, [x28, #16]
    ldr x6, [x11]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x2, [x11, x5, lsl #3]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    ldr x6, [x15, #8]
    ldr x7, [x2, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn3696
    mov x0, x15
    mov x9, x2
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd3696
.Lssa_main_streqn3696:
    mov x0, #0
.Lssa_main_streqd3696:
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    mov x11, x0
    b .Lssa_main_728
.Lssa_main_729:
    mov x11, #0
.Lssa_main_728:
    cbz x11, .Lssa_main_931
.Lssa_main_930:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    mov x0, x14
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    mov x0, x15
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    b .Lssa_main_727
.Lssa_main_931:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    b .Lssa_main_726
.Lssa_main_727:
    mov x19, x11
    b .Lssa_main_723
.Lssa_main_726:
    tbnz x28, #0, .Lssa_main_rcinc3703
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcinc3703
    ldur w5, [x28, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc3703sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc3703sl:
    tbnz w5, #31, .Lssa_main_rcinc3703
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcinc3703:
    .loc 2 902 15
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    mov x0, x28
    mov x9, x12
    bl __fn_http____leading_fields.r
    mov x13, x0
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    tst x13, #1
    b.ne .Lssa_main_uq726
    cmp x13, #16, lsl #12
    b.lo .Lssa_main_uq726
    ldur w5, [x13, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq726us
    bl __fern_san_abort_uaf
.Lssa_main_uq726us:
    cmp w5, #1
.Lssa_main_uq726:
    b.ne .Lssa_main_936
.Lssa_main_935:
    mov x12, x13
    b .Lssa_main_937
.Lssa_main_936:
    mov x12, #0
.Lssa_main_937:
    .loc 6 301 3
    ldr x8, [x13, #8]
    cmp x12, #0
    b.ne .Lssa_main_940
.Lssa_main_938:
    tbnz x8, #0, .Lssa_main_rcinc3711
    cmp x8, #16, lsl #12
    b.lo .Lssa_main_rcinc3711
    ldur w5, [x8, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc3711sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc3711sl:
    tbnz w5, #31, .Lssa_main_rcinc3711
    add w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_main_rcinc3711:
.Lssa_main_940:
    tst x8, #1
    b.ne .Lssa_main_uq940
    cmp x8, #16, lsl #12
    b.lo .Lssa_main_uq940
    ldur w5, [x8, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq940us
    bl __fern_san_abort_uaf
.Lssa_main_uq940us:
    cmp w5, #1
.Lssa_main_uq940:
    b.ne .Lssa_main_942
.Lssa_main_941:
    mov x0, x8
    mov x1, x14
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    mov x23, x0
    b .Lssa_main_943
.Lssa_main_942:
    mov x0, x8
    mov x1, x14
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    bl __fern_arr_push
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    mov x23, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x8
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    mov x0, x8
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
.Lssa_main_943:
    ldr x8, [x13, #16]
    cmp x12, #0
    b.ne .Lssa_main_946
.Lssa_main_944:
    tbnz x8, #0, .Lssa_main_rcinc3721
    cmp x8, #16, lsl #12
    b.lo .Lssa_main_rcinc3721
    ldur w5, [x8, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc3721sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc3721sl:
    tbnz w5, #31, .Lssa_main_rcinc3721
    add w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_main_rcinc3721:
.Lssa_main_946:
    tst x8, #1
    b.ne .Lssa_main_uq946
    cmp x8, #16, lsl #12
    b.lo .Lssa_main_uq946
    ldur w5, [x8, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq946us
    bl __fern_san_abort_uaf
.Lssa_main_uq946us:
    cmp w5, #1
.Lssa_main_uq946:
    b.ne .Lssa_main_948
.Lssa_main_947:
    mov x0, x8
    mov x1, x15
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    mov x14, x0
    b .Lssa_main_949
.Lssa_main_948:
    mov x0, x8
    mov x1, x15
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    bl __fern_arr_push
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    mov x14, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x0, x8
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    mov x0, x8
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
.Lssa_main_949:
    cmp x12, #0
    b.ne .Lssa_main_951
.Lssa_main_950:
    mov x8, #3
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x12, [sp, #-16]!
    str x8, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    adrp x8, .S0
    add x8, x8, :lo12:.S0
    str x8, [x0, #0]
    mov x8, x0
    b .Lssa_main_952
.Lssa_main_951:
    mov x8, x12
.Lssa_main_952:
    cmp x12, #0
    b.ne .Lssa_main_955
.Lssa_main_954:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    str x8, [sp, #24]
    mov x0, x13
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    ldr x8, [sp, #24]
.Lssa_main_955:
    str x23, [x8, #8]
    str x14, [x8, #16]
    mov x20, x8
    mov x19, x11
    b .Lssa_main_723
.Lssa_main_725:
    .loc 2 713 5
    str x10, [sp, #64]
    str x15, [sp, #56]
    mov x0, x22
    mov x10, x9
    mov x9, x21
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x12, x0
    ldr x10, [sp, #64]
    ldr x15, [sp, #56]
.Lssa_main_957:
    tst x20, #1
    b.ne .Lssa_main_uq957
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_uq957
    ldur w5, [x20, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq957us
    bl __fern_san_abort_uaf
.Lssa_main_uq957us:
    cmp w5, #1
.Lssa_main_uq957:
    b.ne .Lssa_main_960
.Lssa_main_959:
    mov x21, x20
    b .Lssa_main_961
.Lssa_main_960:
    mov x21, #0
.Lssa_main_961:
    .loc 6 301 3
    ldr x23, [x20, #8]
    cmp x21, #0
    b.ne .Lssa_main_964
.Lssa_main_962:
    tbnz x23, #0, .Lssa_main_rcinc3748
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_rcinc3748
    ldur w5, [x23, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc3748sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc3748sl:
    tbnz w5, #31, .Lssa_main_rcinc3748
    add w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_main_rcinc3748:
.Lssa_main_964:
    tst x23, #1
    b.ne .Lssa_main_uq964
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_uq964
    ldur w5, [x23, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq964us
    bl __fern_san_abort_uaf
.Lssa_main_uq964us:
    cmp w5, #1
.Lssa_main_uq964:
    b.ne .Lssa_main_966
.Lssa_main_965:
    mov x0, x23
    mov x1, x12
    str x10, [sp, #64]
    str x12, [sp, #56]
    str x15, [sp, #48]
    bl __fern_arr_push_owned
    ldr x10, [sp, #64]
    ldr x12, [sp, #56]
    ldr x15, [sp, #48]
    mov x23, x0
    b .Lssa_main_967
.Lssa_main_966:
    mov x0, x23
    mov x1, x12
    str x10, [sp, #64]
    str x15, [sp, #56]
    bl __fern_arr_push
    ldr x10, [sp, #64]
    ldr x15, [sp, #56]
    mov x9, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x15, [sp, #48]
    mov x0, x23
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x15, [sp, #48]
    mov x0, x23
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
    mov x23, x9
.Lssa_main_967:
    ldr x9, [x20, #16]
    cmp x21, #0
    b.ne .Lssa_main_970
.Lssa_main_968:
    tbnz x9, #0, .Lssa_main_rcinc3758
    cmp x9, #16, lsl #12
    b.lo .Lssa_main_rcinc3758
    ldur w5, [x9, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc3758sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc3758sl:
    tbnz w5, #31, .Lssa_main_rcinc3758
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_main_rcinc3758:
.Lssa_main_970:
    tst x9, #1
    b.ne .Lssa_main_uq970
    cmp x9, #16, lsl #12
    b.lo .Lssa_main_uq970
    ldur w5, [x9, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq970us
    bl __fern_san_abort_uaf
.Lssa_main_uq970us:
    cmp w5, #1
.Lssa_main_uq970:
    b.ne .Lssa_main_972
.Lssa_main_971:
    mov x0, x9
    mov x1, x15
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x15, [sp, #48]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
    mov x12, x0
    b .Lssa_main_973
.Lssa_main_972:
    mov x0, x9
    mov x1, x15
    str x9, [sp, #64]
    str x10, [sp, #56]
    bl __fern_arr_push
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    mov x12, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    mov x0, x9
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    str x10, [sp, #64]
    str x12, [sp, #56]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x10, [sp, #64]
    ldr x12, [sp, #56]
.Lssa_main_973:
    cmp x21, #0
    b.ne .Lssa_main_975
.Lssa_main_974:
    mov x9, #3
    str x10, [sp, #64]
    str x12, [sp, #56]
    str x21, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x10, [sp, #64]
    ldr x12, [sp, #56]
    adrp x9, .S0
    add x9, x9, :lo12:.S0
    str x9, [x0, #0]
    mov x15, x0
    b .Lssa_main_976
.Lssa_main_975:
    mov x15, x21
.Lssa_main_976:
    cmp x21, #0
    b.ne .Lssa_main_979
.Lssa_main_978:
    str x10, [sp, #64]
    str x12, [sp, #56]
    str x15, [sp, #48]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #64]
    ldr x12, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_main_979:
    str x23, [x15, #8]
    str x12, [x15, #16]
    mov x20, x15
.Lssa_main_724:
.Lssa_main_723:
    .loc 2 912 8
    add x10, x10, #2
    sxtw x21, w10
    cmp x21, x26
    b.lt .Lssa_main_776
.Lssa_main_251:
    cbz x19, .Lssa_main_247
.Lssa_main_250:
    ldr x10, [x28, #8]
    ldr x9, [x10, #0]
    cmp x25, x9
    b.ne .Lssa_main_247
.Lssa_main_986:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_249:
    mov x20, x28
    b .Lssa_main_243
.Lssa_main_247:
    cbz x19, .Lssa_main_243
.Lssa_main_991:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_246:
    .loc 2 918 5
    mov x0, x28
    mov x9, x25
    bl __fn_http____leading_fields.r
    mov x20, x0
.Lssa_main_245:
.Lssa_main_244:
.Lssa_main_243:
    .loc 2 1944 3
    add x27, x27, #1
.Lssa_main_242:
    add w27, w27, #7
    ldr x6, [x22]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x27
    ldrb w9, [x5, #8]
    cmp x9, #48
    b.ne .Lssa_main_239
.Lssa_main_241:
    .loc 2 2340 5
    adrp x9, .SB186
    add x9, x9, :lo12:.SB186
    str x9, [sp, #72]
    b .Lssa_main_237
.Lssa_main_239:
    .loc 2 2342 3
    adrp x9, .SB187
    add x9, x9, :lo12:.SB187
    str x9, [sp, #72]
.Lssa_main_238:
.Lssa_main_237:
    .loc 2 1095 3
    mov x9, #-1
    .loc 2 1096 3
    mov x10, #-1
    .loc 2 1097 3
    mov x15, #-1
    .loc 2 1098 3
    mov x12, #-1
    .loc 2 1099 3
    mov x8, #-1
    .loc 2 1100 3
.Lssa_main_236:
    mov x25, x9
    mov x28, x10
    mov x19, x15
    mov x21, x12
    mov x26, x8
    mov x23, #0
.Lssa_main_1001:
    ldr x8, [x20, #8]
    ldr x12, [x8, #0]
    cmp x23, x12
    b.ge .Lssa_main_233
.Lssa_main_1048:
    .loc 2 1102 5
    ldr x12, [x20, #8]
    add x5, x23, #1
    ldr x8, [x12, x5, lsl #3]
.Lssa_main_1047:
    .loc 2 1131 3
    ldr x12, [x8, #8]
    cmp x12, #4
    b.ne .Lssa_main_1044
.Lssa_main_1046:
    .loc 2 1133 5
    adrp x9, .SB188
    add x9, x9, :lo12:.SB188
    mov x10, #3
    str x12, [sp, #64]
    str x8, [sp, #56]
    mov x0, x8
    bl __fn_http____kind_if.r
    ldr x12, [sp, #64]
    ldr x8, [sp, #56]
    b .Lssa_main_1031
.Lssa_main_1044:
    cmp x12, #6
    b.ne .Lssa_main_1041
.Lssa_main_1043:
    .loc 2 1136 5
    adrp x9, .SB189
    add x9, x9, :lo12:.SB189
    mov x10, #4
    str x12, [sp, #64]
    str x8, [sp, #56]
    mov x0, x8
    bl __fn_http____kind_if.r
    ldr x12, [sp, #64]
    ldr x8, [sp, #56]
    b .Lssa_main_1031
.Lssa_main_1041:
    cmp x12, #10
    b.ne .Lssa_main_1038
.Lssa_main_1040:
    .loc 2 1139 5
    adrp x9, .SB63
    add x9, x9, :lo12:.SB63
    mov x10, #5
    str x12, [sp, #64]
    str x8, [sp, #56]
    mov x0, x8
    bl __fn_http____kind_if.r
    ldr x12, [sp, #64]
    ldr x8, [sp, #56]
    b .Lssa_main_1031
.Lssa_main_1038:
    cmp x12, #14
    b.ne .Lssa_main_1035
.Lssa_main_1037:
    .loc 2 1142 5
    adrp x9, .SB62
    add x9, x9, :lo12:.SB62
    mov x10, #1
    str x12, [sp, #64]
    str x8, [sp, #56]
    mov x0, x8
    bl __fn_http____kind_if.r
    ldr x12, [sp, #64]
    ldr x8, [sp, #56]
    b .Lssa_main_1031
.Lssa_main_1035:
    cmp x12, #17
    b.ne .Lssa_main_1032
.Lssa_main_1034:
    .loc 2 1145 5
    adrp x9, .SB64
    add x9, x9, :lo12:.SB64
    mov x10, #2
    mov x0, x8
    bl __fn_http____kind_if.r
    b .Lssa_main_1031
.Lssa_main_1032:
    .loc 2 1147 3
    mov x0, #0
.Lssa_main_1031:
    cmp x0, #1
    b.ne .Lssa_main_1024
.Lssa_main_1029:
    mov x10, #-1
    cmp x25, x10
    b.ne .Lssa_main_1025
.Lssa_main_1028:
    mov x25, x23
.Lssa_main_1027:
    b .Lssa_main_1024
.Lssa_main_1025:
    .loc 2 1127 3
    mov x10, #-2
    mov x25, x10
.Lssa_main_1024:
    cmp x0, #2
    b.ne .Lssa_main_1017
.Lssa_main_1022:
    mov x10, #-1
    cmp x28, x10
    b.ne .Lssa_main_1018
.Lssa_main_1021:
    mov x28, x23
.Lssa_main_1020:
    b .Lssa_main_1017
.Lssa_main_1018:
    mov x10, #-2
    mov x28, x10
.Lssa_main_1017:
    cmp x0, #3
    b.ne .Lssa_main_1010
.Lssa_main_1015:
    mov x10, #-1
    cmp x19, x10
    b.ne .Lssa_main_1011
.Lssa_main_1014:
    mov x19, x23
.Lssa_main_1013:
    b .Lssa_main_1010
.Lssa_main_1011:
    mov x10, #-2
    mov x19, x10
.Lssa_main_1010:
    cmp x0, #4
    b.ne .Lssa_main_1006
.Lssa_main_1009:
    cmp x21, #0
    b.ge .Lssa_main_1006
.Lssa_main_1008:
    mov x21, x23
.Lssa_main_1007:
.Lssa_main_1006:
    b .Lssa_main_pool_899
    .ltorg
.Lssa_main_pool_899:
    cmp x0, #5
    b.ne .Lssa_main_1002
.Lssa_main_1005:
    cmp x26, #0
    b.ge .Lssa_main_1002
.Lssa_main_1004:
    mov x26, x23
.Lssa_main_1003:
.Lssa_main_1002:
    .loc 2 1118 7
    add x23, x23, #1
    b .Lssa_main_1001
.Lssa_main_233:
    cmp x21, #0
    b.ge .Lssa_main_1133
.Lssa_main_232:
    .loc 2 1694 5
    mov x21, #0
    b .Lssa_main_225
.Lssa_main_230:
.Lssa_main_1133:
    cmp x21, #0
    b.lt .Lssa_main_229
.Lssa_main_1136:
    ldr x10, [x20, #16]
    ldr x6, [x10]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x10, x5, lsl #3]
    adrp x9, .SB190
    add x9, x9, :lo12:.SB190
    bl __fn_http____token_is.r
    cbz x0, .Lssa_main_228
.Lssa_main_1134:
    .loc 2 1700 8
    adrp x9, .SB189
    add x9, x9, :lo12:.SB189
    add x21, x21, #1
    sxtw x10, w21
    mov x0, x20
    bl __fn_http____field_at.r
    mov x21, x0
    cmp x21, #0
    b.ge .Lssa_main_1136
.Lssa_main_229:
    .loc 2 1702 3
    mov x21, #1
    b .Lssa_main_225
.Lssa_main_228:
    .loc 2 1698 7
    mov x21, #417
.Lssa_main_227:
.Lssa_main_225:
    mov x10, #-1
    cmp x19, x10
    b.ne .Lssa_main_222
.Lssa_main_224:
    .loc 2 1231 5
    adrp x10, .SB187
    add x10, x10, :lo12:.SB187
    ldr x4, [sp, #72]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_main_1153
.Lssa_main_1152:
    ldr x4, [sp, #72]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn3957
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn3957
    ldr x0, [sp, #72]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd3957
.Lssa_main_streqn3957:
    mov x0, #0
.Lssa_main_streqd3957:
    b .Lssa_main_1154
.Lssa_main_1153:
    mov x0, #0
.Lssa_main_1154:
    cbnz x0, .Lssa_main_211
    b .Lssa_main_213
.Lssa_main_222:
    mov x10, #-2
    cmp x19, x10
    b.eq .Lssa_main_211
.Lssa_main_219:
    .loc 2 1236 3
    ldr x10, [x20, #16]
    ldr x6, [x10]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x9, [x10, x5, lsl #3]
    .loc 2 1237 3
.Lssa_main_218:
    ldr x10, [x9, #8]
    ldr x8, [x9, #0]
    mov x9, #0
.Lssa_main_1161:
    cmp x9, x10
    b.ge .Lssa_main_213
.Lssa_main_1165:
    .loc 2 1239 5
    ldrb w12, [x8, x9]
    cmp x12, #33
    b.lt .Lssa_main_211
.Lssa_main_1164:
    cmp x12, #126
    b.gt .Lssa_main_211
.Lssa_main_1162:
    .loc 2 1243 7
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_main_1165
.Lssa_main_213:
    cmp x21, #417
    b.ne .Lssa_main_209
.Lssa_main_212:
    .loc 2 1710 5
    mov x9, #417
    b .Lssa_main_208
.Lssa_main_211:
    .loc 2 1707 5
    mov x9, #400
    b .Lssa_main_208
.Lssa_main_209:
    .loc 2 1712 3
    mov x9, #0
.Lssa_main_208:
    cmp x9, #0
    b.le .Lssa_main_205
.Lssa_main_1191:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_205:
    mov x9, #-1
    cmp x28, x9
    b.ne .Lssa_main_200
.Lssa_main_203:
    mov x9, #-1
    cmp x25, x9
    b.ne .Lssa_main_190
.Lssa_main_202:
    .loc 2 1159 5
    mov x28, #1
    mov x21, #0
    b .Lssa_main_182
.Lssa_main_200:
    mov x9, #-1
    cmp x25, x9
    b.eq .Lssa_main_199
.Lssa_main_1204:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_199:
    mov x9, #-2
    cmp x28, x9
    b.ne .Lssa_main_197
.Lssa_main_1208:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_197:
    .loc 2 1212 3
    ldr x9, [x20, #16]
    ldr x6, [x9]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x8, [x9, x5, lsl #3]
    adrp x9, .SB191
    add x9, x9, :lo12:.SB191
    mov x1, x9
    mov x0, x8
    str x1, [sp, #-16]!
    str x0, [sp, #-16]!
    bl __fn___fern_str_split
    add sp, sp, #32
    mov x28, x0
    ldr x9, [x28, #0]
    sub w9, w9, #1
    ldr x6, [x28]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x0, [x28, x5, lsl #3]
    adrp x9, .SB192
    add x9, x9, :lo12:.SB192
    bl __fn_http____token_is.r
    cbnz x0, .Lssa_main_195
.Lssa_main_1213:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    tst x28, #1
    b.ne .Lssa_main_uq1213
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_uq1213
    ldur w5, [x28, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq1213us
    bl __fern_san_abort_uaf
.Lssa_main_uq1213us:
    cmp w5, #1
.Lssa_main_uq1213:
    b.ne .Lssa_main_1217
.Lssa_main_1215:
    mov x21, #0
.Lssa_main_1219:
    ldr x9, [x28, #0]
    cmp x21, x9
    b.ge .Lssa_main_1217
.Lssa_main_1220:
    add x5, x21, #1
    ldr x9, [x28, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x21, x21, #1
    b .Lssa_main_1219
.Lssa_main_1217:
    mov x0, x28
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_195:
    .loc 2 1216 3
.Lssa_main_194:
    mov x21, #0
.Lssa_main_1224:
    add x9, x21, #1
    sxtw x9, w9
    ldr x19, [x28, #0]
    cmp x9, x19
    b.ge .Lssa_main_193
.Lssa_main_1227:
    ldr x6, [x28]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x28, x5, lsl #3]
    adrp x9, .SB192
    add x9, x9, :lo12:.SB192
    bl __fn_http____token_is.r
    cbz x0, .Lssa_main_1225
.Lssa_main_1232:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    tst x28, #1
    b.ne .Lssa_main_uq1232
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_uq1232
    ldur w5, [x28, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq1232us
    bl __fern_san_abort_uaf
.Lssa_main_uq1232us:
    cmp w5, #1
.Lssa_main_uq1232:
    b.ne .Lssa_main_1237
.Lssa_main_1235:
    mov x23, #0
.Lssa_main_1239:
    ldr x9, [x28, #0]
    cmp x23, x9
    b.ge .Lssa_main_1237
.Lssa_main_1240:
    add x5, x23, #1
    ldr x9, [x28, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x23, x23, #1
    b .Lssa_main_1239
.Lssa_main_1237:
    mov x0, x28
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_1225:
    .loc 2 1221 7
    add x21, x21, #1
    sxtw x21, w21
    b .Lssa_main_1224
.Lssa_main_193:
    tst x28, #1
    b.ne .Lssa_main_uq193
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_uq193
    ldur w5, [x28, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq193us
    bl __fern_san_abort_uaf
.Lssa_main_uq193us:
    cmp w5, #1
.Lssa_main_uq193:
    b.ne .Lssa_main_1248
.Lssa_main_1246:
    mov x21, #0
.Lssa_main_1250:
    ldr x9, [x28, #0]
    cmp x21, x9
    b.ge .Lssa_main_1248
.Lssa_main_1251:
    add x5, x21, #1
    ldr x9, [x28, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x21, x21, #1
    b .Lssa_main_1250
.Lssa_main_1248:
    mov x0, x28
    bl __fn___fern_arr_dec.r
    cmp x19, #1
    b.le .Lssa_main_192
.Lssa_main_1254:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_192:
    mov x28, #0
    mov x21, #0
    b .Lssa_main_182
.Lssa_main_190:
    mov x9, #-2
    cmp x25, x9
    b.ne .Lssa_main_188
.Lssa_main_1259:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_188:
    .loc 2 1164 3
    ldr x9, [x20, #16]
    ldr x6, [x9]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x21, [x9, x5, lsl #3]
    ldr x9, [x21, #8]
    cmp x9, #0
    b.ne .Lssa_main_186
.Lssa_main_1263:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_186:
    .loc 2 1168 3
    .loc 2 1169 3
.Lssa_main_185:
    ldr x25, [x21, #8]
    ldr x19, [x21, #0]
    mov x21, #0
    mov x28, #0
.Lssa_main_1267:
    cmp x28, x25
    b.ge .Lssa_main_184
.Lssa_main_1275:
    .loc 2 1171 5
    ldrb w23, [x19, x28]
    cmp x23, #48
    b.ge .Lssa_main_1274
.Lssa_main_1280:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_1274:
    cmp x23, #57
    b.le .Lssa_main_1272
.Lssa_main_1284:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_1272:
    .loc 2 1175 5
    sub x23, x23, #48
    sxtw x23, w23
    ldr x9, =214748364
    cmp x21, x9
    b.le .Lssa_main_1271
.Lssa_main_1288:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_1271:
    ldr x9, =214748364
    cmp x21, x9
    b.ne .Lssa_main_1268
.Lssa_main_1270:
    cmp x23, #7
    b.le .Lssa_main_1268
.Lssa_main_1296:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_1
.Lssa_main_1268:
    .loc 2 1179 9
    mov x9, #10
    mul x9, x21, x9
    add x9, x9, x23
    sxtw x21, w9
    .loc 2 1180 7
    add x28, x28, #1
    cmp x28, x25
    b.lt .Lssa_main_1275
.Lssa_main_184:
    mov x28, #1
.Lssa_main_183:
.Lssa_main_182:
    .loc 2 1960 3
    mov x0, x22
    ldr x9, [sp, #96]
    ldr x10, [sp, #104]
    ldr x11, [sp, #112]
    bl __fn_http____shared_string.r
    bl __fn___fern_str_free.r
    ldr x4, [sp, #96]
    ldr x5, [sp, #80]
    add x9, x4, x5
    sxtw x19, w9
.Lssa_main_181:
    .loc 2 2354 3
.Lssa_main_180:
    mov x25, #0
.Lssa_main_1302:
    cmp x26, #0
    b.lt .Lssa_main_179
.Lssa_main_1309:
    ldr x23, [x20, #16]
    ldr x6, [x23]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    ldr x0, [x23, x5, lsl #3]
    adrp x9, .SB193
    add x9, x9, :lo12:.SB193
    bl __fn_http____lists_token.r
    cbz x0, .Lssa_main_1306
.Lssa_main_1308:
    .loc 2 2358 13
    mov x25, #1
.Lssa_main_1307:
.Lssa_main_1306:
    ldr x6, [x23]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    ldr x0, [x23, x5, lsl #3]
    adrp x9, .SB194
    add x9, x9, :lo12:.SB194
    bl __fn_http____lists_token.r
.Lssa_main_1303:
    .loc 2 2363 8
    adrp x9, .SB63
    add x9, x9, :lo12:.SB63
    add x26, x26, #1
    sxtw x10, w26
    mov x0, x20
    bl __fn_http____field_at.r
    mov x26, x0
    cmp x26, #0
    b.ge .Lssa_main_1309
.Lssa_main_179:
    cbnz x25, .Lssa_main_171
.Lssa_main_176:
    adrp x10, .SB186
    add x10, x10, :lo12:.SB186
    ldr x4, [sp, #72]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_main_171
.Lssa_main_1331:
    ldr x4, [sp, #72]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn4221
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn4221
    ldr x0, [sp, #72]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd4221
.Lssa_main_streqn4221:
    mov x0, #0
.Lssa_main_streqd4221:
.Lssa_main_171:
    cbz x28, .Lssa_main_162
.Lssa_main_170:
    ldr x5, [sp, #120]
    cmp x21, x5
    b.le .Lssa_main_167
.Lssa_main_1343:
    mov x0, x22
    bl __fn___fern_arr_dec.r
.Lssa_main_169:
    .loc 2 1497 9
    mov x5, #413
    str x5, [sp, #128]
    b .Lssa_main_98
.Lssa_main_167:
    add x9, x19, x21
    sxtw x9, w9
    ldr x10, [x22, #0]
    cmp x9, x10
    b.le .Lssa_main_164
.Lssa_main_1348:
    mov x0, x22
    bl __fn___fern_arr_dec.r
.Lssa_main_166:
    .loc 2 1500 9
    mov x5, #1
    str x5, [sp, #128]
    b .Lssa_main_98
.Lssa_main_164:
    .loc 2 1502 7
    add x21, x19, x21
    sxtw x21, w21
    str x22, [sp, #-16]!
    str x19, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_bytes_range
    add sp, sp, #48
    mov x28, x0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x28
    bl __fn___fern_arr_dec.r
    mov x5, #2
    str x5, [sp, #128]
    b .Lssa_main_98
.Lssa_main_162:
    adrp x10, .SB187
    add x10, x10, :lo12:.SB187
    ldr x4, [sp, #72]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_main_1355
.Lssa_main_1354:
    ldr x4, [sp, #72]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn4250
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn4250
    ldr x0, [sp, #72]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd4250
.Lssa_main_streqn4250:
    mov x0, #0
.Lssa_main_streqd4250:
    b .Lssa_main_1356
.Lssa_main_1355:
    mov x0, #0
.Lssa_main_1356:
    cbnz x0, .Lssa_main_158
.Lssa_main_1357:
    mov x0, x22
    bl __fn___fern_arr_dec.r
.Lssa_main_161:
    .loc 2 1506 9
    mov x5, #400
    str x5, [sp, #128]
    b .Lssa_main_98
.Lssa_main_158:
    .loc 2 1266 3
    adrp x10, .K0
    add x10, x10, :lo12:.K0
.Lssa_main_157:
    ldr x28, [sp, #128]
    ldr x21, [sp, #120]
    mov x26, x10
.Lssa_main_1362:
.Lssa_main_1421:
    .loc 2 1316 3
    ldr x25, [x22, #0]
    .loc 2 1317 3
    add x10, x19, x28
    sxtw x10, w10
    cmp x10, x25
    csel x23, x25, x10, gt
    .loc 2 1321 3
    mov x0, x22
    mov x9, x19
    mov x10, x23
    bl __fn_http____find_crlf.r
    mov x27, x0
    cmp x27, #0
    csel x10, x27, x23, ge
    mov x0, x22
    mov x9, x19
    bl __fn_http____crlf_terminated.r
    cbz x0, .Lssa_main_1410
.Lssa_main_1413:
    cmp x27, #0
    b.ge .Lssa_main_1405
.Lssa_main_1412:
    add x10, x19, x28
    sxtw x10, w10
    cmp x25, x10
    b.lt .Lssa_main_1408
.Lssa_main_1411:
    .loc 2 1331 7
    mov x10, #431
    mov x27, #0
    mov x25, #0
    b .Lssa_main_1386
.Lssa_main_1410:
    .loc 2 1327 5
    mov x10, #400
    mov x27, #0
    mov x25, #0
    b .Lssa_main_1386
.Lssa_main_1408:
    .loc 2 1333 5
    mov x10, #1
    mov x27, #0
    mov x25, #0
    b .Lssa_main_1386
.Lssa_main_1405:
    .loc 2 1346 3
.Lssa_main_1404:
    mov x9, x19
    mov x10, #0
.Lssa_main_1448:
    cmp x9, x27
    b.ge .Lssa_main_1403
.Lssa_main_1480:
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w8, [x5, #8]
.Lssa_main_1479:
    cmp x8, #48
    b.lo .Lssa_main_1475
.Lssa_main_1478:
    cmp x8, #57
    b.hi .Lssa_main_1475
.Lssa_main_1477:
    .loc 2 1250 5
    sub x12, x8, #48
    sxtw x12, w12
    b .Lssa_main_1466
.Lssa_main_1475:
    cmp x8, #97
    b.lo .Lssa_main_1471
.Lssa_main_1474:
    cmp x8, #102
    b.hi .Lssa_main_1471
.Lssa_main_1473:
    .loc 2 1253 5
    sub x12, x8, #87
    sxtw x12, w12
    b .Lssa_main_1466
.Lssa_main_1471:
    cmp x8, #65
    b.lo .Lssa_main_1467
.Lssa_main_1470:
    cmp x8, #70
    b.hi .Lssa_main_1467
.Lssa_main_1469:
    .loc 2 1256 5
    sub x12, x8, #55
    sxtw x12, w12
    b .Lssa_main_pool_1331
    .ltorg
.Lssa_main_pool_1331:
    b .Lssa_main_1466
.Lssa_main_1467:
    .loc 2 1258 3
    mov x12, #-1
.Lssa_main_1466:
    cmp x12, #0
    b.lt .Lssa_main_1403
.Lssa_main_1464:
    cmp x8, #48
    b.lo .Lssa_main_1460
.Lssa_main_1463:
    cmp x8, #57
    b.hi .Lssa_main_1460
.Lssa_main_1462:
    .loc 2 1250 5
    sub x12, x8, #48
    mov x8, x12
    b .Lssa_main_1451
.Lssa_main_1460:
    cmp x8, #97
    b.lo .Lssa_main_1456
.Lssa_main_1459:
    cmp x8, #102
    b.hi .Lssa_main_1456
.Lssa_main_1458:
    .loc 2 1253 5
    sub x12, x8, #87
    mov x8, x12
    b .Lssa_main_1451
.Lssa_main_1456:
    cmp x8, #65
    b.lo .Lssa_main_1452
.Lssa_main_1455:
    cmp x8, #70
    b.hi .Lssa_main_1452
.Lssa_main_1454:
    .loc 2 1256 5
    sub x8, x8, #55
    b .Lssa_main_1451
.Lssa_main_1452:
    .loc 2 1258 3
    mov x8, #-1
.Lssa_main_1451:
    lsl x12, x10, #4
    add x12, x12, x8
    sxtw x12, w12
    cmp x12, x21
    b.gt .Lssa_main_1401
.Lssa_main_1449:
    .loc 2 1353 10
    lsl x12, x10, #4
    add x12, x12, x8
    sxtw x10, w12
    .loc 2 1354 7
    add x9, x9, #1
    cmp x9, x27
    b.lt .Lssa_main_1480
.Lssa_main_1403:
    cmp x9, x19
    b.ne .Lssa_main_1399
.Lssa_main_1402:
    .loc 2 1357 5
    mov x10, #400
    mov x25, #0
    b .Lssa_main_1398
.Lssa_main_1401:
    .loc 2 1351 7
    mov x10, #413
    mov x25, #0
    b .Lssa_main_1398
.Lssa_main_1399:
    .loc 2 1359 3
    mov x25, x10
    mov x10, #0
.Lssa_main_1398:
    cmp x10, #0
    b.eq .Lssa_main_1560
.Lssa_main_1397:
    .loc 2 1337 5
    mov x27, #0
    mov x25, #0
    b .Lssa_main_1386
.Lssa_main_1395:
.Lssa_main_1560:
    cmp x9, x27
    b.ge .Lssa_main_1388
.Lssa_main_1595:
.Lssa_main_1601:
    cmp x9, x27
    b.ge .Lssa_main_1593
.Lssa_main_1607:
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
.Lssa_main_1606:
    .loc 2 838 3
    cmp x10, #32
    b.eq .Lssa_main_1602
.Lssa_main_1604:
    cmp x10, #9
    b.ne .Lssa_main_1593
.Lssa_main_1602:
    .loc 2 1389 7
    add x9, x9, #1
    cmp x9, x27
    b.lt .Lssa_main_1607
.Lssa_main_1593:
    cmp x9, x27
    b.ge .Lssa_main_1387
.Lssa_main_1592:
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
    cmp x10, #59
    b.ne .Lssa_main_1387
.Lssa_main_1590:
    .loc 2 1369 7
    add x9, x9, #1
.Lssa_main_1589:
    mov x23, x9
.Lssa_main_1631:
    cmp x23, x27
    b.ge .Lssa_main_1587
.Lssa_main_1637:
    ldr x6, [x22]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    ldrb w9, [x5, #8]
.Lssa_main_1636:
    .loc 2 838 3
    cmp x9, #32
    b.eq .Lssa_main_1632
.Lssa_main_1634:
    cmp x9, #9
    b.ne .Lssa_main_1587
.Lssa_main_1632:
    .loc 2 1389 7
    add x23, x23, #1
    cmp x23, x27
    b.lt .Lssa_main_1637
.Lssa_main_1587:
    .loc 2 1395 3
    adrp x9, .K8
    add x9, x9, :lo12:.K8
    mov x2, x9
    mov x1, x23
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L136
    mov x1, #0
.L136:
    adrp x9, .S70
    add x9, x9, :lo12:.S70
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L139
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L137:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L138
    add x5, x5, #16
    cmp x5, x8
    b.ls .L137
    sub x1, x5, x0
    b .L139
.L138:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L140
.L139:
    add x10, x9, #96
.L143:
    cmp x1, x3
    b.ge .L141
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L140
    add x1, x1, #1
    b .L143
.L140:
    str x1, [sp, #-16]!
    b .L142
.L141:
    str x3, [sp, #-16]!
.L142:
    ldr x0, [sp], #16
    cmp x0, x27
    csel x0, x27, x0, gt
    cmp x0, x23
    b.eq .Lssa_main_1387
.Lssa_main_1585:
    mov x9, x0
.Lssa_main_1666:
    cmp x9, x27
    b.ge .Lssa_main_1583
.Lssa_main_1672:
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
.Lssa_main_1671:
    .loc 2 838 3
    cmp x10, #32
    b.eq .Lssa_main_1667
.Lssa_main_1669:
    cmp x10, #9
    b.ne .Lssa_main_1583
.Lssa_main_1667:
    .loc 2 1389 7
    add x9, x9, #1
    cmp x9, x27
    b.lt .Lssa_main_1672
.Lssa_main_1583:
    cmp x9, x27
    b.ge .Lssa_main_1575
.Lssa_main_1582:
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
    cmp x10, #61
    b.ne .Lssa_main_1575
.Lssa_main_1581:
    .loc 2 1377 9
    add x9, x9, #1
.Lssa_main_1580:
    mov x23, x9
.Lssa_main_1696:
    cmp x23, x27
    b.ge .Lssa_main_1577
.Lssa_main_1702:
    ldr x6, [x22]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    ldrb w9, [x5, #8]
.Lssa_main_1701:
    .loc 2 838 3
    cmp x9, #32
    b.eq .Lssa_main_1697
.Lssa_main_1699:
    cmp x9, #9
    b.ne .Lssa_main_1577
.Lssa_main_1697:
    .loc 2 1389 7
    add x23, x23, #1
    cmp x23, x27
    b.lt .Lssa_main_1702
.Lssa_main_1577:
    cmp x23, x27
    b.lt .Lssa_main_1573
.Lssa_main_1576:
    .loc 2 1404 5
    mov x9, #-1
    mov x10, x9
    b .Lssa_main_1563
.Lssa_main_1575:
    mov x9, x0
    b .Lssa_main_1560
.Lssa_main_1573:
    ldr x6, [x22]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_main_1568
.Lssa_main_1572:
    .loc 2 1395 3
    adrp x9, .K8
    add x9, x9, :lo12:.K8
    mov x2, x9
    mov x1, x23
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L144
    mov x1, #0
.L144:
    adrp x9, .S70
    add x9, x9, :lo12:.S70
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L147
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L145:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L146
    add x5, x5, #16
    cmp x5, x8
    b.ls .L145
    sub x1, x5, x0
    b .L147
.L146:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L148
.L147:
    add x10, x9, #96
.L151:
    cmp x1, x3
    b.ge .L149
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L148
    add x1, x1, #1
    b .L151
.L148:
    str x1, [sp, #-16]!
    b .L150
.L149:
    str x3, [sp, #-16]!
.L150:
    ldr x0, [sp], #16
    cmp x0, x27
    csel x0, x27, x0, gt
    cmp x0, x23
    b.ne .Lssa_main_1570
.Lssa_main_1571:
    .loc 2 1409 7
    mov x9, #-1
    mov x10, x9
    b .Lssa_main_1563
.Lssa_main_1570:
    mov x10, x0
    b .Lssa_main_1563
.Lssa_main_1568:
    .loc 2 1413 3
    add x23, x23, #1
.Lssa_main_1567:
.Lssa_main_1743:
    cmp x23, x27
    b.ge .Lssa_main_1566
.Lssa_main_1758:
    .loc 2 1415 5
    ldr x6, [x22]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_main_1565
.Lssa_main_1756:
    .loc 2 1420 9
    add x10, x23, #1
    cmp x9, #92
    csel x10, x10, x23, eq
    cmp x10, x27
    b.ge .Lssa_main_1564
.Lssa_main_1752:
    ldr x6, [x22]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    ldrb w9, [x5, #8]
.Lssa_main_1751:
    .loc 2 1431 3
    cmp x9, #9
    b.eq .Lssa_main_1744
.Lssa_main_1749:
    cmp x9, #32
    b.lo .Lssa_main_1564
.Lssa_main_1748:
    cmp x9, #127
    b.eq .Lssa_main_1564
.Lssa_main_1744:
    .loc 2 1425 7
    add x23, x10, #1
    cmp x23, x27
    b.lt .Lssa_main_1758
.Lssa_main_1566:
    .loc 2 1427 3
    mov x10, #-1
    b .Lssa_main_1563
.Lssa_main_1565:
    .loc 2 1417 7
    add x23, x23, #1
    mov x10, x23
    b .Lssa_main_1563
.Lssa_main_1564:
    .loc 2 1423 7
    mov x10, #-1
.Lssa_main_1563:
    cmp x10, #0
    b.lt .Lssa_main_1387
.Lssa_main_1562:
    mov x9, x10
.Lssa_main_1561:
    cmp x9, x27
    b.lt .Lssa_main_1601
.Lssa_main_1388:
    .loc 2 1342 3
    mov x10, #2
    b .Lssa_main_1386
.Lssa_main_1387:
    .loc 2 1340 5
    mov x10, #400
    mov x27, #0
    mov x25, #0
.Lssa_main_1386:
    cmp x10, #2
    b.ne .Lssa_main_156
.Lssa_main_1384:
    .loc 2 1273 5
    add x27, x27, #2
    sxtw x27, w27
    .loc 2 1275 12
    sub x19, x27, x19
    sub x28, x28, x19
    sub x28, x28, #2
    sxtw x28, w28
    cmp x28, #0
    b.lt .Lssa_main_155
.Lssa_main_1382:
    cmp x25, #0
    b.eq .Lssa_main_154
.Lssa_main_1380:
    .loc 2 1282 5
    add x9, x27, x25
    sxtw x9, w9
.Lssa_main_1379:
    .loc 2 1297 3
    ldr x12, [x22, #0]
    cmp x9, x12
    b.ge .Lssa_main_1375
.Lssa_main_1378:
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w8, [x5, #8]
    cmp x8, #13
    b.eq .Lssa_main_1375
.Lssa_main_1377:
    .loc 2 1299 5
    mov x9, #0
    b .Lssa_main_1367
.Lssa_main_1375:
    add x8, x9, #1
    sxtw x8, w8
    cmp x8, x12
    b.ge .Lssa_main_1371
.Lssa_main_1374:
    add w8, w9, #1
    ldr x6, [x22]
    cmp x8, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x8
    ldrb w15, [x5, #8]
    cmp x15, #10
    b.eq .Lssa_main_1371
.Lssa_main_1373:
    .loc 2 1302 5
    mov x9, #0
    b .Lssa_main_1367
.Lssa_main_1371:
    add x9, x9, #2
    sxtw x9, w9
    cmp x9, x12
    b.le .Lssa_main_1368
.Lssa_main_1370:
    .loc 2 1305 5
    mov x9, #1
    b .Lssa_main_1367
.Lssa_main_1368:
    .loc 2 1307 3
    mov x9, #2
.Lssa_main_1367:
    cmp x9, #0
    b.eq .Lssa_main_151
.Lssa_main_1365:
    cmp x9, #1
    b.eq .Lssa_main_150
.Lssa_main_1363:
    .loc 2 1289 11
    mov x0, x26
    mov x1, x27
    str x10, [sp, #64]
    bl __fern_arr_push_owned
    ldr x10, [sp, #64]
    mov x1, x25
    str x10, [sp, #64]
    bl __fern_arr_push_owned
    ldr x10, [sp, #64]
    mov x26, x0
    .loc 2 1290 10
    sub x21, x21, x25
    sxtw x21, w21
    .loc 2 1291 8
    add x25, x27, x25
    add x25, x25, #2
    sxtw x19, w25
    b .Lssa_main_1421
.Lssa_main_156:
    mov x25, x10
    b .Lssa_main_107
.Lssa_main_155:
    .loc 2 1277 7
    mov x25, #431
    b .Lssa_main_107
.Lssa_main_154:
    .loc 2 1280 7
    add x28, x28, #2
.Lssa_main_153:
    .loc 2 1440 3
    ldr x19, [x22, #0]
    .loc 2 1442 3
    add x10, x27, x28
    sxtw x10, w10
    cmp x10, x19
    csel x25, x19, x10, gt
    .loc 2 1446 3
    sub x10, x27, #2
    sxtw x10, w10
    b .Lssa_main_147
.Lssa_main_151:
    .loc 2 1284 7
    mov x25, #400
    b .Lssa_main_107
.Lssa_main_150:
    .loc 2 1287 7
    mov x25, #1
    b .Lssa_main_107
.Lssa_main_147:
    .loc 2 1073 3
    mov x9, #13
    mov x2, x10
    mov x1, x9
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L152
    mov x2, #0
.L152:
    cmp x1, #255
    b.hi .L157
    cmp x2, x3
    b.ge .L157
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L154
.L153:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L159
    cmp x5, x8
    b.ls .L153
.L154:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L155
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L155
    sub x5, x5, #16
    b .L160
.L159:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L160
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L160:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L158
.L155:
    cmp x5, x6
    b.ge .L157
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L161
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L157
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L157
    add x5, x5, x4
    b .L156
.L161:
    cmp x5, x6
    b.ge .L157
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L156
    add x5, x5, #1
    b .L161
.L156:
    sub x2, x5, x0
    b .L158
.L157:
    mov x2, #-1
.L158:
    mov x0, x2
.Lssa_main_146:
.Lssa_main_1862:
    cmp x0, #0
    b.lt .Lssa_main_145
.Lssa_main_1868:
    add x9, x0, #3
    sxtw x9, w9
    cmp x9, x25
    b.ge .Lssa_main_145
.Lssa_main_1867:
    add w9, w0, #1
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.ne .Lssa_main_1863
.Lssa_main_1866:
    add w10, w0, #2
    ldr x6, [x22]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    ldrb w9, [x5, #8]
    cmp x9, #13
    b.ne .Lssa_main_1863
.Lssa_main_1865:
    add w9, w0, #3
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_main_144
.Lssa_main_1863:
    .loc 2 1078 7
    add x10, x0, #1
    sxtw x10, w10
    mov x9, #13
    mov x2, x10
    mov x1, x9
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L162
    mov x2, #0
.L162:
    cmp x1, #255
    b.hi .L167
    cmp x2, x3
    b.ge .L167
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L164
.L163:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L169
    cmp x5, x8
    b.ls .L163
.L164:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L165
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L165
    sub x5, x5, #16
    b .L170
.L169:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L170
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L170:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L168
.L165:
    cmp x5, x6
    b.ge .L167
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L171
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L167
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L167
    add x5, x5, x4
    b .L166
.L171:
    cmp x5, x6
    b.ge .L167
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L166
    add x5, x5, #1
    b .L171
.L166:
    sub x2, x5, x0
    b .L168
.L167:
    mov x2, #-1
.L168:
    mov x0, x2
    cmp x0, #0
    b.ge .Lssa_main_1868
.Lssa_main_145:
    .loc 2 1080 3
    mov x9, #-1
    mov x21, x9
    b .Lssa_main_143
.Lssa_main_144:
    mov x21, x0
.Lssa_main_143:
    cmp x21, #0
    csel x10, x21, x25, ge
    cmp x10, x27
    b.le .Lssa_main_137
.Lssa_main_139:
    mov x0, x22
    mov x9, x27
    bl __fn_http____crlf_terminated.r
    cbz x0, .Lssa_main_134
.Lssa_main_137:
    cmp x21, #0
    b.ge .Lssa_main_130
.Lssa_main_136:
    add x28, x27, x28
    sxtw x28, w28
    cmp x19, x28
    b.lt .Lssa_main_132
.Lssa_main_135:
    .loc 2 1456 7
    mov x25, #431
    b .Lssa_main_107
.Lssa_main_134:
    .loc 2 1452 5
    mov x25, #400
    b .Lssa_main_107
.Lssa_main_132:
    .loc 2 1458 5
    mov x25, #1
    b .Lssa_main_107
.Lssa_main_130:
    cmp x21, x27
    b.le .Lssa_main_114
.Lssa_main_129:
    .loc 6 90 3
    adrp x28, .K1
    add x28, x28, :lo12:.K1
.Lssa_main_128:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
    .loc 2 871 3
    .loc 2 872 3
.Lssa_main_127:
    mov x23, x27
    mov x27, x0
    mov x19, #1
    mov x25, #0
.Lssa_main_1920:
    cmp x23, x21
    b.lt .Lssa_main_1974
.Lssa_main_1977:
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_126
.Lssa_main_1974:
    .loc 2 1395 3
    adrp x10, .K8
    add x10, x10, :lo12:.K8
    mov x2, x10
    mov x1, x23
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L172
    mov x1, #0
.L172:
    adrp x9, .S70
    add x9, x9, :lo12:.S70
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L175
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L173:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L174
    add x5, x5, #16
    cmp x5, x8
    b.ls .L173
    sub x1, x5, x0
    b .L175
.L174:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L176
.L175:
    add x10, x9, #96
.L179:
    cmp x1, x3
    b.ge .L177
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L176
    add x1, x1, #1
    b .L179
.L176:
    str x1, [sp, #-16]!
    b .L178
.L177:
    str x3, [sp, #-16]!
.L178:
    ldr x0, [sp], #16
    cmp x0, x21
    csel x10, x21, x0, gt
    cmp x10, x23
    b.eq .Lssa_main_1971
.Lssa_main_1973:
    cmp x10, x21
    b.ge .Lssa_main_1971
.Lssa_main_1972:
    ldr x6, [x22]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    ldrb w9, [x5, #8]
    cmp x9, #58
    b.eq .Lssa_main_1969
.Lssa_main_1971:
    .loc 2 926 5
    mov x9, #-1
    mov x10, x21
    b .Lssa_main_1957
.Lssa_main_1969:
    .loc 2 928 3
    add x9, x10, #1
.Lssa_main_1968:
    .loc 2 701 3
    mov x12, #13
    str x10, [sp, #64]
    mov x2, x9
    mov x1, x12
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L180
    mov x2, #0
.L180:
    cmp x1, #255
    b.hi .L185
    cmp x2, x3
    b.ge .L185
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L182
.L181:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L187
    cmp x5, x8
    b.ls .L181
.L182:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L183
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L183
    sub x5, x5, #16
    b .L188
.L187:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L188
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L188:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L186
.L183:
    cmp x5, x6
    b.ge .L185
    and x7, x5, #4095
    cmp x7, #4080
    b.hi .L189
    ld1 {v0.16b}, [x5]
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L185
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    sub x8, x6, x5
    cmp x4, x8
    b.hs .L185
    add x5, x5, x4
    b .L184
.L189:
    cmp x5, x6
    b.ge .L185
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L184
    add x5, x5, #1
    b .L189
.L184:
    sub x2, x5, x0
    b .L186
.L185:
    mov x2, #-1
.L186:
    mov x0, x2
    ldr x10, [sp, #64]
    cmp x0, #0
    b.lt .Lssa_main_1966
.Lssa_main_1967:
    cmp x0, x21
    b.lt .Lssa_main_1964
.Lssa_main_1966:
    mov x0, x21
    b .Lssa_main_1960
.Lssa_main_1964:
    add x12, x0, #1
    cmp x12, x21
    b.ge .Lssa_main_1962
.Lssa_main_1963:
    add x12, x0, #1
    ldr x6, [x22]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x12
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_main_1960
.Lssa_main_1962:
    .loc 2 706 5
    mov x9, #-1
    mov x0, x9
.Lssa_main_1961:
.Lssa_main_1960:
    cmp x0, #0
    b.ge .Lssa_main_1958
.Lssa_main_1959:
    .loc 2 930 5
    mov x9, #-1
    mov x10, x21
    b .Lssa_main_1957
.Lssa_main_1958:
    mov x9, x10
    mov x10, x0
.Lssa_main_1957:
    cmp x9, #0
    b.ge .Lssa_main_1955
.Lssa_main_2025:
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    b .Lssa_main_122
.Lssa_main_1955:
    .loc 2 881 11
    add x12, x25, #1
    sxtw x25, w12
    cmp x25, #100
    b.le .Lssa_main_1953
.Lssa_main_2029:
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    b .Lssa_main_121
.Lssa_main_1953:
    .loc 2 885 5
    sub x12, x25, #1
    sxtw x15, w12
    cbz x19, .Lssa_main_1946
.Lssa_main_1952:
    ldr x12, [x28, #8]
    ldr x8, [x12, #0]
    cmp x15, x8
    b.lt .Lssa_main_1946
.Lssa_main_1951:
    cmp x15, #0
    b.le .Lssa_main_1948
.Lssa_main_2041:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x15, [sp, #48]
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_main_1950:
    tbnz x28, #0, .Lssa_main_rcinc5003
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcinc5003
    ldur w5, [x28, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5003sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5003sl:
    tbnz w5, #31, .Lssa_main_rcinc5003
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcinc5003:
    .loc 2 888 11
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x15, [sp, #48]
    mov x0, x28
    mov x9, x15
    bl __fn_http____leading_fields.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
    mov x27, x0
.Lssa_main_1949:
.Lssa_main_1948:
    .loc 2 890 12
    b .Lssa_main_pool_1806
    .ltorg
.Lssa_main_pool_1806:
    mov x19, #0
.Lssa_main_1947:
.Lssa_main_1946:
    .loc 2 892 5
    mov x8, #-1
    cmp x19, #0
    csel x8, x15, x8, ne
    .loc 2 896 5
    add x12, x9, #1
    sxtw x12, w12
.Lssa_main_1942:
.Lssa_main_2052:
    cmp x12, x10
    b.ge .Lssa_main_1940
.Lssa_main_2058:
    ldr x6, [x22]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x12
    ldrb w14, [x5, #8]
.Lssa_main_2057:
    .loc 2 838 3
    cmp x14, #32
    b.eq .Lssa_main_2053
.Lssa_main_2055:
    cmp x14, #9
    b.ne .Lssa_main_1940
.Lssa_main_2053:
    .loc 2 851 10
    add x12, x12, #1
    cmp x12, x10
    b.lt .Lssa_main_2058
.Lssa_main_1940:
    mov x14, x10
.Lssa_main_2074:
    cmp x14, x12
    b.le .Lssa_main_1939
.Lssa_main_2080:
    sub x11, x14, #1
    ldr x6, [x22]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    ldrb w13, [x5, #8]
.Lssa_main_2079:
    .loc 2 838 3
    cmp x13, #32
    b.eq .Lssa_main_2075
.Lssa_main_2077:
    cmp x13, #9
    b.ne .Lssa_main_1939
.Lssa_main_2075:
    .loc 2 854 9
    sub x14, x14, #1
    cmp x14, x12
    b.gt .Lssa_main_2080
.Lssa_main_1939:
    cmp x8, #0
    b.lt .Lssa_main_1934
.Lssa_main_1938:
    ldr x13, [x28, #16]
    ldr x6, [x13]
    cmp x8, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x8, #1
    ldr x11, [x13, x5, lsl #3]
    ldr x13, [x11, #8]
    sub x11, x14, x12
    sxtw x11, w11
    cmp x13, x11
    b.ne .Lssa_main_1934
.Lssa_main_1937:
    ldr x11, [x28, #16]
    ldr x6, [x11]
    cmp x8, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x8, #1
    ldr x13, [x11, x5, lsl #3]
    .loc 2 2350 3
    ldr x2, [x13, #8]
    mov x1, #0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x4, x2
    mov x3, x1
    mov x2, x13
    mov x1, x12
    mov x0, x22
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L190_aop
    mov x1, #0
.L190_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L190_bop
    mov x3, #0
.L190_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L190_nok
    mov x4, #0
.L190_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L190_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L190_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L190_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L190_done
.L190_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L190_vec
.L190_short:
    cmp x10, #8
    b.lt .L190_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L190_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L190_eq
    add x8, x8, x14
.L190_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L190_done
.L190_w4:
    cmp x10, #4
    b.lt .L190_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L190_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L190_eq
    add x8, x8, x14
.L190_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L190_done
.L190_w2:
    cmp x10, #2
    b.lt .L190_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L190_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L190_eq
    add x8, x8, x14
.L190_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L190_done
.L190_tail:
    cmp x8, x13
    b.ge .L190_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L190_th
    add x8, x8, #1
    add x9, x9, #1
    b .L190_tail
.L190_th:
    sub x2, x8, x12
    b .L190_done
.L190_eq:
    mov x2, x4
.L190_done:
    mov x0, x2
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    ldr x1, [x13, #8]
    cmp x0, x1
    b.ne .Lssa_main_1934
.Lssa_main_1936:
    .loc 2 857 5
    ldr x6, [x11]
    cmp x8, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x8, #1
    ldr x1, [x11, x5, lsl #3]
    tbnz x1, #0, .Lssa_main_rcinc5070
    cmp x1, #16, lsl #12
    b.lo .Lssa_main_rcinc5070
    ldur w5, [x1, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5070sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5070sl:
    tbnz w5, #31, .Lssa_main_rcinc5070
    add w5, w5, #1
    stur w5, [x1, #-8]
.Lssa_main_rcinc5070:
    mov x11, x1
    b .Lssa_main_1930
.Lssa_main_1934:
    adrp x1, .K9
    add x1, x1, :lo12:.K9
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    mov x2, x1
    mov x1, x12
    mov x0, x22
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L191
    mov x1, #0
.L191:
    adrp x9, .S71
    add x9, x9, :lo12:.S71
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L194
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L192:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L193
    add x5, x5, #16
    cmp x5, x8
    b.ls .L192
    sub x1, x5, x0
    b .L194
.L193:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L195
.L194:
    add x10, x9, #96
.L198:
    cmp x1, x3
    b.ge .L196
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L195
    add x1, x1, #1
    b .L198
.L195:
    str x1, [sp, #-16]!
    b .L197
.L196:
    str x3, [sp, #-16]!
.L197:
    ldr x0, [sp], #16
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    cmp x0, x14
    b.ge .Lssa_main_1932
.Lssa_main_2109:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    b .Lssa_main_110
.Lssa_main_1932:
    .loc 2 713 5
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x15, [sp, #48]
    mov x0, x22
    mov x9, x12
    mov x10, x14
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x11, x0
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_main_2113:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    mov x0, x11
    bl __fn_utf8__is_valid.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
    cbnz x0, .Lssa_main_1930
.Lssa_main_2116:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    mov x0, x11
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
    b .Lssa_main_110
.Lssa_main_1931:
.Lssa_main_1930:
    cbz x19, .Lssa_main_1923
.Lssa_main_1929:
    .loc 2 899 11
    ldr x14, [x28, #8]
    ldr x6, [x14]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x15, #1
    ldr x12, [x14, x5, lsl #3]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x22
    mov x10, x9
    mov x11, x12
    mov x9, x23
    bl __fn_http____shared_string.r
    mov x14, x0
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    .loc 2 900 16
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    ldr x6, [x14, #8]
    ldr x7, [x12, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn5104
    mov x0, x14
    mov x9, x12
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd5104
.Lssa_main_streqn5104:
    mov x0, #0
.Lssa_main_streqd5104:
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    cbz x0, .Lssa_main_1927
.Lssa_main_1928:
    ldr x12, [x28, #16]
    ldr x6, [x12]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x15, #1
    ldr x1, [x12, x5, lsl #3]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x14, [sp, #40]
    str x15, [sp, #32]
    ldr x6, [x11, #8]
    ldr x7, [x1, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn5107
    mov x0, x11
    mov x9, x1
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd5107
.Lssa_main_streqn5107:
    mov x0, #0
.Lssa_main_streqd5107:
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x14, [sp, #40]
    ldr x15, [sp, #32]
    mov x12, x0
    b .Lssa_main_1926
.Lssa_main_1927:
    mov x12, #0
.Lssa_main_1926:
    cbz x12, .Lssa_main_2129
.Lssa_main_2128:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    mov x0, x14
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    mov x0, x11
    bl __fn___fern_str_free.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    b .Lssa_main_1925
.Lssa_main_2129:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    b .Lssa_main_1924
.Lssa_main_1925:
    mov x19, x12
    b .Lssa_main_1921
.Lssa_main_1924:
    tbnz x28, #0, .Lssa_main_rcinc5114
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcinc5114
    ldur w5, [x28, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5114sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5114sl:
    tbnz w5, #31, .Lssa_main_rcinc5114
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcinc5114:
    .loc 2 902 15
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x28
    mov x9, x15
    bl __fn_http____leading_fields.r
    mov x8, x0
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    tst x8, #1
    b.ne .Lssa_main_uq1924
    cmp x8, #16, lsl #12
    b.lo .Lssa_main_uq1924
    ldur w5, [x8, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq1924us
    bl __fern_san_abort_uaf
.Lssa_main_uq1924us:
    cmp w5, #1
.Lssa_main_uq1924:
    b.ne .Lssa_main_2134
.Lssa_main_2133:
    mov x15, x8
    b .Lssa_main_2135
.Lssa_main_2134:
    mov x15, #0
.Lssa_main_2135:
    .loc 6 301 3
    ldr x13, [x8, #8]
    cmp x15, #0
    b.ne .Lssa_main_2138
.Lssa_main_2136:
    tbnz x13, #0, .Lssa_main_rcinc5122
    cmp x13, #16, lsl #12
    b.lo .Lssa_main_rcinc5122
    ldur w5, [x13, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5122sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5122sl:
    tbnz w5, #31, .Lssa_main_rcinc5122
    add w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_main_rcinc5122:
.Lssa_main_2138:
    tst x13, #1
    b.ne .Lssa_main_uq2138
    cmp x13, #16, lsl #12
    b.lo .Lssa_main_uq2138
    ldur w5, [x13, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq2138us
    bl __fern_san_abort_uaf
.Lssa_main_uq2138us:
    cmp w5, #1
.Lssa_main_uq2138:
    b.ne .Lssa_main_2140
.Lssa_main_2139:
    mov x0, x13
    mov x1, x14
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    mov x24, x0
    b .Lssa_main_2141
.Lssa_main_2140:
    mov x0, x13
    mov x1, x14
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    bl __fern_arr_push
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    mov x24, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x13
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    str x8, [sp, #24]
    mov x0, x13
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    ldr x8, [sp, #24]
.Lssa_main_2141:
    ldr x13, [x8, #16]
    cmp x15, #0
    b.ne .Lssa_main_2144
.Lssa_main_2142:
    tbnz x13, #0, .Lssa_main_rcinc5132
    cmp x13, #16, lsl #12
    b.lo .Lssa_main_rcinc5132
    ldur w5, [x13, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5132sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5132sl:
    tbnz w5, #31, .Lssa_main_rcinc5132
    add w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_main_rcinc5132:
.Lssa_main_2144:
    tst x13, #1
    b.ne .Lssa_main_uq2144
    cmp x13, #16, lsl #12
    b.lo .Lssa_main_uq2144
    ldur w5, [x13, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq2144us
    bl __fern_san_abort_uaf
.Lssa_main_uq2144us:
    cmp w5, #1
.Lssa_main_uq2144:
    b.ne .Lssa_main_2146
.Lssa_main_2145:
    mov x0, x13
    mov x1, x11
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    mov x14, x0
    b .Lssa_main_2147
.Lssa_main_2146:
    mov x0, x13
    mov x1, x11
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    bl __fern_arr_push
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    mov x14, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x0, x13
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x13
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
.Lssa_main_2147:
    cmp x15, #0
    b.ne .Lssa_main_2149
.Lssa_main_2148:
    mov x13, #3
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    str x15, [sp, #-16]!
    str x13, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    adrp x13, .S0
    add x13, x13, :lo12:.S0
    str x13, [x0, #0]
    mov x13, x0
    b .Lssa_main_2150
.Lssa_main_2149:
    mov x13, x15
.Lssa_main_2150:
    cmp x15, #0
    b.ne .Lssa_main_2153
.Lssa_main_2152:
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    mov x0, x8
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
.Lssa_main_2153:
    str x24, [x13, #8]
    str x14, [x13, #16]
    mov x27, x13
    mov x19, x12
    b .Lssa_main_1921
.Lssa_main_1923:
    .loc 2 713 5
    str x10, [sp, #64]
    str x11, [sp, #56]
    mov x0, x22
    mov x10, x9
    mov x9, x23
    bl __fn___fern_string_from_bytes_range_u8.r
    mov x15, x0
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
.Lssa_main_2155:
    tst x27, #1
    b.ne .Lssa_main_uq2155
    cmp x27, #16, lsl #12
    b.lo .Lssa_main_uq2155
    ldur w5, [x27, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq2155us
    bl __fern_san_abort_uaf
.Lssa_main_uq2155us:
    cmp w5, #1
.Lssa_main_uq2155:
    b.ne .Lssa_main_2158
.Lssa_main_2157:
    mov x23, x27
    b .Lssa_main_2159
.Lssa_main_2158:
    mov x23, #0
.Lssa_main_2159:
    .loc 6 301 3
    ldr x24, [x27, #8]
    cmp x23, #0
    b.ne .Lssa_main_2162
.Lssa_main_2160:
    tbnz x24, #0, .Lssa_main_rcinc5159
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_rcinc5159
    ldur w5, [x24, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5159sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5159sl:
    tbnz w5, #31, .Lssa_main_rcinc5159
    add w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_main_rcinc5159:
.Lssa_main_2162:
    tst x24, #1
    b.ne .Lssa_main_uq2162
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_uq2162
    ldur w5, [x24, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq2162us
    bl __fern_san_abort_uaf
.Lssa_main_uq2162us:
    cmp w5, #1
.Lssa_main_uq2162:
    b.ne .Lssa_main_2164
.Lssa_main_2163:
    mov x0, x24
    mov x1, x15
    str x10, [sp, #64]
    str x11, [sp, #56]
    str x15, [sp, #48]
    bl __fern_arr_push_owned
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
    ldr x15, [sp, #48]
    mov x24, x0
    b .Lssa_main_2165
.Lssa_main_2164:
    mov x0, x24
    mov x1, x15
    str x10, [sp, #64]
    str x11, [sp, #56]
    bl __fern_arr_push
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
    mov x9, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    mov x0, x24
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    mov x0, x24
    bl __fn___fern_arr_dec.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    mov x24, x9
.Lssa_main_2165:
    ldr x9, [x27, #16]
    cmp x23, #0
    b.ne .Lssa_main_2168
.Lssa_main_2166:
    tbnz x9, #0, .Lssa_main_rcinc5169
    cmp x9, #16, lsl #12
    b.lo .Lssa_main_rcinc5169
    ldur w5, [x9, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5169sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5169sl:
    tbnz w5, #31, .Lssa_main_rcinc5169
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_main_rcinc5169:
.Lssa_main_2168:
    tst x9, #1
    b.ne .Lssa_main_uq2168
    cmp x9, #16, lsl #12
    b.lo .Lssa_main_uq2168
    ldur w5, [x9, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq2168us
    bl __fern_san_abort_uaf
.Lssa_main_uq2168us:
    cmp w5, #1
.Lssa_main_uq2168:
    b.ne .Lssa_main_2170
.Lssa_main_2169:
    mov x0, x9
    mov x1, x11
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x11, [sp, #48]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    mov x15, x0
    b .Lssa_main_2171
.Lssa_main_2170:
    mov x0, x9
    mov x1, x11
    str x9, [sp, #64]
    str x10, [sp, #56]
    bl __fern_arr_push
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    mov x15, x0
    str x9, [sp, #64]
    str x10, [sp, #56]
    str x15, [sp, #48]
    mov x0, x9
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
    str x10, [sp, #64]
    str x15, [sp, #56]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x10, [sp, #64]
    ldr x15, [sp, #56]
.Lssa_main_2171:
    cmp x23, #0
    b.ne .Lssa_main_2173
.Lssa_main_2172:
    mov x9, #3
    str x10, [sp, #64]
    str x15, [sp, #56]
    str x23, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x10, [sp, #64]
    ldr x15, [sp, #56]
    adrp x9, .S0
    add x9, x9, :lo12:.S0
    str x9, [x0, #0]
    mov x11, x0
    b .Lssa_main_2174
.Lssa_main_2173:
    mov x11, x23
.Lssa_main_2174:
    cmp x23, #0
    b.ne .Lssa_main_2177
.Lssa_main_2176:
    str x10, [sp, #64]
    str x11, [sp, #56]
    str x15, [sp, #48]
    mov x0, x27
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #64]
    ldr x11, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_main_2177:
    str x24, [x11, #8]
    str x15, [x11, #16]
    mov x27, x11
.Lssa_main_1922:
.Lssa_main_1921:
    .loc 2 912 8
    add x10, x10, #2
    sxtw x23, w10
    cmp x23, x21
    b.ge .Lssa_main_1977
    b .Lssa_main_1974
.Lssa_main_126:
    cbz x19, .Lssa_main_119
.Lssa_main_125:
    ldr x10, [x28, #8]
    ldr x9, [x10, #0]
    cmp x25, x9
    b.ne .Lssa_main_119
    b .Lssa_main_114
.Lssa_main_122:
    .loc 2 879 7
    mov x9, #400
    b .Lssa_main_108
.Lssa_main_121:
    .loc 2 883 7
    mov x9, #431
    b .Lssa_main_108
.Lssa_main_119:
    cbz x19, .Lssa_main_114
.Lssa_main_118:
    .loc 2 918 5
    mov x0, x28
    mov x9, x25
    bl __fn_http____leading_fields.r
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_114:
    .loc 2 1470 3
    mov x25, #2
    b .Lssa_main_107
.Lssa_main_110:
    .loc 2 909 9
    mov x9, #400
.Lssa_main_109:
.Lssa_main_108:
    mov x25, x9
.Lssa_main_107:
    cmp x25, #2
    b.eq .Lssa_main_104
.Lssa_main_2199:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x26
    bl __fn___fern_arr_dec.r
.Lssa_main_106:
    str x25, [sp, #128]
    b .Lssa_main_98
.Lssa_main_104:
    .loc 2 1512 7
.Lssa_main_103:
    .loc 2 1474 3
    .loc 2 1475 3
.Lssa_main_102:
    mov x9, #0
    mov x10, #1
.Lssa_main_2204:
    ldr x11, [x26, #0]
    cmp x10, x11
    b.ge .Lssa_main_101
.Lssa_main_2205:
    .loc 2 1477 11
    add x5, x10, #1
    ldr x11, [x26, x5, lsl #3]
    add x11, x9, x11
    sxtw x9, w11
    .loc 2 1478 7
    add x10, x10, #2
    sxtw x10, w10
    b .Lssa_main_2204
.Lssa_main_101:
    .loc 2 1480 3
    mov x0, x9
    bl __fern_alloc_bytes
    .loc 2 1482 5
    .loc 2 1481 3
.Lssa_main_100:
    mov x28, x0
    mov x25, #0
    mov x19, #0
.Lssa_main_2212:
    add x9, x25, #1
    sxtw x9, w9
    ldr x10, [x26, #0]
    cmp x9, x10
    b.lt .Lssa_main_2213
.Lssa_main_2215:
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x0, x28
    bl __fn___fern_arr_dec.r
    mov x0, x26
    bl __fn___fern_arr_dec.r
    b .Lssa_main_99
.Lssa_main_2213:
    .loc 2 1484 9
    add x10, x25, #1
    sxtw x23, w10
    asr x10, x25, #31
    orr x10, x23, x10
    ldr x6, [x26]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x9, [x26, x5, lsl #3]
    add x5, x23, #1
    ldr x10, [x26, x5, lsl #3]
    str x28, [sp, #-16]!
    str x19, [sp, #-16]!
    str x22, [sp, #-16]!
    str x9, [sp, #-16]!
    str x10, [sp, #-16]!
    bl __fn___fern_bytes_into
    add sp, sp, #80
    mov x28, x0
    .loc 2 1485 7
    ldr x6, [x26]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    ldr x10, [x26, x5, lsl #3]
    add x19, x19, x10
    sxtw x19, w19
    .loc 2 1486 7
    add x25, x25, #2
    sxtw x25, w25
    b .Lssa_main_2212
.Lssa_main_99:
    mov x5, #2
    str x5, [sp, #128]
.Lssa_main_98:
    ldr x4, [sp, #128]
    cmp x4, #2
    b.eq .Lssa_main_95
.Lssa_main_2220:
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_main_38
.Lssa_main_95:
    .loc 1 10 5
    adrp x10, .SB195
    add x10, x10, :lo12:.SB195
    mov x0, x10
    ldr x9, [sp, #88]
    bl __fn___fern_str_concat.r
    mov x19, x0
    ldr x0, [sp, #88]
    bl __fn___fern_str_free.r
    .loc 2 255 3
    mov x0, #2
    bl __fern_arr_box
    mov x28, x0
    adrp x10, .S5
    add x10, x10, :lo12:.S5
    str x10, [x28, #0]
    str x19, [x28, #8]
    .loc 6 90 3
    adrp x19, .K1
    add x19, x19, :lo12:.K1
    adrp x26, .K1
    add x26, x26, :lo12:.K1
    .loc 2 255 3
    adrp x22, .K4
    add x22, x22, :lo12:.K4
    mov x23, #200
    mov x0, #6
    bl __fern_arr_box
    adrp x9, .S4
    add x9, x9, :lo12:.S4
    str x9, [x0, #0]
    str x23, [x0, #8]
    str x28, [x0, #16]
    str x19, [x0, #24]
    str x26, [x0, #32]
    str x22, [x0, #40]
.Lssa_main_93:
    .loc 2 2406 3
    adrp x4, .SB196
    add x4, x4, :lo12:.SB196
    str x4, [sp, #120]
    .loc 2 255 3
.Lssa_main_92:
    mov x26, x0
    mov x19, #200
.Lssa_main_2224:
    ldr x0, [x26, #24]
    bl __fn_http__fields_ok.r
    cbnz x0, .Lssa_main_2226
.Lssa_main_2228:
    mov x0, x26
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_main_2225
.Lssa_main_2226:
    ldr x0, [x26, #32]
    bl __fn_http__fields_ok.r
    cbnz x0, .Lssa_main_89
.Lssa_main_2232:
    mov x0, x26
    bl __fn___sem_release_HttpResponse.r
.Lssa_main_2225:
    .loc 2 271 3
    adrp x26, .K5
    add x26, x26, :lo12:.K5
    mov x19, #500
    b .Lssa_main_2224
.Lssa_main_89:
    .loc 2 2487 3
    cmp x19, #200
    b.lt .Lssa_main_85
.Lssa_main_87:
    cmp x19, #204
    b.ne .Lssa_main_84
.Lssa_main_85:
    mov x28, #1
    b .Lssa_main_82
.Lssa_main_84:
    cmp x19, #304
    cset x10, eq
    mov x28, x10
.Lssa_main_83:
.Lssa_main_82:
    .loc 2 2414 3
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    .loc 2 2415 3
    adrp x9, .SB6
    add x9, x9, :lo12:.SB6
    cbz x28, .Lssa_main_80
.Lssa_main_81:
    mov x27, x10
    mov x23, x9
    b .Lssa_main_79
.Lssa_main_80:
    .loc 2 2417 10
    mov x0, x26
    bl __fn_HttpResponse__body_text_lossy.r
    mov x23, x0
    .loc 2 2418 13
    adrp x27, .SB7
    add x27, x27, :lo12:.SB7
    ldr x0, [x23, #8]
    .loc 14 147 5
    bl __fn_int__int_to_string.r
    mov x21, x0
    .loc 2 2418 13
    mov x0, x27
    mov x9, x21
    bl __fn___fern_str_concat.r
    mov x24, x0
    mov x0, x21
    bl __fn___fern_str_free.r
    adrp x21, .SB8
    add x21, x21, :lo12:.SB8
    str x24, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_2253
.Lssa_main_2252:
    mov x27, x24
    b .Lssa_main_79
.Lssa_main_2253:
    str x24, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x27, x0
    mov x0, x24
    bl __fn___fern_str_free.r
.Lssa_main_2254:
.Lssa_main_79:
    .loc 2 2420 3
    mov x9, #256
    mov x0, x9
    bl __fern_buf_new
    mov x21, x0
.Lssa_main_77:
    adrp x9, .SB9
    add x9, x9, :lo12:.SB9
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_76:
    cmp x19, #0
    b.ge .Lssa_main_73
.Lssa_main_75:
    mov x9, #45
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push_byte
    mov x9, #0
    sub x9, x9, x19
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push_decimal
    b .Lssa_main_72
.Lssa_main_73:
    mov x0, x21
    mov x1, x19
    bl __fern_buf_push_decimal
.Lssa_main_72:
    adrp x9, .SB10
    add x9, x9, :lo12:.SB10
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_70:
    adrp x9, .K6
    add x9, x9, :lo12:.K6
    adrp x10, .K7
    add x10, x10, :lo12:.K7
.Lssa_main_69:
    mov x11, #0
.Lssa_main_2260:
    ldr x15, [x9, #0]
    cmp x11, x15
    b.ge .Lssa_main_68
.Lssa_main_2263:
    add x5, x11, #1
    ldr x15, [x9, x5, lsl #3]
    cmp x15, x19
    b.eq .Lssa_main_67
.Lssa_main_2261:
    add x11, x11, #1
    b .Lssa_main_2260
.Lssa_main_68:
    adrp x9, .SB6
    add x9, x9, :lo12:.SB6
    mov x24, x9
    b .Lssa_main_66
.Lssa_main_67:
    ldr x6, [x10]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x9, [x10, x5, lsl #3]
    tbnz x9, #0, .Lssa_main_rcinc5803
    cmp x9, #16, lsl #12
    b.lo .Lssa_main_rcinc5803
    ldur w5, [x9, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5803sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5803sl:
    tbnz w5, #31, .Lssa_main_rcinc5803
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_main_rcinc5803:
    mov x24, x9
.Lssa_main_66:
    ldr x9, [x24, #8]
    b .Lssa_main_pool_2228
    .ltorg
.Lssa_main_pool_2228:
    cmp x9, #0
    b.ne .Lssa_main_63
.Lssa_main_2275:
    mov x0, x24
    bl __fn___fern_str_free.r
.Lssa_main_65:
    adrp x9, .SB61
    add x9, x9, :lo12:.SB61
    mov x24, x9
.Lssa_main_64:
.Lssa_main_63:
    mov x0, x21
    mov x1, x24
    bl __fern_buf_push
    mov x0, x24
    bl __fn___fern_str_free.r
    adrp x9, .SB8
    add x9, x9, :lo12:.SB8
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_62:
    mov x24, #0
.Lssa_main_2280:
    ldr x9, [x26, #24]
    ldr x11, [x9, #8]
    ldr x9, [x11, #0]
    cmp x24, x9
    b.lt .Lssa_main_2286
.Lssa_main_2288:
    mov x0, x26
    bl __fn___sem_release_HttpResponse.r
    b .Lssa_main_60
.Lssa_main_2286:
    ldr x25, [x26, #24]
    ldr x9, [x25, #8]
    add x5, x24, #1
    ldr x22, [x9, x5, lsl #3]
    adrp x9, .SB62
    add x9, x9, :lo12:.SB62
    mov x0, x22
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_2281
.Lssa_main_2285:
    adrp x9, .SB63
    add x9, x9, :lo12:.SB63
    mov x0, x22
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_2281
.Lssa_main_2284:
    adrp x9, .SB64
    add x9, x9, :lo12:.SB64
    mov x0, x22
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_2281
.Lssa_main_2282:
    ldr x9, [x25, #8]
    add x5, x24, #1
    ldr x11, [x9, x5, lsl #3]
    mov x0, x21
    mov x1, x11
    bl __fern_buf_push
    adrp x11, .SB65
    add x11, x11, :lo12:.SB65
    mov x0, x21
    mov x1, x11
    bl __fern_buf_push
    ldr x11, [x25, #16]
    ldr x6, [x11]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    ldr x9, [x11, x5, lsl #3]
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push
    adrp x9, .SB8
    add x9, x9, :lo12:.SB8
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_2281:
    add x24, x24, #1
    b .Lssa_main_2280
.Lssa_main_60:
    mov x0, x21
    mov x1, x27
    bl __fern_buf_push
    mov x0, x27
    bl __fn___fern_str_free.r
.Lssa_main_59:
    cmp x19, #101
    b.ne .Lssa_main_54
.Lssa_main_58:
    adrp x9, .SB66
    add x9, x9, :lo12:.SB66
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push
    b .Lssa_main_51
.Lssa_main_54:
    adrp x9, .SB67
    add x9, x9, :lo12:.SB67
    mov x0, x21
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_51:
    .loc 2 2422 3
    mov x0, x21
    bl __fern_buf_take
    mov x24, x0
    mov x0, x21
    bl __fern_buf_free
    cbz x28, .Lssa_main_50
.Lssa_main_2311:
    mov x0, x23
    bl __fn___fern_str_free.r
    b .Lssa_main_49
.Lssa_main_50:
    adrp x9, .SB69
    add x9, x9, :lo12:.SB69
    ldr x4, [sp, #120]
    ldr x11, [x4, #8]
    cmp x11, #4
    b.ne .Lssa_main_47
.Lssa_main_2315:
    ldr x4, [sp, #120]
    ldr x6, [x4, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn5881
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn5881
    ldr x0, [sp, #120]
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd5881
.Lssa_main_streqn5881:
    mov x0, #0
.Lssa_main_streqd5881:
    cbz x0, .Lssa_main_47
.Lssa_main_2318:
    mov x0, x23
    bl __fn___fern_str_free.r
.Lssa_main_49:
    mov x21, x24
    b .Lssa_main_44
.Lssa_main_47:
    .loc 2 2427 3
    str x24, [sp, #-16]!
    str x23, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_2324
.Lssa_main_2323:
    mov x21, x24
    b .Lssa_main_2325
.Lssa_main_2324:
    str x24, [sp, #-16]!
    str x23, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x21, x0
    mov x0, x24
    bl __fn___fern_str_free.r
.Lssa_main_2325:
    mov x0, x23
    bl __fn___fern_str_free.r
.Lssa_main_46:
.Lssa_main_44:
    .loc 1 12 11
    ldr x23, [x21, #8]
    mov x0, x21
    bl __fn___fern_str_free.r
    tst x20, #1
    b.ne .Lssa_main_uq44
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_uq44
    ldur w5, [x20, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq44us
    bl __fern_san_abort_uaf
.Lssa_main_uq44us:
    cmp w5, #1
.Lssa_main_uq44:
    b.ne .Lssa_main_2327
.Lssa_main_2326:
    mov x9, x20
    b .Lssa_main_2328
.Lssa_main_2327:
    mov x9, #0
.Lssa_main_2328:
    .loc 6 348 3
    ldr x21, [x20, #8]
    cmp x9, #0
    b.ne .Lssa_main_2331
.Lssa_main_2329:
    tbnz x21, #0, .Lssa_main_rcinc5903
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcinc5903
    ldur w5, [x21, #-8]
    movz w6, #64206
    movk w6, #32493, lsl #16
    cmp w5, w6
    b.ne .Lssa_main_rcinc5903sl
    bl __fern_san_abort_uaf
.Lssa_main_rcinc5903sl:
    tbnz w5, #31, .Lssa_main_rcinc5903
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcinc5903:
.Lssa_main_2331:
    cmp x9, #0
    b.eq .Lssa_main_2333
.Lssa_main_2332:
    ldr x24, [x20, #16]
    tst x24, #1
    b.ne .Lssa_main_uq2332
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_uq2332
    ldur w5, [x24, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq2332us
    bl __fern_san_abort_uaf
.Lssa_main_uq2332us:
    cmp w5, #1
.Lssa_main_uq2332:
    b.ne .Lssa_main_2337
.Lssa_main_2335:
    mov x28, #0
.Lssa_main_2339:
    ldr x9, [x24, #0]
    cmp x28, x9
    b.ge .Lssa_main_2337
.Lssa_main_2340:
    add x5, x28, #1
    ldr x9, [x24, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x28, x28, #1
    b .Lssa_main_2339
.Lssa_main_2337:
    mov x0, x24
    bl __fn___fern_arr_dec.r
    mov x0, x20
    bl __fn___fern_arr_dec.r
    b .Lssa_main_2334
.Lssa_main_2333:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_2334:
    ldr x28, [x21, #0]
    tst x21, #1
    b.ne .Lssa_main_uq2334
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq2334
    ldur w5, [x21, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa_main_uq2334us
    bl __fern_san_abort_uaf
.Lssa_main_uq2334us:
    cmp w5, #1
.Lssa_main_uq2334:
    b.ne .Lssa_main_2345
.Lssa_main_2343:
    mov x24, #0
.Lssa_main_2347:
    ldr x9, [x21, #0]
    cmp x24, x9
    b.ge .Lssa_main_2345
.Lssa_main_2348:
    add x5, x24, #1
    ldr x9, [x21, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x24, x24, #1
    b .Lssa_main_2347
.Lssa_main_2345:
    mov x0, x21
    bl __fn___fern_arr_dec.r
    .loc 1 12 11
    add x23, x23, x28
    sxtw x23, w23
    ldr x4, [sp, #144]
    add x4, x4, x23
    str x4, [sp, #144]
.Lssa_main_43:
    ldr x4, [sp, #136]
    add x4, x4, #1
    str x4, [sp, #136]
    ldr x4, [sp, #136]
    cmp x4, #4000
    b.lt .Lssa_main_396
.Lssa_main_40:
    .loc 1 14 3
    ldr x4, [sp, #144]
    ldr x5, =-6275696437447579415
    smulh x5, x4, x5
    add x5, x5, x4
    asr x5, x5, #6
    add x5, x5, x5, lsr #63
    mov x6, #97
    msub x4, x5, x6, x4
    mov x9, x4
    sxtw x0, w9
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_38:
    ldr x4, [sp, #128]
    cmp x4, #400
    b.ge .Lssa_main_1
.Lssa_main_35:
    adrp x9, .SB186
    add x9, x9, :lo12:.SB186
    ldr x4, [sp, #72]
    ldr x11, [x4, #8]
    cmp x11, #8
    b.ne .Lssa_main_2359
.Lssa_main_2358:
    ldr x4, [sp, #72]
    ldr x6, [x4, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn5953
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn5953
    ldr x0, [sp, #72]
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd5953
.Lssa_main_streqn5953:
    mov x0, #0
.Lssa_main_streqd5953:
    b .Lssa_main_2360
.Lssa_main_2359:
    mov x0, #0
.Lssa_main_2360:
    cbz x0, .Lssa_main_1
.Lssa_main_34:
.Lssa_main_31:
.Lssa_main_30:
.Lssa_main_29:
.Lssa_main_28:
.Lssa_main_27:
.Lssa_main_26:
.Lssa_main_25:
.Lssa_main_24:
.Lssa_main_23:
.Lssa_main_17:
.Lssa_main_16:
.Lssa_main_15:
.Lssa_main_11:
.Lssa_main_10:
.Lssa_main_8:
.Lssa_main_1:
    .loc 1 8 7
    mov x0, #100
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HeaderMap
.weak __fn___sem_drop_HeaderMap.k
__fn___sem_drop_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HeaderMap.k:
__fn___sem_drop_HeaderMap.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HeaderMap_0:
    ldr x20, [x19, #8]
    tst x20, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq0
    ldur w5, [x20, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_drop_HeaderMap_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_drop_HeaderMap_uq0us:
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq0:
    b.ne .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_1:
    mov x21, #0
.Lssa___sem_drop_HeaderMap_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_6:
    add x5, x21, #1
    ldr x9, [x20, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x21, x21, #1
    b .Lssa___sem_drop_HeaderMap_5
.Lssa___sem_drop_HeaderMap_3:
    mov x0, x20
    bl __fn___fern_arr_dec.r
    ldr x21, [x19, #16]
    tst x21, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq3
    cmp x21, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq3
    ldur w5, [x21, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_drop_HeaderMap_uq3us
    bl __fern_san_abort_uaf
.Lssa___sem_drop_HeaderMap_uq3us:
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq3:
    b.ne .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_9:
    mov x19, #0
.Lssa___sem_drop_HeaderMap_13:
    ldr x9, [x21, #0]
    cmp x19, x9
    b.ge .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_14:
    add x5, x19, #1
    ldr x9, [x21, x5, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    add x19, x19, #1
    b .Lssa___sem_drop_HeaderMap_13
.Lssa___sem_drop_HeaderMap_11:
    mov x0, x21
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HeaderMap
.weak __fn___sem_release_HeaderMap.k
__fn___sem_release_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HeaderMap.k:
__fn___sem_release_HeaderMap.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HeaderMap_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HeaderMap_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_HeaderMap_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_HeaderMap_uq0us:
    cmp w5, #1
.Lssa___sem_release_HeaderMap_uq0:
    b.ne .Lssa___sem_release_HeaderMap_3
.Lssa___sem_release_HeaderMap_1:
    mov x0, x19
    bl __fn___sem_drop_HeaderMap.r
.Lssa___sem_release_HeaderMap_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HttpResponse
.weak __fn___sem_drop_HttpResponse.k
__fn___sem_drop_HttpResponse:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HttpResponse.k:
__fn___sem_drop_HttpResponse.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HttpResponse_0:
    ldr x0, [x19, #16]
    bl __fn___sem_release_Body.r
    ldr x0, [x19, #24]
    bl __fn___sem_release_HeaderMap.r
    ldr x0, [x19, #32]
    bl __fn___sem_release_HeaderMap.r
    ldr x0, [x19, #40]
    bl __fn___sem_release_Option$$fn$void.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HttpResponse
.weak __fn___sem_release_HttpResponse.k
__fn___sem_release_HttpResponse:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HttpResponse.k:
__fn___sem_release_HttpResponse.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HttpResponse_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HttpResponse_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HttpResponse_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_HttpResponse_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_HttpResponse_uq0us:
    cmp w5, #1
.Lssa___sem_release_HttpResponse_uq0:
    b.ne .Lssa___sem_release_HttpResponse_3
.Lssa___sem_release_HttpResponse_1:
    mov x0, x19
    bl __fn___sem_drop_HttpResponse.r
.Lssa___sem_release_HttpResponse_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ByteStream
.weak __fn___sem_drop_ByteStream.k
__fn___sem_drop_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ByteStream.k:
__fn___sem_drop_ByteStream.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_ByteStream_0:
    ldr x9, [x19, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x0, [x19, #24]
    bl __fn___sem_release_Option$BodySource.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ByteStream
.weak __fn___sem_release_ByteStream.k
__fn___sem_release_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ByteStream.k:
__fn___sem_release_ByteStream.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ByteStream_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ByteStream_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_ByteStream_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_ByteStream_uq0us:
    cmp w5, #1
.Lssa___sem_release_ByteStream_uq0:
    b.ne .Lssa___sem_release_ByteStream_3
.Lssa___sem_release_ByteStream_1:
    mov x0, x19
    bl __fn___sem_drop_ByteStream.r
.Lssa___sem_release_ByteStream_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ChunkProducer
.weak __fn___sem_drop_ChunkProducer.k
__fn___sem_drop_ChunkProducer:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ChunkProducer.k:
__fn___sem_drop_ChunkProducer.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_ChunkProducer_0:
    ldr x9, [x19, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x9, [x19, #24]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x9, [x19, #32]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ChunkProducer
.weak __fn___sem_release_ChunkProducer.k
__fn___sem_release_ChunkProducer:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ChunkProducer.k:
__fn___sem_release_ChunkProducer.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ChunkProducer_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ChunkProducer_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ChunkProducer_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_ChunkProducer_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_ChunkProducer_uq0us:
    cmp w5, #1
.Lssa___sem_release_ChunkProducer_uq0:
    b.ne .Lssa___sem_release_ChunkProducer_3
.Lssa___sem_release_ChunkProducer_1:
    mov x0, x19
    bl __fn___sem_drop_ChunkProducer.r
.Lssa___sem_release_ChunkProducer_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_BodySource
.weak __fn___sem_drop_BodySource.k
__fn___sem_drop_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_BodySource.k:
__fn___sem_drop_BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_BodySource_0:
    ldr x9, [x19, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    ldr x20, [x19, #16]
    tst x20, #1
    b.ne .Lssa___sem_drop_BodySource_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_uq0
    ldur w5, [x20, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_drop_BodySource_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_drop_BodySource_uq0us:
    cmp w5, #1
.Lssa___sem_drop_BodySource_uq0:
    b.ne .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_1:
    mov x21, #0
.Lssa___sem_drop_BodySource_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_6:
    add x5, x21, #1
    ldr x0, [x20, x5, lsl #3]
    bl __fn___sem_release_Option$StreamFault.r
    add x21, x21, #1
    b .Lssa___sem_drop_BodySource_5
.Lssa___sem_drop_BodySource_3:
    mov x0, x20
    bl __fn___fern_arr_dec.r
    ldr x9, [x19, #24]
    mov x0, x9
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_BodySource
.weak __fn___sem_release_BodySource.k
__fn___sem_release_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_BodySource.k:
__fn___sem_release_BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_BodySource_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_BodySource_uq0us:
    cmp w5, #1
.Lssa___sem_release_BodySource_uq0:
    b.ne .Lssa___sem_release_BodySource_3
.Lssa___sem_release_BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_BodySource.r
.Lssa___sem_release_BodySource_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Body
.weak __fn___sem_drop_Body.k
__fn___sem_drop_Body:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Body.k:
__fn___sem_drop_Body.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_Body_0:
    ldr x9, [x19, #0]
    adrp x10, .S5
    add x10, x10, :lo12:.S5
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_2
.Lssa___sem_drop_Body_1:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_str_free.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_2:
    adrp x10, .S197
    add x10, x10, :lo12:.S197
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_5
.Lssa___sem_drop_Body_4:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_arr_dec.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_5:
    adrp x10, .S198
    add x10, x10, :lo12:.S198
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_8
.Lssa___sem_drop_Body_7:
    ldr x0, [x19, #8]
    bl __fn___sem_release_ByteStream.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_8:
    adrp x10, .S199
    add x10, x10, :lo12:.S199
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_11
.Lssa___sem_drop_Body_10:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_str_free.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_11:
    adrp x10, .S200
    add x10, x10, :lo12:.S200
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_14
.Lssa___sem_drop_Body_13:
    ldr x0, [x19, #8]
    bl __fn___sem_release_ChunkProducer.r
    b .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_14:
    adrp x10, .S201
    add x10, x10, :lo12:.S201
    cmp x9, x10
    b.ne .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_16:
    ldr x10, [x19, #8]
    mov x0, x10
    bl __fn___fern_str_free.r
    ldr x10, [x19, #16]
    mov x0, x10
    bl __fn___fern_arr_dec.r
    ldr x20, [x19, #24]
    tst x20, #1
    b.ne .Lssa___sem_drop_Body_uq16
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_Body_uq16
    ldur w5, [x20, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_drop_Body_uq16us
    bl __fern_san_abort_uaf
.Lssa___sem_drop_Body_uq16us:
    cmp w5, #1
.Lssa___sem_drop_Body_uq16:
    b.ne .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_19:
    mov x19, #0
.Lssa___sem_drop_Body_23:
    ldr x10, [x20, #0]
    cmp x19, x10
    b.ge .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_24:
    add x5, x19, #1
    ldr x10, [x20, x5, lsl #3]
    mov x0, x10
    bl __fn___fern_arr_dec.r
    add x19, x19, #1
    b .Lssa___sem_drop_Body_23
.Lssa___sem_drop_Body_21:
    mov x0, x20
    bl __fn___fern_arr_dec.r
.Lssa___sem_drop_Body_3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Body
.weak __fn___sem_release_Body.k
__fn___sem_release_Body:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Body.k:
__fn___sem_release_Body.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Body_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Body_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Body_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_Body_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_Body_uq0us:
    cmp w5, #1
.Lssa___sem_release_Body_uq0:
    b.ne .Lssa___sem_release_Body_3
.Lssa___sem_release_Body_1:
    mov x0, x19
    bl __fn___sem_drop_Body.r
.Lssa___sem_release_Body_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$$fn$void
.weak __fn___sem_drop_Option$$fn$void.k
__fn___sem_drop_Option$$fn$void:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$$fn$void.k:
__fn___sem_drop_Option$$fn$void.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$$fn$void_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$$fn$void_3
.Lssa___sem_drop_Option$$fn$void_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$$fn$void_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$$fn$void
.weak __fn___sem_release_Option$$fn$void.k
__fn___sem_release_Option$$fn$void:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$$fn$void.k:
__fn___sem_release_Option$$fn$void.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$$fn$void_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$$fn$void_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$$fn$void_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_Option$$fn$void_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_Option$$fn$void_uq0us:
    cmp w5, #1
.Lssa___sem_release_Option$$fn$void_uq0:
    b.ne .Lssa___sem_release_Option$$fn$void_3
.Lssa___sem_release_Option$$fn$void_1:
    mov x0, x19
    bl __fn___sem_drop_Option$$fn$void.r
.Lssa___sem_release_Option$$fn$void_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$BodySource
.weak __fn___sem_drop_Option$BodySource.k
__fn___sem_drop_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$BodySource.k:
__fn___sem_drop_Option$BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$BodySource_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$BodySource_3
.Lssa___sem_drop_Option$BodySource_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___sem_release_BodySource.r
.Lssa___sem_drop_Option$BodySource_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$BodySource
.weak __fn___sem_release_Option$BodySource.k
__fn___sem_release_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$BodySource.k:
__fn___sem_release_Option$BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_Option$BodySource_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_Option$BodySource_uq0us:
    cmp w5, #1
.Lssa___sem_release_Option$BodySource_uq0:
    b.ne .Lssa___sem_release_Option$BodySource_3
.Lssa___sem_release_Option$BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_Option$BodySource.r
.Lssa___sem_release_Option$BodySource_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$StreamFault
.weak __fn___sem_drop_Option$StreamFault.k
__fn___sem_drop_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$StreamFault.k:
__fn___sem_drop_Option$StreamFault.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$StreamFault_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$StreamFault_3
.Lssa___sem_drop_Option$StreamFault_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$StreamFault_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$StreamFault
.weak __fn___sem_release_Option$StreamFault.k
__fn___sem_release_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$StreamFault.k:
__fn___sem_release_Option$StreamFault.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$StreamFault_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$StreamFault_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_uq0
    ldur w5, [x19, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___sem_release_Option$StreamFault_uq0us
    bl __fern_san_abort_uaf
.Lssa___sem_release_Option$StreamFault_uq0us:
    cmp w5, #1
.Lssa___sem_release_Option$StreamFault_uq0:
    b.ne .Lssa___sem_release_Option$StreamFault_3
.Lssa___sem_release_Option$StreamFault_1:
    mov x0, x19
    bl __fn___sem_drop_Option$StreamFault.r
.Lssa___sem_release_Option$StreamFault_3:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_len
.weak __fn___sem_view_len.k
__fn___sem_view_len:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_len.k:
__fn___sem_view_len.r:
.Lssa___sem_view_len_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_len_3
.Lssa___sem_view_len_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #8]
    mov x0, x10
    ret
.Lssa___sem_view_len_3:
    ldr x10, [x0, #0]
    mov x0, x10
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_data
.weak __fn___sem_view_data.k
__fn___sem_view_data:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_data.k:
__fn___sem_view_data.r:
.Lssa___sem_view_data_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_data_3
.Lssa___sem_view_data_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #0]
    mov x0, x10
    ret
.Lssa___sem_view_data_3:
    add x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_slice
.weak __fn___sem_byte_view_slice.k
__fn___sem_byte_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_byte_view_slice.k:
__fn___sem_byte_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_byte_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_byte_view_slice_3
.Lssa___sem_byte_view_slice_1:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_byte_view_slice_6
.Lssa___sem_byte_view_slice_4:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_byte_view_slice_9
.Lssa___sem_byte_view_slice_7:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    add x0, x0, x20
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice
.weak __fn___sem_view_slice.k
__fn___sem_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice.k:
__fn___sem_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_3
.Lssa___sem_view_slice_1:
    bl __fern_slice_abort
.Lssa___sem_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_6
.Lssa___sem_view_slice_4:
    bl __fern_slice_abort
.Lssa___sem_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_9
.Lssa___sem_view_slice_7:
    bl __fern_slice_abort
.Lssa___sem_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice_wide
.weak __fn___sem_view_slice_wide.k
__fn___sem_view_slice_wide:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice_wide.k:
__fn___sem_view_slice_wide.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_wide_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_wide_3
.Lssa___sem_view_slice_wide_1:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_wide_6
.Lssa___sem_view_slice_wide_4:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_wide_9
.Lssa___sem_view_slice_wide_7:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_release
.weak __fn___sem_view_release.k
__fn___sem_view_release:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_release.k:
__fn___sem_view_release.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_view_release_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_release_3
.Lssa___sem_view_release_1:
    mov x9, #-2
    add x9, x0, x9
    str x9, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_view_release_3:
    bl __fn___fern_arr_dec.r
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_string
.weak __fn___sem_byte_view_string.k
__fn___sem_byte_view_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_byte_view_string.k:
__fn___sem_byte_view_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_string_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_byte_view_string_3
.Lssa___sem_byte_view_string_1:
    mov x9, #-2
    add x9, x0, x9
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_string_3:
    bl __fn___fern_string_from_bytes_u8.r
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_mismatch
.weak __fn___sem_byte_view_mismatch.k
__fn___sem_byte_view_mismatch:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___sem_byte_view_mismatch.k:
__fn___sem_byte_view_mismatch.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_mismatch_0:
    mov x13, #2
    and x13, x0, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_3
.Lssa___sem_byte_view_mismatch_1:
    mov x13, #2
    and x13, x10, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_6
.Lssa___sem_byte_view_mismatch_4:
    mov x13, #-2
    add x13, x0, x13
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    mov x0, x13
    ldr x5, [x0, #8]
    ldr x0, [x0]
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L199_aop
    mov x1, #0
.L199_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L199_bop
    mov x3, #0
.L199_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L199_nok
    mov x4, #0
.L199_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L199_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L199_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L199_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L199_done
.L199_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L199_vec
.L199_short:
    cmp x10, #8
    b.lt .L199_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L199_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L199_eq
    add x8, x8, x14
.L199_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L199_done
.L199_w4:
    cmp x10, #4
    b.lt .L199_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L199_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L199_eq
    add x8, x8, x14
.L199_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L199_done
.L199_w2:
    cmp x10, #2
    b.lt .L199_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L199_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L199_eq
    add x8, x8, x14
.L199_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L199_done
.L199_tail:
    cmp x8, x13
    b.ge .L199_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L199_th
    add x8, x8, #1
    add x9, x9, #1
    b .L199_tail
.L199_th:
    sub x2, x8, x12
    b .L199_done
.L199_eq:
    mov x2, x4
.L199_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_6:
    mov x15, #-2
    add x15, x0, x15
    mov x4, x12
    mov x3, x9
    mov x2, x15
    mov x1, x11
    mov x0, x10
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L200_aop
    mov x1, #0
.L200_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L200_bop
    mov x3, #0
.L200_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L200_nok
    mov x4, #0
.L200_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L200_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L200_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L200_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L200_done
.L200_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L200_vec
.L200_short:
    cmp x10, #8
    b.lt .L200_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L200_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L200_eq
    add x8, x8, x14
.L200_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L200_done
.L200_w4:
    cmp x10, #4
    b.lt .L200_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L200_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L200_eq
    add x8, x8, x14
.L200_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L200_done
.L200_w2:
    cmp x10, #2
    b.lt .L200_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L200_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L200_eq
    add x8, x8, x14
.L200_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L200_done
.L200_tail:
    cmp x8, x13
    b.ge .L200_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L200_th
    add x8, x8, #1
    add x9, x9, #1
    b .L200_tail
.L200_th:
    sub x2, x8, x12
    b .L200_done
.L200_eq:
    mov x2, x4
.L200_done:
    mov x14, x2
    mov x0, x14
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_3:
    mov x14, #2
    and x14, x10, x14
    cbz x14, .Lssa___sem_byte_view_mismatch_9
.Lssa___sem_byte_view_mismatch_7:
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L201_aop
    mov x1, #0
.L201_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L201_bop
    mov x3, #0
.L201_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L201_nok
    mov x4, #0
.L201_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L201_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L201_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L201_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L201_done
.L201_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L201_vec
.L201_short:
    cmp x10, #8
    b.lt .L201_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L201_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L201_eq
    add x8, x8, x14
.L201_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L201_done
.L201_w4:
    cmp x10, #4
    b.lt .L201_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L201_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L201_eq
    add x8, x8, x14
.L201_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L201_done
.L201_w2:
    cmp x10, #2
    b.lt .L201_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L201_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L201_eq
    add x8, x8, x14
.L201_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L201_done
.L201_tail:
    cmp x8, x13
    b.ge .L201_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L201_th
    add x8, x8, #1
    add x9, x9, #1
    b .L201_tail
.L201_th:
    sub x2, x8, x12
    b .L201_done
.L201_eq:
    mov x2, x4
.L201_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_9:
    mov x4, x12
    mov x3, x11
    mov x2, x10
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2]
    add x2, x2, #8
    cmp x1, #0
    b.ge .L202_aop
    mov x1, #0
.L202_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L202_bop
    mov x3, #0
.L202_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L202_nok
    mov x4, #0
.L202_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L202_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L202_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L202_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L202_done
.L202_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L202_vec
.L202_short:
    cmp x10, #8
    b.lt .L202_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L202_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L202_eq
    add x8, x8, x14
.L202_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L202_done
.L202_w4:
    cmp x10, #4
    b.lt .L202_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L202_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L202_eq
    add x8, x8, x14
.L202_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L202_done
.L202_w2:
    cmp x10, #2
    b.lt .L202_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L202_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L202_eq
    add x8, x8, x14
.L202_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L202_done
.L202_tail:
    cmp x8, x13
    b.ge .L202_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L202_th
    add x8, x8, #1
    add x9, x9, #1
    b .L202_tail
.L202_th:
    sub x2, x8, x12
    b .L202_done
.L202_eq:
    mov x2, x4
.L202_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
_start:
    adrp x9, .Lfern_relanchor
    add x9, x9, :lo12:.Lfern_relanchor
    ldr x10, [x9]
    sub x9, x9, x10
    cbz x9, .Lfern_reloc_done
    adrp x11, .Lfern_sbox_begin
    add x11, x11, :lo12:.Lfern_sbox_begin
    adrp x12, .Lfern_sbox_end
    add x12, x12, :lo12:.Lfern_sbox_end
.Lfern_sbox_loop:
    cmp x11, x12
    b.hs .Lfern_sbox_done
    ldr x13, [x11, #8]
    add x13, x13, x9
    str x13, [x11, #8]
    add x11, x11, #24
    b .Lfern_sbox_loop
.Lfern_sbox_done:
    adrp x11, .Lfern_cagg_begin
    add x11, x11, :lo12:.Lfern_cagg_begin
    adrp x12, .Lfern_cagg_end
    add x12, x12, :lo12:.Lfern_cagg_end
.Lfern_cagg_loop:
    cmp x11, x12
    b.hs .Lfern_cagg_done
    ldr x13, [x11, #16]
    add x13, x13, x9
    str x13, [x11, #16]
    ldr x14, [x11]
    add x11, x11, #16
    add x11, x11, x14, lsl #3
    b .Lfern_cagg_loop
.Lfern_cagg_done:
    adrp x11, .Lfern_cfn_begin
    add x11, x11, :lo12:.Lfern_cfn_begin
    adrp x12, .Lfern_cfn_end
    add x12, x12, :lo12:.Lfern_cfn_end
.Lfern_cfn_loop:
    cmp x11, x12
    b.hs .Lfern_cfn_done
    ldr x13, [x11, #24]
    add x13, x13, x9
    str x13, [x11, #24]
    add x11, x11, #32
    b .Lfern_cfn_loop
.Lfern_cfn_done:
    adrp x11, .Lfern_cref_begin
    add x11, x11, :lo12:.Lfern_cref_begin
    adrp x12, .Lfern_cref_end
    add x12, x12, :lo12:.Lfern_cref_end
.Lfern_cref_loop:
    cmp x11, x12
    b.hs .Lfern_reloc_done
    ldr x13, [x11]
    add x13, x13, x9
    ldr x14, [x13]
    add x14, x14, x9
    str x14, [x13]
    add x11, x11, #8
    b .Lfern_cref_loop
.Lfern_reloc_done:
    ldr x0, [sp]
    lsl x0, x0, #3
    add x0, x0, #16
    add x0, sp, x0
    adrp x1, __fern_envp
    add x1, x1, :lo12:__fern_envp
    str x0, [x1]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #30
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_stack_map_failed
    mov x19, x0
    mov x1, #1
    lsl x1, x1, #20
    mov x2, #0
    mov x8, #226
    svc #0
    cbnz x0, .Lfern_stack_guard_failed
    mov x9, #1
    lsl x9, x9, #30
    add x9, x19, x9
    sub sp, x9, #16
    mov x10, sp
    adrp x11, __fern_stack_top
    add x11, x11, :lo12:__fern_stack_top
    str x10, [x11]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #16
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_signal_stack_map_failed
    mov x9, #1
    lsl x9, x9, #16
    sub sp, sp, #32
    stp x0, xzr, [sp]
    str x9, [sp, #16]
    mov x0, sp
    mov x1, #0
    mov x8, #132
    svc #0
    cbnz x0, .Lfern_signal_stack_failed
    adrp x9, __fern_segv
    add x9, x9, :lo12:__fern_segv
    mov x10, #4
    movk x10, #0x800, lsl #16
    mov x11, #0x448
    stp x9, x10, [sp]
    stp xzr, x11, [sp, #16]
    bl .Lfern_fault_install
    cbnz x0, .Lfern_fault_handler_failed
    add sp, sp, #32
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    bl __fn_main
    mov x19, x0
    bl __fern_lc_report
    mov x0, x19
    mov x8, #94
    svc #0
__fn___fern_str_concat:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_concat.k:
__fn___fern_str_concat.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_concat_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    add x9, x21, x22
    sxtw x23, w9
    mov x0, x23
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    ldr x9, [x19, #0]
    mov x2, x21
    mov x1, x9
    mov x0, x24
    cbz x2, .Lssa___fern_str_concat_mcd18
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb18
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc18:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct18
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc18
.Lssa___fern_str_concat_mct18:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd18
.Lssa___fern_str_concat_mcb18:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb18
.Lssa___fern_str_concat_mcd18:
    mov x0, #0
    sxtw x21, w21
    add x21, x24, x21
    ldr x9, [x20, #0]
    mov x2, x22
    mov x1, x9
    mov x0, x21
    cbz x2, .Lssa___fern_str_concat_mcd34
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb34
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc34:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct34
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc34
.Lssa___fern_str_concat_mct34:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd34
.Lssa___fern_str_concat_mcb34:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb34
.Lssa___fern_str_concat_mcd34:
    mov x0, #0
    mov x0, x24
    mov x1, x23
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_eq:
    ldr x0, [sp]
    ldr x9, [sp, #16]
__fn___fern_str_eq.r:
    cmp x0, x9
    b.eq .Lseq_yes
    ldr x4, [x0, #8]
    ldr x5, [x9, #8]
    cmp x4, x5
    b.ne .Lseq_no
    ldr x2, [x0]
    ldr x3, [x9]
    cmp x2, x3
    b.eq .Lseq_yes
    add x6, x2, x4
    add x7, x3, x4
    cmp x4, #8
    b.lo .Lseq_short
    sub x6, x6, #8
    sub x7, x7, #8
.Lseq_word:
    ldr x0, [x2]
    ldr x1, [x3]
    cmp x0, x1
    b.ne .Lseq_no
    add x2, x2, #8
    add x3, x3, #8
    cmp x2, x6
    b.lo .Lseq_word
    ldr x0, [x6]
    ldr x1, [x7]
    cmp x0, x1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_short:
    cbz x4, .Lseq_yes
    cmp x4, #4
    b.lo .Lseq_byte
    ldr w0, [x2]
    ldr w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #4
    sub x7, x7, #4
    ldr w0, [x6]
    ldr w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_byte:
    ldrb w0, [x2]
    ldrb w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #1
    sub x7, x7, #1
    ldrb w0, [x6]
    ldrb w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    cmp x4, #3
    b.lo .Lseq_yes
    ldrb w0, [x2, #1]
    ldrb w1, [x3, #1]
    cmp w0, w1
    b.ne .Lseq_no
.Lseq_yes:
    mov x0, #1
    ret
.Lseq_no:
    mov x0, #0
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .bss
    .align 3
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 3
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 3
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 3
__fern_rc_underflow: .quad 0
    .align 3
__fern_map_seed: .quad 0
    .align 3
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 3
__fern_quar_head: .quad 0
    .align 3
__fern_quar_tail: .quad 0
    .align 3
__fern_quar_bytes: .quad 0
    .align 3
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 3
__fern_freelist_shadow: .skip 524288
    .align 3
__fern_large_freelist_shadow: .skip 20480
    .text
.globl __fern_capw
__fern_capw:
    stp x9, x10, [sp, #-32]!
    str x11, [sp, #16]
    ldr x9, [sp, #32]
    cmp x9, #256
    b.ls .Lcapw_ret
    clz x10, x9
    mov x11, #61
    sub x10, x11, x10
    mov x11, #1
    lsl x11, x11, x10
    add x9, x9, x11
    sub x9, x9, #1
    neg x11, x11
    and x9, x9, x11
    mov x10, #0x10000
    cmp x9, x10
    b.lo .Lcapw_store
    mov x9, #65535
.Lcapw_store:
    str x9, [sp, #32]
.Lcapw_ret:
    ldr x11, [sp, #16]
    ldp x9, x10, [sp], #32
    ret
.globl __fern_alloc
.type __fern_alloc, %function
__fern_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    add x0, x0, #7
    lsr x3, x0, #3
    lsl x0, x3, #3
    adrp x1, __fern_lc_alloc_count
    add x1, x1, :lo12:__fern_lc_alloc_count
    ldr x2, [x1]
    add x2, x2, #1
    str x2, [x1]
    adrp x1, __fern_lc_alloc_bytes
    add x1, x1, :lo12:__fern_lc_alloc_bytes
    ldr x2, [x1]
    add x2, x2, x0
    str x2, [x1]
    mov x2, #0x10000
    cmp x3, x2
    b.hs .Lalloc_large
    cmp x3, #256
    b.ls .L203
    str x3, [sp, #-16]!
    bl __fern_capw
    ldr x3, [sp], #16
.L203:
    lsl x0, x3, #3
    adrp x1, __fern_freelist
    add x1, x1, :lo12:__fern_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_large:
    mov x1, #1
    lsl x1, x1, #34
    cmp x0, x1
    b.hi .Lalloc_nofl
    mov x1, #1
    lsl x1, x1, #19
    cmp x0, x1
    csel x0, x1, x0, lo
    clz x1, x0
    mov x3, #61
    sub x3, x3, x1
    mov x1, #1
    lsl x1, x1, x3
    sub x1, x1, #1
    add x0, x0, x1
    bic x0, x0, x1
    clz x1, x0
    mov x3, #61
    sub x1, x3, x1
    lsr x3, x0, x1
    add x3, x3, x1, lsl #2
    sub x3, x3, #72
    adrp x1, __fern_large_freelist
    add x1, x1, :lo12:__fern_large_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_nofl:
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    ldr x2, [x1]
    cbnz x2, .Lalloc_inited
    stp x4, x5, [sp, #-16]!
    stp x8, x9, [sp, #-16]!
    mov x9, x0
    mov x0, #1
    lsl x0, x0, #28
    movz x1, #0
    movk x1, #4, lsl #32
    mov x2, #3
    mov x3, #0x4022
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    cmn x0, #0
    b.mi .Lalloc_map_fail
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    str x0, [x1]
    adrp x1, __fern_heap_base
    add x1, x1, :lo12:__fern_heap_base
    str x0, [x1]
    movz x2, #0
    movk x2, #4, lsl #32
    add x2, x0, x2
    adrp x3, __fern_heap_end
    add x3, x3, :lo12:__fern_heap_end
    str x2, [x3]
    mov x0, x9
    ldp x8, x9, [sp], #16
    ldp x4, x5, [sp], #16
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
.Lalloc_inited:
    ldr x2, [x1]
    adds x3, x2, x0
    b.cs __fern_alloc_size_abort
    str x4, [sp, #-16]!
    adrp x4, __fern_heap_end
    add x4, x4, :lo12:__fern_heap_end
    ldr x4, [x4]
    cmp x3, x4
    ldr x4, [sp], #16
    b.hi .Lalloc_oom
    str x3, [x1]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .text
.Lalloc_oom:
    adrp x1, .Lmsg_oom
    add x1, x1, :lo12:.Lmsg_oom
    mov x2, #43
    mov x0, #125
    b __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .text
.Lalloc_map_fail:
    neg x9, x0
    sub sp, sp, #96
    add x10, sp, #96
    mov x12, #10
    sub x10, x10, #1
    strb w12, [x10]
    mov x11, #41
    sub x10, x10, #1
    strb w11, [x10]
.Lmap_fail_digit:
    udiv x13, x9, x12
    msub x14, x13, x12, x9
    add x14, x14, #48
    sub x10, x10, #1
    strb w14, [x10]
    mov x9, x13
    cbnz x9, .Lmap_fail_digit
    adrp x15, .Lmsg_map_fail
    add x15, x15, :lo12:.Lmsg_map_fail
    add x15, x15, #42
    mov x11, #42
.Lmap_fail_copy:
    sub x15, x15, #1
    ldrb w14, [x15]
    sub x10, x10, #1
    strb w14, [x10]
    subs x11, x11, #1
    b.ne .Lmap_fail_copy
    mov x1, x10
    add x2, sp, #96
    sub x2, x2, x10
    mov x0, #123
    b __fern_report
.size __fern_alloc, .-__fern_alloc
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .text
__fern_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_oob_abort
.type __fern_oob_abort, %function
__fern_oob_abort:
    adrp x1, .Lmsg_arr_oob
    add x1, x1, :lo12:.Lmsg_arr_oob
    mov x2, #31
    b __fern_abort_134
.size __fern_oob_abort, .-__fern_oob_abort
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .text
__fern_str_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_str_oob_abort
.type __fern_str_oob_abort, %function
__fern_str_oob_abort:
    adrp x1, .Lmsg_str_oob
    add x1, x1, :lo12:.Lmsg_str_oob
    mov x2, #32
    b __fern_abort_134
.size __fern_str_oob_abort, .-__fern_str_oob_abort
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .text
__fern_slice_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_slice_abort
.type __fern_slice_abort, %function
__fern_slice_abort:
    adrp x1, .Lmsg_slice
    add x1, x1, :lo12:.Lmsg_slice
    mov x2, #32
    b __fern_abort_134
.size __fern_slice_abort, .-__fern_slice_abort
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .text
__fern_alloc_size_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_alloc_size_abort
.type __fern_alloc_size_abort, %function
__fern_alloc_size_abort:
    adrp x1, .Lmsg_alloc_size
    add x1, x1, :lo12:.Lmsg_alloc_size
    mov x2, #35
    b __fern_abort_134
.size __fern_alloc_size_abort, .-__fern_alloc_size_abort
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .text
.globl __fern_free_range_abort
.type __fern_free_range_abort, %function
__fern_free_range_abort:
    adrp x1, .Lmsg_free_range
    add x1, x1, :lo12:.Lmsg_free_range
    mov x2, #41
    b __fern_abort_134
.size __fern_free_range_abort, .-__fern_free_range_abort
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .text
__fern_double_free_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_double_free_abort
.type __fern_double_free_abort, %function
__fern_double_free_abort:
    adrp x1, .Lmsg_double_free
    add x1, x1, :lo12:.Lmsg_double_free
    mov x2, #45
    b __fern_abort_134
.size __fern_double_free_abort, .-__fern_double_free_abort
__fern_arr_box:
    movz x1, #65535
    movk x1, #4095, lsl #16
    cmp x0, x1
    b.ls .Larrbox_sized
    b __fern_alloc_size_abort_leaf
.Larrbox_sized:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    add x0, x0, #3
    lsl x0, x0, #3
    bl __fern_alloc
    ldr x1, [sp]
    str x1, [x0]
    mov w2, #1
    str w2, [x0, #8]
    str x1, [x0, #16]
    add x0, x0, #16
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
__fern_str_box:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x0, #24
    bl __fern_alloc
    mov x2, #1
    str x2, [x0]
    ldp x2, x3, [sp], #16
    str x2, [x0, #8]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fern_str_box_hdr:
    sub x2, x0, #24
    mov w3, #1
    str w3, [x2]
    mov w4, #32781
    movk w4, #29519, lsl #16
    stur w4, [x2, #4]
    str x0, [x2, #8]
    str x1, [x2, #16]
    add x0, x2, #8
    ret
.globl __fern_buf_new
.type __fern_buf_new, %function
__fern_buf_new:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cmp x19, #16
    b.hs .Lbufnew_cap
    mov x19, #16
.Lbufnew_cap:
    mov x0, #32
    bl __fern_alloc
    mov x20, x0
    mov x0, x19
    bl __fern_alloc
    str x0, [x20]
    str xzr, [x20, #8]
    str x19, [x20, #16]
    str x19, [x20, #24]
    mov x0, x20
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_new, .-__fern_buf_new
.globl __fern_buf_reserve
.type __fern_buf_reserve, %function
__fern_buf_reserve:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19, #16]
    cbnz x21, .Lbufres_dbl
    ldr x21, [x19, #24]
    cbnz x21, .Lbufres_dbl
    mov x21, #64
.Lbufres_dbl:
    cmp x21, x20
    b.hs .Lbufres_alloc
    lsl x21, x21, #1
    b .Lbufres_dbl
.Lbufres_alloc:
    mov x0, x21
    bl __fern_alloc
    mov x22, x0
    ldr x2, [x19, #8]
    cbz x2, .Lbufres_nocopy
    ldr x1, [x19]
    mov x3, x22
    cbz x2, .Lbufres_copy_d
    cmp x2, #8
    b.lo .Lbufres_copy_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x3, x2
    sub x11, x11, #8
.Lbufres_copy_w:
    cmp x3, x11
    b.hs .Lbufres_copy_t
    ldr x9, [x1], #8
    str x9, [x3], #8
    b .Lbufres_copy_w
.Lbufres_copy_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufres_copy_d
.Lbufres_copy_b:
    ldrb w9, [x1], #1
    strb w9, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufres_copy_b
.Lbufres_copy_d:
.Lbufres_nocopy:
    ldr x5, [x19]
    cbz x5, .Lbufres_store
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbufres_old_large
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x6, lsl #3
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x6
    mov x0, x5
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    b .Lbufres_old_done
.Lbufres_old_large:
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x6, lsl #3
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x6
    mov x0, x5
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lbufres_old_done:
.Lbufres_store:
    str x22, [x19]
    str x21, [x19, #16]
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_reserve, .-__fern_buf_reserve
.globl __fern_buf_push
.type __fern_buf_push, %function
__fern_buf_push:
    ldrsw x3, [x1, #8]
    cbz x3, .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufpush_grow
    str x5, [x0, #8]
    ldr x1, [x1]
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
    b .Lbufrange_tail
.Lbufpush_grow:
    mov x2, #0
    b .Lbufrange_grow
.size __fern_buf_push, .-__fern_buf_push
.globl __fern_buf_push_range
.type __fern_buf_push_range, %function
__fern_buf_push_range:
    sxtw x2, w2
    sxtw x3, w3
    tbz x2, #63, .Lbufrange_lo
    b __fern_slice_abort_leaf
.Lbufrange_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lbufrange_hi
    b __fern_slice_abort_leaf
.Lbufrange_hi:
    subs x3, x3, x2
    b.ge .Lbufrange_range
    b __fern_slice_abort_leaf
.Lbufrange_range:
    b.eq .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufrange_grow
.Lbufrange_copy:
    str x5, [x0, #8]
    ldr x1, [x1]
    add x1, x1, x2
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
.Lbufrange_tail:
    cbz x2, .Lbufrange_done
    cmp x2, #8
    b.lo .Lbufrange_loop_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x6, x2
    sub x11, x11, #8
.Lbufrange_loop_w:
    cmp x6, x11
    b.hs .Lbufrange_loop_t
    ldr x9, [x1], #8
    str x9, [x6], #8
    b .Lbufrange_loop_w
.Lbufrange_loop_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufrange_done
.Lbufrange_loop_b:
    ldrb w9, [x1], #1
    strb w9, [x6], #1
    sub x2, x2, #1
    cbnz x2, .Lbufrange_loop_b
.Lbufrange_done:
    ret
.Lbufrange_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    stp x2, x3, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x2, x3, [sp], #16
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, x3
    b .Lbufrange_copy
.size __fern_buf_push_range, .-__fern_buf_push_range
.globl __fern_buf_push_byte
.type __fern_buf_push_byte, %function
__fern_buf_push_byte:
    ldr x4, [x0, #8]
    add x5, x4, #1
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufbyte_grow
.Lbufbyte_fits:
    ldr x6, [x0]
    strb w1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufbyte_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #1
    b .Lbufbyte_fits
.size __fern_buf_push_byte, .-__fern_buf_push_byte
.globl __fern_buf_push_u64
.type __fern_buf_push_u64, %function
__fern_buf_push_u64:
    ldr x4, [x0, #8]
    add x5, x4, #8
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufu64_grow
.Lbufu64_fits:
    ldr x6, [x0]
    str x1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufu64_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #8
    b .Lbufu64_fits
.size __fern_buf_push_u64, .-__fern_buf_push_u64
.globl __fern_buf_push_decimal
.type __fern_buf_push_decimal, %function
__fern_buf_push_decimal:
    stp x29, x30, [sp, #-64]!
    mov x29, sp
    add x8, sp, #40
    adrp x11, .Ldecimal_pairs
    add x11, x11, :lo12:.Ldecimal_pairs
    mov x9, #0xf5c3
    movk x9, #0x5c28, lsl #16
    movk x9, #0xc28f, lsl #32
    movk x9, #0x28f5, lsl #48
    mov x12, #100
.Ldecimal_loop:
    cmp x1, #100
    b.lo .Ldecimal_tail
    lsr x10, x1, #2
    umulh x10, x10, x9
    lsr x10, x10, #2
    msub x13, x10, x12, x1
    ldrh w13, [x11, x13, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    mov x1, x10
    b .Ldecimal_loop
.Ldecimal_tail:
    cmp x1, #10
    b.lo .Ldecimal_one
    ldrh w13, [x11, x1, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    b .Ldecimal_copy
.Ldecimal_one:
    add w13, w1, #48
    sub x8, x8, #1
    strb w13, [x8]
.Ldecimal_copy:
    add x2, sp, #40
    sub x2, x2, x8
    ldr x3, [x0, #8]
    add x4, x3, x2
    ldr x5, [x0, #16]
    cmp x4, x5
    b.hi .Ldecimal_grow
.Ldecimal_fits:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x3
.Ldecimal_byte:
    ldrb w6, [x8], #1
    strb w6, [x5], #1
    subs x2, x2, #1
    b.ne .Ldecimal_byte
    ldp x29, x30, [sp], #64
    ret
.Ldecimal_grow:
    str x0, [sp, #40]
    stp x2, x8, [sp, #48]
    mov x1, x4
    bl __fern_buf_reserve
    ldr x0, [sp, #40]
    ldp x2, x8, [sp, #48]
    ldr x3, [x0, #8]
    add x4, x3, x2
    b .Ldecimal_fits
.size __fern_buf_push_decimal, .-__fern_buf_push_decimal
    .section .rodata
.Ldecimal_pairs:
    .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
    .text
.globl __fern_buf_len
.type __fern_buf_len, %function
__fern_buf_len:
    ldr x0, [x0, #8]
    ret
.size __fern_buf_len, .-__fern_buf_len
.globl __fern_buf_clear
.type __fern_buf_clear, %function
__fern_buf_clear:
    str xzr, [x0, #8]
    mov x0, #0
    ret
.size __fern_buf_clear, .-__fern_buf_clear
.globl __fern_buf_take
.type __fern_buf_take, %function
__fern_buf_take:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    bl __fn___fern_buf_take_text
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_take, .-__fern_buf_take
__fn___fern_buf_text_part:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_buf_text_part.k:
__fn___fern_buf_text_part.r:
.Lssa___fern_buf_text_part_0:
    ldrb w11, [x0, x9]
    cmp x11, #128
    b.ge .Lssa___fern_buf_text_part_18
.Lssa___fern_buf_text_part_20:
    mov x0, #1
    ret
.Lssa___fern_buf_text_part_18:
    cmp x11, #194
    b.lt .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_17:
    cmp x11, #223
    b.gt .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_16:
    mov x12, #2
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_15:
    cmp x11, #224
    b.lt .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_14:
    cmp x11, #239
    b.gt .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_13:
    mov x12, #3
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_12:
    cmp x11, #240
    b.lt .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_11:
    cmp x11, #244
    b.gt .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_10:
    mov x12, #4
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_9:
    mov x12, #0
.Lssa___fern_buf_text_part_8:
.Lssa___fern_buf_text_part_7:
    sub x10, x10, x9
    sxtw x10, w10
    mov x13, #1
.Lssa___fern_buf_text_part_52:
    cmp x13, x12
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_67:
    cmp x13, x10
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_66:
    add x14, x9, x13
    sxtw x14, w14
    ldrb w15, [x0, x14]
    cmp x15, #128
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_65:
    cmp x15, #191
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_63:
    cmp x13, #1
    b.ne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_62:
    cmp x11, #224
    b.ne .Lssa___fern_buf_text_part_60
.Lssa___fern_buf_text_part_61:
    cmp x15, #160
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_60:
    cmp x11, #237
    b.ne .Lssa___fern_buf_text_part_58
.Lssa___fern_buf_text_part_59:
    cmp x15, #159
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_58:
    cmp x11, #240
    b.ne .Lssa___fern_buf_text_part_56
.Lssa___fern_buf_text_part_57:
    cmp x15, #144
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_56:
    cmp x11, #244
    b.ne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_55:
    cmp x15, #143
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_53:
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___fern_buf_text_part_67
.Lssa___fern_buf_text_part_4:
    mov x10, #0
    sub x10, x10, x13
    sxtw x10, w10
    cmp x13, x12
    csel x0, x13, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn___fern_buf_take_text:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_buf_take_text.k:
__fn___fern_buf_take_text.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x0
.Lssa___fern_buf_take_text_0:
    ldr x9, [x19, #8]
    cmp x9, #0
    b.lt .Lssa___fern_buf_take_text_16
.Lssa___fern_buf_take_text_17:
    movn w10, #32768, lsl #16
    cmp x9, x10
    b.le .Lssa___fern_buf_take_text_14
.Lssa___fern_buf_take_text_16:
    mov x10, #-1
    mov x0, x10
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x10, #0
    mov x1, x10
    bl __fern_str_box_hdr
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_14:
    sxtw x20, w9
    cmp x20, #0
    b.ne .Lssa___fern_buf_take_text_11
.Lssa___fern_buf_take_text_13:
    adrp x0, .SB6
    add x0, x0, :lo12:.SB6
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_11:
    ldr x21, [x19, #0]
    ldr x22, =9259542123273814144
.Lssa___fern_buf_take_text_10:
    mov x23, x9
    mov x24, #0
    mov x25, #0
.Lssa___fern_buf_take_text_30:
    cmp x24, x20
    b.ge .Lssa___fern_buf_take_text_9
.Lssa___fern_buf_take_text_40:
    sub x9, x20, x24
    sxtw x9, w9
    cmp x9, #8
    b.lt .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_39:
    add x9, x21, x24
    ldr x11, [x9, #0]
    and x11, x11, x22
    cmp x11, #0
    b.ne .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_38:
    add x11, x24, #8
    sxtw x24, w11
    cmp x24, x20
    b.ge .Lssa___fern_buf_take_text_9
    b .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_34:
    mov x0, x21
    mov x9, x24
    mov x10, x20
    bl __fn___fern_buf_text_part.r
    cmp x0, #0
    b.ge .Lssa___fern_buf_take_text_32
.Lssa___fern_buf_take_text_33:
    add x11, x0, #3
    sxtw x11, w11
    add x11, x23, x11
    sub x9, x24, x0
    sxtw x9, w9
    mov x23, x11
    mov x24, x9
    mov x25, #1
    b .Lssa___fern_buf_take_text_30
.Lssa___fern_buf_take_text_32:
    add x24, x24, x0
    sxtw x24, w24
.Lssa___fern_buf_take_text_31:
    cmp x24, x20
    b.lt .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_9:
    movn w9, #32768, lsl #16
    cmp x23, x9
    b.le .Lssa___fern_buf_take_text_6
.Lssa___fern_buf_take_text_8:
    mov x9, #-1
    mov x0, x9
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x9, #0
    mov x1, x9
    bl __fern_str_box_hdr
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_6:
    sxtw x23, w23
    mov x0, x23
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    cbz x25, .Lssa___fern_buf_take_text_2
.Lssa___fern_buf_take_text_5:
.Lssa___fern_buf_take_text_4:
    mov x25, #0
    mov x26, #0
    mov x27, #0
.Lssa___fern_buf_take_text_70:
    cmp x25, x20
    b.ge .Lssa___fern_buf_take_text_3
.Lssa___fern_buf_take_text_80:
    sub x11, x20, x25
    sxtw x11, w11
    cmp x11, #8
    b.lt .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_79:
    add x11, x21, x25
    ldr x9, [x11, #0]
    and x9, x9, x22
    cmp x9, #0
    b.ne .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_78:
    add x9, x25, #8
    sxtw x25, w9
    cmp x25, x20
    b.ge .Lssa___fern_buf_take_text_3
    b .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_74:
    mov x0, x21
    mov x9, x25
    mov x10, x20
    bl __fn___fern_buf_text_part.r
    mov x28, x0
    cmp x28, #0
    b.ge .Lssa___fern_buf_take_text_72
.Lssa___fern_buf_take_text_73:
    sxtw x9, w27
    add x9, x24, x9
    add x11, x21, x26
    sub x10, x25, x26
    sxtw x10, w10
    str x10, [sp, #56]
    mov x2, x10
    mov x1, x11
    mov x0, x9
    cbz x2, .Lssa___fern_buf_take_text_mcd338
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb338
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc338:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct338
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc338
.Lssa___fern_buf_take_text_mct338:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd338
.Lssa___fern_buf_take_text_mcb338:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb338
.Lssa___fern_buf_take_text_mcd338:
    mov x0, #0
    ldr x10, [sp, #56]
    add x10, x27, x10
    sxtw x10, w10
    mov x11, #239
    strb w11, [x24, x10]
    add x9, x10, #1
    sxtw x9, w9
    mov x11, #191
    strb w11, [x24, x9]
    add x12, x10, #2
    sxtw x12, w12
    mov x11, #189
    strb w11, [x24, x12]
    add x10, x10, #3
    sub x9, x25, x28
    sxtw x9, w9
    mov x25, x9
    mov x26, x9
    mov x27, x10
    b .Lssa___fern_buf_take_text_70
.Lssa___fern_buf_take_text_72:
    add x25, x25, x28
    sxtw x25, w25
.Lssa___fern_buf_take_text_71:
    cmp x25, x20
    b.lt .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_3:
    sxtw x27, w27
    add x27, x24, x27
    add x9, x21, x26
    sub x26, x20, x26
    sxtw x26, w26
    mov x2, x26
    mov x1, x9
    mov x0, x27
    cbz x2, .Lssa___fern_buf_take_text_mcd435
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb435
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc435:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct435
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc435
.Lssa___fern_buf_take_text_mct435:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd435
.Lssa___fern_buf_take_text_mcb435:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb435
.Lssa___fern_buf_take_text_mcd435:
    mov x0, #0
    b .Lssa___fern_buf_take_text_1
.Lssa___fern_buf_take_text_2:
    mov x2, x20
    mov x1, x21
    mov x0, x24
    cbz x2, .Lssa___fern_buf_take_text_mcd442
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb442
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc442:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct442
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc442
.Lssa___fern_buf_take_text_mct442:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd442
.Lssa___fern_buf_take_text_mcb442:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb442
.Lssa___fern_buf_take_text_mcd442:
    mov x0, #0
.Lssa___fern_buf_take_text_1:
    mov x9, #0
    str x9, [x19, #8]
    mov x0, x24
    mov x1, x23
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.globl __fern_buf_free
.type __fern_buf_free, %function
__fern_buf_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cbz x19, .Lbuffree_ret
    ldr x5, [x19]
    cbz x5, .Lbuffree_ctl
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_data_large
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x6, lsl #3
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x6
    mov x0, x5
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    b .Lbuffree_data_done
.Lbuffree_data_large:
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x6, lsl #3
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x6
    mov x0, x5
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lbuffree_data_done:
.Lbuffree_ctl:
    mov x5, x19
    mov x6, #4
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_ctlblk_large
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x6, lsl #3
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x6
    mov x0, x5
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    b .Lbuffree_ctlblk_done
.Lbuffree_ctlblk_large:
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x6, lsl #3
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x6
    mov x0, x5
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lbuffree_ctlblk_done:
.Lbuffree_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_free, .-__fern_buf_free
__fn___alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    bl __fern_alloc
    ldp x29, x30, [sp], #16
    ret
__fn___free:
    ret
__fn___memset:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    ldr x2, [x29, #48]
    cbz x2, .Lfnmemset_done
.Lfnmemset_loop:
    strb w1, [x0], #1
    subs x2, x2, #1
    bne .Lfnmemset_loop
.Lfnmemset_done:
    ldp x29, x30, [sp], #16
    ret
__fn___load_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldrsw x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str w1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_i64:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str x1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___ptr_width:
    mov x0, #8
    ret
__fn___fern_rc_inc:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcinc_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcinc_ret
    and x0, x0, #0xfffffffffffffffd
    ldur w1, [x0, #-8]
    movz w9, #64206
    movk w9, #32493, lsl #16
    cmp w1, w9
    b.ne .Lshrcinc_live
    bl __fern_san_abort_uaf
.Lshrcinc_live:
    tbnz w1, #31, .Lshrcinc_ret
    add w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcinc_ret:
    ldr x0, [sp]
    ret
__fn___fern_rc_dec:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcdec_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcdec_ret
    ldur w1, [x0, #-8]
    movz w9, #64206
    movk w9, #32493, lsl #16
    cmp w1, w9
    b.ne .Lshrcdec_live
    bl __fern_san_abort_uaf
.Lshrcdec_live:
    tbnz w1, #31, .Lshrcdec_ret
    cmp w1, #0
    bgt .Lshrcdec_dec
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w11, [x10]
    add w11, w11, #1
    str w11, [x10]
    bl __fern_san_abort
.Lshrcdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcdec_ret:
    ret
__fn___fern_rc_is_unique:
    ldr x2, [sp]
    mov x0, #0
    tbnz x2, #0, .Lshuniq_ret
    mov x9, #0x10000
    cmp x2, x9
    blo .Lshuniq_ret
    and x2, x2, #0xfffffffffffffffd
    ldur w3, [x2, #-8]
    movz w9, #64206
    movk w9, #32493, lsl #16
    cmp w3, w9
    b.ne .Lshuniq_live
    bl __fern_san_abort_uaf
.Lshuniq_live:
    tbnz w3, #31, .Lshuniq_ret
    cmp w3, #1
    bne .Lshuniq_ret
    mov x0, #1
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    ldr x0, [sp]
__fn___fern_arr_inc_elems.r:
    mov x9, #0x10000
    cmp x0, x9
    blo .Laie_ret
    ldur w1, [x0, #-8]
    movz w9, #64206
    movk w9, #32493, lsl #16
    cmp w1, w9
    b.ne .Laie_live
    bl __fern_san_abort_uaf
.Laie_live:
    tbnz w1, #31, .Laie_ret
    stp x19, x30, [sp, #-16]!
    stp x20, x21, [sp, #-16]!
    mov x19, x0
    ldr x20, [x19]
    mov x21, #0
.Laie_loop:
    cmp x21, x20
    bge .Laie_done
    add x9, x21, #1
    ldr x0, [x19, x9, lsl #3]
    str x0, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    add x21, x21, #1
    b .Laie_loop
.Laie_done:
    mov x0, x19
    ldp x20, x21, [sp], #16
    ldp x19, x30, [sp], #16
.Laie_ret:
    ret
__fn___fern_str_grow:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsg_body
__fn___fern_str_grow_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbnz x2, #63, .Lsg_no
    ldr x4, [x1, #8]
    cmp x3, x4
    b.gt .Lsg_no
    subs x3, x3, x2
    b.lt .Lsg_no
    ldr x1, [x1]
    add x1, x1, x2
.Lsg_body:
    tbnz x0, #0, .Lsg_no
    mov x9, #0x10000
    cmp x0, x9
    blo .Lsg_no
    ldur w2, [x0, #-8]
    movz w9, #64206
    movk w9, #32493, lsl #16
    cmp w2, w9
    b.ne .Lsg_live
    bl __fern_san_abort_uaf
.Lsg_live:
    cmp w2, #1
    b.ne .Lsg_no
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbnz x9, .Lsg_no
    ldur w5, [x0, #-4]
    mov w6, #0x4F57
    movk w6, #0x4752, lsl #16
    cmp w5, w6
    b.ne .Lsg_fused
    add x6, x4, #39
    lsr x6, x6, #3
    ldur x7, [x0, #-16]
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_copy
.Lsg_fused:
    mov w6, #32781
    movk w6, #29519, lsl #16
    cmp w5, w6
    b.ne .Lsg_no
    add x5, x2, #31
    lsr x5, x5, #3
    add x6, x4, #31
    lsr x6, x6, #3
    cmp x6, x5
    b.eq .Lsg_copy
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lsg_large
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x7, x30, [sp], #16
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_fits
.Lsg_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsg_no
    lsl x7, x5, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x7, x7, #3
    cmp x6, x7
    b.hi .Lsg_no
.Lsg_fits:
    sub x7, x6, x5
    adrp x9, __fern_lc_alloc_bytes
    add x9, x9, :lo12:__fern_lc_alloc_bytes
    ldr x10, [x9]
    add x10, x10, x7, lsl #3
    str x10, [x9]
.Lsg_copy:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsg_d
    cmp x3, #8
    b.lo .Lsg_b
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsg_w:
    cmp x5, x10
    b.hs .Lsg_t
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsg_w
.Lsg_t:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsg_d
.Lsg_b:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsg_b
.Lsg_d:
    mov x0, #1
    ret
.Lsg_no:
    mov x0, #0
    ret
__fn___fern_str_grow_fresh:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsgf_body
__fn___fern_str_grow_fresh_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbz x2, #63, .Lsgf_lo
    b __fern_slice_abort_leaf
.Lsgf_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lsgf_hi
    b __fern_slice_abort_leaf
.Lsgf_hi:
    subs x3, x3, x2
    b.ge .Lsgf_range
    b __fern_slice_abort_leaf
.Lsgf_range:
    ldr x1, [x1]
    add x1, x1, x2
.Lsgf_body:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbz x9, .Lsgf_sized
    b __fern_alloc_size_abort
.Lsgf_sized:
    add x5, x4, #39
    lsr x5, x5, #3
    add x6, x2, #31
    lsr x6, x6, #3
    lsl x6, x6, #1
    cmp x6, x5
    csel x6, x5, x6, lo
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lsgf_large
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
    b .Lsgf_alloc
.Lsgf_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsgf_alloc
    lsl x7, x6, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x6, x7, #3
.Lsgf_alloc:
    stp x0, x1, [sp, #-48]!
    stp x2, x3, [sp, #16]
    str x6, [sp, #32]
    lsl x0, x6, #3
    bl __fern_alloc
    ldr x6, [sp, #32]
    ldp x2, x3, [sp, #16]
    ldp x4, x1, [sp], #48
    str x6, [x0]
    mov w5, #1
    str w5, [x0, #8]
    mov w5, #0x4F57
    movk w5, #0x4752, lsl #16
    str w5, [x0, #12]
    add x5, x0, #32
    str x5, [x0, #16]
    add x6, x2, x3
    str x6, [x0, #24]
    ldr x6, [x4]
    cbz x2, .Lsgf_ad
    cmp x2, #8
    b.lo .Lsgf_ab
    add x9, x6, x2
    sub x9, x9, #8
    add x10, x5, x2
    sub x10, x10, #8
.Lsgf_aw:
    cmp x5, x10
    b.hs .Lsgf_at
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_aw
.Lsgf_at:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_ad
.Lsgf_ab:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x2, x2, #1
    cbnz x2, .Lsgf_ab
.Lsgf_ad:
    add x5, x0, #32
    ldr x2, [x0, #24]
    sub x2, x2, x3
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsgf_bd
    cmp x3, #8
    b.lo .Lsgf_bb
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsgf_bw:
    cmp x5, x10
    b.hs .Lsgf_bt
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_bw
.Lsgf_bt:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_bd
.Lsgf_bb:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsgf_bb
.Lsgf_bd:
    add x0, x0, #16
    ldp x29, x30, [sp], #16
    ret
__fn___fern_str_borrow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    mov x0, #24
    bl __fern_alloc
    mov w2, #1
    str w2, [x0]
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    stur w3, [x0, #4]
    ldr x2, [sp, #32]
    str x2, [x0, #8]
    ldr x3, [sp, #16]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fn___fern_alloc_reuse:
    ldr x0, [sp, #16]
    cbz x0, .Lsarelo_fresh
    ldr x1, [sp]
    ldur x2, [x0, #-16]
    cmp x2, x1
    beq .Lsarelo_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_arr_dec.r
    ldp x29, x30, [sp], #16
.Lsarelo_fresh:
    ldr x0, [sp]
    b __fern_arr_box
.Lsarelo_ret:
    ret
__fn___fern_rc_underflow_count:
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w0, [x10]
    ret
__fern_large_push:
    mov x3, #1
    lsl x3, x3, #34
    cmp x2, x3
    b.hi .Llpush_ret
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x4, [x3]
    add x4, x4, x2
    str x4, [x3]
    ret
__fern_large_push_now:
    mov x3, #1
    lsl x3, x3, #19
    cmp x2, x3
    csel x2, x3, x2, lo
    clz x3, x2
    mov x4, #61
    sub x4, x4, x3
    mov x3, #1
    lsl x3, x3, x4
    sub x3, x3, #1
    add x2, x2, x3
    bic x2, x2, x3
    clz x3, x2
    mov x4, #61
    sub x3, x4, x3
    lsr x4, x2, x3
    add x4, x4, x3, lsl #2
    sub x4, x4, #72
    mov x2, x4
    adrp x3, __fern_large_freelist
    add x3, x3, :lo12:__fern_large_freelist
    ldr x4, [x3, x2, lsl #3]
    cmp x4, x1
    b.eq __fern_double_free_abort_leaf
    str x4, [x1]
    str x1, [x3, x2, lsl #3]
.Llpush_ret:
    ret
__fern_quar_push:
    cmp x1, #3
    b.lo .Lquar_ret
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    stp x2, x3, [sp, #-16]!
    stp x4, x5, [sp, #-16]!
    stp x6, x7, [sp, #-16]!
    str x8, [sp, #-16]!
    cmp x2, #8
    b.eq .Lquar_meta0
    movz w9, #64206
    movk w9, #32493, lsl #16
    str w9, [x0]
    str x1, [x0, #8]
    b .Lquar_link
.Lquar_meta0:
    str x1, [x0]
.Lquar_link:
    str xzr, [x0, #16]
    adrp x10, __fern_quar_tail
    add x10, x10, :lo12:__fern_quar_tail
    ldr x11, [x10]
    cbz x11, .Lquar_first
    str x0, [x11, #16]
    b .Lquar_tail
.Lquar_first:
    adrp x12, __fern_quar_head
    add x12, x12, :lo12:__fern_quar_head
    str x0, [x12]
.Lquar_tail:
    str x0, [x10]
    adrp x12, __fern_quar_bytes
    add x12, x12, :lo12:__fern_quar_bytes
    ldr x13, [x12]
    add x13, x13, x1, lsl #3
    str x13, [x12]
    movz w9, #64206
    movk w9, #32493, lsl #16
    orr x9, x9, x9, lsl #32
    add x10, x0, #24
    sub x11, x1, #3
    cbz x11, .Lquar_fill_done
.Lquar_fill:
    str x9, [x10], #8
    subs x11, x11, #1
    b.ne .Lquar_fill
.Lquar_fill_done:
.Lquar_evict:
    movz x14, #0
    movk x14, #1024, lsl #16
    adrp x12, __fern_quar_bytes
    add x12, x12, :lo12:__fern_quar_bytes
    ldr x13, [x12]
    cmp x13, x14
    b.ls .Lquar_done
    adrp x12, __fern_quar_head
    add x12, x12, :lo12:__fern_quar_head
    ldr x0, [x12]
    ldr x11, [x0, #16]
    str x11, [x12]
    cbnz x11, .Lquar_unlinked
    adrp x10, __fern_quar_tail
    add x10, x10, :lo12:__fern_quar_tail
    str xzr, [x10]
.Lquar_unlinked:
    movz w9, #64206
    movk w9, #32493, lsl #16
    ldr w11, [x0]
    cmp w11, w9
    b.ne .Lquar_size0
    ldr x1, [x0, #8]
    str wzr, [x0]
    b .Lquar_recycle
.Lquar_size0:
    ldr w11, [x0, #8]
    cmp w11, w9
    b.ne .Lquar_waf
    ldr x1, [x0]
    str wzr, [x0, #8]
.Lquar_recycle:
    movz w9, #64206
    movk w9, #32493, lsl #16
    orr x9, x9, x9, lsl #32
    add x10, x0, #24
    sub x11, x1, #3
    cbz x11, .Lquar_scan_done
.Lquar_scan:
    ldr x12, [x10], #8
    cmp x12, x9
    b.ne .Lquar_waf
    subs x11, x11, #1
    b.ne .Lquar_scan
.Lquar_scan_done:
    adrp x12, __fern_quar_bytes
    add x12, x12, :lo12:__fern_quar_bytes
    ldr x13, [x12]
    sub x13, x13, x1, lsl #3
    str x13, [x12]
    mov x9, #0x10000
    cmp x1, x9
    b.hs .Lquar_large
    cmp x1, #256
    b.ls .L204
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L204:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x4, [x3, x1, lsl #3]
    str x4, [x0]
    str x0, [x3, x1, lsl #3]
    b .Lquar_evict
.Lquar_large:
    lsl x2, x1, #3
    mov x1, x0
    bl __fern_large_push_now
    b .Lquar_evict
.Lquar_waf:
    b __fern_san_abort_waf
.Lquar_done:
    ldr x8, [sp], #16
    ldp x6, x7, [sp], #16
    ldp x4, x5, [sp], #16
    ldp x2, x3, [sp], #16
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
.Lquar_ret:
    ret
__fern_raw_alloc_san:
    stp x29, x30, [sp, #-32]!
    mov x29, sp
    str x0, [sp, #16]
    add x0, x0, #16
    bl __fern_alloc
    adrp x9, __fern_lc_alloc_bytes
    add x9, x9, :lo12:__fern_lc_alloc_bytes
    ldr x10, [x9]
    sub x10, x10, #16
    str x10, [x9]
    ldr x1, [sp, #16]
    add x1, x1, #7
    lsr x1, x1, #3
    add x9, x0, x1, lsl #3
    movz w10, #64206
    movk w10, #32493, lsl #16
    orr x10, x10, x10, lsl #32
    str x10, [x9]
    str x10, [x9, #8]
    ldp x29, x30, [sp], #32
    ret
__fern_raw_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    cbz x0, .Lrawfree_done
    adrp x9, __fern_heap_base
    add x9, x9, :lo12:__fern_heap_base
    ldr x9, [x9]
    cmp x0, x9
    b.lo .Lrawfree_bad
    adrp x9, __fern_heap_end
    add x9, x9, :lo12:__fern_heap_end
    ldr x9, [x9]
    cmp x0, x9
    b.hs .Lrawfree_bad
    add x1, x1, #7
    lsr x5, x1, #3
    add x9, x0, x5, lsl #3
    movz w10, #64206
    movk w10, #32493, lsl #16
    orr x10, x10, x10, lsl #32
    ldr x11, [x9]
    cmp x11, x10
    b.ne __fern_san_abort_hbo
    ldr x11, [x9, #8]
    cmp x11, x10
    b.ne __fern_san_abort_hbo
    cbz x5, .Lrawfree_done
    ldr w9, [x0]
    movz w10, #64206
    movk w10, #32493, lsl #16
    cmp w9, w10
    b.ne .Lrawfree_fresh
    adrp x10, __fern_quar_head
    add x10, x10, :lo12:__fern_quar_head
    ldr x10, [x10]
.Lrawfree_qscan:
    cbz x10, .Lrawfree_fresh
    cmp x10, x0
    b.eq __fern_double_free_abort
    ldr x10, [x10, #16]
    b .Lrawfree_qscan
.Lrawfree_fresh:
    movz w9, #64206
    movk w9, #32493, lsl #16
    stur w9, [x0]
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x5, lsl #3
    str x10, [x3]
    add x5, x5, #2
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x5
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lrawfree_done:
    ldp x29, x30, [sp], #16
    ret
.Lrawfree_bad:
    b __fern_free_range_abort
__fn___fern_arr_dec:
    ldr x0, [sp]
__fn___fern_arr_dec.r:
    cmp x0, #16, lsl #12
    blo .Larrdec_ret
__fn___fern_arr_dec.u:
    ldur w1, [x0, #-8]
    movz w9, #64206
    movk w9, #32493, lsl #16
    cmp w1, w9
    b.ne .Larrdec_live
    bl __fern_san_abort_uaf
.Larrdec_live:
    cmp w1, #1
    bne .Larrdec_shared
    movz w9, #64206
    movk w9, #32493, lsl #16
    stur w9, [x0, #-8]
    ldur x1, [x0, #-16]
    add x1, x1, #3
    sub x2, x0, #16
    cmp x1, #256
    b.hi .Larrdec_big
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x9, [x3]
    add x9, x9, #1
    str x9, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x9, [x3]
    add x9, x9, x1, lsl #3
    str x9, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x1
    mov x0, x2
    mov x1, x10
    mov x2, #8
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Larrdec_ret:
    ret
.Larrdec_shared:
    tbnz w1, #31, .Larrdec_ret
    bgt .Larrdec_dec
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    bl __fern_san_abort
    ret
.Larrdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
    ret
.Larrdec_big:
    mov x9, #0x10000
    cmp x1, x9
    bhs .Larrdec_large
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x9, [x3]
    add x9, x9, #1
    str x9, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x9, [x3]
    add x9, x9, x1, lsl #3
    str x9, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x1
    mov x0, x2
    mov x1, x10
    mov x2, #8
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    ret
.Larrdec_large:
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x9, [x3]
    add x9, x9, #1
    str x9, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x9, [x3]
    add x9, x9, x1, lsl #3
    str x9, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x1
    mov x0, x2
    mov x1, x10
    mov x2, #8
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    ret
__fn___fern_str_free:
    ldr x0, [sp]
__fn___fern_str_free.r:
    tbnz x0, #0, .Lstrfree_ret
    cmp x0, #16, lsl #12
    blo .Lstrfree_ret
__fn___fern_str_free.u:
    mov x9, #0x10000
    ldur w4, [x0, #-8]
    movz w10, #64206
    movk w10, #32493, lsl #16
    cmp w4, w10
    b.ne .Lstrfree_live
    bl __fern_san_abort_uaf
.Lstrfree_live:
    cmp w4, #1
    bne .Lstrfree_shared
    ldur w2, [x0, #-4]
    mov w3, #32781
    movk w3, #29519, lsl #16
    cmp w2, w3
    beq .Lstrfree_fused
    mov w3, #0x4F57
    movk w3, #0x4752, lsl #16
    cmp w2, w3
    beq .Lstrfree_grown
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    cmp w2, w3
    beq .Lstrfree_box
    ldr x1, [x0]
    ldr x2, [x0, #8]
    cmp x1, x9
    blo .Lstrfree_box
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrfree_box
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrfree_box
    cmp x2, #0
    ble .Lstrfree_box
    add x2, x2, #7
    lsr x2, x2, #3
    cmp x2, x9
    bhs .Lstrfree_box
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x2, lsl #3
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x2
    mov x0, x1
    mov x1, x10
    mov x2, #16
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lstrfree_box:
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x0, #-8]
    sub x1, x0, #8
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, #24
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, #3
    mov x0, x1
    mov x1, x10
    mov x2, #0
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    b .Lstrfree_ret
.Lstrfree_grown:
    ldur x2, [x0, #-16]
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x0, #-8]
    sub x1, x0, #16
    b .Lstrfree_block
.Lstrfree_fused:
    ldr x2, [x0, #8]
    add x2, x2, #7
    lsr x2, x2, #3
    add x2, x2, #3
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x0, #-8]
    sub x1, x0, #8
.Lstrfree_block:
    cmp x2, #256
    b.hi .Lstrfree_fused_big
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x2, lsl #3
    str x10, [x3]
    b .Lstrfree_quar
    b .Lstrfree_ret
.Lstrfree_fused_big:
    cmp x2, x9
    bhs .Lstrfree_fused_large
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x2, lsl #3
    str x10, [x3]
    b .Lstrfree_quar
.Lstrfree_fused_large:
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, x2, lsl #3
    str x10, [x3]
.Lstrfree_quar:
    str x30, [sp, #-16]!
    mov x11, x2
    sub x2, x0, #8
    sub x2, x2, x1
    mov x0, x1
    mov x1, x11
    bl __fern_quar_push
    ldr x30, [sp], #16
    b .Lstrfree_ret
.Lstrfree_shared:
    tbnz w4, #31, .Lstrfree_ret
    blt .Lstrfree_uf
    sub w4, w4, #1
    stur w4, [x0, #-8]
    ret
.Lstrfree_uf:
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    bl __fern_san_abort
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    ldr x0, [sp]
    tbnz x0, #0, .Lstrvfree_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lstrvfree_ret
    ldur w4, [x0, #-8]
    movz w10, #64206
    movk w10, #32493, lsl #16
    cmp w4, w10
    b.ne .Lstrvfree_live
    bl __fern_san_abort_uaf
.Lstrvfree_live:
    tbnz w4, #31, .Lstrvfree_view
    b __fn___fern_str_free
.Lstrvfree_view:
    sub x1, x0, #8
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrvfree_ret
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrvfree_ret
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x0, #-8]
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x10, [x3]
    add x10, x10, #1
    str x10, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x10, [x3]
    add x10, x10, #24
    str x10, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, #3
    mov x0, x1
    mov x1, x10
    mov x2, #0
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_arr_free.k:
__fn___fern_str_arr_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_arr_free_0:
    movz x9, #1, lsl #16
    cmp x19, x9
    b.lo .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    ldrsw x20, [x19]
.Lssa___fern_str_arr_free_4:
    mov x9, #0
.Lssa___fern_str_arr_free_15:
    cmp x9, x20
    b.ge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    add x21, x9, #1
    ldr x9, [x19, x21, lsl #3]
    mov x0, x9
    bl __fn___fern_str_free.r
    mov x9, x21
    cmp x9, x20
    b.lt .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    mov x0, x19
    bl __fn___fern_arr_dec.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_drop_arr_ptr:
    ret
    .section .bss
    .align 8
__fern_envp: .quad 0
    .section .text
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_u8:
    .quad 0
    .text
.globl __fern_alloc_u8
.type __fern_alloc_u8, %function
__fern_alloc_u8:
    tbz w0, #31, .Lfern_alloc_u8_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_u8_sized:
    cbz w0, .Lfern_alloc_u8_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x0, x19
    bl __fern_arr_box
    add x2, x0, #8
    mov w1, w19
.Lfern_alloc_u8_zero:
    cbz x1, .Lfern_alloc_u8_done
    str xzr, [x2], #8
    sub x1, x1, #1
    b .Lfern_alloc_u8_zero
.Lfern_alloc_u8_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_u8_empty:
    adrp x0, .Lfern_empty_u8
    add x0, x0, :lo12:.Lfern_empty_u8
    ret
.size __fern_alloc_u8, .-__fern_alloc_u8
    .bss
    .align 3
__fern_lc_alloc_count: .quad 0
__fern_lc_alloc_bytes: .quad 0
__fern_lc_rt_req: .quad 0
__fern_lc_free_count: .quad 0
__fern_lc_free_bytes: .quad 0
__fern_lc_exited: .quad 0
    .section .rodata
.Llc_a:
    .ascii "leakcheck: allocs="
.Llc_f:
    .ascii " frees="
.Llc_l:
    .ascii " live_bytes="
.Llc_x:
    .ascii " from=exit"
.Llc_nl:
    .ascii "\n"
.Lsan_leak:
    .ascii "fern-sanitizer: leak "
.Lsan_bytesin:
    .ascii " bytes in "
.Lsan_blocks:
    .ascii " blocks"
    .text
    .globl __fern_lc_report_exit
__fern_lc_report_exit:
    adrp x9, __fern_lc_exited
    add x9, x9, :lo12:__fern_lc_exited
    mov x10, #1
    str x10, [x9]
    .globl __fern_lc_report
__fern_lc_report:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    adrp x12, __fern_quar_head
    add x12, x12, :lo12:__fern_quar_head
    ldr x0, [x12]
.Lquar_end_loop:
    cbz x0, .Lquar_end_done
    movz w9, #64206
    movk w9, #32493, lsl #16
    ldr w11, [x0]
    cmp w11, w9
    b.ne .Lquar_end_size0
    ldr x1, [x0, #8]
    b .Lquar_end_scan
.Lquar_end_size0:
    ldr w11, [x0, #8]
    cmp w11, w9
    b.ne __fern_san_abort_waf
    ldr x1, [x0]
.Lquar_end_scan:
    movz w9, #64206
    movk w9, #32493, lsl #16
    orr x9, x9, x9, lsl #32
    add x10, x0, #24
    sub x11, x1, #3
    cbz x11, .Lquar_atexit_done
.Lquar_atexit:
    ldr x12, [x10], #8
    cmp x12, x9
    b.ne __fern_san_abort_waf
    subs x11, x11, #1
    b.ne .Lquar_atexit
.Lquar_atexit_done:
    ldr x0, [x0, #16]
    b .Lquar_end_loop
.Lquar_end_done:
    adrp x1, .Llc_a
    add x1, x1, :lo12:.Llc_a
    mov x2, #18
    bl .Llc_write
    adrp x9, __fern_lc_alloc_count
    add x9, x9, :lo12:__fern_lc_alloc_count
    ldr x0, [x9]
    bl .Llc_wrnum
    adrp x1, .Llc_f
    add x1, x1, :lo12:.Llc_f
    mov x2, #7
    bl .Llc_write
    adrp x9, __fern_lc_free_count
    add x9, x9, :lo12:__fern_lc_free_count
    ldr x0, [x9]
    bl .Llc_wrnum
    adrp x1, .Llc_l
    add x1, x1, :lo12:.Llc_l
    mov x2, #12
    bl .Llc_write
    adrp x9, __fern_lc_alloc_bytes
    add x9, x9, :lo12:__fern_lc_alloc_bytes
    ldr x0, [x9]
    adrp x9, __fern_lc_free_bytes
    add x9, x9, :lo12:__fern_lc_free_bytes
    ldr x1, [x9]
    sub x0, x0, x1
    bl .Llc_wrnum
    adrp x9, __fern_lc_exited
    add x9, x9, :lo12:__fern_lc_exited
    ldr x0, [x9]
    cbz x0, .Llc_from_done
    adrp x1, .Llc_x
    add x1, x1, :lo12:.Llc_x
    mov x2, #10
    bl .Llc_write
.Llc_from_done:
    adrp x1, .Llc_nl
    add x1, x1, :lo12:.Llc_nl
    mov x2, #1
    bl .Llc_write
    adrp x9, __fern_lc_alloc_bytes
    add x9, x9, :lo12:__fern_lc_alloc_bytes
    ldr x10, [x9]
    adrp x9, __fern_lc_free_bytes
    add x9, x9, :lo12:__fern_lc_free_bytes
    ldr x9, [x9]
    subs x10, x10, x9
    b.le .Lsan_leak_done
    adrp x1, .Lsan_leak
    add x1, x1, :lo12:.Lsan_leak
    mov x2, #21
    bl .Llc_write
    mov x0, x10
    bl .Llc_wrnum
    adrp x1, .Lsan_bytesin
    add x1, x1, :lo12:.Lsan_bytesin
    mov x2, #10
    bl .Llc_write
    adrp x9, __fern_lc_alloc_count
    add x9, x9, :lo12:__fern_lc_alloc_count
    ldr x0, [x9]
    adrp x9, __fern_lc_free_count
    add x9, x9, :lo12:__fern_lc_free_count
    ldr x9, [x9]
    sub x0, x0, x9
    bl .Llc_wrnum
    adrp x1, .Lsan_blocks
    add x1, x1, :lo12:.Lsan_blocks
    mov x2, #7
    bl .Llc_write
    adrp x1, .Llc_nl
    add x1, x1, :lo12:.Llc_nl
    mov x2, #1
    bl .Llc_write
.Lsan_leak_done:
    ldp x29, x30, [sp], #16
    ret
.Llc_write:
    mov x0, #2
    mov x8, #64
    svc #0
    ret
.Llc_wrnum:
    sub sp, sp, #48
    str x30, [sp]
    add x3, sp, #32
    mov x4, #10
    mov x5, #0
    cmp x0, #0
    b.ge .Llc_wrnum_loop
    neg x0, x0
    mov x5, #1
.Llc_wrnum_loop:
    udiv x6, x0, x4
    msub x7, x6, x4, x0
    add x7, x7, #48
    sub x3, x3, #1
    strb w7, [x3]
    mov x0, x6
    cbnz x0, .Llc_wrnum_loop
    cbz x5, .Llc_wrnum_emit
    mov x7, #45
    sub x3, x3, #1
    strb w7, [x3]
.Llc_wrnum_emit:
    add x2, sp, #32
    sub x2, x2, x3
    mov x1, x3
    bl .Llc_write
    ldr x30, [sp]
    add sp, sp, #48
    ret
    .section .bss
    .align 8
__fern_sig_sp: .quad 0, 0
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
.Lmsg_illegal_instruction:
    .ascii "fern: illegal instruction\n"
.Lmsg_bus_error:
    .ascii "fern: bus error\n"
    .text
__fern_segv:
    cmp x0, #11
    b.ne .Lfern_fatal_signal
    ldr x9, [x1, #16]
    adrp x14, __fern_stack_top
    add x14, x14, :lo12:__fern_stack_top
    ldr x14, [x14]
    mov x15, #1
    lsl x15, x15, #30
    sub x14, x14, x15
    add x14, x14, #16
    sub x15, x9, x14
    mov x16, #1
    lsl x16, x16, #20
    cmp x15, x16
    b.hs .Lfern_segv_other
.Lfern_segv_overflow:
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_stack_overflow
    add x1, x1, :lo12:.Lmsg_stack_overflow
    mov x2, #21
    mov x0, #134
    b __fern_report
.Lfern_segv_other:
    stp x29, x30, [sp, #-16]!
    sub sp, sp, #32
    stp xzr, xzr, [sp]
    stp xzr, xzr, [sp, #16]
    bl .Lfern_fault_install
    add sp, sp, #32
    ldp x29, x30, [sp], #16
    ret
.Lfern_fault_install:
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x0, #11
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
    mov x0, #4
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
    mov x0, #7
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
.Lfern_fault_install_done:
    ret
.Lfern_fatal_signal:
    ldrsw x9, [x1, #8]
    cmp x9, #0
    b.le .Lfern_signal_sent
    mov x15, x0
    adrp x10, __fern_sig_sp
    add x10, x10, :lo12:__fern_sig_sp
    mov x9, sp
    str x9, [x10]
    str x30, [x10, #8]
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_illegal_instruction
    add x1, x1, :lo12:.Lmsg_illegal_instruction
    mov x2, #26
    cmp x15, #4
    b.eq .Lfern_fatal_report
    adrp x1, .Lmsg_bus_error
    add x1, x1, :lo12:.Lmsg_bus_error
    mov x2, #16
.Lfern_fatal_report:
    mov x0, #-1
    b __fern_report
.Lfern_signal_sent:
    add x0, x0, #128
    mov x8, #94
    svc #0
.Lfern_signal_resume:
    adrp x10, __fern_sig_sp
    add x10, x10, :lo12:__fern_sig_sp
    ldr x9, [x10]
    ldr x30, [x10, #8]
    mov sp, x9
    b .Lfern_segv_other
    .section .rodata
.Lfern_stack_map_failed_msg:
    .ascii "fern: could not map the stack\n"
    .text
.Lfern_stack_map_failed:
    adrp x1, .Lfern_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_stack_map_failed_msg
    mov x2, #30
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    adrp x1, .Lfern_stack_guard_failed_msg
    add x1, x1, :lo12:.Lfern_stack_guard_failed_msg
    mov x2, #40
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    adrp x1, .Lfern_signal_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_map_failed_msg
    mov x2, #37
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    adrp x1, .Lfern_signal_stack_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_failed_msg
    mov x2, #41
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    adrp x1, .Lfern_fault_handler_failed_msg
    add x1, x1, :lo12:.Lfern_fault_handler_failed_msg
    mov x2, #42
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=arm64-linux profile=diagnostic harden=0 pie=0 sanitize=1 backtrace=1 size=0 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .bss
    .align 3
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .align 3
__fern_bt_floor: .quad 0
    .text
.globl __fern_report
.type __fern_report, %function
__fern_abort_134:
    mov x0, #134
__fern_report:
    mov x19, x0
    mov x0, #2
    mov x8, #64
    svc #0
    b __fern_bt_exit
.size __fern_report, .-__fern_report
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .text
    .globl __fern_bt_exit
__fern_bt_exit:
    adrp x1, .Lmsg_bt
    add x1, x1, :lo12:.Lmsg_bt
    mov x2, #11
    mov x0, #2
    mov x8, #64
    svc #0
    mov x20, x29
    mov x21, #64
    mov x22, sp
.Lbt_loop:
    cmp x20, x22
    b.lo .Lbt_done
    and x23, x20, #7
    cbnz x23, .Lbt_done
    ldr x1, [x20, #8]
    cmp x1, #16, lsl #12
    b.lo .Lbt_done
    bl .Lbt_hex
    adrp x24, __fern_bt_floor
    add x24, x24, :lo12:__fern_bt_floor
    ldr x22, [x24]
    str xzr, [x24]
    add x23, x20, #8
    cmp x22, #0
    csel x22, x23, x22, eq
    ldr x20, [x20]
    adrp x24, __fern_stack_top
    add x24, x24, :lo12:__fern_stack_top
    ldr x24, [x24]
    cbz x24, .Lbt_next
    cmp x20, x24
    b.hs .Lbt_done
.Lbt_next:
    subs x21, x21, #1
    b.ne .Lbt_loop
.Lbt_done:
    tbnz x19, #63, .Lfern_signal_resume
    mov x0, x19
    mov x8, #94
    svc #0
.Lbt_hex:
    sub sp, sp, #32
    mov w2, #0x2020
    movk w2, #0x7830, lsl #16
    str w2, [sp]
    mov w2, #10
    strb w2, [sp, #20]
    mov x3, #16
    add x4, sp, #3
.Lbt_hloop:
    and x2, x1, #15
    cmp x2, #10
    add x5, x2, #87
    add x2, x2, #48
    csel x2, x5, x2, hs
    strb w2, [x4, x3]
    lsr x1, x1, #4
    subs x3, x3, #1
    b.ne .Lbt_hloop
    mov x0, #2
    mov x1, sp
    mov x2, #21
    mov x8, #64
    svc #0
    add sp, sp, #32
    ret
    .section .rodata
.Lsan_uaf:
    .ascii "fern-sanitizer: use-after-free (touched a quarantined block)\n"
    .text
    .globl __fern_san_abort_uaf
__fern_san_abort_uaf:
    adrp x1, .Lsan_uaf
    add x1, x1, :lo12:.Lsan_uaf
    mov x2, #61
    mov x0, #2
    mov x8, #64
    svc #0
    mov x19, #124
    b __fern_bt_exit
    .section .rodata
.Lsan_waf:
    .ascii "fern-sanitizer: write-after-free (a quarantined block was written)\n"
    .text
    .globl __fern_san_abort_waf
__fern_san_abort_waf:
    adrp x1, .Lsan_waf
    add x1, x1, :lo12:.Lsan_waf
    mov x2, #67
    mov x0, #2
    mov x8, #64
    svc #0
    mov x19, #124
    b __fern_bt_exit
    .section .rodata
.Lsan_hbo:
    .ascii "fern-sanitizer: heap-buffer-overflow (a raw block was written past its end)\n"
    .text
    .globl __fern_san_abort_hbo
__fern_san_abort_hbo:
    adrp x1, .Lsan_hbo
    add x1, x1, :lo12:.Lsan_hbo
    mov x2, #76
    mov x0, #2
    mov x8, #64
    svc #0
    mov x19, #124
    b __fern_bt_exit
    .section .rodata
.Lsan_df:
    .ascii "fern-sanitizer: rc over-release (double free)\n"
    .text
    .globl __fern_san_abort
__fern_san_abort:
    adrp x1, .Lsan_df
    add x1, x1, :lo12:.Lsan_df
    mov x2, #46
    mov x0, #2
    mov x8, #64
    svc #0
    mov x19, #124
    b __fern_bt_exit
__fern_arr_push:
.Larr_push_slow:
.Larr_push_frame:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    ldur w2, [x19, #-8]
    movz w10, #64206
    movk w10, #32493, lsl #16
    cmp w2, w10
    b.ne .Larr_push_sanlive
    bl __fern_san_abort_uaf
.Larr_push_sanlive:
    cmp w2, #1
    b.eq .Larr_push_rc_ok
    tbnz w2, #31, .Larr_push_rc_ok
    b .Larr_push_grow
.Larr_push_rc_ok:
    cmp x21, x22
    b.ge .Larr_push_grow
    add x1, x21, #1
    str x20, [x19, x1, lsl #3]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_ret
.Larr_push_grow:
    mov x2, x22
    cmp x21, x22
    b.lt .Larr_push_shared_cliff
    cmp x22, #0
    b.ne .Larr_push_dbl
    mov x2, #4
    b .Larr_push_cap
.Larr_push_shared_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21, lsl #3
    str x4, [x3]
    b .Larr_push_cap
.Larr_push_dbl:
    lsl x2, x22, #1
.Larr_push_cap:
    add x9, x21, #1
    cmp x2, x9
    csel x2, x2, x9, hs
    mov x22, x2
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Larr_push_copy4:
    cmp x4, #4
    b.lt .Larr_push_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Larr_push_copy4
.Larr_push_copy1:
    cbz x4, .Larr_push_copy_done
.Larr_push_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Larr_push_copy1_loop
.Larr_push_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
.Larr_push_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned:
.Lapo_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    bl __fern_arr_push
    cmp x0, x19
    beq .Lapo_ret
    mov x9, #0x10000
    cmp x19, x9
    blo .Lapo_ret
    ldur w1, [x19, #-8]
    movz w10, #64206
    movk w10, #32493, lsl #16
    cmp w1, w10
    b.ne .Lapo_live
    bl __fern_san_abort_uaf
.Lapo_live:
    tbnz w1, #31, .Lapo_ret
    cmp w1, #1
    bne .Lapo_ret
    ldur x1, [x19, #-16]
    add x1, x1, #3
    mov x9, #0x10000
    cmp x1, x9
    bhs .Lapo_large
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x19, #-8]
    sub x2, x19, #16
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x9, [x3]
    add x9, x9, #1
    str x9, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x9, [x3]
    add x9, x9, x1, lsl #3
    str x9, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x1
    mov x0, x2
    mov x1, x10
    mov x2, #8
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lapo_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapo_large:
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x19, #-8]
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x9, [x3]
    add x9, x9, #1
    str x9, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x9, [x3]
    add x9, x9, x1, lsl #3
    str x9, [x3]
    sub x2, x19, #16
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x1
    mov x0, x2
    mov x1, x10
    mov x2, #8
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    b .Lapo_ret
__fern_arr_push_u8:
.Larr_push_u8_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    ldur w2, [x19, #-8]
    movz w10, #64206
    movk w10, #32493, lsl #16
    cmp w2, w10
    b.ne .Larr_push_u8_sanlive
    bl __fern_san_abort_uaf
.Larr_push_u8_sanlive:
    cmp w2, #1
    b.eq .Larr_push_u8_rc_ok
    tbnz w2, #31, .Larr_push_u8_rc_ok
    b .Larr_push_u8_grow
.Larr_push_u8_rc_ok:
    lsl x2, x22, #3
    cmp x21, x2
    b.ge .Larr_push_u8_grow
    add x2, x19, x21
    strb w20, [x2, #8]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_u8_ret
.Larr_push_u8_grow:
    mov x2, x22
    lsl x3, x22, #3
    cmp x21, x3
    b.lt .Larr_push_u8_cliff
    cbnz x22, .Larr_push_u8_dbl
    mov x2, #4
    b .Larr_push_u8_cap
.Larr_push_u8_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21
    str x4, [x3]
    b .Larr_push_u8_cap
.Larr_push_u8_dbl:
    lsl x2, x22, #1
.Larr_push_u8_cap:
    add x3, x21, #8
    lsr x3, x3, #3
    cmp x2, x3
    csel x2, x2, x3, hs
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    add x4, x21, #7
    lsr x4, x4, #3
.Larr_push_u8_copy:
    cbz x4, .Larr_push_u8_copied
    ldr x5, [x2], #8
    str x5, [x3], #8
    sub x4, x4, #1
    b .Larr_push_u8_copy
.Larr_push_u8_copied:
    add x2, x0, x21
    strb w20, [x2, #8]
.Larr_push_u8_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned_u8:
.Lapou_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    bl __fern_arr_push_u8
    cmp x0, x19
    beq .Lapou_ret
    mov x9, #0x10000
    cmp x19, x9
    blo .Lapou_ret
    ldur w1, [x19, #-8]
    movz w10, #64206
    movk w10, #32493, lsl #16
    cmp w1, w10
    b.ne .Lapou_live
    bl __fern_san_abort_uaf
.Lapou_live:
    tbnz w1, #31, .Lapou_ret
    cmp w1, #1
    bne .Lapou_ret
    ldur x1, [x19, #-16]
    add x1, x1, #3
    mov x9, #0x10000
    cmp x1, x9
    bhs .Lapou_large
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x19, #-8]
    sub x2, x19, #16
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x9, [x3]
    add x9, x9, #1
    str x9, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x9, [x3]
    add x9, x9, x1, lsl #3
    str x9, [x3]
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x1
    mov x0, x2
    mov x1, x10
    mov x2, #8
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
.Lapou_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapou_large:
    movz w10, #64206
    movk w10, #32493, lsl #16
    stur w10, [x19, #-8]
    adrp x3, __fern_lc_free_count
    add x3, x3, :lo12:__fern_lc_free_count
    ldr x9, [x3]
    add x9, x9, #1
    str x9, [x3]
    adrp x3, __fern_lc_free_bytes
    add x3, x3, :lo12:__fern_lc_free_bytes
    ldr x9, [x3]
    add x9, x9, x1, lsl #3
    str x9, [x3]
    sub x2, x19, #16
    stp x0, x30, [sp, #-16]!
    stp x1, x2, [sp, #-16]!
    mov x10, x1
    mov x0, x2
    mov x1, x10
    mov x2, #8
    bl __fern_quar_push
    ldp x1, x2, [sp], #16
    ldp x0, x30, [sp], #16
    b .Lapou_ret
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .text
__fern_alloc_bytes:
    tbz w0, #31, .Lfern_alloc_bytes_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_bytes_sized:
    cbz w0, .Lfern_alloc_bytes_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    sxtw x19, w0
    add x0, x19, #7
    lsr x0, x0, #3
    mov x20, x0
    bl __fern_arr_box
    str x19, [x0]
    add x2, x0, #8
.Lfern_alloc_bytes_zero:
    cbz x20, .Lfern_alloc_bytes_done
    str xzr, [x2], #8
    sub x20, x20, #1
    b .Lfern_alloc_bytes_zero
.Lfern_alloc_bytes_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_bytes_empty:
    adrp x0, .Lfern_empty_bytes
    add x0, x0, :lo12:.Lfern_empty_bytes
    ret
__fn___fern_bytes_range:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_bytes_range.k:
__fn___fern_bytes_range.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
.Lssa___fern_bytes_range_0:
    mov x9, #2
    and x9, x10, x9
    cmp x9, #0
    b.eq .Lssa___fern_bytes_range_10
.Lssa___fern_bytes_range_11:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x20, x12
    mov x12, x11
    b .Lssa___fern_bytes_range_9
.Lssa___fern_bytes_range_10:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x20, x10
.Lssa___fern_bytes_range_9:
    cmp x19, #0
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_8:
    cmp x0, x19
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_7:
    cmp x0, x12
    b.le .Lssa___fern_bytes_range_4
.Lssa___fern_bytes_range_6:
    bl __fern_slice_abort
.Lssa___fern_bytes_range_4:
    sub x0, x0, x19
    sxtw x21, w0
    cmp x21, #0
    b.ne .Lssa___fern_bytes_range_1
.Lssa___fern_bytes_range_3:
    adrp x0, .K0
    add x0, x0, :lo12:.K0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_range_1:
    add x12, x21, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    sxtw x19, w19
    add x20, x20, x19
    mov x2, x21
    mov x1, x20
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_range_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_bytes_range_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_range_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_range_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_range_mc136
.Lssa___fern_bytes_range_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_range_mcd136
.Lssa___fern_bytes_range_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_range_mcb136
.Lssa___fern_bytes_range_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_bytes_into:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___fern_bytes_into.k:
__fn___fern_bytes_into.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    str x25, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x11
    mov x22, x12
.Lssa___fern_bytes_into_0:
    mov x9, #2
    and x9, x10, x9
    cmp x9, #0
    b.eq .Lssa___fern_bytes_into_15
.Lssa___fern_bytes_into_16:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x23, x12
    mov x12, x11
    b .Lssa___fern_bytes_into_14
.Lssa___fern_bytes_into_15:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x23, x10
.Lssa___fern_bytes_into_14:
    ldrsw x24, [x22]
    cmp x19, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_13:
    cmp x21, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_12:
    cmp x20, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_11:
    sub x10, x24, x19
    sxtw x10, w10
    cmp x21, x10
    b.gt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_10:
    sub x12, x12, x19
    sxtw x12, w12
    cmp x20, x12
    b.le .Lssa___fern_bytes_into_7
.Lssa___fern_bytes_into_9:
    bl __fern_slice_abort
.Lssa___fern_bytes_into_7:
    cmp x19, #0
    b.ne .Lssa___fern_bytes_into_4
.Lssa___fern_bytes_into_6:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_into_4:
    mov x6, #0
    tbnz x22, #0, .Lssa___fern_bytes_into_rcuniq100
    cmp x22, #16, lsl #12
    b.lo .Lssa___fern_bytes_into_rcuniq100
    and x7, x22, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    movz w7, #64206
    movk w7, #32493, lsl #16
    cmp w5, w7
    b.ne .Lssa___fern_bytes_into_rcuniq100us
    bl __fern_san_abort_uaf
.Lssa___fern_bytes_into_rcuniq100us:
    cmp w5, #1
    b.ne .Lssa___fern_bytes_into_rcuniq100
    mov x6, #1
.Lssa___fern_bytes_into_rcuniq100:
    mov x0, x6
    cmp x0, #0
    b.ne .Lssa___fern_bytes_into_1
.Lssa___fern_bytes_into_3:
    add x12, x24, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x25, x0
    str x24, [x25, #0]
    add x10, x25, #8
    add x12, x22, #8
    mov x2, x24
    mov x1, x12
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_into_mcd172
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb172
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc172:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct172
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc172
.Lssa___fern_bytes_into_mct172:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd172
.Lssa___fern_bytes_into_mcb172:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb172
.Lssa___fern_bytes_into_mcd172:
    mov x0, #0
    mov x0, x22
    bl __fn___fern_arr_dec.r
    mov x22, x25
.Lssa___fern_bytes_into_2:
.Lssa___fern_bytes_into_1:
    add x12, x22, #8
    sxtw x21, w21
    add x12, x12, x21
    sxtw x20, w20
    add x23, x23, x20
    mov x2, x19
    mov x1, x23
    mov x0, x12
    cbz x2, .Lssa___fern_bytes_into_mcd207
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb207
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc207:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct207
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc207
.Lssa___fern_bytes_into_mct207:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd207
.Lssa___fern_bytes_into_mcb207:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb207
.Lssa___fern_bytes_into_mcd207:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_utf8_step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_utf8_step.k:
__fn___fern_utf8_step.r:
.Lssa___fern_utf8_step_0:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x9]
    mov x12, #0
    mov x13, #1
    cmp x11, #128
    csel x13, x13, x12, lt
    cmp x11, #194
    b.lt .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_41:
    cmp x11, #224
    b.ge .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_40:
    mov x13, #2
.Lssa___fern_utf8_step_39:
.Lssa___fern_utf8_step_38:
    cmp x11, #224
    b.lt .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_37:
    cmp x11, #240
    b.ge .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_36:
    mov x13, #3
.Lssa___fern_utf8_step_35:
.Lssa___fern_utf8_step_34:
    cmp x11, #240
    b.lt .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_33:
    cmp x11, #245
    b.ge .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_32:
    mov x13, #4
.Lssa___fern_utf8_step_31:
.Lssa___fern_utf8_step_30:
    cmp x13, #1
    b.gt .Lssa___fern_utf8_step_27
.Lssa___fern_utf8_step_29:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_27:
    add x12, x9, #1
    sxtw x12, w12
    cmp x12, x10
    b.lt .Lssa___fern_utf8_step_24
.Lssa___fern_utf8_step_26:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_24:
    mov x12, #128
    mov x14, #160
    cmp x11, #224
    csel x14, x14, x12, eq
    mov x12, #144
    cmp x11, #240
    csel x12, x12, x14, eq
    mov x14, #191
    mov x15, #159
    cmp x11, #237
    csel x15, x15, x14, eq
    mov x14, #143
    cmp x11, #244
    csel x14, x14, x15, eq
    add w15, w9, #1
    ldr x6, [x0, #8]
    cmp x15, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x15]
    cmp x11, x12
    b.ge .Lssa___fern_utf8_step_9
.Lssa___fern_utf8_step_11:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_9:
    cmp x11, x14
    b.le .Lssa___fern_utf8_step_6
.Lssa___fern_utf8_step_8:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_6:
.Lssa___fern_utf8_step_5:
    mov x11, #2
.Lssa___fern_utf8_step_113:
    cmp x11, x13
    b.ge .Lssa___fern_utf8_step_4
.Lssa___fern_utf8_step_120:
    add x15, x9, x11
    sxtw x15, w15
    cmp x15, x10
    b.ge .Lssa___fern_utf8_step_3
.Lssa___fern_utf8_step_118:
    add w15, w9, w11
    ldr x6, [x0, #8]
    cmp x15, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x15]
    cmp x14, #128
    b.lt .Lssa___fern_utf8_step_2
.Lssa___fern_utf8_step_116:
    cmp x14, #191
    b.gt .Lssa___fern_utf8_step_1
.Lssa___fern_utf8_step_114:
    add x11, x11, #1
    cmp x11, x13
    b.lt .Lssa___fern_utf8_step_120
.Lssa___fern_utf8_step_4:
    mov x0, x13
    ret
.Lssa___fern_utf8_step_3:
    mov x0, x11
    ret
.Lssa___fern_utf8_step_2:
    mov x0, x11
    ret
.Lssa___fern_utf8_step_1:
    mov x0, x11
    ret
    .cfi_endproc
    .ltorg
__fn___fern_str_split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_split.k:
__fn___fern_str_split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    sub sp, sp, #144
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_split_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    adrp x9, .K0
    add x9, x9, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa___fern_str_split_3
.Lssa___fern_str_split_7:
.Lssa___fern_str_split_6:
    mov x23, x9
    mov x24, #0
.Lssa___fern_str_split_12:
    cmp x24, x21
    b.ge .Lssa___fern_str_split_5
.Lssa___fern_str_split_13:
    mov x0, x19
    mov x9, x24
    mov x10, x21
    bl __fn___fern_utf8_step.r
    add x0, x24, x0
    sxtw x25, w0
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    mov x0, x26
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x24, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    str x9, [sp, #64]
    bl __fern_arr_push_owned
    ldr x9, [sp, #64]
    mov x23, x0
    mov x24, x25
    cmp x24, x21
    b.lt .Lssa___fern_str_split_13
.Lssa___fern_str_split_5:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_str_split_3:
.Lssa___fern_str_split_2:
    mov x23, x9
    mov x24, #0
    mov x25, #0
.Lssa___fern_str_split_20:
    add x9, x25, x22
    sxtw x9, w9
    cmp x9, x21
    b.gt .Lssa___fern_str_split_1
.Lssa___fern_str_split_26:
.Lssa___fern_str_split_25:
    mov x9, #0
    mov x10, #1
.Lssa___fern_str_split_31:
    cmp x9, x22
    b.ge .Lssa___fern_str_split_24
.Lssa___fern_str_split_35:
    add w11, w25, w9
    ldr x6, [x19, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w12, [x6, x11]
    ldr x11, [x20, #0]
    ldrb w13, [x11, x9]
    mov x11, #0
    add x9, x9, #1
    cmp x12, x13
    csel x9, x22, x9, ne
    csel x10, x11, x10, ne
    cmp x9, x22
    b.lt .Lssa___fern_str_split_35
.Lssa___fern_str_split_24:
    cmp x10, #1
    b.ne .Lssa___fern_str_split_22
.Lssa___fern_str_split_23:
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    mov x0, x26
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x27, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x27
    bl __fern_arr_push_owned
    add x10, x25, x22
    sxtw x10, w10
    mov x23, x0
    mov x24, x10
    mov x25, x10
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_22:
    add x25, x25, #1
    sxtw x25, w25
.Lssa___fern_str_split_21:
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_1:
    mov x0, x19
    mov x1, x24
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x25, x0
    adrp x10, .SB6
    add x10, x10, :lo12:.SB6
    mov x0, x25
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x24, x0
    str x25, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    bl __fern_arr_push_owned
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_bytes_u8.k:
__fn___fern_str_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_bytes_u8_0:
    ldr x20, [x19, #8]
    sxtw x21, w20
    add x9, x21, #7
    mov x4, x9
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    sxtw x10, w10
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    ldr x9, [x19, #0]
    mov x2, x20
    mov x1, x9
    mov x0, x10
    cbz x2, .Lssa___fern_str_bytes_u8_mcd36
    cmp x2, #8
    b.lo .Lssa___fern_str_bytes_u8_mcb36
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_bytes_u8_mc36:
    cmp x0, x10
    b.hs .Lssa___fern_str_bytes_u8_mct36
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_bytes_u8_mc36
.Lssa___fern_str_bytes_u8_mct36:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_bytes_u8_mcd36
.Lssa___fern_str_bytes_u8_mcb36:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_bytes_u8_mcb36
.Lssa___fern_str_bytes_u8_mcd36:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_string_from_bytes_u8.k:
__fn___fern_string_from_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_string_from_bytes_u8_0:
    ldr x20, [x19, #0]
    mov x0, x20
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x21, x0
    add x19, x19, #8
    mov x2, x20
    mov x1, x19
    mov x0, x21
    cbz x2, .Lssa___fern_string_from_bytes_u8_mcd14
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_u8_mcb14
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_u8_mc14:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_u8_mct14
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_u8_mc14
.Lssa___fern_string_from_bytes_u8_mct14:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_u8_mcd14
.Lssa___fern_string_from_bytes_u8_mcb14:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_u8_mcb14
.Lssa___fern_string_from_bytes_u8_mcd14:
    mov x0, #0
    mov x0, x21
    mov x1, x20
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_range_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_string_from_bytes_range_u8.k:
__fn___fern_string_from_bytes_range_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_string_from_bytes_range_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x10, x9
    csel x11, x11, x12, gt
    mov x12, #1
    cmp x20, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x20, x10
    csel x11, x11, x12, gt
    cmp x11, #1
    b.ne .Lssa___fern_string_from_bytes_range_u8_1
.Lssa___fern_string_from_bytes_range_u8_3:
    bl __fern_slice_abort
.Lssa___fern_string_from_bytes_range_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    mov x0, x21
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x22, x0
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x22
    cbz x2, .Lssa___fern_string_from_bytes_range_u8_mcd117
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_range_u8_mcb117
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_range_u8_mc117:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_range_u8_mct117
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_range_u8_mc117
.Lssa___fern_string_from_bytes_range_u8_mct117:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_range_u8_mcd117
.Lssa___fern_string_from_bytes_range_u8_mcb117:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_range_u8_mcb117
.Lssa___fern_string_from_bytes_range_u8_mcd117:
    mov x0, #0
    mov x0, x22
    mov x1, x21
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_arr_slice_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_arr_slice_u8.k:
__fn___fern_arr_slice_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_arr_slice_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x10, x9
    csel x11, x11, x12, gt
    mov x12, #1
    cmp x20, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x20, x10
    csel x11, x11, x12, gt
    cmp x11, #1
    b.ne .Lssa___fern_arr_slice_u8_1
.Lssa___fern_arr_slice_u8_3:
    bl __fern_slice_abort
.Lssa___fern_arr_slice_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    add x10, x21, #7
    sxtw x10, w10
    mov x4, x10
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x11, x4
    mov x0, x11
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x11, x22, #8
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x11
    cbz x2, .Lssa___fern_arr_slice_u8_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_arr_slice_u8_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_arr_slice_u8_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_arr_slice_u8_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_arr_slice_u8_mc136
.Lssa___fern_arr_slice_u8_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_arr_slice_u8_mcd136
.Lssa___fern_arr_slice_u8_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_arr_slice_u8_mcb136
.Lssa___fern_arr_slice_u8_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
    .section .rodata
.S0: .ascii "HeaderMap"
.S1: .ascii "http://"
.S2: .ascii "https://"
.S3: .ascii "!$&'()*+,;="
.S4: .ascii "HttpResponse"
.S5: .ascii "Body$BodyText"
.S6: .ascii ""
.S7: .ascii "Content-Length: "
.S8: .ascii "\r\n"
.S9: .ascii "HTTP/1.1 "
.S10: .ascii " "
.S11: .ascii "Continue"
.S12: .ascii "Switching Protocols"
.S13: .ascii "OK"
.S14: .ascii "Created"
.S15: .ascii "Accepted"
.S16: .ascii "Non-Authoritative Information"
.S17: .ascii "No Content"
.S18: .ascii "Reset Content"
.S19: .ascii "Partial Content"
.S20: .ascii "Multiple Choices"
.S21: .ascii "Moved Permanently"
.S22: .ascii "Found"
.S23: .ascii "See Other"
.S24: .ascii "Not Modified"
.S25: .ascii "Use Proxy"
.S26: .ascii "Temporary Redirect"
.S27: .ascii "Permanent Redirect"
.S28: .ascii "Bad Request"
.S29: .ascii "Unauthorized"
.S30: .ascii "Payment Required"
.S31: .ascii "Forbidden"
.S32: .ascii "Not Found"
.S33: .ascii "Method Not Allowed"
.S34: .ascii "Not Acceptable"
.S35: .ascii "Proxy Authentication Required"
.S36: .ascii "Request Timeout"
.S37: .ascii "Conflict"
.S38: .ascii "Gone"
.S39: .ascii "Length Required"
.S40: .ascii "Precondition Failed"
.S41: .ascii "Payload Too Large"
.S42: .ascii "URI Too Long"
.S43: .ascii "Unsupported Media Type"
.S44: .ascii "Range Not Satisfiable"
.S45: .ascii "Expectation Failed"
.S46: .ascii "I'm a teapot"
.S47: .ascii "Misdirected Request"
.S48: .ascii "Unprocessable Entity"
.S49: .ascii "Too Early"
.S50: .ascii "Upgrade Required"
.S51: .ascii "Precondition Required"
.S52: .ascii "Too Many Requests"
.S53: .ascii "Request Header Fields Too Large"
.S54: .ascii "Internal Server Error"
.S55: .ascii "Not Implemented"
.S56: .ascii "Bad Gateway"
.S57: .ascii "Service Unavailable"
.S58: .ascii "Gateway Timeout"
.S59: .ascii "HTTP Version Not Supported"
.S60: .ascii "Network Authentication Required"
.S61: .ascii "Status"
.S62: .ascii "content-length"
.S63: .ascii "connection"
.S64: .ascii "transfer-encoding"
.S65: .ascii ": "
.S66: .ascii "Connection: Upgrade\r\n\r\n"
.S67: .ascii "Connection: close\r\n\r\n"
.S68: .ascii "Connection: keep-alive\r\n\r\n"
.S69: .ascii "HEAD"
.S70: .ascii "\027\003\007\003\003\003\003\003\007\007\013\253/\253\013\217\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\001\000\000\000\000\000\001\001\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001"
.S71: .ascii "\003\003\003\003\003\003\003\003\003\002\003\003\003\003\003\203\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
.S72: .ascii "0"
.S73: .ascii "1"
.S74: .ascii "2"
.S75: .ascii "3"
.S76: .ascii "4"
.S77: .ascii "5"
.S78: .ascii "6"
.S79: .ascii "7"
.S80: .ascii "8"
.S81: .ascii "9"
.S82: .ascii "10"
.S83: .ascii "11"
.S84: .ascii "12"
.S85: .ascii "13"
.S86: .ascii "14"
.S87: .ascii "15"
.S88: .ascii "16"
.S89: .ascii "17"
.S90: .ascii "18"
.S91: .ascii "19"
.S92: .ascii "20"
.S93: .ascii "21"
.S94: .ascii "22"
.S95: .ascii "23"
.S96: .ascii "24"
.S97: .ascii "25"
.S98: .ascii "26"
.S99: .ascii "27"
.S100: .ascii "28"
.S101: .ascii "29"
.S102: .ascii "30"
.S103: .ascii "31"
.S104: .ascii "32"
.S105: .ascii "33"
.S106: .ascii "34"
.S107: .ascii "35"
.S108: .ascii "36"
.S109: .ascii "37"
.S110: .ascii "38"
.S111: .ascii "39"
.S112: .ascii "40"
.S113: .ascii "41"
.S114: .ascii "42"
.S115: .ascii "43"
.S116: .ascii "44"
.S117: .ascii "45"
.S118: .ascii "46"
.S119: .ascii "47"
.S120: .ascii "48"
.S121: .ascii "49"
.S122: .ascii "50"
.S123: .ascii "51"
.S124: .ascii "52"
.S125: .ascii "53"
.S126: .ascii "54"
.S127: .ascii "55"
.S128: .ascii "56"
.S129: .ascii "57"
.S130: .ascii "58"
.S131: .ascii "59"
.S132: .ascii "60"
.S133: .ascii "61"
.S134: .ascii "62"
.S135: .ascii "63"
.S136: .ascii "64"
.S137: .ascii "65"
.S138: .ascii "66"
.S139: .ascii "67"
.S140: .ascii "68"
.S141: .ascii "69"
.S142: .ascii "70"
.S143: .ascii "71"
.S144: .ascii "72"
.S145: .ascii "73"
.S146: .ascii "74"
.S147: .ascii "75"
.S148: .ascii "76"
.S149: .ascii "77"
.S150: .ascii "78"
.S151: .ascii "79"
.S152: .ascii "80"
.S153: .ascii "81"
.S154: .ascii "82"
.S155: .ascii "83"
.S156: .ascii "84"
.S157: .ascii "85"
.S158: .ascii "86"
.S159: .ascii "87"
.S160: .ascii "88"
.S161: .ascii "89"
.S162: .ascii "90"
.S163: .ascii "91"
.S164: .ascii "92"
.S165: .ascii "93"
.S166: .ascii "94"
.S167: .ascii "95"
.S168: .ascii "96"
.S169: .ascii "97"
.S170: .ascii "98"
.S171: .ascii "99"
.S172: .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
.S173: .ascii "deflate____ReadPhase$deflate__ReadHeader"
.S174: .ascii "deflate____ReadPhase$deflate__ReadStored"
.S175: .ascii "deflate____ReadPhase$deflate__ReadCodes"
.S176: .ascii "deflate____ReadPhase$deflate__ReadCopy"
.S177: .ascii "deflate____ReadPhase$deflate__ReadEnd"
.S178: .ascii "codec__DecodeErrorKind$codec__InvalidByte"
.S179: .ascii "codec__DecodeErrorKind$codec__InvalidLength"
.S180: .ascii "codec__DecodeErrorKind$codec__InvalidPadding"
.S181: .ascii "codec__DecodeErrorKind$codec__NonZeroTrailingBits"
.S182: .ascii "GET /hello HTTP/1.1\r\nHost: bench\r\nUser-Agent: perf-bench\r\nAccept: */*\r\n\r\n"
.S183: .ascii "\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\r"
.S184: .ascii "OPTIONS"
.S185: .ascii "*"
.S186: .ascii "HTTP/1.0"
.S187: .ascii "HTTP/1.1"
.S188: .ascii "host"
.S189: .ascii "expect"
.S190: .ascii "100-continue"
.S191: .ascii ","
.S192: .ascii "chunked"
.S193: .ascii "close"
.S194: .ascii "keep-alive"
.S195: .ascii "hello "
.S196: .ascii "GET"
.S197: .ascii "Body$BodyBytes"
.S198: .ascii "Body$BodyStream"
.S199: .ascii "Body$BodyFile"
.S200: .ascii "Body$BodyChunks"
.S201: .ascii "Body$BodyFileRanges"
    .section .data
    .balign 8
.Lfern_relanchor:
    .quad .Lfern_relanchor
    .section .data.rel.ro
    .balign 8
.Lfern_sbox_begin:
    .section .data.rel.ro
    .balign 8
    .quad -1
.SB0:
    .quad .S0
    .quad 9
    .quad -1
.SB1:
    .quad .S1
    .quad 7
    .quad -1
.SB2:
    .quad .S2
    .quad 8
    .quad -1
.SB3:
    .quad .S3
    .quad 11
    .quad -1
.SB4:
    .quad .S4
    .quad 12
    .quad -1
.SB5:
    .quad .S5
    .quad 13
    .quad -1
.SB6:
    .quad .S6
    .quad 0
    .quad -1
.SB7:
    .quad .S7
    .quad 16
    .quad -1
.SB8:
    .quad .S8
    .quad 2
    .quad -1
.SB9:
    .quad .S9
    .quad 9
    .quad -1
.SB10:
    .quad .S10
    .quad 1
    .quad -1
.SB11:
    .quad .S11
    .quad 8
    .quad -1
.SB12:
    .quad .S12
    .quad 19
    .quad -1
.SB13:
    .quad .S13
    .quad 2
    .quad -1
.SB14:
    .quad .S14
    .quad 7
    .quad -1
.SB15:
    .quad .S15
    .quad 8
    .quad -1
.SB16:
    .quad .S16
    .quad 29
    .quad -1
.SB17:
    .quad .S17
    .quad 10
    .quad -1
.SB18:
    .quad .S18
    .quad 13
    .quad -1
.SB19:
    .quad .S19
    .quad 15
    .quad -1
.SB20:
    .quad .S20
    .quad 16
    .quad -1
.SB21:
    .quad .S21
    .quad 17
    .quad -1
.SB22:
    .quad .S22
    .quad 5
    .quad -1
.SB23:
    .quad .S23
    .quad 9
    .quad -1
.SB24:
    .quad .S24
    .quad 12
    .quad -1
.SB25:
    .quad .S25
    .quad 9
    .quad -1
.SB26:
    .quad .S26
    .quad 18
    .quad -1
.SB27:
    .quad .S27
    .quad 18
    .quad -1
.SB28:
    .quad .S28
    .quad 11
    .quad -1
.SB29:
    .quad .S29
    .quad 12
    .quad -1
.SB30:
    .quad .S30
    .quad 16
    .quad -1
.SB31:
    .quad .S31
    .quad 9
    .quad -1
.SB32:
    .quad .S32
    .quad 9
    .quad -1
.SB33:
    .quad .S33
    .quad 18
    .quad -1
.SB34:
    .quad .S34
    .quad 14
    .quad -1
.SB35:
    .quad .S35
    .quad 29
    .quad -1
.SB36:
    .quad .S36
    .quad 15
    .quad -1
.SB37:
    .quad .S37
    .quad 8
    .quad -1
.SB38:
    .quad .S38
    .quad 4
    .quad -1
.SB39:
    .quad .S39
    .quad 15
    .quad -1
.SB40:
    .quad .S40
    .quad 19
    .quad -1
.SB41:
    .quad .S41
    .quad 17
    .quad -1
.SB42:
    .quad .S42
    .quad 12
    .quad -1
.SB43:
    .quad .S43
    .quad 22
    .quad -1
.SB44:
    .quad .S44
    .quad 21
    .quad -1
.SB45:
    .quad .S45
    .quad 18
    .quad -1
.SB46:
    .quad .S46
    .quad 12
    .quad -1
.SB47:
    .quad .S47
    .quad 19
    .quad -1
.SB48:
    .quad .S48
    .quad 20
    .quad -1
.SB49:
    .quad .S49
    .quad 9
    .quad -1
.SB50:
    .quad .S50
    .quad 16
    .quad -1
.SB51:
    .quad .S51
    .quad 21
    .quad -1
.SB52:
    .quad .S52
    .quad 17
    .quad -1
.SB53:
    .quad .S53
    .quad 31
    .quad -1
.SB54:
    .quad .S54
    .quad 21
    .quad -1
.SB55:
    .quad .S55
    .quad 15
    .quad -1
.SB56:
    .quad .S56
    .quad 11
    .quad -1
.SB57:
    .quad .S57
    .quad 19
    .quad -1
.SB58:
    .quad .S58
    .quad 15
    .quad -1
.SB59:
    .quad .S59
    .quad 26
    .quad -1
.SB60:
    .quad .S60
    .quad 31
    .quad -1
.SB61:
    .quad .S61
    .quad 6
    .quad -1
.SB62:
    .quad .S62
    .quad 14
    .quad -1
.SB63:
    .quad .S63
    .quad 10
    .quad -1
.SB64:
    .quad .S64
    .quad 17
    .quad -1
.SB65:
    .quad .S65
    .quad 2
    .quad -1
.SB66:
    .quad .S66
    .quad 23
    .quad -1
.SB67:
    .quad .S67
    .quad 21
    .quad -1
.SB68:
    .quad .S68
    .quad 26
    .quad -1
.SB69:
    .quad .S69
    .quad 4
    .quad -1
.SB70:
    .quad .S70
    .quad 352
    .quad -1
.SB71:
    .quad .S71
    .quad 352
    .quad -1
.SB72:
    .quad .S72
    .quad 1
    .quad -1
.SB73:
    .quad .S73
    .quad 1
    .quad -1
.SB74:
    .quad .S74
    .quad 1
    .quad -1
.SB75:
    .quad .S75
    .quad 1
    .quad -1
.SB76:
    .quad .S76
    .quad 1
    .quad -1
.SB77:
    .quad .S77
    .quad 1
    .quad -1
.SB78:
    .quad .S78
    .quad 1
    .quad -1
.SB79:
    .quad .S79
    .quad 1
    .quad -1
.SB80:
    .quad .S80
    .quad 1
    .quad -1
.SB81:
    .quad .S81
    .quad 1
    .quad -1
.SB82:
    .quad .S82
    .quad 2
    .quad -1
.SB83:
    .quad .S83
    .quad 2
    .quad -1
.SB84:
    .quad .S84
    .quad 2
    .quad -1
.SB85:
    .quad .S85
    .quad 2
    .quad -1
.SB86:
    .quad .S86
    .quad 2
    .quad -1
.SB87:
    .quad .S87
    .quad 2
    .quad -1
.SB88:
    .quad .S88
    .quad 2
    .quad -1
.SB89:
    .quad .S89
    .quad 2
    .quad -1
.SB90:
    .quad .S90
    .quad 2
    .quad -1
.SB91:
    .quad .S91
    .quad 2
    .quad -1
.SB92:
    .quad .S92
    .quad 2
    .quad -1
.SB93:
    .quad .S93
    .quad 2
    .quad -1
.SB94:
    .quad .S94
    .quad 2
    .quad -1
.SB95:
    .quad .S95
    .quad 2
    .quad -1
.SB96:
    .quad .S96
    .quad 2
    .quad -1
.SB97:
    .quad .S97
    .quad 2
    .quad -1
.SB98:
    .quad .S98
    .quad 2
    .quad -1
.SB99:
    .quad .S99
    .quad 2
    .quad -1
.SB100:
    .quad .S100
    .quad 2
    .quad -1
.SB101:
    .quad .S101
    .quad 2
    .quad -1
.SB102:
    .quad .S102
    .quad 2
    .quad -1
.SB103:
    .quad .S103
    .quad 2
    .quad -1
.SB104:
    .quad .S104
    .quad 2
    .quad -1
.SB105:
    .quad .S105
    .quad 2
    .quad -1
.SB106:
    .quad .S106
    .quad 2
    .quad -1
.SB107:
    .quad .S107
    .quad 2
    .quad -1
.SB108:
    .quad .S108
    .quad 2
    .quad -1
.SB109:
    .quad .S109
    .quad 2
    .quad -1
.SB110:
    .quad .S110
    .quad 2
    .quad -1
.SB111:
    .quad .S111
    .quad 2
    .quad -1
.SB112:
    .quad .S112
    .quad 2
    .quad -1
.SB113:
    .quad .S113
    .quad 2
    .quad -1
.SB114:
    .quad .S114
    .quad 2
    .quad -1
.SB115:
    .quad .S115
    .quad 2
    .quad -1
.SB116:
    .quad .S116
    .quad 2
    .quad -1
.SB117:
    .quad .S117
    .quad 2
    .quad -1
.SB118:
    .quad .S118
    .quad 2
    .quad -1
.SB119:
    .quad .S119
    .quad 2
    .quad -1
.SB120:
    .quad .S120
    .quad 2
    .quad -1
.SB121:
    .quad .S121
    .quad 2
    .quad -1
.SB122:
    .quad .S122
    .quad 2
    .quad -1
.SB123:
    .quad .S123
    .quad 2
    .quad -1
.SB124:
    .quad .S124
    .quad 2
    .quad -1
.SB125:
    .quad .S125
    .quad 2
    .quad -1
.SB126:
    .quad .S126
    .quad 2
    .quad -1
.SB127:
    .quad .S127
    .quad 2
    .quad -1
.SB128:
    .quad .S128
    .quad 2
    .quad -1
.SB129:
    .quad .S129
    .quad 2
    .quad -1
.SB130:
    .quad .S130
    .quad 2
    .quad -1
.SB131:
    .quad .S131
    .quad 2
    .quad -1
.SB132:
    .quad .S132
    .quad 2
    .quad -1
.SB133:
    .quad .S133
    .quad 2
    .quad -1
.SB134:
    .quad .S134
    .quad 2
    .quad -1
.SB135:
    .quad .S135
    .quad 2
    .quad -1
.SB136:
    .quad .S136
    .quad 2
    .quad -1
.SB137:
    .quad .S137
    .quad 2
    .quad -1
.SB138:
    .quad .S138
    .quad 2
    .quad -1
.SB139:
    .quad .S139
    .quad 2
    .quad -1
.SB140:
    .quad .S140
    .quad 2
    .quad -1
.SB141:
    .quad .S141
    .quad 2
    .quad -1
.SB142:
    .quad .S142
    .quad 2
    .quad -1
.SB143:
    .quad .S143
    .quad 2
    .quad -1
.SB144:
    .quad .S144
    .quad 2
    .quad -1
.SB145:
    .quad .S145
    .quad 2
    .quad -1
.SB146:
    .quad .S146
    .quad 2
    .quad -1
.SB147:
    .quad .S147
    .quad 2
    .quad -1
.SB148:
    .quad .S148
    .quad 2
    .quad -1
.SB149:
    .quad .S149
    .quad 2
    .quad -1
.SB150:
    .quad .S150
    .quad 2
    .quad -1
.SB151:
    .quad .S151
    .quad 2
    .quad -1
.SB152:
    .quad .S152
    .quad 2
    .quad -1
.SB153:
    .quad .S153
    .quad 2
    .quad -1
.SB154:
    .quad .S154
    .quad 2
    .quad -1
.SB155:
    .quad .S155
    .quad 2
    .quad -1
.SB156:
    .quad .S156
    .quad 2
    .quad -1
.SB157:
    .quad .S157
    .quad 2
    .quad -1
.SB158:
    .quad .S158
    .quad 2
    .quad -1
.SB159:
    .quad .S159
    .quad 2
    .quad -1
.SB160:
    .quad .S160
    .quad 2
    .quad -1
.SB161:
    .quad .S161
    .quad 2
    .quad -1
.SB162:
    .quad .S162
    .quad 2
    .quad -1
.SB163:
    .quad .S163
    .quad 2
    .quad -1
.SB164:
    .quad .S164
    .quad 2
    .quad -1
.SB165:
    .quad .S165
    .quad 2
    .quad -1
.SB166:
    .quad .S166
    .quad 2
    .quad -1
.SB167:
    .quad .S167
    .quad 2
    .quad -1
.SB168:
    .quad .S168
    .quad 2
    .quad -1
.SB169:
    .quad .S169
    .quad 2
    .quad -1
.SB170:
    .quad .S170
    .quad 2
    .quad -1
.SB171:
    .quad .S171
    .quad 2
    .quad -1
.SB172:
    .quad .S172
    .quad 200
    .quad -1
.SB173:
    .quad .S173
    .quad 40
    .quad -1
.SB174:
    .quad .S174
    .quad 40
    .quad -1
.SB175:
    .quad .S175
    .quad 39
    .quad -1
.SB176:
    .quad .S176
    .quad 38
    .quad -1
.SB177:
    .quad .S177
    .quad 37
    .quad -1
.SB178:
    .quad .S178
    .quad 41
    .quad -1
.SB179:
    .quad .S179
    .quad 43
    .quad -1
.SB180:
    .quad .S180
    .quad 44
    .quad -1
.SB181:
    .quad .S181
    .quad 49
    .quad -1
.SB182:
    .quad .S182
    .quad 73
    .quad -1
.SB183:
    .quad .S183
    .quad 354
    .quad -1
.SB184:
    .quad .S184
    .quad 7
    .quad -1
.SB185:
    .quad .S185
    .quad 1
    .quad -1
.SB186:
    .quad .S186
    .quad 8
    .quad -1
.SB187:
    .quad .S187
    .quad 8
    .quad -1
.SB188:
    .quad .S188
    .quad 4
    .quad -1
.SB189:
    .quad .S189
    .quad 6
    .quad -1
.SB190:
    .quad .S190
    .quad 12
    .quad -1
.SB191:
    .quad .S191
    .quad 1
    .quad -1
.SB192:
    .quad .S192
    .quad 7
    .quad -1
.SB193:
    .quad .S193
    .quad 5
    .quad -1
.SB194:
    .quad .S194
    .quad 10
    .quad -1
.SB195:
    .quad .S195
    .quad 6
    .quad -1
.SB196:
    .quad .S196
    .quad 3
    .quad -1
.SB197:
    .quad .S197
    .quad 14
    .quad -1
.SB198:
    .quad .S198
    .quad 15
    .quad -1
.SB199:
    .quad .S199
    .quad 13
    .quad -1
.SB200:
    .quad .S200
    .quad 15
    .quad -1
.SB201:
    .quad .S201
    .quad 19
.Lfern_sbox_end:
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.K0:
    .quad 0
    .quad 0
    .quad -1
.K2:
    .quad 0
    .balign 8
    .quad 2
    .quad -1
.K4:
    .quad 1
    .quad 0
    .quad 50
    .quad -1
.K6:
    .quad 50
    .quad 100
    .quad 101
    .quad 200
    .quad 201
    .quad 202
    .quad 203
    .quad 204
    .quad 205
    .quad 206
    .quad 300
    .quad 301
    .quad 302
    .quad 303
    .quad 304
    .quad 305
    .quad 307
    .quad 308
    .quad 400
    .quad 401
    .quad 402
    .quad 403
    .quad 404
    .quad 405
    .quad 406
    .quad 407
    .quad 408
    .quad 409
    .quad 410
    .quad 411
    .quad 412
    .quad 413
    .quad 414
    .quad 415
    .quad 416
    .quad 417
    .quad 418
    .quad 421
    .quad 422
    .quad 425
    .quad 426
    .quad 428
    .quad 429
    .quad 431
    .quad 500
    .quad 501
    .quad 502
    .quad 503
    .quad 504
    .quad 505
    .quad 511
    .quad 50
    .quad -1
.K7:
    .quad 50
.K7_0:
    .quad .SB11
.K7_1:
    .quad .SB12
.K7_2:
    .quad .SB13
.K7_3:
    .quad .SB14
.K7_4:
    .quad .SB15
.K7_5:
    .quad .SB16
.K7_6:
    .quad .SB17
.K7_7:
    .quad .SB18
.K7_8:
    .quad .SB19
.K7_9:
    .quad .SB20
.K7_10:
    .quad .SB21
.K7_11:
    .quad .SB22
.K7_12:
    .quad .SB23
.K7_13:
    .quad .SB24
.K7_14:
    .quad .SB25
.K7_15:
    .quad .SB26
.K7_16:
    .quad .SB27
.K7_17:
    .quad .SB28
.K7_18:
    .quad .SB29
.K7_19:
    .quad .SB30
.K7_20:
    .quad .SB31
.K7_21:
    .quad .SB32
.K7_22:
    .quad .SB33
.K7_23:
    .quad .SB34
.K7_24:
    .quad .SB35
.K7_25:
    .quad .SB36
.K7_26:
    .quad .SB37
.K7_27:
    .quad .SB38
.K7_28:
    .quad .SB39
.K7_29:
    .quad .SB40
.K7_30:
    .quad .SB41
.K7_31:
    .quad .SB42
.K7_32:
    .quad .SB43
.K7_33:
    .quad .SB44
.K7_34:
    .quad .SB45
.K7_35:
    .quad .SB46
.K7_36:
    .quad .SB47
.K7_37:
    .quad .SB48
.K7_38:
    .quad .SB49
.K7_39:
    .quad .SB50
.K7_40:
    .quad .SB51
.K7_41:
    .quad .SB52
.K7_42:
    .quad .SB53
.K7_43:
    .quad .SB54
.K7_44:
    .quad .SB55
.K7_45:
    .quad .SB56
.K7_46:
    .quad .SB57
.K7_47:
    .quad .SB58
.K7_48:
    .quad .SB59
.K7_49:
    .quad .SB60
    .quad 0
    .quad -1
.K8:
    .quad 256
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    .balign 8
    .quad 0
    .quad -1
.K9:
    .quad 128
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
    .balign 8
    .quad 100
    .quad -1
.K10:
    .quad 100
.K10_0:
    .quad .SB72
.K10_1:
    .quad .SB73
.K10_2:
    .quad .SB74
.K10_3:
    .quad .SB75
.K10_4:
    .quad .SB76
.K10_5:
    .quad .SB77
.K10_6:
    .quad .SB78
.K10_7:
    .quad .SB79
.K10_8:
    .quad .SB80
.K10_9:
    .quad .SB81
.K10_10:
    .quad .SB82
.K10_11:
    .quad .SB83
.K10_12:
    .quad .SB84
.K10_13:
    .quad .SB85
.K10_14:
    .quad .SB86
.K10_15:
    .quad .SB87
.K10_16:
    .quad .SB88
.K10_17:
    .quad .SB89
.K10_18:
    .quad .SB90
.K10_19:
    .quad .SB91
.K10_20:
    .quad .SB92
.K10_21:
    .quad .SB93
.K10_22:
    .quad .SB94
.K10_23:
    .quad .SB95
.K10_24:
    .quad .SB96
.K10_25:
    .quad .SB97
.K10_26:
    .quad .SB98
.K10_27:
    .quad .SB99
.K10_28:
    .quad .SB100
.K10_29:
    .quad .SB101
.K10_30:
    .quad .SB102
.K10_31:
    .quad .SB103
.K10_32:
    .quad .SB104
.K10_33:
    .quad .SB105
.K10_34:
    .quad .SB106
.K10_35:
    .quad .SB107
.K10_36:
    .quad .SB108
.K10_37:
    .quad .SB109
.K10_38:
    .quad .SB110
.K10_39:
    .quad .SB111
.K10_40:
    .quad .SB112
.K10_41:
    .quad .SB113
.K10_42:
    .quad .SB114
.K10_43:
    .quad .SB115
.K10_44:
    .quad .SB116
.K10_45:
    .quad .SB117
.K10_46:
    .quad .SB118
.K10_47:
    .quad .SB119
.K10_48:
    .quad .SB120
.K10_49:
    .quad .SB121
.K10_50:
    .quad .SB122
.K10_51:
    .quad .SB123
.K10_52:
    .quad .SB124
.K10_53:
    .quad .SB125
.K10_54:
    .quad .SB126
.K10_55:
    .quad .SB127
.K10_56:
    .quad .SB128
.K10_57:
    .quad .SB129
.K10_58:
    .quad .SB130
.K10_59:
    .quad .SB131
.K10_60:
    .quad .SB132
.K10_61:
    .quad .SB133
.K10_62:
    .quad .SB134
.K10_63:
    .quad .SB135
.K10_64:
    .quad .SB136
.K10_65:
    .quad .SB137
.K10_66:
    .quad .SB138
.K10_67:
    .quad .SB139
.K10_68:
    .quad .SB140
.K10_69:
    .quad .SB141
.K10_70:
    .quad .SB142
.K10_71:
    .quad .SB143
.K10_72:
    .quad .SB144
.K10_73:
    .quad .SB145
.K10_74:
    .quad .SB146
.K10_75:
    .quad .SB147
.K10_76:
    .quad .SB148
.K10_77:
    .quad .SB149
.K10_78:
    .quad .SB150
.K10_79:
    .quad .SB151
.K10_80:
    .quad .SB152
.K10_81:
    .quad .SB153
.K10_82:
    .quad .SB154
.K10_83:
    .quad .SB155
.K10_84:
    .quad .SB156
.K10_85:
    .quad .SB157
.K10_86:
    .quad .SB158
.K10_87:
    .quad .SB159
.K10_88:
    .quad .SB160
.K10_89:
    .quad .SB161
.K10_90:
    .quad .SB162
.K10_91:
    .quad .SB163
.K10_92:
    .quad .SB164
.K10_93:
    .quad .SB165
.K10_94:
    .quad .SB166
.K10_95:
    .quad .SB167
.K10_96:
    .quad .SB168
.K10_97:
    .quad .SB169
.K10_98:
    .quad .SB170
.K10_99:
    .quad .SB171
    .quad 0
    .quad -1
.K11:
    .quad 14
    .byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K12:
    .quad 5
    .byte 72, 84, 84, 80, 47
    .balign 8
    .section .data.rel.ro
    .balign 8
.Lfern_cagg_begin:
    .section .data.rel.ro
    .balign 8
    .quad 3
    .quad -1
.K1:
    .quad .S0
.K1_0:
    .quad .K0
.K1_1:
    .quad .K0
    .quad 2
    .quad -1
.K3:
    .quad .S5
.K3_0:
    .quad .SB6
    .quad 6
    .quad -1
.K5:
    .quad .S4
    .quad 500
.K5_1:
    .quad .K3
.K5_2:
    .quad .K1
.K5_3:
    .quad .K1
.K5_4:
    .quad .K4
.Lfern_cagg_end:
    .balign 8
.Lfern_cfn_begin:
.Lfern_cfn_end:
    .balign 8
.Lfern_cref_begin:
    .quad .K1_0
    .quad .K1_1
    .quad .K3_0
    .quad .K5_1
    .quad .K5_2
    .quad .K5_3
    .quad .K5_4
    .quad .K7_0
    .quad .K7_1
    .quad .K7_2
    .quad .K7_3
    .quad .K7_4
    .quad .K7_5
    .quad .K7_6
    .quad .K7_7
    .quad .K7_8
    .quad .K7_9
    .quad .K7_10
    .quad .K7_11
    .quad .K7_12
    .quad .K7_13
    .quad .K7_14
    .quad .K7_15
    .quad .K7_16
    .quad .K7_17
    .quad .K7_18
    .quad .K7_19
    .quad .K7_20
    .quad .K7_21
    .quad .K7_22
    .quad .K7_23
    .quad .K7_24
    .quad .K7_25
    .quad .K7_26
    .quad .K7_27
    .quad .K7_28
    .quad .K7_29
    .quad .K7_30
    .quad .K7_31
    .quad .K7_32
    .quad .K7_33
    .quad .K7_34
    .quad .K7_35
    .quad .K7_36
    .quad .K7_37
    .quad .K7_38
    .quad .K7_39
    .quad .K7_40
    .quad .K7_41
    .quad .K7_42
    .quad .K7_43
    .quad .K7_44
    .quad .K7_45
    .quad .K7_46
    .quad .K7_47
    .quad .K7_48
    .quad .K7_49
    .quad .K10_0
    .quad .K10_1
    .quad .K10_2
    .quad .K10_3
    .quad .K10_4
    .quad .K10_5
    .quad .K10_6
    .quad .K10_7
    .quad .K10_8
    .quad .K10_9
    .quad .K10_10
    .quad .K10_11
    .quad .K10_12
    .quad .K10_13
    .quad .K10_14
    .quad .K10_15
    .quad .K10_16
    .quad .K10_17
    .quad .K10_18
    .quad .K10_19
    .quad .K10_20
    .quad .K10_21
    .quad .K10_22
    .quad .K10_23
    .quad .K10_24
    .quad .K10_25
    .quad .K10_26
    .quad .K10_27
    .quad .K10_28
    .quad .K10_29
    .quad .K10_30
    .quad .K10_31
    .quad .K10_32
    .quad .K10_33
    .quad .K10_34
    .quad .K10_35
    .quad .K10_36
    .quad .K10_37
    .quad .K10_38
    .quad .K10_39
    .quad .K10_40
    .quad .K10_41
    .quad .K10_42
    .quad .K10_43
    .quad .K10_44
    .quad .K10_45
    .quad .K10_46
    .quad .K10_47
    .quad .K10_48
    .quad .K10_49
    .quad .K10_50
    .quad .K10_51
    .quad .K10_52
    .quad .K10_53
    .quad .K10_54
    .quad .K10_55
    .quad .K10_56
    .quad .K10_57
    .quad .K10_58
    .quad .K10_59
    .quad .K10_60
    .quad .K10_61
    .quad .K10_62
    .quad .K10_63
    .quad .K10_64
    .quad .K10_65
    .quad .K10_66
    .quad .K10_67
    .quad .K10_68
    .quad .K10_69
    .quad .K10_70
    .quad .K10_71
    .quad .K10_72
    .quad .K10_73
    .quad .K10_74
    .quad .K10_75
    .quad .K10_76
    .quad .K10_77
    .quad .K10_78
    .quad .K10_79
    .quad .K10_80
    .quad .K10_81
    .quad .K10_82
    .quad .K10_83
    .quad .K10_84
    .quad .K10_85
    .quad .K10_86
    .quad .K10_87
    .quad .K10_88
    .quad .K10_89
    .quad .K10_90
    .quad .K10_91
    .quad .K10_92
    .quad .K10_93
    .quad .K10_94
    .quad .K10_95
    .quad .K10_96
    .quad .K10_97
    .quad .K10_98
    .quad .K10_99
.Lfern_cref_end:
    .text
