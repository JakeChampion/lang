    .file 1 "/workspace/lang-interpreter-map-main-base-20261110-0330/bench/http_hello.fern"
    .file 2 "stdlib://std/http.fern.md"
    .file 3 "stdlib://std/i32.fern.md"
    .file 4 "stdlib://core/map.fern.md"
    .file 5 "stdlib://std/string.fern.md"
    .file 6 "stdlib://std/headers.fern.md"
    .file 7 "stdlib://std/io_buffered.fern.md"
    .file 8 "stdlib://std/json.fern.md"
    .file 9 "stdlib://std/stream.fern.md"
    .file 10 "stdlib://core/error.fern.md"
    .file 11 "stdlib://std/platform.fern.md"
    .file 12 "stdlib://std/url.fern.md"
    .file 13 "stdlib://std/utf8.fern.md"
    .file 14 "stdlib://core/cmp.fern.md"
    .file 15 "stdlib://core/primitive_text.fern.md"
    .file 16 "stdlib://std/number_parse.fern.md"
    .file 17 "stdlib://core/int.fern.md"
    .file 18 "stdlib://core/ops.fern.md"
    .file 19 "stdlib://core/iter.fern.md"
    .file 20 "stdlib://core/utf8_scalar.fern.md"
    .file 21 "stdlib://std/bigint.fern.md"
    .file 22 "stdlib://std/array.fern.md"
    .file 23 "stdlib://core/mem.fern.md"
    .file 24 "stdlib://std/result.fern.md"
    .file 25 "stdlib://std/i64.fern.md"
    .file 26 "stdlib://std/u32.fern.md"
    .file 27 "stdlib://std/u64.fern.md"
    .file 28 "stdlib://std/f32.fern.md"
    .file 29 "stdlib://std/f64.fern.md"
    .file 30 "stdlib://std/fetch.fern.md"
    .file 31 "stdlib://std/http/cookie.fern.md"
    .file 32 "stdlib://std/async.fern.md"
    .file 33 "stdlib://std/time.fern.md"
    .file 34 "stdlib://std/clock.fern.md"
    .file 35 "stdlib://std/net.fern.md"
    .file 36 "stdlib://std/http/trace.fern.md"
    .file 37 "stdlib://core/f64_text.fern.md"
    .file 38 "stdlib://std/num.fern.md"
    .file 39 "stdlib://std/unicode.fern"
    .file 40 "stdlib://std/dns.fern.md"
    .file 41 "stdlib://std/errno.fern.md"
    .file 42 "stdlib://std/base64.fern.md"
    .file 43 "stdlib://std/brotli.fern.md"
    .file 44 "stdlib://std/deflate.fern.md"
    .file 45 "stdlib://std/zstd.fern.md"
    .file 46 "stdlib://std/wasi_http.fern.md"
    .file 47 "stdlib://std/tls.fern.md"
    .file 48 "stdlib://std/tls/client.fern.md"
    .file 49 "stdlib://std/tls/ktls.fern.md"
    .file 50 "stdlib://std/tls/verify.fern.md"
    .file 51 "stdlib://std/crypto.fern.md"
    .file 52 "stdlib://std/hex.fern.md"
    .file 53 "stdlib://std/envflag.fern.md"
    .file 54 "stdlib://std/http/h2.fern.md"
    .file 55 "stdlib://std/http/h3.fern.md"
    .file 56 "stdlib://std/http/h3q.fern.md"
    .file 57 "stdlib://std/quic/conn.fern.md"
    .file 58 "stdlib://std/publicsuffix.fern"
    .file 59 "stdlib://std/option.fern.md"
    .file 60 "stdlib://std/codec.fern.md"
    .file 61 "stdlib://std/brotli/dictionary.fern"
    .file 62 "stdlib://std/brotli/encoder.fern.md"
    .file 63 "stdlib://std/hash/crc32.fern.md"
    .file 64 "stdlib://std/hash.fern.md"
    .file 65 "stdlib://std/tls/handshake.fern.md"
    .file 66 "stdlib://std/tls/identity.fern.md"
    .file 67 "stdlib://std/tls/keyschedule.fern.md"
    .file 68 "stdlib://std/tls/message.fern.md"
    .file 69 "stdlib://std/tls/record.fern.md"
    .file 70 "stdlib://std/tls/x509.fern.md"
    .file 71 "stdlib://std/crypto/ed25519.fern.md"
    .file 72 "stdlib://std/crypto/ecdsa.fern.md"
    .file 73 "stdlib://std/crypto/sha2.fern.md"
    .file 74 "stdlib://std/crypto/rsa.fern.md"
    .file 75 "stdlib://std/tls/pem.fern.md"
    .file 76 "stdlib://std/http/hpack.fern.md"
    .file 77 "stdlib://std/http/h2/frame.fern.md"
    .file 78 "stdlib://std/quic/frames.fern.md"
    .file 79 "stdlib://std/http/qpack.fern.md"
    .file 80 "stdlib://std/quic/streams.fern.md"
    .file 81 "stdlib://std/quic/packet.fern.md"
    .file 82 "stdlib://std/quic/params.fern.md"
    .file 83 "stdlib://std/quic/recovery.fern.md"
    .file 84 "stdlib://std/tls/server.fern.md"
    .file 85 "stdlib://std/tls/keyshare.fern.md"
    .file 86 "stdlib://std/tls/tls12.fern.md"
    .file 87 "stdlib://std/tls/der.fern.md"
    .file 88 "stdlib://std/crypto/aead.fern.md"
    .file 89 "stdlib://std/crypto/aes_gcm.fern.md"
    .file 90 "stdlib://std/crypto/chacha20poly1305.fern.md"
    .file 91 "stdlib://std/crypto/field25519.fern.md"
    .file 92 "stdlib://std/crypto/montgomery.fern.md"
    .file 93 "stdlib://std/crypto/p256.fern.md"
    .file 94 "stdlib://std/http/huffman.fern.md"
    .file 95 "stdlib://std/crypto/mlkem768.fern.md"
    .file 96 "stdlib://std/crypto/x25519.fern.md"
    .globl _start
    .text
__fn_http____find_crlf:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____find_crlf.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____find_crlf_0:
    .loc 2 682 3 prologue_end
    movl $13, %edi
    movq %rsi, %rdx
    movq %rdi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L0
    xorq %rdx, %rdx
.L0:
    cmpq $255, %rcx
    ja .L4
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L8
.L6:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L7
    addq $32, %r9
    cmpq %r10, %r9
    jle .L6
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L8
.L7:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L5
.L8:
    vzeroupper
.L1:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L3
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L2
    addq $16, %rdx
    jmp .L1
.L2:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L5
.L3:
    cmpq %r8, %rdx
    jge .L4
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L9
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L4
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L4
    addq %r9, %rdx
    jmp .L5
.L9:
    cmpq %r8, %rdx
    jge .L4
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L5
    addq $1, %rdx
    jmp .L9
.L4:
    movq $-1, %rdx
.L5:
    movq %rdx, %rax
.Lssa_http____find_crlf_3:
.Lssa_http____find_crlf_4:
    cmpq $0, %rax
    jl .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_8:
    leaq 1(%rax), %rdi
    movslq %edi, %rdi
    cmpq %r12, %rdi
    jge .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_7:
    leal 1(%rax), %edi
    cmpq (%rbx), %rdi
    jae __fern_oob_abort
    movzbl 8(%rbx,%rdi), %esi
    cmpq $10, %rsi
    je .Lssa_http____find_crlf_1
.Lssa_http____find_crlf_5:
    .loc 2 687 7
    leaq 1(%rax), %rsi
    movslq %esi, %rsi
    movl $13, %edi
    movq %rsi, %rdx
    movq %rdi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L10
    xorq %rdx, %rdx
.L10:
    cmpq $255, %rcx
    ja .L14
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L18
.L16:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L17
    addq $32, %r9
    cmpq %r10, %r9
    jle .L16
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L18
.L17:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L15
.L18:
    vzeroupper
.L11:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L13
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L12
    addq $16, %rdx
    jmp .L11
.L12:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L15
.L13:
    cmpq %r8, %rdx
    jge .L14
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L19
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L14
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L14
    addq %r9, %rdx
    jmp .L15
.L19:
    cmpq %r8, %rdx
    jge .L14
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L15
    addq $1, %rdx
    jmp .L19
.L14:
    movq $-1, %rdx
.L15:
    movq %rdx, %rax
    cmpq $0, %rax
    jge .Lssa_http____find_crlf_8
.Lssa_http____find_crlf_2:
    .loc 2 689 3
    movq $-1, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____find_crlf_1:
    .loc 2 685 7
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____shared_string:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____shared_string.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
    movq %r8, %r14
.Lssa_http____shared_string_0:
    movq 8(%r14), %rsi
    movq %r13, %rdi
    subq %r12, %rdi
    movslq %edi, %rdi
    cmpq %rdi, %rsi
    jne .Lssa_http____shared_string_1
.Lssa_http____shared_string_4:
    .loc 2 2350 3 prologue_end
    movq 8(%r14), %rdi
    xorl %esi, %esi
    movq %rdi, %r8
    movq %rsi, %rcx
    movq %r14, %rdx
    movq %r12, %rsi
    movq %rbx, %rax
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L20_aop
    xorq %rsi, %rsi
.L20_aop:
    cmpq %r9, %rsi
    jle .L20_aok
    movq %r9, %rsi
.L20_aok:
    cmpq $0, %rcx
    jge .L20_bop
    xorq %rcx, %rcx
.L20_bop:
    cmpq %r10, %rcx
    jle .L20_bok
    movq %r10, %rcx
.L20_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L20_na
    movq %r9, %r8
.L20_na:
    cmpq %r10, %r8
    jle .L20_nb
    movq %r10, %r8
.L20_nb:
    cmpq $0, %r8
    jge .L20_nok
    xorq %r8, %r8
.L20_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L20_vec
    cmpq $8, %r8
    jge .L20_w8
    cmpq $4, %r8
    jge .L20_w4
    cmpq $2, %r8
    jge .L20_w2
    jmp .L20_tail
.L20_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L20_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L20_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L20_done
.L20_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L20_done
.L20_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L20_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L20_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L20_done
.L20_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L20_done
.L20_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L20_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L20_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L20_done
.L20_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L20_done
.L20_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L20_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L20_hit
    addq $16, %rdx
    jmp .L20_vec
.L20_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L20_done
.L20_tail:
    cmpq %r8, %rdx
    jge .L20_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L20_th
    addq $1, %rdx
    jmp .L20_tail
.L20_th:
    movq %rdx, %rax
    jmp .L20_done
.L20_eq:
    movq %r8, %rax
.L20_done:
    movq 8(%r14), %rsi
    cmpq %rsi, %rax
    jne .Lssa_http____shared_string_1
.Lssa_http____shared_string_3:
    testb $1, %r14b
    jnz .Lssa_http____shared_string_rcinc30
    cmpq $0x10000, %r14
    jb .Lssa_http____shared_string_rcinc30
    movl -8(%r14), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http____shared_string_rcinc30
    addl $1, %ecx
    movl %ecx, -8(%r14)
.Lssa_http____shared_string_rcinc30:
    .loc 2 719 5
    movq %r14, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____shared_string_1:
    .loc 2 713 5
    movq %rbx, %rax
    movq %r12, %rsi
    movq %r13, %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    .loc 2 721 3
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____token_is:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_http____token_is.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_http____token_is_0:
    .loc 2 814 3 prologue_end
    movq 8(%rax), %rdi
    xorl %r8d, %r8d
    xchgq %r8, %rsi
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    jmp __fn_http____token_at.r
    .cfi_restore_state
    .cfi_endproc
__fn_http____token_at:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____token_at.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
.Lssa_http____token_at_0:
.Lssa_http____token_at_10:
.Lssa_http____token_at_11:
    cmpq %rdi, %rsi
    jge .Lssa_http____token_at_33
.Lssa_http____token_at_17:
    cmpq 8(%rax), %rsi
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%rsi), %r9d
.Lssa_http____token_at_16:
    .loc 2 838 3 prologue_end
    cmpq $32, %r9
    je .Lssa_http____token_at_12
.Lssa_http____token_at_14:
    cmpq $9, %r9
    jne .Lssa_http____token_at_33
.Lssa_http____token_at_12:
    .loc 2 819 10
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_http____token_at_17
.Lssa_http____token_at_8:
.Lssa_http____token_at_33:
    cmpq %rsi, %rdi
    jle .Lssa_http____token_at_7
.Lssa_http____token_at_39:
    leaq -1(%rdi), %r9
    cmpq 8(%rax), %r9
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%r9), %r10d
.Lssa_http____token_at_38:
    .loc 2 838 3
    cmpq $32, %r10
    je .Lssa_http____token_at_34
.Lssa_http____token_at_36:
    cmpq $9, %r10
    jne .Lssa_http____token_at_7
.Lssa_http____token_at_34:
    .loc 2 822 9
    subq $1, %rdi
    cmpq %rsi, %rdi
    jg .Lssa_http____token_at_39
.Lssa_http____token_at_7:
    subq %rsi, %rdi
    movslq %edi, %rdi
    movq 8(%r8), %r10
    cmpq %r10, %rdi
    je .Lssa_http____token_at_4
.Lssa_http____token_at_6:
    .loc 2 825 5
    xorl %eax, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____token_at_4:
    .loc 2 827 3
.Lssa_http____token_at_3:
    movq 8(%r8), %r10
    movq 0(%r8), %rdi
    xorl %r8d, %r8d
.Lssa_http____token_at_59:
    cmpq %r10, %r8
    jge .Lssa_http____token_at_2
.Lssa_http____token_at_72:
    leal (%rsi,%r8), %r9d
    cmpq 8(%rax), %r9
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%r9), %ebx
.Lssa_http____token_at_71:
    cmpq $65, %rbx
    jl .Lssa_http____token_at_67
.Lssa_http____token_at_70:
    cmpq $90, %rbx
    jg .Lssa_http____token_at_67
.Lssa_http____token_at_69:
    .loc 2 844 5
    leaq 32(%rbx), %r9
    movslq %r9d, %r9
    movq %r9, %rbx
.Lssa_http____token_at_68:
.Lssa_http____token_at_67:
    movzbl (%rdi,%r8), %r9d
.Lssa_http____token_at_66:
    cmpq $65, %r9
    jl .Lssa_http____token_at_62
.Lssa_http____token_at_65:
    cmpq $90, %r9
    jg .Lssa_http____token_at_62
.Lssa_http____token_at_64:
    leaq 32(%r9), %rcx
    movslq %ecx, %r12
    movq %r12, %r9
.Lssa_http____token_at_63:
.Lssa_http____token_at_62:
    cmpq %r9, %rbx
    jne .Lssa_http____token_at_1
.Lssa_http____token_at_60:
    .loc 2 832 7
    addq $1, %r8
    cmpq %r10, %r8
    jl .Lssa_http____token_at_72
.Lssa_http____token_at_2:
    .loc 2 834 3
    movl $1, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____token_at_1:
    .loc 2 830 7
    xorl %eax, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____leading_fields:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_http____leading_fields.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa_http____leading_fields_0:
    .loc 6 90 3 prologue_end
    leaq .K1(%rip), %rax
    .loc 2 937 3
.Lssa_http____leading_fields_2:
    movq %rax, %r13
    xorl %r14d, %r14d
.Lssa_http____leading_fields_3:
    cmpq -48(%rbp), %r14
    jl .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_6:
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_http____leading_fields_1
.Lssa_http____leading_fields_4:
    .loc 2 939 9
    movq 8(%rbx), %rsi
    cmpq (%rsi), %r14
    jae __fern_oob_abort
    movq 8(%rsi,%r14,8), %r8
    movq 16(%rbx), %rsi
    cmpq (%rsi), %r14
    jae __fern_oob_abort
    movq 8(%rsi,%r14,8), %r15
    testb $1, %r13b
    jnz .Lssa_http____leading_fields_uq4
    cmpq $0x10000, %r13
    jb .Lssa_http____leading_fields_uq4
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____leading_fields_uq4:
    jne .Lssa_http____leading_fields_10
.Lssa_http____leading_fields_9:
    movq %r13, %r9
    jmp .Lssa_http____leading_fields_11
.Lssa_http____leading_fields_10:
    xorl %r9d, %r9d
.Lssa_http____leading_fields_11:
    .loc 6 301 3
    movq 8(%r13), %r10
    cmpq $0, %r9
    jne .Lssa_http____leading_fields_14
.Lssa_http____leading_fields_12:
    testb $1, %r10b
    jnz .Lssa_http____leading_fields_rcinc56
    cmpq $0x10000, %r10
    jb .Lssa_http____leading_fields_rcinc56
    movl -8(%r10), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http____leading_fields_rcinc56
    addl $1, %ecx
    movl %ecx, -8(%r10)
.Lssa_http____leading_fields_rcinc56:
.Lssa_http____leading_fields_14:
    testb $1, %r8b
    jnz .Lssa_http____leading_fields_rcinc57
    cmpq $0x10000, %r8
    jb .Lssa_http____leading_fields_rcinc57
    movl -8(%r8), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http____leading_fields_rcinc57
    addl $1, %ecx
    movl %ecx, -8(%r8)
.Lssa_http____leading_fields_rcinc57:
    testb $1, %r10b
    jnz .Lssa_http____leading_fields_uq14
    cmpq $0x10000, %r10
    jb .Lssa_http____leading_fields_uq14
    movl -8(%r10), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____leading_fields_uq14:
    jne .Lssa_http____leading_fields_16
.Lssa_http____leading_fields_15:
    movq %r10, %rdi
    movq %r8, %rsi
    movq %r8, -56(%rbp)
    movq %r9, -64(%rbp)
    movq %r10, -72(%rbp)
    call __fern_arr_push_owned
    movq -56(%rbp), %r8
    movq -64(%rbp), %r9
    movq -72(%rbp), %r10
    movq %rax, %r12
    jmp .Lssa_http____leading_fields_17
.Lssa_http____leading_fields_16:
    movq %r10, %rdi
    movq %r8, %rsi
    movq %r9, -56(%rbp)
    movq %r10, -64(%rbp)
    call __fern_arr_push
    movq -56(%rbp), %r9
    movq -64(%rbp), %r10
    movq %rax, %r12
    movq %r9, -56(%rbp)
    movq %r10, -64(%rbp)
    movq %r10, %rax
    call __fn___fern_arr_inc_elems.r
    movq -56(%rbp), %r9
    movq -64(%rbp), %r10
    movq %r9, -56(%rbp)
    movq %r10, %rax
    call __fn___fern_arr_dec.r
    movq -56(%rbp), %r9
.Lssa_http____leading_fields_17:
    movq 16(%r13), %r10
    cmpq $0, %r9
    jne .Lssa_http____leading_fields_20
.Lssa_http____leading_fields_18:
    testb $1, %r10b
    jnz .Lssa_http____leading_fields_rcinc67
    cmpq $0x10000, %r10
    jb .Lssa_http____leading_fields_rcinc67
    movl -8(%r10), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http____leading_fields_rcinc67
    addl $1, %ecx
    movl %ecx, -8(%r10)
.Lssa_http____leading_fields_rcinc67:
.Lssa_http____leading_fields_20:
    testb $1, %r15b
    jnz .Lssa_http____leading_fields_rcinc68
    cmpq $0x10000, %r15
    jb .Lssa_http____leading_fields_rcinc68
    movl -8(%r15), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http____leading_fields_rcinc68
    addl $1, %ecx
    movl %ecx, -8(%r15)
.Lssa_http____leading_fields_rcinc68:
    testb $1, %r10b
    jnz .Lssa_http____leading_fields_uq20
    cmpq $0x10000, %r10
    jb .Lssa_http____leading_fields_uq20
    movl -8(%r10), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____leading_fields_uq20:
    jne .Lssa_http____leading_fields_22
.Lssa_http____leading_fields_21:
    movq %r10, %rdi
    movq %r15, %rsi
    movq %r9, -56(%rbp)
    movq %r10, -64(%rbp)
    call __fern_arr_push_owned
    movq -56(%rbp), %r9
    movq -64(%rbp), %r10
    movq %rax, %r15
    jmp .Lssa_http____leading_fields_23
.Lssa_http____leading_fields_22:
    movq %r10, %rdi
    movq %r15, %rsi
    movq %r9, -56(%rbp)
    movq %r10, -64(%rbp)
    call __fern_arr_push
    movq -56(%rbp), %r9
    movq -64(%rbp), %r10
    movq %rax, %r8
    movq %r8, -56(%rbp)
    movq %r9, -64(%rbp)
    movq %r10, -72(%rbp)
    movq %r10, %rax
    call __fn___fern_arr_inc_elems.r
    movq -56(%rbp), %r8
    movq -64(%rbp), %r9
    movq -72(%rbp), %r10
    movq %r8, -56(%rbp)
    movq %r9, -64(%rbp)
    movq %r10, %rax
    call __fn___fern_arr_dec.r
    movq -56(%rbp), %r8
    movq -64(%rbp), %r9
    movq %r8, %r15
.Lssa_http____leading_fields_23:
    cmpq $0, %r9
    jne .Lssa_http____leading_fields_25
.Lssa_http____leading_fields_24:
    movl $3, %r8d
    movq %r9, -56(%rbp)
    movq %r9, %rax
    movq %r8, %rsi
    call __fn___fern_alloc_reuse.r
    movq -56(%rbp), %r9
    leaq .S0(%rip), %r8
    movq %r8, 0(%rax)
    movq %rax, %r10
    jmp .Lssa_http____leading_fields_26
.Lssa_http____leading_fields_25:
    movq %r9, %r10
.Lssa_http____leading_fields_26:
    cmpq $0, %r9
    jne .Lssa_http____leading_fields_29
.Lssa_http____leading_fields_28:
    movq %r10, -56(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -56(%rbp), %r10
.Lssa_http____leading_fields_29:
    movq %r12, 8(%r10)
    movq %r15, 16(%r10)
    .loc 2 940 7
    addq $1, %r14
    movq %r10, %r13
    cmpq -48(%rbp), %r14
    jge .Lssa_http____leading_fields_6
    jmp .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_1:
    .loc 2 942 3
    movq %r13, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____crlf_terminated:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____crlf_terminated.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____crlf_terminated_0:
.Lssa_http____crlf_terminated_7:
    movq %rsi, %r13
.Lssa_http____crlf_terminated_8:
.Lssa_http____crlf_terminated_18:
    .loc 2 953 5 prologue_end
    movl $13, %esi
    movq %r13, %rdx
    movq %rsi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L21
    xorq %rdx, %rdx
.L21:
    cmpq $255, %rcx
    ja .L25
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L29
.L27:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L28
    addq $32, %r9
    cmpq %r10, %r9
    jle .L27
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L29
.L28:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L26
.L29:
    vzeroupper
.L22:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L24
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L23
    addq $16, %rdx
    jmp .L22
.L23:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L26
.L24:
    cmpq %r8, %rdx
    jge .L25
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L30
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L25
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L25
    addq %r9, %rdx
    jmp .L26
.L30:
    cmpq %r8, %rdx
    jge .L25
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L26
    addq $1, %rdx
    jmp .L30
.L25:
    movq $-1, %rdx
.L26:
    movq %rdx, %r14
    .loc 2 954 5
    movl $10, %esi
    movq %r13, %rdx
    movq %rsi, %rcx
    movq %rbx, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L31
    xorq %rdx, %rdx
.L31:
    cmpq $255, %rcx
    ja .L35
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L39
.L37:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L38
    addq $32, %r9
    cmpq %r10, %r9
    jle .L37
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L39
.L38:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L36
.L39:
    vzeroupper
.L32:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L34
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L33
    addq $16, %rdx
    jmp .L32
.L33:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L36
.L34:
    cmpq %r8, %rdx
    jge .L35
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L40
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L35
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L35
    addq %r9, %rdx
    jmp .L36
.L40:
    cmpq %r8, %rdx
    jge .L35
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L36
    addq $1, %rdx
    jmp .L40
.L35:
    movq $-1, %rdx
.L36:
    movq %rdx, %rax
    cmpq $0, %r14
    jl .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_17:
    cmpq %r12, %r14
    jge .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_15:
    cmpq $0, %rax
    jl .Lssa_http____crlf_terminated_12
.Lssa_http____crlf_terminated_14:
    cmpq %r14, %rax
    jl .Lssa_http____crlf_terminated_2
.Lssa_http____crlf_terminated_12:
    leaq 1(%r14), %rsi
    movq 0(%rbx), %rdi
    cmpq %rdi, %rsi
    jge .Lssa_http____crlf_terminated_9
.Lssa_http____crlf_terminated_11:
    leaq 1(%r14), %rdi
    cmpq (%rbx), %rdi
    jae __fern_oob_abort
    movzbl 8(%rbx,%rdi), %esi
    cmpq $10, %rsi
    jne .Lssa_http____crlf_terminated_1
.Lssa_http____crlf_terminated_9:
    .loc 2 964 7
    addq $2, %r14
    movslq %r14d, %r13
    jmp .Lssa_http____crlf_terminated_18
.Lssa_http____crlf_terminated_6:
    .loc 2 956 7
    movl $1, %esi
    cmpq %rax, %r12
    setle %r12b
    movzbq %r12b, %r12
    cmpq $0, %rax
    movq %rsi, %rax
    cmovgeq %r12, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_2:
    .loc 2 959 7
    xorl %eax, %eax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_1:
    .loc 2 962 7
    xorl %eax, %eax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____field_at:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____field_at.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_http____field_at_0:
.Lssa_http____field_at_3:
    movq %rdi, %r13
.Lssa_http____field_at_4:
    movq 8(%rbx), %rdi
    movq 0(%rdi), %rsi
    cmpq %rsi, %r13
    jge .Lssa_http____field_at_2
.Lssa_http____field_at_8:
    movq 8(%rbx), %rsi
    cmpq (%rsi), %r13
    jae __fern_oob_abort
    movq 8(%rsi,%r13,8), %rdi
    movq 8(%rdi), %rsi
    movq 8(%r12), %rdi
    cmpq %rdi, %rsi
    jne .Lssa_http____field_at_5
.Lssa_http____field_at_7:
    movq 8(%rbx), %rdi
    cmpq (%rdi), %r13
    jae __fern_oob_abort
    movq 8(%rdi,%r13,8), %rax
    movq %r12, %rsi
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http____field_at_1
.Lssa_http____field_at_5:
    .loc 2 1089 7 prologue_end
    addq $1, %r13
    jmp .Lssa_http____field_at_4
.Lssa_http____field_at_2:
    .loc 2 1091 3
    movq $-1, %rax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____field_at_1:
    .loc 2 1087 7
    movq %r13, %rax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____kind_if:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____kind_if.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rdi, %rbx
.Lssa_http____kind_if_0:
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jz .Lssa_http____kind_if_1
.Lssa_http____kind_if_3:
    .loc 2 1152 5 prologue_end
    movq %rbx, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____kind_if_1:
    .loc 2 1154 3
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____target_start:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____target_start.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
.Lssa_http____target_start_0:
    movq %rax, %r9
    andq $2, %r9
    testq %r9, %r9
    jz .Lssa_http____target_start_2
.Lssa_http____target_start_1:
    leaq -2(%rax), %r9
    movq 0(%r9), %r10
    movq 8(%r9), %rbx
    movq %rbx, %r9
    jmp .Lssa_http____target_start_3
.Lssa_http____target_start_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____target_start_5
.Lssa_http____target_start_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____target_start_3
.Lssa_http____target_start_5:
    xorl %r9d, %r9d
.Lssa_http____target_start_6:
.Lssa_http____target_start_3:
    leaq 1(%rsi), %rcx
    movslq %ecx, %rbx
    cmpq %rbx, %rdi
    jne .Lssa_http____target_start_13
.Lssa_http____target_start_19:
    movl %esi, %ebx
    cmpq %r9, %rbx
    jb .Lssa_http____target_start_26
.Lssa_http____target_start_24:
    call __fern_oob_abort
.Lssa_http____target_start_26:
    movzbl (%r10,%rbx), %r12d
    cmpq $42, %r12
    jne .Lssa_http____target_start_13
.Lssa_http____target_start_18:
    .loc 2 2056 7 prologue_end
    movq $-1, %rax
    .loc 2 2058 5
    movq $-2, %rsi
    testq %r8, %r8
    movq %rax, %rdi
    cmoveq %rsi, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____target_start_13:
    cmpq %rsi, %rdi
    jle .Lssa_http____target_start_9
.Lssa_http____target_start_12:
    movl %esi, %r8d
    cmpq %r9, %r8
    jb .Lssa_http____target_start_41
.Lssa_http____target_start_39:
    call __fern_oob_abort
.Lssa_http____target_start_41:
    movzbl (%r10,%r8), %r9d
    cmpq $47, %r9
    jne .Lssa_http____target_start_9
.Lssa_http____target_start_11:
    .loc 2 2061 5
    movq %rsi, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____target_start_9:
    .loc 2 2063 3
    call __fn_http____absolute_form_path.r
    .loc 2 2065 5
    movq $-2, %rdi
    cmpq $0, %rax
    cmovlq %rdi, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____path_end:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____path_end.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
.Lssa_http____path_end_0:
    movq %rax, %r8
    andq $2, %r8
    testq %r8, %r8
    jz .Lssa_http____path_end_2
.Lssa_http____path_end_1:
    leaq -2(%rax), %r8
    movq 0(%r8), %r9
    movq 8(%r8), %r10
    xchgq %r9, %r10
    jmp .Lssa_http____path_end_16
.Lssa_http____path_end_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____path_end_5
.Lssa_http____path_end_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____path_end_16
.Lssa_http____path_end_5:
    xorl %r9d, %r9d
.Lssa_http____path_end_6:
.Lssa_http____path_end_3:
.Lssa_http____path_end_15:
.Lssa_http____path_end_16:
    cmpq %rdi, %rsi
    jge .Lssa_http____path_end_14
.Lssa_http____path_end_19:
    movl %esi, %r8d
    cmpq %r9, %r8
    jb .Lssa_http____path_end_26
.Lssa_http____path_end_24:
    call __fern_oob_abort
.Lssa_http____path_end_26:
    movzbl (%r10,%r8), %ebx
    .loc 2 2071 3 prologue_end
    cmpq $63, %rbx
    je .Lssa_http____path_end_13
.Lssa_http____path_end_17:
    .loc 2 2125 7
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_http____path_end_19
.Lssa_http____path_end_14:
    .loc 2 2127 3
    movq $-1, %rbx
    jmp .Lssa_http____path_end_12
.Lssa_http____path_end_13:
    movq %rsi, %rbx
.Lssa_http____path_end_12:
    cmpq $0, %rbx
    jge .Lssa_http____path_end_9
.Lssa_http____path_end_11:
    .loc 2 2073 5
    movq %rdi, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____path_end_9:
    leaq 1(%rbx), %rsi
    movslq %esi, %rsi
    call __fn_http____query_ok.r
    testq %rax, %rax
    jz .Lssa_http____path_end_7
.Lssa_http____path_end_8:
    movq %rbx, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____path_end_7:
    .loc 2 2076 5
    movq $-1, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____absolute_form_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____absolute_form_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa_http____absolute_form_path_0:
    movq %rbx, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____absolute_form_path_2
.Lssa_http____absolute_form_path_1:
    leaq -2(%rbx), %rsi
    movq 0(%rsi), %rdi
    movq 8(%rsi), %r8
    movq %rdi, %r14
    movq %r8, %r15
    jmp .Lssa_http____absolute_form_path_3
.Lssa_http____absolute_form_path_2:
    leaq 8(%rbx), %r8
    cmpq $0, %rbx
    je .Lssa_http____absolute_form_path_5
.Lssa_http____absolute_form_path_4:
    movq 0(%rbx), %rdi
    jmp .Lssa_http____absolute_form_path_6
.Lssa_http____absolute_form_path_5:
    xorl %edi, %edi
.Lssa_http____absolute_form_path_6:
    movq %r8, %r14
    movq %rdi, %r15
.Lssa_http____absolute_form_path_3:
    .loc 2 2082 3 prologue_end
    leaq .SB1(%rip), %r8
    movq %rbx, %rax
    movq %r12, %rsi
    movq %r13, %rdi
    call __fn_http____prefix_ci.r
    testq %rax, %rax
    jz .Lssa_http____absolute_form_path_18
.Lssa_http____absolute_form_path_19:
    .loc 2 2084 8
    leaq 7(%r12), %r8
    movslq %r8d, %r8
    movq %r8, -48(%rbp)
    jmp .Lssa_http____absolute_form_path_17
.Lssa_http____absolute_form_path_18:
    movq $-1, -48(%rbp)
.Lssa_http____absolute_form_path_17:
    leaq .SB2(%rip), %r8
    movq %rbx, %rax
    movq %r12, %rsi
    movq %r13, %rdi
    call __fn_http____prefix_ci.r
    testq %rax, %rax
    jz .Lssa_http____absolute_form_path_14
.Lssa_http____absolute_form_path_16:
    .loc 2 2087 8
    addq $8, %r12
    movslq %r12d, %r12
    movq %r12, -48(%rbp)
.Lssa_http____absolute_form_path_15:
.Lssa_http____absolute_form_path_14:
    cmpq $0, -48(%rbp)
    jge .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_13:
    .loc 2 2090 5
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_11:
    movq -48(%rbp), %r12
.Lssa_http____absolute_form_path_34:
    cmpq %r13, %r12
    jge .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_39:
    movl %r12d, %r8d
    cmpq %r15, %r8
    jb .Lssa_http____absolute_form_path_46
.Lssa_http____absolute_form_path_44:
    call __fern_oob_abort
.Lssa_http____absolute_form_path_46:
    movzbl (%r14,%r8), %eax
    cmpq $47, %rax
    je .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_38:
    cmpq $63, %rax
    je .Lssa_http____absolute_form_path_10
.Lssa_http____absolute_form_path_37:
    call __fn_http____is_pchar.r
    testq %rax, %rax
    jz .Lssa_http____absolute_form_path_8
.Lssa_http____absolute_form_path_35:
    .loc 2 2097 19
    addq $1, %r12
    cmpq %r13, %r12
    jl .Lssa_http____absolute_form_path_39
.Lssa_http____absolute_form_path_10:
    .loc 2 2100 5
    movq $-1, %r8
    cmpq -48(%rbp), %r12
    movq %r8, %rax
    cmovneq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_8:
    .loc 2 2095 7
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____prefix_ci:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____prefix_ci.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
.Lssa_http____prefix_ci_0:
    movq %rax, %r9
    andq $2, %r9
    testq %r9, %r9
    jz .Lssa_http____prefix_ci_2
.Lssa_http____prefix_ci_1:
    leaq -2(%rax), %r9
    movq 0(%r9), %r10
    movq 8(%r9), %rbx
    movq %rbx, %r9
    jmp .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____prefix_ci_5
.Lssa_http____prefix_ci_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_5:
    xorl %r9d, %r9d
.Lssa_http____prefix_ci_6:
.Lssa_http____prefix_ci_3:
    subq %rsi, %rdi
    movslq %edi, %rdi
    movq 8(%r8), %rax
    cmpq %rax, %rdi
    jge .Lssa_http____prefix_ci_10
.Lssa_http____prefix_ci_12:
    .loc 2 2107 5 prologue_end
    xorl %eax, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_10:
    .loc 2 2109 3
.Lssa_http____prefix_ci_9:
    movq 8(%r8), %rdi
    movq 0(%r8), %rax
    xorl %r8d, %r8d
.Lssa_http____prefix_ci_17:
    cmpq %rdi, %r8
    jge .Lssa_http____prefix_ci_8
.Lssa_http____prefix_ci_25:
    leal (%rsi,%r8), %ebx
    cmpq %r9, %rbx
    jb .Lssa_http____prefix_ci_32
.Lssa_http____prefix_ci_30:
    call __fern_oob_abort
.Lssa_http____prefix_ci_32:
    movzbl (%r10,%rbx), %r12d
.Lssa_http____prefix_ci_24:
    cmpq $65, %r12
    jl .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_23:
    cmpq $90, %r12
    jg .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_22:
    .loc 2 844 5
    leaq 32(%r12), %rcx
    movslq %ecx, %rbx
    movq %rbx, %r12
.Lssa_http____prefix_ci_21:
.Lssa_http____prefix_ci_20:
    movzbl (%rax,%r8), %ebx
    cmpq %rbx, %r12
    jne .Lssa_http____prefix_ci_7
.Lssa_http____prefix_ci_18:
    .loc 2 2114 7
    addq $1, %r8
    cmpq %rdi, %r8
    jl .Lssa_http____prefix_ci_25
.Lssa_http____prefix_ci_8:
    .loc 2 2116 3
    movl $1, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_7:
    .loc 2 2112 7
    xorl %eax, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____is_pchar:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http____is_pchar.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_http____is_pchar_0:
.Lssa_http____is_pchar_42:
    .loc 2 2136 3 prologue_end
    cmpq $97, %rax
    jl .Lssa_http____is_pchar_37
.Lssa_http____is_pchar_41:
    cmpq $122, %rax
    jle .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_37:
    cmpq $65, %rax
    jl .Lssa_http____is_pchar_32
.Lssa_http____is_pchar_36:
    cmpq $90, %rax
    jle .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_32:
    cmpq $48, %rax
    jl .Lssa_http____is_pchar_27
.Lssa_http____is_pchar_31:
    cmpq $57, %rax
    jle .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_27:
    cmpq $45, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_24:
    cmpq $46, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_21:
    cmpq $95, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_18:
    cmpq $126, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_14:
    .loc 2 2141 3
    leaq .SB3(%rip), %rsi
    .loc 2 2142 3
.Lssa_http____is_pchar_13:
    movq 8(%rsi), %rdi
    movq 0(%rsi), %r8
    xorl %esi, %esi
.Lssa_http____is_pchar_93:
    cmpq %rdi, %rsi
    jge .Lssa_http____is_pchar_8
.Lssa_http____is_pchar_96:
    movzbl (%r8,%rsi), %r9d
    cmpq %rax, %r9
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_94:
    .loc 2 2147 7
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_http____is_pchar_96
.Lssa_http____is_pchar_8:
    cmpq $58, %rax
    je .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_5:
    cmpq $64, %rax
    jne .Lssa_http____is_pchar_2
.Lssa_http____is_pchar_3:
    movl $1, %eax
    jmp .Lssa_http____is_pchar_1
.Lssa_http____is_pchar_2:
    cmpq $37, %rax
    sete %al
    movzbq %al, %rax
.Lssa_http____is_pchar_1:
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____query_ok:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____query_ok.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa_http____query_ok_0:
    movq %rbx, %rdi
    andq $2, %rdi
    testq %rdi, %rdi
    jz .Lssa_http____query_ok_2
.Lssa_http____query_ok_1:
    leaq -2(%rbx), %rdi
    movq 0(%rdi), %r8
    movq 8(%rdi), %r9
    movq %r8, %r13
    movq %r9, %r14
    jmp .Lssa_http____query_ok_10
.Lssa_http____query_ok_2:
    leaq 8(%rbx), %r9
    cmpq $0, %rbx
    je .Lssa_http____query_ok_5
.Lssa_http____query_ok_4:
    movq 0(%rbx), %r8
    jmp .Lssa_http____query_ok_6
.Lssa_http____query_ok_5:
    xorl %r8d, %r8d
.Lssa_http____query_ok_6:
    movq %r9, %r13
    movq %r8, %r14
.Lssa_http____query_ok_3:
.Lssa_http____query_ok_10:
    movq %rsi, %r15
.Lssa_http____query_ok_11:
    cmpq %r12, %r15
    jge .Lssa_http____query_ok_9
.Lssa_http____query_ok_21:
    movl %r15d, %esi
    cmpq %r14, %rsi
    jb .Lssa_http____query_ok_28
.Lssa_http____query_ok_26:
    call __fern_oob_abort
.Lssa_http____query_ok_28:
    movzbl (%r13,%rsi), %r8d
    cmpq $37, %r8
    jne .Lssa_http____query_ok_17
.Lssa_http____query_ok_20:
    movq %r8, -48(%rbp)
    movq %rbx, %rax
    movq %r15, %rsi
    movq %r12, %rdi
    call __fn_http____pct_byte.r
    movq -48(%rbp), %r8
    cmpq $0, %rax
    jl .Lssa_http____query_ok_8
.Lssa_http____query_ok_18:
    .loc 2 2160 9 prologue_end
    leaq 3(%r15), %rsi
    movslq %esi, %rsi
    movq %rsi, %r15
    jmp .Lssa_http____query_ok_11
.Lssa_http____query_ok_17:
    movq %r8, -48(%rbp)
    movq %r8, %rax
    call __fn_http____is_pchar.r
    movq -48(%rbp), %r8
    testq %rax, %rax
    jnz .Lssa_http____query_ok_13
.Lssa_http____query_ok_16:
    cmpq $47, %r8
    je .Lssa_http____query_ok_13
.Lssa_http____query_ok_15:
    cmpq $63, %r8
    jne .Lssa_http____query_ok_7
.Lssa_http____query_ok_13:
    .loc 2 2165 9
    addq $1, %r15
.Lssa_http____query_ok_12:
    cmpq %r12, %r15
    jl .Lssa_http____query_ok_21
.Lssa_http____query_ok_9:
    .loc 2 2168 3
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____query_ok_8:
    .loc 2 2158 9
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____query_ok_7:
    .loc 2 2163 9
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____pct_byte:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____pct_byte.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_http____pct_byte_0:
    movq %rax, %r8
    andq $2, %r8
    testq %r8, %r8
    jz .Lssa_http____pct_byte_2
.Lssa_http____pct_byte_1:
    leaq -2(%rax), %r8
    movq 0(%r8), %r9
    movq 8(%r8), %r10
    xchgq %r9, %r10
    jmp .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____pct_byte_5
.Lssa_http____pct_byte_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_5:
    xorl %r9d, %r9d
.Lssa_http____pct_byte_6:
.Lssa_http____pct_byte_3:
    leaq 2(%rsi), %r8
    movslq %r8d, %r8
    cmpq %rdi, %r8
    jl .Lssa_http____pct_byte_39
.Lssa_http____pct_byte_41:
    .loc 2 2173 5 prologue_end
    movq $-1, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_39:
    .loc 2 2175 3
    leal 1(%rsi), %r8d
    cmpq %r9, %r8
    jb .Lssa_http____pct_byte_48
.Lssa_http____pct_byte_46:
    call __fern_oob_abort
.Lssa_http____pct_byte_48:
    movzbl (%r10,%r8), %edi
.Lssa_http____pct_byte_38:
    cmpq $48, %rdi
    jb .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_37:
    cmpq $57, %rdi
    ja .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_36:
    .loc 2 1250 5
    leaq -48(%rdi), %r8
    movslq %r8d, %r8
    jmp .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_34:
    cmpq $97, %rdi
    jb .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_33:
    cmpq $102, %rdi
    ja .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_32:
    .loc 2 1253 5
    leaq -87(%rdi), %r8
    movslq %r8d, %r8
    jmp .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_30:
    cmpq $65, %rdi
    jb .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_29:
    cmpq $70, %rdi
    ja .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_28:
    .loc 2 1256 5
    subq $55, %rdi
    movslq %edi, %rdi
    movq %rdi, %r8
    jmp .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_26:
    .loc 2 1258 3
    movq $-1, %r8
.Lssa_http____pct_byte_25:
    .loc 2 2176 3
    addl $2, %esi
    cmpq %r9, %rsi
    jb .Lssa_http____pct_byte_78
.Lssa_http____pct_byte_76:
    call __fern_oob_abort
.Lssa_http____pct_byte_78:
    movzbl (%r10,%rsi), %r9d
.Lssa_http____pct_byte_24:
    cmpq $48, %r9
    jb .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_23:
    cmpq $57, %r9
    ja .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_22:
    .loc 2 1250 5
    leaq -48(%r9), %rsi
    movslq %esi, %rsi
    jmp .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_20:
    cmpq $97, %r9
    jb .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_19:
    cmpq $102, %r9
    ja .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_18:
    .loc 2 1253 5
    leaq -87(%r9), %rsi
    movslq %esi, %rsi
    jmp .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_16:
    cmpq $65, %r9
    jb .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_15:
    cmpq $70, %r9
    ja .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_14:
    .loc 2 1256 5
    subq $55, %r9
    movslq %r9d, %r9
    movq %r9, %rsi
    jmp .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_12:
    .loc 2 1258 3
    movq $-1, %rsi
.Lssa_http____pct_byte_11:
    cmpq $0, %r8
    jl .Lssa_http____pct_byte_9
.Lssa_http____pct_byte_10:
    cmpq $0, %rsi
    jge .Lssa_http____pct_byte_7
.Lssa_http____pct_byte_9:
    .loc 2 2178 5
    movq $-1, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_7:
    .loc 2 2180 3
    shlq $4, %r8
    addq %rsi, %r8
    movslq %r8d, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____plain_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____plain_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rsi, %rbx
    movq %rdi, %r12
.Lssa_http____plain_path_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____plain_path_2
.Lssa_http____plain_path_1:
    leaq -2(%rax), %rsi
    movq 0(%rsi), %rdi
    movq 8(%rsi), %r8
    movq %rdi, %r13
    movq %r8, %r14
    jmp .Lssa_http____plain_path_3
.Lssa_http____plain_path_2:
    leaq 8(%rax), %r8
    cmpq $0, %rax
    je .Lssa_http____plain_path_5
.Lssa_http____plain_path_4:
    movq 0(%rax), %rdi
    jmp .Lssa_http____plain_path_6
.Lssa_http____plain_path_5:
    xorl %edi, %edi
.Lssa_http____plain_path_6:
    movq %r8, %r13
    movq %rdi, %r14
.Lssa_http____plain_path_3:
    .loc 2 2189 3 prologue_end
    leaq 1(%rbx), %rdi
.Lssa_http____plain_path_17:
    movq %rdi, %r15
    movq %rbx, %r8
.Lssa_http____plain_path_18:
    cmpq %r12, %r8
    jge .Lssa_http____plain_path_15
.Lssa_http____plain_path_34:
    movl %r8d, %edi
    cmpq %r14, %rdi
    jb .Lssa_http____plain_path_41
.Lssa_http____plain_path_39:
    call __fern_oob_abort
.Lssa_http____plain_path_41:
    movzbl (%r13,%rdi), %eax
    cmpq $47, %rax
    jne .Lssa_http____plain_path_26
.Lssa_http____plain_path_33:
    cmpq %rbx, %r8
    jle .Lssa_http____plain_path_20
.Lssa_http____plain_path_31:
    .loc 2 2207 3
    movq %r8, %rdi
    subq %r15, %rdi
    movslq %edi, %r9
    cmpq $1, %r9
    jl .Lssa_http____plain_path_27
.Lssa_http____plain_path_30:
    cmpq $2, %r9
    jg .Lssa_http____plain_path_27
.Lssa_http____plain_path_29:
    movl %r15d, %edi
    cmpq %r14, %rdi
    jb .Lssa_http____plain_path_60
.Lssa_http____plain_path_58:
    call __fern_oob_abort
.Lssa_http____plain_path_60:
    movzbl (%r13,%rdi), %esi
    cmpq $46, %rsi
    jne .Lssa_http____plain_path_27
.Lssa_http____plain_path_28:
    leal -1(%r8), %esi
    cmpq %r14, %rsi
    jb .Lssa_http____plain_path_67
.Lssa_http____plain_path_65:
    call __fern_oob_abort
.Lssa_http____plain_path_67:
    movzbl (%r13,%rsi), %edi
    cmpq $46, %rdi
    je .Lssa_http____plain_path_22
.Lssa_http____plain_path_27:
    .loc 2 2209 5
    xorl %r9d, %r9d
    jmp .Lssa_http____plain_path_22
.Lssa_http____plain_path_26:
    cmpq $37, %rax
    je .Lssa_http____plain_path_9
.Lssa_http____plain_path_25:
    movq %r8, -48(%rbp)
    movq %r9, -56(%rbp)
    call __fn_http____is_pchar.r
    movq -48(%rbp), %r8
    movq -56(%rbp), %r9
    testq %rax, %rax
    jz .Lssa_http____plain_path_9
.Lssa_http____plain_path_24:
    jmp .Lssa_http____plain_path_19
.Lssa_http____plain_path_23:
.Lssa_http____plain_path_22:
    cmpq $0, %r9
    jg .Lssa_http____plain_path_10
.Lssa_http____plain_path_20:
    .loc 2 2197 11
    leaq 1(%r8), %r9
    movq %r9, %r15
.Lssa_http____plain_path_19:
    .loc 2 2201 7
    addq $1, %r8
    cmpq %r12, %r8
    jl .Lssa_http____plain_path_34
.Lssa_http____plain_path_15:
    .loc 2 2207 3
    movq %r12, %r8
    subq %r15, %r8
    movslq %r8d, %r8
    cmpq $1, %r8
    jl .Lssa_http____plain_path_11
.Lssa_http____plain_path_14:
    cmpq $2, %r8
    jg .Lssa_http____plain_path_11
.Lssa_http____plain_path_13:
    movl %r15d, %r15d
    cmpq %r14, %r15
    jb .Lssa_http____plain_path_98
.Lssa_http____plain_path_96:
    call __fern_oob_abort
.Lssa_http____plain_path_98:
    movzbl (%r13,%r15), %r9d
    cmpq $46, %r9
    jne .Lssa_http____plain_path_11
.Lssa_http____plain_path_12:
    subl $1, %r12d
    cmpq %r14, %r12
    jb .Lssa_http____plain_path_105
.Lssa_http____plain_path_103:
    call __fern_oob_abort
.Lssa_http____plain_path_105:
    movzbl (%r13,%r12), %r9d
    cmpq $46, %r9
    je .Lssa_http____plain_path_7
.Lssa_http____plain_path_11:
    .loc 2 2209 5
    xorl %r8d, %r8d
    jmp .Lssa_http____plain_path_7
.Lssa_http____plain_path_10:
    .loc 2 2195 9
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____plain_path_9:
    .loc 2 2199 7
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____plain_path_8:
.Lssa_http____plain_path_7:
    .loc 2 2203 3
    movq %r8, %rax
    cmpq $0, %rax
    sete %al
    movzbq %al, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____decoded_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http____decoded_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $104, %rsp
    movq %rax, -48(%rbp)
    movq %rdi, -56(%rbp)
    movq %r8, -64(%rbp)
.Lssa_http____decoded_path_0:
    movq -48(%rbp), %rdi
    andq $2, %rdi
    testq %rdi, %rdi
    jz .Lssa_http____decoded_path_2
.Lssa_http____decoded_path_1:
    movq -48(%rbp), %rdi
    addq $-2, %rdi
    movq 0(%rdi), %r8
    movq 8(%rdi), %r9
    movq %r8, -72(%rbp)
    movq %r9, -80(%rbp)
    jmp .Lssa_http____decoded_path_3
.Lssa_http____decoded_path_2:
    movq -48(%rbp), %r9
    addq $8, %r9
    cmpq $0, -48(%rbp)
    je .Lssa_http____decoded_path_5
.Lssa_http____decoded_path_4:
    movq -48(%rbp), %r11
    movq 0(%r11), %r8
    jmp .Lssa_http____decoded_path_6
.Lssa_http____decoded_path_5:
    xorl %r8d, %r8d
.Lssa_http____decoded_path_6:
    movq %r9, -72(%rbp)
    movq %r8, -80(%rbp)
.Lssa_http____decoded_path_3:
    .loc 2 2215 3 prologue_end
    leaq .K2(%rip), %rdi
    .loc 2 2219 3
    addq $1, %rsi
    movslq %esi, %rsi
    .loc 2 2216 3
    .loc 2 2217 3
    .loc 2 2218 3
.Lssa_http____decoded_path_14:
    movq %rdi, %r13
    movq %rsi, %r8
    xorps %xmm2, %xmm2
    movups %xmm2, -96(%rbp)
    movq $0, -104(%rbp)
.Lssa_http____decoded_path_15:
    cmpq -56(%rbp), %r8
    jg .Lssa_http____decoded_path_13
.Lssa_http____decoded_path_47:
    .loc 2 2222 9
    movl $47, %r9d
.Lssa_http____decoded_path_46:
    movq 0(%r13), %rsi
    cmpq %rsi, -88(%rbp)
    jge .Lssa_http____decoded_path_43
.Lssa_http____decoded_path_45:
    .loc 2 2308 5
    testb $1, %r13b
    jnz .Lssa_http____decoded_path_uq45
    cmpq $0x10000, %r13
    jb .Lssa_http____decoded_path_uq45
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____decoded_path_uq45:
    jne .Lssa_http____decoded_path_57
.Lssa_http____decoded_path_56:
    jmp .Lssa_http____decoded_path_58
.Lssa_http____decoded_path_57:
    movq %r8, -112(%rbp)
    movq %r9, -120(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %r8
    movq -120(%rbp), %r9
    xorl %esi, %esi
    movq 0(%r13), %rdi
    movq %r8, -112(%rbp)
    movq %r9, -120(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_slice_u8.r
    movq -112(%rbp), %r8
    movq -120(%rbp), %r9
    movq %rax, %r13
.Lssa_http____decoded_path_58:
    .loc 2 2222 9
    movl $47, %edi
    .loc 2 2308 5
    movq -88(%rbp), %rcx
    cmpq (%r13), %rcx
    jae __fern_oob_abort
    movb %dil, 8(%r13,%rcx)
    movq %r13, %r10
    jmp .Lssa_http____decoded_path_42
.Lssa_http____decoded_path_43:
    .loc 2 2310 3
    testb $1, %r13b
    jnz .Lssa_http____decoded_path_uq43
    cmpq $0x10000, %r13
    jb .Lssa_http____decoded_path_uq43
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____decoded_path_uq43:
    jne .Lssa_http____decoded_path_61
.Lssa_http____decoded_path_60:
    movq %r13, %rdi
    movq %r9, %rsi
    movq %r8, -112(%rbp)
    movq %r9, -120(%rbp)
    call __fern_arr_push_owned_u8
    movq -112(%rbp), %r8
    movq -120(%rbp), %r9
    movq %rax, %rdi
    movq %rdi, %r10
    jmp .Lssa_http____decoded_path_42
.Lssa_http____decoded_path_61:
    movq %r13, %rdi
    movq %r9, %rsi
    movq %r8, -112(%rbp)
    call __fern_arr_push_u8
    movq -112(%rbp), %r8
    movq %rax, %r10
    movq %r8, -112(%rbp)
    movq %r10, -120(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %r8
    movq -120(%rbp), %r10
.Lssa_http____decoded_path_62:
.Lssa_http____decoded_path_42:
    .loc 2 2223 7
    movq -88(%rbp), %r9
    addq $1, %r9
    movslq %r9d, %r9
.Lssa_http____decoded_path_41:
    movq %r10, %r13
    movq %r9, %r15
    movq -104(%rbp), %rbx
    movq %r8, %r14
.Lssa_http____decoded_path_63:
    cmpq -56(%rbp), %r14
    jge .Lssa_http____decoded_path_40
.Lssa_http____decoded_path_80:
    movl %r14d, %r9d
    cmpq -80(%rbp), %r9
    jb .Lssa_http____decoded_path_87
.Lssa_http____decoded_path_85:
    call __fern_oob_abort
.Lssa_http____decoded_path_87:
    movq -72(%rbp), %r11
    movzbl (%r11,%r9), %r12d
    cmpq $47, %r12
    je .Lssa_http____decoded_path_40
.Lssa_http____decoded_path_79:
    .loc 2 2225 7
    movq -48(%rbp), %rax
    movq %r14, %rsi
    movq -56(%rbp), %rdi
    call __fn_http____path_byte.r
    movq %rax, %r9
    cmpq $0, %r9
    jge .Lssa_http____decoded_path_77
.Lssa_http____decoded_path_92:
    movq %r9, -112(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %r9
    jmp .Lssa_http____decoded_path_10
.Lssa_http____decoded_path_77:
    movl $1, %r10d
    movq %r9, %r8
    cmpq $128, %r8
    setge %r8b
    movzbq %r8b, %r8
    testq %rbx, %rbx
    movq %r10, %rbx
    cmoveq %r8, %rbx
    .loc 2 2230 11
    movq %r9, %r8
    andq $255, %r8
.Lssa_http____decoded_path_73:
    movq 0(%r13), %r9
    cmpq %r9, %r15
    jge .Lssa_http____decoded_path_70
.Lssa_http____decoded_path_72:
    .loc 2 2308 5
    testb $1, %r13b
    jnz .Lssa_http____decoded_path_uq72
    cmpq $0x10000, %r13
    jb .Lssa_http____decoded_path_uq72
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____decoded_path_uq72:
    jne .Lssa_http____decoded_path_106
.Lssa_http____decoded_path_105:
    jmp .Lssa_http____decoded_path_107
.Lssa_http____decoded_path_106:
    movq %r8, -112(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %r8
    xorl %r9d, %r9d
    movq 0(%r13), %r10
    movq %r8, -112(%rbp)
    movq %r13, %rax
    movq %r9, %rsi
    movq %r10, %rdi
    call __fn___fern_arr_slice_u8.r
    movq -112(%rbp), %r8
    movq %rax, %r13
.Lssa_http____decoded_path_107:
    cmpq (%r13), %r15
    jae __fern_oob_abort
    movb %r8b, 8(%r13,%r15)
    jmp .Lssa_http____decoded_path_69
.Lssa_http____decoded_path_70:
    .loc 2 2310 3
    testb $1, %r13b
    jnz .Lssa_http____decoded_path_uq70
    cmpq $0x10000, %r13
    jb .Lssa_http____decoded_path_uq70
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____decoded_path_uq70:
    jne .Lssa_http____decoded_path_110
.Lssa_http____decoded_path_109:
    movq %r13, %rdi
    movq %r8, %rsi
    movq %r8, -112(%rbp)
    call __fern_arr_push_owned_u8
    movq -112(%rbp), %r8
    movq %rax, %r10
    jmp .Lssa_http____decoded_path_111
.Lssa_http____decoded_path_110:
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_arr_push_u8
    movq %rax, %r10
    movq %r10, -112(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -112(%rbp), %r10
.Lssa_http____decoded_path_111:
    movq %r10, %r13
.Lssa_http____decoded_path_69:
    .loc 2 2231 9
    leaq 1(%r15), %r10
    movslq %r10d, %r15
.Lssa_http____decoded_path_68:
    .loc 2 2266 5
    movl $3, %r10d
    .loc 2 2268 3
    movl $1, %r8d
    cmpq $37, %r12
    cmovneq %r8, %r10
    .loc 2 2232 10
    addq %r14, %r10
    movslq %r10d, %r14
    cmpq -56(%rbp), %r14
    jl .Lssa_http____decoded_path_80
.Lssa_http____decoded_path_40:
    .loc 2 2234 14
    movq %r14, %r12
    cmpq -56(%rbp), %r12
    sete %r12b
    movzbq %r12b, %r12
    movq %r13, %r10
    andq $2, %r10
    testq %r10, %r10
    jz .Lssa_http____decoded_path_120
.Lssa_http____decoded_path_119:
    leaq -2(%r13), %r10
    movq 0(%r10), %r8
    movq 8(%r10), %r9
    xchgq %r8, %r9
    jmp .Lssa_http____decoded_path_121
.Lssa_http____decoded_path_120:
    leaq 8(%r13), %r9
    cmpq $0, %r13
    je .Lssa_http____decoded_path_123
.Lssa_http____decoded_path_122:
    movq 0(%r13), %r8
    jmp .Lssa_http____decoded_path_121
.Lssa_http____decoded_path_123:
    xorl %r8d, %r8d
.Lssa_http____decoded_path_124:
.Lssa_http____decoded_path_121:
    .loc 2 2235 5
    movq -88(%rbp), %r10
    addq $1, %r10
.Lssa_http____decoded_path_39:
    .loc 2 2207 3
    movq %r15, %rdi
    subq %r10, %rdi
    movslq %edi, %rdi
    cmpq $1, %rdi
    jl .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_38:
    cmpq $2, %rdi
    jg .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_37:
    movl %r10d, %r10d
    cmpq %r8, %r10
    jb .Lssa_http____decoded_path_135
.Lssa_http____decoded_path_133:
    call __fern_oob_abort
.Lssa_http____decoded_path_135:
    movzbl (%r9,%r10), %esi
    cmpq $46, %rsi
    jne .Lssa_http____decoded_path_35
.Lssa_http____decoded_path_36:
    leal -1(%r15), %esi
    cmpq %r8, %rsi
    jb .Lssa_http____decoded_path_142
.Lssa_http____decoded_path_140:
    call __fern_oob_abort
.Lssa_http____decoded_path_142:
    movzbl (%r9,%rsi), %r8d
    cmpq $46, %r8
    je .Lssa_http____decoded_path_33
.Lssa_http____decoded_path_35:
    .loc 2 2209 5
    xorl %edi, %edi
.Lssa_http____decoded_path_34:
.Lssa_http____decoded_path_33:
    cmpq $0, %rdi
    jne .Lssa_http____decoded_path_30
.Lssa_http____decoded_path_32:
    .loc 2 2237 16
    movq %r15, -88(%rbp)
    movq $0, -96(%rbp)
    jmp .Lssa_http____decoded_path_16
.Lssa_http____decoded_path_30:
    cmpq $1, %rdi
    jne .Lssa_http____decoded_path_27
.Lssa_http____decoded_path_29:
    jmp .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_27:
    cmpq $0, -88(%rbp)
    jne .Lssa_http____decoded_path_24
.Lssa_http____decoded_path_26:
    .loc 2 2276 5
    movq $-1, -88(%rbp)
    jmp .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_24:
    .loc 2 2278 3
    movq -88(%rbp), %rdi
    subq $1, %rdi
    movslq %edi, %rdi
.Lssa_http____decoded_path_23:
    movq %rdi, %r15
.Lssa_http____decoded_path_163:
    cmpq (%r13), %r15
    jae __fern_oob_abort
    movzbl 8(%r13,%r15), %edi
    cmpq $47, %rdi
    je .Lssa_http____decoded_path_22
.Lssa_http____decoded_path_164:
    .loc 2 2280 10
    leaq -1(%r15), %rdi
    movslq %edi, %r15
    jmp .Lssa_http____decoded_path_163
.Lssa_http____decoded_path_22:
    testq %rbx, %rbx
    jz .Lssa_http____decoded_path_20
.Lssa_http____decoded_path_21:
    .loc 2 713 5
    movq %r13, %rax
    movq %r15, %rsi
    movq -88(%rbp), %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r8
    movq %r8, -112(%rbp)
    movq %r8, %rax
    call __fn_utf8__is_valid.r
    movq %rax, %r9
    movq -112(%rbp), %r8
    movq %r9, -112(%rbp)
    movq %r8, %rax
    call __fn___fern_str_free.r
    movq -112(%rbp), %r9
    testq %r9, %r9
    jz .Lssa_http____decoded_path_19
.Lssa_http____decoded_path_20:
    movq %r15, -88(%rbp)
    jmp .Lssa_http____decoded_path_18
.Lssa_http____decoded_path_19:
    .loc 2 2283 5
    movq $-1, -88(%rbp)
.Lssa_http____decoded_path_18:
    cmpq $0, -88(%rbp)
    jge .Lssa_http____decoded_path_17
.Lssa_http____decoded_path_180:
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_http____decoded_path_9
.Lssa_http____decoded_path_17:
    movq %r12, -96(%rbp)
.Lssa_http____decoded_path_16:
    .loc 2 2244 8
    addq $1, %r14
    movslq %r14d, %r8
    movq %rbx, -104(%rbp)
    cmpq -56(%rbp), %r8
    jle .Lssa_http____decoded_path_47
.Lssa_http____decoded_path_13:
    pushq -64(%rbp)
    pushq -56(%rbp)
    pushq -48(%rbp)
    pushq -104(%rbp)
    pushq -96(%rbp)
    pushq -88(%rbp)
    pushq %r13
    call __fn_http____finished_path
    addq $56, %rsp
    movq %rax, %r14
    movq %rdx, %rbx
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    cmpq $0, %r14
    jne .Lssa_http____decoded_path_7
.Lssa_http____decoded_path_11:
    movq %rbx, %rdx
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_10:
    .loc 2 2227 9
    movl $400, %r8d
    movq %r8, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_9:
    .loc 2 2241 9
    movl $400, %r8d
    movq %r8, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____decoded_path_7:
    movq %rbx, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____path_byte:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_http____path_byte.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
.Lssa_http____path_byte_0:
    movq %rax, %r8
    andq $2, %r8
    testq %r8, %r8
    jz .Lssa_http____path_byte_2
.Lssa_http____path_byte_1:
    leaq -2(%rax), %r8
    movq 0(%r8), %r9
    movq 8(%r8), %r10
    xchgq %r9, %r10
    jmp .Lssa_http____path_byte_3
.Lssa_http____path_byte_2:
    leaq 8(%rax), %r10
    cmpq $0, %rax
    je .Lssa_http____path_byte_5
.Lssa_http____path_byte_4:
    movq 0(%rax), %r9
    jmp .Lssa_http____path_byte_3
.Lssa_http____path_byte_5:
    xorl %r9d, %r9d
.Lssa_http____path_byte_6:
.Lssa_http____path_byte_3:
    movl %esi, %r8d
    cmpq %r9, %r8
    jb .Lssa_http____path_byte_19
.Lssa_http____path_byte_17:
    call __fern_oob_abort
.Lssa_http____path_byte_19:
    movzbl (%r10,%r8), %ebx
    cmpq $37, %rbx
    jne .Lssa_http____path_byte_9
.Lssa_http____path_byte_16:
    .loc 2 2252 7 prologue_end
    call __fn_http____pct_byte.r
    cmpq $0, %rax
    jle .Lssa_http____path_byte_12
.Lssa_http____path_byte_15:
    cmpq $47, %rax
    je .Lssa_http____path_byte_12
.Lssa_http____path_byte_14:
    cmpq $63, %rax
    je .Lssa_http____path_byte_12
.Lssa_http____path_byte_13:
    cmpq $35, %rax
    jne .Lssa_http____path_byte_11
.Lssa_http____path_byte_12:
    .loc 2 2254 7
    movq $-1, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____path_byte_11:
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____path_byte_9:
    movq %rbx, %rax
    call __fn_http____is_pchar.r
    testq %rax, %rax
    jz .Lssa_http____path_byte_7
.Lssa_http____path_byte_8:
    movq %rbx, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____path_byte_7:
    .loc 2 2259 5
    movq $-1, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____finished_path:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
    movq 48(%rsp), %r10
__fn_http____finished_path.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $56, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %r8, -48(%rbp)
    movq %r10, -56(%rbp)
    movq 64(%rbp), %r15
.Lssa_http____finished_path_0:
    movq %r9, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa_http____finished_path_2
.Lssa_http____finished_path_1:
    leaq -2(%r9), %rsi
    movq 0(%rsi), %r8
    movq 8(%rsi), %r10
    movq %r8, %r13
    movq %r10, %r14
    jmp .Lssa_http____finished_path_3
.Lssa_http____finished_path_2:
    leaq 8(%r9), %r10
    cmpq $0, %r9
    je .Lssa_http____finished_path_5
.Lssa_http____finished_path_4:
    movq 0(%r9), %r8
    jmp .Lssa_http____finished_path_6
.Lssa_http____finished_path_5:
    xorl %r8d, %r8d
.Lssa_http____finished_path_6:
    movq %r10, %r13
    movq %r8, %r14
.Lssa_http____finished_path_3:
    cmpq $0, %r12
    je .Lssa_http____finished_path_20
.Lssa_http____finished_path_21:
    testq %rdi, %rdi
    jz .Lssa_http____finished_path_17
.Lssa_http____finished_path_20:
    .loc 2 2290 9 prologue_end
    movl $47, %esi
.Lssa_http____finished_path_19:
    movq 0(%rbx), %rdi
    cmpq %rdi, %r12
    jge .Lssa_http____finished_path_15
.Lssa_http____finished_path_18:
    .loc 2 2308 5
    testb $1, %bl
    jnz .Lssa_http____finished_path_uq18
    cmpq $0x10000, %rbx
    jb .Lssa_http____finished_path_uq18
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____finished_path_uq18:
    jne .Lssa_http____finished_path_35
.Lssa_http____finished_path_34:
    movq %rbx, %rax
    jmp .Lssa_http____finished_path_36
.Lssa_http____finished_path_35:
    xorl %edi, %edi
    movq 0(%rbx), %r8
    movq %rbx, %rax
    movq %rdi, %rsi
    movq %r8, %rdi
    call __fn___fern_arr_slice_u8.r
.Lssa_http____finished_path_36:
    .loc 2 2290 9
    movl $47, %r8d
    .loc 2 2308 5
    cmpq (%rax), %r12
    jae __fern_oob_abort
    movb %r8b, 8(%rax,%r12)
    movq %rax, %rdi
    jmp .Lssa_http____finished_path_14
.Lssa_http____finished_path_17:
    movq %rbx, %rdi
    jmp .Lssa_http____finished_path_12
.Lssa_http____finished_path_15:
    .loc 2 2310 3
    movq %rbx, %rdi
    call __fern_arr_push_u8
    movq %rax, %rdi
.Lssa_http____finished_path_14:
    .loc 2 2291 7
    addq $1, %r12
    movslq %r12d, %r12
.Lssa_http____finished_path_13:
.Lssa_http____finished_path_12:
    movq %r12, %r8
    movq -56(%rbp), %r10
    movq %rdi, %r12
.Lssa_http____finished_path_39:
    cmpq %r15, %r10
    jge .Lssa_http____finished_path_11
.Lssa_http____finished_path_45:
    movl %r10d, %edi
    cmpq %r14, %rdi
    jb .Lssa_http____finished_path_52
.Lssa_http____finished_path_50:
    call __fern_oob_abort
.Lssa_http____finished_path_52:
    movzbl (%r13,%rdi), %r9d
.Lssa_http____finished_path_44:
    movq 0(%r12), %rdi
    cmpq %rdi, %r8
    jge .Lssa_http____finished_path_41
.Lssa_http____finished_path_43:
    .loc 2 2308 5
    cmpq %rbx, %r12
    jne .Lssa_http____finished_path_58
.Lssa_http____finished_path_57:
    testb $1, %r12b
    jnz .Lssa_http____finished_path_uq57
    cmpq $0x10000, %r12
    jb .Lssa_http____finished_path_uq57
    movl -8(%r12), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____finished_path_uq57:
    jne .Lssa_http____finished_path_61
.Lssa_http____finished_path_60:
    jmp .Lssa_http____finished_path_62
.Lssa_http____finished_path_61:
    xorl %edi, %edi
    movq 0(%r12), %rsi
    movq %r8, -64(%rbp)
    movq %r9, -72(%rbp)
    movq %r10, -80(%rbp)
    movq %r12, %rax
    xchgq %rdi, %rsi
    call __fn___fern_arr_slice_u8.r
    movq -64(%rbp), %r8
    movq -72(%rbp), %r9
    movq -80(%rbp), %r10
    movq %rax, %r12
.Lssa_http____finished_path_62:
    movq %r12, %rdi
    jmp .Lssa_http____finished_path_59
.Lssa_http____finished_path_58:
    testb $1, %r12b
    jnz .Lssa_http____finished_path_uq58
    cmpq $0x10000, %r12
    jb .Lssa_http____finished_path_uq58
    movl -8(%r12), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http____finished_path_uq58:
    jne .Lssa_http____finished_path_64
.Lssa_http____finished_path_63:
    jmp .Lssa_http____finished_path_65
.Lssa_http____finished_path_64:
    movq %r8, -64(%rbp)
    movq %r9, -72(%rbp)
    movq %r10, -80(%rbp)
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq -64(%rbp), %r8
    movq -72(%rbp), %r9
    movq -80(%rbp), %r10
    xorl %esi, %esi
    movq 0(%r12), %rdi
    movq %r8, -64(%rbp)
    movq %r9, -72(%rbp)
    movq %r10, -80(%rbp)
    movq %r12, %rax
    call __fn___fern_arr_slice_u8.r
    movq -64(%rbp), %r8
    movq -72(%rbp), %r9
    movq -80(%rbp), %r10
    movq %rax, %r12
.Lssa_http____finished_path_65:
    movq %r12, %rdi
.Lssa_http____finished_path_59:
    cmpq (%rdi), %r8
    jae __fern_oob_abort
    movb %r9b, 8(%rdi,%r8)
    movq %rdi, %r12
    jmp .Lssa_http____finished_path_40
.Lssa_http____finished_path_41:
    .loc 2 2310 3
    cmpq %rbx, %r12
    jne .Lssa_http____finished_path_68
.Lssa_http____finished_path_67:
    movq %r12, %rdi
    movq %r9, %rsi
    movq %r8, -64(%rbp)
    movq %r9, -72(%rbp)
    movq %r10, -80(%rbp)
    call __fern_arr_push_u8
    movq -64(%rbp), %r8
    movq -72(%rbp), %r9
    movq -80(%rbp), %r10
    jmp .Lssa_http____finished_path_69
.Lssa_http____finished_path_68:
    movq %r12, %rdi
    movq %r9, %rsi
    movq %r8, -64(%rbp)
    movq %r10, -72(%rbp)
    call __fern_arr_push_owned_u8
    movq -64(%rbp), %r8
    movq -72(%rbp), %r10
.Lssa_http____finished_path_69:
    movq %rax, %r12
.Lssa_http____finished_path_40:
    .loc 2 2296 7
    leaq 1(%r8), %r9
    movslq %r9d, %r8
    .loc 2 2297 7
    addq $1, %r10
    cmpq %r15, %r10
    jl .Lssa_http____finished_path_45
.Lssa_http____finished_path_11:
    .loc 2 2299 3
    xorl %r10d, %r10d
    .loc 2 713 5
    movq %r12, %rax
    movq %r10, %rsi
    movq %r8, %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r14
    cmpq %rbx, %r12
    je .Lssa_http____finished_path_74
.Lssa_http____finished_path_72:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
.Lssa_http____finished_path_74:
    movq -48(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http____finished_path_8
.Lssa_http____finished_path_10:
    movq %r14, %rax
    call __fn_utf8__is_valid.r
    testq %rax, %rax
    jnz .Lssa_http____finished_path_8
.Lssa_http____finished_path_80:
    movq %r14, %rax
    call __fn___fern_str_free.r
    jmp .Lssa_http____finished_path_7
.Lssa_http____finished_path_8:
    movq %r14, %rdx
    .loc 2 2303 3
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____finished_path_7:
    .loc 2 2301 5
    movl $400, %r10d
    movq %r10, %rdx
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http__serialize_response_to:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn_http__serialize_response_to.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $88, %rsp
    movq %rax, -48(%rbp)
    movq %rsi, -56(%rbp)
    movq %r8, -64(%rbp)
.Lssa_http__serialize_response_to_0:
    testb $1, %dil
    jnz .Lssa_http__serialize_response_to_rcinc283
    cmpq $0x10000, %rdi
    jb .Lssa_http__serialize_response_to_rcinc283
    movl -8(%rdi), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http__serialize_response_to_rcinc283
    addl $1, %ecx
    movl %ecx, -8(%rdi)
.Lssa_http__serialize_response_to_rcinc283:
.Lssa_http__serialize_response_to_59:
    movq %rdi, %r14
.Lssa_http__serialize_response_to_60:
    movq 24(%r14), %rax
    call __fn_http__fields_ok.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_62
.Lssa_http__serialize_response_to_64:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_http__serialize_response_to_61
.Lssa_http__serialize_response_to_62:
    movq 32(%r14), %r15
    xorl %ecx, %ecx
    testb $1, %r14b
    jnz .Lssa_http__serialize_response_to_rcuniq296
    cmpq $0x10000, %r14
    jb .Lssa_http__serialize_response_to_rcuniq296
    movl -8(%r14), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
    jne .Lssa_http__serialize_response_to_rcuniq296
    movl $1, %ecx
.Lssa_http__serialize_response_to_rcuniq296:
    movq %rcx, %rax
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_69
.Lssa_http__serialize_response_to_67:
    xorl %edi, %edi
    movq %rdi, 32(%r14)
.Lssa_http__serialize_response_to_69:
    cmpq $0, %rax
    jne .Lssa_http__serialize_response_to_72
.Lssa_http__serialize_response_to_70:
    testb $1, %r15b
    jnz .Lssa_http__serialize_response_to_rcinc301
    cmpq $0x10000, %r15
    jb .Lssa_http__serialize_response_to_rcinc301
    movl -8(%r15), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http__serialize_response_to_rcinc301
    addl $1, %ecx
    movl %ecx, -8(%r15)
.Lssa_http__serialize_response_to_rcinc301:
.Lssa_http__serialize_response_to_72:
    movq %r15, %rax
    call __fn_http__fields_ok.r
    movq %rax, %r8
    movq %r8, -104(%rbp)
    movq %r15, %rax
    call __fn___sem_release_HeaderMap.r
    movq -104(%rbp), %r8
    testq %r8, %r8
    jnz .Lssa_http__serialize_response_to_57
.Lssa_http__serialize_response_to_74:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
.Lssa_http__serialize_response_to_61:
    .loc 2 271 3 prologue_end
    leaq .K5(%rip), %r14
    jmp .Lssa_http__serialize_response_to_60
.Lssa_http__serialize_response_to_57:
    .loc 2 2413 3
    movq 8(%r14), %r11
    movq %r11, -72(%rbp)
.Lssa_http__serialize_response_to_56:
    .loc 2 2487 3
    cmpq $200, -72(%rbp)
    jl .Lssa_http__serialize_response_to_52
.Lssa_http__serialize_response_to_54:
    cmpq $204, -72(%rbp)
    jne .Lssa_http__serialize_response_to_51
.Lssa_http__serialize_response_to_52:
    movq $1, -80(%rbp)
    jmp .Lssa_http__serialize_response_to_49
.Lssa_http__serialize_response_to_51:
    movq -72(%rbp), %r8
    cmpq $304, %r8
    sete %r8b
    movzbq %r8b, %r8
    movq %r8, -80(%rbp)
.Lssa_http__serialize_response_to_50:
.Lssa_http__serialize_response_to_49:
    .loc 2 2414 3
    leaq .SB6(%rip), %r8
    .loc 2 2415 3
    leaq .SB6(%rip), %rsi
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http__serialize_response_to_46
.Lssa_http__serialize_response_to_48:
    movq %r8, -96(%rbp)
    movq %rsi, -88(%rbp)
    jmp .Lssa_http__serialize_response_to_43
.Lssa_http__serialize_response_to_46:
    .loc 2 2725 10
    movq 16(%r14), %rbx
    xorl %ecx, %ecx
    testb $1, %r14b
    jnz .Lssa_http__serialize_response_to_rcuniq331
    cmpq $0x10000, %r14
    jb .Lssa_http__serialize_response_to_rcuniq331
    movl -8(%r14), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
    jne .Lssa_http__serialize_response_to_rcuniq331
    movl $1, %ecx
.Lssa_http__serialize_response_to_rcuniq331:
    movq %rcx, %rax
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_96
.Lssa_http__serialize_response_to_94:
    xorl %esi, %esi
    movq %rsi, 16(%r14)
.Lssa_http__serialize_response_to_96:
    cmpq $0, %rax
    jne .Lssa_http__serialize_response_to_99
.Lssa_http__serialize_response_to_97:
    testb $1, %bl
    jnz .Lssa_http__serialize_response_to_rcinc336
    cmpq $0x10000, %rbx
    jb .Lssa_http__serialize_response_to_rcinc336
    movl -8(%rbx), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http__serialize_response_to_rcinc336
    addl $1, %ecx
    movl %ecx, -8(%rbx)
.Lssa_http__serialize_response_to_rcinc336:
.Lssa_http__serialize_response_to_99:
    movq 0(%rbx), %r8
    cmpq $.S4, %r8
    je .Lssa_http__serialize_response_to_45
.Lssa_http__serialize_response_to_101:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
    movq %rbx, %rax
    call __fn___sem_release_Body.r
    jmp .Lssa_http__serialize_response_to_1
.Lssa_http__serialize_response_to_45:
    testb $1, %bl
    jnz .Lssa_http__serialize_response_to_uq45
    cmpq $0x10000, %rbx
    jb .Lssa_http__serialize_response_to_uq45
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_http__serialize_response_to_uq45:
    jne .Lssa_http__serialize_response_to_105
.Lssa_http__serialize_response_to_104:
    movq %rbx, %r8
    jmp .Lssa_http__serialize_response_to_106
.Lssa_http__serialize_response_to_105:
    xorl %r8d, %r8d
.Lssa_http__serialize_response_to_106:
    .loc 2 2417 10
    movq 8(%rbx), %r11
    movq %r11, -88(%rbp)
    cmpq $0, %r8
    jne .Lssa_http__serialize_response_to_109
.Lssa_http__serialize_response_to_107:
    movq -88(%rbp), %r11
    testb $1, %r11b
    jnz .Lssa_http__serialize_response_to_rcinc348
    cmpq $0x10000, %r11
    jb .Lssa_http__serialize_response_to_rcinc348
    movl -8(%r11), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http__serialize_response_to_rcinc348
    addl $1, %ecx
    movl %ecx, -8(%r11)
.Lssa_http__serialize_response_to_rcinc348:
.Lssa_http__serialize_response_to_109:
    cmpq $0, %r8
    je .Lssa_http__serialize_response_to_111
.Lssa_http__serialize_response_to_110:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_http__serialize_response_to_44
.Lssa_http__serialize_response_to_111:
    movq %rbx, %rax
    call __fn___sem_release_Body.r
.Lssa_http__serialize_response_to_44:
    .loc 2 2418 13
    leaq .SB7(%rip), %rbx
    movq -88(%rbp), %r11
    movq 8(%r11), %rax
    .loc 14 147 5
    call __fn_int__int_to_string.r
    movq %rax, %r13
    .loc 2 2418 13
    movq %rbx, %rax
    movq %r13, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r12
    movq %r13, %rax
    call __fn___fern_str_free.r
    leaq .SB8(%rip), %r13
    pushq %r12
    pushq %r13
    call __fn___fern_str_grow
    addq $16, %rsp
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_114
.Lssa_http__serialize_response_to_113:
    movq %r12, %rbx
    jmp .Lssa_http__serialize_response_to_115
.Lssa_http__serialize_response_to_114:
    pushq %r12
    pushq %r13
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %rbx
    movq %r12, %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_115:
    movq %rbx, -96(%rbp)
.Lssa_http__serialize_response_to_43:
    .loc 2 2420 3
    movl $256, %r8d
    movq %r8, %rdi
    call __fern_buf_new
    movq %rax, %r13
.Lssa_http__serialize_response_to_41:
    leaq .SB9(%rip), %r8
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push
    movq -72(%rbp), %r12
    movslq %r12d, %r12
.Lssa_http__serialize_response_to_40:
    cmpq $0, %r12
    jge .Lssa_http__serialize_response_to_37
.Lssa_http__serialize_response_to_39:
    movl $45, %r8d
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push_byte
    xorl %r8d, %r8d
    subq %r12, %r8
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push_decimal
    jmp .Lssa_http__serialize_response_to_36
.Lssa_http__serialize_response_to_37:
    movq %r13, %rdi
    movq %r12, %rsi
    call __fern_buf_push_decimal
.Lssa_http__serialize_response_to_36:
    leaq .SB10(%rip), %r8
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push
.Lssa_http__serialize_response_to_34:
    leaq .K6(%rip), %r8
    leaq .K7(%rip), %rsi
.Lssa_http__serialize_response_to_33:
    xorl %edi, %edi
.Lssa_http__serialize_response_to_121:
    movq 0(%r8), %r9
    cmpq %r9, %rdi
    jge .Lssa_http__serialize_response_to_32
.Lssa_http__serialize_response_to_124:
    movq 8(%r8,%rdi,8), %r9
    cmpq -72(%rbp), %r9
    je .Lssa_http__serialize_response_to_31
.Lssa_http__serialize_response_to_122:
    addq $1, %rdi
    jmp .Lssa_http__serialize_response_to_121
.Lssa_http__serialize_response_to_32:
    leaq .SB6(%rip), %r8
    jmp .Lssa_http__serialize_response_to_30
.Lssa_http__serialize_response_to_31:
    cmpq (%rsi), %rdi
    jae __fern_oob_abort
    movq 8(%rsi,%rdi,8), %r8
    testb $1, %r8b
    jnz .Lssa_http__serialize_response_to_rcinc401
    cmpq $0x10000, %r8
    jb .Lssa_http__serialize_response_to_rcinc401
    movl -8(%r8), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_http__serialize_response_to_rcinc401
    addl $1, %ecx
    movl %ecx, -8(%r8)
.Lssa_http__serialize_response_to_rcinc401:
.Lssa_http__serialize_response_to_30:
    movq 8(%r8), %rdi
    cmpq $0, %rdi
    jne .Lssa_http__serialize_response_to_28
.Lssa_http__serialize_response_to_136:
    movq %r8, %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_29:
    leaq .SB61(%rip), %rdi
    movq %rdi, %r12
    jmp .Lssa_http__serialize_response_to_27
.Lssa_http__serialize_response_to_28:
    movq %r8, %r12
.Lssa_http__serialize_response_to_27:
    movq %r13, %rdi
    movq %r12, %rsi
    call __fern_buf_push
    movq %r12, %rax
    call __fn___fern_str_free.r
    leaq .SB8(%rip), %rdi
    movq %rdi, %rsi
    movq %r13, %rdi
    call __fern_buf_push
.Lssa_http__serialize_response_to_26:
    xorl %r12d, %r12d
.Lssa_http__serialize_response_to_141:
    movq 24(%r14), %rdi
    movq 8(%rdi), %r8
    movq 0(%r8), %rdi
    cmpq %rdi, %r12
    jl .Lssa_http__serialize_response_to_147
.Lssa_http__serialize_response_to_149:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_http__serialize_response_to_24
.Lssa_http__serialize_response_to_147:
    movq 24(%r14), %rbx
    movq 8(%rbx), %rdi
    movq 8(%rdi,%r12,8), %r15
    leaq .SB62(%rip), %rsi
    movq %r15, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_142
.Lssa_http__serialize_response_to_146:
    leaq .SB63(%rip), %rsi
    movq %r15, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_142
.Lssa_http__serialize_response_to_145:
    leaq .SB64(%rip), %rsi
    movq %r15, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_http__serialize_response_to_142
.Lssa_http__serialize_response_to_143:
    movq 8(%rbx), %rsi
    movq 8(%rsi,%r12,8), %rdi
    movq %rdi, %rsi
    movq %r13, %rdi
    call __fern_buf_push
    leaq .SB65(%rip), %rdi
    movq %rdi, %rsi
    movq %r13, %rdi
    call __fern_buf_push
    movq 16(%rbx), %rdi
    cmpq (%rdi), %r12
    jae __fern_oob_abort
    movq 8(%rdi,%r12,8), %rsi
    movq %r13, %rdi
    call __fern_buf_push
    leaq .SB8(%rip), %rsi
    movq %r13, %rdi
    call __fern_buf_push
.Lssa_http__serialize_response_to_142:
    addq $1, %r12
    jmp .Lssa_http__serialize_response_to_141
.Lssa_http__serialize_response_to_24:
    movq %r13, %rdi
    movq -96(%rbp), %rsi
    call __fern_buf_push
    movq -96(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_23:
    cmpq $101, -72(%rbp)
    jne .Lssa_http__serialize_response_to_19
.Lssa_http__serialize_response_to_22:
    leaq .SB66(%rip), %rsi
    movq %r13, %rdi
    call __fern_buf_push
    jmp .Lssa_http__serialize_response_to_6
.Lssa_http__serialize_response_to_19:
    movq -64(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http__serialize_response_to_14
.Lssa_http__serialize_response_to_16:
    movq -56(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_http__serialize_response_to_9
.Lssa_http__serialize_response_to_15:
    movq -56(%rbp), %r11
    movq 0(%r11), %rsi
    movzbl 7(%rsi), %edi
    cmpq $48, %rdi
    jne .Lssa_http__serialize_response_to_9
    jmp .Lssa_http__serialize_response_to_11
.Lssa_http__serialize_response_to_14:
    leaq .SB67(%rip), %rdi
    movq %rdi, %rsi
    movq %r13, %rdi
    call __fern_buf_push
    jmp .Lssa_http__serialize_response_to_6
.Lssa_http__serialize_response_to_11:
    leaq .SB68(%rip), %rdi
    movq %rdi, %rsi
    movq %r13, %rdi
    call __fern_buf_push
    jmp .Lssa_http__serialize_response_to_6
.Lssa_http__serialize_response_to_9:
    leaq .SB8(%rip), %rdi
    movq %rdi, %rsi
    movq %r13, %rdi
    call __fern_buf_push
.Lssa_http__serialize_response_to_6:
    .loc 2 2422 3
    movq %r13, %rdi
    call __fern_buf_take
    movq %rax, %r12
    movq %r13, %rdi
    call __fern_buf_free
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_http__serialize_response_to_5
.Lssa_http__serialize_response_to_187:
    movq -88(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_http__serialize_response_to_4
.Lssa_http__serialize_response_to_5:
    leaq .SB69(%rip), %rdi
    movq -48(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $4, %rsi
    jne .Lssa_http__serialize_response_to_2
.Lssa_http__serialize_response_to_191:
    movq -48(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_http__serialize_response_to_streqn492
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_http__serialize_response_to_streqn492
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_http__serialize_response_to_streqd492
.Lssa_http__serialize_response_to_streqn492:
    xorl %eax, %eax
.Lssa_http__serialize_response_to_streqd492:
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_2
.Lssa_http__serialize_response_to_194:
    movq -88(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_4:
    .loc 2 2425 5
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http__serialize_response_to_2:
    .loc 2 2427 3
    pushq %r12
    pushq -88(%rbp)
    call __fn___fern_str_grow
    addq $16, %rsp
    testq %rax, %rax
    jz .Lssa_http__serialize_response_to_199
.Lssa_http__serialize_response_to_198:
    movq %r12, %r13
    jmp .Lssa_http__serialize_response_to_200
.Lssa_http__serialize_response_to_199:
    pushq %r12
    pushq -88(%rbp)
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %r13
    movq %r12, %rax
    call __fn___fern_str_free.r
.Lssa_http__serialize_response_to_200:
    movq -88(%rbp), %rax
    call __fn___fern_str_free.r
    movq %r13, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http__serialize_response_to_1:
    movl $134, %edi
    movq %rdi, %r11
    pushq %r11
    call __fern_lc_report_exit
    popq %r11
    movq %r11, %rdi
    movq $231, %rax
    syscall
    xorl %eax, %eax
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_HttpResponse__body_text_lossy:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_HttpResponse__body_text_lossy.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_HttpResponse__body_text_lossy_0:
    .loc 2 2725 10 prologue_end
    movq 16(%rax), %rsi
    movq 0(%rsi), %rdi
    cmpq $.S4, %rdi
    jne .Lssa_HttpResponse__body_text_lossy_1
.Lssa_HttpResponse__body_text_lossy_2:
    movq 8(%rsi), %rax
    testb $1, %al
    jnz .Lssa_HttpResponse__body_text_lossy_rcinc12
    cmpq $0x10000, %rax
    jb .Lssa_HttpResponse__body_text_lossy_rcinc12
    movl -8(%rax), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_HttpResponse__body_text_lossy_rcinc12
    addl $1, %ecx
    movl %ecx, -8(%rax)
.Lssa_HttpResponse__body_text_lossy_rcinc12:
    .loc 2 2726 5
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_HttpResponse__body_text_lossy_1:
    movl $134, %esi
    movq %rsi, %r11
    pushq %r11
    call __fern_lc_report_exit
    popq %r11
    movq %r11, %rdi
    movq $231, %rax
    syscall
    xorl %eax, %eax
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http____lists_token:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_http____lists_token.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_http____lists_token_0:
    .loc 2 3234 3 prologue_end
    movq 8(%rbx), %r13
    .loc 2 3233 3
.Lssa_http____lists_token_3:
    xorl %esi, %esi
.Lssa_http____lists_token_4:
    cmpq %r13, %rsi
    jg .Lssa_http____lists_token_2
.Lssa_http____lists_token_8:
    movq %rsi, %r14
.Lssa_http____lists_token_14:
    cmpq %r13, %r14
    jge .Lssa_http____lists_token_7
.Lssa_http____lists_token_16:
    cmpq 8(%rbx), %r14
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r14), %edi
    cmpq $44, %rdi
    je .Lssa_http____lists_token_7
.Lssa_http____lists_token_15:
    .loc 2 3238 11
    addq $1, %r14
    cmpq %r13, %r14
    jl .Lssa_http____lists_token_16
.Lssa_http____lists_token_7:
    movq %rbx, %rax
    movq %r14, %rdi
    movq %r12, %r8
    call __fn_http____token_at.r
    testq %rax, %rax
    jnz .Lssa_http____lists_token_1
.Lssa_http____lists_token_5:
    .loc 2 3243 10
    addq $1, %r14
    movslq %r14d, %rsi
    cmpq %r13, %rsi
    jle .Lssa_http____lists_token_8
.Lssa_http____lists_token_2:
    .loc 2 3245 3
    xorl %eax, %eax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http____lists_token_1:
    .loc 2 3241 7
    movl $1, %eax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_http__fields_ok:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_http__fields_ok.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
.Lssa_http__fields_ok_0:
    .loc 2 3312 3 prologue_end
.Lssa_http__fields_ok_3:
    xorl %r12d, %r12d
.Lssa_http__fields_ok_4:
    movq 8(%rbx), %rsi
    movq 0(%rsi), %rdi
    cmpq %rdi, %r12
    jge .Lssa_http__fields_ok_2
.Lssa_http__fields_ok_13:
    movq 8(%rbx), %rdi
    movq 8(%rdi,%r12,8), %r13
.Lssa_http__fields_ok_11:
    .loc 2 3274 3
    movq 8(%r13), %rdi
    cmpq $0, %rdi
    jle .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_10:
    leaq .K8(%rip), %rdi
    xorl %esi, %esi
    movq %rdi, %rdx
    movq %rsi, %rcx
    movq %r13, %rax
    movq 8(%rax), %r8
    movq (%rax), %rax
    testq %rcx, %rcx
    jns .L41
    xorq %rcx, %rcx
.L41:
    leaq .S70(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L44
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L42:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L48
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L43
    addq $32, %r9
    jmp .L42
.L48:
    cmpq %r10, %r9
    jg .L49
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L43
    addq $16, %r9
.L49:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L44
.L43:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L47
.L44:
    cmpq %r8, %rcx
    jge .L46
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L45
    addq $1, %rcx
    jmp .L44
.L45:
    pushq %rcx
    jmp .L47
.L46:
    pushq %r8
.L47:
    popq %rax
    movq 8(%r13), %rsi
    cmpq %rsi, %rax
    jne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_7:
    movq 16(%rbx), %rsi
    cmpq (%rsi), %r12
    jae __fern_oob_abort
    movq 8(%rsi,%r12,8), %r13
    .loc 2 3323 3
    leaq .K9(%rip), %rsi
    xorl %edi, %edi
    movq %rsi, %rdx
    movq %rdi, %rcx
    movq %r13, %rax
    movq 8(%rax), %r8
    movq (%rax), %rax
    testq %rcx, %rcx
    jns .L50
    xorq %rcx, %rcx
.L50:
    leaq .S71(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L53
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L51:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L57
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L52
    addq $32, %r9
    jmp .L51
.L57:
    cmpq %r10, %r9
    jg .L58
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L52
    addq $16, %r9
.L58:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L53
.L52:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L56
.L53:
    cmpq %r8, %rcx
    jge .L55
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L54
    addq $1, %rcx
    jmp .L53
.L54:
    pushq %rcx
    jmp .L56
.L55:
    pushq %r8
.L56:
    popq %rax
    movq 8(%r13), %rdi
    cmpq %rdi, %rax
    jne .Lssa_http__fields_ok_1
.Lssa_http__fields_ok_5:
    .loc 2 3317 7
    addq $1, %r12
    jmp .Lssa_http__fields_ok_4
.Lssa_http__fields_ok_2:
    .loc 2 3319 3
    movl $1, %eax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_http__fields_ok_1:
    .loc 2 3315 7
    xorl %eax, %eax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_fnv_str_seeded:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_fnv_str_seeded.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___map_fnv_str_seeded_0:
    .loc 4 157 3 prologue_end
    movl $2166136261, %edi
    movl %esi, %esi
    xorq %rsi, %rdi
    .loc 4 158 3
    .loc 4 159 3
    movq 8(%rax), %rsi
    .loc 4 160 3
.Lssa___map_fnv_str_seeded_4:
    xorl %r8d, %r8d
.Lssa___map_fnv_str_seeded_5:
    leaq 4(%r8), %r9
    movslq %r9d, %r9
    cmpq %rsi, %r9
    jg .Lssa___map_fnv_str_seeded_13
.Lssa___map_fnv_str_seeded_6:
    .loc 4 162 5
    leaq 3(%r8), %r9
    movslq %r9d, %r9
    movq %r8, %r10
    sarq $31, %r10
    orq %r10, %r9
    cmpq 8(%rax), %r9
    jae __fern_str_oob_abort
    movq 0(%rax), %r10
    addq %r8, %r10
    movslq (%r10), %r10
    .loc 4 166 7
    xorq %rdi, %r10
    .loc 4 158 3
    .loc 4 166 7
    imull $16777619, %r10d, %edi
    .loc 4 167 7
    leaq 4(%r8), %r10
    movslq %r10d, %r8
    jmp .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmpq %rsi, %r8
    jge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    .loc 4 170 7
    cmpq 8(%rax), %r8
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%r8), %r10d
    xorq %rdi, %r10
    imull $16777619, %r10d, %edi
    .loc 4 171 7
    addq $1, %r8
    cmpq %rsi, %r8
    jl .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    .loc 4 173 5
    movq %rdi, %r8
    shrq $16, %r8
    xorq %r8, %rdi
    .loc 4 174 5
    movl $2246822507, %r8d
    imull %r8d, %edi
    .loc 4 175 5
    movq %rdi, %r8
    shrq $13, %r8
    xorq %r8, %rdi
    .loc 4 176 5
    movl $3266489909, %r8d
    imull %r8d, %edi
    .loc 4 177 5
    movq %rdi, %r8
    shrq $16, %r8
    xorq %r8, %rdi
    .loc 4 178 3
    movslq %edi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string____str_maxsuf:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn_string____str_maxsuf.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $24, %rsp
    movq %rax, -48(%rbp)
    movq %rsi, -56(%rbp)
.Lssa_string____str_maxsuf_0:
    .loc 5 194 3 prologue_end
    .loc 5 195 3
    .loc 5 196 3
    .loc 5 197 3
.Lssa_string____str_maxsuf_2:
    movq $-1, %rbx
    xorl %r10d, %r10d
    movl $1, %r12d
    movl $1, %r13d
.Lssa_string____str_maxsuf_3:
    leaq (%r10,%r12), %rcx
    movslq %ecx, %r14
    cmpq -56(%rbp), %r14
    jge .Lssa_string____str_maxsuf_1
.Lssa_string____str_maxsuf_16:
    .loc 5 199 5
    leaq (%r10,%r12), %rcx
    imulq %r9, %rcx
    leal (%r8,%rcx), %r14d
    movq -48(%rbp), %r11
    cmpq 8(%r11), %r14
    jae __fern_str_oob_abort
    movq (%r11), %rdx
    movzbl (%rdx,%r14), %r15d
    .loc 5 200 5
    leaq (%rbx,%r12), %rcx
    imulq %r9, %rcx
    leal (%r8,%rcx), %r14d
    cmpq 8(%r11), %r14
    jae __fern_str_oob_abort
    movq (%r11), %rdx
    movzbl (%rdx,%r14), %esi
    testq %rdi, %rdi
    movq %rsi, %r14
    cmoveq %r15, %r14
    testq %rdi, %rdi
    cmoveq %rsi, %r15
    cmpq %r15, %r14
    jge .Lssa_string____str_maxsuf_11
.Lssa_string____str_maxsuf_12:
    .loc 5 207 9
    leaq (%r10,%r12), %rsi
    movslq %esi, %rsi
    .loc 5 209 9
    movq %rsi, %rcx
    subq %rbx, %rcx
    movslq %ecx, %rax
    .loc 5 208 9
    movq %rsi, %r10
    movq %rax, %r13
    movl $1, %r12d
    jmp .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_11:
    cmpq %r15, %r14
    jne .Lssa_string____str_maxsuf_6
.Lssa_string____str_maxsuf_10:
    cmpq %r13, %r12
    jne .Lssa_string____str_maxsuf_8
.Lssa_string____str_maxsuf_9:
    .loc 5 212 11
    leaq (%r10,%r13), %rcx
    movslq %ecx, %rsi
    .loc 5 213 11
    movq %rsi, %r10
    movl $1, %r12d
    jmp .Lssa_string____str_maxsuf_7
.Lssa_string____str_maxsuf_8:
    .loc 5 215 11
    addq $1, %r12
    movslq %r12d, %r12
.Lssa_string____str_maxsuf_7:
    movq %r10, %rsi
    jmp .Lssa_string____str_maxsuf_5
.Lssa_string____str_maxsuf_6:
    .loc 5 219 9
    leaq 1(%r10), %rsi
    movslq %esi, %rsi
    .loc 5 220 9
    .loc 5 221 9
    movq %r10, %rbx
    movl $1, %r12d
    movl $1, %r13d
.Lssa_string____str_maxsuf_5:
    movq %rsi, %r10
.Lssa_string____str_maxsuf_4:
    jmp .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_1:
    movq %r13, %rdx
    .loc 5 224 3
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string____str_two_way:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
    movq 48(%rsp), %r10
__fn_string____str_two_way.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $56, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
    movq %rdi, %r13
    movq %r8, -56(%rbp)
    movq %r9, -64(%rbp)
    movq %r10, %r15
    movq 64(%rbp), %r12
    movq 72(%rbp), %r14
.Lssa_string____str_two_way_0:
.Lssa_string____str_two_way_25:
    cmpq $3, -56(%rbp)
    jge .Lssa_string____str_two_way_22
.Lssa_string____str_two_way_24:
    .loc 5 229 5 prologue_end
    movq -56(%rbp), %rsi
    subq $1, %rsi
    movslq %esi, %rsi
    movq %rsi, -72(%rbp)
    movq $1, -80(%rbp)
    jmp .Lssa_string____str_two_way_18
.Lssa_string____str_two_way_22:
    .loc 5 231 3
    xorl %edi, %edi
    movq %r13, %rax
    movq -56(%rbp), %rsi
    movq %r12, %r8
    movq %r14, %r9
    call __fn_string____str_maxsuf.r
    movq %rax, -72(%rbp)
    movq %rdx, -80(%rbp)
    .loc 5 232 3
    movl $1, %edi
    movq %r13, %rax
    movq -56(%rbp), %rsi
    movq %r12, %r8
    movq %r14, %r9
    call __fn_string____str_maxsuf.r
    movq %rax, -88(%rbp)
    movq %rdx, %rax
    movq -88(%rbp), %r11
    cmpq -72(%rbp), %r11
    jge .Lssa_string____str_two_way_19
.Lssa_string____str_two_way_21:
    .loc 5 234 5
    movq -72(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %rdi
    movq %rdi, -72(%rbp)
    jmp .Lssa_string____str_two_way_18
.Lssa_string____str_two_way_19:
    .loc 5 236 3
    movq -88(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %rdi
    movq %rdi, -72(%rbp)
    movq %rax, -80(%rbp)
.Lssa_string____str_two_way_18:
    .loc 5 254 3
    movq -48(%rbp), %rsi
    subq -56(%rbp), %rsi
    movslq %esi, %r11
    movq %r11, -48(%rbp)
.Lssa_string____str_two_way_17:
    .loc 5 240 3
.Lssa_string____str_two_way_16:
    xorl %r8d, %r8d
.Lssa_string____str_two_way_36:
    cmpq -72(%rbp), %r8
    jge .Lssa_string____str_two_way_12
.Lssa_string____str_two_way_39:
    movq -80(%rbp), %r9
    addq %r8, %r9
    imulq %r14, %r9
    addl %r12d, %r9d
    cmpq 8(%r13), %r9
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r9), %r10d
    movq %r14, %r9
    imulq %r8, %r9
    addl %r12d, %r9d
    cmpq 8(%r13), %r9
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r9), %esi
    cmpq %rsi, %r10
    jne .Lssa_string____str_two_way_7
.Lssa_string____str_two_way_37:
    .loc 5 245 7
    addq $1, %r8
    cmpq -72(%rbp), %r8
    jl .Lssa_string____str_two_way_39
.Lssa_string____str_two_way_12:
    .loc 5 258 5
.Lssa_string____str_two_way_11:
    .loc 5 276 16
    movq -56(%rbp), %r8
    subq -80(%rbp), %r8
    movslq %r8d, %r11
    movq %r11, -88(%rbp)
    xorl %esi, %esi
.Lssa_string____str_two_way_55:
    movq -64(%rbp), %r11
    cmpq -48(%rbp), %r11
    jg .Lssa_string____str_two_way_10
.Lssa_string____str_two_way_67:
    cmpq -72(%rbp), %rsi
    movq %rsi, %r9
    cmovleq -72(%rbp), %r9
.Lssa_string____str_two_way_77:
    cmpq -56(%rbp), %r9
    jge .Lssa_string____str_two_way_63
.Lssa_string____str_two_way_79:
    movq %r14, %r10
    imulq %r9, %r10
    addl %r12d, %r10d
    cmpq 8(%r13), %r10
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r10), %r8d
    movq %r9, %r10
    addq -64(%rbp), %r10
    imulq %r14, %r10
    addl %r15d, %r10d
    cmpq 8(%rbx), %r10
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r10), %eax
    cmpq %rax, %r8
    jne .Lssa_string____str_two_way_63
.Lssa_string____str_two_way_78:
    .loc 5 265 11
    addq $1, %r9
    cmpq -56(%rbp), %r9
    jl .Lssa_string____str_two_way_79
.Lssa_string____str_two_way_63:
    cmpq -56(%rbp), %r9
    jl .Lssa_string____str_two_way_57
.Lssa_string____str_two_way_62:
    .loc 5 268 11
    movq -72(%rbp), %r10
    subq $1, %r10
    movslq %r10d, %r10
.Lssa_string____str_two_way_61:
.Lssa_string____str_two_way_94:
    cmpq %rsi, %r10
    jl .Lssa_string____str_two_way_60
.Lssa_string____str_two_way_96:
    movq %r14, %r8
    imulq %r10, %r8
    addl %r12d, %r8d
    cmpq 8(%r13), %r8
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r8), %eax
    movq %r10, %r8
    addq -64(%rbp), %r8
    imulq %r14, %r8
    addl %r15d, %r8d
    cmpq 8(%rbx), %r8
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r8), %edi
    cmpq %rdi, %rax
    jne .Lssa_string____str_two_way_60
.Lssa_string____str_two_way_95:
    .loc 5 270 13
    leaq -1(%r10), %rdi
    movslq %edi, %r10
    cmpq %rsi, %r10
    jge .Lssa_string____str_two_way_96
.Lssa_string____str_two_way_60:
    cmpq %rsi, %r10
    jl .Lssa_string____str_two_way_9
.Lssa_string____str_two_way_58:
    .loc 5 275 11
    movq -64(%rbp), %r10
    addq -80(%rbp), %r10
    movslq %r10d, %r10
    movq %r10, -64(%rbp)
    movq -88(%rbp), %rsi
    jmp .Lssa_string____str_two_way_55
.Lssa_string____str_two_way_57:
    .loc 5 278 11
    subq -72(%rbp), %r9
    addq -64(%rbp), %r9
    addq $1, %r9
    movslq %r9d, %r9
    .loc 5 279 16
    movq %r9, -64(%rbp)
    xorl %esi, %esi
.Lssa_string____str_two_way_56:
    movq -64(%rbp), %r11
    cmpq -48(%rbp), %r11
    jle .Lssa_string____str_two_way_67
.Lssa_string____str_two_way_10:
    .loc 5 282 5
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_two_way_9:
    .loc 5 273 11
    movq -64(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_two_way_7:
    movq -56(%rbp), %rsi
    subq -72(%rbp), %rsi
    movslq %esi, %rsi
    .loc 5 287 11
    movq -56(%rbp), %r9
    subq -72(%rbp), %r9
    cmpq -72(%rbp), %rsi
    cmovleq -72(%rbp), %r9
    .loc 5 289 9
    leaq 1(%r9), %r11
    movq %r11, -80(%rbp)
.Lssa_string____str_two_way_3:
    movq -64(%rbp), %rax
.Lssa_string____str_two_way_119:
    cmpq -48(%rbp), %rax
    jg .Lssa_string____str_two_way_2
.Lssa_string____str_two_way_128:
    movq -72(%rbp), %rsi
.Lssa_string____str_two_way_134:
    cmpq -56(%rbp), %rsi
    jge .Lssa_string____str_two_way_127
.Lssa_string____str_two_way_136:
    movq %r14, %r10
    imulq %rsi, %r10
    addl %r12d, %r10d
    cmpq 8(%r13), %r10
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r10), %edi
    leaq (%rsi,%rax), %r10
    imulq %r14, %r10
    addl %r15d, %r10d
    cmpq 8(%rbx), %r10
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r10), %r8d
    cmpq %r8, %rdi
    jne .Lssa_string____str_two_way_127
.Lssa_string____str_two_way_135:
    .loc 5 293 9
    addq $1, %rsi
    cmpq -56(%rbp), %rsi
    jl .Lssa_string____str_two_way_136
.Lssa_string____str_two_way_127:
    cmpq -56(%rbp), %rsi
    jl .Lssa_string____str_two_way_121
.Lssa_string____str_two_way_126:
    .loc 5 296 9
    movq -72(%rbp), %r8
    subq $1, %r8
    movslq %r8d, %r8
.Lssa_string____str_two_way_125:
.Lssa_string____str_two_way_151:
    cmpq $0, %r8
    jl .Lssa_string____str_two_way_124
.Lssa_string____str_two_way_153:
    movq %r14, %r10
    imulq %r8, %r10
    addl %r12d, %r10d
    cmpq 8(%r13), %r10
    jae __fern_str_oob_abort
    movq (%r13), %rdx
    movzbl (%rdx,%r10), %edi
    leaq (%r8,%rax), %r10
    imulq %r14, %r10
    addl %r15d, %r10d
    cmpq 8(%rbx), %r10
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r10), %r9d
    cmpq %r9, %rdi
    jne .Lssa_string____str_two_way_124
.Lssa_string____str_two_way_152:
    .loc 5 298 11
    leaq -1(%r8), %r9
    movslq %r9d, %r8
    cmpq $0, %r8
    jge .Lssa_string____str_two_way_153
.Lssa_string____str_two_way_124:
    cmpq $0, %r8
    jl .Lssa_string____str_two_way_1
.Lssa_string____str_two_way_122:
    .loc 5 303 9
    movq %rax, %r8
    addq -80(%rbp), %r8
    movslq %r8d, %r8
    movq %r8, %rax
    jmp .Lssa_string____str_two_way_119
.Lssa_string____str_two_way_121:
    .loc 5 305 9
    subq -72(%rbp), %rsi
    addq %rax, %rsi
    addq $1, %rsi
    movslq %esi, %rsi
    movq %rsi, %rax
.Lssa_string____str_two_way_120:
    cmpq -48(%rbp), %rax
    jle .Lssa_string____str_two_way_128
.Lssa_string____str_two_way_2:
    .loc 5 308 3
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_two_way_1:
    .loc 5 301 9
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string____str_find_from:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn_string____str_find_from.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
.Lssa_string____str_find_from_0:
    .loc 5 333 10 prologue_end
    xorl %r10d, %r10d
    cmpq $0, %r9
    cmovgeq %r9, %r10
    cmpq $0, %r8
    jne .Lssa_string____str_find_from_14
.Lssa_string____str_find_from_18:
    cmpq %rsi, %r10
    movq %rsi, %r9
    cmovleq %r10, %r9
    movq %r9, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_14:
    movq %rsi, %r9
    subq %r10, %r9
    movslq %r9d, %r9
    cmpq %r9, %r8
    jle .Lssa_string____str_find_from_11
.Lssa_string____str_find_from_13:
    .loc 5 342 5
    movq $-1, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_11:
    cmpq $1, %r8
    jne .Lssa_string____str_find_from_8
.Lssa_string____str_find_from_10:
    .loc 5 345 5
    cmpq $0, 8(%rdi)
    jbe __fern_str_oob_abort
    movq (%rdi), %rdx
    movzbl 0(%rdx), %r9d
    movq %r10, %rdx
    movq %r9, %rcx
    movq 8(%rax), %r8
    movq (%rax), %rax
    cmpq $0, %rdx
    jge .L59
    xorq %rdx, %rdx
.L59:
    cmpq $255, %rcx
    ja .L63
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L67
.L65:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L66
    addq $32, %r9
    cmpq %r10, %r9
    jle .L65
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L67
.L66:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L64
.L67:
    vzeroupper
.L60:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L62
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L61
    addq $16, %rdx
    jmp .L60
.L61:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L64
.L62:
    cmpq %r8, %rdx
    jge .L63
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L68
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L63
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L63
    addq %r9, %rdx
    jmp .L64
.L68:
    cmpq %r8, %rdx
    jge .L63
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L64
    addq $1, %rdx
    jmp .L68
.L63:
    movq $-1, %rdx
.L64:
    movq %rdx, %rsi
    movq %rsi, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_8:
    cmpq $4, %r8
    jg .Lssa_string____str_find_from_3
.Lssa_string____str_find_from_6:
    movq %rsi, %r9
    subq %r8, %r9
    movslq %r9d, %r9
.Lssa_string____str_find_from_47:
    cmpq %r9, %r10
    jg .Lssa_string____str_find_from_5
.Lssa_string____str_find_from_52:
    .loc 5 318 5
.Lssa_string____str_find_from_51:
    xorl %ebx, %ebx
.Lssa_string____str_find_from_57:
    cmpq %r8, %rbx
    jge .Lssa_string____str_find_from_50
.Lssa_string____str_find_from_59:
    leal (%r10,%rbx), %esi
    cmpq 8(%rax), %rsi
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%rsi), %r12d
    cmpq 8(%rdi), %rbx
    jae __fern_str_oob_abort
    movq (%rdi), %rdx
    movzbl (%rdx,%rbx), %esi
    cmpq %rsi, %r12
    jne .Lssa_string____str_find_from_50
.Lssa_string____str_find_from_58:
    .loc 5 320 9
    addq $1, %rbx
    cmpq %r8, %rbx
    jl .Lssa_string____str_find_from_59
.Lssa_string____str_find_from_50:
    cmpq %r8, %rbx
    je .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_48:
    .loc 5 325 7
    leaq 1(%r10), %rcx
    movslq %ecx, %r10
    cmpq %r9, %r10
    jle .Lssa_string____str_find_from_52
.Lssa_string____str_find_from_5:
    .loc 5 327 3
    movq $-1, %r10
    jmp .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_3:
    .loc 5 350 3
    xorl %r9d, %r9d
    xorl %ebx, %ebx
    movl $1, %r12d
    pushq %r12
    pushq %rbx
    pushq %r9
    pushq %r10
    pushq %r8
    pushq %rdi
    pushq %rsi
    pushq %rax
    call __fn_string____str_two_way
    addq $64, %rsp
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_2:
.Lssa_string____str_find_from_1:
    .loc 5 348 5
    movq %r10, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string__split:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_string__split.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $152, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa_string__split_0:
    .loc 5 1682 3 prologue_end
    movq 8(%rbx), %r11
    movq %r11, -56(%rbp)
    .loc 5 1683 3
    movq -48(%rbp), %r11
    movq 8(%r11), %r11
    movq %r11, -64(%rbp)
    .loc 5 1684 3
    leaq .K0(%rip), %r11
    movq %r11, -72(%rbp)
    cmpq $0, -64(%rbp)
    jne .Lssa_string__split_3
.Lssa_string__split_7:
    .loc 5 2386 3
    movq 8(%rbx), %r11
    movq %r11, -80(%rbp)
    .loc 5 2387 3
    leaq .K0(%rip), %rdi
    .loc 5 2388 3
.Lssa_string__split_6:
    movq %rdi, %r12
    xorl %r13d, %r13d
.Lssa_string__split_13:
    cmpq -80(%rbp), %r13
    jge .Lssa_string__split_5
.Lssa_string__split_14:
    .loc 5 2390 5
    movq %rbx, %rax
    movq %r13, %rsi
    movq -80(%rbp), %rdi
    call __fn_utf8_scalar__step.r
    .loc 5 2391 9
    addq %r13, %rax
    movslq %eax, %r14
    movq %rbx, %rdx
    movq %r13, %rcx
    movq %r14, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -104(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r15
    leaq .SB6(%rip), %rdi
    movq %r15, %rax
    movq %rdi, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r13
    pushq %r15
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r12, %rdi
    movq %r13, %rsi
    call __fern_arr_push_owned
    movq %rax, %r12
    movq %r14, %r13
    cmpq -80(%rbp), %r13
    jl .Lssa_string__split_14
.Lssa_string__split_5:
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string__split_3:
    .loc 5 1688 3
    xorl %r9d, %r9d
    .loc 5 1689 3
    movq %rbx, %rax
    movq -56(%rbp), %rsi
    movq -48(%rbp), %rdi
    movq -64(%rbp), %r8
    call __fn_string____str_find_from.r
    .loc 5 1688 3
.Lssa_string__split_2:
    movq -72(%rbp), %r12
    movq %rax, %r13
    xorl %r9d, %r9d
.Lssa_string__split_21:
    cmpq $0, %r13
    jl .Lssa_string__split_1
.Lssa_string__split_22:
    .loc 5 1691 9
    movq %rbx, %rdx
    movq %r9, %rcx
    movq %r13, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -128(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r14
    leaq .SB6(%rip), %rdi
    movq %r14, %rax
    movq %rdi, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r15
    pushq %r14
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r12, %rdi
    movq %r15, %rsi
    movq %r9, -160(%rbp)
    call __fern_arr_push_owned
    movq -160(%rbp), %r9
    movq %rax, %r12
    .loc 5 1692 11
    addq -64(%rbp), %r13
    movslq %r13d, %r13
    .loc 5 1693 9
    movq %rbx, %rax
    movq -56(%rbp), %rsi
    movq -48(%rbp), %rdi
    movq -64(%rbp), %r8
    movq %r13, %r9
    call __fn_string____str_find_from.r
    movq %r13, %r9
    movq %rax, %r13
    cmpq $0, %r13
    jge .Lssa_string__split_22
.Lssa_string__split_1:
    .loc 5 1695 3
    movq %rbx, %rdx
    movq %r9, %rcx
    movq -56(%rbp), %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -152(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r13
    leaq .SB6(%rip), %r9
    movq %r13, %rax
    movq %r9, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %rbx
    pushq %r13
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r12, %rdi
    movq %rbx, %rsi
    call __fern_arr_push_owned
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_string__eq_ignore_ascii_case:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_string__eq_ignore_ascii_case.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_string__eq_ignore_ascii_case_0:
    .loc 5 1952 3 prologue_end
    movq 8(%rax), %rdi
    movq 8(%rsi), %r8
    cmpq %r8, %rdi
    je .Lssa_string__eq_ignore_ascii_case_4
.Lssa_string__eq_ignore_ascii_case_6:
    .loc 5 1954 5
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string__eq_ignore_ascii_case_4:
.Lssa_string__eq_ignore_ascii_case_3:
    xorl %r8d, %r8d
.Lssa_string__eq_ignore_ascii_case_11:
    cmpq %rdi, %r8
    jge .Lssa_string__eq_ignore_ascii_case_2
.Lssa_string__eq_ignore_ascii_case_17:
    .loc 5 1957 5
    movq 0(%rax), %r9
    movzbl (%r9,%r8), %r10d
    .loc 5 1958 5
    cmpq 8(%rsi), %r8
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%r8), %r9d
    xorq %r10, %r9
    cmpq $0, %r9
    je .Lssa_string__eq_ignore_ascii_case_12
.Lssa_string__eq_ignore_ascii_case_16:
    cmpq $32, %r9
    jne .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_15:
    movq %r10, %r9
    orq $32, %r9
    cmpq $97, %r9
    jl .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_14:
    orq $32, %r10
    cmpq $122, %r10
    jg .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_12:
    addq $1, %r8
    cmpq %rdi, %r8
    jl .Lssa_string__eq_ignore_ascii_case_17
.Lssa_string__eq_ignore_ascii_case_2:
    .loc 5 1963 3
    movl $1, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_string__eq_ignore_ascii_case_1:
    .loc 5 1960 7
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_io_buffered__BufBlock__drop:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_io_buffered__BufBlock__drop.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_io_buffered__BufBlock__drop_0:
    movq 8(%rax), %rsi
    movq %rsi, %rdi
    call __fern_buf_free
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_json__JsonError__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_json__JsonError__eq.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_json__JsonError__eq_0:
    movq 8(%rbx), %rsi
    movq 8(%r12), %rdi
    movq 8(%rsi), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_json__JsonError__eq_streqn22
    movq %rdi, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_json__JsonError__eq_streqd22
.Lssa_json__JsonError__eq_streqn22:
    xorl %eax, %eax
.Lssa_json__JsonError__eq_streqd22:
    testq %rax, %rax
    jz .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_9:
    movq 16(%rbx), %rdi
    movq 16(%r12), %rsi
    cmpq %rsi, %rdi
    jne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_6:
    movq 24(%rbx), %rsi
    movq 24(%r12), %rdi
    cmpq %rdi, %rsi
    jne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_3:
    movq 32(%rbx), %rdi
    movq 32(%r12), %rsi
    movq %rdi, %rax
    cmpq %rsi, %rax
    sete %al
    movzbq %al, %rax
    jmp .Lssa_json__JsonError__eq_1
.Lssa_json__JsonError__eq_2:
    xorl %eax, %eax
.Lssa_json__JsonError__eq_1:
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_utf8__is_valid:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_utf8__is_valid.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
.Lssa_utf8__is_valid_0:
.Lssa_utf8__is_valid_21:
    .loc 13 155 3 prologue_end
    movq 8(%rbx), %r12
    .loc 13 156 3
.Lssa_utf8__is_valid_20:
    xorl %r13d, %r13d
.Lssa_utf8__is_valid_22:
    cmpq %r12, %r13
    jge .Lssa_utf8__is_valid_19
.Lssa_utf8__is_valid_70:
    .loc 13 158 5
    cmpq 8(%rbx), %r13
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%r13), %r14d
    cmpq $128, %r14
    jge .Lssa_utf8__is_valid_65
.Lssa_utf8__is_valid_69:
    .loc 13 160 9
    movq %r13, %rdx
    movq %rbx, %rax
    movq 8(%rax), %r8
    movq (%rax), %rax
    cmpq $0, %rdx
    jge .L69
    xorq %rdx, %rdx
.L69:
.L75:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $32, %r9
    jl .L77
    vmovdqu (%rax,%rdx), %ymm0
    vpmovmskb %ymm0, %r9d
    testl %r9d, %r9d
    jnz .L76
    addq $32, %rdx
    jmp .L75
.L76:
    vzeroupper
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L74
.L77:
    vzeroupper
.L70:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L72
    movdqu (%rax,%rdx), %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L71
    addq $16, %rdx
    jmp .L70
.L71:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L74
.L72:
    cmpq %r8, %rdx
    jge .L73
    movzbq (%rax,%rdx), %r9
    testq $128, %r9
    jnz .L74
    addq $1, %rdx
    jmp .L72
.L73:
    movq %r8, %rdx
.L74:
    movq %rdx, %rax
    cmpq %r12, %rax
    jge .Lssa_utf8__is_valid_18
.Lssa_utf8__is_valid_67:
    .loc 13 164 10
    cmpq 8(%rbx), %rax
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rax), %esi
    movq %rax, %r13
    movq %rsi, %r14
.Lssa_utf8__is_valid_66:
.Lssa_utf8__is_valid_65:
    cmpq $192, %r14
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_64:
    cmpq $224, %r14
    jge .Lssa_utf8__is_valid_55
.Lssa_utf8__is_valid_63:
    leaq 1(%r13), %rsi
    movslq %esi, %rsi
    cmpq %r12, %rsi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_61:
    .loc 13 172 7
    leal 1(%r13), %esi
    cmpq 8(%rbx), %rsi
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rsi), %edi
    cmpq $128, %rdi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_60:
    cmpq $192, %rdi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_58:
    leaq -192(%r14), %rsi
    shlq $6, %rsi
    movslq %esi, %rsi
    subq $128, %rdi
    movslq %edi, %rdi
    orq %rdi, %rsi
    cmpq $128, %rsi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_56:
    .loc 13 179 9
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    movq %rsi, %r13
    jmp .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_55:
    cmpq $240, %r14
    jge .Lssa_utf8__is_valid_40
.Lssa_utf8__is_valid_54:
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    cmpq %r12, %rsi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_52:
    .loc 13 184 7
    leaq 1(%r13), %rsi
    movslq %esi, %rsi
    leaq 1(%rsi), %rdi
    movslq %edi, %rdi
    movq %rsi, %r8
    sarq $31, %r8
    orq %r8, %rdi
    cmpq 8(%rbx), %rdi
    jae __fern_str_oob_abort
    movq 0(%rbx), %r8
    movzbl (%r8,%rsi), %edi
    .loc 13 185 7
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    movzbl (%r8,%rsi), %r9d
    cmpq $128, %rdi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_51:
    cmpq $192, %rdi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_49:
    cmpq $128, %r9
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_48:
    cmpq $192, %r9
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_46:
    .loc 13 192 7
    leaq -224(%r14), %rsi
    shlq $12, %rsi
    movslq %esi, %rsi
    subq $128, %rdi
    shlq $6, %rdi
    movslq %edi, %rdi
    orq %rdi, %rsi
    subq $128, %r9
    movslq %r9d, %r9
    orq %r9, %rsi
    cmpq $2048, %rsi
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_44:
    cmpq $55296, %rsi
    jl .Lssa_utf8__is_valid_41
.Lssa_utf8__is_valid_43:
    cmpq $57343, %rsi
    jle .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_41:
    .loc 13 199 9
    leaq 3(%r13), %rsi
    movslq %esi, %rsi
    movq %rsi, %r13
    jmp .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_40:
    cmpq $248, %r14
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_39:
    leaq 3(%r13), %rsi
    movslq %esi, %rsi
    cmpq %r12, %rsi
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_37:
    .loc 13 204 7
    leaq 1(%r13), %rsi
    movslq %esi, %rsi
    leaq 2(%rsi), %r9
    movslq %r9d, %r9
    movq %rsi, %rdi
    sarq $31, %rdi
    orq %rdi, %r9
    cmpq 8(%rbx), %r9
    jae __fern_str_oob_abort
    movq 0(%rbx), %rdi
    movzbl (%rdi,%rsi), %r9d
    .loc 13 205 7
    leaq 2(%r13), %rsi
    movslq %esi, %rsi
    movzbl (%rdi,%rsi), %r8d
    .loc 13 206 7
    leaq 3(%r13), %rsi
    movslq %esi, %rsi
    movzbl (%rdi,%rsi), %r10d
    cmpq $128, %r9
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_36:
    cmpq $192, %r9
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_34:
    cmpq $128, %r8
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_33:
    cmpq $192, %r8
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_31:
    cmpq $128, %r10
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_30:
    cmpq $192, %r10
    jge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_28:
    .loc 13 216 7
    subq $240, %r14
    shlq $18, %r14
    movslq %r14d, %r14
    subq $128, %r9
    shlq $12, %r9
    movslq %r9d, %r9
    orq %r9, %r14
    subq $128, %r8
    shlq $6, %r8
    movslq %r8d, %r8
    orq %r8, %r14
    subq $128, %r10
    movslq %r10d, %r10
    orq %r10, %r14
    cmpq $65536, %r14
    jl .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_26:
    cmpq $1114111, %r14
    jg .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_24:
    .loc 13 223 9
    leaq 4(%r13), %r10
    movslq %r10d, %r10
    movq %r10, %r13
.Lssa_utf8__is_valid_23:
    cmpq %r12, %r13
    jl .Lssa_utf8__is_valid_70
.Lssa_utf8__is_valid_19:
    movq %r12, %r13
    jmp .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_18:
    movq %r12, %r13
.Lssa_utf8__is_valid_17:
.Lssa_utf8__is_valid_16:
.Lssa_utf8__is_valid_15:
.Lssa_utf8__is_valid_14:
.Lssa_utf8__is_valid_13:
.Lssa_utf8__is_valid_12:
.Lssa_utf8__is_valid_11:
.Lssa_utf8__is_valid_10:
.Lssa_utf8__is_valid_9:
.Lssa_utf8__is_valid_8:
.Lssa_utf8__is_valid_7:
.Lssa_utf8__is_valid_6:
.Lssa_utf8__is_valid_5:
.Lssa_utf8__is_valid_4:
.Lssa_utf8__is_valid_3:
.Lssa_utf8__is_valid_2:
.Lssa_utf8__is_valid_1:
    .loc 13 149 3
    movq 8(%rbx), %r10
    movq %r13, %rax
    cmpq %r10, %rax
    sete %al
    movzbq %al, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___primitive_i32_to_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___primitive_i32_to_string.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___primitive_i32_to_string_0:
    .loc 15 55 3 prologue_end
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    jmp __fn_int__int_to_string.r
    .cfi_restore_state
    .cfi_endproc
__fn___primitive_i64_to_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___primitive_i64_to_string.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___primitive_i64_to_string_0:
    cmpq $0, %rax
    jge .Lssa___primitive_i64_to_string_1
.Lssa___primitive_i64_to_string_3:
    .loc 15 74 5 prologue_end
    xorl %esi, %esi
    subq %rax, %rsi
    movl $1, %edi
    movq %rsi, %rax
    movq %rdi, %rsi
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    jmp __fn_int____int_to_string_u64.r
    .cfi_restore_state
.Lssa___primitive_i64_to_string_1:
    .loc 15 76 3
    xorl %esi, %esi
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    jmp __fn_int____int_to_string_u64.r
    .cfi_restore_state
    .cfi_endproc
__fn_int__int_to_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn_int__int_to_string.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
.Lssa_int__int_to_string_0:
    cmpq $0, %rax
    jl .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_47:
    cmpq $100, %rax
    jge .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_46:
    .loc 17 104 5 prologue_end
    leaq .K10(%rip), %rsi
    cmpq (%rsi), %rax
    jae __fern_oob_abort
    movq 8(%rsi,%rax,8), %rdi
    testb $1, %dil
    jnz .Lssa_int__int_to_string_rcinc220
    cmpq $0x10000, %rdi
    jb .Lssa_int__int_to_string_rcinc220
    movl -8(%rdi), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_int__int_to_string_rcinc220
    addl $1, %ecx
    movl %ecx, -8(%rdi)
.Lssa_int__int_to_string_rcinc220:
    movq %rdi, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_int__int_to_string_44:
    .loc 17 106 3
    xorl %edi, %edi
    .loc 17 109 7
    xorl %esi, %esi
    subq %rax, %rsi
    .loc 17 108 9
    movl $1, %r8d
    cmpq $0, %rax
    cmovgeq %rax, %rsi
    movq %r8, %rbx
    cmovgeq %rdi, %rbx
    .loc 17 111 3
    movl %esi, %r12d
.Lssa_int__int_to_string_40:
    cmpq $10, %r12
    jae .Lssa_int__int_to_string_37
.Lssa_int__int_to_string_39:
    .loc 17 68 5
    movl $1, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_37:
    cmpq $100, %r12
    jae .Lssa_int__int_to_string_34
.Lssa_int__int_to_string_36:
    .loc 17 71 5
    movl $2, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_34:
    cmpq $1000, %r12
    jae .Lssa_int__int_to_string_31
.Lssa_int__int_to_string_33:
    .loc 17 74 5
    movl $3, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_31:
    cmpq $10000, %r12
    jae .Lssa_int__int_to_string_28
.Lssa_int__int_to_string_30:
    .loc 17 77 5
    movl $4, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_28:
    cmpq $100000, %r12
    jae .Lssa_int__int_to_string_25
.Lssa_int__int_to_string_27:
    .loc 17 80 5
    movl $5, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_25:
    cmpq $1000000, %r12
    jae .Lssa_int__int_to_string_22
.Lssa_int__int_to_string_24:
    .loc 17 83 5
    movl $6, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_22:
    cmpq $10000000, %r12
    jae .Lssa_int__int_to_string_19
.Lssa_int__int_to_string_21:
    .loc 17 86 5
    movl $7, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_19:
    cmpq $100000000, %r12
    jae .Lssa_int__int_to_string_16
.Lssa_int__int_to_string_18:
    .loc 17 89 5
    movl $8, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_16:
    cmpq $1000000000, %r12
    jae .Lssa_int__int_to_string_13
.Lssa_int__int_to_string_15:
    .loc 17 92 5
    movl $9, %esi
    jmp .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_13:
    .loc 17 94 3
    movl $10, %esi
.Lssa_int__int_to_string_12:
    .loc 17 115 11
    leaq 1(%rsi), %r8
    movslq %r8d, %r8
    testq %rbx, %rbx
    movq %r8, %r13
    cmoveq %rsi, %r13
    .loc 17 117 3
    movq %r13, %rdi
    call __fern_alloc_bytes
    movq %rax, %r14
    .loc 17 63 3
    leaq .SB172(%rip), %r8
.Lssa_int__int_to_string_8:
.Lssa_int__int_to_string_111:
    .loc 17 127 3
    cmpq $100, %r12
    jb .Lssa_int__int_to_string_7
.Lssa_int__int_to_string_112:
    .loc 17 121 5
    movq %r12, %rax
    movl %eax, %ecx
    movl $1374389535, %eax
    mull %ecx
    shrl $5, %edx
    movl %edx, %eax
    movq %rax, %rsi
    imulq $100, %rsi, %rdi
    movq %r12, %r11
    subq %rdi, %r11
    movq %r11, %rdi
    .loc 17 123 7
    leaq -2(%r13), %r9
    movslq %r9d, %r13
    shlq $1, %rdi
    .loc 17 124 9
    movslq %edi, %rdi
    cmpq 8(%r8), %rdi
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%rdi), %r9d
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r13)
    .loc 17 125 9
    leal 1(%r13), %r10d
    addl $1, %edi
    cmpq 8(%r8), %rdi
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%rdi), %r9d
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r10)
    movq %rsi, %r12
    cmpq $100, %r12
    jae .Lssa_int__int_to_string_112
.Lssa_int__int_to_string_7:
    cmpq $10, %r12
    jb .Lssa_int__int_to_string_5
.Lssa_int__int_to_string_6:
    .loc 17 129 7
    leaq -2(%r13), %rdi
    movslq %edi, %rdi
    movq %r12, %r9
    shlq $1, %r9
    .loc 17 130 9
    movslq %r9d, %r9
    cmpq 8(%r8), %r9
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%r9), %r10d
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movb %r10b, 8(%r14,%rdi)
    .loc 17 131 9
    addl $1, %edi
    addl $1, %r9d
    cmpq 8(%r8), %r9
    jae __fern_str_oob_abort
    movq (%r8), %rdx
    movzbl (%rdx,%r9), %esi
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movb %sil, 8(%r14,%rdi)
    jmp .Lssa_int__int_to_string_4
.Lssa_int__int_to_string_5:
    .loc 17 133 7
    subl $1, %r13d
    .loc 17 134 9
    addq $48, %r12
    andq $255, %r12
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %r12b, 8(%r14,%r13)
.Lssa_int__int_to_string_4:
    testq %rbx, %rbx
    jz .Lssa_int__int_to_string_1
.Lssa_int__int_to_string_3:
    .loc 17 137 9
    movl $45, %r9d
    cmpq $0, 0(%r14)
    jbe __fern_oob_abort
    movb %r9b, 8(%r14)
.Lssa_int__int_to_string_1:
    .loc 17 140 5
    movq %r14, %rax
    call __fn___fern_string_from_bytes_u8.r
    movq %rax, %r12
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %r12, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_int____int_to_string_u64:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_int____int_to_string_u64.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_int____int_to_string_u64_0:
    .loc 17 146 3 prologue_end
.Lssa_int____int_to_string_u64_16:
    movq %rbx, %rdi
    movl $1, %esi
.Lssa_int____int_to_string_u64_17:
    cmpq $100, %rdi
    jb .Lssa_int____int_to_string_u64_15
.Lssa_int____int_to_string_u64_18:
    .loc 17 149 10
    leaq 2(%rsi), %r8
    movslq %r8d, %rsi
    .loc 17 150 11
    movq %rdi, %rax
    movq %rax, %rcx
    movq %rcx, %rdx
    shrq $2, %rdx
    movabsq $2951479051793528259, %rax
    mulq %rdx
    shrq $2, %rdx
    movq %rdx, %rax
    movq %rax, %rdi
    cmpq $100, %rdi
    jae .Lssa_int____int_to_string_u64_18
.Lssa_int____int_to_string_u64_15:
    .loc 17 153 10
    leaq 1(%rsi), %r8
    movslq %r8d, %r8
    cmpq $10, %rdi
    cmovbq %rsi, %r8
    .loc 17 157 11
    leaq 1(%r8), %rsi
    movslq %esi, %rsi
    cmpq $0, %r12
    movq %rsi, %r13
    cmoveq %r8, %r13
    .loc 17 159 3
    movq %r13, %rdi
    call __fern_alloc_bytes
    movq %rax, %r14
    .loc 17 63 3
    leaq .SB172(%rip), %rsi
.Lssa_int____int_to_string_u64_8:
.Lssa_int____int_to_string_u64_35:
    .loc 17 169 3
    cmpq $100, %rbx
    jb .Lssa_int____int_to_string_u64_7
.Lssa_int____int_to_string_u64_36:
    .loc 17 163 5
    movq %rbx, %rax
    movq %rax, %rcx
    movq %rcx, %rdx
    shrq $2, %rdx
    movabsq $2951479051793528259, %rax
    mulq %rdx
    shrq $2, %rdx
    movq %rdx, %rax
    movq %rax, %r8
    imulq $100, %r8, %rdi
    movq %rbx, %r11
    subq %rdi, %r11
    movq %r11, %rdi
    .loc 17 165 7
    leaq -2(%r13), %r9
    movslq %r9d, %r13
    shlq $1, %rdi
    .loc 17 166 9
    movslq %edi, %rdi
    cmpq 8(%rsi), %rdi
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%rdi), %r9d
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r13)
    .loc 17 167 9
    leal 1(%r13), %r10d
    addl $1, %edi
    cmpq 8(%rsi), %rdi
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%rdi), %r9d
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movb %r9b, 8(%r14,%r10)
    movq %r8, %rbx
    cmpq $100, %rbx
    jae .Lssa_int____int_to_string_u64_36
.Lssa_int____int_to_string_u64_7:
    cmpq $10, %rbx
    jb .Lssa_int____int_to_string_u64_5
.Lssa_int____int_to_string_u64_6:
    .loc 17 171 7
    leaq -2(%r13), %rdi
    movslq %edi, %rdi
    movq %rbx, %r9
    shlq $1, %r9
    .loc 17 172 9
    movslq %r9d, %r9
    cmpq 8(%rsi), %r9
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%r9), %r10d
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movb %r10b, 8(%r14,%rdi)
    .loc 17 173 9
    addl $1, %edi
    addl $1, %r9d
    cmpq 8(%rsi), %r9
    jae __fern_str_oob_abort
    movq (%rsi), %rdx
    movzbl (%rdx,%r9), %r8d
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movb %r8b, 8(%r14,%rdi)
    jmp .Lssa_int____int_to_string_u64_4
.Lssa_int____int_to_string_u64_5:
    .loc 17 175 7
    subl $1, %r13d
    .loc 17 176 9
    addq $48, %rbx
    andq $255, %rbx
    cmpq (%r14), %r13
    jae __fern_oob_abort
    movb %bl, 8(%r14,%r13)
.Lssa_int____int_to_string_u64_4:
    cmpq $0, %r12
    je .Lssa_int____int_to_string_u64_1
.Lssa_int____int_to_string_u64_3:
    .loc 17 179 9
    movl $45, %r9d
    cmpq $0, 0(%r14)
    jbe __fern_oob_abort
    movb %r9b, 8(%r14)
.Lssa_int____int_to_string_u64_1:
    .loc 17 182 5
    movq %r14, %rax
    call __fn___fern_string_from_bytes_u8.r
    movq %rax, %rbx
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %rbx, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_utf8_scalar__step:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_utf8_scalar__step.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
.Lssa_utf8_scalar__step_0:
    .loc 20 201 3 prologue_end
    cmpq 8(%rax), %rsi
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%rsi), %r8d
.Lssa_utf8_scalar__step_47:
    cmpq $128, %r8
    jge .Lssa_utf8_scalar__step_44
.Lssa_utf8_scalar__step_46:
    .loc 20 163 5
    movl $1, %r9d
    jmp .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_44:
    cmpq $194, %r8
    jge .Lssa_utf8_scalar__step_41
.Lssa_utf8_scalar__step_43:
    .loc 20 166 5
    xorl %r9d, %r9d
    jmp .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_41:
    cmpq $224, %r8
    jge .Lssa_utf8_scalar__step_38
.Lssa_utf8_scalar__step_40:
    .loc 20 169 5
    movl $2, %r9d
    jmp .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_38:
    cmpq $240, %r8
    jge .Lssa_utf8_scalar__step_35
.Lssa_utf8_scalar__step_37:
    .loc 20 172 5
    movl $3, %r9d
    jmp .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_35:
    cmpq $245, %r8
    jge .Lssa_utf8_scalar__step_32
.Lssa_utf8_scalar__step_34:
    .loc 20 175 5
    movl $4, %r9d
    jmp .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_32:
    .loc 20 177 3
    xorl %r9d, %r9d
.Lssa_utf8_scalar__step_31:
    cmpq $1, %r9
    jg .Lssa_utf8_scalar__step_28
.Lssa_utf8_scalar__step_30:
    .loc 20 204 5
    movl $1, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_28:
    leaq 1(%rsi), %r10
    movslq %r10d, %r10
    cmpq %rdi, %r10
    jl .Lssa_utf8_scalar__step_25
.Lssa_utf8_scalar__step_27:
    .loc 20 207 5
    movl $1, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_25:
    .loc 20 209 3
    leal 1(%rsi), %r10d
    cmpq 8(%rax), %r10
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%r10), %ebx
.Lssa_utf8_scalar__step_24:
    cmpq $224, %r8
    jne .Lssa_utf8_scalar__step_21
.Lssa_utf8_scalar__step_23:
    .loc 20 182 5
    movl $160, %r10d
    jmp .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_21:
    cmpq $240, %r8
    jne .Lssa_utf8_scalar__step_18
.Lssa_utf8_scalar__step_20:
    .loc 20 185 5
    movl $144, %r10d
    jmp .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_18:
    .loc 20 187 3
    movl $128, %r10d
.Lssa_utf8_scalar__step_17:
    cmpq %r10, %rbx
    jl .Lssa_utf8_scalar__step_7
.Lssa_utf8_scalar__step_15:
    cmpq $237, %r8
    jne .Lssa_utf8_scalar__step_12
.Lssa_utf8_scalar__step_14:
    .loc 20 192 5
    movl $159, %r10d
    jmp .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_12:
    cmpq $244, %r8
    jne .Lssa_utf8_scalar__step_9
.Lssa_utf8_scalar__step_11:
    .loc 20 195 5
    movl $143, %r10d
    jmp .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_9:
    .loc 20 197 3
    movl $191, %r10d
.Lssa_utf8_scalar__step_8:
    cmpq %r10, %rbx
    jle .Lssa_utf8_scalar__step_5
.Lssa_utf8_scalar__step_7:
    .loc 20 211 5
    movl $1, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_5:
    .loc 20 213 3
.Lssa_utf8_scalar__step_4:
    movl $2, %r10d
.Lssa_utf8_scalar__step_109:
    cmpq %r9, %r10
    jge .Lssa_utf8_scalar__step_3
.Lssa_utf8_scalar__step_118:
    leaq (%rsi,%r10), %r8
    movslq %r8d, %r8
    cmpq %rdi, %r8
    jge .Lssa_utf8_scalar__step_2
.Lssa_utf8_scalar__step_116:
    leal (%rsi,%r10), %r8d
    cmpq 8(%rax), %r8
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%r8), %ebx
.Lssa_utf8_scalar__step_115:
    .loc 20 158 3
    cmpq $128, %rbx
    jl .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_114:
    cmpq $192, %rbx
    jge .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_110:
    .loc 20 221 7
    addq $1, %r10
    cmpq %r9, %r10
    jl .Lssa_utf8_scalar__step_118
.Lssa_utf8_scalar__step_3:
    .loc 20 223 3
    movq %r9, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_2:
    .loc 20 216 7
    movq %r10, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_utf8_scalar__step_1:
    .loc 20 219 7
    movq %r10, %rax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_deflate____ReadPhase__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_deflate____ReadPhase__eq.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_deflate____ReadPhase__eq_0:
    movq 0(%rax), %rdi
    cmpq $.S173, %rdi
    jne .Lssa_deflate____ReadPhase__eq_20
.Lssa_deflate____ReadPhase__eq_24:
    movq 0(%rsi), %r8
    movl $1, %r9d
    xorl %r10d, %r10d
    cmpq $.S173, %r8
    movq %r9, %rax
    cmovneq %r10, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_deflate____ReadPhase__eq_20:
    cmpq $.S174, %rdi
    jne .Lssa_deflate____ReadPhase__eq_15
.Lssa_deflate____ReadPhase__eq_19:
    movq 0(%rsi), %r10
    movl $1, %r9d
    xorl %r8d, %r8d
    cmpq $.S174, %r10
    movq %r9, %rax
    cmovneq %r8, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_deflate____ReadPhase__eq_15:
    cmpq $.S175, %rdi
    jne .Lssa_deflate____ReadPhase__eq_10
.Lssa_deflate____ReadPhase__eq_14:
    movq 0(%rsi), %r8
    movl $1, %r9d
    xorl %r10d, %r10d
    cmpq $.S175, %r8
    movq %r9, %rax
    cmovneq %r10, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_deflate____ReadPhase__eq_10:
    cmpq $.S176, %rdi
    jne .Lssa_deflate____ReadPhase__eq_4
.Lssa_deflate____ReadPhase__eq_9:
    movq 0(%rsi), %r10
    movl $1, %r9d
    xorl %edi, %edi
    cmpq $.S176, %r10
    movq %r9, %rax
    cmovneq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_deflate____ReadPhase__eq_4:
    movq 0(%rsi), %rdi
    movl $1, %esi
    xorl %r9d, %r9d
    cmpq $.S177, %rdi
    movq %rsi, %rax
    cmovneq %r9, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_codec__DecodeErrorKind__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_codec__DecodeErrorKind__eq.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa_codec__DecodeErrorKind__eq_0:
    movq 0(%rax), %rdi
    cmpq $.S178, %rdi
    jne .Lssa_codec__DecodeErrorKind__eq_15
.Lssa_codec__DecodeErrorKind__eq_19:
    movq 8(%rax), %r8
    movq 0(%rsi), %r9
    cmpq $.S178, %r9
    jne .Lssa_codec__DecodeErrorKind__eq_16
.Lssa_codec__DecodeErrorKind__eq_18:
    movq 8(%rsi), %r9
    movq %r8, %rax
    cmpq %r9, %rax
    sete %al
    movzbq %al, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_codec__DecodeErrorKind__eq_16:
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_codec__DecodeErrorKind__eq_15:
    cmpq $.S179, %rdi
    jne .Lssa_codec__DecodeErrorKind__eq_10
.Lssa_codec__DecodeErrorKind__eq_14:
    movq 0(%rsi), %r9
    movl $1, %r8d
    xorl %r10d, %r10d
    cmpq $.S179, %r9
    movq %r8, %rax
    cmovneq %r10, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_codec__DecodeErrorKind__eq_10:
    cmpq $.S180, %rdi
    jne .Lssa_codec__DecodeErrorKind__eq_4
.Lssa_codec__DecodeErrorKind__eq_9:
    movq 0(%rsi), %r10
    movl $1, %r8d
    xorl %edi, %edi
    cmpq $.S180, %r10
    movq %r8, %rax
    cmovneq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_codec__DecodeErrorKind__eq_4:
    movq 0(%rsi), %rdi
    movl $1, %esi
    xorl %r8d, %r8d
    cmpq $.S181, %rdi
    movq %rsi, %rax
    cmovneq %r8, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_codec__DecodeError__eq:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn_codec__DecodeError__eq.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa_codec__DecodeError__eq_0:
    movq 8(%rbx), %rsi
    movq 8(%r12), %rdi
    movq 8(%rsi), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_codec__DecodeError__eq_streqn36
    movq %rdi, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_codec__DecodeError__eq_streqd36
.Lssa_codec__DecodeError__eq_streqn36:
    xorl %eax, %eax
.Lssa_codec__DecodeError__eq_streqd36:
    testq %rax, %rax
    jz .Lssa_codec__DecodeError__eq_19
.Lssa_codec__DecodeError__eq_26:
    movq 16(%rbx), %rdi
    movq 16(%r12), %rsi
    cmpq %rsi, %rdi
    jne .Lssa_codec__DecodeError__eq_19
.Lssa_codec__DecodeError__eq_23:
    movq 24(%rbx), %rsi
    movq 24(%r12), %rdi
.Lssa_codec__DecodeError__eq_22:
    movq 0(%rsi), %r8
    cmpq $.S178, %r8
    jne .Lssa_codec__DecodeError__eq_16
.Lssa_codec__DecodeError__eq_21:
    movq 8(%rsi), %r9
    movq 0(%rdi), %rsi
    cmpq $.S178, %rsi
    jne .Lssa_codec__DecodeError__eq_17
.Lssa_codec__DecodeError__eq_20:
    movq 8(%rdi), %rsi
    movq %r9, %rax
    cmpq %rsi, %rax
    sete %al
    movzbq %al, %rax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_19:
    xorl %eax, %eax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_17:
    xorl %eax, %eax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_16:
    cmpq $.S179, %r8
    jne .Lssa_codec__DecodeError__eq_11
.Lssa_codec__DecodeError__eq_15:
    movq 0(%rdi), %rsi
    cmpq $.S179, %rsi
    jne .Lssa_codec__DecodeError__eq_12
.Lssa_codec__DecodeError__eq_14:
    movl $1, %eax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_12:
    xorl %eax, %eax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_11:
    cmpq $.S180, %r8
    jne .Lssa_codec__DecodeError__eq_5
.Lssa_codec__DecodeError__eq_10:
    movq 0(%rdi), %rsi
    cmpq $.S180, %rsi
    jne .Lssa_codec__DecodeError__eq_7
.Lssa_codec__DecodeError__eq_9:
    movl $1, %eax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_7:
    xorl %eax, %eax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_5:
    movq 0(%rdi), %rsi
    cmpq $.S181, %rsi
    jne .Lssa_codec__DecodeError__eq_2
.Lssa_codec__DecodeError__eq_4:
    movl $1, %eax
    jmp .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_2:
    xorl %eax, %eax
.Lssa_codec__DecodeError__eq_1:
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_main:
    .cfi_startproc
__fn_main.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $168, %rsp
.Lssa_main_0:
    .loc 1 4 3 prologue_end
    leaq .SB182(%rip), %r11
    movq %r11, -48(%rbp)
    .loc 1 5 3
.Lssa_main_41:
    xorps %xmm2, %xmm2
    movups %xmm2, -64(%rbp)
.Lssa_main_42:
    cmpq $4000, -64(%rbp)
    jge .Lssa_main_40
.Lssa_main_396:
    .loc 2 2380 3
    pushq -48(%rbp)
    call __fn___fern_str_bytes_u8
    addq $8, %rsp
    movq %rax, %r14
.Lssa_main_394:
    .loc 2 737 3
    .loc 2 1789 3
    .loc 2 1805 3
    leaq .SB6(%rip), %r11
    movq %r11, -72(%rbp)
    leaq .SB6(%rip), %r11
    movq %r11, -80(%rbp)
    .loc 6 90 3
    leaq .K1(%rip), %r11
    movq %r11, -88(%rbp)
.Lssa_main_392:
    movq 0(%r14), %rsi
    cmpq $1, %rsi
    jle .Lssa_main_388
.Lssa_main_391:
    .loc 2 1789 3
    movzbl 8(%r14), %esi
    cmpq $13, %rsi
    jne .Lssa_main_388
.Lssa_main_390:
    movzbl 9(%r14), %esi
    cmpq $10, %rsi
    jne .Lssa_main_388
.Lssa_main_389:
    .loc 2 2315 5
    movq $2, -96(%rbp)
    jmp .Lssa_main_387
.Lssa_main_388:
    movq $0, -96(%rbp)
.Lssa_main_387:
    .loc 2 970 3
    movq 0(%r14), %r11
    movq %r11, -104(%rbp)
    movq -96(%rbp), %r11
    cmpq -104(%rbp), %r11
    jl .Lssa_main_384
.Lssa_main_415:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_1
.Lssa_main_384:
    .loc 2 971 3
    movq -96(%rbp), %rsi
    addq $8192, %rsi
    addq $2, %rsi
    movslq %esi, %r11
    movq %r11, -112(%rbp)
    .loc 2 972 3
    movq -96(%rbp), %rsi
    addq $32768, %rsi
    addq $4, %rsi
    movslq %esi, %r11
    movq %r11, -120(%rbp)
    cmpq -104(%rbp), %r11
    cmovgeq -104(%rbp), %r11
    movq %r11, -128(%rbp)
    .loc 2 977 3
    .loc 2 978 3
    .loc 2 979 3
    .loc 2 981 3
    .loc 2 983 3
    leaq .K11(%rip), %rsi
    movq %rsi, %rdx
    movq -96(%rbp), %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L78
    xorq %rcx, %rcx
.L78:
    leaq .S183(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L81
    vpbroadcastb 352(%r11), %ymm2
    vpbroadcastb 353(%r11), %ymm3
.L79:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L85
    vmovdqu (%r9), %ymm0
    vpcmpeqb %ymm2, %ymm0, %ymm1
    vpcmpeqb %ymm3, %ymm0, %ymm8
    vpor %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L80
    addq $32, %r9
    jmp .L79
.L85:
    cmpq %r10, %r9
    jg .L86
    vmovdqu (%r9), %xmm0
    vpcmpeqb %xmm2, %xmm0, %xmm1
    vpcmpeqb %xmm3, %xmm0, %xmm8
    vpor %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L80
    addq $16, %r9
.L86:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L81
.L80:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L84
.L81:
    cmpq %r8, %rcx
    jge .L83
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L82
    addq $1, %rcx
    jmp .L81
.L82:
    pushq %rcx
    jmp .L84
.L83:
    pushq %r8
.L84:
    popq %rax
.Lssa_main_380:
    cmpq -128(%rbp), %rax
    jl .Lssa_main_377
.Lssa_main_379:
    .loc 2 1017 5
    movl $2, %edi
    jmp .Lssa_main_367
.Lssa_main_377:
    cmpq (%r14), %rax
    jae __fern_oob_abort
    movzbl 8(%r14,%rax), %esi
    cmpq $10, %rsi
    je .Lssa_main_374
.Lssa_main_376:
    leaq 1(%rax), %rsi
    movq 0(%r14), %rdi
    cmpq %rdi, %rsi
    jge .Lssa_main_372
.Lssa_main_375:
    leaq 1(%rax), %rdi
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %esi
    cmpq $10, %rsi
    je .Lssa_main_372
.Lssa_main_374:
    .loc 2 1020 5
    movl $1, %edi
    jmp .Lssa_main_367
.Lssa_main_372:
    leaq 1(%rax), %rsi
    movq 0(%r14), %rdi
    cmpq %rdi, %rsi
    jl .Lssa_main_369
.Lssa_main_371:
    .loc 2 1023 5
    movl $2, %edi
    jmp .Lssa_main_367
.Lssa_main_369:
    .loc 2 1025 3
    xorl %edi, %edi
.Lssa_main_368:
.Lssa_main_367:
    movq -96(%rbp), %rsi
    movq -96(%rbp), %r10
    movq %rdi, %r15
    movq $-1, %rdi
    xorl %r8d, %r8d
    xorl %r9d, %r9d
.Lssa_main_447:
    cmpq $2, %r15
    jne .Lssa_main_473
.Lssa_main_475:
    movq %rdi, %r13
    movq $-1, %r15
    jmp .Lssa_main_362
.Lssa_main_473:
    cmpq $1, %r15
    jne .Lssa_main_471
.Lssa_main_472:
    .loc 2 989 9
    leaq 1(%rax), %rcx
    movslq %ecx, %r15
    .loc 2 987 12
    .loc 2 988 18
    movq %rdi, -136(%rbp)
    movq %r15, %rbx
    movq %r15, %r13
    movq $1, -144(%rbp)
    xorl %r15d, %r15d
    jmp .Lssa_main_461
.Lssa_main_471:
    cmpq $-1, %rdi
    jne .Lssa_main_465
.Lssa_main_470:
    .loc 2 993 20
    leaq 1(%rax), %rcx
    movslq %ecx, %r15
.Lssa_main_469:
    cmpq -112(%rbp), %r15
    jl .Lssa_main_466
.Lssa_main_468:
    .loc 2 1030 5
    movq $-2, %rdi
.Lssa_main_467:
    jmp .Lssa_main_465
.Lssa_main_466:
    movq %rax, %rdi
.Lssa_main_465:
    cmpq %rsi, %rax
    jne .Lssa_main_462
.Lssa_main_464:
    testq %r9, %r9
    jnz .Lssa_main_366
.Lssa_main_462:
    .loc 2 1000 9
    leaq 2(%rax), %r9
    movslq %r9d, %r9
    .loc 2 999 18
    movq %rdi, -136(%rbp)
    movq %r8, -144(%rbp)
    movq %r9, %rbx
    movq %r9, %r13
    movl $1, %r15d
.Lssa_main_461:
    .loc 2 1003 7
    leaq .K11(%rip), %r9
    movq %r9, %rdx
    movq %r13, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L87
    xorq %rcx, %rcx
.L87:
    leaq .S183(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L90
    vpbroadcastb 352(%r11), %ymm2
    vpbroadcastb 353(%r11), %ymm3
.L88:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L94
    vmovdqu (%r9), %ymm0
    vpcmpeqb %ymm2, %ymm0, %ymm1
    vpcmpeqb %ymm3, %ymm0, %ymm8
    vpor %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L89
    addq $32, %r9
    jmp .L88
.L94:
    cmpq %r10, %r9
    jg .L95
    vmovdqu (%r9), %xmm0
    vpcmpeqb %xmm2, %xmm0, %xmm1
    vpcmpeqb %xmm3, %xmm0, %xmm8
    vpor %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L89
    addq $16, %r9
.L95:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L90
.L89:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L93
.L90:
    cmpq %r8, %rcx
    jge .L92
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L91
    addq $1, %rcx
    jmp .L90
.L91:
    pushq %rcx
    jmp .L93
.L92:
    pushq %r8
.L93:
    popq %rax
.Lssa_main_460:
    cmpq -128(%rbp), %rax
    jl .Lssa_main_457
.Lssa_main_459:
    .loc 2 1017 5
    movl $2, %esi
    jmp .Lssa_main_448
.Lssa_main_457:
    cmpq (%r14), %rax
    jae __fern_oob_abort
    movzbl 8(%r14,%rax), %r9d
    cmpq $10, %r9
    je .Lssa_main_454
.Lssa_main_456:
    leaq 1(%rax), %r9
    movq 0(%r14), %rsi
    cmpq %rsi, %r9
    jge .Lssa_main_452
.Lssa_main_455:
    leaq 1(%rax), %rsi
    cmpq (%r14), %rsi
    jae __fern_oob_abort
    movzbl 8(%r14,%rsi), %r9d
    cmpq $10, %r9
    je .Lssa_main_452
.Lssa_main_454:
    .loc 2 1020 5
    movl $1, %esi
    jmp .Lssa_main_448
.Lssa_main_452:
    leaq 1(%rax), %r9
    movq 0(%r14), %rsi
    cmpq %rsi, %r9
    jl .Lssa_main_449
.Lssa_main_451:
    .loc 2 1023 5
    movl $2, %esi
    jmp .Lssa_main_448
.Lssa_main_449:
    .loc 2 1025 3
    xorl %esi, %esi
.Lssa_main_448:
    movq -136(%rbp), %rdi
    movq -144(%rbp), %r8
    movq %r15, %r9
    movq %r13, %r10
    movq %rsi, %r15
    movq %rbx, %rsi
    cmpq $2, %r15
    je .Lssa_main_475
    jmp .Lssa_main_473
.Lssa_main_366:
    .loc 2 996 21
    leaq -2(%rax), %rsi
    movslq %esi, %rsi
    addq $1, %rax
    movslq %eax, %rax
.Lssa_main_365:
    cmpq -120(%rbp), %rax
    jl .Lssa_main_363
.Lssa_main_364:
    .loc 2 1030 5
    movq %rdi, %r13
    movq $-2, %r15
    jmp .Lssa_main_362
.Lssa_main_363:
    movq %rdi, %r13
    movq %rsi, %r15
.Lssa_main_362:
    cmpq $-1, %r13
    jne .Lssa_main_356
.Lssa_main_360:
    .loc 2 1036 3
    movq 0(%r14), %rbx
    movq -112(%rbp), %r11
    cmpq -128(%rbp), %r11
    jle .Lssa_main_349
.Lssa_main_359:
    cmpq %rbx, -128(%rbp)
    jge .Lssa_main_349
.Lssa_main_358:
    cmpq %rbx, -112(%rbp)
    movq -112(%rbp), %rdi
    cmovgeq %rbx, %rdi
    .loc 2 1042 5
    movq %r8, -184(%rbp)
    movq %r14, %rax
    movq %r10, %rsi
    call __fn_http____find_crlf.r
    movq -184(%rbp), %r8
    cmpq $0, %rax
    jl .Lssa_main_349
    jmp .Lssa_main_353
.Lssa_main_356:
    movq %r13, -112(%rbp)
    jmp .Lssa_main_345
.Lssa_main_353:
    movq %rax, -112(%rbp)
    jmp .Lssa_main_345
.Lssa_main_349:
    cmpq -112(%rbp), %rbx
    jl .Lssa_main_346
.Lssa_main_348:
    .loc 2 1048 5
    movq $-2, -112(%rbp)
    jmp .Lssa_main_345
.Lssa_main_346:
    .loc 2 1050 3
    movq $-1, -112(%rbp)
.Lssa_main_345:
    cmpq $-1, %r15
    jne .Lssa_main_342
.Lssa_main_344:
    movq -104(%rbp), %r11
    cmpq -120(%rbp), %r11
    jl .Lssa_main_342
.Lssa_main_343:
    .loc 2 1010 17
    movq $-2, -104(%rbp)
    jmp .Lssa_main_339
.Lssa_main_342:
    movq %r15, -104(%rbp)
.Lssa_main_341:
.Lssa_main_339:
    cmpq $-2, -112(%rbp)
    jne .Lssa_main_336
.Lssa_main_338:
    .loc 2 1965 5
    movl $414, %r8d
    jmp .Lssa_main_329
.Lssa_main_336:
    cmpq $-2, -104(%rbp)
    jne .Lssa_main_333
.Lssa_main_335:
    .loc 2 1968 5
    movl $431, %r8d
    jmp .Lssa_main_329
.Lssa_main_333:
    testq %r8, %r8
    jz .Lssa_main_330
.Lssa_main_332:
    .loc 2 1971 5
    movl $400, %r8d
    jmp .Lssa_main_329
.Lssa_main_330:
    .loc 2 1973 3
    xorl %r8d, %r8d
.Lssa_main_329:
    cmpq $0, %r8
    je .Lssa_main_327
.Lssa_main_584:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_1
.Lssa_main_327:
    .loc 2 1917 3
    leaq .SB6(%rip), %rbx
    cmpq $0, -112(%rbp)
    jl .Lssa_main_321
.Lssa_main_325:
    .loc 2 1395 3
    leaq .K8(%rip), %r8
    movq %r8, %rdx
    movq -96(%rbp), %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L96
    xorq %rcx, %rcx
.L96:
    leaq .S70(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L99
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L97:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L103
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L98
    addq $32, %r9
    jmp .L97
.L103:
    cmpq %r10, %r9
    jg .L104
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L98
    addq $16, %r9
.L104:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L99
.L98:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L102
.L99:
    cmpq %r8, %rcx
    jge .L101
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L100
    addq $1, %rcx
    jmp .L99
.L100:
    pushq %rcx
    jmp .L102
.L101:
    pushq %r8
.L102:
    popq %rax
    cmpq -112(%rbp), %rax
    movq -112(%rbp), %r8
    cmovleq %rax, %r8
    cmpq -96(%rbp), %r8
    je .Lssa_main_322
.Lssa_main_324:
    cmpq -112(%rbp), %r8
    jge .Lssa_main_322
.Lssa_main_323:
    cmpq (%r14), %r8
    jae __fern_oob_abort
    movzbl 8(%r14,%r8), %edi
    cmpq $32, %rdi
    je .Lssa_main_319
.Lssa_main_322:
    .loc 2 1761 5
    leaq .SB6(%rip), %rdi
    movq %rdi, %r8
    movl $400, %eax
    movq $-1, %rbx
    movq $-1, %r13
    jmp .Lssa_main_262
.Lssa_main_321:
    movq %rbx, -128(%rbp)
    movq $-1, -80(%rbp)
    movq $-1, -120(%rbp)
    jmp .Lssa_main_260
.Lssa_main_319:
    .loc 2 1763 3
    leaq 1(%r8), %rdi
.Lssa_main_318:
    movl $32, %r10d
    .loc 2 693 3
    movq %r8, -184(%rbp)
    movq %rdi, %rdx
    movq %r10, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L105
    xorq %rdx, %rdx
.L105:
    cmpq $255, %rcx
    ja .L109
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L113
.L111:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L112
    addq $32, %r9
    cmpq %r10, %r9
    jle .L111
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L113
.L112:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L110
.L113:
    vzeroupper
.L106:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L108
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L107
    addq $16, %rdx
    jmp .L106
.L107:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L110
.L108:
    cmpq %r8, %rdx
    jge .L109
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L114
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L109
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L109
    addq %r9, %rdx
    jmp .L110
.L114:
    cmpq %r8, %rdx
    jge .L109
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L110
    addq $1, %rdx
    jmp .L114
.L109:
    movq $-1, %rdx
.L110:
    movq %rdx, %rax
    movq -184(%rbp), %r8
    .loc 2 697 3
    movq $-1, %r10
    cmpq -112(%rbp), %rax
    movq %rax, %rbx
    cmovgeq %r10, %rbx
    cmpq $0, %rbx
    jl .Lssa_main_312
.Lssa_main_313:
    leaq 1(%r8), %r10
    cmpq %r10, %rbx
    jne .Lssa_main_310
.Lssa_main_312:
    .loc 2 1765 5
    leaq .SB6(%rip), %r10
    movq %r10, %r8
    movl $400, %eax
    movq $-1, %rbx
    movq $-1, %r13
    jmp .Lssa_main_262
.Lssa_main_310:
    .loc 2 1767 3
    leaq 1(%rbx), %r10
    movslq %r10d, %r10
.Lssa_main_309:
    movq -112(%rbp), %rdi
    subq %r10, %rdi
    movslq %edi, %rdi
    cmpq $8, %rdi
    jne .Lssa_main_307
.Lssa_main_308:
    leaq .K12(%rip), %rdi
    xorl %esi, %esi
    movl $5, %r9d
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r14, %rax
    movq %rsi, %r8
    movq %r10, %rsi
    call __fn___sem_byte_view_mismatch.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    cmpq $5, %rax
    je .Lssa_main_305
.Lssa_main_307:
    .loc 2 2327 5
    movl $400, %esi
    jmp .Lssa_main_288
.Lssa_main_305:
    leal 5(%r10), %r9d
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %esi
.Lssa_main_304:
    .loc 2 2346 3
    cmpq $48, %rsi
    jb .Lssa_main_291
.Lssa_main_303:
    cmpq $57, %rsi
    ja .Lssa_main_291
.Lssa_main_300:
    leal 6(%r10), %esi
    cmpq (%r14), %rsi
    jae __fern_oob_abort
    movzbl 8(%r14,%rsi), %r9d
    cmpq $46, %r9
    jne .Lssa_main_291
.Lssa_main_299:
    leal 7(%r10), %r9d
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %esi
.Lssa_main_298:
    cmpq $48, %rsi
    jb .Lssa_main_291
.Lssa_main_297:
    cmpq $57, %rsi
    ja .Lssa_main_291
.Lssa_main_293:
    addl $5, %r10d
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movzbl 8(%r14,%r10), %esi
    cmpq $49, %rsi
    je .Lssa_main_289
.Lssa_main_292:
    .loc 2 2333 5
    movl $505, %esi
    jmp .Lssa_main_288
.Lssa_main_291:
    .loc 2 2330 5
    movl $400, %esi
    jmp .Lssa_main_288
.Lssa_main_289:
    .loc 2 2335 3
    xorl %esi, %esi
.Lssa_main_288:
    cmpq $0, %rsi
    je .Lssa_main_285
.Lssa_main_287:
    .loc 2 1769 5
    leaq .SB6(%rip), %r10
    movq %rsi, %rax
    movq %r10, %r8
    movq $-1, %rbx
    movq $-1, %r13
    jmp .Lssa_main_262
.Lssa_main_285:
    .loc 2 1771 3
    leaq 1(%r8), %r10
    movq %r8, %rsi
    subq -96(%rbp), %rsi
    movslq %esi, %rsi
    cmpq $7, %rsi
    jne .Lssa_main_283
.Lssa_main_284:
    leaq .SB184(%rip), %r9
    .loc 2 2350 3
    movq 8(%r9), %rsi
    xorl %edi, %edi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %rsi, %r8
    movq %rdi, %rcx
    movq %r9, %rdx
    movq -96(%rbp), %rsi
    movq %r14, %rax
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L115_aop
    xorq %rsi, %rsi
.L115_aop:
    cmpq %r9, %rsi
    jle .L115_aok
    movq %r9, %rsi
.L115_aok:
    cmpq $0, %rcx
    jge .L115_bop
    xorq %rcx, %rcx
.L115_bop:
    cmpq %r10, %rcx
    jle .L115_bok
    movq %r10, %rcx
.L115_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L115_na
    movq %r9, %r8
.L115_na:
    cmpq %r10, %r8
    jle .L115_nb
    movq %r10, %r8
.L115_nb:
    cmpq $0, %r8
    jge .L115_nok
    xorq %r8, %r8
.L115_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L115_vec
    cmpq $8, %r8
    jge .L115_w8
    cmpq $4, %r8
    jge .L115_w4
    cmpq $2, %r8
    jge .L115_w2
    jmp .L115_tail
.L115_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L115_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L115_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L115_done
.L115_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L115_done
.L115_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L115_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L115_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L115_done
.L115_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L115_done
.L115_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L115_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L115_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L115_done
.L115_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L115_done
.L115_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L115_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L115_hit
    addq $16, %rdx
    jmp .L115_vec
.L115_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L115_done
.L115_tail:
    cmpq %r8, %rdx
    jge .L115_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L115_th
    addq $1, %rdx
    jmp .L115_tail
.L115_th:
    movq %rdx, %rax
    jmp .L115_done
.L115_eq:
    movq %r8, %rax
.L115_done:
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq 8(%r9), %rdi
    cmpq %rdi, %rax
    sete %al
    movzbq %al, %rax
    jmp .Lssa_main_281
.Lssa_main_283:
    xorl %eax, %eax
.Lssa_main_282:
.Lssa_main_281:
    .loc 2 2022 3
    movq %r8, -184(%rbp)
    movq %r10, %rsi
    movq %rbx, %rdi
    movq %rax, %r8
    movq %r14, %rax
    call __fn_http____target_start.r
    movq %rax, %r9
    movq -184(%rbp), %r8
    cmpq $-2, %r9
    jne .Lssa_main_278
.Lssa_main_280:
    .loc 2 2024 5
    movl $400, %eax
    jmp .Lssa_main_263
.Lssa_main_278:
    cmpq $-1, %r9
    jne .Lssa_main_275
.Lssa_main_277:
    .loc 2 2027 5
    leaq .SB185(%rip), %r10
    movq %r10, %rax
    jmp .Lssa_main_266
.Lssa_main_275:
    .loc 2 2029 3
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r14, %rax
    movq %r9, %rsi
    movq %rbx, %rdi
    call __fn_http____path_end.r
    movq %rax, %r10
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    cmpq $0, %r10
    jge .Lssa_main_272
.Lssa_main_274:
    .loc 2 2031 5
    movl $400, %eax
    jmp .Lssa_main_263
.Lssa_main_272:
    cmpq %r10, %r9
    jge .Lssa_main_268
.Lssa_main_271:
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r14, %rax
    movq %r9, %rsi
    movq %r10, %rdi
    call __fn_http____plain_path.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    testq %rax, %rax
    jz .Lssa_main_268
.Lssa_main_270:
    .loc 2 2034 5
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r14, %rax
    movq %r9, %rsi
    movq %rbx, %rdi
    movq -80(%rbp), %r8
    call __fn_http____shared_string.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    jmp .Lssa_main_266
.Lssa_main_268:
    movq %r8, -184(%rbp)
    movq %r14, %rax
    movq %r9, %rsi
    movq %r10, %rdi
    movq %rbx, %r8
    call __fn_http____decoded_path.r
    movq %rax, %r13
    movq -184(%rbp), %r8
    movq %r8, -184(%rbp)
    movq %rdx, %rax
    movq -184(%rbp), %r8
    cmpq $0, %r13
    jne .Lssa_main_263
.Lssa_main_267:
.Lssa_main_266:
    .loc 2 1773 7
    movq %rbx, %r13
    movq %r8, %rbx
    movq %rax, %r8
    xorl %eax, %eax
    jmp .Lssa_main_262
.Lssa_main_265:
.Lssa_main_264:
.Lssa_main_263:
    .loc 2 1776 7
    leaq .SB6(%rip), %r8
    movq $-1, %rbx
    movq $-1, %r13
.Lssa_main_262:
    cmpq $0, %rax
    je .Lssa_main_261
.Lssa_main_705:
    movq %r8, -184(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq %r8, -184(%rbp)
    movq %r8, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
    jmp .Lssa_main_1
.Lssa_main_261:
    movq %rbx, -80(%rbp)
    movq %r13, -120(%rbp)
    movq %r8, -128(%rbp)
.Lssa_main_260:
    cmpq $0, -112(%rbp)
    jge .Lssa_main_259
.Lssa_main_709:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_main_1
.Lssa_main_259:
    cmpq $0, -104(%rbp)
    jge .Lssa_main_257
.Lssa_main_713:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_main_1
.Lssa_main_257:
    .loc 2 1930 3
    movq -104(%rbp), %r8
    addq $4, %r8
    movq %r8, %r11
    subq -96(%rbp), %r11
    movq %r11, -136(%rbp)
    .loc 2 1931 3
    movq -112(%rbp), %r8
    addq $2, %r8
    movslq %r8d, %r8
    cmpq -104(%rbp), %r8
    movq -104(%rbp), %rsi
    cmovleq %r8, %rsi
.Lssa_main_253:
    .loc 6 90 3
    leaq .K1(%rip), %rax
    .loc 2 871 3
    .loc 2 872 3
.Lssa_main_252:
    movq %rax, %r13
    movq %rsi, -152(%rbp)
    movq $1, -112(%rbp)
    movq $0, -144(%rbp)
.Lssa_main_722:
    movq -152(%rbp), %r11
    cmpq -104(%rbp), %r11
    jge .Lssa_main_251
.Lssa_main_776:
    .loc 2 1395 3
    leaq .K8(%rip), %rsi
    movq %rsi, %rdx
    movq -152(%rbp), %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L116
    xorq %rcx, %rcx
.L116:
    leaq .S70(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L119
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L117:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L123
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L118
    addq $32, %r9
    jmp .L117
.L123:
    cmpq %r10, %r9
    jg .L124
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L118
    addq $16, %r9
.L124:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L119
.L118:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L122
.L119:
    cmpq %r8, %rcx
    jge .L121
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L120
    addq $1, %rcx
    jmp .L119
.L120:
    pushq %rcx
    jmp .L122
.L121:
    pushq %r8
.L122:
    popq %rax
    cmpq -104(%rbp), %rax
    movq -104(%rbp), %r8
    cmovleq %rax, %r8
    cmpq -152(%rbp), %r8
    je .Lssa_main_773
.Lssa_main_775:
    cmpq -104(%rbp), %r8
    jge .Lssa_main_773
.Lssa_main_774:
    cmpq (%r14), %r8
    jae __fern_oob_abort
    movzbl 8(%r14,%r8), %esi
    cmpq $58, %rsi
    je .Lssa_main_771
.Lssa_main_773:
    .loc 2 926 5
    movq -104(%rbp), %r10
    movq $-1, -160(%rbp)
    jmp .Lssa_main_759
.Lssa_main_771:
    .loc 2 928 3
    leaq 1(%r8), %rsi
.Lssa_main_770:
    .loc 2 701 3
    movl $13, %r10d
    movq %r8, -184(%rbp)
    movq %rsi, %rdx
    movq %r10, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L125
    xorq %rdx, %rdx
.L125:
    cmpq $255, %rcx
    ja .L129
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L133
.L131:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L132
    addq $32, %r9
    cmpq %r10, %r9
    jle .L131
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L133
.L132:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L130
.L133:
    vzeroupper
.L126:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L128
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L127
    addq $16, %rdx
    jmp .L126
.L127:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L130
.L128:
    cmpq %r8, %rdx
    jge .L129
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L134
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L129
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L129
    addq %r9, %rdx
    jmp .L130
.L134:
    cmpq %r8, %rdx
    jge .L129
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L130
    addq $1, %rdx
    jmp .L134
.L129:
    movq $-1, %rdx
.L130:
    movq %rdx, %rax
    movq -184(%rbp), %r8
    cmpq $0, %rax
    jl .Lssa_main_768
.Lssa_main_769:
    cmpq -104(%rbp), %rax
    jl .Lssa_main_766
.Lssa_main_768:
    movq -104(%rbp), %rax
    jmp .Lssa_main_762
.Lssa_main_766:
    leaq 1(%rax), %r10
    cmpq -104(%rbp), %r10
    jge .Lssa_main_764
.Lssa_main_765:
    leaq 1(%rax), %r10
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movzbl 8(%r14,%r10), %esi
    cmpq $10, %rsi
    je .Lssa_main_762
.Lssa_main_764:
    .loc 2 706 5
    movq $-1, %rax
.Lssa_main_763:
.Lssa_main_762:
    cmpq $0, %rax
    jge .Lssa_main_760
.Lssa_main_761:
    .loc 2 930 5
    movq -104(%rbp), %r10
    movq $-1, -160(%rbp)
    jmp .Lssa_main_759
.Lssa_main_760:
    movq %r8, -160(%rbp)
    movq %rax, %r10
.Lssa_main_759:
    cmpq $0, -160(%rbp)
    jge .Lssa_main_757
.Lssa_main_827:
    movq %r10, -184(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_757:
    .loc 2 881 11
    movq -144(%rbp), %rsi
    addq $1, %rsi
    movslq %esi, %r11
    movq %r11, -144(%rbp)
    cmpq $100, %r11
    jle .Lssa_main_755
.Lssa_main_831:
    movq %r10, -184(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_755:
    .loc 2 885 5
    movq -144(%rbp), %rsi
    subq $1, %rsi
    movslq %esi, %r12
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_748
.Lssa_main_754:
    movq -88(%rbp), %r11
    movq 8(%r11), %rsi
    movq 0(%rsi), %rdi
    cmpq %rdi, %r12
    jl .Lssa_main_748
.Lssa_main_753:
    cmpq $0, %r12
    jle .Lssa_main_750
.Lssa_main_843:
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
.Lssa_main_752:
    movq -88(%rbp), %r11
    testb $1, %r11b
    jnz .Lssa_main_rcinc3588
    cmpq $0x10000, %r11
    jb .Lssa_main_rcinc3588
    movl -8(%r11), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc3588
    addl $1, %ecx
    movl %ecx, -8(%r11)
.Lssa_main_rcinc3588:
    .loc 2 888 11
    movq %r10, -184(%rbp)
    movq -88(%rbp), %rax
    movq %r12, %rsi
    call __fn_http____leading_fields.r
    movq -184(%rbp), %r10
    movq %rax, %r13
.Lssa_main_751:
.Lssa_main_750:
    .loc 2 890 12
    movq $0, -112(%rbp)
.Lssa_main_749:
.Lssa_main_748:
    .loc 2 892 5
    movq $-1, %rdi
    movq -112(%rbp), %r11
    testq %r11, %r11
    movq %r12, %r11
    cmoveq %rdi, %r11
    movq %r11, -168(%rbp)
    .loc 2 896 5
    movq -160(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %rdi
.Lssa_main_744:
    movq %rdi, %r8
.Lssa_main_854:
    cmpq %r10, %r8
    jge .Lssa_main_742
.Lssa_main_860:
    cmpq (%r14), %r8
    jae __fern_oob_abort
    movzbl 8(%r14,%r8), %edi
.Lssa_main_859:
    .loc 2 838 3
    cmpq $32, %rdi
    je .Lssa_main_855
.Lssa_main_857:
    cmpq $9, %rdi
    jne .Lssa_main_742
.Lssa_main_855:
    .loc 2 851 10
    addq $1, %r8
    cmpq %r10, %r8
    jl .Lssa_main_860
.Lssa_main_742:
    movq %r10, %rbx
.Lssa_main_876:
    cmpq %r8, %rbx
    jle .Lssa_main_741
.Lssa_main_882:
    leaq -1(%rbx), %rdi
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %esi
.Lssa_main_881:
    .loc 2 838 3
    cmpq $32, %rsi
    je .Lssa_main_877
.Lssa_main_879:
    cmpq $9, %rsi
    jne .Lssa_main_741
.Lssa_main_877:
    .loc 2 854 9
    subq $1, %rbx
    cmpq %r8, %rbx
    jg .Lssa_main_882
.Lssa_main_741:
    cmpq $0, -168(%rbp)
    jl .Lssa_main_736
.Lssa_main_740:
    movq -88(%rbp), %r11
    movq 16(%r11), %rsi
    movq -168(%rbp), %rcx
    cmpq (%rsi), %rcx
    jae __fern_oob_abort
    movq 8(%rsi,%rcx,8), %rdi
    movq 8(%rdi), %rsi
    movq %rbx, %rdi
    subq %r8, %rdi
    movslq %edi, %rdi
    cmpq %rdi, %rsi
    jne .Lssa_main_736
.Lssa_main_739:
    movq -88(%rbp), %r11
    movq 16(%r11), %r15
    movq -168(%rbp), %rcx
    cmpq (%r15), %rcx
    jae __fern_oob_abort
    movq 8(%r15,%rcx,8), %r9
    .loc 2 2350 3
    movq 8(%r9), %rdi
    xorl %esi, %esi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %rsi, %rcx
    movq %r9, %rdx
    movq %r8, %rsi
    movq %r14, %rax
    movq %rdi, %r8
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L135_aop
    xorq %rsi, %rsi
.L135_aop:
    cmpq %r9, %rsi
    jle .L135_aok
    movq %r9, %rsi
.L135_aok:
    cmpq $0, %rcx
    jge .L135_bop
    xorq %rcx, %rcx
.L135_bop:
    cmpq %r10, %rcx
    jle .L135_bok
    movq %r10, %rcx
.L135_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L135_na
    movq %r9, %r8
.L135_na:
    cmpq %r10, %r8
    jle .L135_nb
    movq %r10, %r8
.L135_nb:
    cmpq $0, %r8
    jge .L135_nok
    xorq %r8, %r8
.L135_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L135_vec
    cmpq $8, %r8
    jge .L135_w8
    cmpq $4, %r8
    jge .L135_w4
    cmpq $2, %r8
    jge .L135_w2
    jmp .L135_tail
.L135_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L135_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L135_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L135_done
.L135_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L135_done
.L135_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L135_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L135_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L135_done
.L135_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L135_done
.L135_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L135_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L135_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L135_done
.L135_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L135_done
.L135_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L135_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L135_hit
    addq $16, %rdx
    jmp .L135_vec
.L135_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L135_done
.L135_tail:
    cmpq %r8, %rdx
    jge .L135_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L135_th
    addq $1, %rdx
    jmp .L135_tail
.L135_th:
    movq %rdx, %rax
    jmp .L135_done
.L135_eq:
    movq %r8, %rax
.L135_done:
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq 8(%r9), %rsi
    cmpq %rsi, %rax
    jne .Lssa_main_736
.Lssa_main_738:
    .loc 2 857 5
    movq -168(%rbp), %rcx
    cmpq (%r15), %rcx
    jae __fern_oob_abort
    movq 8(%r15,%rcx,8), %rsi
    testb $1, %sil
    jnz .Lssa_main_rcinc3655
    cmpq $0x10000, %rsi
    jb .Lssa_main_rcinc3655
    movl -8(%rsi), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc3655
    addl $1, %ecx
    movl %ecx, -8(%rsi)
.Lssa_main_rcinc3655:
    movq %rsi, -168(%rbp)
    jmp .Lssa_main_732
.Lssa_main_736:
    leaq .K9(%rip), %rsi
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %rsi, %rdx
    movq %r8, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L136
    xorq %rcx, %rcx
.L136:
    leaq .S71(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L139
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L137:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L143
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L138
    addq $32, %r9
    jmp .L137
.L143:
    cmpq %r10, %r9
    jg .L144
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L138
    addq $16, %r9
.L144:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L139
.L138:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L142
.L139:
    cmpq %r8, %rcx
    jge .L141
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L140
    addq $1, %rcx
    jmp .L139
.L140:
    pushq %rcx
    jmp .L142
.L141:
    pushq %r8
.L142:
    popq %rax
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    cmpq %rbx, %rax
    jge .Lssa_main_734
.Lssa_main_911:
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_734:
    .loc 2 713 5
    movq %r10, -184(%rbp)
    movq %r14, %rax
    movq %r8, %rsi
    movq %rbx, %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r15
    movq -184(%rbp), %r10
.Lssa_main_915:
    movq %r10, -184(%rbp)
    movq %r15, %rax
    call __fn_utf8__is_valid.r
    movq -184(%rbp), %r10
    testq %rax, %rax
    jnz .Lssa_main_733
.Lssa_main_918:
    movq %r10, -184(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq %r15, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_733:
    movq %r15, -168(%rbp)
.Lssa_main_732:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_725
.Lssa_main_731:
    .loc 2 899 11
    movq -88(%rbp), %r11
    movq 8(%r11), %r8
    cmpq (%r8), %r12
    jae __fern_oob_abort
    movq 8(%r8,%r12,8), %rbx
    movq %r10, -184(%rbp)
    movq %r14, %rax
    movq -152(%rbp), %rsi
    movq -160(%rbp), %rdi
    movq %rbx, %r8
    call __fn_http____shared_string.r
    movq %rax, %r8
    movq -184(%rbp), %r10
    .loc 2 900 16
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq 8(%r8), %rdx
    cmpq 8(%rbx), %rdx
    jne .Lssa_main_streqn3693
    movq %r8, %rax
    movq %rbx, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd3693
.Lssa_main_streqn3693:
    xorl %eax, %eax
.Lssa_main_streqd3693:
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    testq %rax, %rax
    jz .Lssa_main_729
.Lssa_main_730:
    movq -88(%rbp), %r11
    movq 16(%r11), %rsi
    cmpq (%rsi), %r12
    jae __fern_oob_abort
    movq 8(%rsi,%r12,8), %r9
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -168(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%r9), %rdx
    jne .Lssa_main_streqn3696
    movq %r11, %rax
    movq %r9, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd3696
.Lssa_main_streqn3696:
    xorl %eax, %eax
.Lssa_main_streqd3696:
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %rax, -176(%rbp)
    jmp .Lssa_main_728
.Lssa_main_729:
    movq $0, -176(%rbp)
.Lssa_main_728:
    movq -176(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_931
.Lssa_main_930:
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r8, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -168(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    jmp .Lssa_main_727
.Lssa_main_931:
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    jmp .Lssa_main_726
.Lssa_main_727:
    movq -176(%rbp), %rcx
    movq %rcx, -112(%rbp)
    jmp .Lssa_main_723
.Lssa_main_726:
    movq -88(%rbp), %r11
    testb $1, %r11b
    jnz .Lssa_main_rcinc3703
    cmpq $0x10000, %r11
    jb .Lssa_main_rcinc3703
    movl -8(%r11), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc3703
    addl $1, %ecx
    movl %ecx, -8(%r11)
.Lssa_main_rcinc3703:
    .loc 2 902 15
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -88(%rbp), %rax
    movq %r12, %rsi
    call __fn_http____leading_fields.r
    movq %rax, %r9
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    testb $1, %r9b
    jnz .Lssa_main_uq726
    cmpq $0x10000, %r9
    jb .Lssa_main_uq726
    movl -8(%r9), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq726:
    jne .Lssa_main_936
.Lssa_main_935:
    movq %r9, %r12
    jmp .Lssa_main_937
.Lssa_main_936:
    xorl %r12d, %r12d
.Lssa_main_937:
    .loc 6 301 3
    movq 8(%r9), %rbx
    cmpq $0, %r12
    jne .Lssa_main_940
.Lssa_main_938:
    testb $1, %bl
    jnz .Lssa_main_rcinc3711
    cmpq $0x10000, %rbx
    jb .Lssa_main_rcinc3711
    movl -8(%rbx), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc3711
    addl $1, %ecx
    movl %ecx, -8(%rbx)
.Lssa_main_rcinc3711:
.Lssa_main_940:
    testb $1, %bl
    jnz .Lssa_main_uq940
    cmpq $0x10000, %rbx
    jb .Lssa_main_uq940
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq940:
    jne .Lssa_main_942
.Lssa_main_941:
    movq %rbx, %rdi
    movq %r8, %rsi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq %rax, %r15
    jmp .Lssa_main_943
.Lssa_main_942:
    movq %rbx, %rdi
    movq %r8, %rsi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %rax, %r15
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %rbx, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
.Lssa_main_943:
    movq 16(%r9), %rbx
    cmpq $0, %r12
    jne .Lssa_main_946
.Lssa_main_944:
    testb $1, %bl
    jnz .Lssa_main_rcinc3721
    cmpq $0x10000, %rbx
    jb .Lssa_main_rcinc3721
    movl -8(%rbx), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc3721
    addl $1, %ecx
    movl %ecx, -8(%rbx)
.Lssa_main_rcinc3721:
.Lssa_main_946:
    testb $1, %bl
    jnz .Lssa_main_uq946
    cmpq $0x10000, %rbx
    jb .Lssa_main_uq946
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq946:
    jne .Lssa_main_948
.Lssa_main_947:
    movq %rbx, %rdi
    movq -168(%rbp), %rsi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %rax, %rbx
    jmp .Lssa_main_949
.Lssa_main_948:
    movq %rbx, %rdi
    movq -168(%rbp), %rsi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %rax, %r8
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %rbx, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq %r8, %rbx
.Lssa_main_949:
    cmpq $0, %r12
    jne .Lssa_main_951
.Lssa_main_950:
    movl $3, %r8d
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r12, %rax
    movq %r8, %rsi
    call __fn___fern_alloc_reuse.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    leaq .S0(%rip), %r8
    movq %r8, 0(%rax)
    movq %rax, %r8
    jmp .Lssa_main_952
.Lssa_main_951:
    movq %r12, %r8
.Lssa_main_952:
    cmpq $0, %r12
    jne .Lssa_main_955
.Lssa_main_954:
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r9, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
.Lssa_main_955:
    movq %r15, 8(%r8)
    movq %rbx, 16(%r8)
    movq %r8, %r13
    movq -176(%rbp), %rcx
    movq %rcx, -112(%rbp)
    jmp .Lssa_main_723
.Lssa_main_725:
    .loc 2 713 5
    movq %r10, -184(%rbp)
    movq %r14, %rax
    movq -152(%rbp), %rsi
    movq -160(%rbp), %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r9
    movq -184(%rbp), %r10
.Lssa_main_957:
    testb $1, %r13b
    jnz .Lssa_main_uq957
    cmpq $0x10000, %r13
    jb .Lssa_main_uq957
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq957:
    jne .Lssa_main_960
.Lssa_main_959:
    movq %r13, %rbx
    jmp .Lssa_main_961
.Lssa_main_960:
    xorl %ebx, %ebx
.Lssa_main_961:
    .loc 6 301 3
    movq 8(%r13), %r15
    cmpq $0, %rbx
    jne .Lssa_main_964
.Lssa_main_962:
    testb $1, %r15b
    jnz .Lssa_main_rcinc3748
    cmpq $0x10000, %r15
    jb .Lssa_main_rcinc3748
    movl -8(%r15), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc3748
    addl $1, %ecx
    movl %ecx, -8(%r15)
.Lssa_main_rcinc3748:
.Lssa_main_964:
    testb $1, %r15b
    jnz .Lssa_main_uq964
    cmpq $0x10000, %r15
    jb .Lssa_main_uq964
    movl -8(%r15), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq964:
    jne .Lssa_main_966
.Lssa_main_965:
    movq %r15, %rdi
    movq %r9, %rsi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %rax, %r12
    jmp .Lssa_main_967
.Lssa_main_966:
    movq %r15, %rdi
    movq %r9, %rsi
    movq %r10, -184(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r10
    movq %rax, %r12
    movq %r10, -184(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r10
.Lssa_main_967:
    movq 16(%r13), %r15
    cmpq $0, %rbx
    jne .Lssa_main_970
.Lssa_main_968:
    testb $1, %r15b
    jnz .Lssa_main_rcinc3758
    cmpq $0x10000, %r15
    jb .Lssa_main_rcinc3758
    movl -8(%r15), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc3758
    addl $1, %ecx
    movl %ecx, -8(%r15)
.Lssa_main_rcinc3758:
.Lssa_main_970:
    testb $1, %r15b
    jnz .Lssa_main_uq970
    cmpq $0x10000, %r15
    jb .Lssa_main_uq970
    movl -8(%r15), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq970:
    jne .Lssa_main_972
.Lssa_main_971:
    movq %r15, %rdi
    movq -168(%rbp), %rsi
    movq %r10, -184(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r10
    movq %rax, %r15
    jmp .Lssa_main_973
.Lssa_main_972:
    movq %r15, %rdi
    movq -168(%rbp), %rsi
    movq %r10, -184(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r10
    movq %rax, %r9
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, %r15
.Lssa_main_973:
    cmpq $0, %rbx
    jne .Lssa_main_975
.Lssa_main_974:
    movl $3, %r9d
    movq %r10, -184(%rbp)
    movq %rbx, %rax
    movq %r9, %rsi
    call __fn___fern_alloc_reuse.r
    movq -184(%rbp), %r10
    leaq .S0(%rip), %r9
    movq %r9, 0(%rax)
    movq %rax, %r8
    jmp .Lssa_main_976
.Lssa_main_975:
    movq %rbx, %r8
.Lssa_main_976:
    cmpq $0, %rbx
    jne .Lssa_main_979
.Lssa_main_978:
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
.Lssa_main_979:
    movq %r12, 8(%r8)
    movq %r15, 16(%r8)
    movq %r8, %r13
.Lssa_main_724:
.Lssa_main_723:
    .loc 2 912 8
    addq $2, %r10
    movslq %r10d, %r11
    movq %r11, -152(%rbp)
    movq -152(%rbp), %r11
    cmpq -104(%rbp), %r11
    jl .Lssa_main_776
.Lssa_main_251:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_247
.Lssa_main_250:
    movq -88(%rbp), %r11
    movq 8(%r11), %r10
    movq 0(%r10), %r9
    cmpq %r9, -144(%rbp)
    jne .Lssa_main_247
.Lssa_main_986:
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_main_249:
    jmp .Lssa_main_243
.Lssa_main_247:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_245
.Lssa_main_991:
    movq %r13, %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_main_246:
    .loc 2 918 5
    movq -88(%rbp), %rax
    movq -144(%rbp), %rsi
    call __fn_http____leading_fields.r
    movq %rax, -88(%rbp)
    jmp .Lssa_main_243
.Lssa_main_245:
    movq %r13, -88(%rbp)
.Lssa_main_244:
.Lssa_main_243:
    .loc 2 1944 3
    movq -120(%rbp), %r9
    addq $1, %r9
.Lssa_main_242:
    addl $7, %r9d
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %r10d
    cmpq $48, %r10
    jne .Lssa_main_239
.Lssa_main_241:
    .loc 2 2340 5
    leaq .SB186(%rip), %r10
    movq %r10, -104(%rbp)
    jmp .Lssa_main_237
.Lssa_main_239:
    .loc 2 2342 3
    leaq .SB187(%rip), %r10
    movq %r10, -104(%rbp)
.Lssa_main_238:
.Lssa_main_237:
    .loc 2 1095 3
    .loc 2 1096 3
    .loc 2 1097 3
    .loc 2 1098 3
    .loc 2 1099 3
    .loc 2 1100 3
.Lssa_main_236:
    movq $-1, -112(%rbp)
    movq $-1, %rbx
    movq $-1, %r15
    movq $-1, %r10
    movq $-1, -120(%rbp)
    xorl %r9d, %r9d
.Lssa_main_1001:
    movq -88(%rbp), %r11
    movq 8(%r11), %r8
    movq 0(%r8), %rsi
    cmpq %rsi, %r9
    jge .Lssa_main_233
.Lssa_main_1048:
    .loc 2 1102 5
    movq -88(%rbp), %r11
    movq 8(%r11), %rsi
    movq 8(%rsi,%r9,8), %r8
.Lssa_main_1047:
    .loc 2 1131 3
    movq 8(%r8), %r12
    cmpq $4, %r12
    jne .Lssa_main_1044
.Lssa_main_1046:
    .loc 2 1133 5
    leaq .SB188(%rip), %rsi
    movl $3, %edi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r8, %rax
    call __fn_http____kind_if.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    jmp .Lssa_main_1031
.Lssa_main_1044:
    cmpq $6, %r12
    jne .Lssa_main_1041
.Lssa_main_1043:
    .loc 2 1136 5
    leaq .SB189(%rip), %rsi
    movl $4, %edi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r8, %rax
    call __fn_http____kind_if.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    jmp .Lssa_main_1031
.Lssa_main_1041:
    cmpq $10, %r12
    jne .Lssa_main_1038
.Lssa_main_1040:
    .loc 2 1139 5
    leaq .SB63(%rip), %rsi
    movl $5, %edi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r8, %rax
    call __fn_http____kind_if.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    jmp .Lssa_main_1031
.Lssa_main_1038:
    cmpq $14, %r12
    jne .Lssa_main_1035
.Lssa_main_1037:
    .loc 2 1142 5
    leaq .SB62(%rip), %rsi
    movl $1, %edi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r8, %rax
    call __fn_http____kind_if.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    jmp .Lssa_main_1031
.Lssa_main_1035:
    cmpq $17, %r12
    jne .Lssa_main_1032
.Lssa_main_1034:
    .loc 2 1145 5
    leaq .SB64(%rip), %rsi
    movl $2, %edi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r8, %rax
    call __fn_http____kind_if.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    jmp .Lssa_main_1031
.Lssa_main_1032:
    .loc 2 1147 3
    xorl %eax, %eax
.Lssa_main_1031:
    cmpq $1, %rax
    jne .Lssa_main_1024
.Lssa_main_1029:
    cmpq $-1, -112(%rbp)
    jne .Lssa_main_1025
.Lssa_main_1028:
    movq %r9, -112(%rbp)
.Lssa_main_1027:
    jmp .Lssa_main_1024
.Lssa_main_1025:
    .loc 2 1127 3
    movq $-2, -112(%rbp)
.Lssa_main_1024:
    cmpq $2, %rax
    jne .Lssa_main_1017
.Lssa_main_1022:
    cmpq $-1, %rbx
    jne .Lssa_main_1018
.Lssa_main_1021:
    movq %r9, %rbx
.Lssa_main_1020:
    jmp .Lssa_main_1017
.Lssa_main_1018:
    movq $-2, %rbx
.Lssa_main_1017:
    cmpq $3, %rax
    jne .Lssa_main_1010
.Lssa_main_1015:
    cmpq $-1, %r15
    jne .Lssa_main_1011
.Lssa_main_1014:
    movq %r9, %r15
.Lssa_main_1013:
    jmp .Lssa_main_1010
.Lssa_main_1011:
    movq $-2, %r15
.Lssa_main_1010:
    cmpq $4, %rax
    jne .Lssa_main_1006
.Lssa_main_1009:
    cmpq $0, %r10
    jge .Lssa_main_1006
.Lssa_main_1008:
    movq %r9, %r10
.Lssa_main_1007:
.Lssa_main_1006:
    cmpq $5, %rax
    jne .Lssa_main_1002
.Lssa_main_1005:
    cmpq $0, -120(%rbp)
    jge .Lssa_main_1002
.Lssa_main_1004:
    movq %r9, -120(%rbp)
.Lssa_main_1003:
.Lssa_main_1002:
    .loc 2 1118 7
    addq $1, %r9
    jmp .Lssa_main_1001
.Lssa_main_233:
    cmpq $0, %r10
    jge .Lssa_main_230
.Lssa_main_232:
    .loc 2 1694 5
    xorl %r12d, %r12d
    jmp .Lssa_main_225
.Lssa_main_230:
    movq %r10, %r12
.Lssa_main_1133:
    cmpq $0, %r12
    jl .Lssa_main_229
.Lssa_main_1136:
    movq -88(%rbp), %r11
    movq 16(%r11), %r9
    cmpq (%r9), %r12
    jae __fern_oob_abort
    movq 8(%r9,%r12,8), %rax
    leaq .SB190(%rip), %rsi
    call __fn_http____token_is.r
    testq %rax, %rax
    jz .Lssa_main_228
.Lssa_main_1134:
    .loc 2 1700 8
    leaq .SB189(%rip), %rsi
    addq $1, %r12
    movslq %r12d, %rdi
    movq -88(%rbp), %rax
    call __fn_http____field_at.r
    movq %rax, %r12
    cmpq $0, %r12
    jge .Lssa_main_1136
.Lssa_main_229:
    .loc 2 1702 3
    movl $1, %r12d
    jmp .Lssa_main_225
.Lssa_main_228:
    .loc 2 1698 7
    movl $417, %r12d
.Lssa_main_227:
.Lssa_main_225:
    cmpq $-1, %r15
    jne .Lssa_main_222
.Lssa_main_224:
    .loc 2 1231 5
    leaq .SB187(%rip), %rdi
    movq -104(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_main_1153
.Lssa_main_1152:
    movq -104(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_main_streqn3957
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn3957
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd3957
.Lssa_main_streqn3957:
    xorl %eax, %eax
.Lssa_main_streqd3957:
    jmp .Lssa_main_1154
.Lssa_main_1153:
    xorl %eax, %eax
.Lssa_main_1154:
    testq %rax, %rax
    jnz .Lssa_main_211
    jmp .Lssa_main_213
.Lssa_main_222:
    cmpq $-2, %r15
    je .Lssa_main_211
.Lssa_main_219:
    .loc 2 1236 3
    movq -88(%rbp), %r11
    movq 16(%r11), %rdi
    cmpq (%rdi), %r15
    jae __fern_oob_abort
    movq 8(%rdi,%r15,8), %rsi
    .loc 2 1237 3
.Lssa_main_218:
    movq 8(%rsi), %rdi
    movq 0(%rsi), %r9
    xorl %esi, %esi
.Lssa_main_1161:
    cmpq %rdi, %rsi
    jge .Lssa_main_213
.Lssa_main_1165:
    .loc 2 1239 5
    movzbl (%r9,%rsi), %r10d
    cmpq $33, %r10
    jl .Lssa_main_211
.Lssa_main_1164:
    cmpq $126, %r10
    jg .Lssa_main_211
.Lssa_main_1162:
    .loc 2 1243 7
    addq $1, %rsi
    cmpq %rdi, %rsi
    jl .Lssa_main_1165
.Lssa_main_213:
    cmpq $417, %r12
    jne .Lssa_main_209
.Lssa_main_212:
    .loc 2 1710 5
    movl $417, %esi
    jmp .Lssa_main_208
.Lssa_main_211:
    .loc 2 1707 5
    movl $400, %esi
    jmp .Lssa_main_208
.Lssa_main_209:
    .loc 2 1712 3
    xorl %esi, %esi
.Lssa_main_208:
    cmpq $0, %rsi
    jle .Lssa_main_205
.Lssa_main_1191:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_205:
    cmpq $-1, %rbx
    jne .Lssa_main_200
.Lssa_main_203:
    cmpq $-1, -112(%rbp)
    jne .Lssa_main_190
.Lssa_main_202:
    .loc 2 1159 5
    movq $1, -112(%rbp)
    movq $0, -144(%rbp)
    jmp .Lssa_main_182
.Lssa_main_200:
    cmpq $-1, -112(%rbp)
    je .Lssa_main_199
.Lssa_main_1204:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_199:
    cmpq $-2, %rbx
    jne .Lssa_main_197
.Lssa_main_1208:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_197:
    .loc 2 1212 3
    movq -88(%rbp), %r11
    movq 16(%r11), %rsi
    cmpq (%rsi), %rbx
    jae __fern_oob_abort
    movq 8(%rsi,%rbx,8), %r9
    leaq .SB191(%rip), %rsi
    movq %r9, %rdi
    pushq %rsi
    pushq %rdi
    call __fn___fern_str_split
    addq $16, %rsp
    movq %rax, %rbx
    movq 0(%rbx), %rsi
    subl $1, %esi
    cmpq (%rbx), %rsi
    jae __fern_oob_abort
    movq 8(%rbx,%rsi,8), %rax
    leaq .SB192(%rip), %rsi
    call __fn_http____token_is.r
    testq %rax, %rax
    jnz .Lssa_main_195
.Lssa_main_1213:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    testb $1, %bl
    jnz .Lssa_main_uq1213
    cmpq $0x10000, %rbx
    jb .Lssa_main_uq1213
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq1213:
    jne .Lssa_main_1217
.Lssa_main_1215:
    xorl %r12d, %r12d
.Lssa_main_1219:
    movq 0(%rbx), %rsi
    cmpq %rsi, %r12
    jge .Lssa_main_1217
.Lssa_main_1220:
    movq 8(%rbx,%r12,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r12
    jmp .Lssa_main_1219
.Lssa_main_1217:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_195:
    .loc 2 1216 3
.Lssa_main_194:
    xorl %r12d, %r12d
.Lssa_main_1224:
    leaq 1(%r12), %rsi
    movslq %esi, %rsi
    movq 0(%rbx), %r11
    movq %r11, -144(%rbp)
    cmpq %r11, %rsi
    jge .Lssa_main_193
.Lssa_main_1227:
    cmpq (%rbx), %r12
    jae __fern_oob_abort
    movq 8(%rbx,%r12,8), %rax
    leaq .SB192(%rip), %rsi
    call __fn_http____token_is.r
    testq %rax, %rax
    jz .Lssa_main_1225
.Lssa_main_1232:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    testb $1, %bl
    jnz .Lssa_main_uq1232
    cmpq $0x10000, %rbx
    jb .Lssa_main_uq1232
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq1232:
    jne .Lssa_main_1237
.Lssa_main_1235:
    xorl %r15d, %r15d
.Lssa_main_1239:
    movq 0(%rbx), %rsi
    cmpq %rsi, %r15
    jge .Lssa_main_1237
.Lssa_main_1240:
    movq 8(%rbx,%r15,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r15
    jmp .Lssa_main_1239
.Lssa_main_1237:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_1225:
    .loc 2 1221 7
    addq $1, %r12
    movslq %r12d, %r12
    jmp .Lssa_main_1224
.Lssa_main_193:
    testb $1, %bl
    jnz .Lssa_main_uq193
    cmpq $0x10000, %rbx
    jb .Lssa_main_uq193
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq193:
    jne .Lssa_main_1248
.Lssa_main_1246:
    xorl %r12d, %r12d
.Lssa_main_1250:
    movq 0(%rbx), %rsi
    cmpq %rsi, %r12
    jge .Lssa_main_1248
.Lssa_main_1251:
    movq 8(%rbx,%r12,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r12
    jmp .Lssa_main_1250
.Lssa_main_1248:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    cmpq $1, -144(%rbp)
    jle .Lssa_main_192
.Lssa_main_1254:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_192:
    movq $0, -112(%rbp)
    movq $0, -144(%rbp)
    jmp .Lssa_main_182
.Lssa_main_190:
    cmpq $-2, -112(%rbp)
    jne .Lssa_main_188
.Lssa_main_1259:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_188:
    .loc 2 1164 3
    movq -88(%rbp), %r11
    movq 16(%r11), %rsi
    movq -112(%rbp), %rcx
    cmpq (%rsi), %rcx
    jae __fern_oob_abort
    movq 8(%rsi,%rcx,8), %r12
    movq 8(%r12), %rsi
    cmpq $0, %rsi
    jne .Lssa_main_186
.Lssa_main_1263:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_1
.Lssa_main_186:
    .loc 2 1168 3
    .loc 2 1169 3
.Lssa_main_185:
    movq 8(%r12), %rbx
    movq 0(%r12), %r15
    xorl %r12d, %r12d
    xorl %r9d, %r9d
.Lssa_main_1267:
    cmpq %rbx, %r9
    jge .Lssa_main_184
.Lssa_main_1275:
    .loc 2 1171 5
    movzbl (%r15,%r9), %r10d
    cmpq $48, %r10
    jge .Lssa_main_1274
.Lssa_main_1280:
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_1274:
    cmpq $57, %r10
    jle .Lssa_main_1272
.Lssa_main_1284:
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    jmp .Lssa_main_1
.Lssa_main_1272:
    .loc 2 1175 5
    subq $48, %r10
    movslq %r10d, %r8
    cmpq $214748364, %r12
    jle .Lssa_main_1271
.Lssa_main_1288:
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    jmp .Lssa_main_1
.Lssa_main_1271:
    cmpq $214748364, %r12
    jne .Lssa_main_1268
.Lssa_main_1270:
    cmpq $7, %r8
    jle .Lssa_main_1268
.Lssa_main_1296:
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    jmp .Lssa_main_1
.Lssa_main_1268:
    .loc 2 1179 9
    imulq $10, %r12, %r10
    addq %r8, %r10
    movslq %r10d, %r12
    .loc 2 1180 7
    addq $1, %r9
    cmpq %rbx, %r9
    jl .Lssa_main_1275
.Lssa_main_184:
    movq %r12, -144(%rbp)
    movq $1, -112(%rbp)
.Lssa_main_183:
.Lssa_main_182:
    .loc 2 1960 3
    movq %r14, %rax
    movq -96(%rbp), %rsi
    movq -80(%rbp), %rdi
    movq -72(%rbp), %r8
    call __fn_http____shared_string.r
    call __fn___fern_str_free.r
    movq -96(%rbp), %r9
    addq -136(%rbp), %r9
    movslq %r9d, %rbx
.Lssa_main_181:
    .loc 2 2354 3
.Lssa_main_180:
    xorl %r12d, %r12d
.Lssa_main_1302:
    cmpq $0, -120(%rbp)
    jl .Lssa_main_179
.Lssa_main_1309:
    movq -88(%rbp), %r11
    movq 16(%r11), %r15
    movq -120(%rbp), %rcx
    cmpq (%r15), %rcx
    jae __fern_oob_abort
    movq 8(%r15,%rcx,8), %rax
    leaq .SB193(%rip), %rsi
    call __fn_http____lists_token.r
    testq %rax, %rax
    jz .Lssa_main_1306
.Lssa_main_1308:
    .loc 2 2358 13
    movl $1, %r12d
.Lssa_main_1307:
.Lssa_main_1306:
    movq -120(%rbp), %rcx
    cmpq (%r15), %rcx
    jae __fern_oob_abort
    movq 8(%r15,%rcx,8), %rax
    leaq .SB194(%rip), %rsi
    call __fn_http____lists_token.r
.Lssa_main_1303:
    .loc 2 2363 8
    leaq .SB63(%rip), %rsi
    movq -120(%rbp), %r9
    addq $1, %r9
    movslq %r9d, %rdi
    movq -88(%rbp), %rax
    call __fn_http____field_at.r
    movq %rax, -120(%rbp)
    cmpq $0, -120(%rbp)
    jge .Lssa_main_1309
.Lssa_main_179:
    testq %r12, %r12
    jnz .Lssa_main_171
.Lssa_main_176:
    leaq .SB186(%rip), %rdi
    movq -104(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_main_171
.Lssa_main_1331:
    movq -104(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_main_streqn4221
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn4221
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd4221
.Lssa_main_streqn4221:
    xorl %eax, %eax
.Lssa_main_streqd4221:
.Lssa_main_171:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_162
.Lssa_main_170:
    cmpq $1048576, -144(%rbp)
    jle .Lssa_main_167
.Lssa_main_1343:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
.Lssa_main_169:
    .loc 2 1497 9
    movq $413, -72(%rbp)
    jmp .Lssa_main_98
.Lssa_main_167:
    movq %rbx, %rsi
    addq -144(%rbp), %rsi
    movslq %esi, %rsi
    movq 0(%r14), %rdi
    cmpq %rdi, %rsi
    jle .Lssa_main_164
.Lssa_main_1348:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
.Lssa_main_166:
    .loc 2 1500 9
    movq $1, -72(%rbp)
    jmp .Lssa_main_98
.Lssa_main_164:
    .loc 2 1502 7
    movq %rbx, %rdi
    addq -144(%rbp), %rdi
    movslq %edi, %rdi
    pushq %r14
    pushq %rbx
    pushq %rdi
    call __fn___fern_bytes_range
    addq $24, %rsp
    movq %rax, %r12
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq $2, -72(%rbp)
    jmp .Lssa_main_98
.Lssa_main_162:
    leaq .SB187(%rip), %rdi
    movq -104(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $8, %rsi
    jne .Lssa_main_1355
.Lssa_main_1354:
    movq -104(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_main_streqn4250
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn4250
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd4250
.Lssa_main_streqn4250:
    xorl %eax, %eax
.Lssa_main_streqd4250:
    jmp .Lssa_main_1356
.Lssa_main_1355:
    xorl %eax, %eax
.Lssa_main_1356:
    testq %rax, %rax
    jnz .Lssa_main_158
.Lssa_main_1357:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
.Lssa_main_161:
    .loc 2 1506 9
    movq $400, -72(%rbp)
    jmp .Lssa_main_98
.Lssa_main_158:
    .loc 2 1266 3
    leaq .K0(%rip), %rdi
.Lssa_main_157:
    movq %rbx, -72(%rbp)
    movq %rdi, -96(%rbp)
    movq $32768, -80(%rbp)
    movl $1048576, %r15d
.Lssa_main_1362:
.Lssa_main_1421:
    .loc 2 1316 3
    movq 0(%r14), %r13
    .loc 2 1317 3
    movq -72(%rbp), %rdi
    addq -80(%rbp), %rdi
    movslq %edi, %rdi
    cmpq %r13, %rdi
    movq %r13, %r12
    cmovleq %rdi, %r12
    .loc 2 1321 3
    movq %r14, %rax
    movq -72(%rbp), %rsi
    movq %r12, %rdi
    call __fn_http____find_crlf.r
    movq %rax, %rbx
    cmpq $0, %rbx
    movq %rbx, %rdi
    cmovlq %r12, %rdi
    movq %r14, %rax
    movq -72(%rbp), %rsi
    call __fn_http____crlf_terminated.r
    testq %rax, %rax
    jz .Lssa_main_1410
.Lssa_main_1413:
    cmpq $0, %rbx
    jge .Lssa_main_1405
.Lssa_main_1412:
    movq -72(%rbp), %rdi
    addq -80(%rbp), %rdi
    movslq %edi, %rdi
    cmpq %rdi, %r13
    jl .Lssa_main_1408
.Lssa_main_1411:
    .loc 2 1331 7
    movl $431, %r9d
    xorl %ebx, %ebx
    xorl %r13d, %r13d
    jmp .Lssa_main_1386
.Lssa_main_1410:
    .loc 2 1327 5
    movl $400, %r9d
    xorl %ebx, %ebx
    xorl %r13d, %r13d
    jmp .Lssa_main_1386
.Lssa_main_1408:
    .loc 2 1333 5
    movl $1, %r9d
    xorl %ebx, %ebx
    xorl %r13d, %r13d
    jmp .Lssa_main_1386
.Lssa_main_1405:
    .loc 2 1346 3
.Lssa_main_1404:
    movq -72(%rbp), %rdi
    xorl %esi, %esi
.Lssa_main_1448:
    cmpq %rbx, %rdi
    jge .Lssa_main_1403
.Lssa_main_1480:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %r9d
.Lssa_main_1479:
    cmpq $48, %r9
    jb .Lssa_main_1475
.Lssa_main_1478:
    cmpq $57, %r9
    ja .Lssa_main_1475
.Lssa_main_1477:
    .loc 2 1250 5
    leaq -48(%r9), %r10
    movslq %r10d, %r10
    jmp .Lssa_main_1466
.Lssa_main_1475:
    cmpq $97, %r9
    jb .Lssa_main_1471
.Lssa_main_1474:
    cmpq $102, %r9
    ja .Lssa_main_1471
.Lssa_main_1473:
    .loc 2 1253 5
    leaq -87(%r9), %r10
    movslq %r10d, %r10
    jmp .Lssa_main_1466
.Lssa_main_1471:
    cmpq $65, %r9
    jb .Lssa_main_1467
.Lssa_main_1470:
    cmpq $70, %r9
    ja .Lssa_main_1467
.Lssa_main_1469:
    .loc 2 1256 5
    leaq -55(%r9), %r10
    movslq %r10d, %r10
    jmp .Lssa_main_1466
.Lssa_main_1467:
    .loc 2 1258 3
    movq $-1, %r10
.Lssa_main_1466:
    cmpq $0, %r10
    jl .Lssa_main_1403
.Lssa_main_1464:
    cmpq $48, %r9
    jb .Lssa_main_1460
.Lssa_main_1463:
    cmpq $57, %r9
    ja .Lssa_main_1460
.Lssa_main_1462:
    .loc 2 1250 5
    leaq -48(%r9), %r10
    jmp .Lssa_main_1451
.Lssa_main_1460:
    cmpq $97, %r9
    jb .Lssa_main_1456
.Lssa_main_1459:
    cmpq $102, %r9
    ja .Lssa_main_1456
.Lssa_main_1458:
    .loc 2 1253 5
    leaq -87(%r9), %r10
    jmp .Lssa_main_1451
.Lssa_main_1456:
    cmpq $65, %r9
    jb .Lssa_main_1452
.Lssa_main_1455:
    cmpq $70, %r9
    ja .Lssa_main_1452
.Lssa_main_1454:
    .loc 2 1256 5
    subq $55, %r9
    movq %r9, %r10
    jmp .Lssa_main_1451
.Lssa_main_1452:
    .loc 2 1258 3
    movq $-1, %r10
.Lssa_main_1451:
    movq %rsi, %r9
    shlq $4, %r9
    addq %r10, %r9
    movslq %r9d, %r9
    cmpq %r15, %r9
    jg .Lssa_main_1401
.Lssa_main_1449:
    .loc 2 1353 10
    movq %rsi, %r9
    shlq $4, %r9
    addq %r10, %r9
    movslq %r9d, %rsi
    .loc 2 1354 7
    addq $1, %rdi
    cmpq %rbx, %rdi
    jl .Lssa_main_1480
.Lssa_main_1403:
    cmpq -72(%rbp), %rdi
    jne .Lssa_main_1399
.Lssa_main_1402:
    .loc 2 1357 5
    movl $400, %esi
    xorl %r13d, %r13d
    jmp .Lssa_main_1398
.Lssa_main_1401:
    .loc 2 1351 7
    movl $413, %esi
    xorl %r13d, %r13d
    jmp .Lssa_main_1398
.Lssa_main_1399:
    .loc 2 1359 3
    movq %rsi, %r13
    xorl %esi, %esi
.Lssa_main_1398:
    cmpq $0, %rsi
    je .Lssa_main_1560
.Lssa_main_1397:
    .loc 2 1337 5
    movq %rsi, %r9
    xorl %ebx, %ebx
    xorl %r13d, %r13d
    jmp .Lssa_main_1386
.Lssa_main_1395:
.Lssa_main_1560:
    cmpq %rbx, %rdi
    jge .Lssa_main_1388
.Lssa_main_1595:
.Lssa_main_1601:
    cmpq %rbx, %rdi
    jge .Lssa_main_1593
.Lssa_main_1607:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %esi
.Lssa_main_1606:
    .loc 2 838 3
    cmpq $32, %rsi
    je .Lssa_main_1602
.Lssa_main_1604:
    cmpq $9, %rsi
    jne .Lssa_main_1593
.Lssa_main_1602:
    .loc 2 1389 7
    addq $1, %rdi
    cmpq %rbx, %rdi
    jl .Lssa_main_1607
.Lssa_main_1593:
    cmpq %rbx, %rdi
    jge .Lssa_main_1387
.Lssa_main_1592:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %esi
    cmpq $59, %rsi
    jne .Lssa_main_1387
.Lssa_main_1590:
    .loc 2 1369 7
    addq $1, %rdi
.Lssa_main_1589:
    movq %rdi, %r12
.Lssa_main_1631:
    cmpq %rbx, %r12
    jge .Lssa_main_1587
.Lssa_main_1637:
    cmpq (%r14), %r12
    jae __fern_oob_abort
    movzbl 8(%r14,%r12), %edi
.Lssa_main_1636:
    .loc 2 838 3
    cmpq $32, %rdi
    je .Lssa_main_1632
.Lssa_main_1634:
    cmpq $9, %rdi
    jne .Lssa_main_1587
.Lssa_main_1632:
    .loc 2 1389 7
    addq $1, %r12
    cmpq %rbx, %r12
    jl .Lssa_main_1637
.Lssa_main_1587:
    .loc 2 1395 3
    leaq .K8(%rip), %rdi
    movq %rdi, %rdx
    movq %r12, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L145
    xorq %rcx, %rcx
.L145:
    leaq .S70(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L148
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L146:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L152
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L147
    addq $32, %r9
    jmp .L146
.L152:
    cmpq %r10, %r9
    jg .L153
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L147
    addq $16, %r9
.L153:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L148
.L147:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L151
.L148:
    cmpq %r8, %rcx
    jge .L150
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L149
    addq $1, %rcx
    jmp .L148
.L149:
    pushq %rcx
    jmp .L151
.L150:
    pushq %r8
.L151:
    popq %rax
    cmpq %rbx, %rax
    cmovgq %rbx, %rax
    cmpq %r12, %rax
    je .Lssa_main_1387
.Lssa_main_1585:
    movq %rax, %rdi
.Lssa_main_1666:
    cmpq %rbx, %rdi
    jge .Lssa_main_1583
.Lssa_main_1672:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %esi
.Lssa_main_1671:
    .loc 2 838 3
    cmpq $32, %rsi
    je .Lssa_main_1667
.Lssa_main_1669:
    cmpq $9, %rsi
    jne .Lssa_main_1583
.Lssa_main_1667:
    .loc 2 1389 7
    addq $1, %rdi
    cmpq %rbx, %rdi
    jl .Lssa_main_1672
.Lssa_main_1583:
    cmpq %rbx, %rdi
    jge .Lssa_main_1575
.Lssa_main_1582:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %esi
    cmpq $61, %rsi
    jne .Lssa_main_1575
.Lssa_main_1581:
    .loc 2 1377 9
    addq $1, %rdi
.Lssa_main_1580:
    movq %rdi, %r12
.Lssa_main_1696:
    cmpq %rbx, %r12
    jge .Lssa_main_1577
.Lssa_main_1702:
    cmpq (%r14), %r12
    jae __fern_oob_abort
    movzbl 8(%r14,%r12), %edi
.Lssa_main_1701:
    .loc 2 838 3
    cmpq $32, %rdi
    je .Lssa_main_1697
.Lssa_main_1699:
    cmpq $9, %rdi
    jne .Lssa_main_1577
.Lssa_main_1697:
    .loc 2 1389 7
    addq $1, %r12
    cmpq %rbx, %r12
    jl .Lssa_main_1702
.Lssa_main_1577:
    cmpq %rbx, %r12
    jl .Lssa_main_1573
.Lssa_main_1576:
    .loc 2 1404 5
    movq $-1, %rax
    jmp .Lssa_main_1563
.Lssa_main_1575:
    movq %rax, %rdi
    jmp .Lssa_main_1560
.Lssa_main_1573:
    cmpq (%r14), %r12
    jae __fern_oob_abort
    movzbl 8(%r14,%r12), %edi
    cmpq $34, %rdi
    je .Lssa_main_1568
.Lssa_main_1572:
    .loc 2 1395 3
    leaq .K8(%rip), %rdi
    movq %rdi, %rdx
    movq %r12, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L154
    xorq %rcx, %rcx
.L154:
    leaq .S70(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L157
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L155:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L161
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L156
    addq $32, %r9
    jmp .L155
.L161:
    cmpq %r10, %r9
    jg .L162
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L156
    addq $16, %r9
.L162:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L157
.L156:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L160
.L157:
    cmpq %r8, %rcx
    jge .L159
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L158
    addq $1, %rcx
    jmp .L157
.L158:
    pushq %rcx
    jmp .L160
.L159:
    pushq %r8
.L160:
    popq %rax
    cmpq %rbx, %rax
    cmovgq %rbx, %rax
    cmpq %r12, %rax
    jne .Lssa_main_1563
.Lssa_main_1571:
    .loc 2 1409 7
    movq $-1, %rax
.Lssa_main_1570:
    jmp .Lssa_main_1563
.Lssa_main_1568:
    .loc 2 1413 3
    addq $1, %r12
.Lssa_main_1567:
.Lssa_main_1743:
    cmpq %rbx, %r12
    jge .Lssa_main_1566
.Lssa_main_1758:
    .loc 2 1415 5
    cmpq (%r14), %r12
    jae __fern_oob_abort
    movzbl 8(%r14,%r12), %edi
    cmpq $34, %rdi
    je .Lssa_main_1565
.Lssa_main_1756:
    .loc 2 1420 9
    leaq 1(%r12), %rsi
    cmpq $92, %rdi
    cmovneq %r12, %rsi
    cmpq %rbx, %rsi
    jge .Lssa_main_1564
.Lssa_main_1752:
    cmpq (%r14), %rsi
    jae __fern_oob_abort
    movzbl 8(%r14,%rsi), %edi
.Lssa_main_1751:
    .loc 2 1431 3
    cmpq $9, %rdi
    je .Lssa_main_1744
.Lssa_main_1749:
    cmpq $32, %rdi
    jb .Lssa_main_1564
.Lssa_main_1748:
    cmpq $127, %rdi
    je .Lssa_main_1564
.Lssa_main_1744:
    .loc 2 1425 7
    leaq 1(%rsi), %r12
    cmpq %rbx, %r12
    jl .Lssa_main_1758
.Lssa_main_1566:
    .loc 2 1427 3
    movq $-1, %rax
    jmp .Lssa_main_1563
.Lssa_main_1565:
    .loc 2 1417 7
    addq $1, %r12
    movq %r12, %rax
    jmp .Lssa_main_1563
.Lssa_main_1564:
    .loc 2 1423 7
    movq $-1, %rax
.Lssa_main_1563:
    cmpq $0, %rax
    jl .Lssa_main_1387
.Lssa_main_1562:
    movq %rax, %rdi
.Lssa_main_1561:
    cmpq %rbx, %rdi
    jl .Lssa_main_1601
.Lssa_main_1388:
    .loc 2 1342 3
    movl $2, %r9d
    jmp .Lssa_main_1386
.Lssa_main_1387:
    .loc 2 1340 5
    movl $400, %r9d
    xorl %ebx, %ebx
    xorl %r13d, %r13d
.Lssa_main_1386:
    cmpq $2, %r9
    jne .Lssa_main_156
.Lssa_main_1384:
    .loc 2 1273 5
    addq $2, %rbx
    movslq %ebx, %rbx
    .loc 2 1275 12
    movq %rbx, %rdi
    subq -72(%rbp), %rdi
    movq -80(%rbp), %r11
    subq %rdi, %r11
    movq %r11, %rdi
    subq $2, %rdi
    movslq %edi, %r10
    cmpq $0, %r10
    jl .Lssa_main_155
.Lssa_main_1382:
    cmpq $0, %r13
    je .Lssa_main_154
.Lssa_main_1380:
    .loc 2 1282 5
    leaq (%rbx,%r13), %rdi
    movslq %edi, %rdi
.Lssa_main_1379:
    .loc 2 1297 3
    movq 0(%r14), %rsi
    cmpq %rsi, %rdi
    jge .Lssa_main_1375
.Lssa_main_1378:
    cmpq (%r14), %rdi
    jae __fern_oob_abort
    movzbl 8(%r14,%rdi), %r8d
    cmpq $13, %r8
    je .Lssa_main_1375
.Lssa_main_1377:
    .loc 2 1299 5
    xorl %edi, %edi
    jmp .Lssa_main_1367
.Lssa_main_1375:
    leaq 1(%rdi), %r8
    movslq %r8d, %r8
    cmpq %rsi, %r8
    jge .Lssa_main_1371
.Lssa_main_1374:
    leal 1(%rdi), %r8d
    cmpq (%r14), %r8
    jae __fern_oob_abort
    movzbl 8(%r14,%r8), %eax
    cmpq $10, %rax
    je .Lssa_main_1371
.Lssa_main_1373:
    .loc 2 1302 5
    xorl %edi, %edi
    jmp .Lssa_main_1367
.Lssa_main_1371:
    addq $2, %rdi
    movslq %edi, %rdi
    cmpq %rsi, %rdi
    jle .Lssa_main_1368
.Lssa_main_1370:
    .loc 2 1305 5
    movl $1, %edi
    jmp .Lssa_main_1367
.Lssa_main_1368:
    .loc 2 1307 3
    movl $2, %edi
.Lssa_main_1367:
    cmpq $0, %rdi
    je .Lssa_main_151
.Lssa_main_1365:
    cmpq $1, %rdi
    je .Lssa_main_150
.Lssa_main_1363:
    .loc 2 1289 11
    movq -96(%rbp), %rdi
    movq %rbx, %rsi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %rax, %rdi
    movq %r13, %rsi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %rax, -96(%rbp)
    .loc 2 1290 10
    subq %r13, %r15
    movslq %r15d, %r15
    .loc 2 1291 8
    addq %rbx, %r13
    addq $2, %r13
    movslq %r13d, %r11
    movq %r11, -72(%rbp)
    movq %r10, -80(%rbp)
    jmp .Lssa_main_1421
.Lssa_main_156:
    movq %r9, %rbx
    jmp .Lssa_main_107
.Lssa_main_155:
    .loc 2 1277 7
    movl $431, %ebx
    jmp .Lssa_main_107
.Lssa_main_154:
    .loc 2 1280 7
    leaq 2(%r10), %r11
    movq %r11, -72(%rbp)
.Lssa_main_153:
    .loc 2 1440 3
    movq 0(%r14), %r15
    .loc 2 1442 3
    movq %rbx, %r10
    addq -72(%rbp), %r10
    movslq %r10d, %r10
    cmpq %r15, %r10
    movq %r15, %r12
    cmovleq %r10, %r12
    .loc 2 1446 3
    leaq -2(%rbx), %r10
    movslq %r10d, %r10
    jmp .Lssa_main_147
.Lssa_main_151:
    .loc 2 1284 7
    movl $400, %ebx
    jmp .Lssa_main_107
.Lssa_main_150:
    .loc 2 1287 7
    movl $1, %ebx
    jmp .Lssa_main_107
.Lssa_main_147:
    .loc 2 1073 3
    movl $13, %r9d
    movq %r10, %rdx
    movq %r9, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L163
    xorq %rdx, %rdx
.L163:
    cmpq $255, %rcx
    ja .L167
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L171
.L169:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L170
    addq $32, %r9
    cmpq %r10, %r9
    jle .L169
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L171
.L170:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L168
.L171:
    vzeroupper
.L164:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L166
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L165
    addq $16, %rdx
    jmp .L164
.L165:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L168
.L166:
    cmpq %r8, %rdx
    jge .L167
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L172
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L167
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L167
    addq %r9, %rdx
    jmp .L168
.L172:
    cmpq %r8, %rdx
    jge .L167
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L168
    addq $1, %rdx
    jmp .L172
.L167:
    movq $-1, %rdx
.L168:
    movq %rdx, %rax
.Lssa_main_146:
.Lssa_main_1862:
    cmpq $0, %rax
    jl .Lssa_main_145
.Lssa_main_1868:
    leaq 3(%rax), %r9
    movslq %r9d, %r9
    cmpq %r12, %r9
    jge .Lssa_main_145
.Lssa_main_1867:
    leal 1(%rax), %r9d
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %r10d
    cmpq $10, %r10
    jne .Lssa_main_1863
.Lssa_main_1866:
    leal 2(%rax), %r10d
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movzbl 8(%r14,%r10), %r9d
    cmpq $13, %r9
    jne .Lssa_main_1863
.Lssa_main_1865:
    leal 3(%rax), %r9d
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %r10d
    cmpq $10, %r10
    je .Lssa_main_144
.Lssa_main_1863:
    .loc 2 1078 7
    leaq 1(%rax), %r10
    movslq %r10d, %r10
    movl $13, %r9d
    movq %r10, %rdx
    movq %r9, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L173
    xorq %rdx, %rdx
.L173:
    cmpq $255, %rcx
    ja .L177
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L181
.L179:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L180
    addq $32, %r9
    cmpq %r10, %r9
    jle .L179
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L181
.L180:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L178
.L181:
    vzeroupper
.L174:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L176
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L175
    addq $16, %rdx
    jmp .L174
.L175:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L178
.L176:
    cmpq %r8, %rdx
    jge .L177
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L182
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L177
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L177
    addq %r9, %rdx
    jmp .L178
.L182:
    cmpq %r8, %rdx
    jge .L177
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L178
    addq $1, %rdx
    jmp .L182
.L177:
    movq $-1, %rdx
.L178:
    movq %rdx, %rax
    cmpq $0, %rax
    jge .Lssa_main_1868
.Lssa_main_145:
    .loc 2 1080 3
    movq $-1, -80(%rbp)
    jmp .Lssa_main_143
.Lssa_main_144:
    movq %rax, -80(%rbp)
.Lssa_main_143:
    cmpq $0, -80(%rbp)
    movq -80(%rbp), %rdi
    cmovlq %r12, %rdi
    cmpq %rbx, %rdi
    jle .Lssa_main_137
.Lssa_main_139:
    movq %r14, %rax
    movq %rbx, %rsi
    call __fn_http____crlf_terminated.r
    testq %rax, %rax
    jz .Lssa_main_134
.Lssa_main_137:
    cmpq $0, -80(%rbp)
    jge .Lssa_main_130
.Lssa_main_136:
    movq %rbx, %rdi
    addq -72(%rbp), %rdi
    movslq %edi, %rdi
    cmpq %rdi, %r15
    jl .Lssa_main_132
.Lssa_main_135:
    .loc 2 1456 7
    movl $431, %ebx
    jmp .Lssa_main_107
.Lssa_main_134:
    .loc 2 1452 5
    movl $400, %ebx
    jmp .Lssa_main_107
.Lssa_main_132:
    .loc 2 1458 5
    movl $1, %ebx
    jmp .Lssa_main_107
.Lssa_main_130:
    cmpq %rbx, -80(%rbp)
    jle .Lssa_main_114
.Lssa_main_129:
    .loc 6 90 3
    leaq .K1(%rip), %r11
    movq %r11, -72(%rbp)
.Lssa_main_128:
    leaq .K1(%rip), %rax
    .loc 2 871 3
    .loc 2 872 3
.Lssa_main_127:
    movq %rbx, -136(%rbp)
    movq %rax, %rbx
    movq $1, -112(%rbp)
    movq $0, -120(%rbp)
.Lssa_main_1920:
    movq -136(%rbp), %r11
    cmpq -80(%rbp), %r11
    jl .Lssa_main_1974
.Lssa_main_1977:
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_126
.Lssa_main_1974:
    .loc 2 1395 3
    leaq .K8(%rip), %rdi
    movq %rdi, %rdx
    movq -136(%rbp), %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L183
    xorq %rcx, %rcx
.L183:
    leaq .S70(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L186
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L184:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L190
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L185
    addq $32, %r9
    jmp .L184
.L190:
    cmpq %r10, %r9
    jg .L191
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L185
    addq $16, %r9
.L191:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L186
.L185:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L189
.L186:
    cmpq %r8, %rcx
    jge .L188
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L187
    addq $1, %rcx
    jmp .L186
.L187:
    pushq %rcx
    jmp .L189
.L188:
    pushq %r8
.L189:
    popq %rax
    cmpq -80(%rbp), %rax
    movq -80(%rbp), %r9
    cmovleq %rax, %r9
    cmpq -136(%rbp), %r9
    je .Lssa_main_1971
.Lssa_main_1973:
    cmpq -80(%rbp), %r9
    jge .Lssa_main_1971
.Lssa_main_1972:
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %edi
    cmpq $58, %rdi
    je .Lssa_main_1969
.Lssa_main_1971:
    .loc 2 926 5
    movq -80(%rbp), %r10
    movq $-1, -144(%rbp)
    jmp .Lssa_main_1957
.Lssa_main_1969:
    .loc 2 928 3
    leaq 1(%r9), %rdi
.Lssa_main_1968:
    .loc 2 701 3
    movl $13, %r10d
    movq %r9, -184(%rbp)
    movq %rdi, %rdx
    movq %r10, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    cmpq $0, %rdx
    jge .L192
    xorq %rdx, %rdx
.L192:
    cmpq $255, %rcx
    ja .L196
    movd %ecx, %xmm1
    punpcklbw %xmm1, %xmm1
    punpcklwd %xmm1, %xmm1
    pshufd $0, %xmm1, %xmm1
    vpbroadcastb %xmm1, %ymm1
    leaq (%rax,%rdx), %r9
    leaq -32(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L200
.L198:
    vpcmpeqb (%r9), %ymm1, %ymm0
    vpmovmskb %ymm0, %r11d
    testl %r11d, %r11d
    jnz .L199
    addq $32, %r9
    cmpq %r10, %r9
    jle .L198
    subq %rax, %r9
    movq %r9, %rdx
    jmp .L200
.L199:
    vzeroupper
    bsfl %r11d, %r11d
    subq %rax, %r9
    leaq (%r9,%r11), %rdx
    jmp .L197
.L200:
    vzeroupper
.L193:
    movq %r8, %r9
    subq %rdx, %r9
    cmpq $16, %r9
    jl .L195
    movdqu (%rax,%rdx), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jnz .L194
    addq $16, %rdx
    jmp .L193
.L194:
    bsfl %r9d, %r9d
    addq %r9, %rdx
    jmp .L197
.L195:
    cmpq %r8, %rdx
    jge .L196
    leaq (%rax,%rdx), %r9
    movl %r9d, %r10d
    andl $4095, %r10d
    cmpl $4080, %r10d
    ja .L201
    movdqu (%r9), %xmm0
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %r9d
    testl %r9d, %r9d
    jz .L196
    bsfl %r9d, %r9d
    movq %r8, %r10
    subq %rdx, %r10
    cmpq %r10, %r9
    jae .L196
    addq %r9, %rdx
    jmp .L197
.L201:
    cmpq %r8, %rdx
    jge .L196
    movzbq (%rax,%rdx), %r9
    cmpq %rcx, %r9
    je .L197
    addq $1, %rdx
    jmp .L201
.L196:
    movq $-1, %rdx
.L197:
    movq %rdx, %rax
    movq -184(%rbp), %r9
    cmpq $0, %rax
    jl .Lssa_main_1966
.Lssa_main_1967:
    cmpq -80(%rbp), %rax
    jl .Lssa_main_1964
.Lssa_main_1966:
    movq -80(%rbp), %rax
    jmp .Lssa_main_1960
.Lssa_main_1964:
    leaq 1(%rax), %r10
    cmpq -80(%rbp), %r10
    jge .Lssa_main_1962
.Lssa_main_1963:
    leaq 1(%rax), %r10
    cmpq (%r14), %r10
    jae __fern_oob_abort
    movzbl 8(%r14,%r10), %edi
    cmpq $10, %rdi
    je .Lssa_main_1960
.Lssa_main_1962:
    .loc 2 706 5
    movq $-1, %rax
.Lssa_main_1961:
.Lssa_main_1960:
    cmpq $0, %rax
    jge .Lssa_main_1958
.Lssa_main_1959:
    .loc 2 930 5
    movq -80(%rbp), %r10
    movq $-1, -144(%rbp)
    jmp .Lssa_main_1957
.Lssa_main_1958:
    movq %r9, -144(%rbp)
    movq %rax, %r10
.Lssa_main_1957:
    cmpq $0, -144(%rbp)
    jge .Lssa_main_1955
.Lssa_main_2025:
    movq %r10, -184(%rbp)
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
    jmp .Lssa_main_122
.Lssa_main_1955:
    .loc 2 881 11
    movq -120(%rbp), %rdi
    addq $1, %rdi
    movslq %edi, %r11
    movq %r11, -120(%rbp)
    cmpq $100, %r11
    jle .Lssa_main_1953
.Lssa_main_2029:
    movq %r10, -184(%rbp)
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
    jmp .Lssa_main_121
.Lssa_main_1953:
    .loc 2 885 5
    movq -120(%rbp), %rdi
    subq $1, %rdi
    movslq %edi, %r12
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_1946
.Lssa_main_1952:
    movq -72(%rbp), %r11
    movq 8(%r11), %rdi
    movq 0(%rdi), %rsi
    cmpq %rsi, %r12
    jl .Lssa_main_1946
.Lssa_main_1951:
    cmpq $0, %r12
    jle .Lssa_main_1948
.Lssa_main_2041:
    movq %r10, -184(%rbp)
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
.Lssa_main_1950:
    movq -72(%rbp), %r11
    testb $1, %r11b
    jnz .Lssa_main_rcinc5003
    cmpq $0x10000, %r11
    jb .Lssa_main_rcinc5003
    movl -8(%r11), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5003
    addl $1, %ecx
    movl %ecx, -8(%r11)
.Lssa_main_rcinc5003:
    .loc 2 888 11
    movq %r10, -184(%rbp)
    movq -72(%rbp), %rax
    movq %r12, %rsi
    call __fn_http____leading_fields.r
    movq -184(%rbp), %r10
    movq %rax, %rbx
.Lssa_main_1949:
.Lssa_main_1948:
    .loc 2 890 12
    movq $0, -112(%rbp)
.Lssa_main_1947:
.Lssa_main_1946:
    .loc 2 892 5
    movq $-1, %rsi
    movq -112(%rbp), %r11
    testq %r11, %r11
    movq %r12, %r11
    cmoveq %rsi, %r11
    movq %r11, -152(%rbp)
    .loc 2 896 5
    movq -144(%rbp), %rsi
    addq $1, %rsi
    movslq %esi, %rsi
.Lssa_main_1942:
    movq %rsi, %r9
.Lssa_main_2052:
    cmpq %r10, %r9
    jge .Lssa_main_1940
.Lssa_main_2058:
    cmpq (%r14), %r9
    jae __fern_oob_abort
    movzbl 8(%r14,%r9), %esi
.Lssa_main_2057:
    .loc 2 838 3
    cmpq $32, %rsi
    je .Lssa_main_2053
.Lssa_main_2055:
    cmpq $9, %rsi
    jne .Lssa_main_1940
.Lssa_main_2053:
    .loc 2 851 10
    addq $1, %r9
    cmpq %r10, %r9
    jl .Lssa_main_2058
.Lssa_main_1940:
    movq %r10, %r15
.Lssa_main_2074:
    cmpq %r9, %r15
    jle .Lssa_main_1939
.Lssa_main_2080:
    leaq -1(%r15), %rsi
    cmpq (%r14), %rsi
    jae __fern_oob_abort
    movzbl 8(%r14,%rsi), %edi
.Lssa_main_2079:
    .loc 2 838 3
    cmpq $32, %rdi
    je .Lssa_main_2075
.Lssa_main_2077:
    cmpq $9, %rdi
    jne .Lssa_main_1939
.Lssa_main_2075:
    .loc 2 854 9
    subq $1, %r15
    cmpq %r9, %r15
    jg .Lssa_main_2080
.Lssa_main_1939:
    cmpq $0, -152(%rbp)
    jl .Lssa_main_1934
.Lssa_main_1938:
    movq -72(%rbp), %r11
    movq 16(%r11), %rdi
    movq -152(%rbp), %rcx
    cmpq (%rdi), %rcx
    jae __fern_oob_abort
    movq 8(%rdi,%rcx,8), %rsi
    movq 8(%rsi), %rdi
    movq %r15, %rsi
    subq %r9, %rsi
    movslq %esi, %rsi
    cmpq %rsi, %rdi
    jne .Lssa_main_1934
.Lssa_main_1937:
    movq -72(%rbp), %r11
    movq 16(%r11), %r13
    movq -152(%rbp), %rcx
    cmpq (%r13), %rcx
    jae __fern_oob_abort
    movq 8(%r13,%rcx,8), %r8
    .loc 2 2350 3
    movq 8(%r8), %rsi
    xorl %edi, %edi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %rdi, %rcx
    movq %r8, %rdx
    movq %r14, %rax
    movq %rsi, %r8
    movq %r9, %rsi
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L202_aop
    xorq %rsi, %rsi
.L202_aop:
    cmpq %r9, %rsi
    jle .L202_aok
    movq %r9, %rsi
.L202_aok:
    cmpq $0, %rcx
    jge .L202_bop
    xorq %rcx, %rcx
.L202_bop:
    cmpq %r10, %rcx
    jle .L202_bok
    movq %r10, %rcx
.L202_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L202_na
    movq %r9, %r8
.L202_na:
    cmpq %r10, %r8
    jle .L202_nb
    movq %r10, %r8
.L202_nb:
    cmpq $0, %r8
    jge .L202_nok
    xorq %r8, %r8
.L202_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L202_vec
    cmpq $8, %r8
    jge .L202_w8
    cmpq $4, %r8
    jge .L202_w4
    cmpq $2, %r8
    jge .L202_w2
    jmp .L202_tail
.L202_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L202_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L202_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L202_done
.L202_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L202_done
.L202_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L202_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L202_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L202_done
.L202_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L202_done
.L202_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L202_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L202_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L202_done
.L202_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L202_done
.L202_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L202_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L202_hit
    addq $16, %rdx
    jmp .L202_vec
.L202_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L202_done
.L202_tail:
    cmpq %r8, %rdx
    jge .L202_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L202_th
    addq $1, %rdx
    jmp .L202_tail
.L202_th:
    movq %rdx, %rax
    jmp .L202_done
.L202_eq:
    movq %r8, %rax
.L202_done:
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq 8(%r8), %rdi
    cmpq %rdi, %rax
    jne .Lssa_main_1934
.Lssa_main_1936:
    .loc 2 857 5
    movq -152(%rbp), %rcx
    cmpq (%r13), %rcx
    jae __fern_oob_abort
    movq 8(%r13,%rcx,8), %rsi
    testb $1, %sil
    jnz .Lssa_main_rcinc5070
    cmpq $0x10000, %rsi
    jb .Lssa_main_rcinc5070
    movl -8(%rsi), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5070
    addl $1, %ecx
    movl %ecx, -8(%rsi)
.Lssa_main_rcinc5070:
    movq %rsi, -152(%rbp)
    jmp .Lssa_main_1930
.Lssa_main_1934:
    leaq .K9(%rip), %rsi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %rsi, %rdx
    movq %r9, %rcx
    movq %r14, %rax
    movq (%rax), %r8
    addq $8, %rax
    testq %rcx, %rcx
    jns .L203
    xorq %rcx, %rcx
.L203:
    leaq .S71(%rip), %r11
    leaq (%rax,%rcx), %r9
    leaq -16(%rax,%r8), %r10
    cmpq %r10, %r9
    jg .L206
    vbroadcasti128 (%r11), %ymm2
    vbroadcasti128 16(%r11), %ymm3
    vbroadcasti128 32(%r11), %ymm4
    vbroadcasti128 48(%r11), %ymm5
    vbroadcasti128 64(%r11), %ymm6
    vbroadcasti128 80(%r11), %ymm7
.L204:
    leaq 16(%r9), %rdx
    cmpq %r10, %rdx
    jg .L210
    vmovdqu (%r9), %ymm0
    vpand %ymm5, %ymm0, %ymm1
    vpxor %ymm6, %ymm0, %ymm8
    vpand %ymm5, %ymm8, %ymm8
    vpshufb %ymm1, %ymm2, %ymm9
    vpshufb %ymm8, %ymm3, %ymm1
    vpor %ymm9, %ymm1, %ymm1
    vpsrlw $4, %ymm0, %ymm0
    vpand %ymm7, %ymm0, %ymm0
    vpshufb %ymm0, %ymm4, %ymm8
    vpand %ymm8, %ymm1, %ymm1
    vpcmpeqb %ymm8, %ymm1, %ymm1
    vpmovmskb %ymm1, %edx
    testl %edx, %edx
    jnz .L205
    addq $32, %r9
    jmp .L204
.L210:
    cmpq %r10, %r9
    jg .L211
    vmovdqu (%r9), %xmm0
    vpand %xmm5, %xmm0, %xmm1
    vpxor %xmm6, %xmm0, %xmm8
    vpand %xmm5, %xmm8, %xmm8
    vpshufb %xmm1, %xmm2, %xmm9
    vpshufb %xmm8, %xmm3, %xmm1
    vpor %xmm9, %xmm1, %xmm1
    vpsrlw $4, %xmm0, %xmm0
    vpand %xmm7, %xmm0, %xmm0
    vpshufb %xmm0, %xmm4, %xmm8
    vpand %xmm8, %xmm1, %xmm1
    vpcmpeqb %xmm8, %xmm1, %xmm1
    vpmovmskb %xmm1, %edx
    testl %edx, %edx
    jnz .L205
    addq $16, %r9
.L211:
    vzeroupper
    movq %r9, %rcx
    subq %rax, %rcx
    jmp .L206
.L205:
    vzeroupper
    bsfl %edx, %edx
    subq %rax, %r9
    addq %rdx, %r9
    pushq %r9
    jmp .L209
.L206:
    cmpq %r8, %rcx
    jge .L208
    movzbq (%rax,%rcx), %r9
    cmpb $0, 96(%r11,%r9)
    jne .L207
    addq $1, %rcx
    jmp .L206
.L207:
    pushq %rcx
    jmp .L209
.L208:
    pushq %r8
.L209:
    popq %rax
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    cmpq %r15, %rax
    jge .Lssa_main_1932
.Lssa_main_2109:
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    jmp .Lssa_main_110
.Lssa_main_1932:
    .loc 2 713 5
    movq %r10, -184(%rbp)
    movq %r14, %rax
    movq %r9, %rsi
    movq %r15, %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r13
    movq -184(%rbp), %r10
.Lssa_main_2113:
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn_utf8__is_valid.r
    movq -184(%rbp), %r10
    testq %rax, %rax
    jnz .Lssa_main_1931
.Lssa_main_2116:
    movq %r10, -184(%rbp)
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r10
    jmp .Lssa_main_110
.Lssa_main_1931:
    movq %r13, -152(%rbp)
.Lssa_main_1930:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_1923
.Lssa_main_1929:
    .loc 2 899 11
    movq -72(%rbp), %r11
    movq 8(%r11), %r9
    cmpq (%r9), %r12
    jae __fern_oob_abort
    movq 8(%r9,%r12,8), %r15
    movq %r10, -184(%rbp)
    movq %r14, %rax
    movq -136(%rbp), %rsi
    movq -144(%rbp), %rdi
    movq %r15, %r8
    call __fn_http____shared_string.r
    movq %rax, %r9
    movq -184(%rbp), %r10
    .loc 2 900 16
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq 8(%r9), %rdx
    cmpq 8(%r15), %rdx
    jne .Lssa_main_streqn5104
    movq %r9, %rax
    movq %r15, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd5104
.Lssa_main_streqn5104:
    xorl %eax, %eax
.Lssa_main_streqd5104:
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    testq %rax, %rax
    jz .Lssa_main_1927
.Lssa_main_1928:
    movq -72(%rbp), %r11
    movq 16(%r11), %rsi
    cmpq (%rsi), %r12
    jae __fern_oob_abort
    movq 8(%rsi,%r12,8), %rdi
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -152(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa_main_streqn5107
    movq %r11, %rax
    movq %rdi, %rsi
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd5107
.Lssa_main_streqn5107:
    xorl %eax, %eax
.Lssa_main_streqd5107:
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %rax, -160(%rbp)
    jmp .Lssa_main_1926
.Lssa_main_1927:
    movq $0, -160(%rbp)
.Lssa_main_1926:
    movq -160(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_2129
.Lssa_main_2128:
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r9, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -152(%rbp), %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    jmp .Lssa_main_1925
.Lssa_main_2129:
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    jmp .Lssa_main_1924
.Lssa_main_1925:
    movq -160(%rbp), %rcx
    movq %rcx, -112(%rbp)
    jmp .Lssa_main_1921
.Lssa_main_1924:
    movq -72(%rbp), %r11
    testb $1, %r11b
    jnz .Lssa_main_rcinc5114
    cmpq $0x10000, %r11
    jb .Lssa_main_rcinc5114
    movl -8(%r11), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5114
    addl $1, %ecx
    movl %ecx, -8(%r11)
.Lssa_main_rcinc5114:
    .loc 2 902 15
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq -72(%rbp), %rax
    movq %r12, %rsi
    call __fn_http____leading_fields.r
    movq %rax, %r8
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    testb $1, %r8b
    jnz .Lssa_main_uq1924
    cmpq $0x10000, %r8
    jb .Lssa_main_uq1924
    movl -8(%r8), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq1924:
    jne .Lssa_main_2134
.Lssa_main_2133:
    movq %r8, %r12
    jmp .Lssa_main_2135
.Lssa_main_2134:
    xorl %r12d, %r12d
.Lssa_main_2135:
    .loc 6 301 3
    movq 8(%r8), %r15
    cmpq $0, %r12
    jne .Lssa_main_2138
.Lssa_main_2136:
    testb $1, %r15b
    jnz .Lssa_main_rcinc5122
    cmpq $0x10000, %r15
    jb .Lssa_main_rcinc5122
    movl -8(%r15), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5122
    addl $1, %ecx
    movl %ecx, -8(%r15)
.Lssa_main_rcinc5122:
.Lssa_main_2138:
    testb $1, %r15b
    jnz .Lssa_main_uq2138
    cmpq $0x10000, %r15
    jb .Lssa_main_uq2138
    movl -8(%r15), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq2138:
    jne .Lssa_main_2140
.Lssa_main_2139:
    movq %r15, %rdi
    movq %r9, %rsi
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq %rax, %r13
    jmp .Lssa_main_2141
.Lssa_main_2140:
    movq %r15, %rdi
    movq %r9, %rsi
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %rax, %r13
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
.Lssa_main_2141:
    movq 16(%r8), %r15
    cmpq $0, %r12
    jne .Lssa_main_2144
.Lssa_main_2142:
    testb $1, %r15b
    jnz .Lssa_main_rcinc5132
    cmpq $0x10000, %r15
    jb .Lssa_main_rcinc5132
    movl -8(%r15), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5132
    addl $1, %ecx
    movl %ecx, -8(%r15)
.Lssa_main_rcinc5132:
.Lssa_main_2144:
    testb $1, %r15b
    jnz .Lssa_main_uq2144
    cmpq $0x10000, %r15
    jb .Lssa_main_uq2144
    movl -8(%r15), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq2144:
    jne .Lssa_main_2146
.Lssa_main_2145:
    movq %r15, %rdi
    movq -152(%rbp), %rsi
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %rax, %r15
    jmp .Lssa_main_2147
.Lssa_main_2146:
    movq %r15, %rdi
    movq -152(%rbp), %rsi
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %rax, %r9
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq %r8, -184(%rbp)
    movq %r9, -192(%rbp)
    movq %r10, -200(%rbp)
    movq %r15, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r9
    movq -200(%rbp), %r10
    movq %r9, %r15
.Lssa_main_2147:
    cmpq $0, %r12
    jne .Lssa_main_2149
.Lssa_main_2148:
    movl $3, %r9d
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r12, %rax
    movq %r9, %rsi
    call __fn___fern_alloc_reuse.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    leaq .S0(%rip), %r9
    movq %r9, 0(%rax)
    movq %rax, %r9
    jmp .Lssa_main_2150
.Lssa_main_2149:
    movq %r12, %r9
.Lssa_main_2150:
    cmpq $0, %r12
    jne .Lssa_main_2153
.Lssa_main_2152:
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r8, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
.Lssa_main_2153:
    movq %r13, 8(%r9)
    movq %r15, 16(%r9)
    movq %r9, %rbx
    movq -160(%rbp), %rcx
    movq %rcx, -112(%rbp)
    jmp .Lssa_main_1921
.Lssa_main_1923:
    .loc 2 713 5
    movq %r10, -184(%rbp)
    movq %r14, %rax
    movq -136(%rbp), %rsi
    movq -144(%rbp), %rdi
    call __fn___fern_string_from_bytes_range_u8.r
    movq %rax, %r8
    movq -184(%rbp), %r10
.Lssa_main_2155:
    testb $1, %bl
    jnz .Lssa_main_uq2155
    cmpq $0x10000, %rbx
    jb .Lssa_main_uq2155
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq2155:
    jne .Lssa_main_2158
.Lssa_main_2157:
    movq %rbx, %r15
    jmp .Lssa_main_2159
.Lssa_main_2158:
    xorl %r15d, %r15d
.Lssa_main_2159:
    .loc 6 301 3
    movq 8(%rbx), %r13
    cmpq $0, %r15
    jne .Lssa_main_2162
.Lssa_main_2160:
    testb $1, %r13b
    jnz .Lssa_main_rcinc5159
    cmpq $0x10000, %r13
    jb .Lssa_main_rcinc5159
    movl -8(%r13), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5159
    addl $1, %ecx
    movl %ecx, -8(%r13)
.Lssa_main_rcinc5159:
.Lssa_main_2162:
    testb $1, %r13b
    jnz .Lssa_main_uq2162
    cmpq $0x10000, %r13
    jb .Lssa_main_uq2162
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq2162:
    jne .Lssa_main_2164
.Lssa_main_2163:
    movq %r13, %rdi
    movq %r8, %rsi
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %rax, %r12
    jmp .Lssa_main_2165
.Lssa_main_2164:
    movq %r13, %rdi
    movq %r8, %rsi
    movq %r10, -184(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r10
    movq %rax, %r12
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r10
    movq %r10, -184(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r10
.Lssa_main_2165:
    movq 16(%rbx), %r13
    cmpq $0, %r15
    jne .Lssa_main_2168
.Lssa_main_2166:
    testb $1, %r13b
    jnz .Lssa_main_rcinc5169
    cmpq $0x10000, %r13
    jb .Lssa_main_rcinc5169
    movl -8(%r13), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5169
    addl $1, %ecx
    movl %ecx, -8(%r13)
.Lssa_main_rcinc5169:
.Lssa_main_2168:
    testb $1, %r13b
    jnz .Lssa_main_uq2168
    cmpq $0x10000, %r13
    jb .Lssa_main_uq2168
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq2168:
    jne .Lssa_main_2170
.Lssa_main_2169:
    movq %r13, %rdi
    movq -152(%rbp), %rsi
    movq %r10, -184(%rbp)
    call __fern_arr_push_owned
    movq -184(%rbp), %r10
    movq %rax, %r13
    jmp .Lssa_main_2171
.Lssa_main_2170:
    movq %r13, %rdi
    movq -152(%rbp), %rsi
    movq %r10, -184(%rbp)
    call __fern_arr_push
    movq -184(%rbp), %r10
    movq %rax, %r8
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_inc_elems.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %r8, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -184(%rbp), %r8
    movq -192(%rbp), %r10
    movq %r8, %r13
.Lssa_main_2171:
    cmpq $0, %r15
    jne .Lssa_main_2173
.Lssa_main_2172:
    movl $3, %r8d
    movq %r10, -184(%rbp)
    movq %r15, %rax
    movq %r8, %rsi
    call __fn___fern_alloc_reuse.r
    movq -184(%rbp), %r10
    leaq .S0(%rip), %r8
    movq %r8, 0(%rax)
    movq %rax, %r9
    jmp .Lssa_main_2174
.Lssa_main_2173:
    movq %r15, %r9
.Lssa_main_2174:
    cmpq $0, %r15
    jne .Lssa_main_2177
.Lssa_main_2176:
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    movq %rbx, %rax
    call __fn___sem_release_HeaderMap.r
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
.Lssa_main_2177:
    movq %r12, 8(%r9)
    movq %r13, 16(%r9)
    movq %r9, %rbx
.Lssa_main_1922:
.Lssa_main_1921:
    .loc 2 912 8
    addq $2, %r10
    movslq %r10d, %r11
    movq %r11, -136(%rbp)
    movq -136(%rbp), %r11
    cmpq -80(%rbp), %r11
    jge .Lssa_main_1977
    jmp .Lssa_main_1974
.Lssa_main_126:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_119
.Lssa_main_125:
    movq -72(%rbp), %r11
    movq 8(%r11), %r10
    movq 0(%r10), %r8
    cmpq %r8, -120(%rbp)
    jne .Lssa_main_119
    jmp .Lssa_main_114
.Lssa_main_122:
    .loc 2 879 7
    movl $400, %r8d
    jmp .Lssa_main_108
.Lssa_main_121:
    .loc 2 883 7
    movl $431, %r8d
    jmp .Lssa_main_108
.Lssa_main_119:
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_114
.Lssa_main_118:
    .loc 2 918 5
    movq -72(%rbp), %rax
    movq -120(%rbp), %rsi
    call __fn_http____leading_fields.r
    call __fn___sem_release_HeaderMap.r
.Lssa_main_114:
    .loc 2 1470 3
    movl $2, %ebx
    jmp .Lssa_main_107
.Lssa_main_110:
    .loc 2 909 9
    movl $400, %r8d
.Lssa_main_109:
.Lssa_main_108:
    movq %r8, %rbx
.Lssa_main_107:
    cmpq $2, %rbx
    je .Lssa_main_104
.Lssa_main_2199:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -96(%rbp), %rax
    call __fn___fern_arr_dec.r
.Lssa_main_106:
    movq %rbx, -72(%rbp)
    jmp .Lssa_main_98
.Lssa_main_104:
    .loc 2 1512 7
.Lssa_main_103:
    .loc 2 1474 3
    .loc 2 1475 3
.Lssa_main_102:
    xorl %edi, %edi
    movl $1, %r8d
.Lssa_main_2204:
    movq -96(%rbp), %r11
    movq 0(%r11), %r10
    cmpq %r10, %r8
    jge .Lssa_main_101
.Lssa_main_2205:
    .loc 2 1477 11
    movq -96(%rbp), %r11
    movq 8(%r11,%r8,8), %r10
    addq %rdi, %r10
    movslq %r10d, %rdi
    .loc 2 1478 7
    addq $2, %r8
    movslq %r8d, %r8
    jmp .Lssa_main_2204
.Lssa_main_101:
    .loc 2 1480 3
    call __fern_alloc_bytes
    .loc 2 1482 5
    .loc 2 1481 3
.Lssa_main_100:
    movq %rax, %r13
    xorl %ebx, %ebx
    xorl %r12d, %r12d
.Lssa_main_2212:
    leaq 1(%rbx), %rdi
    movslq %edi, %rdi
    movq -96(%rbp), %r11
    movq 0(%r11), %r8
    cmpq %r8, %rdi
    jl .Lssa_main_2213
.Lssa_main_2215:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    movq -96(%rbp), %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_99
.Lssa_main_2213:
    .loc 2 1484 9
    leaq 1(%rbx), %r8
    movslq %r8d, %r15
    movq %rbx, %r8
    sarq $31, %r8
    orq %r15, %r8
    movq -96(%rbp), %r11
    cmpq (%r11), %r8
    jae __fern_oob_abort
    movq 8(%r11,%rbx,8), %rdi
    movq 8(%r11,%r15,8), %r8
    pushq %r13
    pushq %r12
    pushq %r14
    pushq %rdi
    pushq %r8
    call __fn___fern_bytes_into
    addq $40, %rsp
    movq %rax, %r13
    .loc 2 1485 7
    movq -96(%rbp), %r11
    cmpq (%r11), %r15
    jae __fern_oob_abort
    movq 8(%r11,%r15,8), %r8
    addq %r8, %r12
    movslq %r12d, %r12
    .loc 2 1486 7
    addq $2, %rbx
    movslq %ebx, %rbx
    jmp .Lssa_main_2212
.Lssa_main_99:
    movq $2, -72(%rbp)
.Lssa_main_98:
    cmpq $2, -72(%rbp)
    je .Lssa_main_95
.Lssa_main_2220:
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
    jmp .Lssa_main_38
.Lssa_main_95:
    .loc 1 10 5
    leaq .SB195(%rip), %r8
    movq %r8, %rax
    movq -128(%rbp), %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r12
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    .loc 2 255 3
    movq $2, %rdi
    call __fern_arr_box
    movq %rax, %r13
    leaq .S4(%rip), %r8
    movq %r8, 0(%r13)
    movq %r12, 8(%r13)
    .loc 6 90 3
    leaq .K1(%rip), %r12
    leaq .K1(%rip), %r14
    .loc 2 255 3
    leaq .K4(%rip), %r15
    movl $200, %ebx
    movq $6, %rdi
    call __fern_arr_box
    leaq .S5(%rip), %rdi
    movq %rdi, 0(%rax)
    movq %rbx, 8(%rax)
    movq %r13, 16(%rax)
    movq %r12, 24(%rax)
    movq %r14, 32(%rax)
    movq %r15, 40(%rax)
.Lssa_main_93:
    .loc 2 2406 3
    leaq .SB196(%rip), %r11
    movq %r11, -80(%rbp)
    .loc 2 255 3
.Lssa_main_92:
    movq %rax, %r14
    movq $200, -96(%rbp)
.Lssa_main_2224:
    movq 24(%r14), %rax
    call __fn_http__fields_ok.r
    testq %rax, %rax
    jnz .Lssa_main_2226
.Lssa_main_2228:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_main_2225
.Lssa_main_2226:
    movq 32(%r14), %rax
    call __fn_http__fields_ok.r
    testq %rax, %rax
    jnz .Lssa_main_89
.Lssa_main_2232:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
.Lssa_main_2225:
    .loc 2 271 3
    leaq .K5(%rip), %r14
    movq $500, -96(%rbp)
    jmp .Lssa_main_2224
.Lssa_main_89:
    .loc 2 2487 3
    cmpq $200, -96(%rbp)
    jl .Lssa_main_85
.Lssa_main_87:
    cmpq $204, -96(%rbp)
    jne .Lssa_main_84
.Lssa_main_85:
    movq $1, -112(%rbp)
    jmp .Lssa_main_82
.Lssa_main_84:
    movq -96(%rbp), %r8
    cmpq $304, %r8
    sete %r8b
    movzbq %r8b, %r8
    movq %r8, -112(%rbp)
.Lssa_main_83:
.Lssa_main_82:
    .loc 2 2414 3
    leaq .SB6(%rip), %r8
    .loc 2 2415 3
    leaq .SB6(%rip), %rdi
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_80
.Lssa_main_81:
    movq %r8, -120(%rbp)
    movq %rdi, -128(%rbp)
    jmp .Lssa_main_79
.Lssa_main_80:
    .loc 2 2417 10
    movq %r14, %rax
    call __fn_HttpResponse__body_text_lossy.r
    movq %rax, %rbx
    .loc 2 2418 13
    leaq .SB7(%rip), %r8
    movq 8(%rbx), %rax
    .loc 14 147 5
    movq %r8, -184(%rbp)
    call __fn_int__int_to_string.r
    movq %rax, %r10
    movq -184(%rbp), %r8
    .loc 2 2418 13
    movq %r10, -184(%rbp)
    movq %r8, %rax
    movq %r10, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r9
    movq -184(%rbp), %r10
    movq %r9, -184(%rbp)
    movq %r10, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r9
    leaq .SB8(%rip), %r10
    movq %r9, -184(%rbp)
    movq %r10, -192(%rbp)
    pushq %r9
    pushq %r10
    call __fn___fern_str_grow
    addq $16, %rsp
    movq -184(%rbp), %r9
    movq -192(%rbp), %r10
    testq %rax, %rax
    jz .Lssa_main_2253
.Lssa_main_2252:
    movq %r9, %r8
    jmp .Lssa_main_2254
.Lssa_main_2253:
    movq %r9, -184(%rbp)
    pushq %r9
    pushq %r10
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %r8
    movq -184(%rbp), %r9
    movq %r8, -184(%rbp)
    movq %r9, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
.Lssa_main_2254:
    movq %r8, -120(%rbp)
    movq %rbx, -128(%rbp)
.Lssa_main_79:
    .loc 2 2420 3
    movl $256, %r8d
    movq %r8, %rdi
    call __fern_buf_new
    movq %rax, %r13
.Lssa_main_77:
    leaq .SB9(%rip), %r8
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push
.Lssa_main_76:
    cmpq $0, -96(%rbp)
    jge .Lssa_main_73
.Lssa_main_75:
    movl $45, %r8d
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push_byte
    xorl %r8d, %r8d
    subq -96(%rbp), %r8
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push_decimal
    jmp .Lssa_main_72
.Lssa_main_73:
    movq %r13, %rdi
    movq -96(%rbp), %rsi
    call __fern_buf_push_decimal
.Lssa_main_72:
    leaq .SB10(%rip), %r8
    movq %r13, %rdi
    movq %r8, %rsi
    call __fern_buf_push
.Lssa_main_70:
    leaq .K6(%rip), %r8
    leaq .K7(%rip), %r10
.Lssa_main_69:
    xorl %r9d, %r9d
.Lssa_main_2260:
    movq 0(%r8), %rdi
    cmpq %rdi, %r9
    jge .Lssa_main_68
.Lssa_main_2263:
    movq 8(%r8,%r9,8), %rdi
    cmpq -96(%rbp), %rdi
    je .Lssa_main_67
.Lssa_main_2261:
    addq $1, %r9
    jmp .Lssa_main_2260
.Lssa_main_68:
    leaq .SB6(%rip), %r8
    jmp .Lssa_main_66
.Lssa_main_67:
    cmpq (%r10), %r9
    jae __fern_oob_abort
    movq 8(%r10,%r9,8), %r8
    testb $1, %r8b
    jnz .Lssa_main_rcinc5803
    cmpq $0x10000, %r8
    jb .Lssa_main_rcinc5803
    movl -8(%r8), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5803
    addl $1, %ecx
    movl %ecx, -8(%r8)
.Lssa_main_rcinc5803:
.Lssa_main_66:
    movq 8(%r8), %r9
    cmpq $0, %r9
    jne .Lssa_main_64
.Lssa_main_2275:
    movq %r8, -184(%rbp)
    movq %r8, %rax
    call __fn___fern_str_free.r
    movq -184(%rbp), %r8
.Lssa_main_65:
    leaq .SB61(%rip), %r9
    movq %r9, %rbx
    jmp .Lssa_main_63
.Lssa_main_64:
    movq %r8, %rbx
.Lssa_main_63:
    movq %r13, %rdi
    movq %rbx, %rsi
    call __fern_buf_push
    movq %rbx, %rax
    call __fn___fern_str_free.r
    leaq .SB8(%rip), %r9
    movq %r13, %rdi
    movq %r9, %rsi
    call __fern_buf_push
.Lssa_main_62:
    xorl %ebx, %ebx
.Lssa_main_2280:
    movq 24(%r14), %r9
    movq 8(%r9), %r8
    movq 0(%r8), %r9
    cmpq %r9, %rbx
    jl .Lssa_main_2286
.Lssa_main_2288:
    movq %r14, %rax
    call __fn___sem_release_HttpResponse.r
    jmp .Lssa_main_60
.Lssa_main_2286:
    movq 24(%r14), %r15
    movq 8(%r15), %r9
    movq 8(%r9,%rbx,8), %r12
    leaq .SB62(%rip), %rsi
    movq %r12, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_main_2281
.Lssa_main_2285:
    leaq .SB63(%rip), %rsi
    movq %r12, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_main_2281
.Lssa_main_2284:
    leaq .SB64(%rip), %rsi
    movq %r12, %rax
    call __fn_string__eq_ignore_ascii_case.r
    testq %rax, %rax
    jnz .Lssa_main_2281
.Lssa_main_2282:
    movq 8(%r15), %rsi
    movq 8(%rsi,%rbx,8), %r9
    movq %r13, %rdi
    movq %r9, %rsi
    call __fern_buf_push
    leaq .SB65(%rip), %r9
    movq %r13, %rdi
    movq %r9, %rsi
    call __fern_buf_push
    movq 16(%r15), %r9
    cmpq (%r9), %rbx
    jae __fern_oob_abort
    movq 8(%r9,%rbx,8), %rsi
    movq %r13, %rdi
    call __fern_buf_push
    leaq .SB8(%rip), %rsi
    movq %r13, %rdi
    call __fern_buf_push
.Lssa_main_2281:
    addq $1, %rbx
    jmp .Lssa_main_2280
.Lssa_main_60:
    movq %r13, %rdi
    movq -120(%rbp), %rsi
    call __fern_buf_push
    movq -120(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_main_59:
    cmpq $101, -96(%rbp)
    jne .Lssa_main_54
.Lssa_main_58:
    leaq .SB66(%rip), %rsi
    movq %r13, %rdi
    call __fern_buf_push
    jmp .Lssa_main_51
.Lssa_main_54:
    leaq .SB67(%rip), %rsi
    movq %r13, %rdi
    call __fern_buf_push
.Lssa_main_51:
    .loc 2 2422 3
    movq %r13, %rdi
    call __fern_buf_take
    movq %rax, %rbx
    movq %r13, %rdi
    call __fern_buf_free
    movq -112(%rbp), %r11
    testq %r11, %r11
    jz .Lssa_main_50
.Lssa_main_2311:
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
    jmp .Lssa_main_49
.Lssa_main_50:
    leaq .SB69(%rip), %rsi
    movq -80(%rbp), %r11
    movq 8(%r11), %r9
    cmpq $4, %r9
    jne .Lssa_main_47
.Lssa_main_2315:
    movq -80(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rsi), %rdx
    jne .Lssa_main_streqn5881
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn5881
    movq %r11, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd5881
.Lssa_main_streqn5881:
    xorl %eax, %eax
.Lssa_main_streqd5881:
    testq %rax, %rax
    jz .Lssa_main_47
.Lssa_main_2318:
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_main_49:
    movq %rbx, %r13
    jmp .Lssa_main_44
.Lssa_main_47:
    .loc 2 2427 3
    pushq %rbx
    pushq -128(%rbp)
    call __fn___fern_str_grow
    addq $16, %rsp
    testq %rax, %rax
    jz .Lssa_main_2324
.Lssa_main_2323:
    movq %rbx, %r13
    jmp .Lssa_main_2325
.Lssa_main_2324:
    pushq %rbx
    pushq -128(%rbp)
    call __fn___fern_str_grow_fresh
    addq $16, %rsp
    movq %rax, %r13
    movq %rbx, %rax
    call __fn___fern_str_free.r
.Lssa_main_2325:
    movq -128(%rbp), %rax
    call __fn___fern_str_free.r
.Lssa_main_46:
.Lssa_main_44:
    .loc 1 12 11
    movq 8(%r13), %rbx
    movq %r13, %rax
    call __fn___fern_str_free.r
    movq -88(%rbp), %r11
    testb $1, %r11b
    jnz .Lssa_main_uq44
    cmpq $0x10000, %r11
    jb .Lssa_main_uq44
    movl -8(%r11), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq44:
    jne .Lssa_main_2327
.Lssa_main_2326:
    movq -88(%rbp), %rsi
    jmp .Lssa_main_2328
.Lssa_main_2327:
    xorl %esi, %esi
.Lssa_main_2328:
    .loc 6 348 3
    movq -88(%rbp), %r11
    movq 8(%r11), %r13
    cmpq $0, %rsi
    jne .Lssa_main_2331
.Lssa_main_2329:
    testb $1, %r13b
    jnz .Lssa_main_rcinc5903
    cmpq $0x10000, %r13
    jb .Lssa_main_rcinc5903
    movl -8(%r13), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lssa_main_rcinc5903
    addl $1, %ecx
    movl %ecx, -8(%r13)
.Lssa_main_rcinc5903:
.Lssa_main_2331:
    cmpq $0, %rsi
    je .Lssa_main_2333
.Lssa_main_2332:
    movq -88(%rbp), %r11
    movq 16(%r11), %r14
    testb $1, %r14b
    jnz .Lssa_main_uq2332
    cmpq $0x10000, %r14
    jb .Lssa_main_uq2332
    movl -8(%r14), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq2332:
    jne .Lssa_main_2337
.Lssa_main_2335:
    xorl %r15d, %r15d
.Lssa_main_2339:
    movq 0(%r14), %rsi
    cmpq %rsi, %r15
    jge .Lssa_main_2337
.Lssa_main_2340:
    movq 8(%r14,%r15,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r15
    jmp .Lssa_main_2339
.Lssa_main_2337:
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq -88(%rbp), %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa_main_2334
.Lssa_main_2333:
    movq -88(%rbp), %rax
    call __fn___sem_release_HeaderMap.r
.Lssa_main_2334:
    movq 0(%r13), %r15
    testb $1, %r13b
    jnz .Lssa_main_uq2334
    cmpq $0x10000, %r13
    jb .Lssa_main_uq2334
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa_main_uq2334:
    jne .Lssa_main_2345
.Lssa_main_2343:
    xorl %r14d, %r14d
.Lssa_main_2347:
    movq 0(%r13), %rsi
    cmpq %rsi, %r14
    jge .Lssa_main_2345
.Lssa_main_2348:
    movq 8(%r13,%r14,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r14
    jmp .Lssa_main_2347
.Lssa_main_2345:
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    .loc 1 12 11
    addq %r15, %rbx
    movslq %ebx, %rbx
    addq %rbx, -56(%rbp)
.Lssa_main_43:
    addq $1, -64(%rbp)
    cmpq $4000, -64(%rbp)
    jl .Lssa_main_396
.Lssa_main_40:
    .loc 1 14 3
    movq -56(%rbp), %rax
    movq %rax, %rcx
    movabsq $-6275696437447579415, %rax
    imulq %rcx
    addq %rcx, %rdx
    sarq $6, %rdx
    movq %rdx, %rax
    shrq $63, %rdx
    addq %rdx, %rax
    imulq $97, %rax, %rax
    subq %rax, %rcx
    movq %rcx, %rax
    movq %rax, %rsi
    movslq %esi, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa_main_38:
    cmpq $400, -72(%rbp)
    jge .Lssa_main_1
.Lssa_main_35:
    leaq .SB186(%rip), %rsi
    movq -104(%rbp), %r11
    movq 8(%r11), %r9
    cmpq $8, %r9
    jne .Lssa_main_2359
.Lssa_main_2358:
    movq -104(%rbp), %r11
    movq 8(%r11), %rdx
    cmpq 8(%rsi), %rdx
    jne .Lssa_main_streqn5953
    movq (%r11), %rdx
    cmpb $72, (%rdx)
    jne .Lssa_main_streqn5953
    movq %r11, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa_main_streqd5953
.Lssa_main_streqn5953:
    xorl %eax, %eax
.Lssa_main_streqd5953:
    jmp .Lssa_main_2360
.Lssa_main_2359:
    xorl %eax, %eax
.Lssa_main_2360:
    testq %rax, %rax
    jz .Lssa_main_1
.Lssa_main_34:
.Lssa_main_31:
.Lssa_main_30:
.Lssa_main_29:
.Lssa_main_28:
.Lssa_main_27:
.Lssa_main_26:
.Lssa_main_25:
.Lssa_main_24:
.Lssa_main_23:
.Lssa_main_17:
.Lssa_main_16:
.Lssa_main_15:
.Lssa_main_11:
.Lssa_main_10:
.Lssa_main_8:
.Lssa_main_1:
    .loc 1 8 7
    movl $100, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_HeaderMap
.weak __fn___sem_drop_HeaderMap.r
__fn___sem_drop_HeaderMap:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_HeaderMap.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_drop_HeaderMap_0:
    movq 8(%rbx), %r12
    testb $1, %r12b
    jnz .Lssa___sem_drop_HeaderMap_uq0
    cmpq $0x10000, %r12
    jb .Lssa___sem_drop_HeaderMap_uq0
    movl -8(%r12), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_drop_HeaderMap_uq0:
    jne .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_1:
    xorl %r13d, %r13d
.Lssa___sem_drop_HeaderMap_5:
    movq 0(%r12), %rsi
    cmpq %rsi, %r13
    jge .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_6:
    movq 8(%r12,%r13,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %r13
    jmp .Lssa___sem_drop_HeaderMap_5
.Lssa___sem_drop_HeaderMap_3:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq 16(%rbx), %r13
    testb $1, %r13b
    jnz .Lssa___sem_drop_HeaderMap_uq3
    cmpq $0x10000, %r13
    jb .Lssa___sem_drop_HeaderMap_uq3
    movl -8(%r13), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_drop_HeaderMap_uq3:
    jne .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_9:
    xorl %ebx, %ebx
.Lssa___sem_drop_HeaderMap_13:
    movq 0(%r13), %rsi
    cmpq %rsi, %rbx
    jge .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_14:
    movq 8(%r13,%rbx,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    addq $1, %rbx
    jmp .Lssa___sem_drop_HeaderMap_13
.Lssa___sem_drop_HeaderMap_11:
    movq %r13, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_HeaderMap
.weak __fn___sem_release_HeaderMap.r
__fn___sem_release_HeaderMap:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_HeaderMap.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_HeaderMap_0:
    testb $1, %bl
    jnz .Lssa___sem_release_HeaderMap_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_HeaderMap_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_HeaderMap_uq0:
    jne .Lssa___sem_release_HeaderMap_3
.Lssa___sem_release_HeaderMap_1:
    movq %rbx, %rax
    call __fn___sem_drop_HeaderMap.r
.Lssa___sem_release_HeaderMap_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_HttpResponse
.weak __fn___sem_drop_HttpResponse.r
__fn___sem_drop_HttpResponse:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_HttpResponse.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_drop_HttpResponse_0:
    movq 16(%rbx), %rax
    call __fn___sem_release_Body.r
    movq 24(%rbx), %rax
    call __fn___sem_release_HeaderMap.r
    movq 32(%rbx), %rax
    call __fn___sem_release_HeaderMap.r
    movq 40(%rbx), %rax
    call __fn___sem_release_Option$$fn$void.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_HttpResponse
.weak __fn___sem_release_HttpResponse.r
__fn___sem_release_HttpResponse:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_HttpResponse.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_HttpResponse_0:
    testb $1, %bl
    jnz .Lssa___sem_release_HttpResponse_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_HttpResponse_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_HttpResponse_uq0:
    jne .Lssa___sem_release_HttpResponse_3
.Lssa___sem_release_HttpResponse_1:
    movq %rbx, %rax
    call __fn___sem_drop_HttpResponse.r
.Lssa___sem_release_HttpResponse_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_ByteStream
.weak __fn___sem_drop_ByteStream.r
__fn___sem_drop_ByteStream:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_ByteStream.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_drop_ByteStream_0:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %rax
    call __fn___sem_release_Option$BodySource.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_ByteStream
.weak __fn___sem_release_ByteStream.r
__fn___sem_release_ByteStream:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_ByteStream.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_ByteStream_0:
    testb $1, %bl
    jnz .Lssa___sem_release_ByteStream_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_ByteStream_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_ByteStream_uq0:
    jne .Lssa___sem_release_ByteStream_3
.Lssa___sem_release_ByteStream_1:
    movq %rbx, %rax
    call __fn___sem_drop_ByteStream.r
.Lssa___sem_release_ByteStream_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_ChunkProducer
.weak __fn___sem_drop_ChunkProducer.r
__fn___sem_drop_ChunkProducer:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_ChunkProducer.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_drop_ChunkProducer_0:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 32(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_ChunkProducer
.weak __fn___sem_release_ChunkProducer.r
__fn___sem_release_ChunkProducer:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_ChunkProducer.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_ChunkProducer_0:
    testb $1, %bl
    jnz .Lssa___sem_release_ChunkProducer_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_ChunkProducer_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_ChunkProducer_uq0:
    jne .Lssa___sem_release_ChunkProducer_3
.Lssa___sem_release_ChunkProducer_1:
    movq %rbx, %rax
    call __fn___sem_drop_ChunkProducer.r
.Lssa___sem_release_ChunkProducer_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_BodySource
.weak __fn___sem_drop_BodySource.r
__fn___sem_drop_BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_BodySource.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_drop_BodySource_0:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 16(%rbx), %r12
    testb $1, %r12b
    jnz .Lssa___sem_drop_BodySource_uq0
    cmpq $0x10000, %r12
    jb .Lssa___sem_drop_BodySource_uq0
    movl -8(%r12), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_drop_BodySource_uq0:
    jne .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_1:
    xorl %r13d, %r13d
.Lssa___sem_drop_BodySource_5:
    movq 0(%r12), %rsi
    cmpq %rsi, %r13
    jge .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_6:
    movq 8(%r12,%r13,8), %rax
    call __fn___sem_release_Option$StreamFault.r
    addq $1, %r13
    jmp .Lssa___sem_drop_BodySource_5
.Lssa___sem_drop_BodySource_3:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_BodySource
.weak __fn___sem_release_BodySource.r
__fn___sem_release_BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_BodySource.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_BodySource_0:
    testb $1, %bl
    jnz .Lssa___sem_release_BodySource_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_BodySource_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_BodySource_uq0:
    jne .Lssa___sem_release_BodySource_3
.Lssa___sem_release_BodySource_1:
    movq %rbx, %rax
    call __fn___sem_drop_BodySource.r
.Lssa___sem_release_BodySource_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Body
.weak __fn___sem_drop_Body.r
__fn___sem_drop_Body:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Body.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    movq %rax, %rbx
.Lssa___sem_drop_Body_0:
    movq 0(%rbx), %rsi
    cmpq $.S4, %rsi
    jne .Lssa___sem_drop_Body_2
.Lssa___sem_drop_Body_1:
    movq 8(%rbx), %rdi
    movq %rdi, %rax
    call __fn___fern_str_free.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_2:
    cmpq $.S197, %rsi
    jne .Lssa___sem_drop_Body_5
.Lssa___sem_drop_Body_4:
    movq 8(%rbx), %rdi
    movq %rdi, %rax
    call __fn___fern_arr_dec.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_5:
    cmpq $.S198, %rsi
    jne .Lssa___sem_drop_Body_8
.Lssa___sem_drop_Body_7:
    movq 8(%rbx), %rax
    call __fn___sem_release_ByteStream.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_8:
    cmpq $.S199, %rsi
    jne .Lssa___sem_drop_Body_11
.Lssa___sem_drop_Body_10:
    movq 8(%rbx), %rdi
    movq %rdi, %rax
    call __fn___fern_str_free.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_11:
    cmpq $.S200, %rsi
    jne .Lssa___sem_drop_Body_14
.Lssa___sem_drop_Body_13:
    movq 8(%rbx), %rax
    call __fn___sem_release_ChunkProducer.r
    jmp .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_14:
    cmpq $.S201, %rsi
    jne .Lssa___sem_drop_Body_3
.Lssa___sem_drop_Body_16:
    movq 8(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    movq 16(%rbx), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    movq 24(%rbx), %r12
    testb $1, %r12b
    jnz .Lssa___sem_drop_Body_uq16
    cmpq $0x10000, %r12
    jb .Lssa___sem_drop_Body_uq16
    movl -8(%r12), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_drop_Body_uq16:
    jne .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_19:
    xorl %ebx, %ebx
.Lssa___sem_drop_Body_23:
    movq 0(%r12), %rsi
    cmpq %rsi, %rbx
    jge .Lssa___sem_drop_Body_21
.Lssa___sem_drop_Body_24:
    movq 8(%r12,%rbx,8), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
    addq $1, %rbx
    jmp .Lssa___sem_drop_Body_23
.Lssa___sem_drop_Body_21:
    movq %r12, %rax
    call __fn___fern_arr_dec.r
.Lssa___sem_drop_Body_3:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Body
.weak __fn___sem_release_Body.r
__fn___sem_release_Body:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Body.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_Body_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Body_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Body_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_Body_uq0:
    jne .Lssa___sem_release_Body_3
.Lssa___sem_release_Body_1:
    movq %rbx, %rax
    call __fn___sem_drop_Body.r
.Lssa___sem_release_Body_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Option$$fn$void
.weak __fn___sem_drop_Option$$fn$void.r
__fn___sem_drop_Option$$fn$void:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Option$$fn$void.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_drop_Option$$fn$void_0:
    movq 0(%rax), %rsi
    cmpq $0, %rsi
    jne .Lssa___sem_drop_Option$$fn$void_3
.Lssa___sem_drop_Option$$fn$void_1:
    movq 8(%rax), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$$fn$void_3:
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Option$$fn$void
.weak __fn___sem_release_Option$$fn$void.r
__fn___sem_release_Option$$fn$void:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Option$$fn$void.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_Option$$fn$void_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Option$$fn$void_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Option$$fn$void_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_Option$$fn$void_uq0:
    jne .Lssa___sem_release_Option$$fn$void_3
.Lssa___sem_release_Option$$fn$void_1:
    movq %rbx, %rax
    call __fn___sem_drop_Option$$fn$void.r
.Lssa___sem_release_Option$$fn$void_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Option$BodySource
.weak __fn___sem_drop_Option$BodySource.r
__fn___sem_drop_Option$BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Option$BodySource.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_drop_Option$BodySource_0:
    movq 0(%rax), %rsi
    cmpq $0, %rsi
    jne .Lssa___sem_drop_Option$BodySource_3
.Lssa___sem_drop_Option$BodySource_1:
    movq 8(%rax), %rsi
    movq %rsi, %rax
    call __fn___sem_release_BodySource.r
.Lssa___sem_drop_Option$BodySource_3:
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Option$BodySource
.weak __fn___sem_release_Option$BodySource.r
__fn___sem_release_Option$BodySource:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Option$BodySource.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_Option$BodySource_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Option$BodySource_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Option$BodySource_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_Option$BodySource_uq0:
    jne .Lssa___sem_release_Option$BodySource_3
.Lssa___sem_release_Option$BodySource_1:
    movq %rbx, %rax
    call __fn___sem_drop_Option$BodySource.r
.Lssa___sem_release_Option$BodySource_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_drop_Option$StreamFault
.weak __fn___sem_drop_Option$StreamFault.r
__fn___sem_drop_Option$StreamFault:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_drop_Option$StreamFault.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_drop_Option$StreamFault_0:
    movq 0(%rax), %rsi
    cmpq $0, %rsi
    jne .Lssa___sem_drop_Option$StreamFault_3
.Lssa___sem_drop_Option$StreamFault_1:
    movq 8(%rax), %rsi
    movq %rsi, %rax
    call __fn___fern_arr_dec.r
.Lssa___sem_drop_Option$StreamFault_3:
    xorl %eax, %eax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_release_Option$StreamFault
.weak __fn___sem_release_Option$StreamFault.r
__fn___sem_release_Option$StreamFault:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_release_Option$StreamFault.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___sem_release_Option$StreamFault_0:
    testb $1, %bl
    jnz .Lssa___sem_release_Option$StreamFault_uq0
    cmpq $0x10000, %rbx
    jb .Lssa___sem_release_Option$StreamFault_uq0
    movl -8(%rbx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
.Lssa___sem_release_Option$StreamFault_uq0:
    jne .Lssa___sem_release_Option$StreamFault_3
.Lssa___sem_release_Option$StreamFault_1:
    movq %rbx, %rax
    call __fn___sem_drop_Option$StreamFault.r
.Lssa___sem_release_Option$StreamFault_3:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -8(%rbp), %rsp
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_len
.weak __fn___sem_view_len.r
__fn___sem_view_len:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_view_len.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_view_len_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_view_len_3
.Lssa___sem_view_len_1:
    leaq -2(%rax), %rsi
    movq 8(%rsi), %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___sem_view_len_3:
    movq 0(%rax), %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_data
.weak __fn___sem_view_data.r
__fn___sem_view_data:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_view_data.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_view_data_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_view_data_3
.Lssa___sem_view_data_1:
    leaq -2(%rax), %rsi
    movq 0(%rsi), %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___sem_view_data_3:
    addq $8, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_byte_view_slice
.weak __fn___sem_byte_view_slice.r
__fn___sem_byte_view_slice:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___sem_byte_view_slice.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa___sem_byte_view_slice_0:
    cmpq $0, %r12
    jge .Lssa___sem_byte_view_slice_3
.Lssa___sem_byte_view_slice_1:
    call __fern_slice_abort
.Lssa___sem_byte_view_slice_3:
    cmpq %r12, %r13
    jge .Lssa___sem_byte_view_slice_6
.Lssa___sem_byte_view_slice_4:
    call __fern_slice_abort
.Lssa___sem_byte_view_slice_6:
    movq %rbx, %rax
    call __fn___sem_view_len.r
    cmpq %rax, %r13
    jle .Lssa___sem_byte_view_slice_9
.Lssa___sem_byte_view_slice_7:
    call __fern_slice_abort
.Lssa___sem_byte_view_slice_9:
    movq %rbx, %rax
    call __fn___sem_view_data.r
    addq %r12, %rax
    subq %r12, %r13
    pushq %rax
    pushq %r13
    call __fn___fern_str_borrow
    addq $16, %rsp
    addq $2, %rax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_slice
.weak __fn___sem_view_slice.r
__fn___sem_view_slice:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___sem_view_slice.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa___sem_view_slice_0:
    cmpq $0, %r12
    jge .Lssa___sem_view_slice_3
.Lssa___sem_view_slice_1:
    call __fern_slice_abort
.Lssa___sem_view_slice_3:
    cmpq %r12, %r13
    jge .Lssa___sem_view_slice_6
.Lssa___sem_view_slice_4:
    call __fern_slice_abort
.Lssa___sem_view_slice_6:
    movq %rbx, %rax
    call __fn___sem_view_len.r
    cmpq %rax, %r13
    jle .Lssa___sem_view_slice_9
.Lssa___sem_view_slice_7:
    call __fern_slice_abort
.Lssa___sem_view_slice_9:
    movq %rbx, %rax
    call __fn___sem_view_data.r
    movl %r12d, %esi
    imulq $8, %rsi, %rsi
    addq %rsi, %rax
    subq %r12, %r13
    pushq %rax
    pushq %r13
    call __fn___fern_str_borrow
    addq $16, %rsp
    addq $2, %rax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_slice_wide
.weak __fn___sem_view_slice_wide.r
__fn___sem_view_slice_wide:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___sem_view_slice_wide.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa___sem_view_slice_wide_0:
    cmpq $0, %r12
    jge .Lssa___sem_view_slice_wide_3
.Lssa___sem_view_slice_wide_1:
    call __fern_slice_abort
.Lssa___sem_view_slice_wide_3:
    cmpq %r12, %r13
    jge .Lssa___sem_view_slice_wide_6
.Lssa___sem_view_slice_wide_4:
    call __fern_slice_abort
.Lssa___sem_view_slice_wide_6:
    movq %rbx, %rax
    call __fn___sem_view_len.r
    cmpq %rax, %r13
    jle .Lssa___sem_view_slice_wide_9
.Lssa___sem_view_slice_wide_7:
    call __fern_slice_abort
.Lssa___sem_view_slice_wide_9:
    movq %rbx, %rax
    call __fn___sem_view_data.r
    movl %r12d, %esi
    imulq $8, %rsi, %rsi
    addq %rsi, %rax
    subq %r12, %r13
    pushq %rax
    pushq %r13
    call __fn___fern_str_borrow
    addq $16, %rsp
    addq $2, %rax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_view_release
.weak __fn___sem_view_release.r
__fn___sem_view_release:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_view_release.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_view_release_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_view_release_3
.Lssa___sem_view_release_1:
    leaq -2(%rax), %rsi
    pushq %rsi
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %rax, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___sem_view_release_3:
    call __fn___fern_arr_dec.r
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_byte_view_string
.weak __fn___sem_byte_view_string.r
__fn___sem_byte_view_string:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___sem_byte_view_string.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_byte_view_string_0:
    movq %rax, %rsi
    andq $2, %rsi
    testq %rsi, %rsi
    jz .Lssa___sem_byte_view_string_3
.Lssa___sem_byte_view_string_1:
    leaq -2(%rax), %rsi
    leaq .SB6(%rip), %rdi
    movq %rsi, %rax
    movq %rdi, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r8
    movq %r8, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_string_3:
    call __fn___fern_string_from_bytes_u8.r
    movq %rax, %r8
    movq %r8, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
.weak __fn___sem_byte_view_mismatch
.weak __fn___sem_byte_view_mismatch.r
__fn___sem_byte_view_mismatch:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn___sem_byte_view_mismatch.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
.Lssa___sem_byte_view_mismatch_0:
    movq %rax, %r10
    andq $2, %r10
    testq %r10, %r10
    jz .Lssa___sem_byte_view_mismatch_3
.Lssa___sem_byte_view_mismatch_1:
    movq %rdi, %r10
    andq $2, %r10
    testq %r10, %r10
    jz .Lssa___sem_byte_view_mismatch_6
.Lssa___sem_byte_view_mismatch_4:
    leaq -2(%rax), %r10
    leaq -2(%rdi), %rax
    movq %r8, %rcx
    movq %rax, %rdx
    movq %r10, %rax
    movq %r9, %r8
    movq 8(%rax), %r9
    movq (%rax), %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L212_aop
    xorq %rsi, %rsi
.L212_aop:
    cmpq %r9, %rsi
    jle .L212_aok
    movq %r9, %rsi
.L212_aok:
    cmpq $0, %rcx
    jge .L212_bop
    xorq %rcx, %rcx
.L212_bop:
    cmpq %r10, %rcx
    jle .L212_bok
    movq %r10, %rcx
.L212_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L212_na
    movq %r9, %r8
.L212_na:
    cmpq %r10, %r8
    jle .L212_nb
    movq %r10, %r8
.L212_nb:
    cmpq $0, %r8
    jge .L212_nok
    xorq %r8, %r8
.L212_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L212_vec
    cmpq $8, %r8
    jge .L212_w8
    cmpq $4, %r8
    jge .L212_w4
    cmpq $2, %r8
    jge .L212_w2
    jmp .L212_tail
.L212_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L212_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L212_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L212_done
.L212_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L212_done
.L212_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L212_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L212_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L212_done
.L212_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L212_done
.L212_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L212_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L212_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L212_done
.L212_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L212_done
.L212_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L212_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L212_hit
    addq $16, %rdx
    jmp .L212_vec
.L212_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L212_done
.L212_tail:
    cmpq %r8, %rdx
    jge .L212_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L212_th
    addq $1, %rdx
    jmp .L212_tail
.L212_th:
    movq %rdx, %rax
    jmp .L212_done
.L212_eq:
    movq %r8, %rax
.L212_done:
    movq %rax, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_6:
    leaq -2(%rax), %r10
    movq %rsi, %rcx
    movq %r10, %rdx
    movq %r8, %rsi
    movq %rdi, %rax
    movq %r9, %r8
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L213_aop
    xorq %rsi, %rsi
.L213_aop:
    cmpq %r9, %rsi
    jle .L213_aok
    movq %r9, %rsi
.L213_aok:
    cmpq $0, %rcx
    jge .L213_bop
    xorq %rcx, %rcx
.L213_bop:
    cmpq %r10, %rcx
    jle .L213_bok
    movq %r10, %rcx
.L213_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L213_na
    movq %r9, %r8
.L213_na:
    cmpq %r10, %r8
    jle .L213_nb
    movq %r10, %r8
.L213_nb:
    cmpq $0, %r8
    jge .L213_nok
    xorq %r8, %r8
.L213_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L213_vec
    cmpq $8, %r8
    jge .L213_w8
    cmpq $4, %r8
    jge .L213_w4
    cmpq $2, %r8
    jge .L213_w2
    jmp .L213_tail
.L213_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L213_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L213_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L213_done
.L213_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L213_done
.L213_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L213_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L213_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L213_done
.L213_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L213_done
.L213_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L213_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L213_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L213_done
.L213_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L213_done
.L213_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L213_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L213_hit
    addq $16, %rdx
    jmp .L213_vec
.L213_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L213_done
.L213_tail:
    cmpq %r8, %rdx
    jge .L213_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L213_th
    addq $1, %rdx
    jmp .L213_tail
.L213_th:
    movq %rdx, %rax
    jmp .L213_done
.L213_eq:
    movq %r8, %rax
.L213_done:
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_3:
    movq %rdi, %r10
    andq $2, %r10
    testq %r10, %r10
    jz .Lssa___sem_byte_view_mismatch_9
.Lssa___sem_byte_view_mismatch_7:
    leaq -2(%rdi), %r10
    movq %r8, %rcx
    movq %r10, %rdx
    movq %r9, %r8
    movq (%rax), %r9
    addq $8, %rax
    movq 8(%rdx), %r10
    movq (%rdx), %rdx
    cmpq $0, %rsi
    jge .L214_aop
    xorq %rsi, %rsi
.L214_aop:
    cmpq %r9, %rsi
    jle .L214_aok
    movq %r9, %rsi
.L214_aok:
    cmpq $0, %rcx
    jge .L214_bop
    xorq %rcx, %rcx
.L214_bop:
    cmpq %r10, %rcx
    jle .L214_bok
    movq %r10, %rcx
.L214_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L214_na
    movq %r9, %r8
.L214_na:
    cmpq %r10, %r8
    jle .L214_nb
    movq %r10, %r8
.L214_nb:
    cmpq $0, %r8
    jge .L214_nok
    xorq %r8, %r8
.L214_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L214_vec
    cmpq $8, %r8
    jge .L214_w8
    cmpq $4, %r8
    jge .L214_w4
    cmpq $2, %r8
    jge .L214_w2
    jmp .L214_tail
.L214_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L214_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L214_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L214_done
.L214_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L214_done
.L214_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L214_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L214_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L214_done
.L214_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L214_done
.L214_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L214_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L214_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L214_done
.L214_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L214_done
.L214_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L214_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L214_hit
    addq $16, %rdx
    jmp .L214_vec
.L214_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L214_done
.L214_tail:
    cmpq %r8, %rdx
    jge .L214_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L214_th
    addq $1, %rdx
    jmp .L214_tail
.L214_th:
    movq %rdx, %rax
    jmp .L214_done
.L214_eq:
    movq %r8, %rax
.L214_done:
    movq %rax, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_9:
    movq %r8, %rcx
    movq %rdi, %rdx
    movq %r9, %r8
    movq (%rax), %r9
    addq $8, %rax
    movq (%rdx), %r10
    addq $8, %rdx
    cmpq $0, %rsi
    jge .L215_aop
    xorq %rsi, %rsi
.L215_aop:
    cmpq %r9, %rsi
    jle .L215_aok
    movq %r9, %rsi
.L215_aok:
    cmpq $0, %rcx
    jge .L215_bop
    xorq %rcx, %rcx
.L215_bop:
    cmpq %r10, %rcx
    jle .L215_bok
    movq %r10, %rcx
.L215_bok:
    subq %rsi, %r9
    subq %rcx, %r10
    cmpq %r9, %r8
    jle .L215_na
    movq %r9, %r8
.L215_na:
    cmpq %r10, %r8
    jle .L215_nb
    movq %r10, %r8
.L215_nb:
    cmpq $0, %r8
    jge .L215_nok
    xorq %r8, %r8
.L215_nok:
    addq %rax, %rsi
    addq %rdx, %rcx
    xorq %rdx, %rdx
    cmpq $16, %r8
    jge .L215_vec
    cmpq $8, %r8
    jge .L215_w8
    cmpq $4, %r8
    jge .L215_w4
    cmpq $2, %r8
    jge .L215_w2
    jmp .L215_tail
.L215_w8:
    movq (%rsi), %rax
    xorq (%rcx), %rax
    jnz .L215_w8l
    movq %r8, %rdi
    subq $8, %rdi
    movq (%rsi,%rdi), %rax
    xorq (%rcx,%rdi), %rax
    jz .L215_eq
    bsfq %rax, %rax
    shrq $3, %rax
    addq %rdi, %rax
    jmp .L215_done
.L215_w8l:
    bsfq %rax, %rax
    shrq $3, %rax
    jmp .L215_done
.L215_w4:
    movl (%rsi), %eax
    xorl (%rcx), %eax
    jnz .L215_w4l
    movq %r8, %rdi
    subq $4, %rdi
    movl (%rsi,%rdi), %eax
    xorl (%rcx,%rdi), %eax
    jz .L215_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L215_done
.L215_w4l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L215_done
.L215_w2:
    movzwl (%rsi), %eax
    movzwl (%rcx), %r9d
    xorl %r9d, %eax
    jnz .L215_w2l
    movq %r8, %rdi
    subq $2, %rdi
    movzwl (%rsi,%rdi), %eax
    movzwl (%rcx,%rdi), %r9d
    xorl %r9d, %eax
    jz .L215_eq
    bsfl %eax, %eax
    shrl $3, %eax
    addq %rdi, %rax
    jmp .L215_done
.L215_w2l:
    bsfl %eax, %eax
    shrl $3, %eax
    jmp .L215_done
.L215_vec:
    movq %r8, %rax
    subq %rdx, %rax
    cmpq $16, %rax
    jl .L215_tail
    movdqu (%rsi,%rdx), %xmm0
    movdqu (%rcx,%rdx), %xmm1
    pcmpeqb %xmm1, %xmm0
    pmovmskb %xmm0, %eax
    cmpl $65535, %eax
    jne .L215_hit
    addq $16, %rdx
    jmp .L215_vec
.L215_hit:
    notl %eax
    bsfl %eax, %eax
    addq %rdx, %rax
    jmp .L215_done
.L215_tail:
    cmpq %r8, %rdx
    jge .L215_eq
    movzbq (%rsi,%rdx), %rax
    movzbq (%rcx,%rdx), %rdi
    cmpq %rdi, %rax
    jne .L215_th
    addq $1, %rdx
    jmp .L215_tail
.L215_th:
    movq %rdx, %rax
    jmp .L215_done
.L215_eq:
    movq %r8, %rax
.L215_done:
    movq %rax, %r10
    movq %r10, %rax
    .cfi_remember_state
    leave
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
_start:
    xorl %edi, %edi
    movq $1073741824, %rsi
    movl $3, %edx
    movl $0x24022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $-4096, %rax
    ja .Lfern_stack_map_failed
    movq %rax, %rbx
    movq %rax, %rdi
    movq $1048576, %rsi
    xorl %edx, %edx
    movl $10, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_stack_guard_failed
    leaq 1073741808(%rbx), %rsp
    movq %rsp, __fern_stack_top(%rip)
    xorl %edi, %edi
    movq $65536, %rsi
    movl $3, %edx
    movl $0x24022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $-4096, %rax
    ja .Lfern_signal_stack_map_failed
    subq $32, %rsp
    movq %rax, (%rsp)
    movq $0, 8(%rsp)
    movq $65536, 16(%rsp)
    movq %rsp, %rdi
    xorl %esi, %esi
    movl $131, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_signal_stack_failed
    leaq __fern_segv(%rip), %rax
    movq %rax, (%rsp)
    movq $0x0c000004, 8(%rsp)
    call .Lfern_fault_install
    testq %rax, %rax
    jnz .Lfern_fault_handler_failed
    addq $32, %rsp
    pushq %rbp
    movq %rsp, %rbp
    call __fn_main
    pushq %rax
    call __fern_lc_report
    popq %rax
    movq %rax, %rdi
    movq $231, %rax
    syscall
    .section .rodata
.S0: .ascii "HeaderMap"
.S1: .ascii "http://"
.S2: .ascii "https://"
.S3: .ascii "!$&'()*+,;="
.S4: .ascii "Body$BodyText"
.S5: .ascii "HttpResponse"
.S6: .ascii ""
.S7: .ascii "Content-Length: "
.S8: .ascii "\r\n"
.S9: .ascii "HTTP/1.1 "
.S10: .ascii " "
.S11: .ascii "Continue"
.S12: .ascii "Switching Protocols"
.S13: .ascii "OK"
.S14: .ascii "Created"
.S15: .ascii "Accepted"
.S16: .ascii "Non-Authoritative Information"
.S17: .ascii "No Content"
.S18: .ascii "Reset Content"
.S19: .ascii "Partial Content"
.S20: .ascii "Multiple Choices"
.S21: .ascii "Moved Permanently"
.S22: .ascii "Found"
.S23: .ascii "See Other"
.S24: .ascii "Not Modified"
.S25: .ascii "Use Proxy"
.S26: .ascii "Temporary Redirect"
.S27: .ascii "Permanent Redirect"
.S28: .ascii "Bad Request"
.S29: .ascii "Unauthorized"
.S30: .ascii "Payment Required"
.S31: .ascii "Forbidden"
.S32: .ascii "Not Found"
.S33: .ascii "Method Not Allowed"
.S34: .ascii "Not Acceptable"
.S35: .ascii "Proxy Authentication Required"
.S36: .ascii "Request Timeout"
.S37: .ascii "Conflict"
.S38: .ascii "Gone"
.S39: .ascii "Length Required"
.S40: .ascii "Precondition Failed"
.S41: .ascii "Payload Too Large"
.S42: .ascii "URI Too Long"
.S43: .ascii "Unsupported Media Type"
.S44: .ascii "Range Not Satisfiable"
.S45: .ascii "Expectation Failed"
.S46: .ascii "I'm a teapot"
.S47: .ascii "Misdirected Request"
.S48: .ascii "Unprocessable Entity"
.S49: .ascii "Too Early"
.S50: .ascii "Upgrade Required"
.S51: .ascii "Precondition Required"
.S52: .ascii "Too Many Requests"
.S53: .ascii "Request Header Fields Too Large"
.S54: .ascii "Internal Server Error"
.S55: .ascii "Not Implemented"
.S56: .ascii "Bad Gateway"
.S57: .ascii "Service Unavailable"
.S58: .ascii "Gateway Timeout"
.S59: .ascii "HTTP Version Not Supported"
.S60: .ascii "Network Authentication Required"
.S61: .ascii "Status"
.S62: .ascii "content-length"
.S63: .ascii "connection"
.S64: .ascii "transfer-encoding"
.S65: .ascii ": "
.S66: .ascii "Connection: Upgrade\r\n\r\n"
.S67: .ascii "Connection: close\r\n\r\n"
.S68: .ascii "Connection: keep-alive\r\n\r\n"
.S69: .ascii "HEAD"
.S70: .ascii "\027\003\007\003\003\003\003\003\007\007\013\253/\253\013\217\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\001\000\000\000\000\000\001\001\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001"
.S71: .ascii "\003\003\003\003\003\003\003\003\003\002\003\003\003\003\003\203\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
.S72: .ascii "0"
.S73: .ascii "1"
.S74: .ascii "2"
.S75: .ascii "3"
.S76: .ascii "4"
.S77: .ascii "5"
.S78: .ascii "6"
.S79: .ascii "7"
.S80: .ascii "8"
.S81: .ascii "9"
.S82: .ascii "10"
.S83: .ascii "11"
.S84: .ascii "12"
.S85: .ascii "13"
.S86: .ascii "14"
.S87: .ascii "15"
.S88: .ascii "16"
.S89: .ascii "17"
.S90: .ascii "18"
.S91: .ascii "19"
.S92: .ascii "20"
.S93: .ascii "21"
.S94: .ascii "22"
.S95: .ascii "23"
.S96: .ascii "24"
.S97: .ascii "25"
.S98: .ascii "26"
.S99: .ascii "27"
.S100: .ascii "28"
.S101: .ascii "29"
.S102: .ascii "30"
.S103: .ascii "31"
.S104: .ascii "32"
.S105: .ascii "33"
.S106: .ascii "34"
.S107: .ascii "35"
.S108: .ascii "36"
.S109: .ascii "37"
.S110: .ascii "38"
.S111: .ascii "39"
.S112: .ascii "40"
.S113: .ascii "41"
.S114: .ascii "42"
.S115: .ascii "43"
.S116: .ascii "44"
.S117: .ascii "45"
.S118: .ascii "46"
.S119: .ascii "47"
.S120: .ascii "48"
.S121: .ascii "49"
.S122: .ascii "50"
.S123: .ascii "51"
.S124: .ascii "52"
.S125: .ascii "53"
.S126: .ascii "54"
.S127: .ascii "55"
.S128: .ascii "56"
.S129: .ascii "57"
.S130: .ascii "58"
.S131: .ascii "59"
.S132: .ascii "60"
.S133: .ascii "61"
.S134: .ascii "62"
.S135: .ascii "63"
.S136: .ascii "64"
.S137: .ascii "65"
.S138: .ascii "66"
.S139: .ascii "67"
.S140: .ascii "68"
.S141: .ascii "69"
.S142: .ascii "70"
.S143: .ascii "71"
.S144: .ascii "72"
.S145: .ascii "73"
.S146: .ascii "74"
.S147: .ascii "75"
.S148: .ascii "76"
.S149: .ascii "77"
.S150: .ascii "78"
.S151: .ascii "79"
.S152: .ascii "80"
.S153: .ascii "81"
.S154: .ascii "82"
.S155: .ascii "83"
.S156: .ascii "84"
.S157: .ascii "85"
.S158: .ascii "86"
.S159: .ascii "87"
.S160: .ascii "88"
.S161: .ascii "89"
.S162: .ascii "90"
.S163: .ascii "91"
.S164: .ascii "92"
.S165: .ascii "93"
.S166: .ascii "94"
.S167: .ascii "95"
.S168: .ascii "96"
.S169: .ascii "97"
.S170: .ascii "98"
.S171: .ascii "99"
.S172: .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
.S173: .ascii "deflate____ReadPhase$deflate__ReadHeader"
.S174: .ascii "deflate____ReadPhase$deflate__ReadStored"
.S175: .ascii "deflate____ReadPhase$deflate__ReadCodes"
.S176: .ascii "deflate____ReadPhase$deflate__ReadCopy"
.S177: .ascii "deflate____ReadPhase$deflate__ReadEnd"
.S178: .ascii "codec__DecodeErrorKind$codec__InvalidByte"
.S179: .ascii "codec__DecodeErrorKind$codec__InvalidLength"
.S180: .ascii "codec__DecodeErrorKind$codec__InvalidPadding"
.S181: .ascii "codec__DecodeErrorKind$codec__NonZeroTrailingBits"
.S182: .ascii "GET /hello HTTP/1.1\r\nHost: bench\r\nUser-Agent: perf-bench\r\nAccept: */*\r\n\r\n"
.S183: .ascii "\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\r"
.S184: .ascii "OPTIONS"
.S185: .ascii "*"
.S186: .ascii "HTTP/1.0"
.S187: .ascii "HTTP/1.1"
.S188: .ascii "host"
.S189: .ascii "expect"
.S190: .ascii "100-continue"
.S191: .ascii ","
.S192: .ascii "chunked"
.S193: .ascii "close"
.S194: .ascii "keep-alive"
.S195: .ascii "hello "
.S196: .ascii "GET"
.S197: .ascii "Body$BodyBytes"
.S198: .ascii "Body$BodyStream"
.S199: .ascii "Body$BodyFile"
.S200: .ascii "Body$BodyChunks"
.S201: .ascii "Body$BodyFileRanges"
    .section .data.rel.ro
    .balign 8
    .quad -1
.SB0:
    .quad .S0
    .quad 9
    .quad -1
.SB1:
    .quad .S1
    .quad 7
    .quad -1
.SB2:
    .quad .S2
    .quad 8
    .quad -1
.SB3:
    .quad .S3
    .quad 11
    .quad -1
.SB4:
    .quad .S4
    .quad 13
    .quad -1
.SB5:
    .quad .S5
    .quad 12
    .quad -1
.SB6:
    .quad .S6
    .quad 0
    .quad -1
.SB7:
    .quad .S7
    .quad 16
    .quad -1
.SB8:
    .quad .S8
    .quad 2
    .quad -1
.SB9:
    .quad .S9
    .quad 9
    .quad -1
.SB10:
    .quad .S10
    .quad 1
    .quad -1
.SB11:
    .quad .S11
    .quad 8
    .quad -1
.SB12:
    .quad .S12
    .quad 19
    .quad -1
.SB13:
    .quad .S13
    .quad 2
    .quad -1
.SB14:
    .quad .S14
    .quad 7
    .quad -1
.SB15:
    .quad .S15
    .quad 8
    .quad -1
.SB16:
    .quad .S16
    .quad 29
    .quad -1
.SB17:
    .quad .S17
    .quad 10
    .quad -1
.SB18:
    .quad .S18
    .quad 13
    .quad -1
.SB19:
    .quad .S19
    .quad 15
    .quad -1
.SB20:
    .quad .S20
    .quad 16
    .quad -1
.SB21:
    .quad .S21
    .quad 17
    .quad -1
.SB22:
    .quad .S22
    .quad 5
    .quad -1
.SB23:
    .quad .S23
    .quad 9
    .quad -1
.SB24:
    .quad .S24
    .quad 12
    .quad -1
.SB25:
    .quad .S25
    .quad 9
    .quad -1
.SB26:
    .quad .S26
    .quad 18
    .quad -1
.SB27:
    .quad .S27
    .quad 18
    .quad -1
.SB28:
    .quad .S28
    .quad 11
    .quad -1
.SB29:
    .quad .S29
    .quad 12
    .quad -1
.SB30:
    .quad .S30
    .quad 16
    .quad -1
.SB31:
    .quad .S31
    .quad 9
    .quad -1
.SB32:
    .quad .S32
    .quad 9
    .quad -1
.SB33:
    .quad .S33
    .quad 18
    .quad -1
.SB34:
    .quad .S34
    .quad 14
    .quad -1
.SB35:
    .quad .S35
    .quad 29
    .quad -1
.SB36:
    .quad .S36
    .quad 15
    .quad -1
.SB37:
    .quad .S37
    .quad 8
    .quad -1
.SB38:
    .quad .S38
    .quad 4
    .quad -1
.SB39:
    .quad .S39
    .quad 15
    .quad -1
.SB40:
    .quad .S40
    .quad 19
    .quad -1
.SB41:
    .quad .S41
    .quad 17
    .quad -1
.SB42:
    .quad .S42
    .quad 12
    .quad -1
.SB43:
    .quad .S43
    .quad 22
    .quad -1
.SB44:
    .quad .S44
    .quad 21
    .quad -1
.SB45:
    .quad .S45
    .quad 18
    .quad -1
.SB46:
    .quad .S46
    .quad 12
    .quad -1
.SB47:
    .quad .S47
    .quad 19
    .quad -1
.SB48:
    .quad .S48
    .quad 20
    .quad -1
.SB49:
    .quad .S49
    .quad 9
    .quad -1
.SB50:
    .quad .S50
    .quad 16
    .quad -1
.SB51:
    .quad .S51
    .quad 21
    .quad -1
.SB52:
    .quad .S52
    .quad 17
    .quad -1
.SB53:
    .quad .S53
    .quad 31
    .quad -1
.SB54:
    .quad .S54
    .quad 21
    .quad -1
.SB55:
    .quad .S55
    .quad 15
    .quad -1
.SB56:
    .quad .S56
    .quad 11
    .quad -1
.SB57:
    .quad .S57
    .quad 19
    .quad -1
.SB58:
    .quad .S58
    .quad 15
    .quad -1
.SB59:
    .quad .S59
    .quad 26
    .quad -1
.SB60:
    .quad .S60
    .quad 31
    .quad -1
.SB61:
    .quad .S61
    .quad 6
    .quad -1
.SB62:
    .quad .S62
    .quad 14
    .quad -1
.SB63:
    .quad .S63
    .quad 10
    .quad -1
.SB64:
    .quad .S64
    .quad 17
    .quad -1
.SB65:
    .quad .S65
    .quad 2
    .quad -1
.SB66:
    .quad .S66
    .quad 23
    .quad -1
.SB67:
    .quad .S67
    .quad 21
    .quad -1
.SB68:
    .quad .S68
    .quad 26
    .quad -1
.SB69:
    .quad .S69
    .quad 4
    .quad -1
.SB70:
    .quad .S70
    .quad 352
    .quad -1
.SB71:
    .quad .S71
    .quad 352
    .quad -1
.SB72:
    .quad .S72
    .quad 1
    .quad -1
.SB73:
    .quad .S73
    .quad 1
    .quad -1
.SB74:
    .quad .S74
    .quad 1
    .quad -1
.SB75:
    .quad .S75
    .quad 1
    .quad -1
.SB76:
    .quad .S76
    .quad 1
    .quad -1
.SB77:
    .quad .S77
    .quad 1
    .quad -1
.SB78:
    .quad .S78
    .quad 1
    .quad -1
.SB79:
    .quad .S79
    .quad 1
    .quad -1
.SB80:
    .quad .S80
    .quad 1
    .quad -1
.SB81:
    .quad .S81
    .quad 1
    .quad -1
.SB82:
    .quad .S82
    .quad 2
    .quad -1
.SB83:
    .quad .S83
    .quad 2
    .quad -1
.SB84:
    .quad .S84
    .quad 2
    .quad -1
.SB85:
    .quad .S85
    .quad 2
    .quad -1
.SB86:
    .quad .S86
    .quad 2
    .quad -1
.SB87:
    .quad .S87
    .quad 2
    .quad -1
.SB88:
    .quad .S88
    .quad 2
    .quad -1
.SB89:
    .quad .S89
    .quad 2
    .quad -1
.SB90:
    .quad .S90
    .quad 2
    .quad -1
.SB91:
    .quad .S91
    .quad 2
    .quad -1
.SB92:
    .quad .S92
    .quad 2
    .quad -1
.SB93:
    .quad .S93
    .quad 2
    .quad -1
.SB94:
    .quad .S94
    .quad 2
    .quad -1
.SB95:
    .quad .S95
    .quad 2
    .quad -1
.SB96:
    .quad .S96
    .quad 2
    .quad -1
.SB97:
    .quad .S97
    .quad 2
    .quad -1
.SB98:
    .quad .S98
    .quad 2
    .quad -1
.SB99:
    .quad .S99
    .quad 2
    .quad -1
.SB100:
    .quad .S100
    .quad 2
    .quad -1
.SB101:
    .quad .S101
    .quad 2
    .quad -1
.SB102:
    .quad .S102
    .quad 2
    .quad -1
.SB103:
    .quad .S103
    .quad 2
    .quad -1
.SB104:
    .quad .S104
    .quad 2
    .quad -1
.SB105:
    .quad .S105
    .quad 2
    .quad -1
.SB106:
    .quad .S106
    .quad 2
    .quad -1
.SB107:
    .quad .S107
    .quad 2
    .quad -1
.SB108:
    .quad .S108
    .quad 2
    .quad -1
.SB109:
    .quad .S109
    .quad 2
    .quad -1
.SB110:
    .quad .S110
    .quad 2
    .quad -1
.SB111:
    .quad .S111
    .quad 2
    .quad -1
.SB112:
    .quad .S112
    .quad 2
    .quad -1
.SB113:
    .quad .S113
    .quad 2
    .quad -1
.SB114:
    .quad .S114
    .quad 2
    .quad -1
.SB115:
    .quad .S115
    .quad 2
    .quad -1
.SB116:
    .quad .S116
    .quad 2
    .quad -1
.SB117:
    .quad .S117
    .quad 2
    .quad -1
.SB118:
    .quad .S118
    .quad 2
    .quad -1
.SB119:
    .quad .S119
    .quad 2
    .quad -1
.SB120:
    .quad .S120
    .quad 2
    .quad -1
.SB121:
    .quad .S121
    .quad 2
    .quad -1
.SB122:
    .quad .S122
    .quad 2
    .quad -1
.SB123:
    .quad .S123
    .quad 2
    .quad -1
.SB124:
    .quad .S124
    .quad 2
    .quad -1
.SB125:
    .quad .S125
    .quad 2
    .quad -1
.SB126:
    .quad .S126
    .quad 2
    .quad -1
.SB127:
    .quad .S127
    .quad 2
    .quad -1
.SB128:
    .quad .S128
    .quad 2
    .quad -1
.SB129:
    .quad .S129
    .quad 2
    .quad -1
.SB130:
    .quad .S130
    .quad 2
    .quad -1
.SB131:
    .quad .S131
    .quad 2
    .quad -1
.SB132:
    .quad .S132
    .quad 2
    .quad -1
.SB133:
    .quad .S133
    .quad 2
    .quad -1
.SB134:
    .quad .S134
    .quad 2
    .quad -1
.SB135:
    .quad .S135
    .quad 2
    .quad -1
.SB136:
    .quad .S136
    .quad 2
    .quad -1
.SB137:
    .quad .S137
    .quad 2
    .quad -1
.SB138:
    .quad .S138
    .quad 2
    .quad -1
.SB139:
    .quad .S139
    .quad 2
    .quad -1
.SB140:
    .quad .S140
    .quad 2
    .quad -1
.SB141:
    .quad .S141
    .quad 2
    .quad -1
.SB142:
    .quad .S142
    .quad 2
    .quad -1
.SB143:
    .quad .S143
    .quad 2
    .quad -1
.SB144:
    .quad .S144
    .quad 2
    .quad -1
.SB145:
    .quad .S145
    .quad 2
    .quad -1
.SB146:
    .quad .S146
    .quad 2
    .quad -1
.SB147:
    .quad .S147
    .quad 2
    .quad -1
.SB148:
    .quad .S148
    .quad 2
    .quad -1
.SB149:
    .quad .S149
    .quad 2
    .quad -1
.SB150:
    .quad .S150
    .quad 2
    .quad -1
.SB151:
    .quad .S151
    .quad 2
    .quad -1
.SB152:
    .quad .S152
    .quad 2
    .quad -1
.SB153:
    .quad .S153
    .quad 2
    .quad -1
.SB154:
    .quad .S154
    .quad 2
    .quad -1
.SB155:
    .quad .S155
    .quad 2
    .quad -1
.SB156:
    .quad .S156
    .quad 2
    .quad -1
.SB157:
    .quad .S157
    .quad 2
    .quad -1
.SB158:
    .quad .S158
    .quad 2
    .quad -1
.SB159:
    .quad .S159
    .quad 2
    .quad -1
.SB160:
    .quad .S160
    .quad 2
    .quad -1
.SB161:
    .quad .S161
    .quad 2
    .quad -1
.SB162:
    .quad .S162
    .quad 2
    .quad -1
.SB163:
    .quad .S163
    .quad 2
    .quad -1
.SB164:
    .quad .S164
    .quad 2
    .quad -1
.SB165:
    .quad .S165
    .quad 2
    .quad -1
.SB166:
    .quad .S166
    .quad 2
    .quad -1
.SB167:
    .quad .S167
    .quad 2
    .quad -1
.SB168:
    .quad .S168
    .quad 2
    .quad -1
.SB169:
    .quad .S169
    .quad 2
    .quad -1
.SB170:
    .quad .S170
    .quad 2
    .quad -1
.SB171:
    .quad .S171
    .quad 2
    .quad -1
.SB172:
    .quad .S172
    .quad 200
    .quad -1
.SB173:
    .quad .S173
    .quad 40
    .quad -1
.SB174:
    .quad .S174
    .quad 40
    .quad -1
.SB175:
    .quad .S175
    .quad 39
    .quad -1
.SB176:
    .quad .S176
    .quad 38
    .quad -1
.SB177:
    .quad .S177
    .quad 37
    .quad -1
.SB178:
    .quad .S178
    .quad 41
    .quad -1
.SB179:
    .quad .S179
    .quad 43
    .quad -1
.SB180:
    .quad .S180
    .quad 44
    .quad -1
.SB181:
    .quad .S181
    .quad 49
    .quad -1
.SB182:
    .quad .S182
    .quad 73
    .quad -1
.SB183:
    .quad .S183
    .quad 354
    .quad -1
.SB184:
    .quad .S184
    .quad 7
    .quad -1
.SB185:
    .quad .S185
    .quad 1
    .quad -1
.SB186:
    .quad .S186
    .quad 8
    .quad -1
.SB187:
    .quad .S187
    .quad 8
    .quad -1
.SB188:
    .quad .S188
    .quad 4
    .quad -1
.SB189:
    .quad .S189
    .quad 6
    .quad -1
.SB190:
    .quad .S190
    .quad 12
    .quad -1
.SB191:
    .quad .S191
    .quad 1
    .quad -1
.SB192:
    .quad .S192
    .quad 7
    .quad -1
.SB193:
    .quad .S193
    .quad 5
    .quad -1
.SB194:
    .quad .S194
    .quad 10
    .quad -1
.SB195:
    .quad .S195
    .quad 6
    .quad -1
.SB196:
    .quad .S196
    .quad 3
    .quad -1
.SB197:
    .quad .S197
    .quad 14
    .quad -1
.SB198:
    .quad .S198
    .quad 15
    .quad -1
.SB199:
    .quad .S199
    .quad 13
    .quad -1
.SB200:
    .quad .S200
    .quad 15
    .quad -1
.SB201:
    .quad .S201
    .quad 19
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.K0:
    .quad 0
    .quad 3
    .quad -1
.K1:
    .quad .S0
.K1_0:
    .quad .K0
.K1_1:
    .quad .K0
    .quad 0
    .quad -1
.K2:
    .quad 0
    .balign 8
    .quad 2
    .quad -1
.K3:
    .quad .S4
.K3_0:
    .quad .SB6
    .quad 2
    .quad -1
.K4:
    .quad 1
    .quad 0
    .quad 6
    .quad -1
.K5:
    .quad .S5
    .quad 500
.K5_1:
    .quad .K3
.K5_2:
    .quad .K1
.K5_3:
    .quad .K1
.K5_4:
    .quad .K4
    .quad 50
    .quad -1
.K6:
    .quad 50
    .quad 100
    .quad 101
    .quad 200
    .quad 201
    .quad 202
    .quad 203
    .quad 204
    .quad 205
    .quad 206
    .quad 300
    .quad 301
    .quad 302
    .quad 303
    .quad 304
    .quad 305
    .quad 307
    .quad 308
    .quad 400
    .quad 401
    .quad 402
    .quad 403
    .quad 404
    .quad 405
    .quad 406
    .quad 407
    .quad 408
    .quad 409
    .quad 410
    .quad 411
    .quad 412
    .quad 413
    .quad 414
    .quad 415
    .quad 416
    .quad 417
    .quad 418
    .quad 421
    .quad 422
    .quad 425
    .quad 426
    .quad 428
    .quad 429
    .quad 431
    .quad 500
    .quad 501
    .quad 502
    .quad 503
    .quad 504
    .quad 505
    .quad 511
    .quad 50
    .quad -1
.K7:
    .quad 50
.K7_0:
    .quad .SB11
.K7_1:
    .quad .SB12
.K7_2:
    .quad .SB13
.K7_3:
    .quad .SB14
.K7_4:
    .quad .SB15
.K7_5:
    .quad .SB16
.K7_6:
    .quad .SB17
.K7_7:
    .quad .SB18
.K7_8:
    .quad .SB19
.K7_9:
    .quad .SB20
.K7_10:
    .quad .SB21
.K7_11:
    .quad .SB22
.K7_12:
    .quad .SB23
.K7_13:
    .quad .SB24
.K7_14:
    .quad .SB25
.K7_15:
    .quad .SB26
.K7_16:
    .quad .SB27
.K7_17:
    .quad .SB28
.K7_18:
    .quad .SB29
.K7_19:
    .quad .SB30
.K7_20:
    .quad .SB31
.K7_21:
    .quad .SB32
.K7_22:
    .quad .SB33
.K7_23:
    .quad .SB34
.K7_24:
    .quad .SB35
.K7_25:
    .quad .SB36
.K7_26:
    .quad .SB37
.K7_27:
    .quad .SB38
.K7_28:
    .quad .SB39
.K7_29:
    .quad .SB40
.K7_30:
    .quad .SB41
.K7_31:
    .quad .SB42
.K7_32:
    .quad .SB43
.K7_33:
    .quad .SB44
.K7_34:
    .quad .SB45
.K7_35:
    .quad .SB46
.K7_36:
    .quad .SB47
.K7_37:
    .quad .SB48
.K7_38:
    .quad .SB49
.K7_39:
    .quad .SB50
.K7_40:
    .quad .SB51
.K7_41:
    .quad .SB52
.K7_42:
    .quad .SB53
.K7_43:
    .quad .SB54
.K7_44:
    .quad .SB55
.K7_45:
    .quad .SB56
.K7_46:
    .quad .SB57
.K7_47:
    .quad .SB58
.K7_48:
    .quad .SB59
.K7_49:
    .quad .SB60
    .quad 0
    .quad -1
.K8:
    .quad 256
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    .balign 8
    .quad 0
    .quad -1
.K9:
    .quad 128
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
    .balign 8
    .quad 100
    .quad -1
.K10:
    .quad 100
.K10_0:
    .quad .SB72
.K10_1:
    .quad .SB73
.K10_2:
    .quad .SB74
.K10_3:
    .quad .SB75
.K10_4:
    .quad .SB76
.K10_5:
    .quad .SB77
.K10_6:
    .quad .SB78
.K10_7:
    .quad .SB79
.K10_8:
    .quad .SB80
.K10_9:
    .quad .SB81
.K10_10:
    .quad .SB82
.K10_11:
    .quad .SB83
.K10_12:
    .quad .SB84
.K10_13:
    .quad .SB85
.K10_14:
    .quad .SB86
.K10_15:
    .quad .SB87
.K10_16:
    .quad .SB88
.K10_17:
    .quad .SB89
.K10_18:
    .quad .SB90
.K10_19:
    .quad .SB91
.K10_20:
    .quad .SB92
.K10_21:
    .quad .SB93
.K10_22:
    .quad .SB94
.K10_23:
    .quad .SB95
.K10_24:
    .quad .SB96
.K10_25:
    .quad .SB97
.K10_26:
    .quad .SB98
.K10_27:
    .quad .SB99
.K10_28:
    .quad .SB100
.K10_29:
    .quad .SB101
.K10_30:
    .quad .SB102
.K10_31:
    .quad .SB103
.K10_32:
    .quad .SB104
.K10_33:
    .quad .SB105
.K10_34:
    .quad .SB106
.K10_35:
    .quad .SB107
.K10_36:
    .quad .SB108
.K10_37:
    .quad .SB109
.K10_38:
    .quad .SB110
.K10_39:
    .quad .SB111
.K10_40:
    .quad .SB112
.K10_41:
    .quad .SB113
.K10_42:
    .quad .SB114
.K10_43:
    .quad .SB115
.K10_44:
    .quad .SB116
.K10_45:
    .quad .SB117
.K10_46:
    .quad .SB118
.K10_47:
    .quad .SB119
.K10_48:
    .quad .SB120
.K10_49:
    .quad .SB121
.K10_50:
    .quad .SB122
.K10_51:
    .quad .SB123
.K10_52:
    .quad .SB124
.K10_53:
    .quad .SB125
.K10_54:
    .quad .SB126
.K10_55:
    .quad .SB127
.K10_56:
    .quad .SB128
.K10_57:
    .quad .SB129
.K10_58:
    .quad .SB130
.K10_59:
    .quad .SB131
.K10_60:
    .quad .SB132
.K10_61:
    .quad .SB133
.K10_62:
    .quad .SB134
.K10_63:
    .quad .SB135
.K10_64:
    .quad .SB136
.K10_65:
    .quad .SB137
.K10_66:
    .quad .SB138
.K10_67:
    .quad .SB139
.K10_68:
    .quad .SB140
.K10_69:
    .quad .SB141
.K10_70:
    .quad .SB142
.K10_71:
    .quad .SB143
.K10_72:
    .quad .SB144
.K10_73:
    .quad .SB145
.K10_74:
    .quad .SB146
.K10_75:
    .quad .SB147
.K10_76:
    .quad .SB148
.K10_77:
    .quad .SB149
.K10_78:
    .quad .SB150
.K10_79:
    .quad .SB151
.K10_80:
    .quad .SB152
.K10_81:
    .quad .SB153
.K10_82:
    .quad .SB154
.K10_83:
    .quad .SB155
.K10_84:
    .quad .SB156
.K10_85:
    .quad .SB157
.K10_86:
    .quad .SB158
.K10_87:
    .quad .SB159
.K10_88:
    .quad .SB160
.K10_89:
    .quad .SB161
.K10_90:
    .quad .SB162
.K10_91:
    .quad .SB163
.K10_92:
    .quad .SB164
.K10_93:
    .quad .SB165
.K10_94:
    .quad .SB166
.K10_95:
    .quad .SB167
.K10_96:
    .quad .SB168
.K10_97:
    .quad .SB169
.K10_98:
    .quad .SB170
.K10_99:
    .quad .SB171
    .quad 0
    .quad -1
.K11:
    .quad 14
    .byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K12:
    .quad 5
    .byte 72, 84, 84, 80, 47
    .balign 8
    .section .bss
    .align 8
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 8
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 8
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 8
__fern_rc_underflow: .quad 0
    .align 8
__fern_map_seed: .quad 0
    .align 8
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 8
__fern_quar_head: .quad 0
    .align 8
__fern_quar_tail: .quad 0
    .align 8
__fern_quar_bytes: .quad 0
    .align 8
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 8
__fern_freelist_shadow: .skip 524288
    .align 8
__fern_large_freelist_shadow: .skip 20480
    .section .text
__fern_alloc:
    pushq %rdi
    call __fern_alloc_inner
    popq %rdi
    pushq %rsi
    movq 8(%rsp), %rsi
    addq $7, %rdi
    shrq $3, %rdi
    pushq %rdi
    pushq %rax
    pushq %rsi
    call __fern_hev_a
    addq $24, %rsp
    popq %rsi
    ret
__fern_alloc_inner:
    addq $7, %rdi
    andq $-8, %rdi
    cmpq $2048, %rdi
    ja .Lalloc_full
    leaq __fern_freelist(%rip), %rax
    addq %rax, %rdi
    movq (%rdi), %rax
    testq %rax, %rax
    jz .Lalloc_fast_miss
    pushq (%rax)
    popq (%rdi)
    ret
.Lalloc_fast_miss:
    leaq __fern_freelist(%rip), %rax
    subq %rax, %rdi
    movq __fern_heap_ptr(%rip), %rax
    testq %rax, %rax
    jz .Lalloc_full
    addq %rax, %rdi
    cmpq __fern_heap_end(%rip), %rdi
    ja .Lalloc_oom
    movq %rdi, __fern_heap_ptr(%rip)
    ret
.Lalloc_full:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rcx
    pushq %rdx
    movq %rdi, %rcx
    shrq $3, %rcx
    cmpq $65536, %rcx
    jae .Lalloc_large
    cmpq $256, %rcx
    jbe .L216
    pushq %rcx
    call __fern_capw
    popq %rcx
.L216:
    leaq 0(,%rcx,8), %rdi
    leaq __fern_freelist(%rip), %rdx
    movq (%rdx,%rcx,8), %rax
    testq %rax, %rax
    jz .Lalloc_nofl
    movq (%rax), %rdi
    movq %rdi, (%rdx,%rcx,8)
    popq %rdx
    popq %rcx
    popq %rbp
    ret
.Lalloc_large:
    movabs $17179869184, %rax
    cmpq %rax, %rdi
    ja .Lalloc_nofl
    movq %rdi, %rax
    cmpq $524288, %rax
    jae .L217
    movl $524288, %eax
.L217:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    movq %rax, %rdi
    movq %rdx, %rax
    leaq __fern_large_freelist(%rip), %rdx
    movq (%rdx,%rax,8), %rcx
    testq %rcx, %rcx
    jz .Lalloc_nofl
    movq (%rcx), %rdi
    movq %rdi, (%rdx,%rax,8)
    movq %rcx, %rax
    popq %rdx
    popq %rcx
    popq %rbp
    ret
.Lalloc_nofl:
    popq %rdx
    popq %rcx
    movq __fern_heap_ptr(%rip), %rax
    testq %rax, %rax
    jne .Lalloc_inited
    pushq %rdi
    pushq %rsi
    pushq %rcx
    pushq %rdx
    pushq %r8
    pushq %r9
    pushq %r10
    pushq %r11
    movl $0x10000000, %edi
    movabs $17179869184, %rsi
    movl $3, %edx
    movl $0x4022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $0, %rax
    jl .Lalloc_map_fail
    movq %rax, __fern_heap_ptr(%rip)
    movq %rax, __fern_heap_base(%rip)
    movabs $17179869184, %rcx
    addq %rax, %rcx
    movq %rcx, __fern_heap_end(%rip)
    popq %r11
    popq %r10
    popq %r9
    popq %r8
    popq %rdx
    popq %rcx
    popq %rsi
    popq %rdi
.Lalloc_inited:
    movq __fern_heap_ptr(%rip), %rax
    addq %rax, %rdi
    jc __fern_alloc_size_abort
    cmpq __fern_heap_end(%rip), %rdi
    ja .Lalloc_oom
    movq %rdi, __fern_heap_ptr(%rip)
    popq %rbp
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .section .text
.Lalloc_oom:
    leaq .Lmsg_oom(%rip), %rsi
    movq $43, %rdx
    movq $125, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .section .text
.Lalloc_map_fail:
    negq %rax
    subq $96, %rsp
    leaq 96(%rsp), %rdi
    movl $10, %edx
    decq %rdi
    movb %dl, (%rdi)
    movl $41, %edx
    decq %rdi
    movb %dl, (%rdi)
    movl $10, %ecx
.Lmap_fail_digit:
    xorl %edx, %edx
    divq %rcx
    addl $48, %edx
    decq %rdi
    movb %dl, (%rdi)
    testq %rax, %rax
    jne .Lmap_fail_digit
    leaq .Lmsg_map_fail(%rip), %rsi
    addq $42, %rsi
    movl $42, %ecx
.Lmap_fail_copy:
    decq %rsi
    movb (%rsi), %dl
    decq %rdi
    movb %dl, (%rdi)
    decq %rcx
    jne .Lmap_fail_copy
    movq %rdi, %rsi
    leaq 96(%rsp), %rdx
    subq %rsi, %rdx
    movq $123, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .section .text
__fern_oob_abort:
    leaq .Lmsg_arr_oob(%rip), %rsi
    movq $31, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .section .text
__fern_str_oob_abort:
    leaq .Lmsg_str_oob(%rip), %rsi
    movq $32, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .section .text
__fern_slice_abort:
    leaq .Lmsg_slice(%rip), %rsi
    movq $32, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .section .text
__fern_alloc_size_abort:
    leaq .Lmsg_alloc_size(%rip), %rsi
    movq $35, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .section .text
.Lrawfree_bad:
    pushq (%rsp)
    pushq %rbp
    movq %rsp, %rbp
__fern_free_range_abort:
    leaq .Lmsg_free_range(%rip), %rsi
    movq $41, %rdx
    jmp __fern_abort_134
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .section .text
.Lrawfree_double:
    pushq (%rsp)
    pushq %rbp
    movq %rsp, %rbp
__fern_double_free_abort:
    leaq .Lmsg_double_free(%rip), %rsi
    movq $45, %rdx
    jmp __fern_abort_134
__fern_arr_box:
    cmpq $268435455, %rdi
    ja __fern_alloc_size_abort.c
    movq __fern_hev_site(%rip), %rax
    testq %rax, %rax
    jne .Larrbox_hs
    movq (%rsp), %rax
    movq %rax, __fern_hev_site(%rip)
.Larrbox_hs:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rdi
    addq $3, %rdi
    shlq $3, %rdi
    call __fern_alloc
    popq %rdi
    movq %rdi, (%rax)
    movq $1, 8(%rax)
    movq %rdi, 16(%rax)
    addq $16, %rax
    leave
    ret
__fern_str_box:
    movq __fern_hev_site(%rip), %rax
    testq %rax, %rax
    jne .Lstrbox_hs
    movq (%rsp), %rax
    movq %rax, __fern_hev_site(%rip)
.Lstrbox_hs:
    pushq %rsi
    pushq %rdi
    movq $24, %rdi
    call __fern_alloc
    movq $1, (%rax)
    popq %rdi
    popq %rsi
    movq %rdi, 8(%rax)
    movq %rsi, 16(%rax)
    addq $8, %rax
    ret
__fern_str_box_hdr:
    leaq -24(%rdi), %rax
    movl $1, (%rax)
    movl $1934589965, 4(%rax)
    movq %rdi, 8(%rax)
    movq %rsi, 16(%rax)
    addq $8, %rax
    ret
__fn___fern_rc_inc:
    movq 8(%rsp), %rax
    testb $1, %al
    jnz .Lshrcinc_ret
    cmpq $0x10000, %rax
    jb .Lshrcinc_ret
    andq $-3, %rax
    movl -8(%rax), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lshrcinc_ret
    addl $1, %ecx
    movl %ecx, -8(%rax)
.Lshrcinc_ret:
    movq 8(%rsp), %rax
    ret
__fn___fern_rc_underflow_count:
    movl __fern_rc_underflow(%rip), %eax
    ret
__fern_large_push:
    movabs $17179869184, %rax
    cmpq %rax, %rsi
    ja .Llpush_ret
    movq %rsi, %rax
    shrq $3, %rax
    pushq %rax
    pushq %r8
    call __fern_hev_f
    addq $16, %rsp
    ret
__fern_large_push_now:
    movq %rsi, %rax
    cmpq $524288, %rax
    jae .L218
    movl $524288, %eax
.L218:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    movq %rdx, %rax
    leaq __fern_large_freelist(%rip), %rdx
    movq (%rdx,%rax,8), %rcx
    cmpq %r8, %rcx
    je .Lrawfree_double
    movq %rcx, (%r8)
    movq %r8, (%rdx,%rax,8)
.Llpush_ret:
    ret
__fern_capw:
    pushq %rax
    pushq %rcx
    pushq %rdx
    movq 32(%rsp), %rax
    cmpq $256, %rax
    jbe .Lcapw_ret
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    cmpq $65536, %rax
    jb .Lcapw_store
    movl $65535, %eax
.Lcapw_store:
    movq %rax, 32(%rsp)
.Lcapw_ret:
    popq %rdx
    popq %rcx
    popq %rax
    ret
__fern_quar_push:
    cmpq $3, %rsi
    jb .Lquar_ret
    pushq %rax
    pushq %rcx
    pushq %r8
    cmpq $8, %rdx
    je .Lquar_meta0
    movl $2129525454, (%rdi)
    movq %rsi, 8(%rdi)
    jmp .Lquar_link
.Lquar_meta0:
    movq %rsi, (%rdi)
.Lquar_link:
    movq $0, 16(%rdi)
    movq __fern_quar_tail(%rip), %rax
    testq %rax, %rax
    jz .Lquar_first
    movq %rdi, 16(%rax)
    jmp .Lquar_tail
.Lquar_first:
    movq %rdi, __fern_quar_head(%rip)
.Lquar_tail:
    movq %rdi, __fern_quar_tail(%rip)
    leaq 0(,%rsi,8), %rax
    addq %rax, __fern_quar_bytes(%rip)
    leaq 24(%rdi), %r8
    leaq -3(%rsi), %rcx
    movabs $9146242183059077838, %rax
    testq %rcx, %rcx
    jz .Lquar_fill_done
.Lquar_fill:
    movq %rax, (%r8)
    addq $8, %r8
    subq $1, %rcx
    jnz .Lquar_fill
.Lquar_fill_done:
.Lquar_evict:
    movabs $67108864, %rax
    cmpq %rax, __fern_quar_bytes(%rip)
    jbe .Lquar_done
    movq __fern_quar_head(%rip), %rdi
    movq 16(%rdi), %rax
    movq %rax, __fern_quar_head(%rip)
    testq %rax, %rax
    jnz .Lquar_unlinked
    movq $0, __fern_quar_tail(%rip)
.Lquar_unlinked:
    cmpl $2129525454, (%rdi)
    jne .Lquar_size0
    movq 8(%rdi), %rsi
    movl $0, (%rdi)
    jmp .Lquar_recycle
.Lquar_size0:
    cmpl $2129525454, 8(%rdi)
    jne __fern_san_abort_waf
    movq (%rdi), %rsi
    movl $0, 8(%rdi)
.Lquar_recycle:
    leaq 24(%rdi), %r8
    leaq -3(%rsi), %rcx
    movabs $9146242183059077838, %rax
    testq %rcx, %rcx
    jz .Lquar_scan_done
.Lquar_scan:
    cmpq %rax, (%r8)
    jne __fern_san_abort_waf
    addq $8, %r8
    subq $1, %rcx
    jnz .Lquar_scan
.Lquar_scan_done:
    leaq 0(,%rsi,8), %rax
    subq %rax, __fern_quar_bytes(%rip)
    cmpq $65536, %rsi
    jae .Lquar_large
    movq %rsi, %rcx
    cmpq $256, %rcx
    jbe .L219
    pushq %rcx
    call __fern_capw
    popq %rcx
.L219:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rax
    movq %rax, (%rdi)
    movq %rdi, (%r8,%rcx,8)
    jmp .Lquar_evict
.Lquar_large:
    movq %rdi, %r8
    leaq 0(,%rsi,8), %rsi
    call __fern_large_push_now
    jmp .Lquar_evict
.Lquar_done:
    popq %r8
    popq %rcx
    popq %rax
.Lquar_ret:
    ret
__fern_raw_alloc_san:
    pushq %rdi
    pushq %rdi
    addq $16, %rdi
    call __fern_alloc
    popq %rdi
    popq %rdi
    subq $16, __fern_lc_alloc_bytes(%rip)
    addq $7, %rdi
    andq $-8, %rdi
    movabs $9146242183059077838, %rdx
    movq %rdx, (%rax,%rdi)
    movq %rdx, 8(%rax,%rdi)
    ret
__fern_raw_free:
    testq %rdi, %rdi
    jz .Lrawfree_ret
    cmpq __fern_heap_base(%rip), %rdi
    jb .Lrawfree_bad
    cmpq __fern_heap_end(%rip), %rdi
    jae .Lrawfree_bad
    addq $7, %rsi
    andq $-8, %rsi
    movabs $9146242183059077838, %r8
    cmpq %r8, (%rdi,%rsi)
    jne __fern_san_abort_hbo
    cmpq %r8, 8(%rdi,%rsi)
    jne __fern_san_abort_hbo
    cmpq $8, %rsi
    jb .Lrawfree_ret
    cmpl $2129525454, (%rdi)
    jne .Lrawfree_fresh
    movq __fern_quar_head(%rip), %rcx
.Lrawfree_qscan:
    testq %rcx, %rcx
    jz .Lrawfree_fresh
    cmpq %rdi, %rcx
    je .Lrawfree_double
    movq 16(%rcx), %rcx
    jmp .Lrawfree_qscan
.Lrawfree_fresh:
    movl $2129525454, (%rdi)
    movq %rsi, %rcx
    shrq $3, %rcx
    pushq %rcx
    pushq %rdi
    call __fern_hev_f
    addq $16, %rsp
    addq $2, %rcx
    movq %rcx, %rsi
    movq $0, %rdx
    call __fern_quar_push
.Lrawfree_ret:
    ret
__fn___fern_arr_dec:
    movq 8(%rsp), %rax
__fn___fern_arr_dec.r:
    cmpq $0x10000, %rax
    jb .Larrdec_ret
__fn___fern_arr_dec.u:
    movl -8(%rax), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    cmpl $1, %ecx
    jne .Larrdec_shared
    movl $2129525454, -8(%rax)
    movl -16(%rax), %ecx
    addq $3, %rcx
    leaq -16(%rax), %rdx
    cmpq $256, %rcx
    ja .Larrdec_big
    pushq %rcx
    pushq %rdx
    call __fern_hev_f
    addq $16, %rsp
    movq %rcx, %rsi
    movq %rdx, %rdi
    movq $8, %rdx
    call __fern_quar_push
.Larrdec_ret:
    ret
.Larrdec_shared:
    testl %ecx, %ecx
    js .Larrdec_ret
    jg .Larrdec_dec
    incl __fern_rc_underflow(%rip)
    call __fern_san_abort
    jmp .Larrdec_ret
.Larrdec_dec:
    subl $1, %ecx
    movl %ecx, -8(%rax)
    ret
.Larrdec_big:
    cmpq $65536, %rcx
    jae .Larrdec_large
    pushq %rcx
    pushq %rdx
    call __fern_hev_f
    addq $16, %rsp
    movq %rcx, %rsi
    movq %rdx, %rdi
    movq $8, %rdx
    call __fern_quar_push
    ret
.Larrdec_large:
    leaq -16(%rax), %rdi
    pushq %rcx
    pushq %rdi
    call __fern_hev_f
    addq $16, %rsp
    movq %rcx, %rsi
    movq $8, %rdx
    call __fern_quar_push
    ret
__fn___fern_str_free:
    movq 8(%rsp), %rax
__fn___fern_str_free.r:
    testb $1, %al
    jnz .Lstrfree_ret
    cmpq $0x10000, %rax
    jb .Lstrfree_ret
__fn___fern_str_free.u:
    movl -8(%rax), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    cmpl $1, %ecx
    jne .Lstrfree_shared
    movl -4(%rax), %edx
    cmpl $1934589965, %edx
    je .Lstrfree_fused
    cmpl $1196576599, %edx
    je .Lstrfree_grown
    cmpl $1112494674, %edx
    je .Lstrfree_box
    movq (%rax), %rcx
    movq 8(%rax), %rdx
    movq __fern_heap_base(%rip), %rsi
    cmpq %rsi, %rcx
    jb .Lstrfree_box
    cmpq __fern_heap_end(%rip), %rcx
    jae .Lstrfree_box
    testq %rdx, %rdx
    jle .Lstrfree_box
    addq $7, %rdx
    shrq $3, %rdx
    cmpq $65536, %rdx
    jae .Lstrfree_large
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
.Lstrfree_box:
    movl $2129525454, -8(%rax)
    leaq -8(%rax), %rdx
    pushq $3
    pushq %rdx
    call __fern_hev_f
    addq $16, %rsp
    movq $3, %rsi
    movq %rdx, %rdi
    movq $0, %rdx
    call __fern_quar_push
    jmp .Lstrfree_ret
.Lstrfree_large:
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
    jmp .Lstrfree_box
.Lstrfree_grown:
    movq -16(%rax), %rdx
    leaq -16(%rax), %rcx
    jmp .Lstrfree_block
.Lstrfree_fused:
    movq 8(%rax), %rdx
    addq $7, %rdx
    shrq $3, %rdx
    addq $3, %rdx
    leaq -8(%rax), %rcx
.Lstrfree_block:
    movl $2129525454, -8(%rax)
    cmpq $256, %rdx
    ja .Lstrfree_fused_big
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    jmp .Lstrfree_quar
    jmp .Lstrfree_ret
.Lstrfree_fused_big:
    cmpq $65536, %rdx
    jae .Lstrfree_fused_large
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    jmp .Lstrfree_quar
.Lstrfree_fused_large:
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
.Lstrfree_quar:
    movq %rdx, %rsi
    movq %rcx, %rdi
    leaq -8(%rax), %rdx
    subq %rcx, %rdx
    call __fern_quar_push
    jmp .Lstrfree_ret
.Lstrfree_shared:
    testl %ecx, %ecx
    js .Lstrfree_ret
    je .Lstrfree_uf
    subl $1, %ecx
    movl %ecx, -8(%rax)
    ret
.Lstrfree_uf:
    incl __fern_rc_underflow(%rip)
    call __fern_san_abort
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    movq 8(%rsp), %rax
    testb $1, %al
    jnz .Lstrvfree_ret
    cmpq $0x10000, %rax
    jb .Lstrvfree_ret
    movl -8(%rax), %ecx
    testl %ecx, %ecx
    js .Lstrvfree_view
    jmp __fn___fern_str_free
.Lstrvfree_view:
    leaq -8(%rax), %rdx
    movq __fern_heap_base(%rip), %rsi
    cmpq %rsi, %rdx
    jb .Lstrvfree_ret
    cmpq __fern_heap_end(%rip), %rdx
    jae .Lstrvfree_ret
    movl $2129525454, -8(%rax)
    pushq $3
    pushq %rdx
    call __fern_hev_f
    addq $16, %rsp
    movq $3, %rsi
    movq %rdx, %rdi
    movq $0, %rdx
    call __fern_quar_push
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_str_arr_free.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___fern_str_arr_free_0:
    cmpq $65536, %rbx
    jb .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    leaq -8(%rbx), %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    movslq (%rbx), %r12
.Lssa___fern_str_arr_free_4:
    xorl %esi, %esi
.Lssa___fern_str_arr_free_15:
    cmpq %r12, %rsi
    jge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    leaq 1(%rsi), %r13
    movq (%rbx,%r13,8), %rsi
    movq %rsi, %rax
    call __fn___fern_str_free.r
    movq %r13, %rsi
    cmpq %r12, %rsi
    jl .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    movq %rbx, %rax
    call __fn___fern_arr_dec.r
    xorl %eax, %eax
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___fern_rc_is_unique:
    movq 8(%rsp), %rcx
    movq $0, %rax
    testb $1, %cl
    jnz .Lshuniq_ret
    cmpq $0x10000, %rcx
    jb .Lshuniq_ret
    andq $-3, %rcx
    movl -8(%rcx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    testl %edx, %edx
    js .Lshuniq_ret
    cmpl $1, %edx
    jne .Lshuniq_ret
    movq $1, %rax
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    movq 8(%rsp), %rax
__fn___fern_arr_inc_elems.r:
    cmpq $0x10000, %rax
    jb .Laie_ret
    movl -8(%rax), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Laie_ret
    movq (%rax), %rsi
    xorl %edx, %edx
.Laie_loop:
    cmpq %rsi, %rdx
    jge .Laie_ret
    movq 8(%rax,%rdx,8), %rcx
    incq %rdx
    testb $1, %cl
    jnz .Laie_loop
    cmpq $0x10000, %rcx
    jb .Laie_loop
    andq $-3, %rcx
    movl -8(%rcx), %edi
    cmpl $2129525454, %edi
    je __fern_san_abort_uaf
    testl %edi, %edi
    js .Laie_loop
    addl $1, -8(%rcx)
    jmp .Laie_loop
.Laie_ret:
    ret
__fn___fern_str_grow:
    movq 16(%rsp), %r8
    movq 8(%rsp), %rdx
    movq 8(%rdx), %rsi
    movq (%rdx), %rdx
    jmp .Lsg_body
__fn___fern_str_grow_range:
    movq 32(%rsp), %r8
    movslq 16(%rsp), %rax
    movslq 8(%rsp), %rsi
    movq 24(%rsp), %rdx
    testq %rax, %rax
    js .Lsg_out
    cmpq 8(%rdx), %rsi
    jg .Lsg_out
    subq %rax, %rsi
    js .Lsg_out
    movq (%rdx), %rdx
    addq %rax, %rdx
    jmp .Lsg_body
.Lsg_out:
    xorl %eax, %eax
    ret
.Lsg_body:
    xorl %eax, %eax
    testb $1, %r8b
    jnz .Lsg_ret
    cmpq $0x10000, %r8
    jb .Lsg_ret
    movl -8(%r8), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    cmpl $1, %ecx
    jne .Lsg_ret
    movq 8(%r8), %rcx
    leaq (%rcx,%rsi), %rdi
    cmpq $0x7fffffff, %rdi
    ja .Lsg_ret
    cmpl $1196576599, -4(%r8)
    jne .Lsg_fused
    leaq 39(%rdi), %r10
    shrq $3, %r10
    cmpq -16(%r8), %r10
    ja .Lsg_ret
    jmp .Lsg_copy
.Lsg_fused:
    cmpl $1934589965, -4(%r8)
    jne .Lsg_ret
    leaq 31(%rcx), %r9
    shrq $3, %r9
    leaq 31(%rdi), %r10
    shrq $3, %r10
    cmpq %r9, %r10
    je .Lsg_copy
    cmpq $65536, %r9
    jae .Lsg_large
    pushq %r9
    call __fern_capw
    popq %r11
    cmpq %r11, %r10
    ja .Lsg_ret
    jmp .Lsg_fits
.Lsg_large:
    cmpq $0x8000000, %r10
    ja .Lsg_ret
    leaq 0(,%r9,8), %rax
    pushq %rcx
    pushq %rdx
    cmpq $524288, %rax
    jae .L220
    movl $524288, %eax
.L220:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    popq %rdx
    popq %rcx
    shrq $3, %rax
    cmpq %rax, %r10
    movl $0, %eax
    ja .Lsg_ret
.Lsg_fits:
    movq %r10, %rax
    subq %r9, %rax
    shlq $3, %rax
    addq %rax, __fern_lc_alloc_bytes(%rip)
.Lsg_copy:
    movq %rdi, 8(%r8)
    movq (%r8), %rdi
    addq %rcx, %rdi
    movq %rsi, %rcx
    movq %rdx, %rsi
    rep movsb
    movl $1, %eax
.Lsg_ret:
    ret
__fn___fern_str_grow_fresh:
    movq __fern_hev_site(%rip), %rax
    testq %rax, %rax
    jne .Lsgf_hs
    movq (%rsp), %rax
    movq %rax, __fern_hev_site(%rip)
.Lsgf_hs:
    movq 16(%rsp), %r8
    movq 8(%rsp), %rdx
    movq 8(%rdx), %rsi
    movq (%rdx), %rdx
    jmp .Lsgf_body
__fn___fern_str_grow_fresh_range:
    movq __fern_hev_site(%rip), %rax
    testq %rax, %rax
    jne .Lsgfr_hs
    movq (%rsp), %rax
    movq %rax, __fern_hev_site(%rip)
.Lsgfr_hs:
    movq 32(%rsp), %r8
    movslq 16(%rsp), %rax
    movslq 8(%rsp), %rsi
    movq 24(%rsp), %rdx
    testq %rax, %rax
    js __fern_slice_abort.c
    cmpq 8(%rdx), %rsi
    jg __fern_slice_abort.c
    subq %rax, %rsi
    js __fern_slice_abort.c
    movq (%rdx), %rdx
    addq %rax, %rdx
.Lsgf_body:
    movq 8(%r8), %rcx
    leaq (%rcx,%rsi), %rdi
    cmpq $0x7fffffff, %rdi
    ja __fern_alloc_size_abort.c
    leaq 39(%rdi), %r9
    shrq $3, %r9
    leaq 31(%rcx), %r10
    shrq $3, %r10
    addq %r10, %r10
    cmpq %r9, %r10
    jae .Lsgf_class
    movq %r9, %r10
.Lsgf_class:
    cmpq $65536, %r10
    jae .Lsgf_large
    pushq %r10
    call __fern_capw
    popq %r10
    jmp .Lsgf_alloc
.Lsgf_large:
    cmpq $0x8000000, %r10
    ja .Lsgf_alloc
    leaq 0(,%r10,8), %rax
    pushq %rcx
    pushq %rdx
    cmpq $524288, %rax
    jae .L221
    movl $524288, %eax
.L221:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    popq %rdx
    popq %rcx
    shrq $3, %rax
    movq %rax, %r10
.Lsgf_alloc:
    leaq 0(,%r10,8), %rdi
    call __fern_alloc
    movq %r10, (%rax)
    movl $1, 8(%rax)
    movl $1196576599, 12(%rax)
    leaq 32(%rax), %rdi
    movq %rdi, 16(%rax)
    leaq (%rcx,%rsi), %r9
    movq %r9, 24(%rax)
    movq %rsi, %r9
    movq (%r8), %rsi
    rep movsb
    movq %rdx, %rsi
    movq %r9, %rcx
    rep movsb
    addq $16, %rax
    ret
__fn___fern_str_borrow:
    movq $24, %rdi
    call __fern_alloc
    movl $1, (%rax)
    movl $1112494674, 4(%rax)
    movq 16(%rsp), %rcx
    movq %rcx, 8(%rax)
    movq 8(%rsp), %rcx
    movq %rcx, 16(%rax)
    addq $8, %rax
    ret
__fn___fern_alloc_reuse:
    movq 16(%rsp), %rax
    movq 8(%rsp), %rsi
__fn___fern_alloc_reuse.r:
    testq %rax, %rax
    jz .Lsarelo_fresh
    cmpq %rsi, -16(%rax)
    je .Lsarelo_ret
    pushq %rsi
    call __fn___fern_arr_dec.r
    popq %rsi
.Lsarelo_fresh:
    movq %rsi, %rdi
    jmp __fern_arr_box
.Lsarelo_ret:
    ret
__fern_memcpy:
    movq %rdi, %rax
    cmpq $8, %rdx
    jb .Lmcp_lt8
    cmpq $16, %rdx
    jb .Lmcp_8_15
    cmpq $32, %rdx
    jbe .Lmcp_16_32
    leaq -32(%rdi,%rdx), %r8
    leaq -32(%rsi,%rdx), %r9
.Lmcp_bulk:
    movdqu (%rsi), %xmm0
    movdqu 16(%rsi), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, 16(%rdi)
    addq $32, %rsi
    addq $32, %rdi
    cmpq %r8, %rdi
    jb .Lmcp_bulk
    movdqu (%r9), %xmm0
    movdqu 16(%r9), %xmm1
    movdqu %xmm0, (%r8)
    movdqu %xmm1, 16(%r8)
    ret
.Lmcp_16_32:
    movdqu (%rsi), %xmm0
    movdqu -16(%rsi,%rdx), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, -16(%rdi,%rdx)
    ret
.Lmcp_8_15:
    movq (%rsi), %r8
    movq -8(%rsi,%rdx), %r9
    movq %r8, (%rdi)
    movq %r9, -8(%rdi,%rdx)
    ret
.Lmcp_lt8:
    cmpq $4, %rdx
    jb .Lmcp_lt4
    movl (%rsi), %r8d
    movl -4(%rsi,%rdx), %r9d
    movl %r8d, (%rdi)
    movl %r9d, -4(%rdi,%rdx)
    ret
.Lmcp_lt4:
    testq %rdx, %rdx
    je .Lmcp_done
    movzbq (%rsi), %r8
    movzbq -1(%rsi,%rdx), %r9
    movb %r8b, (%rdi)
    movb %r9b, -1(%rdi,%rdx)
    cmpq $3, %rdx
    jb .Lmcp_done
    movzbq 1(%rsi), %r8
    movb %r8b, 1(%rdi)
.Lmcp_done:
    ret
__fern_buf_new:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rbx
    pushq %r12
    movq %rdi, %rbx
    cmpq $16, %rbx
    jae .Lbufnew_cap
    movq $16, %rbx
.Lbufnew_cap:
    movq $32, %rdi
    call __fern_alloc
    movq %rax, %r12
    movq %rbx, %rdi
    call __fern_alloc
    movq %rax, (%r12)
    movq $0, 8(%r12)
    movq %rbx, 16(%r12)
    movq %rbx, 24(%r12)
    movq %r12, %rax
    popq %r12
    popq %rbx
    popq %rbp
    ret
__fern_buf_reserve:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rdi, %rbx
    movq %rsi, %r12
    movq 16(%rbx), %r13
    testq %r13, %r13
    jnz .Lbufres_dbl
    movq 24(%rbx), %r13
    testq %r13, %r13
    jnz .Lbufres_dbl
    movq $64, %r13
.Lbufres_dbl:
    cmpq %r12, %r13
    jae .Lbufres_alloc
    addq %r13, %r13
    jmp .Lbufres_dbl
.Lbufres_alloc:
    movq %r13, %rdi
    call __fern_alloc
    movq %rax, %r14
    movq 8(%rbx), %rcx
    testq %rcx, %rcx
    jz .Lbufres_nocopy
    movq (%rbx), %rsi
    movq %r14, %rdx
    movq %rdx, %rdi
    movq %rcx, %rdx
    call __fern_memcpy
.Lbufres_nocopy:
    movq (%rbx), %rcx
    testq %rcx, %rcx
    jz .Lbufres_store
    movq 16(%rbx), %rdx
    addq $7, %rdx
    shrq $3, %rdx
    cmpq $65536, %rdx
    jae .Lbufres_old_large
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
    jmp .Lbufres_old_done
.Lbufres_old_large:
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
.Lbufres_old_done:
.Lbufres_store:
    movq %r14, (%rbx)
    movq %r13, 16(%rbx)
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    ret
__fern_buf_push:
    movslq 8(%rsi), %rcx
    testq %rcx, %rcx
    jz .Lbufrange_done
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r8
    cmpq 16(%rdi), %r8
    ja .Lbufpush_grow
    movq %r8, 8(%rdi)
    movq (%rsi), %rsi
    movq (%rdi), %rdi
    addq %rax, %rdi
    jmp .Lbufrange_tail
.Lbufpush_grow:
    xorl %edx, %edx
    jmp .Lbufrange_grow
__fern_buf_push_range:
    movslq %edx, %rdx
    movslq %ecx, %rcx
    testq %rdx, %rdx
    js __fern_slice_abort.c
    cmpq 8(%rsi), %rcx
    jg __fern_slice_abort.c
    subq %rdx, %rcx
    js __fern_slice_abort.c
    jz .Lbufrange_done
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r8
    cmpq 16(%rdi), %r8
    ja .Lbufrange_grow
.Lbufrange_copy:
    movq %r8, 8(%rdi)
    movq (%rsi), %rsi
    addq %rdx, %rsi
    movq (%rdi), %rdi
    addq %rax, %rdi
.Lbufrange_tail:
    cmpq $8, %rcx
    jae .Lbufrange_c8
    cmpq $4, %rcx
    jae .Lbufrange_c4
    cmpq $2, %rcx
    jae .Lbufrange_c2
    movzbl (%rsi), %r8d
    movb %r8b, (%rdi)
    ret
.Lbufrange_c2:
    movzwl (%rsi), %r8d
    movzwl -2(%rsi,%rcx), %r9d
    movw %r8w, (%rdi)
    movw %r9w, -2(%rdi,%rcx)
    ret
.Lbufrange_c4:
    movl (%rsi), %r8d
    movl -4(%rsi,%rcx), %r9d
    movl %r8d, (%rdi)
    movl %r9d, -4(%rdi,%rcx)
    ret
.Lbufrange_c8:
    cmpq $16, %rcx
    ja .Lbufrange_long
    movq (%rsi), %r8
    movq -8(%rsi,%rcx), %r9
    movq %r8, (%rdi)
    movq %r9, -8(%rdi,%rcx)
    ret
.Lbufrange_long:
    movq %rcx, %rdx
    jmp __fern_memcpy
.Lbufrange_grow:
    pushq %rdi
    pushq %rsi
    pushq %rdx
    pushq %rcx
    subq $8, %rsp
    movq %r8, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %rcx
    popq %rdx
    popq %rsi
    popq %rdi
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r8
    jmp .Lbufrange_copy
.Lbufrange_done:
    ret
__fern_buf_push_byte:
    movq 8(%rdi), %rax
    leaq 1(%rax), %rcx
    cmpq 16(%rdi), %rcx
    ja .Lbufbyte_grow
.Lbufbyte_fits:
    movq (%rdi), %rdx
    movb %sil, (%rdx,%rax)
    movq %rcx, 8(%rdi)
    ret
.Lbufbyte_grow:
    pushq %rdi
    pushq %rsi
    subq $8, %rsp
    movq %rcx, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %rsi
    popq %rdi
    movq 8(%rdi), %rax
    leaq 1(%rax), %rcx
    jmp .Lbufbyte_fits
__fern_buf_push_u64:
    movq 8(%rdi), %rax
    leaq 8(%rax), %rcx
    cmpq 16(%rdi), %rcx
    ja .Lbufu64_grow
.Lbufu64_fits:
    movq (%rdi), %rdx
    movq %rsi, (%rdx,%rax)
    movq %rcx, 8(%rdi)
    ret
.Lbufu64_grow:
    pushq %rdi
    pushq %rsi
    subq $8, %rsp
    movq %rcx, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %rsi
    popq %rdi
    movq 8(%rdi), %rax
    leaq 8(%rax), %rcx
    jmp .Lbufu64_fits
__fern_buf_push_decimal:
    subq $40, %rsp
    leaq 32(%rsp), %r8
    movq %rsi, %rax
    leaq .Ldecimal_pairs(%rip), %r11
    movabsq $2951479051793528259, %r10
.Ldecimal_loop:
    cmpq $100, %rax
    jb .Ldecimal_tail
    movq %rax, %r9
    shrq $2, %rax
    mulq %r10
    shrq $2, %rdx
    imulq $100, %rdx, %rax
    subq %rax, %r9
    movzwl (%r11,%r9,2), %eax
    subq $2, %r8
    movw %ax, (%r8)
    movq %rdx, %rax
    jmp .Ldecimal_loop
.Ldecimal_tail:
    cmpq $10, %rax
    jb .Ldecimal_one
    movzwl (%r11,%rax,2), %eax
    subq $2, %r8
    movw %ax, (%r8)
    jmp .Ldecimal_copy
.Ldecimal_one:
    addl $48, %eax
    subq $1, %r8
    movb %al, (%r8)
.Ldecimal_copy:
    leaq 32(%rsp), %rcx
    subq %r8, %rcx
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r9
    cmpq 16(%rdi), %r9
    ja .Ldecimal_grow
.Ldecimal_fits:
    movq %r9, 8(%rdi)
    movq (%rdi), %rdx
    addq %rax, %rdx
    cmpq $8, %rcx
    jae .Ldecimal_c8
    cmpq $4, %rcx
    jae .Ldecimal_c4
    cmpq $2, %rcx
    jae .Ldecimal_c2
    movzbl (%r8), %eax
    movb %al, (%rdx)
    addq $40, %rsp
    ret
.Ldecimal_c2:
    movzwl (%r8), %eax
    movzwl -2(%r8,%rcx), %r9d
    movw %ax, (%rdx)
    movw %r9w, -2(%rdx,%rcx)
    addq $40, %rsp
    ret
.Ldecimal_c4:
    movl (%r8), %eax
    movl -4(%r8,%rcx), %r9d
    movl %eax, (%rdx)
    movl %r9d, -4(%rdx,%rcx)
    addq $40, %rsp
    ret
.Ldecimal_c8:
    movq (%r8), %rax
    movq 8(%r8), %r10
    movq -8(%r8,%rcx), %r9
    movq %rax, (%rdx)
    cmpq $16, %rcx
    jbe .Ldecimal_c8_tail
    movq %r10, 8(%rdx)
.Ldecimal_c8_tail:
    movq %r9, -8(%rdx,%rcx)
    addq $40, %rsp
    ret
.Ldecimal_grow:
    pushq %rdi
    pushq %rcx
    pushq %r8
    subq $8, %rsp
    movq %r9, %rsi
    call __fern_buf_reserve
    addq $8, %rsp
    popq %r8
    popq %rcx
    popq %rdi
    movq 8(%rdi), %rax
    leaq (%rax,%rcx), %r9
    jmp .Ldecimal_fits
    .section .rodata
.Ldecimal_pairs:
    .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
    .section .text
__fern_buf_len:
    movq 8(%rdi), %rax
    ret
__fern_buf_clear:
    movq $0, 8(%rdi)
    xorl %eax, %eax
    ret
__fern_buf_take:
    pushq %rdi
    call __fn___fern_buf_take_text
    addq $8, %rsp
    ret
__fn___fern_buf_text_part:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_buf_text_part.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
.Lssa___fern_buf_text_part_0:
    movzbl (%rax,%rsi), %r8d
    cmpq $128, %r8
    jge .Lssa___fern_buf_text_part_18
.Lssa___fern_buf_text_part_20:
    movl $1, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_text_part_18:
    cmpq $194, %r8
    jl .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_17:
    cmpq $223, %r8
    jg .Lssa___fern_buf_text_part_15
.Lssa___fern_buf_text_part_16:
    movl $2, %r9d
    jmp .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_15:
    cmpq $224, %r8
    jl .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_14:
    cmpq $239, %r8
    jg .Lssa___fern_buf_text_part_12
.Lssa___fern_buf_text_part_13:
    movl $3, %r9d
    jmp .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_12:
    cmpq $240, %r8
    jl .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_11:
    cmpq $244, %r8
    jg .Lssa___fern_buf_text_part_9
.Lssa___fern_buf_text_part_10:
    movl $4, %r9d
    jmp .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_9:
    xorl %r9d, %r9d
.Lssa___fern_buf_text_part_8:
.Lssa___fern_buf_text_part_7:
    subq %rsi, %rdi
    movslq %edi, %rdi
    movl $1, %r10d
.Lssa___fern_buf_text_part_52:
    cmpq %r9, %r10
    jge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_67:
    cmpq %rdi, %r10
    jge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_66:
    leaq (%rsi,%r10), %rcx
    movslq %ecx, %rbx
    movzbl (%rax,%rbx), %r12d
    cmpq $128, %r12
    jl .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_65:
    cmpq $191, %r12
    jg .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_63:
    cmpq $1, %r10
    jne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_62:
    cmpq $224, %r8
    jne .Lssa___fern_buf_text_part_60
.Lssa___fern_buf_text_part_61:
    cmpq $160, %r12
    jl .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_60:
    cmpq $237, %r8
    jne .Lssa___fern_buf_text_part_58
.Lssa___fern_buf_text_part_59:
    cmpq $159, %r12
    jg .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_58:
    cmpq $240, %r8
    jne .Lssa___fern_buf_text_part_56
.Lssa___fern_buf_text_part_57:
    cmpq $144, %r12
    jl .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_56:
    cmpq $244, %r8
    jne .Lssa___fern_buf_text_part_53
.Lssa___fern_buf_text_part_55:
    cmpq $143, %r12
    jg .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_53:
    addq $1, %r10
    cmpq %r9, %r10
    jl .Lssa___fern_buf_text_part_67
.Lssa___fern_buf_text_part_4:
    xorl %edi, %edi
    subq %r10, %rdi
    movslq %edi, %rdi
    cmpq %r9, %r10
    movq %r10, %rax
    cmovneq %rdi, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___fern_buf_take_text:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_buf_take_text.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $72, %rsp
    movq %rax, -48(%rbp)
.Lssa___fern_buf_take_text_0:
    movq -48(%rbp), %r11
    movq 8(%r11), %rsi
    cmpq $0, %rsi
    jl .Lssa___fern_buf_take_text_16
.Lssa___fern_buf_take_text_17:
    cmpq $2147483647, %rsi
    jle .Lssa___fern_buf_take_text_14
.Lssa___fern_buf_take_text_16:
    movq $-1, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    xorl %edi, %edi
    movq %rax, %r11
    movq %rdi, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    movq %rax, %r8
    movq %r8, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_14:
    movslq %esi, %r12
    cmpq $0, %r12
    jne .Lssa___fern_buf_take_text_11
.Lssa___fern_buf_take_text_13:
    leaq .SB6(%rip), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_11:
    movq -48(%rbp), %r11
    movq 0(%r11), %r11
    movq %r11, -56(%rbp)
    movabsq $9259542123273814144, %r11
    movq %r11, -64(%rbp)
.Lssa___fern_buf_take_text_10:
    movq %rsi, %r15
    xorl %ebx, %ebx
    xorl %r14d, %r14d
.Lssa___fern_buf_take_text_30:
    cmpq %r12, %rbx
    jge .Lssa___fern_buf_take_text_9
.Lssa___fern_buf_take_text_40:
    movq %r12, %rsi
    subq %rbx, %rsi
    movslq %esi, %rsi
    cmpq $8, %rsi
    jl .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_39:
    movq -56(%rbp), %rsi
    addq %rbx, %rsi
    movq 0(%rsi), %r8
    andq -64(%rbp), %r8
    cmpq $0, %r8
    jne .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_38:
    leaq 8(%rbx), %r8
    movslq %r8d, %rbx
    cmpq %r12, %rbx
    jge .Lssa___fern_buf_take_text_9
    jmp .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_34:
    movq -56(%rbp), %rax
    movq %rbx, %rsi
    movq %r12, %rdi
    call __fn___fern_buf_text_part.r
    cmpq $0, %rax
    jge .Lssa___fern_buf_take_text_32
.Lssa___fern_buf_take_text_33:
    leaq 3(%rax), %r8
    movslq %r8d, %r8
    addq %r15, %r8
    movq %rbx, %rsi
    subq %rax, %rsi
    movslq %esi, %rsi
    movq %r8, %r15
    movq %rsi, %rbx
    movl $1, %r14d
    jmp .Lssa___fern_buf_take_text_30
.Lssa___fern_buf_take_text_32:
    addq %rax, %rbx
    movslq %ebx, %rbx
.Lssa___fern_buf_take_text_31:
    cmpq %r12, %rbx
    jl .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_9:
    cmpq $2147483647, %r15
    jle .Lssa___fern_buf_take_text_6
.Lssa___fern_buf_take_text_8:
    movq $-1, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    xorl %edi, %edi
    movq %rax, %r11
    movq %rdi, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    movq %rax, %rsi
    movq %rsi, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_6:
    movslq %r15d, %r11
    movq %r11, -72(%rbp)
    movq -72(%rbp), %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %rbx
    testq %r14, %r14
    jz .Lssa___fern_buf_take_text_2
.Lssa___fern_buf_take_text_5:
.Lssa___fern_buf_take_text_4:
    xorl %r14d, %r14d
    xorl %r15d, %r15d
    xorl %r13d, %r13d
.Lssa___fern_buf_take_text_70:
    cmpq %r12, %r14
    jge .Lssa___fern_buf_take_text_3
.Lssa___fern_buf_take_text_80:
    movq %r12, %rsi
    subq %r14, %rsi
    movslq %esi, %rsi
    cmpq $8, %rsi
    jl .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_79:
    movq -56(%rbp), %rsi
    addq %r14, %rsi
    movq 0(%rsi), %rdi
    andq -64(%rbp), %rdi
    cmpq $0, %rdi
    jne .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_78:
    leaq 8(%r14), %rdi
    movslq %edi, %r14
    cmpq %r12, %r14
    jge .Lssa___fern_buf_take_text_3
    jmp .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_74:
    movq -56(%rbp), %rax
    movq %r14, %rsi
    movq %r12, %rdi
    call __fn___fern_buf_text_part.r
    movq %rax, %r8
    cmpq $0, %r8
    jge .Lssa___fern_buf_take_text_72
.Lssa___fern_buf_take_text_73:
    movslq %r13d, %rdi
    addq %rbx, %rdi
    movq -56(%rbp), %rsi
    addq %r15, %rsi
    movq %r14, %r9
    subq %r15, %r9
    movslq %r9d, %r9
    movq %r8, -80(%rbp)
    movq %r9, -88(%rbp)
    movq %r9, %rdx
    call __fern_memcpy
    pushq $0
    popq %rax
    movq -80(%rbp), %r8
    movq -88(%rbp), %r9
    addq %r13, %r9
    movslq %r9d, %r9
    movl $239, %esi
    movb %sil, (%rbx,%r9)
    leaq 1(%r9), %rdi
    movslq %edi, %rdi
    movl $191, %esi
    movb %sil, (%rbx,%rdi)
    leaq 2(%r9), %r10
    movslq %r10d, %r10
    movl $189, %esi
    movb %sil, (%rbx,%r10)
    addq $3, %r9
    movq %r14, %rdi
    subq %r8, %rdi
    movslq %edi, %rdi
    movq %rdi, %r14
    movq %rdi, %r15
    movq %r9, %r13
    jmp .Lssa___fern_buf_take_text_70
.Lssa___fern_buf_take_text_72:
    addq %r8, %r14
    movslq %r14d, %r14
.Lssa___fern_buf_take_text_71:
    cmpq %r12, %r14
    jl .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_3:
    movslq %r13d, %r13
    addq %rbx, %r13
    movq -56(%rbp), %r8
    addq %r15, %r8
    movq %r12, %r11
    subq %r15, %r11
    movq %r11, %r15
    movslq %r15d, %r15
    movq %r15, %rdx
    movq %r8, %rsi
    movq %r13, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    jmp .Lssa___fern_buf_take_text_1
.Lssa___fern_buf_take_text_2:
    movq %r12, %rdx
    movq -56(%rbp), %rsi
    movq %rbx, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
.Lssa___fern_buf_take_text_1:
    xorl %r8d, %r8d
    movq -48(%rbp), %r11
    movq %r8, 8(%r11)
    movq %rbx, %r11
    movq -72(%rbp), %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fern_buf_free:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rbx
    pushq %r12
    movq %rdi, %rbx
    testq %rbx, %rbx
    jz .Lbuffree_ret
    movq (%rbx), %rcx
    testq %rcx, %rcx
    jz .Lbuffree_ctl
    movq 16(%rbx), %rdx
    addq $7, %rdx
    shrq $3, %rdx
    cmpq $65536, %rdx
    jae .Lbuffree_data_large
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
    jmp .Lbuffree_data_done
.Lbuffree_data_large:
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
.Lbuffree_data_done:
.Lbuffree_ctl:
    movq %rbx, %rcx
    movq $4, %rdx
    cmpq $65536, %rdx
    jae .Lbuffree_ctlblk_large
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
    jmp .Lbuffree_ctlblk_done
.Lbuffree_ctlblk_large:
    pushq %rdx
    pushq %rcx
    call __fern_hev_f
    addq $16, %rsp
    movq %rdx, %rsi
    movq %rcx, %rdi
    movq $16, %rdx
    call __fern_quar_push
.Lbuffree_ctlblk_done:
.Lbuffree_ret:
    popq %r12
    popq %rbx
    popq %rbp
    ret
__fern_arr_push:
.Larr_push_slow:
.Larr_push_frame:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    movq %rdi, %r12
    movq %rsi, %r13
    movq (%r12), %r14
    movq -16(%r12), %r15
    movl -8(%r12), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    cmpl $1, %ecx
    je .Larr_push_rc_ok
    testl %ecx, %ecx
    js .Larr_push_rc_ok
    jmp .Larr_push_grow
.Larr_push_rc_ok:
    cmpq %r15, %r14
    jge .Larr_push_grow
    movq %r14, %rcx
    incq %rcx
    movq %r13, (%r12,%rcx,8)
    incq %r14
    movq %r14, (%r12)
    movq %r12, %rax
    jmp .Larr_push_ret
.Larr_push_grow:
    movq %r15, %rcx
    cmpq %r15, %r14
    jl .Larr_push_shared_cliff
    cmpq $0, %rcx
    jne .Larr_push_dbl
    movq $4, %rcx
    jmp .Larr_push_cap
.Larr_push_shared_cliff:
    incq __fern_arr_push_shared(%rip)
    movq %r14, %rax
    shlq $3, %rax
    addq %rax, __fern_arr_push_copied(%rip)
    jmp .Larr_push_cap
.Larr_push_dbl:
    shlq $1, %rcx
.Larr_push_cap:
    leaq 1(%r14), %rax
    cmpq %rax, %rcx
    cmovbq %rax, %rcx
    movq %rcx, %r15
    movq %r15, %rdi
    call __fern_arr_box
    movq %r14, %rcx
    incq %rcx
    movq %rcx, (%rax)
    leaq 8(%r12), %rsi
    leaq 8(%rax), %rdi
    movq %r14, %rcx
    subq $8, %rcx
    jl .Larr_push_copy_lt8
.Larr_push_copy8:
    vmovdqu (%rsi), %ymm0
    vmovdqu 32(%rsi), %ymm1
    vmovdqu %ymm0, (%rdi)
    vmovdqu %ymm1, 32(%rdi)
    addq $64, %rsi
    addq $64, %rdi
    subq $8, %rcx
    jge .Larr_push_copy8
    vzeroupper
.Larr_push_copy_lt8:
    addq $8, %rcx
    cmpq $4, %rcx
    jl .Larr_push_copy1
    movdqu (%rsi), %xmm0
    movdqu 16(%rsi), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, 16(%rdi)
    addq $32, %rsi
    addq $32, %rdi
    subq $4, %rcx
.Larr_push_copy1:
    testq %rcx, %rcx
    jz .Larr_push_copy_done
.Larr_push_copy1_loop:
    movq (%rsi), %rdx
    movq %rdx, (%rdi)
    addq $8, %rsi
    addq $8, %rdi
    decq %rcx
    jnz .Larr_push_copy1_loop
.Larr_push_copy_done:
    movq %r14, %rcx
    incq %rcx
    movq %r13, (%rax,%rcx,8)
.Larr_push_ret:
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    leave
    ret
__fern_arr_push_owned:
.Lapo_slow:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    movq %rdi, %r12
    call __fern_arr_push
    cmpq %rax, %r12
    je .Lapo_ret
    cmpq $0x10000, %r12
    jb .Lapo_ret
    movl -8(%r12), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lapo_ret
    cmpl $1, %ecx
    jne .Lapo_ret
    movl -16(%r12), %ecx
    addq $3, %rcx
    cmpq $65536, %rcx
    jae .Lapo_large
    movl $2129525454, -8(%r12)
    leaq -16(%r12), %rdx
    pushq %rcx
    pushq %rdx
    call __fern_hev_f
    addq $16, %rsp
    movq %rcx, %rsi
    movq %rdx, %rdi
    movq $8, %rdx
    call __fern_quar_push
.Lapo_ret:
    popq %r13
    popq %r12
    leave
    ret
.Lapo_large:
    movl $2129525454, -8(%r12)
    leaq -16(%r12), %rdi
    pushq %rcx
    pushq %rdi
    call __fern_hev_f
    addq $16, %rsp
    movq %rcx, %rsi
    movq $8, %rdx
    call __fern_quar_push
    jmp .Lapo_ret
__fern_arr_push_u8:
.Larr_push_u8_slow:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    movq %rdi, %r12
    movq %rsi, %r13
    movq (%r12), %r14
    movq -16(%r12), %r15
    movl -8(%r12), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    cmpl $1, %ecx
    je .Larr_push_u8_rc_ok
    testl %ecx, %ecx
    js .Larr_push_u8_rc_ok
    jmp .Larr_push_u8_grow
.Larr_push_u8_rc_ok:
    movq %r15, %rcx
    shlq $3, %rcx
    cmpq %rcx, %r14
    jge .Larr_push_u8_grow
    movb %r13b, 8(%r12,%r14)
    incq %r14
    movq %r14, (%r12)
    movq %r12, %rax
    jmp .Larr_push_u8_ret
.Larr_push_u8_grow:
    movq %r15, %rcx
    movq %r15, %rax
    shlq $3, %rax
    cmpq %rax, %r14
    jl .Larr_push_u8_cliff
    testq %rcx, %rcx
    jne .Larr_push_u8_dbl
    movq $4, %rcx
    jmp .Larr_push_u8_cap
.Larr_push_u8_cliff:
    incq __fern_arr_push_shared(%rip)
    addq %r14, __fern_arr_push_copied(%rip)
    jmp .Larr_push_u8_cap
.Larr_push_u8_dbl:
    shlq $1, %rcx
.Larr_push_u8_cap:
    leaq 8(%r14), %rax
    shrq $3, %rax
    cmpq %rax, %rcx
    cmovbq %rax, %rcx
    movq %rcx, %rdi
    call __fern_arr_box
    leaq 1(%r14), %rcx
    movq %rcx, (%rax)
    leaq 8(%r12), %rsi
    leaq 8(%rax), %rdi
    movq %r14, %rcx
    rep movsb
    movb %r13b, 8(%rax,%r14)
.Larr_push_u8_ret:
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    leave
    ret
__fern_arr_push_owned_u8:
.Lapou_slow:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    movq %rdi, %r12
    call __fern_arr_push_u8
    cmpq %rax, %r12
    je .Lapou_ret
    cmpq $0x10000, %r12
    jb .Lapou_ret
    movl -8(%r12), %ecx
    cmpl $2129525454, %ecx
    je __fern_san_abort_uaf
    testl %ecx, %ecx
    js .Lapou_ret
    cmpl $1, %ecx
    jne .Lapou_ret
    movl -16(%r12), %ecx
    addq $3, %rcx
    cmpq $65536, %rcx
    jae .Lapou_large
    movl $2129525454, -8(%r12)
    leaq -16(%r12), %rdx
    pushq %rcx
    pushq %rdx
    call __fern_hev_f
    addq $16, %rsp
    movq %rcx, %rsi
    movq %rdx, %rdi
    movq $8, %rdx
    call __fern_quar_push
.Lapou_ret:
    popq %r13
    popq %r12
    leave
    ret
.Lapou_large:
    movl $2129525454, -8(%r12)
    leaq -16(%r12), %rdi
    pushq %rcx
    pushq %rdi
    call __fern_hev_f
    addq $16, %rsp
    movq %rcx, %rsi
    movq $8, %rdx
    call __fern_quar_push
    jmp .Lapou_ret
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .section .text
__fern_alloc_bytes:
    testl %edi, %edi
    js __fern_alloc_size_abort.c
    jz .Lfern_alloc_bytes_empty
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    movq %rdi, %r12
    leaq 7(%rdi), %rdi
    shrq $3, %rdi
    movq %rdi, %r13
    call __fern_arr_box
    movq %r12, (%rax)
    movq %rax, %rdx
    leaq 8(%rax), %rdi
    movq %r13, %rcx
    xorl %eax, %eax
    rep stosq
    movq %rdx, %rax
    popq %r13
    popq %r12
    popq %rbp
    ret
.Lfern_alloc_bytes_empty:
    leaq .Lfern_empty_bytes(%rip), %rax
    ret
    .text
    .section .bss
    .align 8
__fern_lc_alloc_count: .quad 0
    .align 8
__fern_lc_alloc_bytes: .quad 0
    .align 8
__fern_lc_rt_req: .quad 0
    .align 8
__fern_lc_free_count: .quad 0
    .align 8
__fern_lc_free_bytes: .quad 0
    .align 8
__fern_lc_exited: .quad 0
    .align 8
__fern_hev_site: .quad 0
    .section .rodata
.Lhev_nl:
    .ascii "\n"
.Llc_a:
    .ascii "leakcheck: allocs="
.Llc_f:
    .ascii " frees="
.Llc_l:
    .ascii " live_bytes="
.Llc_x:
    .ascii " from=exit"
.Lsan_df:
    .ascii "fern-sanitizer: rc over-release (double free)\n"
.Lsan_leak:
    .ascii "fern-sanitizer: leak "
.Lsan_bytesin:
    .ascii " bytes in "
.Lsan_blocks:
    .ascii " blocks"
    .section .text
    .globl __fern_hev_a
__fern_hev_a:
    pushq %rax
    pushq %rcx
    pushq %rdx
    pushq %rsi
    pushq %rdi
    pushq %r8
    pushq %r9
    pushq %r10
    pushq %r11
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq 112(%rsp), %r14
    movq 120(%rsp), %r12
    movq 128(%rsp), %r13
    shlq $3, %r13
    movq $97, %rbx
    movq __fern_hev_site(%rip), %rax
    testq %rax, %rax
    je .Lhev_a_nosite
    movq %rax, %r14
    movq $0, %rax
    movq %rax, __fern_hev_site(%rip)
.Lhev_a_nosite:
    movq __fern_lc_alloc_count(%rip), %rax
    addq $1, %rax
    movq %rax, __fern_lc_alloc_count(%rip)
    movq __fern_lc_alloc_bytes(%rip), %rax
    addq %r13, %rax
    movq %rax, __fern_lc_alloc_bytes(%rip)
    jmp .Lhev_emit
    .globl __fern_hev_f
__fern_hev_f:
    pushq %rax
    pushq %rcx
    pushq %rdx
    pushq %rsi
    pushq %rdi
    pushq %r8
    pushq %r9
    pushq %r10
    pushq %r11
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq 104(%rsp), %r14
    movq 112(%rsp), %r12
    movq 120(%rsp), %r13
    shlq $3, %r13
    movq $102, %rbx
    movq __fern_lc_free_count(%rip), %rax
    addq $1, %rax
    movq %rax, __fern_lc_free_count(%rip)
    movq __fern_lc_free_bytes(%rip), %rax
    addq %r13, %rax
    movq %rax, __fern_lc_free_bytes(%rip)
.Lhev_emit:
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %r11
    popq %r10
    popq %r9
    popq %r8
    popq %rdi
    popq %rsi
    popq %rdx
    popq %rcx
    popq %rax
    ret
.Lhev_w:
    movq $2, %rdi
    movq $1, %rax
    syscall
    ret
    .globl __fern_lc_report_exit
__fern_lc_report_exit:
    movq $1, __fern_lc_exited(%rip)
    .globl __fern_lc_report
__fern_lc_report:
    movq __fern_quar_head(%rip), %rdi
.Lquar_end_loop:
    testq %rdi, %rdi
    jz .Lquar_end_done
    cmpl $2129525454, (%rdi)
    jne .Lquar_end_size0
    movq 8(%rdi), %rsi
    jmp .Lquar_end_scan
.Lquar_end_size0:
    cmpl $2129525454, 8(%rdi)
    jne __fern_san_abort_waf
    movq (%rdi), %rsi
.Lquar_end_scan:
    leaq 24(%rdi), %r8
    leaq -3(%rsi), %rcx
    movabs $9146242183059077838, %rax
    testq %rcx, %rcx
    jz .Lquar_atexit_done
.Lquar_atexit:
    cmpq %rax, (%r8)
    jne __fern_san_abort_waf
    addq $8, %r8
    subq $1, %rcx
    jnz .Lquar_atexit
.Lquar_atexit_done:
    movq 16(%rdi), %rdi
    jmp .Lquar_end_loop
.Lquar_end_done:
    leaq .Llc_a(%rip), %rsi
    movq $18, %rdx
    call .Lhev_w
    movq __fern_lc_alloc_count(%rip), %rdi
    call .Llc_num
    leaq .Llc_f(%rip), %rsi
    movq $7, %rdx
    call .Lhev_w
    movq __fern_lc_free_count(%rip), %rdi
    call .Llc_num
    leaq .Llc_l(%rip), %rsi
    movq $12, %rdx
    call .Lhev_w
    movq __fern_lc_alloc_bytes(%rip), %rdi
    movq __fern_lc_free_bytes(%rip), %rax
    subq %rax, %rdi
    call .Llc_num
    cmpq $0, __fern_lc_exited(%rip)
    je .Llc_from_done
    leaq .Llc_x(%rip), %rsi
    movq $10, %rdx
    call .Lhev_w
.Llc_from_done:
    leaq .Lhev_nl(%rip), %rsi
    movq $1, %rdx
    call .Lhev_w
    movq __fern_lc_alloc_bytes(%rip), %rax
    subq __fern_lc_free_bytes(%rip), %rax
    testq %rax, %rax
    jle .Lsan_leak_done
    leaq .Lsan_leak(%rip), %rsi
    movq $21, %rdx
    call .Lhev_w
    movq __fern_lc_alloc_bytes(%rip), %rdi
    subq __fern_lc_free_bytes(%rip), %rdi
    call .Llc_num
    leaq .Lsan_bytesin(%rip), %rsi
    movq $10, %rdx
    call .Lhev_w
    movq __fern_lc_alloc_count(%rip), %rdi
    subq __fern_lc_free_count(%rip), %rdi
    call .Llc_num
    leaq .Lsan_blocks(%rip), %rsi
    movq $7, %rdx
    call .Lhev_w
    leaq .Lhev_nl(%rip), %rsi
    movq $1, %rdx
    call .Lhev_w
.Lsan_leak_done:
    ret
.Llc_num:
    subq $48, %rsp
    movq %rsp, %rcx
    addq $32, %rcx
    movq $0, %r9
    movq %rdi, %rax
    testq %rax, %rax
    jns .Llc_numloop
    negq %rax
    movq $1, %r9
.Llc_numloop:
    movq $0, %rdx
    movq $10, %rsi
    divq %rsi
    addq $48, %rdx
    subq $1, %rcx
    movb %dl, (%rcx)
    testq %rax, %rax
    jne .Llc_numloop
    testq %r9, %r9
    je .Llc_numemit
    subq $1, %rcx
    movq $45, %rdx
    movb %dl, (%rcx)
.Llc_numemit:
    movq %rsp, %rdx
    addq $32, %rdx
    subq %rcx, %rdx
    movq %rcx, %rsi
    call .Lhev_w
    addq $48, %rsp
    ret
    .globl __fern_san_abort
__fern_san_abort:
    leaq .Lsan_df(%rip), %rsi
    movq $46, %rdx
    call .Lhev_w
    movq $124, %r15
    jmp __fern_bt_exit
    .text
    .section .bss
    .align 8
__fern_sig_sp: .quad 0
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
.Lmsg_illegal_instruction:
    .ascii "fern: illegal instruction\n"
.Lmsg_bus_error:
    .ascii "fern: bus error\n"
    .text
__fern_segv:
    cmpq $11, %rdi
    jne .Lfern_fatal_signal
    movq 16(%rsi), %rax
    movq __fern_stack_top(%rip), %rcx
    subq $1073741808, %rcx
    subq %rcx, %rax
    cmpq $1048576, %rax
    jae .Lfern_segv_other
.Lfern_segv_overflow:
    movq 168(%rdx), %rax
    movq 120(%rdx), %rcx
    subq $16, %rsp
    movq %rcx, (%rsp)
    movq %rax, 8(%rsp)
    movq %rsp, %rbp
    movq 160(%rdx), %rax
    movq %rax, __fern_bt_floor(%rip)
    leaq .Lmsg_stack_overflow(%rip), %rsi
    movq $21, %rdx
    movq $134, %rdi
    jmp __fern_report
.Lfern_segv_other:
    subq $32, %rsp
    movq $0, (%rsp)
    movq $0x04000000, 8(%rsp)
    call .Lfern_fault_install
    addq $32, %rsp
    ret
.Lfern_segv_restorer:
    movl $15, %eax
    syscall
.Lfern_fault_install:
    leaq .Lfern_segv_restorer(%rip), %rax
    movq %rax, 24(%rsp)
    movq $0x448, 32(%rsp)
    leaq 8(%rsp), %rsi
    xorl %edx, %edx
    movl $8, %r10d
    movl $11, %edi
    movl $13, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_fault_install_done
    movl $4, %edi
    movl $13, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_fault_install_done
    movl $7, %edi
    movl $13, %eax
    syscall
    testq %rax, %rax
    jnz .Lfern_fault_install_done
.Lfern_fault_install_done:
    ret
.Lfern_fatal_signal:
    movslq 8(%rsi), %rax
    testq %rax, %rax
    jle .Lfern_signal_sent
    movq %rsp, __fern_sig_sp(%rip)
    movq 168(%rdx), %rax
    movq 120(%rdx), %rcx
    subq $16, %rsp
    movq %rcx, (%rsp)
    movq %rax, 8(%rsp)
    movq %rsp, %rbp
    movq 160(%rdx), %rax
    movq %rax, __fern_bt_floor(%rip)
    leaq .Lmsg_illegal_instruction(%rip), %rsi
    movq $26, %rdx
    cmpq $4, %rdi
    je .Lfern_fatal_report
    leaq .Lmsg_bus_error(%rip), %rsi
    movq $16, %rdx
.Lfern_fatal_report:
    movq $-1, %rdi
    jmp __fern_report
.Lfern_signal_resume:
    movq __fern_sig_sp(%rip), %rsp
    jmp .Lfern_segv_other
.Lfern_signal_sent:
    addq $128, %rdi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_stack_map_failed_msg:
    .ascii "fern: could not map the stack\n"
    .text
.Lfern_stack_map_failed:
    leaq .Lfern_stack_map_failed_msg(%rip), %rsi
    movq $30, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    leaq .Lfern_stack_guard_failed_msg(%rip), %rsi
    movq $40, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    leaq .Lfern_signal_stack_map_failed_msg(%rip), %rsi
    movq $37, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    leaq .Lfern_signal_stack_failed_msg(%rip), %rsi
    movq $41, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    leaq .Lfern_fault_handler_failed_msg(%rip), %rsi
    movq $42, %rdx
    movl $2, %edi
    movl $1, %eax
    syscall
    movl $134, %edi
    movl $231, %eax
    syscall
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=x86-64-linux profile=diagnostic harden=0 pie=0 sanitize=1 backtrace=1 size=0 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .section .bss
    .align 8
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .globl __fern_bt_floor
__fern_bt_floor: .quad 0
    .section .text
__fern_abort_134:
    movq $134, %rdi
__fern_report:
    movq %rdi, %r15
    movq $2, %rdi
    movq $1, %rax
    syscall
    jmp __fern_bt_exit
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .section .text
    .globl __fern_bt_exit
__fern_bt_exit:
    andq $-16, %rsp
    movq %rsp, %r13
    leaq .Lmsg_bt(%rip), %rsi
    movq $11, %rdx
    movq $2, %rdi
    movq $1, %rax
    syscall
    movq %rbp, %rbx
    movl $64, %r14d
.Lbt_loop:
    testl %r14d, %r14d
    jz .Lbt_done
    cmpq %r13, %rbx
    jb .Lbt_done
    testq $7, %rbx
    jnz .Lbt_done
    movq 8(%rbx), %rsi
    cmpq $0x10000, %rsi
    jb .Lbt_done
    call .Lbt_hex
    movq __fern_bt_floor(%rip), %r13
    movq $0, __fern_bt_floor(%rip)
    leaq 8(%rbx), %rax
    testq %r13, %r13
    cmovzq %rax, %r13
    movq (%rbx), %rbx
    decl %r14d
    movq __fern_stack_top(%rip), %rax
    testq %rax, %rax
    jz .Lbt_loop
    cmpq %rax, %rbx
    jae .Lbt_done
    jmp .Lbt_loop
.Lbt_done:
    testq %r15, %r15
    js .Lfern_signal_resume
    movq %r15, %rdi
    movq $231, %rax
    syscall
.Lbt_hex:
    subq $32, %rsp
    movl $0x78302020, (%rsp)
    movb $10, 20(%rsp)
    movl $16, %ecx
.Lbt_hloop:
    movq %rsi, %rax
    andl $15, %eax
    cmpb $10, %al
    jb .Lbt_hdec
    addb $87, %al
    jmp .Lbt_hput
.Lbt_hdec:
    addb $48, %al
.Lbt_hput:
    movb %al, 3(%rsp,%rcx)
    shrq $4, %rsi
    decl %ecx
    jnz .Lbt_hloop
    movq $1, %rax
    movq %rsp, %rsi
    movq $21, %rdx
    syscall
    addq $32, %rsp
    ret
    .text
    .section .rodata
.Lsan_uaf:
    .ascii "fern-sanitizer: use-after-free (touched a quarantined block)\n"
    .section .text
    .globl __fern_san_abort_uaf
__fern_san_abort_uaf:
    leaq .Lsan_uaf(%rip), %rsi
    movq $61, %rdx
    movq $2, %rdi
    movq $1, %rax
    syscall
    movq $124, %r15
    jmp __fern_bt_exit
    .section .rodata
.Lsan_waf:
    .ascii "fern-sanitizer: write-after-free (a quarantined block was written)\n"
    .section .text
    .globl __fern_san_abort_waf
__fern_san_abort_waf:
    leaq .Lsan_waf(%rip), %rsi
    movq $67, %rdx
    movq $2, %rdi
    movq $1, %rax
    syscall
    movq $124, %r15
    jmp __fern_bt_exit
    .section .rodata
.Lsan_hbo:
    .ascii "fern-sanitizer: heap-buffer-overflow (a raw block was written past its end)\n"
    .section .text
    .globl __fern_san_abort_hbo
__fern_san_abort_hbo:
    leaq .Lsan_hbo(%rip), %rsi
    movq $76, %rdx
    movq $2, %rdi
    movq $1, %rax
    syscall
    movq $124, %r15
    jmp __fern_bt_exit
    .text
__fn___fern_str_eq:
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___fern_str_eq.r:
    cmpq %rsi, %rax
    jz .Lseq_yes
    movq 8(%rax), %rdx
    cmpq 8(%rsi), %rdx
    jnz .Lseq_no
    movq (%rax), %rcx
    movq (%rsi), %rsi
    cmpq %rsi, %rcx
    jz .Lseq_yes
    cmpq $8, %rdx
    jb .Lseq_short
    leaq -8(%rcx,%rdx), %r8
    leaq -8(%rsi,%rdx), %r9
.Lseq_word:
    movq (%rcx), %rax
    cmpq (%rsi), %rax
    jnz .Lseq_no
    addq $8, %rcx
    addq $8, %rsi
    cmpq %r8, %rcx
    jb .Lseq_word
    movq (%r8), %rax
    cmpq (%r9), %rax
    jnz .Lseq_no
    jmp .Lseq_yes
.Lseq_short:
    testq %rdx, %rdx
    jz .Lseq_yes
    cmpq $4, %rdx
    jb .Lseq_byte
    movl (%rcx), %eax
    cmpl (%rsi), %eax
    jnz .Lseq_no
    movl -4(%rcx,%rdx), %eax
    cmpl -4(%rsi,%rdx), %eax
    jnz .Lseq_no
    jmp .Lseq_yes
.Lseq_byte:
    movzbl (%rcx), %eax
    cmpb (%rsi), %al
    jnz .Lseq_no
    movzbl -1(%rcx,%rdx), %eax
    cmpb -1(%rsi,%rdx), %al
    jnz .Lseq_no
    cmpq $3, %rdx
    jb .Lseq_yes
    movzbl 1(%rcx), %eax
    cmpb 1(%rsi), %al
    jnz .Lseq_no
.Lseq_yes:
    movl $1, %eax
    ret
.Lseq_no:
    xorl %eax, %eax
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .text
__fn___fern_string_from_bytes_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_string_from_bytes_u8.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    subq $8, %rsp
    movq %rax, %rbx
.Lssa___fern_string_from_bytes_u8_0:
    movq 0(%rbx), %r12
    movq %r12, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %r13
    addq $8, %rbx
    movq %r12, %rdx
    movq %rbx, %rsi
    movq %r13, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r13, %r11
    movq %r12, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    leaq -24(%rbp), %rsp
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_string_from_bytes_range_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_string_from_bytes_range_u8.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa___fern_string_from_bytes_range_u8_0:
    movq 0(%rbx), %rsi
    xorl %r8d, %r8d
    movl $1, %r9d
    cmpq $0, %rdi
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rsi, %rdi
    cmovleq %r9, %r8
    movl $1, %r9d
    cmpq $0, %r12
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rdi, %r12
    cmovleq %r9, %r8
    cmpq $1, %r8
    jne .Lssa___fern_string_from_bytes_range_u8_1
.Lssa___fern_string_from_bytes_range_u8_3:
    call __fern_slice_abort
.Lssa___fern_string_from_bytes_range_u8_1:
    subq %r12, %rdi
    movslq %edi, %r13
    movq %r13, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %r14
    addq $8, %rbx
    movslq %r12d, %r12
    addq %r12, %rbx
    movq %r13, %rdx
    movq %rbx, %rsi
    movq %r14, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %r11
    movq %r13, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_str_bytes_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_str_bytes_u8.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
.Lssa___fern_str_bytes_u8_0:
    movq 8(%rbx), %r12
    movslq %r12d, %r13
    leaq 7(%r13), %rsi
    movq %rsi, %rax
    movq %rax, %rcx
    sarq $63, %rcx
    shrq $61, %rcx
    addq %rax, %rcx
    movq %rcx, %rax
    sarq $3, %rax
    movq %rax, %rdi
    movslq %edi, %rdi
    call __fern_arr_box
    movq %rax, %r14
    movq %r13, 0(%r14)
    leaq 8(%r14), %rdi
    movq 0(%rbx), %rsi
    movq %r12, %rdx
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_arr_slice_u8:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_arr_slice_u8.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa___fern_arr_slice_u8_0:
    movq 0(%rbx), %rsi
    xorl %r8d, %r8d
    movl $1, %r9d
    cmpq $0, %rdi
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rsi, %rdi
    cmovleq %r9, %r8
    movl $1, %r9d
    cmpq $0, %r12
    cmovgeq %r8, %r9
    movl $1, %r8d
    cmpq %rdi, %r12
    cmovleq %r9, %r8
    cmpq $1, %r8
    jne .Lssa___fern_arr_slice_u8_1
.Lssa___fern_arr_slice_u8_3:
    call __fern_slice_abort
.Lssa___fern_arr_slice_u8_1:
    subq %r12, %rdi
    movslq %edi, %r13
    leaq 7(%r13), %rdi
    movslq %edi, %rdi
    movq %rdi, %rax
    movl %eax, %ecx
    sarl $31, %ecx
    shrl $29, %ecx
    addl %eax, %ecx
    movl %ecx, %eax
    sarl $3, %eax
    cltq
    movq %rax, %r8
    movq %r8, %rdi
    call __fern_arr_box
    movq %rax, %r14
    movq %r13, 0(%r14)
    leaq 8(%r14), %r8
    addq $8, %rbx
    movslq %r12d, %r12
    addq %r12, %rbx
    movq %r13, %rdx
    movq %rbx, %rsi
    movq %r8, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_utf8_step:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_utf8_step.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
.Lssa___fern_utf8_step_0:
    cmpq 8(%rax), %rsi
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%rsi), %r8d
    xorl %r9d, %r9d
    movl $1, %r10d
    cmpq $128, %r8
    cmovgeq %r9, %r10
    cmpq $194, %r8
    jl .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_41:
    cmpq $224, %r8
    jge .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_40:
    movl $2, %r10d
.Lssa___fern_utf8_step_39:
.Lssa___fern_utf8_step_38:
    cmpq $224, %r8
    jl .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_37:
    cmpq $240, %r8
    jge .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_36:
    movl $3, %r10d
.Lssa___fern_utf8_step_35:
.Lssa___fern_utf8_step_34:
    cmpq $240, %r8
    jl .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_33:
    cmpq $245, %r8
    jge .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_32:
    movl $4, %r10d
.Lssa___fern_utf8_step_31:
.Lssa___fern_utf8_step_30:
    cmpq $1, %r10
    jg .Lssa___fern_utf8_step_27
.Lssa___fern_utf8_step_29:
    movl $1, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_27:
    leaq 1(%rsi), %r9
    movslq %r9d, %r9
    cmpq %rdi, %r9
    jl .Lssa___fern_utf8_step_24
.Lssa___fern_utf8_step_26:
    movl $1, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_24:
    movl $128, %r9d
    movl $160, %ebx
    cmpq $224, %r8
    cmovneq %r9, %rbx
    movl $144, %r9d
    cmpq $240, %r8
    cmovneq %rbx, %r9
    movl $191, %ebx
    movl $159, %r12d
    cmpq $237, %r8
    cmovneq %rbx, %r12
    movl $143, %ebx
    cmpq $244, %r8
    cmovneq %r12, %rbx
    leal 1(%rsi), %r8d
    cmpq 8(%rax), %r8
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%r8), %r12d
    cmpq %r9, %r12
    jge .Lssa___fern_utf8_step_9
.Lssa___fern_utf8_step_11:
    movl $1, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_9:
    cmpq %rbx, %r12
    jle .Lssa___fern_utf8_step_6
.Lssa___fern_utf8_step_8:
    movl $1, %eax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_6:
.Lssa___fern_utf8_step_5:
    movl $2, %r8d
.Lssa___fern_utf8_step_113:
    cmpq %r10, %r8
    jge .Lssa___fern_utf8_step_4
.Lssa___fern_utf8_step_120:
    leaq (%rsi,%r8), %r9
    movslq %r9d, %r9
    cmpq %rdi, %r9
    jge .Lssa___fern_utf8_step_3
.Lssa___fern_utf8_step_118:
    leal (%rsi,%r8), %r9d
    cmpq 8(%rax), %r9
    jae __fern_str_oob_abort
    movq (%rax), %rdx
    movzbl (%rdx,%r9), %r12d
    cmpq $128, %r12
    jl .Lssa___fern_utf8_step_2
.Lssa___fern_utf8_step_116:
    cmpq $191, %r12
    jg .Lssa___fern_utf8_step_1
.Lssa___fern_utf8_step_114:
    addq $1, %r8
    cmpq %r10, %r8
    jl .Lssa___fern_utf8_step_120
.Lssa___fern_utf8_step_4:
    movq %r10, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_3:
    movq %r8, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_2:
    movq %r8, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_utf8_step_1:
    movq %r8, %rax
    .cfi_remember_state
    leaq -16(%rbp), %rsp
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___fern_str_split:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___fern_str_split.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $136, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa___fern_str_split_0:
    movq 8(%rbx), %r11
    movq %r11, -56(%rbp)
    movq -48(%rbp), %r11
    movq 8(%r11), %r14
    leaq .K0(%rip), %r8
    cmpq $0, %r14
    jne .Lssa___fern_str_split_3
.Lssa___fern_str_split_7:
.Lssa___fern_str_split_6:
    movq %r8, -64(%rbp)
    xorl %r13d, %r13d
.Lssa___fern_str_split_12:
    cmpq -56(%rbp), %r13
    jge .Lssa___fern_str_split_5
.Lssa___fern_str_split_13:
    movq %rbx, %rax
    movq %r13, %rsi
    movq -56(%rbp), %rdi
    call __fn___fern_utf8_step.r
    addq %r13, %rax
    movslq %eax, %r15
    movq %rbx, %rdx
    movq %r13, %rcx
    movq %r15, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -88(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r12
    leaq .SB6(%rip), %rsi
    movq %r12, %rax
    call __fn___fern_str_concat.r
    movq %rax, %r13
    pushq %r12
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq -64(%rbp), %rdi
    movq %r13, %rsi
    movq %r8, -144(%rbp)
    call __fern_arr_push_owned
    movq -144(%rbp), %r8
    movq %rax, -64(%rbp)
    movq %r15, %r13
    cmpq -56(%rbp), %r13
    jl .Lssa___fern_str_split_13
.Lssa___fern_str_split_5:
    movq -64(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_str_split_3:
.Lssa___fern_str_split_2:
    movq %r8, %r13
    xorl %r15d, %r15d
    xorl %r12d, %r12d
.Lssa___fern_str_split_20:
    leaq (%r12,%r14), %r8
    movslq %r8d, %r8
    cmpq -56(%rbp), %r8
    jg .Lssa___fern_str_split_1
.Lssa___fern_str_split_26:
.Lssa___fern_str_split_25:
    xorl %r8d, %r8d
    movl $1, %esi
.Lssa___fern_str_split_31:
    cmpq %r14, %r8
    jge .Lssa___fern_str_split_24
.Lssa___fern_str_split_35:
    leal (%r12,%r8), %edi
    cmpq 8(%rbx), %rdi
    jae __fern_str_oob_abort
    movq (%rbx), %rdx
    movzbl (%rdx,%rdi), %r9d
    movq -48(%rbp), %r11
    movq 0(%r11), %rdi
    movzbl (%rdi,%r8), %r10d
    xorl %edi, %edi
    addq $1, %r8
    cmpq %r10, %r9
    cmovneq %r14, %r8
    cmovneq %rdi, %rsi
    cmpq %r14, %r8
    jl .Lssa___fern_str_split_35
.Lssa___fern_str_split_24:
    cmpq $1, %rsi
    jne .Lssa___fern_str_split_22
.Lssa___fern_str_split_23:
    movq %rbx, %rdx
    movq %r15, %rcx
    movq %r12, %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -112(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r8
    leaq .SB6(%rip), %rsi
    movq %r8, -144(%rbp)
    movq %r8, %rax
    call __fn___fern_str_concat.r
    movq %rax, %r10
    movq -144(%rbp), %r8
    movq %r10, -144(%rbp)
    pushq %r8
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq -144(%rbp), %r10
    movq %r13, %rdi
    movq %r10, %rsi
    call __fern_arr_push_owned
    leaq (%r12,%r14), %r10
    movslq %r10d, %r10
    movq %rax, %r13
    movq %r10, %r15
    movq %r10, %r12
    jmp .Lssa___fern_str_split_20
.Lssa___fern_str_split_22:
    addq $1, %r12
    movslq %r12d, %r12
.Lssa___fern_str_split_21:
    jmp .Lssa___fern_str_split_20
.Lssa___fern_str_split_1:
    movq %rbx, %rdx
    movq %r15, %rcx
    movq -56(%rbp), %rax
    cmpq 8(%rdx), %rax
    ja __fern_str_oob_abort
    cmpq %rax, %rcx
    ja __fern_str_oob_abort
    subq %rcx, %rax
    addq (%rdx), %rcx
    leaq -136(%rbp), %rdx
    movq $-1, (%rdx)
    movq %rcx, 8(%rdx)
    movq %rax, 16(%rdx)
    addq $8, %rdx
    movq %rdx, %r12
    leaq .SB6(%rip), %r10
    movq %r12, %rax
    movq %r10, %rsi
    call __fn___fern_str_concat.r
    movq %rax, %r15
    pushq %r12
    call __fn___fern_str_view_free
    addq $8, %rsp
    movq %r13, %rdi
    movq %r15, %rsi
    call __fern_arr_push_owned
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_str_concat:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___fern_str_concat.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa___fern_str_concat_0:
    movq 8(%rbx), %r13
    movq -48(%rbp), %r11
    movq 8(%r11), %r14
    leaq (%r13,%r14), %rsi
    movslq %esi, %r15
    movq %r15, %rdi
    testl %edi, %edi
    js __fern_alloc_size_abort
    addq $24, %rdi
    call __fern_alloc
    addq $24, %rax
    movq %rax, %r12
    movq 0(%rbx), %rsi
    movq %r13, %rdx
    movq %r12, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movslq %r13d, %r13
    addq %r12, %r13
    movq -48(%rbp), %r11
    movq 0(%r11), %rsi
    movq %r14, %rdx
    movq %r13, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r12, %r11
    movq %r15, %rcx
    movq %r11, %rdi
    movq %rcx, %rsi
    call __fern_str_box_hdr
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_bytes_range:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___fern_bytes_range.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    movq %rsi, %rbx
.Lssa___fern_bytes_range_0:
    testq $2, %rdi
    je .Lssa___fern_bytes_range_10
.Lssa___fern_bytes_range_11:
    leaq -2(%rdi), %rsi
    leaq 8(%rsi), %r8
    movslq (%r8), %r8
    movq 0(%rsi), %r9
    movq %r9, %r12
    movq %r8, %r9
    jmp .Lssa___fern_bytes_range_9
.Lssa___fern_bytes_range_10:
    movslq (%rdi), %r9
    addq $8, %rdi
    movq %rdi, %r12
.Lssa___fern_bytes_range_9:
    cmpq $0, %rbx
    jl .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_8:
    cmpq %rbx, %rax
    jl .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_7:
    cmpq %r9, %rax
    jle .Lssa___fern_bytes_range_4
.Lssa___fern_bytes_range_6:
    call __fern_slice_abort
.Lssa___fern_bytes_range_4:
    subq %rbx, %rax
    movslq %eax, %r13
    cmpq $0, %r13
    jne .Lssa___fern_bytes_range_1
.Lssa___fern_bytes_range_3:
    leaq .K0(%rip), %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_bytes_range_1:
    leaq 7(%r13), %r9
    movslq %r9d, %r9
    movq %r9, %rax
    movl %eax, %ecx
    sarl $31, %ecx
    shrl $29, %ecx
    addl %eax, %ecx
    movl %ecx, %eax
    sarl $3, %eax
    cltq
    movq %rax, %rdi
    call __fern_arr_box
    movq %rax, %r14
    movq %r13, 0(%r14)
    leaq 8(%r14), %rdi
    movslq %ebx, %rbx
    addq %rbx, %r12
    movq %r13, %rdx
    movq %r12, %rsi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq -32(%rbp), %rsp
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fn___fern_bytes_into:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn___fern_bytes_into.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $24, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
    movq %r8, %r13
    movq %r9, %r14
.Lssa___fern_bytes_into_0:
    testq $2, %rdi
    je .Lssa___fern_bytes_into_15
.Lssa___fern_bytes_into_16:
    leaq -2(%rdi), %rsi
    leaq 8(%rsi), %r8
    movslq (%r8), %r8
    movq 0(%rsi), %r9
    movq %r9, -56(%rbp)
    movq %r8, %r9
    jmp .Lssa___fern_bytes_into_14
.Lssa___fern_bytes_into_15:
    movslq (%rdi), %r9
    addq $8, %rdi
    movq %rdi, -56(%rbp)
.Lssa___fern_bytes_into_14:
    movslq (%r14), %r15
    cmpq $0, %rbx
    jl .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_13:
    cmpq $0, %r13
    jl .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_12:
    cmpq $0, -48(%rbp)
    jl .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_11:
    movq %r15, %rdi
    subq %rbx, %rdi
    movslq %edi, %rdi
    cmpq %rdi, %r13
    jg .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_10:
    subq %rbx, %r9
    movslq %r9d, %r9
    cmpq %r9, -48(%rbp)
    jle .Lssa___fern_bytes_into_7
.Lssa___fern_bytes_into_9:
    call __fern_slice_abort
.Lssa___fern_bytes_into_7:
    cmpq $0, %rbx
    jne .Lssa___fern_bytes_into_4
.Lssa___fern_bytes_into_6:
    movq %r14, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___fern_bytes_into_4:
    xorl %ecx, %ecx
    testb $1, %r14b
    jnz .Lssa___fern_bytes_into_rcuniq100
    cmpq $0x10000, %r14
    jb .Lssa___fern_bytes_into_rcuniq100
    movq %r14, %rdx
    andq $-3, %rdx
    movl -8(%rdx), %edx
    cmpl $2129525454, %edx
    je __fern_san_abort_uaf
    cmpl $1, %edx
    jne .Lssa___fern_bytes_into_rcuniq100
    movl $1, %ecx
.Lssa___fern_bytes_into_rcuniq100:
    movq %rcx, %rax
    cmpq $0, %rax
    jne .Lssa___fern_bytes_into_1
.Lssa___fern_bytes_into_3:
    leaq 7(%r15), %r9
    movslq %r9d, %r9
    movq %r9, %rax
    movl %eax, %ecx
    sarl $31, %ecx
    shrl $29, %ecx
    addl %eax, %ecx
    movl %ecx, %eax
    sarl $3, %eax
    cltq
    movq %rax, %rdi
    call __fern_arr_box
    movq %rax, %r12
    movq %r15, 0(%r12)
    leaq 8(%r12), %rdi
    leaq 8(%r14), %r9
    movq %r15, %rdx
    movq %r9, %rsi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    call __fn___fern_arr_dec.r
    movq %r12, %r14
.Lssa___fern_bytes_into_2:
.Lssa___fern_bytes_into_1:
    leaq 8(%r14), %r9
    movslq %r13d, %r13
    addq %r13, %r9
    movq -48(%rbp), %rdi
    movslq %edi, %rdi
    addq -56(%rbp), %rdi
    movq %rbx, %rdx
    movq %rdi, %rsi
    movq %r9, %rdi
    call __fern_memcpy
    pushq $0
    popq %rax
    movq %r14, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
    .text
__fern_slice_abort.c:
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_slice_abort
__fern_alloc_size_abort.c:
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_alloc_size_abort
