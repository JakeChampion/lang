from pathlib import Path
import subprocess,json,hashlib,gzip,collections,io,tarfile
root=Path('/workspace/lang-byte-stream-publish');out=Path('/workspace/scratch/lang-stream-name/os-byte-integration');measured='7fc8e3b0cfd1f4ffe3bd7288e6bd87b63ffa5e15';base='d4478d821';core=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();dest=root/'docs/benchmarks/byte-stream-name-2026-10-24/os-byte-integration'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert core=='7f467b722582594295c3dba4b40824d33b4e476c';base=git('rev-parse',base).decode().strip();assert not git('diff',measured,core,'--','compiler','internal/stdlib','*.go','conformance','spec','site','.github')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['fixedpoint']and boot['source_git']==measured;native=boot['stages'][-1]['sha256'];assert native==boot['stages'][1]['sha256']==hashlib.sha256((out/'bootstrap/stage3').read_bytes()).hexdigest()
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256'];tests=[]
for name,runs,skips,packages in [('native-regressions.jsonl',125,0,1),('go-selected-regressions.jsonl',3378,11,7),('byte-stream-checker.jsonl',2,0,1)]:
 es=[json.loads(s)for s in(out/name).read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);ps=[e for e in es if'Test'not in e and e['Action']in ['pass','fail']];assert c['run']==runs and c['skip']==skips and not c['fail']and len(ps)==packages and all(e['Action']=='pass'for e in ps);tests.append(dict(file=name,runs=runs,passed=c['pass']-packages,skips=skips,packages=packages))
m=json.loads((out/'committed-matrix-results.json').read_text());assert m['core_commit']==measured and len(m['commands'])==76 and not m['failures']and all(r['pass_']for r in m['commands']);cs=[r['census']for r in m['commands']if'census'in r];assert len(cs)==12 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
assert m['binaries'][str(out/'bootstrap/stage3')]['sha256']==native;version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+measured in version and 'vcs.modified=false'in version
assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for n in ['format.log','gofmt.log','vet.log']:assert not(out/n).read_bytes()
legacy=Path('/workspace/scratch/lang-stream-name/current-main-integration/resolve.py').read_text();a=legacy.index('def rename_identifiers');b=legacy.index('\nchanged=',a);ns={};exec(legacy[a:b],ns);mechanical=[]
for row in json.loads(Path('/workspace/scratch/lang-stream-name/current-main-integration/mechanical-renames.json').read_text()):
 n=row['path'];prior=git('show',base+':'+n).decode();actual=(root/n).read_text();expected=ns['rename_identifiers'](prior)
 if n=='conformance/cases/stream_reader/main.fern':
  rendered=subprocess.run([str(out/'oracle'),'-fmt','-'],input=expected.encode(),stdout=subprocess.PIPE,cwd=root,check=True).stdout.decode();assert rendered==actual,n
 else:assert expected==actual,n
 mechanical.append(dict(path=n,before_sha256=hashlib.sha256(prior.encode()).hexdigest(),after_sha256=hashlib.sha256(actual.encode()).hexdigest(),only_bare_stream_identifier_renamed=True,canonical_format_applied=n=='conformance/cases/stream_reader/main.fern'))
(out/'mechanical-type-renames.json').write_text(json.dumps(mechanical,indent=2)+'\n');(out/'source-identity.json').write_text(json.dumps(dict(measured_source=measured,packaged_source=core,dependency_base=base,compiler_go_and_test_inputs_unchanged=True,only_dependency_evidence_changed=True),indent=2)+'\n')
dest.mkdir(parents=True,exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','native-regressions.jsonl','go-selected-regressions.jsonl','byte-stream-checker.jsonl','selected-go-command.json','oracle-version.txt','committed-matrix-results.json','matrix.py','matrix.log','driver-builds.json','driver-sizes.txt','driver-gate.log','sizes.log','check-sizes.py','format.log','gofmt.log','vet.log','source-identity.json','mechanical-type-renames.json','record-proofs.py']:take(n)
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for p in sorted((out/'committed-matrix').glob('*.fern')):
  data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));inputs.append(p.name)
save('formatted-inputs.tar.gz',stream.getvalue());(dest/'artifacts.json').write_text(json.dumps(dict(measured_source=measured,packaged_source=core,dependency_base=base,native_sha256=native,source_sha256=h.hexdigest(),source_files=len(files),tests=tests,matrix_commands=76,balanced_censuses=12,formatted_inputs=len(inputs),patch_excludes=['docs/benchmarks'],artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(artifacts=len(artifacts),native=native,source_files=len(files),mechanical_rename_files=len(mechanical))))
