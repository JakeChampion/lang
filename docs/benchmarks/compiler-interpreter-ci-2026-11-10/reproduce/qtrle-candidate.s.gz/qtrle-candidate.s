    .globl _start
    .text
__fn_frame__VideoError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_frame__VideoError__eq.k:
__fn_frame__VideoError__eq.r:
.Lssa_frame__VideoError__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S0
    add x11, x11, :lo12:.S0
    cmp x10, x11
    b.ne .Lssa_frame__VideoError__eq_30
.Lssa_frame__VideoError__eq_34:
    ldr x11, [x9, #0]
    adrp x12, .S0
    add x12, x12, :lo12:.S0
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_frame__VideoError__eq_30:
    adrp x14, .S1
    add x14, x14, :lo12:.S1
    cmp x10, x14
    b.ne .Lssa_frame__VideoError__eq_25
.Lssa_frame__VideoError__eq_29:
    ldr x14, [x9, #0]
    adrp x13, .S1
    add x13, x13, :lo12:.S1
    mov x12, #1
    mov x11, #0
    cmp x14, x13
    csel x0, x12, x11, eq
    ret
.Lssa_frame__VideoError__eq_25:
    adrp x11, .S2
    add x11, x11, :lo12:.S2
    cmp x10, x11
    b.ne .Lssa_frame__VideoError__eq_20
.Lssa_frame__VideoError__eq_24:
    ldr x11, [x9, #0]
    adrp x12, .S2
    add x12, x12, :lo12:.S2
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_frame__VideoError__eq_20:
    adrp x14, .S3
    add x14, x14, :lo12:.S3
    cmp x10, x14
    b.ne .Lssa_frame__VideoError__eq_15
.Lssa_frame__VideoError__eq_19:
    ldr x14, [x9, #0]
    adrp x13, .S3
    add x13, x13, :lo12:.S3
    mov x12, #1
    mov x11, #0
    cmp x14, x13
    csel x0, x12, x11, eq
    ret
.Lssa_frame__VideoError__eq_15:
    adrp x11, .S4
    add x11, x11, :lo12:.S4
    cmp x10, x11
    b.ne .Lssa_frame__VideoError__eq_10
.Lssa_frame__VideoError__eq_14:
    ldr x11, [x9, #0]
    adrp x12, .S4
    add x12, x12, :lo12:.S4
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_frame__VideoError__eq_10:
    adrp x14, .S5
    add x14, x14, :lo12:.S5
    cmp x10, x14
    b.ne .Lssa_frame__VideoError__eq_4
.Lssa_frame__VideoError__eq_9:
    ldr x14, [x9, #0]
    adrp x10, .S5
    add x10, x10, :lo12:.S5
    mov x13, #1
    mov x12, #0
    cmp x14, x10
    csel x0, x13, x12, eq
    ret
.Lssa_frame__VideoError__eq_4:
    ldr x12, [x9, #0]
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    mov x13, #1
    mov x10, #0
    cmp x12, x9
    csel x0, x13, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn_frame__Format__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_frame__Format__eq.k:
__fn_frame__Format__eq.r:
.Lssa_frame__Format__eq_0:
    ldr x10, [x0, #8]
    ldr x11, [x9, #8]
    cmp x10, x11
    b.ne .Lssa_frame__Format__eq_2
.Lssa_frame__Format__eq_3:
    ldr x11, [x0, #16]
    ldr x10, [x9, #16]
    cmp x11, x10
    cset x0, eq
    b .Lssa_frame__Format__eq_1
.Lssa_frame__Format__eq_2:
    mov x0, #0
.Lssa_frame__Format__eq_1:
    ret
    .cfi_endproc
    .ltorg
__fn_qtrle__decode_span:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_qtrle__decode_span.k:
__fn_qtrle__decode_span.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x10
.Lssa_qtrle__decode_span_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa_qtrle__decode_span_2
.Lssa_qtrle__decode_span_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #0]
    ldr x11, [x9, #8]
    mov x20, x11
    mov x11, x10
    b .Lssa_qtrle__decode_span_51
.Lssa_qtrle__decode_span_2:
    add x11, x0, #8
    cmp x0, #0
    b.eq .Lssa_qtrle__decode_span_5
.Lssa_qtrle__decode_span_4:
    ldr x10, [x0, #0]
    b .Lssa_qtrle__decode_span_6
.Lssa_qtrle__decode_span_5:
    mov x10, #0
.Lssa_qtrle__decode_span_6:
    mov x20, x10
.Lssa_qtrle__decode_span_3:
.Lssa_qtrle__decode_span_51:
    cmp x20, #4
    b.ge .Lssa_qtrle__decode_span_47
.Lssa_qtrle__decode_span_50:
    adrp x10, .K0
    add x10, x10, :lo12:.K0
    mov x9, x10
    b .Lssa_qtrle__decode_span_39
.Lssa_qtrle__decode_span_47:
.Lssa_qtrle__decode_span_46:
    mov x10, #0
    mov x9, #0
.Lssa_qtrle__decode_span_57:
    cmp x9, #4
    b.ge .Lssa_qtrle__decode_span_44
.Lssa_qtrle__decode_span_58:
    lsl x12, x10, #8
    mov w13, w9
    cmp x13, x20
    b.lo .Lssa_qtrle__decode_span_65
.Lssa_qtrle__decode_span_63:
    bl __fern_oob_abort
.Lssa_qtrle__decode_span_65:
    ldrb w14, [x11, x13]
    orr x10, x12, x14
    add x9, x9, #1
    cmp x9, #4
    b.lt .Lssa_qtrle__decode_span_58
.Lssa_qtrle__decode_span_44:
    mov w10, w10
    movz x9, #49152, lsl #16
    and x9, x10, x9
    cmp x9, #0
    b.eq .Lssa_qtrle__decode_span_41
.Lssa_qtrle__decode_span_43:
    adrp x9, .K1
    add x9, x9, :lo12:.K1
    b .Lssa_qtrle__decode_span_39
.Lssa_qtrle__decode_span_41:
    mov w9, w20
    cmp x10, x9
    b.eq .Lssa_qtrle__decode_span_36
.Lssa_qtrle__decode_span_40:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
.Lssa_qtrle__decode_span_39:
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_span_36:
    cmp x20, #8
    b.ge .Lssa_qtrle__decode_span_32
.Lssa_qtrle__decode_span_35:
    mov x21, #0
    mov x22, #0
    mov x0, #4
    bl __fern_arr_box
    adrp x9, .S7
    add x9, x9, :lo12:.S7
    str x9, [x0, #0]
    str x20, [x0, #8]
    str x21, [x0, #16]
    str x22, [x0, #24]
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_span_32:
.Lssa_qtrle__decode_span_31:
    mov x10, #0
    mov x9, #0
.Lssa_qtrle__decode_span_81:
    cmp x9, #2
    b.ge .Lssa_qtrle__decode_span_29
.Lssa_qtrle__decode_span_82:
    lsl x14, x10, #8
    add w12, w9, #4
    cmp x12, x20
    b.lo .Lssa_qtrle__decode_span_89
.Lssa_qtrle__decode_span_87:
    bl __fern_oob_abort
.Lssa_qtrle__decode_span_89:
    ldrb w13, [x11, x12]
    orr x10, x14, x13
    add x9, x9, #1
    cmp x9, #2
    b.lt .Lssa_qtrle__decode_span_82
.Lssa_qtrle__decode_span_29:
    cmp x10, #0
    b.eq .Lssa_qtrle__decode_span_25
.Lssa_qtrle__decode_span_28:
    cmp x10, #8
    b.eq .Lssa_qtrle__decode_span_25
.Lssa_qtrle__decode_span_27:
    adrp x9, .K1
    add x9, x9, :lo12:.K1
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_span_25:
    cmp x10, #0
    b.ne .Lssa_qtrle__decode_span_22
.Lssa_qtrle__decode_span_24:
    mov x22, #6
    mov x21, #0
    mov x0, #4
    bl __fern_arr_box
    adrp x9, .S7
    add x9, x9, :lo12:.S7
    str x9, [x0, #0]
    str x22, [x0, #8]
    str x21, [x0, #16]
    str x19, [x0, #24]
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_span_22:
    cmp x20, #14
    b.ge .Lssa_qtrle__decode_span_18
.Lssa_qtrle__decode_span_21:
    adrp x10, .K0
    add x10, x10, :lo12:.K0
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_span_18:
.Lssa_qtrle__decode_span_17:
    mov x10, #0
    mov x9, #0
.Lssa_qtrle__decode_span_108:
    cmp x9, #2
    b.ge .Lssa_qtrle__decode_span_15
.Lssa_qtrle__decode_span_109:
    lsl x13, x10, #8
    add w14, w9, #6
    cmp x14, x20
    b.lo .Lssa_qtrle__decode_span_116
.Lssa_qtrle__decode_span_114:
    bl __fern_oob_abort
.Lssa_qtrle__decode_span_116:
    ldrb w12, [x11, x14]
    orr x10, x13, x12
    add x9, x9, #1
    cmp x9, #2
    b.lt .Lssa_qtrle__decode_span_109
.Lssa_qtrle__decode_span_15:
    sxtw x21, w10
.Lssa_qtrle__decode_span_14:
.Lssa_qtrle__decode_span_13:
    mov x10, #0
    mov x9, #0
.Lssa_qtrle__decode_span_119:
    cmp x9, #2
    b.ge .Lssa_qtrle__decode_span_11
.Lssa_qtrle__decode_span_120:
    lsl x12, x10, #8
    add w13, w9, #10
    cmp x13, x20
    b.lo .Lssa_qtrle__decode_span_127
.Lssa_qtrle__decode_span_125:
    bl __fern_oob_abort
.Lssa_qtrle__decode_span_127:
    ldrb w14, [x11, x13]
    orr x10, x12, x14
    add x9, x9, #1
    cmp x9, #2
    b.lt .Lssa_qtrle__decode_span_120
.Lssa_qtrle__decode_span_11:
    sxtw x10, w10
    cmp x21, x19
    b.gt .Lssa_qtrle__decode_span_9
.Lssa_qtrle__decode_span_10:
    sub x19, x19, x21
    sxtw x19, w19
    cmp x10, x19
    b.le .Lssa_qtrle__decode_span_7
.Lssa_qtrle__decode_span_9:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_span_7:
    add x10, x21, x10
    sxtw x19, w10
    mov x20, #14
    mov x0, #4
    bl __fern_arr_box
    adrp x10, .S7
    add x10, x10, :lo12:.S7
    str x10, [x0, #0]
    str x20, [x0, #8]
    str x21, [x0, #16]
    str x19, [x0, #24]
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_qtrle__write_run:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
    ldr x13, [sp, #80]
    ldr x14, [sp, #96]
__fn_qtrle__write_run.k:
__fn_qtrle__write_run.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x12
    mov x23, x13
.Lssa_qtrle__write_run_0:
    mov x9, #2
    and x9, x11, x9
    cbz x9, .Lssa_qtrle__write_run_2
.Lssa_qtrle__write_run_1:
    mov x9, #-2
    add x9, x11, x9
    ldr x10, [x9, #0]
    ldr x12, [x9, #8]
    mov x24, x10
    mov x25, x12
    b .Lssa_qtrle__write_run_3
.Lssa_qtrle__write_run_2:
    add x12, x11, #8
    cmp x11, #0
    b.eq .Lssa_qtrle__write_run_5
.Lssa_qtrle__write_run_4:
    ldr x10, [x11, #0]
    b .Lssa_qtrle__write_run_6
.Lssa_qtrle__write_run_5:
    mov x10, #0
.Lssa_qtrle__write_run_6:
    mov x24, x12
    mov x25, x10
.Lssa_qtrle__write_run_3:
    cbz x14, .Lssa_qtrle__write_run_21
.Lssa_qtrle__write_run_26:
    tst x19, #1
    b.ne .Lssa_qtrle__write_run_uq26
    cmp x19, #16, lsl #12
    b.lo .Lssa_qtrle__write_run_uq26
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_qtrle__write_run_uq26:
    b.ne .Lssa_qtrle__write_run_32
.Lssa_qtrle__write_run_31:
    b .Lssa_qtrle__write_run_33
.Lssa_qtrle__write_run_32:
    mov x14, #0
    ldr x10, [x19, #0]
    mov x0, x19
    mov x9, x14
    bl __fn___fern_arr_slice.r
    mov x26, x0
    cmp x19, #16, lsl #12
    b.lo .Lssa_qtrle__write_run_rcdeck144
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__write_run_rcdecd144
    tbnz w5, #31, .Lssa_qtrle__write_run_rcdeck144
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__write_run_rcdece144
.Lssa_qtrle__write_run_rcdecd144:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_qtrle__write_run_rcdeck144:
.Lssa_qtrle__write_run_rcdece144:
    mov x19, x26
.Lssa_qtrle__write_run_33:
.Lssa_qtrle__write_run_25:
    mov x10, #0
.Lssa_qtrle__write_run_34:
    cmp x10, x21
    b.ge .Lssa_qtrle__write_run_24
.Lssa_qtrle__write_run_48:
    add w14, w20, w10
    mul x12, x10, x23
    add x12, x22, x12
.Lssa_qtrle__write_run_47:
    cmp x23, #4
    b.ne .Lssa_qtrle__write_run_40
.Lssa_qtrle__write_run_45:
.Lssa_qtrle__write_run_44:
    mov x11, #0
    mov x9, #0
.Lssa_qtrle__write_run_57:
    cmp x9, #4
    b.ge .Lssa_qtrle__write_run_42
.Lssa_qtrle__write_run_58:
    lsl x13, x11, #8
    add w15, w12, w9
    cmp x15, x25
    b.lo .Lssa_qtrle__write_run_65
.Lssa_qtrle__write_run_63:
    bl __fern_oob_abort
.Lssa_qtrle__write_run_65:
    ldrb w1, [x24, x15]
    orr x11, x13, x1
    add x9, x9, #1
    cmp x9, #4
    b.lt .Lssa_qtrle__write_run_58
.Lssa_qtrle__write_run_42:
    mov w11, w11
    b .Lssa_qtrle__write_run_35
.Lssa_qtrle__write_run_40:
    movz x11, #65280, lsl #16
.Lssa_qtrle__write_run_39:
.Lssa_qtrle__write_run_38:
    mov x9, #0
    mov x1, #0
.Lssa_qtrle__write_run_69:
    cmp x1, #3
    b.ge .Lssa_qtrle__write_run_36
.Lssa_qtrle__write_run_70:
    lsl x13, x9, #8
    add w15, w12, w1
    cmp x15, x25
    b.lo .Lssa_qtrle__write_run_77
.Lssa_qtrle__write_run_75:
    bl __fern_oob_abort
.Lssa_qtrle__write_run_77:
    ldrb w2, [x24, x15]
    orr x9, x13, x2
    add x1, x1, #1
    cmp x1, #3
    b.lt .Lssa_qtrle__write_run_70
.Lssa_qtrle__write_run_36:
    mov w9, w9
    orr x11, x11, x9
.Lssa_qtrle__write_run_35:
    ldr x7, [x19]
    cmp x14, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    str x11, [x19, x5, lsl #3]
    add x10, x10, #1
    cmp x10, x21
    b.lt .Lssa_qtrle__write_run_48
.Lssa_qtrle__write_run_24:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__write_run_21:
    cmp x23, #4
    b.ne .Lssa_qtrle__write_run_14
.Lssa_qtrle__write_run_19:
.Lssa_qtrle__write_run_18:
    mov x10, #0
    mov x9, #0
.Lssa_qtrle__write_run_86:
    cmp x9, #4
    b.ge .Lssa_qtrle__write_run_16
.Lssa_qtrle__write_run_87:
    lsl x11, x10, #8
    add w14, w22, w9
    cmp x14, x25
    b.lo .Lssa_qtrle__write_run_94
.Lssa_qtrle__write_run_92:
    bl __fern_oob_abort
.Lssa_qtrle__write_run_94:
    ldrb w1, [x24, x14]
    orr x10, x11, x1
    add x9, x9, #1
    cmp x9, #4
    b.lt .Lssa_qtrle__write_run_87
.Lssa_qtrle__write_run_16:
    mov w10, w10
    mov x25, x10
    b .Lssa_qtrle__write_run_9
.Lssa_qtrle__write_run_14:
    movz x10, #65280, lsl #16
.Lssa_qtrle__write_run_13:
.Lssa_qtrle__write_run_12:
    mov x9, #0
    mov x1, #0
.Lssa_qtrle__write_run_98:
    cmp x1, #3
    b.ge .Lssa_qtrle__write_run_10
.Lssa_qtrle__write_run_99:
    lsl x11, x9, #8
    add w14, w22, w1
    cmp x14, x25
    b.lo .Lssa_qtrle__write_run_106
.Lssa_qtrle__write_run_104:
    bl __fern_oob_abort
.Lssa_qtrle__write_run_106:
    ldrb w12, [x24, x14]
    orr x9, x11, x12
    add x1, x1, #1
    cmp x1, #3
    b.lt .Lssa_qtrle__write_run_99
.Lssa_qtrle__write_run_10:
    mov w9, w9
    orr x10, x10, x9
    mov x25, x10
.Lssa_qtrle__write_run_9:
.Lssa_qtrle__write_run_8:
    mov x24, #0
.Lssa_qtrle__write_run_109:
    cmp x24, x21
    b.ge .Lssa_qtrle__write_run_7
.Lssa_qtrle__write_run_110:
    add w22, w20, w24
    tst x19, #1
    b.ne .Lssa_qtrle__write_run_uq110
    cmp x19, #16, lsl #12
    b.lo .Lssa_qtrle__write_run_uq110
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_qtrle__write_run_uq110:
    b.ne .Lssa_qtrle__write_run_116
.Lssa_qtrle__write_run_115:
    b .Lssa_qtrle__write_run_117
.Lssa_qtrle__write_run_116:
    cmp x19, #16, lsl #12
    b.lo .Lssa_qtrle__write_run_rcdeck329
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__write_run_rcdecd329
    tbnz w5, #31, .Lssa_qtrle__write_run_rcdeck329
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__write_run_rcdece329
.Lssa_qtrle__write_run_rcdecd329:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_qtrle__write_run_rcdeck329:
.Lssa_qtrle__write_run_rcdece329:
    mov x10, #0
    ldr x9, [x19, #0]
    mov x0, x19
    mov x4, x10
    mov x10, x9
    mov x9, x4
    bl __fn___fern_arr_slice.r
    mov x19, x0
.Lssa_qtrle__write_run_117:
    ldr x7, [x19]
    cmp x22, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    str x25, [x19, x5, lsl #3]
    add x24, x24, #1
    cmp x24, x21
    b.lt .Lssa_qtrle__write_run_110
.Lssa_qtrle__write_run_7:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_qtrle__decode_row:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
    ldr x13, [sp, #80]
    ldr x14, [sp, #96]
__fn_qtrle__decode_row.k:
__fn_qtrle__decode_row.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #80
    mov x19, x0
    str x10, [sp, #72]
    mov x21, x11
    mov x22, x13
    mov x23, x14
.Lssa_qtrle__decode_row_0:
    mov x12, #2
    and x12, x19, x12
    cbz x12, .Lssa_qtrle__decode_row_2
.Lssa_qtrle__decode_row_1:
    mov x12, #-2
    add x12, x19, x12
    ldr x10, [x12, #0]
    ldr x11, [x12, #8]
    mov x24, x10
    mov x25, x11
    b .Lssa_qtrle__decode_row_3
.Lssa_qtrle__decode_row_2:
    add x11, x19, #8
    cmp x19, #0
    b.eq .Lssa_qtrle__decode_row_5
.Lssa_qtrle__decode_row_4:
    ldr x10, [x19, #0]
    b .Lssa_qtrle__decode_row_6
.Lssa_qtrle__decode_row_5:
    mov x10, #0
.Lssa_qtrle__decode_row_6:
    mov x24, x11
    mov x25, x10
.Lssa_qtrle__decode_row_3:
    cmp x9, x25
    b.ne .Lssa_qtrle__decode_row_23
.Lssa_qtrle__decode_row_26:
    cmp x23, #16, lsl #12
    b.lo .Lssa_qtrle__decode_row_rcdeck154
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_row_rcdecd154
    tbnz w5, #31, .Lssa_qtrle__decode_row_rcdeck154
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_row_rcdece154
.Lssa_qtrle__decode_row_rcdecd154:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_qtrle__decode_row_rcdeck154:
.Lssa_qtrle__decode_row_rcdece154:
.Lssa_qtrle__decode_row_25:
    adrp x10, .K0
    add x10, x10, :lo12:.K0
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_row_23:
    mov w10, w9
    cmp x10, x25
    b.lo .Lssa_qtrle__decode_row_32
.Lssa_qtrle__decode_row_30:
    bl __fern_oob_abort
.Lssa_qtrle__decode_row_32:
    ldrb w11, [x24, x10]
    add x9, x9, #1
    sxtw x26, w9
    cmp x11, #0
    b.ne .Lssa_qtrle__decode_row_17
.Lssa_qtrle__decode_row_22:
    cmp x26, x25
    b.eq .Lssa_qtrle__decode_row_19
.Lssa_qtrle__decode_row_37:
    cmp x23, #16, lsl #12
    b.lo .Lssa_qtrle__decode_row_rcdeck168
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_row_rcdecd168
    tbnz w5, #31, .Lssa_qtrle__decode_row_rcdeck168
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_row_rcdece168
.Lssa_qtrle__decode_row_rcdecd168:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_qtrle__decode_row_rcdeck168:
.Lssa_qtrle__decode_row_rcdece168:
.Lssa_qtrle__decode_row_21:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_row_19:
    mov x27, #1
    mov x0, #4
    bl __fern_arr_box
    adrp x9, .S8
    add x9, x9, :lo12:.S8
    str x9, [x0, #0]
    str x23, [x0, #8]
    str x26, [x0, #16]
    str x27, [x0, #24]
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_row_17:
    sub x11, x11, #1
    sxtw x11, w11
    cmp x11, x21
    b.le .Lssa_qtrle__decode_row_14
.Lssa_qtrle__decode_row_41:
    cmp x23, #16, lsl #12
    b.lo .Lssa_qtrle__decode_row_rcdeck185
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_row_rcdecd185
    tbnz w5, #31, .Lssa_qtrle__decode_row_rcdeck185
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_row_rcdece185
.Lssa_qtrle__decode_row_rcdecd185:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_qtrle__decode_row_rcdeck185:
.Lssa_qtrle__decode_row_rcdece185:
.Lssa_qtrle__decode_row_16:
    adrp x10, .K2
    add x10, x10, :lo12:.K2
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_row_14:
    mov x27, x11
.Lssa_qtrle__decode_row_45:
.Lssa_qtrle__decode_row_85:
    cmp x26, x25
    b.ne .Lssa_qtrle__decode_row_83
.Lssa_qtrle__decode_row_86:
    cmp x23, #16, lsl #12
    b.lo .Lssa_qtrle__decode_row_rcdeck213
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_row_rcdecd213
    tbnz w5, #31, .Lssa_qtrle__decode_row_rcdeck213
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_row_rcdece213
.Lssa_qtrle__decode_row_rcdecd213:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_qtrle__decode_row_rcdeck213:
.Lssa_qtrle__decode_row_rcdece213:
    b .Lssa_qtrle__decode_row_13
.Lssa_qtrle__decode_row_83:
    mov w10, w26
    cmp x10, x25
    b.lo .Lssa_qtrle__decode_row_92
.Lssa_qtrle__decode_row_90:
    bl __fern_oob_abort
.Lssa_qtrle__decode_row_92:
    ldrb w28, [x24, x10]
    add x26, x26, #1
    sxtw x26, w26
    cmp x28, #255
    b.eq .Lssa_qtrle__decode_row_12
.Lssa_qtrle__decode_row_81:
    sub x10, x21, x27
    sxtw x10, w10
.Lssa_qtrle__decode_row_80:
    cmp x28, #0
    b.ne .Lssa_qtrle__decode_row_70
.Lssa_qtrle__decode_row_79:
    cmp x26, x25
    b.ne .Lssa_qtrle__decode_row_76
.Lssa_qtrle__decode_row_78:
    mov x11, #-1
    mov x20, x11
    b .Lssa_qtrle__decode_row_58
.Lssa_qtrle__decode_row_76:
    mov w11, w26
    cmp x11, x25
    b.lo .Lssa_qtrle__decode_row_108
.Lssa_qtrle__decode_row_106:
    bl __fern_oob_abort
.Lssa_qtrle__decode_row_108:
    ldrb w9, [x24, x11]
    sub x9, x9, #1
    sxtw x9, w9
    cmp x9, #0
    b.lt .Lssa_qtrle__decode_row_74
.Lssa_qtrle__decode_row_75:
    cmp x9, x10
    b.le .Lssa_qtrle__decode_row_72
.Lssa_qtrle__decode_row_74:
    mov x9, #-2
    mov x20, x9
    b .Lssa_qtrle__decode_row_58
.Lssa_qtrle__decode_row_72:
    mov x20, #1
    b .Lssa_qtrle__decode_row_58
.Lssa_qtrle__decode_row_70:
    mov x9, #256
    sub x9, x9, x28
    sxtw x9, w9
    cmp x28, #128
    csel x9, x28, x9, lt
    mul x11, x9, x22
    sxtw x11, w11
    cmp x28, #128
    csel x11, x11, x22, lt
    cmp x9, x10
    b.le .Lssa_qtrle__decode_row_61
.Lssa_qtrle__decode_row_63:
    mov x9, #-2
    mov x20, x9
    b .Lssa_qtrle__decode_row_58
.Lssa_qtrle__decode_row_61:
    sub x9, x25, x26
    sxtw x9, w9
    cmp x11, x9
    b.le .Lssa_qtrle__decode_row_59
.Lssa_qtrle__decode_row_60:
    mov x9, #-1
    mov x20, x9
    b .Lssa_qtrle__decode_row_58
.Lssa_qtrle__decode_row_59:
    mov x20, x11
.Lssa_qtrle__decode_row_58:
    cmp x20, #0
    b.ge .Lssa_qtrle__decode_row_55
.Lssa_qtrle__decode_row_139:
    cmp x23, #16, lsl #12
    b.lo .Lssa_qtrle__decode_row_rcdeck268
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_row_rcdecd268
    tbnz w5, #31, .Lssa_qtrle__decode_row_rcdeck268
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_row_rcdece268
.Lssa_qtrle__decode_row_rcdecd268:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_qtrle__decode_row_rcdeck268:
.Lssa_qtrle__decode_row_rcdece268:
    b .Lssa_qtrle__decode_row_10
.Lssa_qtrle__decode_row_55:
    cmp x28, #0
    b.ne .Lssa_qtrle__decode_row_52
.Lssa_qtrle__decode_row_54:
    mov w9, w26
    cmp x9, x25
    b.lo .Lssa_qtrle__decode_row_149
.Lssa_qtrle__decode_row_147:
    bl __fern_oob_abort
.Lssa_qtrle__decode_row_149:
    ldrb w11, [x24, x9]
    sub x11, x11, #1
    sxtw x10, w11
    b .Lssa_qtrle__decode_row_49
.Lssa_qtrle__decode_row_52:
    cmp x28, #128
    b.ge .Lssa_qtrle__decode_row_50
.Lssa_qtrle__decode_row_51:
    mov x10, x28
    b .Lssa_qtrle__decode_row_49
.Lssa_qtrle__decode_row_50:
    mov x10, #256
    sub x10, x10, x28
    sxtw x10, w10
.Lssa_qtrle__decode_row_49:
    cmp x28, #0
    b.eq .Lssa_qtrle__decode_row_46
.Lssa_qtrle__decode_row_48:
    ldr x4, [sp, #72]
    mul x11, x4, x21
    add x11, x11, x27
    sxtw x9, w11
    cmp x28, #128
    cset x14, lt
    str x10, [sp, #64]
    mov x0, x23
    mov x11, x19
    mov x12, x26
    mov x13, x22
    bl __fn_qtrle__write_run.r
    ldr x10, [sp, #64]
    mov x23, x0
.Lssa_qtrle__decode_row_47:
.Lssa_qtrle__decode_row_46:
    add x14, x26, x20
    sxtw x26, w14
    add x27, x27, x10
    b .Lssa_qtrle__decode_row_85
.Lssa_qtrle__decode_row_13:
    adrp x10, .K0
    add x10, x10, :lo12:.K0
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_row_12:
    mov x27, #0
    mov x0, #4
    bl __fern_arr_box
    adrp x10, .S8
    add x10, x10, :lo12:.S8
    str x10, [x0, #0]
    str x23, [x0, #8]
    str x26, [x0, #16]
    str x27, [x0, #24]
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_row_10:
    mov x14, #-1
    cmp x20, x14
    b.ne .Lssa_qtrle__decode_row_8
.Lssa_qtrle__decode_row_9:
    adrp x14, .K0
    add x14, x14, :lo12:.K0
    b .Lssa_qtrle__decode_row_7
.Lssa_qtrle__decode_row_8:
    adrp x14, .K2
    add x14, x14, :lo12:.K2
.Lssa_qtrle__decode_row_7:
    mov x1, x14
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_qtrle__decode_into:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
    ldr x13, [sp, #80]
__fn_qtrle__decode_into.k:
__fn_qtrle__decode_into.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #80
    mov x19, x0
    mov x20, x11
.Lssa_qtrle__decode_into_0:
    mov x11, #2
    and x11, x19, x11
    cbz x11, .Lssa_qtrle__decode_into_2
.Lssa_qtrle__decode_into_1:
    mov x11, #-2
    add x11, x19, x11
    ldr x14, [x11, #0]
    ldr x15, [x11, #8]
    str x14, [sp, #72]
    mov x22, x15
    b .Lssa_qtrle__decode_into_63
.Lssa_qtrle__decode_into_2:
    add x15, x19, #8
    cmp x19, #0
    b.eq .Lssa_qtrle__decode_into_5
.Lssa_qtrle__decode_into_4:
    ldr x14, [x19, #0]
    b .Lssa_qtrle__decode_into_6
.Lssa_qtrle__decode_into_5:
    mov x14, #0
.Lssa_qtrle__decode_into_6:
    str x15, [sp, #72]
    mov x22, x14
.Lssa_qtrle__decode_into_3:
.Lssa_qtrle__decode_into_63:
    cmp x12, #0
    b.ge .Lssa_qtrle__decode_into_62
.Lssa_qtrle__decode_into_64:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck244
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd244
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck244
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece244
.Lssa_qtrle__decode_into_rcdecd244:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck244:
.Lssa_qtrle__decode_into_rcdece244:
    b .Lssa_qtrle__decode_into_61
.Lssa_qtrle__decode_into_62:
    cmp x13, #0
    b.ge .Lssa_qtrle__decode_into_60
.Lssa_qtrle__decode_into_68:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck247
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd247
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck247
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece247
.Lssa_qtrle__decode_into_rcdecd247:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck247:
.Lssa_qtrle__decode_into_rcdece247:
.Lssa_qtrle__decode_into_61:
    mov x14, #134
    mov x0, x14
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_60:
    cmp x22, x13
    b.le .Lssa_qtrle__decode_into_54
.Lssa_qtrle__decode_into_72:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck253
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd253
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck253
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece253
.Lssa_qtrle__decode_into_rcdecd253:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck253:
.Lssa_qtrle__decode_into_rcdece253:
.Lssa_qtrle__decode_into_59:
    adrp x14, .K3
    add x14, x14, :lo12:.K3
.Lssa_qtrle__decode_into_58:
    mov x1, x14
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_54:
    ldr x23, [x9, #8]
    cmp x23, #0
    b.gt .Lssa_qtrle__decode_into_53
.Lssa_qtrle__decode_into_76:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck260
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd260
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck260
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece260
.Lssa_qtrle__decode_into_rcdecd260:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck260:
.Lssa_qtrle__decode_into_rcdece260:
    b .Lssa_qtrle__decode_into_52
.Lssa_qtrle__decode_into_53:
    ldr x24, [x9, #16]
    cmp x24, #0
    b.gt .Lssa_qtrle__decode_into_50
.Lssa_qtrle__decode_into_80:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck264
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd264
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck264
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece264
.Lssa_qtrle__decode_into_rcdecd264:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck264:
.Lssa_qtrle__decode_into_rcdece264:
.Lssa_qtrle__decode_into_52:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    b .Lssa_qtrle__decode_into_36
.Lssa_qtrle__decode_into_50:
    cmp x12, #0
    b.ge .Lssa_qtrle__decode_into_49
.Lssa_qtrle__decode_into_85:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck269
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd269
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck269
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece269
.Lssa_qtrle__decode_into_rcdecd269:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck269:
.Lssa_qtrle__decode_into_rcdece269:
    b .Lssa_qtrle__decode_into_48
.Lssa_qtrle__decode_into_49:
    cmp x13, #0
    b.ge .Lssa_qtrle__decode_into_46
.Lssa_qtrle__decode_into_89:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck272
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd272
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck272
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece272
.Lssa_qtrle__decode_into_rcdecd272:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck272:
.Lssa_qtrle__decode_into_rcdece272:
.Lssa_qtrle__decode_into_48:
    mov x9, #134
    mov x0, x9
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_46:
    cmp x23, #0
    cset x9, ne
    mul x13, x23, x24
    sxtw x13, w13
    mov x4, x13
    mov x5, x23
    sdiv x4, x4, x5
    sxtw x4, w4
    mov x14, x4
    cmp x14, x24
    cset x14, ne
    mov x13, #-1
    cmp x23, x13
    cset x13, eq
    ldr x15, =-2147483648
    cmp x24, x15
    cset x15, eq
    and x13, x13, x15
    orr x14, x14, x13
    and x9, x9, x14
    mul x14, x23, x24
    sxtw x14, w14
    mov x13, #0
    cmp x9, #0
    cset x9, eq
    cmp x9, #0
    csel x14, x14, x13, ne
    cbnz x9, .Lssa_qtrle__decode_into_45
.Lssa_qtrle__decode_into_97:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck295
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd295
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck295
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece295
.Lssa_qtrle__decode_into_rcdecd295:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck295:
.Lssa_qtrle__decode_into_rcdece295:
    b .Lssa_qtrle__decode_into_37
.Lssa_qtrle__decode_into_45:
    cmp x14, x12
    b.le .Lssa_qtrle__decode_into_44
.Lssa_qtrle__decode_into_100:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck297
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd297
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck297
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece297
.Lssa_qtrle__decode_into_rcdecd297:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck297:
.Lssa_qtrle__decode_into_rcdece297:
    b .Lssa_qtrle__decode_into_43
.Lssa_qtrle__decode_into_44:
    movn w9, #61440, lsl #16
    cmp x14, x9
    b.le .Lssa_qtrle__decode_into_40
.Lssa_qtrle__decode_into_104:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck300
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd300
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck300
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece300
.Lssa_qtrle__decode_into_rcdecd300:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck300:
.Lssa_qtrle__decode_into_rcdece300:
.Lssa_qtrle__decode_into_43:
    adrp x9, .K3
    add x9, x9, :lo12:.K3
    b .Lssa_qtrle__decode_into_36
.Lssa_qtrle__decode_into_40:
    cmp x10, #24
    b.ne .Lssa_qtrle__decode_into_34
.Lssa_qtrle__decode_into_39:
    mov x25, #3
    b .Lssa_qtrle__decode_into_32
.Lssa_qtrle__decode_into_37:
    adrp x9, .K3
    add x9, x9, :lo12:.K3
.Lssa_qtrle__decode_into_36:
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_34:
    cmp x10, #32
    b.eq .Lssa_qtrle__decode_into_33
.Lssa_qtrle__decode_into_115:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck313
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd313
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck313
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece313
.Lssa_qtrle__decode_into_rcdecd313:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck313:
.Lssa_qtrle__decode_into_rcdece313:
    b .Lssa_qtrle__decode_into_19
.Lssa_qtrle__decode_into_33:
    mov x25, #4
.Lssa_qtrle__decode_into_32:
    ldr x9, [x20, #0]
    cmp x9, x14
    b.eq .Lssa_qtrle__decode_into_29
.Lssa_qtrle__decode_into_118:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck318
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd318
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck318
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece318
.Lssa_qtrle__decode_into_rcdecd318:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck318:
.Lssa_qtrle__decode_into_rcdece318:
.Lssa_qtrle__decode_into_31:
    adrp x9, .K4
    add x9, x9, :lo12:.K4
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_29:
    mov x0, x19
    mov x9, x23
    mov x10, x24
    bl __fn_qtrle__decode_span.r
    mov x26, x0
    mov x27, x1
    cmp x26, #0
    b.eq .Lssa_qtrle__decode_into_27
.Lssa_qtrle__decode_into_123:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck326
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd326
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck326
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece326
.Lssa_qtrle__decode_into_rcdecd326:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck326:
.Lssa_qtrle__decode_into_rcdece326:
    b .Lssa_qtrle__decode_into_9
.Lssa_qtrle__decode_into_27:
    ldr x9, [x27, #8]
    ldr x10, [x27, #16]
.Lssa_qtrle__decode_into_26:
    mov x26, x9
    mov x28, x10
.Lssa_qtrle__decode_into_126:
    ldr x10, [x27, #24]
    cmp x28, x10
    b.lt .Lssa_qtrle__decode_into_131
.Lssa_qtrle__decode_into_133:
    cmp x27, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck343
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd343
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck343
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece343
.Lssa_qtrle__decode_into_rcdecd343:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_qtrle__decode_into_rcdeck343:
.Lssa_qtrle__decode_into_rcdece343:
    b .Lssa_qtrle__decode_into_24
.Lssa_qtrle__decode_into_131:
    mov x0, x19
    mov x9, x26
    mov x10, x28
    mov x11, x23
    mov x12, x24
    mov x13, x25
    mov x14, x20
    bl __fn_qtrle__decode_row.r
    mov x21, x0
    mov x10, x1
    cmp x21, #0
    b.eq .Lssa_qtrle__decode_into_129
.Lssa_qtrle__decode_into_137:
    cmp x27, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck348
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd348
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck348
    str x10, [sp, #64]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x10, [sp, #64]
    b .Lssa_qtrle__decode_into_rcdece348
.Lssa_qtrle__decode_into_rcdecd348:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_qtrle__decode_into_rcdeck348:
.Lssa_qtrle__decode_into_rcdece348:
    b .Lssa_qtrle__decode_into_7
.Lssa_qtrle__decode_into_129:
    tst x10, #1
    b.ne .Lssa_qtrle__decode_into_uq129
    cmp x10, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_uq129
    ldur w5, [x10, #-8]
    cmp w5, #1
.Lssa_qtrle__decode_into_uq129:
    b.ne .Lssa_qtrle__decode_into_141
.Lssa_qtrle__decode_into_140:
    mov x9, x10
    b .Lssa_qtrle__decode_into_142
.Lssa_qtrle__decode_into_141:
    mov x9, #0
.Lssa_qtrle__decode_into_142:
    ldr x20, [x10, #8]
    cmp x9, #0
    b.ne .Lssa_qtrle__decode_into_145
.Lssa_qtrle__decode_into_143:
    tbnz x20, #0, .Lssa_qtrle__decode_into_rcinc355
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcinc355
    ldur w5, [x20, #-8]
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcinc355
    add w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcinc355:
.Lssa_qtrle__decode_into_145:
    ldr x26, [x10, #16]
    ldr x21, [x10, #24]
    cmp x9, #0
    b.eq .Lssa_qtrle__decode_into_147
.Lssa_qtrle__decode_into_146:
    mov x9, x10
    b .Lssa_qtrle__decode_into_148
.Lssa_qtrle__decode_into_147:
    str x10, [sp, #64]
    mov x0, x10
    bl __fn___sem_release_qtrle__Row.r
    ldr x10, [sp, #64]
    mov x9, #0
.Lssa_qtrle__decode_into_148:
    cbz x21, .Lssa_qtrle__decode_into_150
.Lssa_qtrle__decode_into_149:
    cmp x27, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck363
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd363
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck363
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    b .Lssa_qtrle__decode_into_rcdece363
.Lssa_qtrle__decode_into_rcdecd363:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_qtrle__decode_into_rcdeck363:
.Lssa_qtrle__decode_into_rcdece363:
    b .Lssa_qtrle__decode_into_21
.Lssa_qtrle__decode_into_150:
    cmp x9, #0
    b.eq .Lssa_qtrle__decode_into_127
.Lssa_qtrle__decode_into_153:
    cmp x9, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck366
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd366
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck366
    str x9, [sp, #64]
    str x10, [sp, #56]
    mov x0, x9
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #64]
    ldr x10, [sp, #56]
    b .Lssa_qtrle__decode_into_rcdece366
.Lssa_qtrle__decode_into_rcdecd366:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_qtrle__decode_into_rcdeck366:
.Lssa_qtrle__decode_into_rcdece366:
.Lssa_qtrle__decode_into_127:
    add x28, x28, #1
    b .Lssa_qtrle__decode_into_126
.Lssa_qtrle__decode_into_24:
    cmp x26, x22
    b.ge .Lssa_qtrle__decode_into_16
.Lssa_qtrle__decode_into_23:
    mov w14, w26
    cmp x14, x22
    b.lo .Lssa_qtrle__decode_into_164
.Lssa_qtrle__decode_into_162:
    bl __fern_oob_abort
.Lssa_qtrle__decode_into_164:
    ldr x4, [sp, #72]
    ldrb w13, [x4, x14]
    cmp x13, #0
    b.ne .Lssa_qtrle__decode_into_16
.Lssa_qtrle__decode_into_22:
    add x13, x26, #1
    mov x26, x13
    b .Lssa_qtrle__decode_into_16
.Lssa_qtrle__decode_into_21:
    mov x13, #4
    str x9, [sp, #-16]!
    str x13, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x13, .S9
    add x13, x13, :lo12:.S9
    str x13, [x0, #0]
    str x23, [x0, #8]
    str x24, [x0, #16]
    str x20, [x0, #24]
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_19:
    adrp x9, .K1
    add x9, x9, :lo12:.K1
.Lssa_qtrle__decode_into_18:
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_17:
.Lssa_qtrle__decode_into_16:
    cmp x26, x22
    b.eq .Lssa_qtrle__decode_into_11
.Lssa_qtrle__decode_into_170:
    cmp x20, #16, lsl #12
    b.lo .Lssa_qtrle__decode_into_rcdeck395
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_qtrle__decode_into_rcdecd395
    tbnz w5, #31, .Lssa_qtrle__decode_into_rcdeck395
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_qtrle__decode_into_rcdece395
.Lssa_qtrle__decode_into_rcdecd395:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_qtrle__decode_into_rcdeck395:
.Lssa_qtrle__decode_into_rcdece395:
.Lssa_qtrle__decode_into_15:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
.Lssa_qtrle__decode_into_14:
    mov x1, x9
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_11:
    mov x0, #4
    bl __fern_arr_box
    adrp x9, .S9
    add x9, x9, :lo12:.S9
    str x9, [x0, #0]
    str x23, [x0, #8]
    str x24, [x0, #16]
    str x20, [x0, #24]
    mov x1, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_9:
    mov x1, x27
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_qtrle__decode_into_7:
    mov x1, x10
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___primitive_i64_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_i64_to_string.k:
__fn___primitive_i64_to_string.r:
.Lssa___primitive_i64_to_string_0:
    cmp x0, #0
    b.ge .Lssa___primitive_i64_to_string_1
.Lssa___primitive_i64_to_string_3:
    mov x9, #0
    sub x9, x9, x0
    mov x10, #1
    mov x0, x9
    mov x9, x10
    b __fn_int____int_to_string_u64.r
.Lssa___primitive_i64_to_string_1:
    mov x9, #0
    b __fn_int____int_to_string_u64.r
    .cfi_endproc
    .ltorg
__fn___primitive_u64_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_u64_to_string.k:
__fn___primitive_u64_to_string.r:
.Lssa___primitive_u64_to_string_0:
    mov x9, #0
    b __fn_int____int_to_string_u64.r
    .cfi_endproc
    .ltorg
__fn___primitive_string_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_string_to_string.k:
__fn___primitive_string_to_string.r:
.Lssa___primitive_string_to_string_0:
    tbnz x0, #0, .Lssa___primitive_string_to_string_rcinc1
    cmp x0, #16, lsl #12
    b.lo .Lssa___primitive_string_to_string_rcinc1
    ldur w5, [x0, #-8]
    tbnz w5, #31, .Lssa___primitive_string_to_string_rcinc1
    add w5, w5, #1
    stur w5, [x0, #-8]
.Lssa___primitive_string_to_string_rcinc1:
    ret
    .cfi_endproc
    .ltorg
__fn_i64__to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_i64__to_string.k:
__fn_i64__to_string.r:
.Lssa_i64__to_string_0:
    cmp x0, #0
    b.ge .Lssa_i64__to_string_1
.Lssa_i64__to_string_3:
    mov x9, #0
    sub x9, x9, x0
    mov x10, #1
    mov x0, x9
    mov x9, x10
    b __fn_int____int_to_string_u64.r
.Lssa_i64__to_string_1:
    mov x9, #0
    b __fn_int____int_to_string_u64.r
    .cfi_endproc
    .ltorg
__fn_codec__DecodeErrorKind__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeErrorKind__eq.k:
__fn_codec__DecodeErrorKind__eq.r:
.Lssa_codec__DecodeErrorKind__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S10
    add x11, x11, :lo12:.S10
    cmp x10, x11
    b.ne .Lssa_codec__DecodeErrorKind__eq_15
.Lssa_codec__DecodeErrorKind__eq_19:
    ldr x11, [x0, #8]
    ldr x12, [x9, #0]
    adrp x13, .S10
    add x13, x13, :lo12:.S10
    cmp x12, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_16
.Lssa_codec__DecodeErrorKind__eq_18:
    ldr x13, [x9, #8]
    cmp x11, x13
    cset x0, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_16:
    mov x0, #0
    ret
.Lssa_codec__DecodeErrorKind__eq_15:
    adrp x13, .S11
    add x13, x13, :lo12:.S11
    cmp x10, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_10
.Lssa_codec__DecodeErrorKind__eq_14:
    ldr x13, [x9, #0]
    adrp x11, .S11
    add x11, x11, :lo12:.S11
    mov x12, #1
    mov x14, #0
    cmp x13, x11
    csel x0, x12, x14, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_10:
    adrp x14, .S12
    add x14, x14, :lo12:.S12
    cmp x10, x14
    b.ne .Lssa_codec__DecodeErrorKind__eq_4
.Lssa_codec__DecodeErrorKind__eq_9:
    ldr x14, [x9, #0]
    adrp x10, .S12
    add x10, x10, :lo12:.S12
    mov x12, #1
    mov x11, #0
    cmp x14, x10
    csel x0, x12, x11, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_4:
    ldr x11, [x9, #0]
    adrp x9, .S13
    add x9, x9, :lo12:.S13
    mov x12, #1
    mov x10, #0
    cmp x11, x9
    csel x0, x12, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeError__eq.k:
__fn_codec__DecodeError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_codec__DecodeError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_codec__DecodeError__eq_streqn36
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_codec__DecodeError__eq_streqd36
.Lssa_codec__DecodeError__eq_streqn36:
    mov x0, #0
.Lssa_codec__DecodeError__eq_streqd36:
    cbz x0, .Lssa_codec__DecodeError__eq_19
.Lssa_codec__DecodeError__eq_26:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_codec__DecodeError__eq_19
.Lssa_codec__DecodeError__eq_23:
    ldr x9, [x19, #24]
    ldr x10, [x20, #24]
.Lssa_codec__DecodeError__eq_22:
    ldr x11, [x9, #0]
    adrp x12, .S10
    add x12, x12, :lo12:.S10
    cmp x11, x12
    b.ne .Lssa_codec__DecodeError__eq_16
.Lssa_codec__DecodeError__eq_21:
    ldr x12, [x9, #8]
    ldr x9, [x10, #0]
    adrp x13, .S10
    add x13, x13, :lo12:.S10
    cmp x9, x13
    b.ne .Lssa_codec__DecodeError__eq_17
.Lssa_codec__DecodeError__eq_20:
    ldr x13, [x10, #8]
    cmp x12, x13
    cset x0, eq
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_19:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_17:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_16:
    adrp x13, .S11
    add x13, x13, :lo12:.S11
    cmp x11, x13
    b.ne .Lssa_codec__DecodeError__eq_11
.Lssa_codec__DecodeError__eq_15:
    ldr x13, [x10, #0]
    adrp x12, .S11
    add x12, x12, :lo12:.S11
    cmp x13, x12
    b.ne .Lssa_codec__DecodeError__eq_12
.Lssa_codec__DecodeError__eq_14:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_12:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_11:
    adrp x12, .S12
    add x12, x12, :lo12:.S12
    cmp x11, x12
    b.ne .Lssa_codec__DecodeError__eq_5
.Lssa_codec__DecodeError__eq_10:
    ldr x12, [x10, #0]
    adrp x11, .S12
    add x11, x11, :lo12:.S12
    cmp x12, x11
    b.ne .Lssa_codec__DecodeError__eq_7
.Lssa_codec__DecodeError__eq_9:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_7:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_5:
    ldr x11, [x10, #0]
    adrp x10, .S13
    add x10, x10, :lo12:.S13
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_2
.Lssa_codec__DecodeError__eq_4:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_2:
    mov x0, #0
.Lssa_codec__DecodeError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_int____int_to_string_u64:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_int____int_to_string_u64.k:
__fn_int____int_to_string_u64.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_int____int_to_string_u64_0:
.Lssa_int____int_to_string_u64_16:
    mov x10, x19
    mov x9, #1
.Lssa_int____int_to_string_u64_17:
    cmp x10, #100
    b.lo .Lssa_int____int_to_string_u64_15
.Lssa_int____int_to_string_u64_18:
    add x11, x9, #2
    sxtw x9, w11
    mov x4, x10
    ldr x5, =2951479051793528259
    lsr x6, x4, #2
    umulh x5, x6, x5
    lsr x5, x5, #2
    mov x4, x5
    mov x10, x4
    cmp x10, #100
    b.hs .Lssa_int____int_to_string_u64_18
.Lssa_int____int_to_string_u64_15:
    add x11, x9, #1
    sxtw x11, w11
    cmp x10, #10
    csel x11, x11, x9, hs
    add x9, x11, #1
    sxtw x9, w9
    cmp x20, #0
    csel x21, x9, x11, ne
    mov x0, x21
    bl __fern_alloc_bytes
    mov x22, x0
    adrp x9, .SB14
    add x9, x9, :lo12:.SB14
.Lssa_int____int_to_string_u64_8:
.Lssa_int____int_to_string_u64_35:
    cmp x19, #100
    b.lo .Lssa_int____int_to_string_u64_7
.Lssa_int____int_to_string_u64_36:
    mov x4, x19
    ldr x5, =2951479051793528259
    lsr x6, x4, #2
    umulh x5, x6, x5
    lsr x5, x5, #2
    mov x4, x5
    mov x11, x4
    mov x10, #100
    mul x10, x11, x10
    sub x10, x19, x10
    sub x12, x21, #2
    sxtw x21, w12
    lsl x10, x10, #1
    sxtw x10, w10
    ldr x6, [x9, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w12, [x5, #8]
    add w13, w21, #1
    add w10, w10, #1
    ldr x6, [x9, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w12, [x6, x10]
    ldr x7, [x22]
    cmp x13, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    strb w12, [x5, #8]
    mov x19, x11
    cmp x19, #100
    b.hs .Lssa_int____int_to_string_u64_36
.Lssa_int____int_to_string_u64_7:
    cmp x19, #10
    b.lo .Lssa_int____int_to_string_u64_5
.Lssa_int____int_to_string_u64_6:
    sub x10, x21, #2
    sxtw x10, w10
    lsl x12, x19, #1
    sxtw x12, w12
    ldr x6, [x9, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w13, [x6, x12]
    ldr x7, [x22]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    strb w13, [x5, #8]
    add w10, w10, #1
    add w12, w12, #1
    ldr x6, [x9, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x9]
    ldrb w11, [x6, x12]
    ldr x7, [x22]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x10
    strb w11, [x5, #8]
    b .Lssa_int____int_to_string_u64_4
.Lssa_int____int_to_string_u64_5:
    sub w21, w21, #1
    add x19, x19, #48
    and x19, x19, #255
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w19, [x5, #8]
.Lssa_int____int_to_string_u64_4:
    cmp x20, #0
    b.eq .Lssa_int____int_to_string_u64_1
.Lssa_int____int_to_string_u64_3:
    mov x12, #45
    ldr x6, [x22, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    strb w12, [x22, #8]
.Lssa_int____int_to_string_u64_1:
    mov x0, x22
    bl __fn___fern_string_from_bytes_u8.r
    mov x19, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa_int____int_to_string_u64_rcdeck197
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_int____int_to_string_u64_rcdecd197
    tbnz w5, #31, .Lssa_int____int_to_string_u64_rcdeck197
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_int____int_to_string_u64_rcdece197
.Lssa_int____int_to_string_u64_rcdecd197:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_int____int_to_string_u64_rcdeck197:
.Lssa_int____int_to_string_u64_rcdece197:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_main:
    .cfi_startproc
__fn_main.k:
__fn_main.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
.Lssa_main_0:
    adrp x9, .K23
    add x9, x9, :lo12:.K23
    ldr x19, [x9, #48]
    mov x6, #0
    tbnz x9, #0, .Lssa_main_rcuniq402
    cmp x9, #16, lsl #12
    b.lo .Lssa_main_rcuniq402
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.ne .Lssa_main_rcuniq402
    mov x6, #1
.Lssa_main_rcuniq402:
    mov x0, x6
    cbz x0, .Lssa_main_34
.Lssa_main_32:
    mov x10, #0
    str x10, [x9, #48]
.Lssa_main_34:
    cmp x0, #0
    b.ne .Lssa_main_37
.Lssa_main_35:
    tbnz x19, #0, .Lssa_main_rcinc408
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcinc408
    ldur w5, [x19, #-8]
    tbnz w5, #31, .Lssa_main_rcinc408
    add w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcinc408:
.Lssa_main_37:
    adrp x11, .K24
    add x11, x11, :lo12:.K24
    ldr x20, [x19, #32]
.Lssa_main_31:
    mov x21, x11
    mov x22, #0
.Lssa_main_38:
    ldr x11, [x20, #0]
    cmp x22, x11
    b.ge .Lssa_main_30
.Lssa_main_48:
    add x5, x22, #1
    ldr x23, [x20, x5, lsl #3]
.Lssa_main_47:
.Lssa_main_46:
    ldr x24, [x23, #8]
    ldr x25, [x23, #0]
    mov x26, #0
.Lssa_main_53:
    cmp x26, x24
    b.ge .Lssa_main_45
.Lssa_main_70:
    ldrb w11, [x25, x26]
.Lssa_main_69:
    cmp x11, #48
    b.lt .Lssa_main_65
.Lssa_main_68:
    cmp x11, #58
    b.ge .Lssa_main_65
.Lssa_main_67:
    sub x10, x11, #48
    sxtw x10, w10
    mov x11, x10
    b .Lssa_main_56
.Lssa_main_65:
    cmp x11, #97
    b.lt .Lssa_main_61
.Lssa_main_64:
    cmp x11, #103
    b.ge .Lssa_main_61
.Lssa_main_63:
    sub x10, x11, #87
    sxtw x10, w10
    mov x11, x10
    b .Lssa_main_56
.Lssa_main_61:
    cmp x11, #65
    b.lt .Lssa_main_57
.Lssa_main_60:
    cmp x11, #71
    b.ge .Lssa_main_57
.Lssa_main_59:
    sub x11, x11, #55
    sxtw x11, w11
    b .Lssa_main_56
.Lssa_main_57:
    mov x11, #-1
.Lssa_main_56:
    cmp x11, #0
    b.ge .Lssa_main_54
.Lssa_main_102:
    tst x21, #1
    b.ne .Lssa_main_uq102
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq102
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq102:
    b.ne .Lssa_main_107
.Lssa_main_105:
    mov x27, #0
.Lssa_main_109:
    ldr x11, [x21, #0]
    cmp x27, x11
    b.ge .Lssa_main_107
.Lssa_main_110:
    add x5, x27, #1
    ldr x11, [x21, x5, lsl #3]
    cmp x11, #16, lsl #12
    b.lo .Lssa_main_rcdeck485
    ldur w5, [x11, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd485
    tbnz w5, #31, .Lssa_main_rcdeck485
    mov x0, x11
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece485
.Lssa_main_rcdecd485:
    sub w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_main_rcdeck485:
.Lssa_main_rcdece485:
    add x27, x27, #1
    b .Lssa_main_109
.Lssa_main_107:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck489
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd489
    tbnz w5, #31, .Lssa_main_rcdeck489
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece489
.Lssa_main_rcdecd489:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck489:
.Lssa_main_rcdece489:
    b .Lssa_main_25
.Lssa_main_54:
    add x26, x26, #1
    cmp x26, x24
    b.lt .Lssa_main_70
.Lssa_main_45:
    ldr x11, [x23, #8]
    mov x10, #1
    and x11, x11, x10
    cmp x11, #0
    b.eq .Lssa_main_43
.Lssa_main_116:
    tst x21, #1
    b.ne .Lssa_main_uq116
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq116
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq116:
    b.ne .Lssa_main_121
.Lssa_main_119:
    mov x26, #0
.Lssa_main_123:
    ldr x11, [x21, #0]
    cmp x26, x11
    b.ge .Lssa_main_121
.Lssa_main_124:
    add x5, x26, #1
    ldr x11, [x21, x5, lsl #3]
    cmp x11, #16, lsl #12
    b.lo .Lssa_main_rcdeck504
    ldur w5, [x11, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd504
    tbnz w5, #31, .Lssa_main_rcdeck504
    mov x0, x11
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece504
.Lssa_main_rcdecd504:
    sub w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_main_rcdeck504:
.Lssa_main_rcdece504:
    add x26, x26, #1
    b .Lssa_main_123
.Lssa_main_121:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck508
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd508
    tbnz w5, #31, .Lssa_main_rcdeck508
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece508
.Lssa_main_rcdecd508:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck508:
.Lssa_main_rcdece508:
    b .Lssa_main_24
.Lssa_main_43:
    ldr x11, [x23, #8]
    asr x11, x11, #1
    mov x0, x11
    bl __fern_alloc_bytes
.Lssa_main_42:
    mov x11, #0
.Lssa_main_128:
    ldr x10, [x0, #0]
    cmp x11, x10
    b.ge .Lssa_main_40
.Lssa_main_157:
    lsl x10, x11, #1
    mov w10, w10
    ldr x6, [x23, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x23]
    ldrb w9, [x6, x10]
.Lssa_main_156:
    cmp x9, #48
    b.lt .Lssa_main_152
.Lssa_main_155:
    cmp x9, #58
    b.ge .Lssa_main_152
.Lssa_main_154:
    sub x10, x9, #48
    mov x9, x10
    b .Lssa_main_143
.Lssa_main_152:
    cmp x9, #97
    b.lt .Lssa_main_148
.Lssa_main_151:
    cmp x9, #103
    b.ge .Lssa_main_148
.Lssa_main_150:
    sub x10, x9, #87
    mov x9, x10
    b .Lssa_main_143
.Lssa_main_148:
    cmp x9, #65
    b.lt .Lssa_main_144
.Lssa_main_147:
    cmp x9, #71
    b.ge .Lssa_main_144
.Lssa_main_146:
    sub x9, x9, #55
    b .Lssa_main_143
.Lssa_main_144:
    mov x9, #-1
.Lssa_main_143:
    lsl x10, x11, #1
    add w10, w10, #1
    ldr x6, [x23, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x23]
    ldrb w12, [x6, x10]
.Lssa_main_142:
    cmp x12, #48
    b.lt .Lssa_main_138
.Lssa_main_141:
    cmp x12, #58
    b.ge .Lssa_main_138
.Lssa_main_140:
    sub x10, x12, #48
    mov x12, x10
    b .Lssa_main_129
.Lssa_main_138:
    cmp x12, #97
    b.lt .Lssa_main_134
.Lssa_main_137:
    cmp x12, #103
    b.ge .Lssa_main_134
.Lssa_main_136:
    sub x10, x12, #87
    mov x12, x10
    b .Lssa_main_129
.Lssa_main_134:
    cmp x12, #65
    b.lt .Lssa_main_130
.Lssa_main_133:
    cmp x12, #71
    b.ge .Lssa_main_130
.Lssa_main_132:
    sub x12, x12, #55
    b .Lssa_main_129
.Lssa_main_130:
    mov x12, #-1
.Lssa_main_129:
    lsl x9, x9, #4
    orr x9, x9, x12
    and x9, x9, #255
    add x5, x0, x11
    strb w9, [x5, #8]
    add x11, x11, #1
    b .Lssa_main_128
.Lssa_main_40:
    mov x1, x0
    mov x0, x21
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_main_apush595s
.Lssa_main_apush595o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_main_apush595e
.Lssa_main_apush595s:
    bl __fern_arr_push_owned
.Lssa_main_apush595e:
    mov x21, x0
.Lssa_main_39:
    add x22, x22, #1
    b .Lssa_main_38
.Lssa_main_30:
    ldr x20, [x19, #8]
    ldr x23, [x19, #16]
    mov x0, x19
    bl __fn___sem_release_video_vectors__Vector.r
    mov x0, #3
    bl __fern_arr_box
    mov x26, x0
    adrp x11, .S35
    add x11, x11, :lo12:.S35
    str x11, [x26, #0]
    str x20, [x26, #8]
    str x23, [x26, #16]
    movz x25, #128, lsl #16
    movz x24, #256, lsl #16
.Lssa_main_28:
    cmp x20, #0
    b.gt .Lssa_main_27
.Lssa_main_220:
    tst x21, #1
    b.ne .Lssa_main_uq220
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq220
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq220:
    b.ne .Lssa_main_225
.Lssa_main_223:
    mov x27, #0
.Lssa_main_227:
    ldr x12, [x21, #0]
    cmp x27, x12
    b.ge .Lssa_main_225
.Lssa_main_228:
    add x5, x27, #1
    ldr x12, [x21, x5, lsl #3]
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck617
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd617
    tbnz w5, #31, .Lssa_main_rcdeck617
    mov x0, x12
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece617
.Lssa_main_rcdecd617:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck617:
.Lssa_main_rcdece617:
    add x27, x27, #1
    b .Lssa_main_227
.Lssa_main_225:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck621
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd621
    tbnz w5, #31, .Lssa_main_rcdeck621
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece621
.Lssa_main_rcdecd621:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck621:
.Lssa_main_rcdece621:
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck622
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd622
    tbnz w5, #31, .Lssa_main_rcdeck622
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece622
.Lssa_main_rcdecd622:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck622:
.Lssa_main_rcdece622:
    b .Lssa_main_4
.Lssa_main_27:
    cmp x23, #0
    b.gt .Lssa_main_17
.Lssa_main_232:
    tst x21, #1
    b.ne .Lssa_main_uq232
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq232
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq232:
    b.ne .Lssa_main_237
.Lssa_main_235:
    mov x27, #0
.Lssa_main_239:
    ldr x12, [x21, #0]
    cmp x27, x12
    b.ge .Lssa_main_237
.Lssa_main_240:
    add x5, x27, #1
    ldr x12, [x21, x5, lsl #3]
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck631
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd631
    tbnz w5, #31, .Lssa_main_rcdeck631
    mov x0, x12
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece631
.Lssa_main_rcdecd631:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck631:
.Lssa_main_rcdece631:
    add x27, x27, #1
    b .Lssa_main_239
.Lssa_main_237:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck635
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd635
    tbnz w5, #31, .Lssa_main_rcdeck635
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece635
.Lssa_main_rcdecd635:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck635:
.Lssa_main_rcdece635:
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck636
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd636
    tbnz w5, #31, .Lssa_main_rcdeck636
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece636
.Lssa_main_rcdecd636:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck636:
.Lssa_main_rcdece636:
    b .Lssa_main_4
.Lssa_main_25:
    tst x19, #1
    b.ne .Lssa_main_uq25
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_uq25
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_main_uq25:
    b.ne .Lssa_main_246
.Lssa_main_245:
    mov x12, x19
    b .Lssa_main_247
.Lssa_main_246:
    mov x12, #0
.Lssa_main_247:
    ldr x27, [x19, #32]
    cmp x12, #0
    b.ne .Lssa_main_250
.Lssa_main_248:
    tbnz x27, #0, .Lssa_main_rcinc644
    cmp x27, #16, lsl #12
    b.lo .Lssa_main_rcinc644
    ldur w5, [x27, #-8]
    tbnz w5, #31, .Lssa_main_rcinc644
    add w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_main_rcinc644:
.Lssa_main_250:
    cmp x12, #0
    b.eq .Lssa_main_252
.Lssa_main_251:
    ldr x12, [x19, #40]
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck648
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd648
    tbnz w5, #31, .Lssa_main_rcdeck648
    mov x0, x12
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece648
.Lssa_main_rcdecd648:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck648:
.Lssa_main_rcdece648:
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_main_253
.Lssa_main_252:
    mov x0, x19
    bl __fn___sem_release_video_vectors__Vector.r
.Lssa_main_253:
    add x5, x22, #1
    ldr x12, [x27, x5, lsl #3]
    tst x27, #1
    b.ne .Lssa_main_uq253
    cmp x27, #16, lsl #12
    b.lo .Lssa_main_uq253
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_main_uq253:
    b.ne .Lssa_main_256
.Lssa_main_254:
    mov x28, #0
.Lssa_main_258:
    ldr x12, [x27, #0]
    cmp x28, x12
    b.ge .Lssa_main_256
.Lssa_main_259:
    add x5, x28, #1
    ldr x12, [x27, x5, lsl #3]
    tbnz x12, #0, .Lssa_main_rcdeck661
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck661
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd661
    tbnz w5, #31, .Lssa_main_rcdeck661
    mov x0, x12
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece661
.Lssa_main_rcdecd661:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck661:
.Lssa_main_rcdece661:
    add x28, x28, #1
    b .Lssa_main_258
.Lssa_main_256:
    cmp x27, #16, lsl #12
    b.lo .Lssa_main_rcdeck665
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd665
    tbnz w5, #31, .Lssa_main_rcdeck665
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece665
.Lssa_main_rcdecd665:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_main_rcdeck665:
.Lssa_main_rcdece665:
    b .Lssa_main_22
.Lssa_main_24:
    tst x19, #1
    b.ne .Lssa_main_uq24
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_uq24
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_main_uq24:
    b.ne .Lssa_main_264
.Lssa_main_263:
    mov x12, x19
    b .Lssa_main_265
.Lssa_main_264:
    mov x12, #0
.Lssa_main_265:
    ldr x28, [x19, #32]
    cmp x12, #0
    b.ne .Lssa_main_268
.Lssa_main_266:
    tbnz x28, #0, .Lssa_main_rcinc672
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcinc672
    ldur w5, [x28, #-8]
    tbnz w5, #31, .Lssa_main_rcinc672
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcinc672:
.Lssa_main_268:
    cmp x12, #0
    b.eq .Lssa_main_270
.Lssa_main_269:
    ldr x12, [x19, #40]
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck676
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd676
    tbnz w5, #31, .Lssa_main_rcdeck676
    mov x0, x12
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece676
.Lssa_main_rcdecd676:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck676:
.Lssa_main_rcdece676:
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_main_271
.Lssa_main_270:
    mov x0, x19
    bl __fn___sem_release_video_vectors__Vector.r
.Lssa_main_271:
    add x5, x22, #1
    ldr x12, [x28, x5, lsl #3]
    tst x28, #1
    b.ne .Lssa_main_uq271
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_uq271
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_main_uq271:
    b.ne .Lssa_main_274
.Lssa_main_272:
    mov x22, #0
.Lssa_main_276:
    ldr x12, [x28, #0]
    cmp x22, x12
    b.ge .Lssa_main_274
.Lssa_main_277:
    add x5, x22, #1
    ldr x12, [x28, x5, lsl #3]
    tbnz x12, #0, .Lssa_main_rcdeck688
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck688
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd688
    tbnz w5, #31, .Lssa_main_rcdeck688
    mov x0, x12
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece688
.Lssa_main_rcdecd688:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck688:
.Lssa_main_rcdece688:
    add x22, x22, #1
    b .Lssa_main_276
.Lssa_main_274:
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck692
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd692
    tbnz w5, #31, .Lssa_main_rcdeck692
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece692
.Lssa_main_rcdecd692:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck692:
.Lssa_main_rcdece692:
.Lssa_main_22:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_17:
    cmp x20, #0
    cset x12, ne
    mul x11, x20, x23
    sxtw x11, w11
    mov x4, x11
    mov x5, x20
    sdiv x4, x4, x5
    sxtw x4, w4
    mov x9, x4
    cmp x9, x23
    cset x9, ne
    mov x11, #-1
    cmp x20, x11
    cset x11, eq
    ldr x10, =-2147483648
    cmp x23, x10
    cset x10, eq
    and x11, x11, x10
    orr x9, x9, x11
    and x12, x12, x9
    mul x20, x20, x23
    sxtw x20, w20
    mov x9, #0
    cmp x12, #0
    cset x12, eq
    cmp x12, #0
    csel x20, x20, x9, ne
    cbnz x12, .Lssa_main_16
.Lssa_main_284:
    tst x21, #1
    b.ne .Lssa_main_uq284
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq284
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq284:
    b.ne .Lssa_main_288
.Lssa_main_286:
    mov x23, #0
.Lssa_main_290:
    ldr x12, [x21, #0]
    cmp x23, x12
    b.ge .Lssa_main_288
.Lssa_main_291:
    add x5, x23, #1
    ldr x12, [x21, x5, lsl #3]
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck722
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd722
    tbnz w5, #31, .Lssa_main_rcdeck722
    mov x0, x12
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece722
.Lssa_main_rcdecd722:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck722:
.Lssa_main_rcdece722:
    add x23, x23, #1
    b .Lssa_main_290
.Lssa_main_288:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck726
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd726
    tbnz w5, #31, .Lssa_main_rcdeck726
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece726
.Lssa_main_rcdecd726:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck726:
.Lssa_main_rcdece726:
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck727
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd727
    tbnz w5, #31, .Lssa_main_rcdeck727
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece727
.Lssa_main_rcdecd727:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck727:
.Lssa_main_rcdece727:
    b .Lssa_main_4
.Lssa_main_16:
    cmp x20, x25
    b.le .Lssa_main_15
.Lssa_main_295:
    tst x21, #1
    b.ne .Lssa_main_uq295
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq295
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq295:
    b.ne .Lssa_main_300
.Lssa_main_298:
    mov x23, #0
.Lssa_main_302:
    ldr x12, [x21, #0]
    cmp x23, x12
    b.ge .Lssa_main_300
.Lssa_main_303:
    add x5, x23, #1
    ldr x12, [x21, x5, lsl #3]
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck735
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd735
    tbnz w5, #31, .Lssa_main_rcdeck735
    mov x0, x12
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece735
.Lssa_main_rcdecd735:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck735:
.Lssa_main_rcdece735:
    add x23, x23, #1
    b .Lssa_main_302
.Lssa_main_300:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck739
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd739
    tbnz w5, #31, .Lssa_main_rcdeck739
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece739
.Lssa_main_rcdecd739:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck739:
.Lssa_main_rcdece739:
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck740
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd740
    tbnz w5, #31, .Lssa_main_rcdeck740
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece740
.Lssa_main_rcdecd740:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck740:
.Lssa_main_rcdece740:
    b .Lssa_main_4
.Lssa_main_15:
    movn w12, #61440, lsl #16
    cmp x20, x12
    b.le .Lssa_main_12
.Lssa_main_307:
    tst x21, #1
    b.ne .Lssa_main_uq307
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq307
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq307:
    b.ne .Lssa_main_312
.Lssa_main_310:
    mov x23, #0
.Lssa_main_314:
    ldr x12, [x21, #0]
    cmp x23, x12
    b.ge .Lssa_main_312
.Lssa_main_315:
    add x5, x23, #1
    ldr x12, [x21, x5, lsl #3]
    cmp x12, #16, lsl #12
    b.lo .Lssa_main_rcdeck749
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd749
    tbnz w5, #31, .Lssa_main_rcdeck749
    mov x0, x12
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece749
.Lssa_main_rcdecd749:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_main_rcdeck749:
.Lssa_main_rcdece749:
    add x23, x23, #1
    b .Lssa_main_314
.Lssa_main_312:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck753
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd753
    tbnz w5, #31, .Lssa_main_rcdeck753
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece753
.Lssa_main_rcdecd753:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck753:
.Lssa_main_rcdece753:
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck754
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd754
    tbnz w5, #31, .Lssa_main_rcdeck754
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece754
.Lssa_main_rcdecd754:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck754:
.Lssa_main_rcdece754:
    b .Lssa_main_4
.Lssa_main_12:
    adrp x11, .K24
    add x11, x11, :lo12:.K24
    cmp x20, #0
    b.gt .Lssa_main_11
.Lssa_main_321:
    mov x20, x11
    b .Lssa_main_9
.Lssa_main_11:
    mov x0, x20
    bl __fern_alloc_u8
    mov x11, x0
    mov x20, x11
.Lssa_main_10:
.Lssa_main_9:
    adrp x0, __fern_alloc_count
    add x0, x0, :lo12:__fern_alloc_count
    ldr x0, [x0]
    mov x23, x0
.Lssa_main_8:
    mov x22, #0
    mov x28, #0
.Lssa_main_324:
    ldr x11, =100000
    cmp x28, x11
    b.lt .Lssa_main_328
.Lssa_main_330:
    tst x21, #1
    b.ne .Lssa_main_uq330
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq330
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq330:
    b.ne .Lssa_main_334
.Lssa_main_332:
    mov x19, #0
.Lssa_main_336:
    ldr x11, [x21, #0]
    cmp x19, x11
    b.ge .Lssa_main_334
.Lssa_main_337:
    add x5, x19, #1
    ldr x11, [x21, x5, lsl #3]
    cmp x11, #16, lsl #12
    b.lo .Lssa_main_rcdeck788
    ldur w5, [x11, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd788
    tbnz w5, #31, .Lssa_main_rcdeck788
    mov x0, x11
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece788
.Lssa_main_rcdecd788:
    sub w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_main_rcdeck788:
.Lssa_main_rcdece788:
    add x19, x19, #1
    b .Lssa_main_336
.Lssa_main_334:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck792
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd792
    tbnz w5, #31, .Lssa_main_rcdeck792
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece792
.Lssa_main_rcdecd792:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck792:
.Lssa_main_rcdece792:
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck793
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd793
    tbnz w5, #31, .Lssa_main_rcdeck793
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece793
.Lssa_main_rcdecd793:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck793:
.Lssa_main_rcdece793:
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_rcdeck794
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd794
    tbnz w5, #31, .Lssa_main_rcdeck794
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece794
.Lssa_main_rcdecd794:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_main_rcdeck794:
.Lssa_main_rcdece794:
    b .Lssa_main_7
.Lssa_main_328:
    mov x11, #3
    and x11, x28, x11
    ldr x6, [x21]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x0, [x21, x5, lsl #3]
    mov x10, #32
    b .Lssa_main_pool_445
    .ltorg
.Lssa_main_pool_445:
    mov x9, x26
    mov x11, x20
    mov x12, x25
    mov x13, x24
    bl __fn_qtrle__decode_into.r
    mov x19, x0
    mov x20, x1
    cmp x19, #0
    b.eq .Lssa_main_326
.Lssa_main_342:
    tst x21, #1
    b.ne .Lssa_main_uq342
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_uq342
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_main_uq342:
    b.ne .Lssa_main_346
.Lssa_main_344:
    mov x19, #0
.Lssa_main_348:
    ldr x10, [x21, #0]
    cmp x19, x10
    b.ge .Lssa_main_346
.Lssa_main_349:
    add x5, x19, #1
    ldr x10, [x21, x5, lsl #3]
    cmp x10, #16, lsl #12
    b.lo .Lssa_main_rcdeck809
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd809
    tbnz w5, #31, .Lssa_main_rcdeck809
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece809
.Lssa_main_rcdecd809:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_main_rcdeck809:
.Lssa_main_rcdece809:
    add x19, x19, #1
    b .Lssa_main_348
.Lssa_main_346:
    cmp x21, #16, lsl #12
    b.lo .Lssa_main_rcdeck813
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd813
    tbnz w5, #31, .Lssa_main_rcdeck813
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece813
.Lssa_main_rcdecd813:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_main_rcdeck813:
.Lssa_main_rcdece813:
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck814
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd814
    tbnz w5, #31, .Lssa_main_rcdeck814
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece814
.Lssa_main_rcdecd814:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck814:
.Lssa_main_rcdece814:
    b .Lssa_main_3
.Lssa_main_326:
    tst x20, #1
    b.ne .Lssa_main_uq326
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_uq326
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_main_uq326:
    b.ne .Lssa_main_354
.Lssa_main_353:
    mov x10, x20
    b .Lssa_main_355
.Lssa_main_354:
    mov x10, #0
.Lssa_main_355:
    ldr x19, [x20, #24]
    cmp x10, #0
    b.ne .Lssa_main_358
.Lssa_main_356:
    tbnz x19, #0, .Lssa_main_rcinc821
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcinc821
    ldur w5, [x19, #-8]
    tbnz w5, #31, .Lssa_main_rcinc821
    add w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcinc821:
.Lssa_main_358:
    cmp x10, #0
    b.eq .Lssa_main_360
.Lssa_main_359:
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_main_361
.Lssa_main_360:
    mov x0, x20
    bl __fn___sem_release_frame__Frame.r
.Lssa_main_361:
    ldr x10, [x19, #0]
    mov x4, x28
    mov x5, x10
    sdiv x6, x4, x5
    msub x4, x6, x5, x4
    mov x11, x4
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x10, [x19, x5, lsl #3]
    mov w10, w10
    add x22, x22, x10
.Lssa_main_325:
    add x28, x28, #1
    mov x20, x19
    b .Lssa_main_324
.Lssa_main_7:
    adrp x0, __fern_alloc_count
    add x0, x0, :lo12:__fern_alloc_count
    ldr x0, [x0]
    sub x23, x0, x23
    mov x9, #0
    mov x0, x22
    bl __fn_int____int_to_string_u64.r
    mov x28, x0
    adrp x22, .SB36
    add x22, x22, :lo12:.SB36
    str x28, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_365
.Lssa_main_364:
    mov x19, x28
    b .Lssa_main_366
.Lssa_main_365:
    str x28, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x19, x0
    tbnz x28, #0, .Lssa_main_rcdeck841
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck841
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd841
    tbnz w5, #31, .Lssa_main_rcdeck841
    mov x0, x28
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece841
.Lssa_main_rcdecd841:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck841:
.Lssa_main_rcdece841:
.Lssa_main_366:
    mov x0, x23
    bl __fn_i64__to_string.r
    mov x22, x0
    str x19, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_368
.Lssa_main_367:
    mov x23, x19
    b .Lssa_main_369
.Lssa_main_368:
    str x19, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x23, x0
    tbnz x19, #0, .Lssa_main_rcdeck846
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck846
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd846
    tbnz w5, #31, .Lssa_main_rcdeck846
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece846
.Lssa_main_rcdecd846:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck846:
.Lssa_main_rcdece846:
.Lssa_main_369:
    tbnz x22, #0, .Lssa_main_rcdeck848
    cmp x22, #16, lsl #12
    b.lo .Lssa_main_rcdeck848
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd848
    tbnz w5, #31, .Lssa_main_rcdeck848
    mov x0, x22
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece848
.Lssa_main_rcdecd848:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_main_rcdeck848:
.Lssa_main_rcdece848:
    mov x0, x23
    bl __fn___fern_print_str.r
    adrp x9, .SB37
    add x9, x9, :lo12:.SB37
    mov x0, x9
    bl __fn___fern_print_str.r
    tbnz x23, #0, .Lssa_main_rcdeck852
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_rcdeck852
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd852
    tbnz w5, #31, .Lssa_main_rcdeck852
    mov x0, x23
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece852
.Lssa_main_rcdecd852:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_main_rcdeck852:
.Lssa_main_rcdece852:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_4:
    mov x0, #2
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_3:
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_rcdeck855
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd855
    tbnz w5, #31, .Lssa_main_rcdeck855
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece855
.Lssa_main_rcdecd855:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_main_rcdeck855:
.Lssa_main_rcdece855:
.Lssa_main_1:
    mov x0, #3
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_frame__Frame
.weak __fn___sem_drop_frame__Frame.k
__fn___sem_drop_frame__Frame:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_frame__Frame.k:
__fn___sem_drop_frame__Frame.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_frame__Frame_0:
    ldr x9, [x0, #24]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_frame__Frame_rcdeck3
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_frame__Frame_rcdecd3
    tbnz w5, #31, .Lssa___sem_drop_frame__Frame_rcdeck3
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_frame__Frame_rcdece3
.Lssa___sem_drop_frame__Frame_rcdecd3:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_frame__Frame_rcdeck3:
.Lssa___sem_drop_frame__Frame_rcdece3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_frame__Frame
.weak __fn___sem_release_frame__Frame.k
__fn___sem_release_frame__Frame:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_frame__Frame.k:
__fn___sem_release_frame__Frame.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_frame__Frame_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_frame__Frame_release_dec
    tbz w5, #31, .Lssa___sem_release_frame__Frame_release_slow
.Lssa___sem_release_frame__Frame_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_frame__Frame_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_frame__Frame_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_frame__Frame_0:
    tst x19, #1
    b.ne .Lssa___sem_release_frame__Frame_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_frame__Frame_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_frame__Frame_uq0:
    b.ne .Lssa___sem_release_frame__Frame_3
.Lssa___sem_release_frame__Frame_1:
    mov x0, x19
    bl __fn___sem_drop_frame__Frame.r
.Lssa___sem_release_frame__Frame_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_frame__Frame_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_frame__Frame_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_frame__Frame_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_frame__Frame_rcdece3
.Lssa___sem_release_frame__Frame_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_frame__Frame_rcdeck3:
.Lssa___sem_release_frame__Frame_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_qtrle__Row
.weak __fn___sem_drop_qtrle__Row.k
__fn___sem_drop_qtrle__Row:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_qtrle__Row.k:
__fn___sem_drop_qtrle__Row.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_qtrle__Row_0:
    ldr x9, [x0, #8]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_qtrle__Row_rcdeck3
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_qtrle__Row_rcdecd3
    tbnz w5, #31, .Lssa___sem_drop_qtrle__Row_rcdeck3
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_qtrle__Row_rcdece3
.Lssa___sem_drop_qtrle__Row_rcdecd3:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_qtrle__Row_rcdeck3:
.Lssa___sem_drop_qtrle__Row_rcdece3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_qtrle__Row
.weak __fn___sem_release_qtrle__Row.k
__fn___sem_release_qtrle__Row:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_qtrle__Row.k:
__fn___sem_release_qtrle__Row.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_qtrle__Row_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_qtrle__Row_release_dec
    tbz w5, #31, .Lssa___sem_release_qtrle__Row_release_slow
.Lssa___sem_release_qtrle__Row_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_qtrle__Row_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_qtrle__Row_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_qtrle__Row_0:
    tst x19, #1
    b.ne .Lssa___sem_release_qtrle__Row_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_qtrle__Row_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_qtrle__Row_uq0:
    b.ne .Lssa___sem_release_qtrle__Row_3
.Lssa___sem_release_qtrle__Row_1:
    mov x0, x19
    bl __fn___sem_drop_qtrle__Row.r
.Lssa___sem_release_qtrle__Row_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_qtrle__Row_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_qtrle__Row_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_qtrle__Row_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_qtrle__Row_rcdece3
.Lssa___sem_release_qtrle__Row_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_qtrle__Row_rcdeck3:
.Lssa___sem_release_qtrle__Row_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_video_vectors__Vector
.weak __fn___sem_drop_video_vectors__Vector.k
__fn___sem_drop_video_vectors__Vector:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_video_vectors__Vector.k:
__fn___sem_drop_video_vectors__Vector.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_video_vectors__Vector_0:
    ldr x20, [x19, #32]
    tst x20, #1
    b.ne .Lssa___sem_drop_video_vectors__Vector_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_video_vectors__Vector_uq0
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_video_vectors__Vector_uq0:
    b.ne .Lssa___sem_drop_video_vectors__Vector_3
.Lssa___sem_drop_video_vectors__Vector_1:
    mov x21, #0
.Lssa___sem_drop_video_vectors__Vector_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_video_vectors__Vector_3
.Lssa___sem_drop_video_vectors__Vector_6:
    add x5, x21, #1
    ldr x9, [x20, x5, lsl #3]
    tbnz x9, #0, .Lssa___sem_drop_video_vectors__Vector_rcdeck11
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_video_vectors__Vector_rcdeck11
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_video_vectors__Vector_rcdecd11
    tbnz w5, #31, .Lssa___sem_drop_video_vectors__Vector_rcdeck11
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_video_vectors__Vector_rcdece11
.Lssa___sem_drop_video_vectors__Vector_rcdecd11:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_video_vectors__Vector_rcdeck11:
.Lssa___sem_drop_video_vectors__Vector_rcdece11:
    add x21, x21, #1
    b .Lssa___sem_drop_video_vectors__Vector_5
.Lssa___sem_drop_video_vectors__Vector_3:
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_video_vectors__Vector_rcdeck15
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_video_vectors__Vector_rcdecd15
    tbnz w5, #31, .Lssa___sem_drop_video_vectors__Vector_rcdeck15
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_video_vectors__Vector_rcdece15
.Lssa___sem_drop_video_vectors__Vector_rcdecd15:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___sem_drop_video_vectors__Vector_rcdeck15:
.Lssa___sem_drop_video_vectors__Vector_rcdece15:
    ldr x9, [x19, #40]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_video_vectors__Vector_rcdeck17
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_video_vectors__Vector_rcdecd17
    tbnz w5, #31, .Lssa___sem_drop_video_vectors__Vector_rcdeck17
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_video_vectors__Vector_rcdece17
.Lssa___sem_drop_video_vectors__Vector_rcdecd17:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_video_vectors__Vector_rcdeck17:
.Lssa___sem_drop_video_vectors__Vector_rcdece17:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_video_vectors__Vector
.weak __fn___sem_release_video_vectors__Vector.k
__fn___sem_release_video_vectors__Vector:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_video_vectors__Vector.k:
__fn___sem_release_video_vectors__Vector.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_video_vectors__Vector_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_video_vectors__Vector_release_dec
    tbz w5, #31, .Lssa___sem_release_video_vectors__Vector_release_slow
.Lssa___sem_release_video_vectors__Vector_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_video_vectors__Vector_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_video_vectors__Vector_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_video_vectors__Vector_0:
    tst x19, #1
    b.ne .Lssa___sem_release_video_vectors__Vector_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_video_vectors__Vector_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_video_vectors__Vector_uq0:
    b.ne .Lssa___sem_release_video_vectors__Vector_3
.Lssa___sem_release_video_vectors__Vector_1:
    mov x0, x19
    bl __fn___sem_drop_video_vectors__Vector.r
.Lssa___sem_release_video_vectors__Vector_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_video_vectors__Vector_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_video_vectors__Vector_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_video_vectors__Vector_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_video_vectors__Vector_rcdece3
.Lssa___sem_release_video_vectors__Vector_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_video_vectors__Vector_rcdeck3:
.Lssa___sem_release_video_vectors__Vector_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_len
.weak __fn___sem_view_len.k
__fn___sem_view_len:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_len.k:
__fn___sem_view_len.r:
.Lssa___sem_view_len_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_len_3
.Lssa___sem_view_len_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #8]
    mov x0, x10
    ret
.Lssa___sem_view_len_3:
    ldr x10, [x0, #0]
    mov x0, x10
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_data
.weak __fn___sem_view_data.k
__fn___sem_view_data:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_data.k:
__fn___sem_view_data.r:
.Lssa___sem_view_data_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_data_3
.Lssa___sem_view_data_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #0]
    mov x0, x10
    ret
.Lssa___sem_view_data_3:
    add x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_slice
.weak __fn___sem_byte_view_slice.k
__fn___sem_byte_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_byte_view_slice.k:
__fn___sem_byte_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_byte_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_byte_view_slice_3
.Lssa___sem_byte_view_slice_1:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_byte_view_slice_6
.Lssa___sem_byte_view_slice_4:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_byte_view_slice_9
.Lssa___sem_byte_view_slice_7:
    bl __fern_slice_abort
.Lssa___sem_byte_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    add x0, x0, x20
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice
.weak __fn___sem_view_slice.k
__fn___sem_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice.k:
__fn___sem_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_3
.Lssa___sem_view_slice_1:
    bl __fern_slice_abort
.Lssa___sem_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_6
.Lssa___sem_view_slice_4:
    bl __fern_slice_abort
.Lssa___sem_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_9
.Lssa___sem_view_slice_7:
    bl __fern_slice_abort
.Lssa___sem_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice_wide
.weak __fn___sem_view_slice_wide.k
__fn___sem_view_slice_wide:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice_wide.k:
__fn___sem_view_slice_wide.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_wide_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_wide_3
.Lssa___sem_view_slice_wide_1:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_wide_6
.Lssa___sem_view_slice_wide_4:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_wide_9
.Lssa___sem_view_slice_wide_7:
    bl __fern_slice_abort
.Lssa___sem_view_slice_wide_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_release
.weak __fn___sem_view_release.k
__fn___sem_view_release:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_release.k:
__fn___sem_view_release.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_view_release_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_release_3
.Lssa___sem_view_release_1:
    mov x9, #-2
    add x9, x0, x9
    str x9, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_view_release_3:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_view_release_rcdeck6
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_view_release_rcdecd6
    tbnz w5, #31, .Lssa___sem_view_release_rcdeck6
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_view_release_rcdece6
.Lssa___sem_view_release_rcdecd6:
    sub w5, w5, #1
    stur w5, [x0, #-8]
.Lssa___sem_view_release_rcdeck6:
.Lssa___sem_view_release_rcdece6:
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_string
.weak __fn___sem_byte_view_string.k
__fn___sem_byte_view_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_byte_view_string.k:
__fn___sem_byte_view_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_string_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_byte_view_string_3
.Lssa___sem_byte_view_string_1:
    mov x9, #-2
    add x9, x0, x9
    adrp x10, .SB38
    add x10, x10, :lo12:.SB38
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_concat.r
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_string_3:
    bl __fn___fern_string_from_bytes_u8.r
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
_start:
    adrp x9, .Lfern_relanchor
    add x9, x9, :lo12:.Lfern_relanchor
    ldr x10, [x9]
    sub x9, x9, x10
    cbz x9, .Lfern_reloc_done
    adrp x11, .Lfern_sbox_begin
    add x11, x11, :lo12:.Lfern_sbox_begin
    adrp x12, .Lfern_sbox_end
    add x12, x12, :lo12:.Lfern_sbox_end
.Lfern_sbox_loop:
    cmp x11, x12
    b.hs .Lfern_sbox_done
    ldr x13, [x11, #8]
    add x13, x13, x9
    str x13, [x11, #8]
    add x11, x11, #24
    b .Lfern_sbox_loop
.Lfern_sbox_done:
    adrp x11, .Lfern_cagg_begin
    add x11, x11, :lo12:.Lfern_cagg_begin
    adrp x12, .Lfern_cagg_end
    add x12, x12, :lo12:.Lfern_cagg_end
.Lfern_cagg_loop:
    cmp x11, x12
    b.hs .Lfern_cagg_done
    ldr x13, [x11, #16]
    add x13, x13, x9
    str x13, [x11, #16]
    ldr x14, [x11]
    add x11, x11, #16
    add x11, x11, x14, lsl #3
    b .Lfern_cagg_loop
.Lfern_cagg_done:
    adrp x11, .Lfern_cfn_begin
    add x11, x11, :lo12:.Lfern_cfn_begin
    adrp x12, .Lfern_cfn_end
    add x12, x12, :lo12:.Lfern_cfn_end
.Lfern_cfn_loop:
    cmp x11, x12
    b.hs .Lfern_cfn_done
    ldr x13, [x11, #24]
    add x13, x13, x9
    str x13, [x11, #24]
    add x11, x11, #32
    b .Lfern_cfn_loop
.Lfern_cfn_done:
    adrp x11, .Lfern_cref_begin
    add x11, x11, :lo12:.Lfern_cref_begin
    adrp x12, .Lfern_cref_end
    add x12, x12, :lo12:.Lfern_cref_end
.Lfern_cref_loop:
    cmp x11, x12
    b.hs .Lfern_reloc_done
    ldr x13, [x11]
    add x13, x13, x9
    ldr x14, [x13]
    add x14, x14, x9
    str x14, [x13]
    add x11, x11, #8
    b .Lfern_cref_loop
.Lfern_reloc_done:
    ldr x0, [sp]
    lsl x0, x0, #3
    add x0, x0, #16
    add x0, sp, x0
    adrp x1, __fern_envp
    add x1, x1, :lo12:__fern_envp
    str x0, [x1]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #30
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_stack_map_failed
    mov x19, x0
    mov x1, #1
    lsl x1, x1, #20
    mov x2, #0
    mov x8, #226
    svc #0
    cbnz x0, .Lfern_stack_guard_failed
    mov x9, #1
    lsl x9, x9, #30
    add x9, x19, x9
    sub sp, x9, #16
    mov x10, sp
    adrp x11, __fern_stack_top
    add x11, x11, :lo12:__fern_stack_top
    str x10, [x11]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #16
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_signal_stack_map_failed
    mov x9, #1
    lsl x9, x9, #16
    sub sp, sp, #32
    stp x0, xzr, [sp]
    str x9, [sp, #16]
    mov x0, sp
    mov x1, #0
    mov x8, #132
    svc #0
    cbnz x0, .Lfern_signal_stack_failed
    adrp x9, __fern_segv
    add x9, x9, :lo12:__fern_segv
    mov x10, #4
    movk x10, #0x800, lsl #16
    mov x11, #0x448
    stp x9, x10, [sp]
    stp xzr, x11, [sp, #16]
    bl .Lfern_fault_install
    cbnz x0, .Lfern_fault_handler_failed
    add sp, sp, #32
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    bl __fn_main
    mov x8, #94
    svc #0
__fn___fern_print_str:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_print_str.k:
__fn___fern_print_str.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___fern_print_str_0:
    ldr x9, [x0, #0]
    ldr x10, [x0, #8]
    sxtw x10, w10
    mov x11, #64
    mov x12, #1
    str x11, [sp, #-16]!
    str x12, [sp, #-16]!
    str x9, [sp, #-16]!
    str x10, [sp, #-16]!
    ldr x2, [sp], #16
    ldr x1, [sp], #16
    ldr x0, [sp], #16
    ldr x8, [sp], #16
    svc #0
    sxtw x0, w0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_concat:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_concat.k:
__fn___fern_str_concat.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_concat_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    add x9, x21, x22
    sxtw x23, w9
    mov x0, x23
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    ldr x9, [x19, #0]
    mov x2, x21
    mov x1, x9
    mov x0, x24
    cbz x2, .Lssa___fern_str_concat_mcd18
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb18
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc18:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct18
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc18
.Lssa___fern_str_concat_mct18:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd18
.Lssa___fern_str_concat_mcb18:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb18
.Lssa___fern_str_concat_mcd18:
    mov x0, #0
    sxtw x21, w21
    add x21, x24, x21
    ldr x9, [x20, #0]
    mov x2, x22
    mov x1, x9
    mov x0, x21
    cbz x2, .Lssa___fern_str_concat_mcd34
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb34
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc34:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct34
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc34
.Lssa___fern_str_concat_mct34:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd34
.Lssa___fern_str_concat_mcb34:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb34
.Lssa___fern_str_concat_mcd34:
    mov x0, #0
    mov x0, x24
    mov x1, x23
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_eq:
    ldr x0, [sp]
    ldr x9, [sp, #16]
__fn___fern_str_eq.r:
    cmp x0, x9
    b.eq .Lseq_yes
    ldr x4, [x0, #8]
    ldr x5, [x9, #8]
    cmp x4, x5
    b.ne .Lseq_no
    ldr x2, [x0]
    ldr x3, [x9]
    cmp x2, x3
    b.eq .Lseq_yes
    add x6, x2, x4
    add x7, x3, x4
    cmp x4, #8
    b.lo .Lseq_short
    sub x6, x6, #8
    sub x7, x7, #8
.Lseq_word:
    ldr x0, [x2]
    ldr x1, [x3]
    cmp x0, x1
    b.ne .Lseq_no
    add x2, x2, #8
    add x3, x3, #8
    cmp x2, x6
    b.lo .Lseq_word
    ldr x0, [x6]
    ldr x1, [x7]
    cmp x0, x1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_short:
    cbz x4, .Lseq_yes
    cmp x4, #4
    b.lo .Lseq_byte
    ldr w0, [x2]
    ldr w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #4
    sub x7, x7, #4
    ldr w0, [x6]
    ldr w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_byte:
    ldrb w0, [x2]
    ldrb w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #1
    sub x7, x7, #1
    ldrb w0, [x6]
    ldrb w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    cmp x4, #3
    b.lo .Lseq_yes
    ldrb w0, [x2, #1]
    ldrb w1, [x3, #1]
    cmp w0, w1
    b.ne .Lseq_no
.Lseq_yes:
    mov x0, #1
    ret
.Lseq_no:
    mov x0, #0
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .bss
    .align 3
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 3
    .globl __fern_alloc_count
__fern_alloc_count: .quad 0
    .align 3
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 3
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 3
__fern_rc_underflow: .quad 0
    .align 3
__fern_map_seed: .quad 0
    .align 3
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 3
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 3
__fern_freelist_shadow: .skip 524288
    .align 3
__fern_large_freelist_shadow: .skip 20480
    .text
.globl __fern_capw
__fern_capw:
    stp x9, x10, [sp, #-32]!
    str x11, [sp, #16]
    ldr x9, [sp, #32]
    cmp x9, #256
    b.ls .Lcapw_ret
    clz x10, x9
    mov x11, #61
    sub x10, x11, x10
    mov x11, #1
    lsl x11, x11, x10
    add x9, x9, x11
    sub x9, x9, #1
    neg x11, x11
    and x9, x9, x11
    mov x10, #0x10000
    cmp x9, x10
    b.lo .Lcapw_store
    mov x9, #65535
.Lcapw_store:
    str x9, [sp, #32]
.Lcapw_ret:
    ldr x11, [sp, #16]
    ldp x9, x10, [sp], #32
    ret
.globl __fern_alloc
.type __fern_alloc, %function
__fern_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    add x0, x0, #7
    lsr x3, x0, #3
    lsl x0, x3, #3
    adrp x1, __fern_alloc_count
    add x1, x1, :lo12:__fern_alloc_count
    ldr x2, [x1]
    add x2, x2, #1
    str x2, [x1]
    mov x2, #0x10000
    cmp x3, x2
    b.hs .Lalloc_large
    cmp x3, #256
    b.ls .L0
    str x3, [sp, #-16]!
    bl __fern_capw
    ldr x3, [sp], #16
.L0:
    lsl x0, x3, #3
    adrp x1, __fern_freelist
    add x1, x1, :lo12:__fern_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_large:
    mov x1, #1
    lsl x1, x1, #34
    cmp x0, x1
    b.hi .Lalloc_nofl
    mov x1, #1
    lsl x1, x1, #19
    cmp x0, x1
    csel x0, x1, x0, lo
    clz x1, x0
    mov x3, #61
    sub x3, x3, x1
    mov x1, #1
    lsl x1, x1, x3
    sub x1, x1, #1
    add x0, x0, x1
    bic x0, x0, x1
    clz x1, x0
    mov x3, #61
    sub x1, x3, x1
    lsr x3, x0, x1
    add x3, x3, x1, lsl #2
    sub x3, x3, #72
    adrp x1, __fern_large_freelist
    add x1, x1, :lo12:__fern_large_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_nofl:
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    ldr x2, [x1]
    cbnz x2, .Lalloc_inited
    stp x4, x5, [sp, #-16]!
    stp x8, x9, [sp, #-16]!
    mov x9, x0
    mov x0, #1
    lsl x0, x0, #28
    movz x1, #0
    movk x1, #4, lsl #32
    mov x2, #3
    mov x3, #0x4022
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    cmn x0, #0
    b.mi .Lalloc_map_fail
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    str x0, [x1]
    adrp x1, __fern_heap_base
    add x1, x1, :lo12:__fern_heap_base
    str x0, [x1]
    movz x2, #0
    movk x2, #4, lsl #32
    add x2, x0, x2
    adrp x3, __fern_heap_end
    add x3, x3, :lo12:__fern_heap_end
    str x2, [x3]
    mov x0, x9
    ldp x8, x9, [sp], #16
    ldp x4, x5, [sp], #16
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
.Lalloc_inited:
    ldr x2, [x1]
    adds x3, x2, x0
    b.cs __fern_alloc_size_abort
    str x4, [sp, #-16]!
    adrp x4, __fern_heap_end
    add x4, x4, :lo12:__fern_heap_end
    ldr x4, [x4]
    cmp x3, x4
    ldr x4, [sp], #16
    b.hi .Lalloc_oom
    str x3, [x1]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .text
.Lalloc_oom:
    adrp x1, .Lmsg_oom
    add x1, x1, :lo12:.Lmsg_oom
    mov x2, #43
    mov x0, #125
    b __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .text
.Lalloc_map_fail:
    neg x9, x0
    sub sp, sp, #96
    add x10, sp, #96
    mov x12, #10
    sub x10, x10, #1
    strb w12, [x10]
    mov x11, #41
    sub x10, x10, #1
    strb w11, [x10]
.Lmap_fail_digit:
    udiv x13, x9, x12
    msub x14, x13, x12, x9
    add x14, x14, #48
    sub x10, x10, #1
    strb w14, [x10]
    mov x9, x13
    cbnz x9, .Lmap_fail_digit
    adrp x15, .Lmsg_map_fail
    add x15, x15, :lo12:.Lmsg_map_fail
    add x15, x15, #42
    mov x11, #42
.Lmap_fail_copy:
    sub x15, x15, #1
    ldrb w14, [x15]
    sub x10, x10, #1
    strb w14, [x10]
    subs x11, x11, #1
    b.ne .Lmap_fail_copy
    mov x1, x10
    add x2, sp, #96
    sub x2, x2, x10
    mov x0, #123
    b __fern_report
.size __fern_alloc, .-__fern_alloc
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .text
__fern_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_oob_abort
.type __fern_oob_abort, %function
__fern_oob_abort:
    adrp x1, .Lmsg_arr_oob
    add x1, x1, :lo12:.Lmsg_arr_oob
    mov x2, #31
    b __fern_abort_134
.size __fern_oob_abort, .-__fern_oob_abort
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .text
__fern_str_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_str_oob_abort
.type __fern_str_oob_abort, %function
__fern_str_oob_abort:
    adrp x1, .Lmsg_str_oob
    add x1, x1, :lo12:.Lmsg_str_oob
    mov x2, #32
    b __fern_abort_134
.size __fern_str_oob_abort, .-__fern_str_oob_abort
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .text
__fern_slice_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_slice_abort
.type __fern_slice_abort, %function
__fern_slice_abort:
    adrp x1, .Lmsg_slice
    add x1, x1, :lo12:.Lmsg_slice
    mov x2, #32
    b __fern_abort_134
.size __fern_slice_abort, .-__fern_slice_abort
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .text
__fern_alloc_size_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_alloc_size_abort
.type __fern_alloc_size_abort, %function
__fern_alloc_size_abort:
    adrp x1, .Lmsg_alloc_size
    add x1, x1, :lo12:.Lmsg_alloc_size
    mov x2, #35
    b __fern_abort_134
.size __fern_alloc_size_abort, .-__fern_alloc_size_abort
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .text
.globl __fern_free_range_abort
.type __fern_free_range_abort, %function
__fern_free_range_abort:
    adrp x1, .Lmsg_free_range
    add x1, x1, :lo12:.Lmsg_free_range
    mov x2, #41
    b __fern_abort_134
.size __fern_free_range_abort, .-__fern_free_range_abort
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .text
__fern_double_free_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_double_free_abort
.type __fern_double_free_abort, %function
__fern_double_free_abort:
    adrp x1, .Lmsg_double_free
    add x1, x1, :lo12:.Lmsg_double_free
    mov x2, #45
    b __fern_abort_134
.size __fern_double_free_abort, .-__fern_double_free_abort
__fern_arr_box:
    movz x1, #65535
    movk x1, #4095, lsl #16
    cmp x0, x1
    b.ls .Larrbox_sized
    b __fern_alloc_size_abort_leaf
.Larrbox_sized:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    add x0, x0, #3
    lsl x0, x0, #3
    bl __fern_alloc
    ldr x1, [sp]
    str x1, [x0]
    mov w2, #1
    str w2, [x0, #8]
    str x1, [x0, #16]
    add x0, x0, #16
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
__fern_str_box:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x0, #24
    bl __fern_alloc
    mov x2, #1
    str x2, [x0]
    ldp x2, x3, [sp], #16
    str x2, [x0, #8]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fern_str_box_hdr:
    sub x2, x0, #24
    mov w3, #1
    str w3, [x2]
    mov w4, #32781
    movk w4, #29519, lsl #16
    stur w4, [x2, #4]
    str x0, [x2, #8]
    str x1, [x2, #16]
    add x0, x2, #8
    ret
__fn___alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    bl __fern_alloc
    ldp x29, x30, [sp], #16
    ret
__fn___free:
    ret
__fn___memset:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    ldr x2, [x29, #48]
    cbz x2, .Lfnmemset_done
.Lfnmemset_loop:
    strb w1, [x0], #1
    subs x2, x2, #1
    bne .Lfnmemset_loop
.Lfnmemset_done:
    ldp x29, x30, [sp], #16
    ret
__fn___load_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldrsw x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str w1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_i64:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str x1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___ptr_width:
    mov x0, #8
    ret
__fn___fern_rc_inc:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcinc_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcinc_ret
    and x0, x0, #0xfffffffffffffffd
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcinc_ret
    add w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcinc_ret:
    ldr x0, [sp]
    ret
__fn___fern_rc_dec:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcdec_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcdec_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcdec_ret
    cmp w1, #0
    bgt .Lshrcdec_dec
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w11, [x10]
    add w11, w11, #1
    str w11, [x10]
.Lshrcdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcdec_ret:
    ret
__fn___fern_rc_is_unique:
    ldr x2, [sp]
    mov x0, #0
    tbnz x2, #0, .Lshuniq_ret
    mov x9, #0x10000
    cmp x2, x9
    blo .Lshuniq_ret
    and x2, x2, #0xfffffffffffffffd
    ldur w3, [x2, #-8]
    tbnz w3, #31, .Lshuniq_ret
    cmp w3, #1
    bne .Lshuniq_ret
    mov x0, #1
.Lshuniq_ret:
    ret
__fn___fern_str_grow:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsg_body
__fn___fern_str_grow_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbnz x2, #63, .Lsg_no
    ldr x4, [x1, #8]
    cmp x3, x4
    b.gt .Lsg_no
    subs x3, x3, x2
    b.lt .Lsg_no
    ldr x1, [x1]
    add x1, x1, x2
.Lsg_body:
    tbnz x0, #0, .Lsg_no
    mov x9, #0x10000
    cmp x0, x9
    blo .Lsg_no
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.ne .Lsg_no
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbnz x9, .Lsg_no
    ldur w5, [x0, #-4]
    mov w6, #0x4F57
    movk w6, #0x4752, lsl #16
    cmp w5, w6
    b.ne .Lsg_fused
    add x6, x4, #39
    lsr x6, x6, #3
    ldur x7, [x0, #-16]
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_copy
.Lsg_fused:
    mov w6, #32781
    movk w6, #29519, lsl #16
    cmp w5, w6
    b.ne .Lsg_no
    add x5, x2, #31
    lsr x5, x5, #3
    add x6, x4, #31
    lsr x6, x6, #3
    cmp x6, x5
    b.eq .Lsg_copy
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lsg_large
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x7, x30, [sp], #16
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_fits
.Lsg_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsg_no
    lsl x7, x5, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x7, x7, #3
    cmp x6, x7
    b.hi .Lsg_no
.Lsg_fits:
.Lsg_copy:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsg_d
    cmp x3, #8
    b.lo .Lsg_b
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsg_w:
    cmp x5, x10
    b.hs .Lsg_t
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsg_w
.Lsg_t:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsg_d
.Lsg_b:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsg_b
.Lsg_d:
    mov x0, #1
    ret
.Lsg_no:
    mov x0, #0
    ret
__fn___fern_str_grow_fresh:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsgf_body
__fn___fern_str_grow_fresh_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbz x2, #63, .Lsgf_lo
    b __fern_slice_abort_leaf
.Lsgf_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lsgf_hi
    b __fern_slice_abort_leaf
.Lsgf_hi:
    subs x3, x3, x2
    b.ge .Lsgf_range
    b __fern_slice_abort_leaf
.Lsgf_range:
    ldr x1, [x1]
    add x1, x1, x2
.Lsgf_body:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbz x9, .Lsgf_sized
    b __fern_alloc_size_abort
.Lsgf_sized:
    add x5, x4, #39
    lsr x5, x5, #3
    add x6, x2, #31
    lsr x6, x6, #3
    lsl x6, x6, #1
    cmp x6, x5
    csel x6, x5, x6, lo
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lsgf_large
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
    b .Lsgf_alloc
.Lsgf_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsgf_alloc
    lsl x7, x6, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x6, x7, #3
.Lsgf_alloc:
    stp x0, x1, [sp, #-48]!
    stp x2, x3, [sp, #16]
    str x6, [sp, #32]
    lsl x0, x6, #3
    bl __fern_alloc
    ldr x6, [sp, #32]
    ldp x2, x3, [sp, #16]
    ldp x4, x1, [sp], #48
    str x6, [x0]
    mov w5, #1
    str w5, [x0, #8]
    mov w5, #0x4F57
    movk w5, #0x4752, lsl #16
    str w5, [x0, #12]
    add x5, x0, #32
    str x5, [x0, #16]
    add x6, x2, x3
    str x6, [x0, #24]
    ldr x6, [x4]
    cbz x2, .Lsgf_ad
    cmp x2, #8
    b.lo .Lsgf_ab
    add x9, x6, x2
    sub x9, x9, #8
    add x10, x5, x2
    sub x10, x10, #8
.Lsgf_aw:
    cmp x5, x10
    b.hs .Lsgf_at
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_aw
.Lsgf_at:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_ad
.Lsgf_ab:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x2, x2, #1
    cbnz x2, .Lsgf_ab
.Lsgf_ad:
    add x5, x0, #32
    ldr x2, [x0, #24]
    sub x2, x2, x3
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsgf_bd
    cmp x3, #8
    b.lo .Lsgf_bb
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsgf_bw:
    cmp x5, x10
    b.hs .Lsgf_bt
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_bw
.Lsgf_bt:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_bd
.Lsgf_bb:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsgf_bb
.Lsgf_bd:
    add x0, x0, #16
    ldp x29, x30, [sp], #16
    ret
__fn___fern_str_borrow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    mov x0, #24
    bl __fern_alloc
    mov w2, #1
    str w2, [x0]
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    stur w3, [x0, #4]
    ldr x2, [sp, #32]
    str x2, [x0, #8]
    ldr x3, [sp, #16]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fn___fern_alloc_reuse:
    ldr x0, [sp, #16]
    cbz x0, .Lsarelo_fresh
    ldr x1, [sp]
    ldur x2, [x0, #-16]
    cmp x2, x1
    beq .Lsarelo_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_arr_dec.r
    ldp x29, x30, [sp], #16
.Lsarelo_fresh:
    ldr x0, [sp]
    b __fern_arr_box
.Lsarelo_ret:
    ret
__fn___fern_rc_underflow_count:
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w0, [x10]
    ret
__fern_large_push:
    mov x3, #1
    lsl x3, x3, #34
    cmp x2, x3
    b.hi .Llpush_ret
    mov x3, #1
    lsl x3, x3, #19
    cmp x2, x3
    csel x2, x3, x2, lo
    clz x3, x2
    mov x4, #61
    sub x4, x4, x3
    mov x3, #1
    lsl x3, x3, x4
    sub x3, x3, #1
    add x2, x2, x3
    bic x2, x2, x3
    clz x3, x2
    mov x4, #61
    sub x3, x4, x3
    lsr x4, x2, x3
    add x4, x4, x3, lsl #2
    sub x4, x4, #72
    mov x2, x4
    adrp x3, __fern_large_freelist
    add x3, x3, :lo12:__fern_large_freelist
    ldr x4, [x3, x2, lsl #3]
    cmp x4, x1
    b.eq __fern_double_free_abort_leaf
    str x4, [x1]
    str x1, [x3, x2, lsl #3]
.Llpush_ret:
    ret
__fern_raw_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    cbz x0, .Lrawfree_done
    adrp x9, __fern_heap_base
    add x9, x9, :lo12:__fern_heap_base
    ldr x9, [x9]
    cmp x0, x9
    b.lo .Lrawfree_bad
    adrp x9, __fern_heap_end
    add x9, x9, :lo12:__fern_heap_end
    ldr x9, [x9]
    cmp x0, x9
    b.hs .Lrawfree_bad
    add x1, x1, #7
    lsr x5, x1, #3
    cbz x5, .Lrawfree_done
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lrawfree_b_large
    cmp x5, #256
    b.ls .L1
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x5, x30, [sp], #16
.L1:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x5, lsl #3]
    cmp x10, x0
    b.eq __fern_double_free_abort
    str x10, [x0]
    str x0, [x3, x5, lsl #3]
    b .Lrawfree_b_done
.Lrawfree_b_large:
    mov x1, x0
    lsl x2, x5, #3
    bl __fern_large_push
.Lrawfree_b_done:
.Lrawfree_done:
    ldp x29, x30, [sp], #16
    ret
.Lrawfree_bad:
    b __fern_free_range_abort
__fn___fern_arr_dec:
    ldr x0, [sp]
__fn___fern_arr_dec.r:
    cmp x0, #16, lsl #12
    blo .Larrdec_ret
__fn___fern_arr_dec.u:
    ldur w1, [x0, #-8]
    cmp w1, #1
    bne .Larrdec_shared
    stur wzr, [x0, #-8]
    ldur x1, [x0, #-16]
    add x1, x1, #3
    sub x2, x0, #16
    cmp x1, #256
    b.hi .Larrdec_big
.Larrdec_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Larrdec_ret:
    ret
.Larrdec_shared:
    tbnz w1, #31, .Larrdec_ret
    bgt .Larrdec_dec
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    ret
.Larrdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
    ret
.Larrdec_big:
    mov x9, #0x10000
    cmp x1, x9
    bhs .Larrdec_large
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
    b .Larrdec_push
.Larrdec_large:
    lsl x2, x1, #3
    sub x1, x0, #16
    b __fern_large_push
__fn___fern_str_free:
    ldr x0, [sp]
__fn___fern_str_free.r:
    tbnz x0, #0, .Lstrfree_ret
    cmp x0, #16, lsl #12
    blo .Lstrfree_ret
__fn___fern_str_free.u:
    mov x9, #0x10000
    ldur w4, [x0, #-8]
    cmp w4, #1
    bne .Lstrfree_shared
    ldur w2, [x0, #-4]
    mov w3, #32781
    movk w3, #29519, lsl #16
    cmp w2, w3
    beq .Lstrfree_fused
    mov w3, #0x4F57
    movk w3, #0x4752, lsl #16
    cmp w2, w3
    beq .Lstrfree_grown
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    cmp w2, w3
    beq .Lstrfree_box
    ldr x1, [x0]
    ldr x2, [x0, #8]
    cmp x1, x9
    blo .Lstrfree_box
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrfree_box
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrfree_box
    cmp x2, #0
    ble .Lstrfree_box
    add x2, x2, #7
    lsr x2, x2, #3
    cmp x2, x9
    bhs .Lstrfree_box
    cmp x2, #256
    b.ls .L2
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
.L2:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
.Lstrfree_box:
    stur wzr, [x0, #-8]
    sub x1, x0, #8
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
    b .Lstrfree_ret
.Lstrfree_grown:
    ldur x2, [x0, #-16]
    stur wzr, [x0, #-8]
    sub x1, x0, #16
    b .Lstrfree_block
.Lstrfree_fused:
    ldr x2, [x0, #8]
    add x2, x2, #7
    lsr x2, x2, #3
    add x2, x2, #3
    stur wzr, [x0, #-8]
    sub x1, x0, #8
.Lstrfree_block:
    cmp x2, #256
    b.hi .Lstrfree_fused_big
.Lstrfree_fused_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
    b .Lstrfree_ret
.Lstrfree_fused_big:
    cmp x2, x9
    bhs .Lstrfree_fused_large
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
    b .Lstrfree_fused_push
.Lstrfree_fused_large:
    lsl x2, x2, #3
    b __fern_large_push
.Lstrfree_shared:
    tbnz w4, #31, .Lstrfree_ret
    blt .Lstrfree_uf
    sub w4, w4, #1
    stur w4, [x0, #-8]
    ret
.Lstrfree_uf:
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    ldr x0, [sp]
    tbnz x0, #0, .Lstrvfree_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lstrvfree_ret
    ldur w4, [x0, #-8]
    tbnz w4, #31, .Lstrvfree_view
    b __fn___fern_str_free
.Lstrvfree_view:
    sub x1, x0, #8
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrvfree_ret
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrvfree_ret
    stur wzr, [x0, #-8]
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_arr_free.k:
__fn___fern_str_arr_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_arr_free_0:
    movz x9, #1, lsl #16
    cmp x19, x9
    b.lo .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    ldrsw x20, [x19]
.Lssa___fern_str_arr_free_4:
    mov x9, #0
.Lssa___fern_str_arr_free_15:
    cmp x9, x20
    b.ge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    add x21, x9, #1
    ldr x9, [x19, x21, lsl #3]
    tbnz x9, #0, .Lssa___fern_str_arr_free_rcdeck36
    cmp x9, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck36
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd36
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck36
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___fern_str_arr_free_rcdece36
.Lssa___fern_str_arr_free_rcdecd36:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___fern_str_arr_free_rcdeck36:
.Lssa___fern_str_arr_free_rcdece36:
    mov x9, x21
    cmp x9, x20
    b.lt .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    cmp x19, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck40
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd40
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck40
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___fern_str_arr_free_rcdece40
.Lssa___fern_str_arr_free_rcdecd40:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___fern_str_arr_free_rcdeck40:
.Lssa___fern_str_arr_free_rcdece40:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_drop_arr_ptr:
    ret
    .section .bss
    .align 8
__fern_envp: .quad 0
    .section .text
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_u8:
    .quad 0
    .text
.globl __fern_alloc_u8
.type __fern_alloc_u8, %function
__fern_alloc_u8:
    tbz w0, #31, .Lfern_alloc_u8_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_u8_sized:
    cbz w0, .Lfern_alloc_u8_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x0, x19
    bl __fern_arr_box
    add x2, x0, #8
    mov w1, w19
.Lfern_alloc_u8_zero:
    cbz x1, .Lfern_alloc_u8_done
    str xzr, [x2], #8
    sub x1, x1, #1
    b .Lfern_alloc_u8_zero
.Lfern_alloc_u8_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_u8_empty:
    adrp x0, .Lfern_empty_u8
    add x0, x0, :lo12:.Lfern_empty_u8
    ret
.size __fern_alloc_u8, .-__fern_alloc_u8
    .section .bss
    .align 8
__fern_sig_sp: .quad 0, 0
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
.Lmsg_illegal_instruction:
    .ascii "fern: illegal instruction\n"
.Lmsg_bus_error:
    .ascii "fern: bus error\n"
    .text
__fern_segv:
    cmp x0, #11
    b.ne .Lfern_fatal_signal
    ldr x9, [x1, #16]
    adrp x14, __fern_stack_top
    add x14, x14, :lo12:__fern_stack_top
    ldr x14, [x14]
    mov x15, #1
    lsl x15, x15, #30
    sub x14, x14, x15
    add x14, x14, #16
    sub x15, x9, x14
    mov x16, #1
    lsl x16, x16, #20
    cmp x15, x16
    b.hs .Lfern_segv_other
.Lfern_segv_overflow:
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_stack_overflow
    add x1, x1, :lo12:.Lmsg_stack_overflow
    mov x2, #21
    mov x0, #134
    b __fern_report
.Lfern_segv_other:
    stp x29, x30, [sp, #-16]!
    sub sp, sp, #32
    stp xzr, xzr, [sp]
    stp xzr, xzr, [sp, #16]
    bl .Lfern_fault_install
    add sp, sp, #32
    ldp x29, x30, [sp], #16
    ret
.Lfern_fault_install:
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x0, #11
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
    mov x0, #4
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
    mov x0, #7
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_install_done
.Lfern_fault_install_done:
    ret
.Lfern_fatal_signal:
    ldrsw x9, [x1, #8]
    cmp x9, #0
    b.le .Lfern_signal_sent
    mov x15, x0
    adrp x10, __fern_sig_sp
    add x10, x10, :lo12:__fern_sig_sp
    mov x9, sp
    str x9, [x10]
    str x30, [x10, #8]
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_illegal_instruction
    add x1, x1, :lo12:.Lmsg_illegal_instruction
    mov x2, #26
    cmp x15, #4
    b.eq .Lfern_fatal_report
    adrp x1, .Lmsg_bus_error
    add x1, x1, :lo12:.Lmsg_bus_error
    mov x2, #16
.Lfern_fatal_report:
    mov x0, #-1
    b __fern_report
.Lfern_signal_sent:
    add x0, x0, #128
    mov x8, #94
    svc #0
.Lfern_signal_resume:
    adrp x10, __fern_sig_sp
    add x10, x10, :lo12:__fern_sig_sp
    ldr x9, [x10]
    ldr x30, [x10, #8]
    mov sp, x9
    b .Lfern_segv_other
    .section .rodata
.Lfern_stack_map_failed_msg:
    .ascii "fern: could not map the stack\n"
    .text
.Lfern_stack_map_failed:
    adrp x1, .Lfern_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_stack_map_failed_msg
    mov x2, #30
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    adrp x1, .Lfern_stack_guard_failed_msg
    add x1, x1, :lo12:.Lfern_stack_guard_failed_msg
    mov x2, #40
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    adrp x1, .Lfern_signal_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_map_failed_msg
    mov x2, #37
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    adrp x1, .Lfern_signal_stack_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_failed_msg
    mov x2, #41
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    adrp x1, .Lfern_fault_handler_failed_msg
    add x1, x1, :lo12:.Lfern_fault_handler_failed_msg
    mov x2, #42
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=arm64-linux profile= harden=0 pie=0 sanitize=0 backtrace=1 size=0 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .bss
    .align 3
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .align 3
__fern_bt_floor: .quad 0
    .text
.globl __fern_report
.type __fern_report, %function
__fern_abort_134:
    mov x0, #134
__fern_report:
    mov x19, x0
    mov x0, #2
    mov x8, #64
    svc #0
    b __fern_bt_exit
.size __fern_report, .-__fern_report
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .text
    .globl __fern_bt_exit
__fern_bt_exit:
    adrp x1, .Lmsg_bt
    add x1, x1, :lo12:.Lmsg_bt
    mov x2, #11
    mov x0, #2
    mov x8, #64
    svc #0
    mov x20, x29
    mov x21, #64
    mov x22, sp
.Lbt_loop:
    cmp x20, x22
    b.lo .Lbt_done
    and x23, x20, #7
    cbnz x23, .Lbt_done
    ldr x1, [x20, #8]
    cmp x1, #16, lsl #12
    b.lo .Lbt_done
    bl .Lbt_hex
    adrp x24, __fern_bt_floor
    add x24, x24, :lo12:__fern_bt_floor
    ldr x22, [x24]
    str xzr, [x24]
    add x23, x20, #8
    cmp x22, #0
    csel x22, x23, x22, eq
    ldr x20, [x20]
    adrp x24, __fern_stack_top
    add x24, x24, :lo12:__fern_stack_top
    ldr x24, [x24]
    cbz x24, .Lbt_next
    cmp x20, x24
    b.hs .Lbt_done
.Lbt_next:
    subs x21, x21, #1
    b.ne .Lbt_loop
.Lbt_done:
    tbnz x19, #63, .Lfern_signal_resume
    mov x0, x19
    mov x8, #94
    svc #0
.Lbt_hex:
    sub sp, sp, #32
    mov w2, #0x2020
    movk w2, #0x7830, lsl #16
    str w2, [sp]
    mov w2, #10
    strb w2, [sp, #20]
    mov x3, #16
    add x4, sp, #3
.Lbt_hloop:
    and x2, x1, #15
    cmp x2, #10
    add x5, x2, #87
    add x2, x2, #48
    csel x2, x5, x2, hs
    strb w2, [x4, x3]
    lsr x1, x1, #4
    subs x3, x3, #1
    b.ne .Lbt_hloop
    mov x0, #2
    mov x1, sp
    mov x2, #21
    mov x8, #64
    svc #0
    add sp, sp, #32
    ret
__fern_arr_push:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Larr_push_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_slow_ok
    tbz w3, #31, .Larr_push_slow
.Larr_push_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Larr_push_slow:
.Larr_push_frame:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_rc_ok
    tbnz w2, #31, .Larr_push_rc_ok
    b .Larr_push_grow
.Larr_push_rc_ok:
    cmp x21, x22
    b.ge .Larr_push_grow
    add x1, x21, #1
    str x20, [x19, x1, lsl #3]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_ret
.Larr_push_grow:
    mov x2, x22
    cmp x21, x22
    b.lt .Larr_push_shared_cliff
    cmp x22, #0
    b.ne .Larr_push_dbl
    mov x2, #4
    b .Larr_push_cap
.Larr_push_shared_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21, lsl #3
    str x4, [x3]
    b .Larr_push_cap
.Larr_push_dbl:
    lsl x2, x22, #1
.Larr_push_cap:
    add x9, x21, #1
    cmp x2, x9
    csel x2, x2, x9, hs
    mov x22, x2
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Larr_push_copy4:
    cmp x4, #4
    b.lt .Larr_push_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Larr_push_copy4
.Larr_push_copy1:
    cbz x4, .Larr_push_copy_done
.Larr_push_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Larr_push_copy1_loop
.Larr_push_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
.Larr_push_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lapo_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapo_slow_ok
    tbz w3, #31, .Lapo_slow
.Lapo_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Lapo_slow:
    ldr x2, [x0]
    cbnz x2, .Lapo_grow
    ldur x2, [x0, #-16]
    cbnz x2, .Lapo_grow
    ldur w2, [x0, #-8]
    tbz w2, #31, .Lapo_grow
    b .Larr_push_slow
.Lapo_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    bl .Larr_push_slow
    cmp x0, x19
    beq .Lapo_ret
    mov x9, #0x10000
    cmp x19, x9
    blo .Lapo_ret
    ldur w1, [x19, #-8]
    tbnz w1, #31, .Lapo_ret
    cmp w1, #1
    bne .Lapo_ret
    ldur x1, [x19, #-16]
    add x1, x1, #3
    mov x9, #0x10000
    cmp x1, x9
    bhs .Lapo_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L3
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L3:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapo_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapo_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapo_ret
    .section .data.rel.ro
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .text
__fern_alloc_bytes:
    tbz w0, #31, .Lfern_alloc_bytes_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_bytes_sized:
    cbz w0, .Lfern_alloc_bytes_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    sxtw x19, w0
    add x0, x19, #7
    lsr x0, x0, #3
    mov x20, x0
    bl __fern_arr_box
    str x19, [x0]
    add x2, x0, #8
.Lfern_alloc_bytes_zero:
    cbz x20, .Lfern_alloc_bytes_done
    str xzr, [x2], #8
    sub x20, x20, #1
    b .Lfern_alloc_bytes_zero
.Lfern_alloc_bytes_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_bytes_empty:
    adrp x0, .Lfern_empty_bytes
    add x0, x0, :lo12:.Lfern_empty_bytes
    ret
__fn___fern_arr_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_arr_slice.k:
__fn___fern_arr_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_arr_slice_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x10, x9
    csel x11, x11, x12, gt
    mov x12, #1
    cmp x20, #0
    csel x12, x12, x11, lt
    mov x11, #1
    cmp x20, x10
    csel x11, x11, x12, gt
    cmp x11, #1
    b.ne .Lssa___fern_arr_slice_5
.Lssa___fern_arr_slice_7:
    bl __fern_slice_abort
.Lssa___fern_arr_slice_5:
    sub x10, x10, x20
    sxtw x21, w10
    mov x0, x21
    bl __fern_arr_box
    mov x22, x0
    add x10, x22, #8
    add x19, x19, #8
.Lssa___fern_arr_slice_4:
.Lssa___fern_arr_slice_45:
    cmp x20, #0
    b.le .Lssa___fern_arr_slice_2
.Lssa___fern_arr_slice_49:
    movz x11, #2048, lsl #16
    movz x12, #2048, lsl #16
    cmp x20, x11
    csel x12, x12, x20, gt
    lsl x11, x12, #3
    sxtw x11, w11
    add x19, x19, x11
    sub x20, x20, x12
    sxtw x20, w20
    cmp x20, #0
    b.gt .Lssa___fern_arr_slice_49
.Lssa___fern_arr_slice_2:
    mov x20, x10
.Lssa___fern_arr_slice_61:
    cmp x21, #0
    b.le .Lssa___fern_arr_slice_1
.Lssa___fern_arr_slice_65:
    movz x10, #2048, lsl #16
    movz x12, #2048, lsl #16
    cmp x21, x10
    csel x23, x12, x21, gt
    lsl x12, x23, #3
    sxtw x24, w12
    mov x2, x24
    mov x1, x19
    mov x0, x20
    cbz x2, .Lssa___fern_arr_slice_mcd211
    cmp x2, #8
    b.lo .Lssa___fern_arr_slice_mcb211
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_arr_slice_mc211:
    cmp x0, x10
    b.hs .Lssa___fern_arr_slice_mct211
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_arr_slice_mc211
.Lssa___fern_arr_slice_mct211:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_arr_slice_mcd211
.Lssa___fern_arr_slice_mcb211:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_arr_slice_mcb211
.Lssa___fern_arr_slice_mcd211:
    mov x0, #0
    add x20, x20, x24
    add x19, x19, x24
    sub x21, x21, x23
    sxtw x21, w21
    cmp x21, #0
    b.gt .Lssa___fern_arr_slice_65
.Lssa___fern_arr_slice_1:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_string_from_bytes_u8.k:
__fn___fern_string_from_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_string_from_bytes_u8_0:
    ldr x20, [x19, #0]
    mov x0, x20
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x21, x0
    add x19, x19, #8
    mov x2, x20
    mov x1, x19
    mov x0, x21
    cbz x2, .Lssa___fern_string_from_bytes_u8_mcd14
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_u8_mcb14
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_u8_mc14:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_u8_mct14
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_u8_mc14
.Lssa___fern_string_from_bytes_u8_mct14:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_u8_mcd14
.Lssa___fern_string_from_bytes_u8_mcb14:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_u8_mcb14
.Lssa___fern_string_from_bytes_u8_mcd14:
    mov x0, #0
    mov x0, x21
    mov x1, x20
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
    .section .rodata
.S0: .ascii "frame__VideoError$frame__Header"
.S1: .ascii "frame__VideoError$frame__Truncated"
.S2: .ascii "frame__VideoError$frame__Unsupported"
.S3: .ascii "frame__VideoError$frame__Limit"
.S4: .ascii "frame__VideoError$frame__Buffer"
.S5: .ascii "frame__VideoError$frame__Platform"
.S6: .ascii "frame__VideoError$frame__State"
.S7: .ascii "qtrle__Span"
.S8: .ascii "qtrle__Row"
.S9: .ascii "frame__Frame"
.S10: .ascii "codec__DecodeErrorKind$codec__InvalidByte"
.S11: .ascii "codec__DecodeErrorKind$codec__InvalidLength"
.S12: .ascii "codec__DecodeErrorKind$codec__InvalidPadding"
.S13: .ascii "codec__DecodeErrorKind$codec__NonZeroTrailingBits"
.S14: .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
.S15: .ascii "video_vectors__Vector"
.S16: .ascii "0000000d0000010147515bff00"
.S17: .ascii "0000000d00000101fa0102ff00"
.S18: .ascii "00000007000000"
.S19: .ascii "0000000d00000101141e28ff00"
.S20: .ascii "0000000e000001012547515bff00"
.S21: .ascii "0000000e0000010113fa0102ff00"
.S22: .ascii "0000000e0000010100141e28ff00"
.S23: .ascii "0000001b0000018047515b0147515bff018047515b0147515bff00"
.S24: .ascii "00000017000800010000000100004101fa01020041ff00"
.S25: .ascii "00000017000800000000000100000101141e280081ff00"
.S26: .ascii "0000001f000001802547515b012547515bff01802547515b012547515bff00"
.S27: .ascii "0000001800080001000000010000410113fa01020041ff00"
.S28: .ascii "0000001800080000000000010000010100141e280081ff00"
.S29: .ascii "000009760000018047515bfe47515b038090dbf3c65ffadc007fb5267bd0eb774f0e1b906485af78d40cb8b656d9ae75a279c42f47f8eabe09cced935f9e4da0c6a523f2aafeeb77bffa413987b89af7818dfc08c5d0d82efdbb3eafe773b4bd15a48973ddff1a40fb98e89efa3bc8ec1a0df90d8b29ab9da8973fe0e8bf4abb062951f0c3fe72b4bb5a472d93466e9221f407d74768528696eed711ce3b23f9811ba12d41a39e484ed98f819c6e1bc3f98d1aab2811993f0c5c832eb34edc47a067ea5e85e1d4908e1bb9a7c4a0bf9dfc96ed504709c625abbf3bc0a41a6f0f57a65670fb08c742f1a4e3b3d3c9fe4aa9ffb14e986d215f5aac90bb066885ee8bc0ee77af392245f848cd8300f5e59fcba207e185e229756b9699bc8434d3b297ba022c7e6ff9f10d6e5bd3fc953a402f62f5a2f94eb2abad769aedb11e60737fed2c9251a1edcb78251649274c5dd1029af7bd38c45f471e6e1a395025c927e6de93d1dfa776db84471765b5ae008bee34c59f2743937a19e40a5ac30d9bc1c39d7205c7c892613cf8cd7fea1a987ab13d9a0427e06d8047515bfe47515b04e33358d95a88aeb40e4b18c97f9c7627277e6b264e120cdc0cbd2ebf32a6facca0477a3f5ba58f83b53b481edeb30c7eec8e5f18baa9a9db1b9955a032621c60fe3bb1490b7dca65e2366281ed2a354d09245183ef498cdedff148c959904c138da89b1c5ee43e11b0070b4730e1551e8601ab74f20de75e8c64af07dc0764213b646bda967d6d3e30c67be622124cf181ff086456b747993a5a1a42c110d15fcbcd5920dac0e2cb0ab95551a58b866920093e18510e01a15457e3c731386ebdc92b07f0120fc38ec3919207e65782240fdbbbddde9810f05df9d660b7439de2e011c65220405b0892827f20c0018e5d65a23ac0b01ab47594ab334ba09c986d95a9d0e75693eb53834ff33215fca87ae47edbdd04e1ca739e634f99476f55f556c681d4cf4519c736aac002ed57853a73f49ab2dbb360b97d59acc82dc3a7dbd64e7f4dfb57e0e26657535980808cea9af5fe2c5d3bf283728c4b62ce9ff98b64b9188046f625274c394422a1e59afe9e832a7a06b06f55e3fb8a9c643667e2329b10c866ec3f47515bff018047515bfe47515b0353d728371dab8f5cd17fe936c0b87507f644f0b3f1f047ff1491aba52aa16c4c1851c46739ef3956aa556282a567eb7e112db7aece25560a2be7d66ec248af82947c0d7c2fc4b824af63ece512ae89319a32132f7d60132bf88010886da5fbe70f8e70e829e626cab9d10acf88d813f1b30c8d2acfabe33d4fec1d589a994b88b5667239054955745630a3f4da7649a39036ffd6e53919240b8fbb9a1200ef53d5df7248a6a69a19f20ada00b85ab1050eeebee4d18eed30c4701a6b60dbbfa4951ba178b537313e6622724f6124ceaa1f1dbae7c9b525cb993bffdcc42bbad78bcab2d3e1c40761aa877440b5d5c91b1e33d2cdf9396c674e881cb0733c7ef5df3067f38dd957a34466abec088568fe50fbf3e735fb110665ffb3cace6261782b4a50d74ad8cc6189c21cbe49a80d3424c0778088109931f3ad3b305220b994c37f243fcd95b71fdaa1d5b0df83246cbccd18950dee4fb51cd158b9e3fec6674cb6ec1c8d5bfc48a63d4aa77ff6af238857f23ea914e6ac0276dc3b5e395de9d19d67070092f78047515bfe47515b046b3714a04d994ab8859c72a57f1050022b08255005b66ab35aef3d0306732baf3e9c6763c245e7abdc632f98c5ecef3f03de28cf0552f698ef9969c080e71c8209a7824074d70f07ded9b6183534193a281ab9fd007c942540fe3f01e9166ab4095b147e5741b6b0d8c05d116043a835f5b48492cd4bd7ada6a167a1720aec79062b16f9c1c4e65324bb72fe2014f8a2d37047207e02db2f48fb4b36433a901d89282a4eb413e605b29e3e9da200a3a34dd0ed4b06c71b3560b3ca89afe7e68c62734db7ffbf633a554a81402a7bb139c03b73f90e2f37b102d7680e105e3da1b40a2c21cf2eafca784045c61d8de631b450f54290e050d152aed48015222889896761e400a0b69096d350f3feacbc5e2dd752ef1c7a611428f9e54a2e071d93ca5d4ac1a40ea01cd625b2870484530d5564f27ef06448c56e67a64c34b51e13f0388163edcc2c12fab9a871e65636f3a4239b34fa3355beb4b03125f703cdc4a72d28a6827ce0b08a8955199080659f702e877142b94dc4cf9890ae8b7870d24236739a32776e47515bff018047515bfe47515b03b012de68471b91437b7f8ab4b07f74f42b6bd1e5cd7316cba803c508c633f190d3447d961c2f8ddff7c36e6e605139801f3e447bc8a37cac243f9bcd0557cc2270768f2b96f1206b624a3a58dcec5b945c8a35090b9ddadf4df5d5fae9710767128773bdbb39303f66472eedce7cc935f6c5e088d3f24580d06f61cbc10899806f94c392edf18a4441ff50315694b37a3ac999a39bad38b06a9310040ab7752c89cec5f07577e248f270546342cdac668d6372c0c414c50c0df4df62b8bb219696a4ef2c42e49440d223ba3cbb371906a6463fd5ac805640c7f46b1e57c092bc76f5235f8f1ff439c52b836860e6a0d926abed5a5704451e7df72804e0213dc5ca214c3bea0dd42551dd3efe6aa64c6c2d4b1d7c4ee9c0c9a4383ab3e015bb9eeaf34d2b9b7149738f0fa3097921ac67c494edc6df1e31f38fd6a901ab83dbe3f165e064019713be60f0055f07480784e1a207a140d0a176666b943786fa6dee061623ca7cb3b8e881e6c2295f9e3d264443f2a3a72b16177a67e53be77ff5680d8155ba35074e8047515bfe47515b04a55abd472d0676bb247063a57fd44ae1e275f6cb2b85f6f769a32cc8e8ab43d604222b17bc4085741a2621fa84a07657f2f0482b7b590460b4e249f69fd59a71abc3a097c90b35f19816d8085226eaccc5820759efdfd6f651f915b962e8c1e7fb066b7ebe1995af322388cf4d552c24bcc51e630055cad2bac075add0c9a55c7ae545985709af1c3bfa5d2e1374b43d7794cdb56ee3bad923e83d2aaf7418fcb9bf71025264f327d1ee2eb5b2a874da354cfdaff30246e5050ef9de37443c8568aeb7cf9e6c74d5bb317a85c4fdb9f76c3797af803683bddc1c6c221f18582345b7b2bdc3001753a75bea3baf58c92ccd5db2ce5ea8c12c68fe279d8ef7a81712f291188accb8a1db85d6f266ae4fad3d26231ec7bbd9643a462eb49cb017e0a63187b012cda204de4fce6f0c31bc5ab1f5606fb3260520ceb35827533f5a95ec99186ffe00861a4272c6c3604c058df3d03f77bf5018370c246c373ed60fc26285027b7a44e3c7b40c18c077e07ab36510378e6a3b567301c6b3fe9b2c5e61b386232159e52147515bff00"
.S30: .ascii "0000001b00080001000000010000ff000701fa010200ff0007ff00"
.S31: .ascii "0000001b000800000000000100000101141e2800ff00ff000dff00"
.S32: .ascii "00000c91000001802547515bfe2547515b038e8090db95f3c65f9cfadc007fa3b5267baad0eb77b14f0e1bb8906485bfaf78d4c60cb8b6cd56d9aed475a279dbc42f47e2f8eabee909ccedf0935f9ef74da0c6fea523f205aafeeb0c77bffa134139871ab89af721818dfc2808c5d02fd82efd36bb3eaf3de773b444bd15a44b8973dd52ff1a4059fb98e8609efa3b67c8ec1a6e0df90d758b29ab7c9da897833fe0e88abf4abb9106295198f0c3fe9f72b4bba65a472dad93466eb49221f4bb07d747c2685286c996eed7d011ce3bd723f981de1ba12de541a39eec484ed9f38f819cfa6e1bc301f98d1a08ab28110f993f0c165c832e1db34edc2447a0672bea5e8532e1d490398e1bb940a7c4a047bf9dfc4e96ed50554709c65c25abbf633bc0a46a1a6f0f7157a6567870fb087fc742f186a4e3b38dd3c9fe944aa9ff9bb14e98a26d215fa95aac90b0bb0668b785ee8bbec0ee77c5af3922cc45f848d3cd8300daf5e59fe1cba207e8e185e2ef29756bf69699bcfd8434d304b297ba0b022c7e126ff9f1190d6e5b20d3fc95273a402f2e62f5a235f94eb23cabad76439aedb14a1e6073517fed2c589251a15fedcb78662516496d274c5d74d1029a7bf7bd3882c45f47891e6e1a9039502597c927e69ede93d1a5dfa776acdb8447b31765b5baae008bc1ee34c5c89f2743cf937a19d6e40a5addc30d9be4c1c39deb7205c7f2c89261f93cf8cd007fea1a07987ab10e3d9a041527e06d802547515bfe2547515b04aae33358b1d95a88b8aeb40ebf4b18c97fc69c7627cd277e6bd4264e12db0cdc0ce2bd2ebfe932a6faf0cca047f77a3f5bfea58f8305b53b480c1edeb3130c7eec1a8e5f1821baa9a928db1b992f55a03236621c603dfe3bb144490b7d4bca65e25236628159ed2a35604d0924675183ef6e498cde75dff1487cc95990834c138d8aa89b1c915ee43e9811b0079f0b4730a6e1551ead8601abb474f20dbbe75e8cc264af07c9dc0764d0213b64d76bda96de7d6d3ee530c67bece62212f34cf181faff08640156b74708993a5a0f1a42c11610d15f1dcbcd592420dac02be2cb0a32b9555139a58b8640692009473e18514e0e01a1555457e35cc73138636ebdc96a2b07f071120fc3788ec3917f9207e6865782248d0fdbbb94ddde989b10f05da2f9d660a9b7439db0e2e011b7c65220be405b08c592827fcc20c001d38e5d65daa23ac0e1b01ab4e87594abef334ba0f69c986dfd95a9d004e756930beb5383124ff3321915fca8207ae47e27dbdd042ee1ca73359e634f3c99476f4355f5564ac681d451cf451958c736aa5fc002ed6657853a6d73f49a74b2dbb37b60b97d8259acc8892dc3a790dbd64e977f4dfb9e57e0e2a5665753ac598080b38cea9abaf5fe2cc15d3bf2c883728ccf4b62ced69ff98bdd64b918e48046f6eb25274cf2394422f9a1e59a00fe9e83072a7a060eb06f5515e3fb8a1c9c64362367e2322a9b10c83166ec3f2547515bff01802547515bfe2547515b03ad53d728b4371dabbb8f5cd17fc2e936c0c9b87507d0f644f0d7b3f1f0de47ff14e591aba5ec2aa16cf34c1851fac4673901ef395608aa55620f82a56716eb7e111d2db7ae24ce25562b0a2be732d66ec23948af8240947c0d477c2fc44eb824af5563ece55c12ae8963319a326a132f7d7160132b78f880107f886da586fbe70f8d8e70e89429e6269bcab9d1a20acf88a9d813f1b0b30c8db72acfabbee33d4fc5ec1d58cc9a994bd388b566da723905e1495574e85630a3eff4da76f649a390fd36ffd604e539190b240b8f12bb9a121900ef5320d5df722748a6a62e9a19f2350ada003cb85ab143050eee4abee4d1518eed3058c4701a5f6b60db66bfa4956d1ba17874b537317b3e662282724f618924ceaa901f1dba97e7c9b59e25cb99a53bffdcacc42bbab3d78bcabab2d3e1c1c40761c8aa8774cf40b5d5d6c91b1edd33d2cde4f9396ceb674e88f21cb073f93c7ef500df306707f38dd90e57a3441566abec1c08856823fe50fb2af3e73531fb11063865ffb33fcace624661782b4d4a50d7544ad8cc5b6189c2621cbe4969a80d347024c077778088107e9931f385ad3b308c5220b99394c37f9a243fcda195b71fa8daa1d5afb0df83b6246cbcbdcd1895c40dee4fcbb51cd1d258b9e3d9fec667e04cb6ece71c8d5beefc48a6f53d4aa7fc7ff6af032388570af23ea91114e6ac180276dc1f3b5e39265de9d12d9d6707340092f7802547515bfe2547515b04c96b3714d0a04d99d74ab885de9c72a57fe5105002ec2b0825f35005b6fa6ab35a01ef3d030806732b0faf3e9c166763c21d45e7ab24dc632f2b98c5ec32ef3f0339de28cf400552f64798ef994e69c08055e71c825c09a782634074d76a0f07de71d9b618783534197f3a281a86b9fd008d7c94259440fe3f9b01e916a26ab409a95b147eb05741b6b7b0d8c0be5d1160c543a835ccf5b484d392cd4bdad7ada6e1a167a1e8720aecef79062bf616f9c1fdc4e6530424bb720bfe201412f8a2d319704720207e02db272f48fb2e4b3643353a901d3c89282a434eb4134ae605b2519e3e9d58a200a35fa34dd066ed4b066dc71b357460b3ca7b89afe782e68c6289734db790ffbf63973a554a9e81402aa57bb139acc03b73b3f90e2fba37b102c1d7680ec8105e3dcfa1b40ad62c21cfdd2eafcae4784045ebc61d8df2e631b4f950f5420090e05007d152ae0ed48015152228891c89676123e400a02ab6909631d350f338feacbc3f5e2dd74652ef1c4d7a61145428f9e55b4a2e07621d93ca695d4ac170a40ea0771cd6257eb287048584530d8c5564f2937ef0649a48c56ea167a64ca834b51eaf13f038b68163edbdcc2c12c4fab9a8cb71e656d236f3a4d9239b34e0fa3355e7beb4b0ee3125f7f503cdc4fca72d2803a6827c0ae0b08a11895519189080651f9f702e268771422db94dc434cf98903bae8b784270d2424936739a5032776e2547515bff01802547515bfe2547515b03ccb012ded368471bda91437b7fe18ab4b0e87f74f4ef2b6bd1f6e5cd73fd16cba80403c5080bc633f11290d344197d961c202f8ddf27f7c36e2e6e60513539801f3c3e447b43c8a37c4aac243f519bcd055857cc225f70768f662b96f16d206b62744a3a587bdcec5b82945c8a8935090b909ddadf974df5d59efae971a5076712ac8773bdb3bb3930ba3f6647c12eedcec87cc935cff6c5e0d688d3f2dd4580d0e46f61cbebc10899f2806f94f9c392ed00f18a440741ff500e31569415b37a3a1cc999a3239bad382ab06a933110040a38b7752c3f89cec546f075774de248f2547054635b42cdac62668d636972c0c47014c50c770df4df7e62b8bb852196968ca4ef2c9342e4949a40d223a1ba3cbba8371906afa6463fb6d5ac80bd5640c7c4f46b1ecb57c092d2bc76f5d9235f8fe01ff439e7c52b83ee6860e6f5a0d926fcabed5a035704450a1e7df7112804e018213dc51fca214c263bea0d2dd4255134dd3efe3b6aa64c426c2d4b491d7c4e50e9c0c957a4383a5eb3e01565bb9eea6cf34d2b739b71497a738f0f81a309798821ac678fc494ed96c6df1e9d31f38fa4d6a901abab83dbb2e3f165b9e06401c09713bec760f005ce5f0748d50784e1dca207a1e340d0a1ea76666bf1943786f8fa6deeff06162306ca7cb30db8e88114e6c2291b5f9e3d2226444329f2a3a7302b1617377a67e53e3be77f45f5680d4c8155ba5335074e802547515bfe2547515b04e8a55abdef472d06f676bb24fd7063a57f04d44ae10be275f612cb2b8519f6f76920a32cc827e8ab432ed60422352b17bc3c408574431a26214afa84a0517657f258f0482b5f7b59046660b4e26d49f69f74d59a717babc3a08297c90b8935f1989016d808975226ea9eccc582a50759efacdfd6f6b351f915bab962e8c1c1e7fbc8066b7ecfbe1995d6af3223dd88cf4de4552c24ebbcc51ef2630055f9cad2ba00c075ad07d0c9a50e5c7ae5154598571c09af1c233bfa5d2a2e137431b43d773894cdb53f6ee3ba46d923e84d3d2aaf547418fc5bb9bf716202526469f327d170ee2eb577b2a8747eda354c85fdaff38c0246e593050ef99ade3744a13c8568a8aeb7cfaf9e6c74b6d5bb31bd7a85c4c4fdb9f7cb6c3797d2af8036d983bddce01c6c22e71f1858ee2345b7f5b2bdc3fc00175303a75bea0a3baf5811c92ccd185db2ce1f5ea8c1262c68fe2d279d8e34f7a8173b12f29142188acc49b8a1db5085d6f25766ae4f5ead3d2665231ec76cbbd964733a462e7ab49cb08117e0a6883187b08f12cda29604de4f9dce6f0ca431bc5aabb1f560b26fb326b90520cec0b35827c7533f5ace95ec99d5186ffedc00861ae34272c6eac3604cf1058df3f8d03f77ffbf501806370c240d6c373e14d60fc21b628502227b7a4429e3c7b4300c18c03777e07a3eb3651045378e6a4c3b56735301c6b35afe9b2c615e61b3688623216f59e5212547515bff00"
.S33: .ascii "0000001c00080001000000010000ff00070113fa010200ff0007ff00"
.S34: .ascii "0000001c00080000000000010000010100141e2800ff00ff000dff00"
.S35: .ascii "frame__Format"
.S36: .ascii " "
.S37: .ascii "\n"
.S38: .ascii ""
    .section .data
    .balign 8
.Lfern_relanchor:
    .quad .Lfern_relanchor
    .section .data.rel.ro
    .balign 8
.Lfern_sbox_begin:
    .section .data.rel.ro
    .balign 8
    .quad -1
.SB0:
    .quad .S0
    .quad 31
    .quad -1
.SB1:
    .quad .S1
    .quad 34
    .quad -1
.SB2:
    .quad .S2
    .quad 36
    .quad -1
.SB3:
    .quad .S3
    .quad 30
    .quad -1
.SB4:
    .quad .S4
    .quad 31
    .quad -1
.SB5:
    .quad .S5
    .quad 33
    .quad -1
.SB6:
    .quad .S6
    .quad 30
    .quad -1
.SB7:
    .quad .S7
    .quad 11
    .quad -1
.SB8:
    .quad .S8
    .quad 10
    .quad -1
.SB9:
    .quad .S9
    .quad 12
    .quad -1
.SB10:
    .quad .S10
    .quad 41
    .quad -1
.SB11:
    .quad .S11
    .quad 43
    .quad -1
.SB12:
    .quad .S12
    .quad 44
    .quad -1
.SB13:
    .quad .S13
    .quad 49
    .quad -1
.SB14:
    .quad .S14
    .quad 200
    .quad -1
.SB15:
    .quad .S15
    .quad 21
    .quad -1
.SB16:
    .quad .S16
    .quad 26
    .quad -1
.SB17:
    .quad .S17
    .quad 26
    .quad -1
.SB18:
    .quad .S18
    .quad 14
    .quad -1
.SB19:
    .quad .S19
    .quad 26
    .quad -1
.SB20:
    .quad .S20
    .quad 28
    .quad -1
.SB21:
    .quad .S21
    .quad 28
    .quad -1
.SB22:
    .quad .S22
    .quad 28
    .quad -1
.SB23:
    .quad .S23
    .quad 54
    .quad -1
.SB24:
    .quad .S24
    .quad 46
    .quad -1
.SB25:
    .quad .S25
    .quad 46
    .quad -1
.SB26:
    .quad .S26
    .quad 62
    .quad -1
.SB27:
    .quad .S27
    .quad 48
    .quad -1
.SB28:
    .quad .S28
    .quad 48
    .quad -1
.SB29:
    .quad .S29
    .quad 4844
    .quad -1
.SB30:
    .quad .S30
    .quad 54
    .quad -1
.SB31:
    .quad .S31
    .quad 54
    .quad -1
.SB32:
    .quad .S32
    .quad 6434
    .quad -1
.SB33:
    .quad .S33
    .quad 56
    .quad -1
.SB34:
    .quad .S34
    .quad 56
    .quad -1
.SB35:
    .quad .S35
    .quad 13
    .quad -1
.SB36:
    .quad .S36
    .quad 1
    .quad -1
.SB37:
    .quad .S37
    .quad 1
    .quad -1
.SB38:
    .quad .S38
    .quad 0
.Lfern_sbox_end:
    .section .data.rel.ro
    .balign 8
    .quad 4
    .quad -1
.K5:
    .quad 4
.K5_0:
    .quad .SB16
.K5_1:
    .quad .SB17
.K5_2:
    .quad .SB18
.K5_3:
    .quad .SB19
    .quad 4
    .quad -1
.K6:
    .quad 4
    .quad 3582830273
    .quad 2953281414
    .quad 2953281414
    .quad 93996388
    .quad 4
    .quad -1
.K8:
    .quad 4
.K8_0:
    .quad .SB20
.K8_1:
    .quad .SB21
.K8_2:
    .quad .SB18
.K8_3:
    .quad .SB22
    .quad 4
    .quad -1
.K9:
    .quad 4
    .quad 2623864636
    .quad 749633798
    .quad 749633798
    .quad 3684647829
    .quad 4
    .quad -1
.K11:
    .quad 4
.K11_0:
    .quad .SB23
.K11_1:
    .quad .SB24
.K11_2:
    .quad .SB18
.K11_3:
    .quad .SB25
    .quad 4
    .quad -1
.K12:
    .quad 4
    .quad 3218467530
    .quad 2919402609
    .quad 2919402609
    .quad 1391715213
    .quad 4
    .quad -1
.K14:
    .quad 4
.K14_0:
    .quad .SB26
.K14_1:
    .quad .SB27
.K14_2:
    .quad .SB18
.K14_3:
    .quad .SB28
    .quad 4
    .quad -1
.K15:
    .quad 4
    .quad 1773077146
    .quad 2434017775
    .quad 2434017775
    .quad 1145696665
    .quad 4
    .quad -1
.K17:
    .quad 4
.K17_0:
    .quad .SB29
.K17_1:
    .quad .SB30
.K17_2:
    .quad .SB18
.K17_3:
    .quad .SB31
    .quad 4
    .quad -1
.K18:
    .quad 4
    .quad 156037723
    .quad 3007236879
    .quad 3007236879
    .quad 2670636699
    .quad 4
    .quad -1
.K20:
    .quad 4
.K20_0:
    .quad .SB32
.K20_1:
    .quad .SB33
.K20_2:
    .quad .SB18
.K20_3:
    .quad .SB34
    .quad 4
    .quad -1
.K21:
    .quad 4
    .quad 1206733038
    .quad 2617616591
    .quad 2617616591
    .quad 2981960154
    .quad 6
    .quad -1
.K23:
    .quad 6
.K23_0:
    .quad .K7
.K23_1:
    .quad .K10
.K23_2:
    .quad .K13
.K23_3:
    .quad .K16
.K23_4:
    .quad .K19
.K23_5:
    .quad .K22
    .quad 0
    .quad -1
.K24:
    .quad 0
    .section .data.rel.ro
    .balign 8
.Lfern_cagg_begin:
    .section .data.rel.ro
    .balign 8
    .quad 1
    .quad -1
.K0:
    .quad .S1
    .quad 1
    .quad -1
.K1:
    .quad .S2
    .quad 1
    .quad -1
.K2:
    .quad .S0
    .quad 1
    .quad -1
.K3:
    .quad .S3
    .quad 1
    .quad -1
.K4:
    .quad .S4
    .quad 6
    .quad -1
.K7:
    .quad .S15
    .quad 1
    .quad 1
    .quad 24
.K7_3:
    .quad .K5
.K7_4:
    .quad .K6
    .quad 6
    .quad -1
.K10:
    .quad .S15
    .quad 1
    .quad 1
    .quad 32
.K10_3:
    .quad .K8
.K10_4:
    .quad .K9
    .quad 6
    .quad -1
.K13:
    .quad .S15
    .quad 129
    .quad 2
    .quad 24
.K13_3:
    .quad .K11
.K13_4:
    .quad .K12
    .quad 6
    .quad -1
.K16:
    .quad .S15
    .quad 129
    .quad 2
    .quad 32
.K16_3:
    .quad .K14
.K16_4:
    .quad .K15
    .quad 6
    .quad -1
.K19:
    .quad .S15
    .quad 521
    .quad 3
    .quad 24
.K19_3:
    .quad .K17
.K19_4:
    .quad .K18
    .quad 6
    .quad -1
.K22:
    .quad .S15
    .quad 521
    .quad 3
    .quad 32
.K22_3:
    .quad .K20
.K22_4:
    .quad .K21
.Lfern_cagg_end:
    .balign 8
.Lfern_cfn_begin:
.Lfern_cfn_end:
    .balign 8
.Lfern_cref_begin:
    .quad .K5_0
    .quad .K5_1
    .quad .K5_2
    .quad .K5_3
    .quad .K7_3
    .quad .K7_4
    .quad .K8_0
    .quad .K8_1
    .quad .K8_2
    .quad .K8_3
    .quad .K10_3
    .quad .K10_4
    .quad .K11_0
    .quad .K11_1
    .quad .K11_2
    .quad .K11_3
    .quad .K13_3
    .quad .K13_4
    .quad .K14_0
    .quad .K14_1
    .quad .K14_2
    .quad .K14_3
    .quad .K16_3
    .quad .K16_4
    .quad .K17_0
    .quad .K17_1
    .quad .K17_2
    .quad .K17_3
    .quad .K19_3
    .quad .K19_4
    .quad .K20_0
    .quad .K20_1
    .quad .K20_2
    .quad .K20_3
    .quad .K22_3
    .quad .K22_4
    .quad .K23_0
    .quad .K23_1
    .quad .K23_2
    .quad .K23_3
    .quad .K23_4
    .quad .K23_5
.Lfern_cref_end:
    .text
