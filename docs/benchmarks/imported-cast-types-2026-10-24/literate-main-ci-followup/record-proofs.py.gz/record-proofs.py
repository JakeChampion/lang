from pathlib import Path
import subprocess,json,hashlib,gzip,collections
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-imported-cast-types/literate-main-ci-followup');core='b15d4e7e10ddaec58bba62c4d3d8d8c41c06e632';base='4f6f5d5b0578378f2026a12ab638b5aa84e5b840';dest=root/'docs/benchmarks/imported-cast-types-2026-10-24/literate-main-ci-followup'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core and not git('status','--porcelain')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==core and boot['fixedpoint'];native=boot['stages'][-1]['sha256'];assert boot['stages'][1]['sha256']==native
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256']
events=[json.loads(s)for s in(out/'regressions.jsonl').read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in events);packages=[e for e in events if'Test'not in e and e['Action']in['pass','fail']];assert not c['fail']and not c['skip']and len(packages)==1 and packages[0]['Action']=='pass';parents=[e['Test']for e in events if e['Action']=='pass'and'Test'in e and'/'not in e['Test']];assert len(parents)==5,parents
assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for name in ['format.log','gofmt.log','vet.log']:assert not(out/name).read_bytes()
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+core in version and 'vcs.modified=false'in version
m=json.loads((out/'matrix.json').read_text());assert m['complete']and len(m['runs'])==33;cs=[r['census']for r in m['runs']if'census'in r];assert len(cs)==9 and all(x['allocs']==x['frees']and x['live_bytes']==0 for x in cs)
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core);subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','main-failure-excerpts.json','regressions.jsonl','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','sizes.log','oracle-version.txt','format.log','gofmt.log','vet.log','cast-matrix.py','matrix.json','record-proofs.py']:take(n)
for p in sorted((out/'matrix').glob('*')):
 if p.suffix in['.stdout','.stderr']:take('matrix/'+p.name)
(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=core,dependency_base=base,source_sha256=h.hexdigest(),native_sha256=native,tests=dict(runs=c['run'],skips=0,packages=1,parents=parents),commands=33,balanced_censuses=9,artifacts=artifacts),indent=2)+'\n')
print(json.dumps(dict(tests=c['run'],native=native,artifacts=len(artifacts))))
