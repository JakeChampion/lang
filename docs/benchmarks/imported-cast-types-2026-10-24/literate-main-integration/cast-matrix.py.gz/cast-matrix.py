from pathlib import Path
import subprocess,json,hashlib,os,time,re
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-imported-cast-types/literate-main-integration');work=out/'matrix';work.mkdir(exist_ok=False);compiler=out/'bootstrap/stage3';oracle=out/'oracle-final';stdlib=root/'internal/stdlib';rows=[];meta=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),oracle_sha256=hashlib.sha256(oracle.read_bytes()).hexdigest(),runs=rows,fixtures=[])
def save():(out/'matrix.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,args,extra={}):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(os.environ,**extra),capture_output=True,timeout=120);(work/(name+'.stdout')).write_bytes(r.stdout);(work/(name+'.stderr')).write_bytes(r.stderr);row=dict(name=name,args=list(map(str,args)),exit=r.returncode,seconds=time.monotonic()-start);rows.append(row);save();assert r.returncode==0,(name,r.stdout,r.stderr);assert not r.stdout,(name,r.stdout);print(name,'PASS',flush=True);return r,row
for d in sorted((Path('/workspace/scratch/lang-imported-cast-types/baseline-inputs')).iterdir()):
 name=d.name;src=d/'main.fern';meta['fixtures'].append(dict(name=name,main_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),module_sha256=hashlib.sha256((d/'model.fern').read_bytes()).hexdigest()))
 for tag,cli in [('go',oracle),('native',compiler)]:
  for mode in ['-check','-interp']:run(name+'-'+tag+mode,[cli,mode,src,stdlib])
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=work/(name+'-'+target);run(name+'-build-'+target,[compiler,'-target',target,'-o',dest]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[src,stdlib],dict(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1'))
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest]if target=='x86-64-linux'else['qemu-aarch64',dest]if target=='arm64-linux'else['wasmtime','run',dest];r,row=run(name+'-run-'+target,args);m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m;ralloc,rfree,live=map(int,m.groups());assert ralloc==rfree and live==0
  if name!='checked-downcast':assert ralloc>0
  row['census']=dict(allocs=ralloc,frees=rfree,live_bytes=live);save()
meta['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
