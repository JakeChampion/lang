from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-imported-cast-types/literate-main-integration');core='3cda652cef89a883f476afabadaaca85cd0d1f91';base='3cf4afe7dbb88d91ce8a189053136735506db5a5';dest=root/'docs/benchmarks/imported-cast-types-2026-10-24/literate-main-integration'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core and not git('status','--porcelain')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['fixedpoint']and boot['source_git']==core;native=boot['stages'][-1]['sha256'];assert native==boot['stages'][1]['sha256']=='b71a022817dc777f2639236e097241074deb59faa7a612e68dc5a1fb04bab4c9'
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256'];tests=[]
for n,count,pkgs in [('go-regressions.jsonl',2495,6),('native-regressions.jsonl',186,1)]:
 es=[json.loads(s)for s in(out/n).read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);ps=[e for e in es if'Test'not in e and e['Action']in ['pass','fail']];assert c['run']==count and not c['skip']and not c['fail']and len(ps)==pkgs and all(e['Action']=='pass'for e in ps);tests.append(dict(file=n,runs=count,skips=0,packages=pkgs,scope='merge resolution before the final blank-line format adjustment'))
# Preserve the exact earlier Map input and its format-only delta.
map_path='internal/stdlib/core/map.fern.md';final_map=(root/map_path).read_bytes();needle=b'}\n```\n\n### `20 Map entry snapshots`';assert final_map.count(needle)==1;tested_map=final_map.replace(needle,b'}\n\n```\n\n### `20 Map entry snapshots`');old_blob=hashlib.sha1(b'blob '+str(len(tested_map)).encode()+b'\0'+tested_map).hexdigest();assert git('cat-file','blob',old_blob)==tested_map
identity=json.loads((out/'library-program-identity.json').read_text());assert len(identity['files'])==7 and all(r['executable_tokens_unchanged']for r in identity['files']);audit=json.loads((out/'audit.json').read_text());assert not any(r['status']in ['reference','policy','tracker']for r in audit)
matrices=[]
for n,key,count,census in [('matrix.json','runs',33,9),('matrix-helper.json','runs',88,24),('byte-matrix.json','runs',38,9),('loop-profile/report.json','runs',18,9)]:
 m=json.loads((out/n).read_text());assert m['complete']and len(m[key])==count;cs=[r['census']for r in m[key]if'census'in r];assert len(cs)==census and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs);matrices.append(dict(file=n,commands=count,balanced_censuses=census))
version=(out/'oracle-final-version.txt').read_text();assert 'vcs.revision='+core in version and 'vcs.modified=false'in version
assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for n in ['format-final.log','gofmt.log','vet.log']:assert not(out/n).read_bytes()
prior=json.loads(Path('/workspace/scratch/lang-imported-cast-types/driver-builds.json').read_text());new=json.loads((out/'driver-builds.json').read_text());before={r['source']:r['sha256']for r in prior};after={r['source']:r['sha256']for r in new};(out/'driver-image-identity.json').write_text(json.dumps(dict(previous_source='feedc9050efb5017d83423c8b782ba24e9f66f5c',current_source=core,all_driver_images_unchanged=before==after,previous=before,current=after),indent=2)+'\n')
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');save('regression-map-before-final-format.md.gz',gzip.compress(tested_map,mtime=0));patch=git('diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','go-regressions.jsonl','native-regressions.jsonl','library-program-identity.json','current-path-updates.json','audit.json','audit.py','audit-before.log','audit-after.log','driver-builds.json','driver-sizes.txt','driver-gate.log','driver-image-identity.json','check-sizes.py','sizes.log','matrix.json','matrix-helper.json','byte-matrix.json','loop-profile/report.json','cast-matrix.py','matrix-helper.py','os-byte-matrix.py','loop-profile.py','format.log','format-final.log','gofmt.log','vet.log','oracle-final-version.txt','record-proofs.py']:take(n)
stream=io.BytesIO();logs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['matrix','matrix-helper','byte-matrix','loop-profile']:
  for p in sorted((out/folder).glob('*')):
   if p.suffix not in ['.stdout','.stderr','.fern']:continue
   data=p.read_bytes();name=folder+'/'+p.name;item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(data));logs.append(name)
save('execution-inputs-logs.tar.gz',stream.getvalue());(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=core,dependency_base=base,source_sha256=h.hexdigest(),source_files=len(files),native_sha256=native,tests=tests,tested_map_blob=old_blob,final_format_only=True,matrices=matrices,commands=177,balanced_censuses=51,inputs_logs=len(logs),patch_excludes=['docs/benchmarks'],artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(artifacts=len(artifacts),source_files=len(files),inputs_logs=len(logs),native=native,driver_images_unchanged=before==after)))
