from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io
root=Path('/workspace/lang-imported-cast-types');out=Path('/workspace/scratch/lang-imported-cast-types');core='feedc9050efb5017d83423c8b782ba24e9f66f5c';tests_source='866e4a26f';base='1284b139bd8211475dbccf7fcde4e424e1ad1065';dest=root/'docs/benchmarks/imported-cast-types-2026-10-24'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core;tests_source=git('rev-parse',tests_source).decode().strip();assert not git('diff',tests_source,core,'--','compiler','internal/stdlib','*.go','conformance','spec','site','.github')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['fixedpoint']and boot['source_git']==core;native=boot['stages'][-1]['sha256'];assert native==boot['stages'][1]['sha256']==hashlib.sha256((out/'bootstrap/stage3').read_bytes()).hexdigest()
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256'];suites=[]
for name,runs,pkgs in [('regressions.jsonl',36,1),('go-regressions.jsonl',2066,2)]:
 es=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es);ps=[e for e in es if'Test'not in e and e['Action']in ['pass','fail']];assert c['run']==runs and not c['fail']and not c['skip']and len(ps)==pkgs and all(e['Action']=='pass'for e in ps);suites.append(dict(file=name,source=tests_source,runs=runs,passed=c['pass']-pkgs,skips=0,packages=pkgs))
m=json.loads((out/'matrix.json').read_text());assert m['complete']and m['source_commit']==core and len(m['runs'])==33 and all(r['exit']==0 for r in m['runs'])and m['compiler_sha256']==native;cs=[r['census']for r in m['runs']if'census'in r];assert len(cs)==9 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+core in version and 'vcs.modified=false'in version;assert m['oracle_sha256']==hashlib.sha256((out/'oracle').read_bytes()).hexdigest()
b=json.loads((out/'baseline-reported-cases.json').read_text());assert len(b['runs'])==6 and all((r['exit']==0)==(r['tool']=='go')for r in b['runs']);assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for n in ['format.log','gofmt.log','vet.log']:assert not(out/n).read_bytes()
(out/'source-identity.json').write_text(json.dumps(dict(measured_source=core,regression_source=tests_source,dependency_base=base,compiler_library_go_and_test_inputs_unchanged=True,only_dependency_evidence_changed=True),indent=2)+'\n')
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','regressions.jsonl','go-regressions.jsonl','oracle-version.txt','baseline-reported-cases.json','matrix.py','matrix.json','matrix.log','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','sizes.log','format.log','gofmt.log','vet.log','source-identity.json','record-proofs.py']:take(n)
stream=io.BytesIO();logs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['baseline-inputs','matrix']:
  for p in sorted((out/folder).rglob('*')):
   if not p.is_file()or p.suffix not in ['.fern','.stdout','.stderr']:continue
   data=p.read_bytes();name=str(p.relative_to(out));item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(data));logs.append(name)
save('execution-inputs-logs.tar.gz',stream.getvalue());(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=core,dependency_base=base,source_sha256=h.hexdigest(),source_files=len(files),native_sha256=native,tests=suites,matrix_commands=33,balanced_censuses=9,inputs_and_logs=len(logs),patch_excludes=['docs/benchmarks'],artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(artifacts=len(artifacts),source_files=len(files),inputs_logs=len(logs),native=native)))
