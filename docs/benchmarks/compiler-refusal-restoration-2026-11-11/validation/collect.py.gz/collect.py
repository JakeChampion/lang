from pathlib import Path
import subprocess,json,datetime,traceback,hashlib,os
out=Path(__file__).parent;root=Path('/workspace/lang-spec-index-pins-concurrent-20261111-0748');main='eb264b32a2775d534109f244b83dabe57258949e'
s={'source':main,'concurrent_parent':'4e8cbe42176f1be18790297ea0dc83ae5aafb1ad','started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Current-source correctness after preservation of the concurrent merge and restoration of committed records and refusal validation. No performance claim.','runs':[]}
def save():(out/'result.json').write_text(json.dumps(s,indent=2)+'\n')
save()
try:
 assert hashlib.sha256(Path(os.environ['STAGE0']).read_bytes()).hexdigest()=='a66fcf94f418bea5f969bfaf2b07e6fe56235d2565ca405c950e6e263187a751'
 assert not subprocess.check_output(['git','diff',main,'--','compiler','internal/stdlib','internal/check','internal/syntax','conformance'],cwd=root)
 tests='^TestSelfHost(CheckerCodesX86_64|CheckEntryShadowOfBuiltin|ImportedRawBuiltinNameIsReserved|ImportedVariantKeepsBuiltinType|SIMDUnzipFusion|IRStrength.*|X86RIP.*|X86GasRIPConstants|X86ShuffleFormsMatchGas|X86VEXRejectsMixedWidths)$'
 commands=[('source-check',[os.environ['STAGE0'],'-check','compiler/fern.fern','internal/stdlib']),('go-frontend',['go','test','./internal/check/checker','./internal/syntax/parser','-count=1','-timeout=10m','-json']),('current-native',['go','test','./internal/testing/e2ecompiler','-run',tests,'-count=1','-timeout=25m','-json']),('refusal-controls',['go','test','./internal/testing/e2ecompiler','-run','^TestProvidedLoweringRefusalVerdict$','-count=1','-timeout=5m','-json']),('fixtures',['go','test','./internal/testing/e2e','-run','^TestFernFixtures(SelfHost(Check|X86_64|Arm64|Wasm))?$/^(diag_e010_raw_builtin_function|diag_e091_range_index|for_loop_continue_steps)$','-count=1','-timeout=12m','-json']),('indexes',['go','test','./internal/testing/e2e','./internal/testing/sourcelint','-run','^(TestDiagnosticsIndexIsAccurate|TestSemanticsIndexIsAccurate|TestConformanceCensusHasARowPerFixture|TestConformanceCorpusFormat)$','-count=1','-timeout=12m','-json']),('gofmt',['gofmt','-l','internal/testing/e2ecompiler/self_host_irverify_test.go']),('vet',['go','vet','./internal/testing/e2ecompiler']),('ci-selftest',['make','ci-selftest']),('whitespace',['git','diff','--cached','--check'])]
 for label,args in commands:
  r={'label':label,'args':args,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};s['runs'].append(r);save()
  with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:p=subprocess.run(args,cwd=root,stdout=so,stderr=se,timeout=1980)
  r.update(exit_code=p.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save();assert p.returncode==0,(label,p.returncode)
  if label=='gofmt':assert not(out/(label+'.stdout')).read_bytes()
  if '-json'in args:
   rows=[json.loads(l)for l in(out/(label+'.stdout')).read_text().splitlines()if l.strip()];r.update(passes=sum(x.get('Action')=='pass'and bool(x.get('Test'))for x in rows),skips=sum(x.get('Action')=='skip'for x in rows),failures=[x.get('Test')or x.get('Package')for x in rows if x.get('Action')=='fail']);save();assert r['passes']>0 and not r['skips']and not r['failures']
   names={x.get('Test')for x in rows if x.get('Action')=='pass'}
   if label=='current-native':
    for name in ['TestSelfHostCheckerCodesX86_64','TestSelfHostCheckEntryShadowOfBuiltin','TestSelfHostImportedRawBuiltinNameIsReserved','TestSelfHostSIMDUnzipFusion','TestSelfHostIRStrengthPeephole','TestSelfHostX86RIPConstantsMatchGas','TestSelfHostX86GasRIPConstants','TestSelfHostX86ShuffleFormsMatchGas']:assert name in names,name
   if label=='fixtures':
    for family in ['TestFernFixtures','TestFernFixturesSelfHostCheck','TestFernFixturesSelfHostX86_64','TestFernFixturesSelfHostArm64','TestFernFixturesSelfHostWasm']:
     for case in ['diag_e010_raw_builtin_function','diag_e091_range_index','for_loop_continue_steps']:assert family+'/'+case in names,(family,case)
 s.update(exit_code=0,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except Exception as e:s.update(exit_code=1,error=repr(e),traceback=traceback.format_exc());save();raise
