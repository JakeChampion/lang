from pathlib import Path
import subprocess,json,datetime,os,shutil,hashlib,gzip,traceback
root=Path('/workspace/lang-spec-index-pins-concurrent-20261111-0748');out=Path(__file__).parent;head='4e8cbe42176f1be18790297ea0dc83ae5aafb1ad';published='34229724c031302b5147b5132333de7e2397579e';main=json.loads((out/'checkout-plan.json').read_text())['main'];sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a,cwd=root):return subprocess.check_output(['git',*a],cwd=cwd)
def blob(rev,name):return git('show',rev+':'+name)
def entries(rev,prefix):
 d={}
 for line in git('ls-tree','-r','-z',rev,'--',prefix).split(b'\0'):
  if line:
   meta,name=line.split(b'\t');mode,kind,oid=meta.decode().split();assert kind=='blob';d[name.decode()]=(mode,oid)
 return d
links=[]
def private(name):
 p=root/name
 if not p.is_file()or p.is_symlink():return
 b=p.read_bytes();st=p.stat();q=out/'before-restore'/Path(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(b,mtime=0));tmp=p.with_name(p.name+'.private-0748');shutil.copy2(p,tmp);os.replace(tmp,p);assert p.stat().st_ino!=st.st_ino and p.read_bytes()==b;links.append({'path':name,'before_nlink':st.st_nlink,'after_nlink':p.stat().st_nlink,'raw_bytes':len(b),'raw_sha256':sha(b)})
def write(name,b,mode='100644'):
 p=root/name;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.restore-0748');tmp.write_bytes(b);os.chmod(tmp,0o755 if mode=='100755'else 0o644);os.replace(tmp,p);subprocess.run(['git','add','--',name],cwd=root,check=True)
try:
 rows=[]
 for line in git('worktree','list','--porcelain').decode().splitlines():
  if line.startswith('worktree '):
   p=line[9:];status=git('status','--porcelain=v1',cwd=p).decode();rows.append({'path':p,'status':status});assert not status,p
 (out/'worktrees-before-restore.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':rows},indent=2)+'\n')
 assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1')
 raw=git('-c','credential.helper=','ls-remote','--heads','https://github.com/JakeChampion/lang.git','main','fix/e065-spec-index-pins');(out/'pre-restore-refs.txt').write_bytes(raw);r={n:h for h,n in(l.split()for l in raw.decode().splitlines())};assert r['refs/heads/main']==main and r['refs/heads/fix/e065-spec-index-pins']==head
 archives=entries(published,'docs/benchmarks');(out/'published-archive-inventory.json').write_text(json.dumps(archives,indent=2)+'\n')
 for name in git('diff','--name-only',head,main).decode().splitlines():
  if name.startswith(('site/','web/')):private(name)
 p=subprocess.run(['git','merge','--no-ff','--no-commit',main],cwd=root,capture_output=True);(out/'merge-main.stdout').write_bytes(p.stdout);(out/'merge-main.stderr').write_bytes(p.stderr);assert p.returncode==0,(p.returncode,p.stderr.decode())
 restored=[]
 for name,(mode,oid)in archives.items():
  b=git('cat-file','blob',oid)
  if not(root/name).exists()or(root/name).read_bytes()!=b:
   if(root/name).exists():private(name)
   write(name,b,mode);restored.append({'path':name,'git_blob':oid,'sha256':sha(b),'source':published})
 harness='internal/testing/e2ecompiler/self_host_irverify_test.go';assert blob(head,harness)==blob(main,harness)
 private(harness);write(harness,blob(published,harness))
 census='internal/testing/e2e/testdata/conformance-leak-census.txt'
 def nums(b):return{a[0]:a[1:]for l in b.decode().splitlines()if l.strip()and not l.lstrip().startswith('#')for a in[l.split()]}
 assert nums(blob(published,census))==nums(blob(main,census));private(census);write(census,blob(published,census))
 baseline='.github/cliff-baseline.txt';assert(root/baseline).read_bytes()==blob(published,baseline)
 assert not git('diff',main,'--','compiler','internal/stdlib','internal/check','internal/syntax','conformance','scripts','tests','examples','.github/actions','.github/workflows','.github/selfhost-driver-sizes.txt','spec','site','web')
 for name,(mode,oid)in archives.items():assert git('hash-object',name).decode().strip()==oid,name
 readme='docs/benchmarks/compiler-main-rollback-ci-2026-11-11/README.md';private(readme);text=(root/readme).read_text();assert '--commit HEAD'in text;text=text.replace('--commit HEAD','--commit '+published);text+='\nThe later integration retains current main compiler and standard library sources.\nThe concurrent merge remains an ancestor.\nThe committed archive files and refusal harness return from publication `34229724`.\nThese earlier measurements retain their original source and publication.\n';write(readme,text.encode())
 for folder in ['compiler-checker-cliff-ci-2026-11-11','compiler-main-rollback-ci-2026-11-11']:
  p=root/'docs/benchmarks'/folder;m=json.loads((p/'manifest.json').read_text())
  for name,h in m['data_sha256'].items():assert sha((p/name).read_bytes())==h,(folder,name)
  for row in m['gzip_identities']:
   b=gzip.decompress((p/row['file']).read_bytes());assert len(b)==row['raw_bytes']and sha(b)==row['raw_sha256']
  assert(p/'verify.py').read_bytes()==blob(published,'docs/benchmarks/'+folder+'/verify.py')
 (out/'linkbreaks-restore.json').write_text(json.dumps(links,indent=2)+'\n');(out/'restored-files.json').write_text(json.dumps(restored,indent=2)+'\n');subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
 result={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'concurrent_parent_preserved':head,'current_main_parent':main,'published_source':published,'new_mutable':str(root),'old_mutable_preserved_clean':'/workspace/lang-spec-index-pins-20261111-0230','worktrees_inspected':len(rows),'restored_archive_files':len(restored),'original_data_records_verified':31,'original_gzip_identities_verified':20,'later_data_records_verified':72,'later_gzip_identities_verified':63,'harness_exact_published':True,'baseline_numeric_changes':False,'all_production_and_upstream_ci_changes_exact_main':True,'ignored_artifact_recovery_claim':False,'stage_tree':git('write-tree').decode().strip()};(out/'restoration.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
except Exception as e:(out/'restoration-failure.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'error':repr(e),'traceback':traceback.format_exc()},indent=2)+'\n');raise
