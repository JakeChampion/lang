from pathlib import Path
import subprocess,json,datetime,hashlib,os,signal,traceback,time
out=Path(__file__).parent;root=Path('/workspace/lang-spec-index-pins-concurrent-20261111-0748');frozen=Path('/workspace/lang-compiler-main-20261111-0748');images=Path('/dev/shm/fern-refusal-restoration-20261111-0748/images');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':'wait-validation','owner_commit':'eb264b32a2775d534109f244b83dabe57258949e','source_parent':'4e8cbe42176f1be18790297ea0dc83ae5aafb1ad','scope':'Current-source correctness after the concurrent push and committed data restoration. No optimization, paired timing, allocation or leak claim.','runs':[]}
def save():
 p=out/'result.tmp';p.write_text(json.dumps(s,indent=2)+'\n');p.replace(out/'result.json')
def guard():
 for rel,h in inv.items():assert sha(root/rel)==sha(frozen/rel)==h,rel
 assert sha(Path(os.environ['STAGE0']))=='a66fcf94f418bea5f969bfaf2b07e6fe56235d2565ca405c950e6e263187a751'
def run(label,args,env=None,cwd=root,expected=0):
 guard();r={'label':label,'args':args,'expected_exit':expected,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};s['runs'].append(r);save()
 with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:
  p=subprocess.Popen(args,cwd=cwd,env=env,stdout=so,stderr=se,start_new_session=True);r['pid']=p.pid;save()
  try:code=p.wait(timeout=1980)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait();r['deadline_exceeded']=True
 r.update(exit_code=code,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save();assert code==expected,(label,code,expected)
 if '-json'in args:
  rows=[json.loads(x)for x in(out/(label+'.stdout')).read_text().splitlines()if x.strip()]
  r.update(passes=sum(x.get('Action')=='pass'and bool(x.get('Test'))for x in rows),skips=sum(x.get('Action')=='skip'for x in rows),failures=[x.get('Test')or x.get('Package')for x in rows if x.get('Action')=='fail']);save();assert not r['skips']and not r['failures']
  text=''.join(x.get('Output','')for x in rows);assert f'swept {len(mains)}/{len(mains)} fixtures'in text and f'validated {len(refusals)} expected lowering refusals'in text
 guard()
save()
try:
 mains=[p for p in sorted((root/'conformance/cases').glob('*/main.fern'))if not(p.parent/'expected.error').exists()];refusals=[p.parent.name for p in mains if(p.parent/'expected.lowering-error').exists()];s['corpus']={'fixtures':len(mains),'refusals':refusals};save()
 paths=subprocess.check_output(['git','ls-files','compiler','internal/stdlib','bootstrap/stage0.lock'],cwd=root,text=True).splitlines();inv={p:sha(root/p)for p in paths};(out/'source-inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
 while True:
  p=out.parent/'validation-resume/result.json'
  if p.exists():
   d=json.loads(p.read_text())
   if 'exit_code'in d:assert d['exit_code']==0,d;break
  time.sleep(3)
 s['phase']='qualify';save()
 run('complete-ir-corpus',['go','test','./internal/testing/e2ecompiler','-run','^TestSelfHostIRVerifyProvidedCorpusClean$','-count=1','-timeout=25m','-json'])
 e={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};e.update({'FERN_PROFILE':'0','FERN_LEAKCHECK':'0','FERN_RC_CERTIFY':'1','FERN_RC_CERTIFY_MEMO':'0'});s['normal_flags']={k:v for k,v in e.items()if k.startswith('FERN_')};save()
 baseline=images/'baseline-normal';run('baseline-normal-build',[os.environ['STAGE0'],'-target','x86-64-linux','-o',str(baseline),'compiler/fern.fern','internal/stdlib'],e,cwd=frozen);s['baseline_normal_sha256']=sha(baseline);save()
 normal=images/'normal';run('normal-build',[os.environ['STAGE0'],'-target','x86-64-linux','-o',str(normal),'compiler/fern.fern','internal/stdlib'],e);s['normal_sha256']=sha(normal);assert s['normal_sha256']==s['baseline_normal_sha256'];save()
 for case,code in [('diag_e010_raw_builtin_function','E010'),('diag_e091_range_index','E091')]:
  want=(root/'conformance/cases'/case/'expected.error').read_text().strip()
  for target in ['x86-64-linux','arm64-linux','wasm32-wasi']:
   label='production-refusal-'+case+'-'+target;dest=images/label;assert not dest.exists()
   run(label,[str(normal),'-target',target,'-o',str(dest),'conformance/cases/'+case+'/main.fern','internal/stdlib'],e,expected=1)
   message=(out/(label+'.stdout')).read_text()+(out/(label+'.stderr')).read_text();assert 'error['+code+']:'in message and 'error: internal:'not in message and all(line.strip()in message for line in want.splitlines()if line.strip());assert not dest.exists()
 run('normal-own-source',[str(normal),'-check','compiler/fern.fern','internal/stdlib'],e)
 run('baseline-opus-compile',[str(baseline),'-target','x86-64-linux','-o',str(images/'baseline-opus'),'tests/stdlib/opus_delimited_test.fern','internal/stdlib'],e,cwd=frozen)
 run('opus-compile',[str(normal),'-target','x86-64-linux','-o',str(images/'opus-native'),'tests/stdlib/opus_delimited_test.fern','internal/stdlib'],e);s['opus_sha256']=sha(images/'opus-native');save()
 run('opus-program',[str(images/'opus-native')],e);assert sha(out/'opus-program.stdout')=='07c2de202ca09462f396f349cbf99df5b0f044194e9314840de8bf6331c29161'
 assert s['opus_sha256']==sha(images/'baseline-opus');s['previous_source_opus_sha256']='4eceb083ab65e78b7a515c70ecdbe57dc30f99b96cc05d4ddcaafcc8474c3e4c';s['new_generated_program_differs_from_old_source']=s['opus_sha256']!=s['previous_source_opus_sha256'];save()
 for label,compiler,dest in [('stage2',normal,images/'stage2'),('stage3',images/'stage2',images/'stage3')]:run(label,[str(compiler),'-target','x86-64-linux','-o',str(dest),'compiler/fern.fern','internal/stdlib'],e)
 s['stage2_sha256']=sha(images/'stage2');s['stage3_sha256']=sha(images/'stage3');assert s['stage2_sha256']==s['stage3_sha256'];s['fixpoint_limit']='Secondary correctness only; not a proof against stable miscompilation or performance evidence.'
 guard();s.update(exit_code=0,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except Exception as e:s.update(exit_code=1,error=repr(e),traceback=traceback.format_exc(),finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise
