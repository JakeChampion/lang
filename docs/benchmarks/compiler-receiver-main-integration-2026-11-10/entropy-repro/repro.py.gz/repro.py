from pathlib import Path
import subprocess,json,datetime,os
out=Path(__file__).resolve().parent
root='/workspace/lang-compiler-main-20261110-1845'
state={'source':'bcd223bae6ab2d8dc14b3b152027fa7be90e6779','purpose':'Reproduce a historical main-red entropy-capacity assertion on actual immutable main before any test repair. No performance comparison.','args':['go','test','./internal/testing/e2e','-run','^TestSelfHostEntropyAllocationCapacity$','-count=1','-timeout=12m','-json'],'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'repro.json').write_text(json.dumps(state,indent=2)+'\n')
with(out/'repro.jsonl').open('wb')as so,(out/'repro.stderr').open('wb')as se:r=subprocess.run(state['args'],cwd=root,stdout=so,stderr=se)
es=[json.loads(x)for x in(out/'repro.jsonl').read_text().splitlines()if x.strip()]
state.update(exit_code=r.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),failures=[x.get('Test')for x in es if x.get('Action')=='fail'],skips=sum(x.get('Action')=='skip'for x in es))
(out/'repro.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(state))

