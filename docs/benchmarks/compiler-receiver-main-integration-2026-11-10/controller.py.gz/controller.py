from pathlib import Path
import json,subprocess,datetime,concurrent.futures,hashlib,os
out=Path(__file__).resolve().parent
root=Path('/workspace/lang-checker-union-retained-20261110-1845')
fixed=Path('/workspace/lang-compiler-main-20261110-1845')
state={'source':'63d33384bb4261faa38f4436b4abf4d52a9b9542','main':'bcd223bae6ab2d8dc14b3b152027fa7be90e6779','purpose':'Fresh correctness controls after main owned-result integration. No timing comparison. Normal full is not an allocation-balance control.','runs':[]}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save():(out/'result.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,cwd=root,env=None,timeout=1980):
 row={'label':label,'args':args,'cwd':str(cwd),'started':now()};state['runs'].append(row);save()
 with(out/(label+'.controller.log')).open('wb')as log:r=subprocess.run(args,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 row.update(exit_code=r.returncode,finished=now());save()
 assert r.returncode==0,(label,r.returncode)
def py(name):run(name,['python3',str(out/(name+'.py'))])
def compilation():
 py('build');py('normal-own-source');py('native-opus')
 env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};env.update(FERN_PROFILE='0',FERN_LEAKCHECK='0',FERN_RC_CERTIFY='1',FERN_RC_CERTIFY_MEMO='0')
 args=[str(out/'retained-normal'),'-stdlib',str(fixed/'internal/stdlib'),'-interp',str(fixed/'tests/stdlib/opus_delimited_test.fern')]
 row={'label':'full-interpreter','args':args,'started':now(),'budget_seconds':1980,'note':'Correctness only, overlaps targeted tests. No paired timing or normal-run leak claim.'};state['runs'].append(row);save()
 with(out/'full.stdout').open('wb')as so,(out/'full.stderr').open('wb')as se:r=subprocess.run(args,cwd=fixed,env=env,stdout=so,stderr=se,timeout=1980)
 digest=hashlib.sha256((out/'full.stdout').read_bytes()).hexdigest();row.update(exit_code=r.returncode,stdout_sha256=digest,finished=now());save()
 assert r.returncode==0 and digest=='07c2de202ca09462f396f349cbf99df5b0f044194e9314840de8bf6331c29161'
save()
try:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==state['source']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)
 py('quick')
 with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
  fs=[pool.submit(py,'validate'),pool.submit(py,'unit-controls'),pool.submit(compilation)]
  for f in fs:f.result()
 run('ci-selftest',['make','ci-selftest'])
 state.update(exit_code=0,finished=now())
except Exception as e:state.update(exit_code=1,error=repr(e),finished=now());raise
finally:save()

