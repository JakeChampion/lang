from pathlib import Path
import json,gzip,hashlib,subprocess,shutil
repo=Path('/workspace/lang-checker-union-index-20261110-1540')
src=repo/'build/main-integration-20261110-1845'
out=repo/'docs/benchmarks/compiler-receiver-main-integration-2026-11-10'
assert not out.exists()
load=lambda n:json.loads((src/n).read_text())
for n in ['result.json','validation.json','build.json','unit-controls.json','native-opus.json','normal-own-source.json','entropy-fixed/repro.json']:assert load(n)['exit_code']==0,n
assert load('entropy-repro/repro.json')['exit_code']==1
assert not subprocess.check_output(['git','diff','--name-only','bcd223bae6ab2d8dc14b3b152027fa7be90e6779','74c84520a2925bf40089b640a728813f46fca3c7','--','compiler','internal/stdlib'],cwd=repo)
out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
sources={};compressed={}
exclude={'main-normal','retained-normal','opus-native','collector.pid','result.tmp'}
for f in sorted(src.rglob('*')):
 if not f.is_file()or '__pycache__'in f.parts or f.name in exclude or f.name.startswith('checkpoint-'):continue
 rel=f.relative_to(src).as_posix();data=f.read_bytes()
 if f.suffix in ['.stdout','.stderr','.log','.patch','.jsonl','.txt']or data.endswith(b'\n\n'):
  name=rel+'.gz';payload=gzip.compress(data,mtime=0);compressed[name]={'original_bytes':len(data),'original_sha256':sha(data)}
 else:name=rel;payload=data
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(payload)
 sources[name]={'original_path':str(f),'original_bytes':len(data),'original_sha256':sha(data),'compressed':name!=rel}
def events(n):return[json.loads(x)for x in(src/n).read_text().splitlines()if x.strip()]
def counts(es):return{'test_subtest_passes':sum(x.get('Action')=='pass'and bool(x.get('Test'))for x in es),'skips':sum(x.get('Action')=='skip'for x in es),'failures':[x.get('Test')for x in es if x.get('Action')=='fail']}
summary={'main':'bcd223bae6ab2d8dc14b3b152027fa7be90e6779','integration':'63d33384bb4261faa38f4436b4abf4d52a9b9542','retained':'74c84520a2925bf40089b640a728813f46fca3c7','scope':'Compiler and standard library exactly match main. Receiver and kernel tests match the integration snapshot. The additional entropy fixture alone changes after that snapshot. No timing comparison, normal-run leak claim, or retained compiler optimization.','native':counts(events('tests.jsonl')),'units':counts(events('go-units.jsonl')),'formatter':counts(events('go-syntax-units.stdout')),'entropy_before':counts(events('entropy-repro/repro.jsonl')),'entropy_after':counts(events('entropy-fixed/repro.jsonl')),'build':load('build.json'),'control':load('result.json'),'own_source':load('normal-own-source.json'),'native_opus':load('native-opus.json'),'source_audit':load('source-audit.json'),'historical_ci_logs':load('historical-main-red/log-origin.json'),'claim':load('entropy-repro/claim-receipt.json')}
for n,d in [('summary.json',summary),('source-files.json',sources),('compression-identities.json',compressed)]:(out/n).write_text(json.dumps(d,indent=2)+'\n')
shutil.copy2(src/'integration-verify.py',out/'verify.py')
manifest={f.relative_to(out).as_posix():sha(f.read_bytes())for f in sorted(out.rglob('*'))if f.is_file()}
(out/'manifest.json').write_text(json.dumps({'sha256':manifest},indent=2)+'\n')
print(json.dumps({'data_hashes':len(manifest),'source_records':len(sources),'lossless_gzip_identities':len(compressed)}))

