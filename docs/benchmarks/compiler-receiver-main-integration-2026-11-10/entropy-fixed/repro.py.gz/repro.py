from pathlib import Path
import subprocess,json,datetime,os
out=Path(__file__).resolve().parent
root='/workspace/lang-checker-union-retained-20261110-1850'
state={'source':'74c84520a2925bf40089b640a728813f46fca3c7','purpose':'Validate negative refusal and all original nonnegative capacity controls after the fixture repair. No product compiler or runtime change.','args':['go','test','./internal/testing/e2e','-run','^Test(SelfHostEntropyAllocationCapacity|SelfHostEntropyReadCompletion|SelfHostStringBytesAllocationCapacity|RandomBytesLargeFill)$','-count=1','-timeout=12m','-json'],'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'repro.json').write_text(json.dumps(state,indent=2)+'\n')
with(out/'repro.jsonl').open('wb')as so,(out/'repro.stderr').open('wb')as se:r=subprocess.run(state['args'],cwd=root,stdout=so,stderr=se)
es=[json.loads(x)for x in(out/'repro.jsonl').read_text().splitlines()if x.strip()]
state.update(exit_code=r.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),failures=[x.get('Test')for x in es if x.get('Action')=='fail'],skips=sum(x.get('Action')=='skip'for x in es))
(out/'repro.json').write_text(json.dumps(state,indent=2)+'\n')
print(json.dumps(state))

