from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-grammar-publish');scratch=Path('/workspace/scratch/lang-grammar/os-byte-integration');out=scratch/'matrix';out.mkdir(exist_ok=True);compiler=scratch/'bootstrap-runtime-integration/stage3';oracle=scratch/'oracle-runtime-integration';stdlib=root/'internal/stdlib';rows=[]
names=['basic','flow','string','array','nested','literal_once','enum_once','diverge','statement_arms','lambda_tails'];meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'compiler_source_commit':'6ac7c8eeb8665041c1deb83944d1b3b3bce0fb7b','producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows,'fixtures':[]}
def save():(scratch/'matrix.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,args,stdout=None,extra={}):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(os.environ,**extra),capture_output=True,timeout=180);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);row={'name':name,'args':list(map(str,args)),'exit':r.returncode,'seconds':time.monotonic()-start};rows.append(row);save();print(row,flush=True);assert r.returncode==0,(name,r.stdout,r.stderr);assert stdout is None or r.stdout==stdout,(name,r.stdout,stdout);return r,row
for name in names:
 folder=root/'conformance/cases'/('control_value_'+name);source=folder/'main.fern';stdout=(folder/'expected.stdout').read_bytes();meta['fixtures'].append({'name':name,'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'expected_stdout':stdout.decode()});formats=[]
 for engine,tool in [('go',oracle),('self',compiler)]:
  lib=[stdlib]if engine=='self'else[]
  for mode in ['-check','-interp']:run(name+'-'+engine+mode,[tool,mode,source]+lib,stdout if mode=='-interp'else b'')
  r,_=run(name+'-'+engine+'-fmt',[tool,'-fmt',source]);formats.append(r.stdout);formatted=out/(name+'-'+engine+'-formatted.fern');formatted.write_bytes(r.stdout)
  run(name+'-'+engine+'-fmt-again',[tool,'-fmt',formatted],r.stdout)
  for mode in ['-check','-interp']:run(name+'-'+engine+'-formatted'+mode,[tool,mode,formatted]+lib,stdout if mode=='-interp'else b'')
 assert formats[0]==formats[1],(name,'formatter mismatch',formats)
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=out/(name+'-'+target);run(name+'-build-'+target,[compiler,'-target',target,'-o',dest]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[source,stdlib],b'',{'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest]if target=='x86-64-linux'else['qemu-aarch64',dest]if target=='arm64-linux'else['wasmtime','run',dest];r,row=run(name+'-run-'+target,args,stdout);m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,(name,target,r.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
meta['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
