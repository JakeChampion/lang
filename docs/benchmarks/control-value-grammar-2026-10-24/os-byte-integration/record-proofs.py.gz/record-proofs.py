from pathlib import Path
import collections,gzip,hashlib,io,json,subprocess,tarfile
root=Path('/workspace/lang-grammar-publish');out=Path('/workspace/scratch/lang-grammar/os-byte-integration');measured='6ac7c8eeb8665041c1deb83944d1b3b3bce0fb7b';core='78350882a8999033008422ff6c62861bc5cfc6d6';focused='afdbeacb42b579a13c577ff8aa622e2846b6d012';base='44e75d1104c7dd416e9e30667fc21f4012117d7e';dest=root/'docs/benchmarks/control-value-grammar-2026-10-24/os-byte-integration'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core
assert not git('diff',measured,core,'--','compiler','internal/stdlib','bootstrap')
boot=json.loads((out/'bootstrap-runtime-integration/bootstrap.json').read_text());assert boot['fixedpoint']and boot['source_git']==measured and len({s['sha256']for s in boot['stages']})==1
native=boot['stages'][-1]['sha256'];assert hashlib.sha256((out/'bootstrap-runtime-integration/stage3').read_bytes()).hexdigest()==native
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256'];tests=[]
for name,runs,skips,packages,source in [('focused-tests.jsonl',563,0,1,focused),('go-selected-runtime-integration.jsonl',3429,11,7,measured),('native-formatter-parity-runtime-integration.jsonl',105,0,1,measured)]:
 es=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es);terminal=[e for e in es if'Test'not in e and e['Action']in ['pass','fail']];assert c['run']==runs and c['skip']==skips and not c['fail'];assert len(terminal)==packages and all(e['Action']=='pass'for e in terminal);tests.append(dict(file=name,source=source,runs=runs,passed=c['pass']-packages,skips=skips,packages=[e['Package']for e in terminal]))
m=json.loads((out/'matrix.json').read_text());assert m['complete']and len(m['runs'])==190 and m['compiler_source_commit']==measured and m['producer_sha256']==native
cs=[r['census']for r in m['runs']if'census'in r];assert len(cs)==30 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
d=json.loads((out/'diagnostics.json').read_text());assert d['complete']and len(d['runs'])==54 and d['producer_sha256']==native
for i in range(0,54,2):assert d['runs'][i]['codes']==d['runs'][i+1]['codes']
version=(out/'oracle-runtime-integration-version.txt').read_text();assert 'vcs.revision='+measured in version and 'vcs.modified=false'in version;assert m['oracle_sha256']==hashlib.sha256((out/'oracle-runtime-integration').read_bytes()).hexdigest()
assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for n in ['format-runtime-integration-corrected.log','vet-runtime-integration-corrected.log','gofmt-runtime-integration.log']:assert not(out/n).read_bytes()
# Only interpreter regression and evidence were merged after the measured compiler.
identity=dict(measured_source=measured,integrated_source=core,compiler_library_and_pin_unchanged=True,changed_files=git('diff','--name-only',measured,core).decode().splitlines())
(out/'runtime-merge-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap-runtime-integration/bootstrap.json','bootstrap-runtime-integration/stage1.log','bootstrap-runtime-integration/stage2.log','bootstrap-runtime-integration/stage3.log','focused-tests.jsonl','focused-command.json','compiler-selector.txt','go-selected-runtime-integration.jsonl','selected-go-command.json','go-selector.txt','native-formatter-parity-runtime-integration.jsonl','formatter-before.json','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','sizes.log','matrix.json','matrix.py','matrix.log','diagnostics.json','diagnostics.py','diagnostics.log','format-runtime-integration-corrected.log','vet-runtime-integration-corrected.log','gofmt-runtime-integration.log','oracle-runtime-integration-version.txt','runtime-merge-identity.json','record-proofs.py']:take(n)
stream=io.BytesIO();logs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['matrix','diagnostics']:
  for p in sorted((out/folder).glob('*')):
   if p.suffix not in ['.stdout','.stderr','.fern']:continue
   data=p.read_bytes();name=folder+'/'+p.name;info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));logs.append(name)
save('execution-inputs-logs.tar.gz',stream.getvalue());manifest=dict(measured_source=measured,integrated_source=core,dependency_base=base,patch_excludes=['docs/benchmarks'],source_sha256=h.hexdigest(),native_sha256=native,tests=tests,matrix_commands=190,balanced_censuses=30,diagnostic_checks=54,source_files=len(files),archived_inputs_logs=len(logs),artifacts=artifacts);(dest/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(artifacts=len(artifacts),source_files=len(files),logs=len(logs),native=native)))
