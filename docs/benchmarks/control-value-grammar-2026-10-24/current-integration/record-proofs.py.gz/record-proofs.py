from pathlib import Path
import collections, gzip, hashlib, io, json, subprocess, tarfile

root = Path('/workspace/lang-grammar-publish')
out = Path('/workspace/scratch/lang-grammar/csv-path-diagnostic-integration')
core = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
base = '72a2bf57b778cddd5d60e499dfbbbc1156b5aef9'
dest = root / 'docs/benchmarks/control-value-grammar-2026-10-24/current-integration'
assert core.startswith('e195d3b14115')
boot = json.loads((out / 'bootstrap/bootstrap.json').read_text())
assert boot['fixedpoint'] and boot['source_git'] == core
assert boot['stages'][1]['sha256'] == boot['stages'][2]['sha256']
tests = []
for name, count, skips, packages in [('compiler-followup', 563, 0, 1), ('go-regressions', 3234, 11, 6), ('missing-block-value-tests', 7, 0, 1)]:
    es = [json.loads(s) for s in (out / (name + '.jsonl')).read_text().splitlines() if s.startswith('{')]
    c = collections.Counter(e['Action'] for e in es)
    assert c['run'] == count and not c['fail'] and c['skip'] == skips, (name, c)
    ps = [e for e in es if 'Test' not in e and e['Action'] == 'pass']
    assert len(ps) == packages and es[-1]['Action'] == 'pass'
    tests.append({'suite': name, 'run': count, 'pass': c['pass'] - packages, 'intentional_skips': skips})
matrix = json.loads((out / 'matrix.json').read_text())
assert matrix['complete'] and len(matrix['runs']) == 190
assert matrix['producer_sha256'] == boot['stages'][2]['sha256']
assert matrix['oracle_sha256'] == hashlib.sha256((out / 'oracle').read_bytes()).hexdigest()
censuses = [r['census'] for r in matrix['runs'] if 'census' in r]
assert len(censuses) == 30 and all(c['allocs'] == c['frees'] and c['live_bytes'] == 0 for c in censuses)
diagnostics = json.loads((out / 'diagnostics.json').read_text())
assert diagnostics['complete'] and len(diagnostics['runs']) == 54
for i in range(0, 54, 2):
    assert diagnostics['runs'][i]['codes'] == diagnostics['runs'][i + 1]['codes']
assert 'Every driver measured here is within 5%' in (out / 'driver-gate.log').read_text()
for name in ['format.log', 'gofmt.log', 'vet.log']:
    assert not (out / name).read_bytes(), name
files = []
digest = hashlib.sha256()
for name in sorted(subprocess.check_output(['git', 'ls-files', 'compiler', 'internal/stdlib'], cwd=root, text=True).splitlines()):
    data = (root / name).read_bytes()
    digest.update(name.encode() + b'\0' + data + b'\0')
    files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert digest.hexdigest() == boot['source_sha256']
dest.mkdir(parents=True, exist_ok=False)
artifacts = []
def save(name, data):
    p = dest / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    artifacts.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
def take(name):
    save(name + '.gz', gzip.compress((out / name).read_bytes(), mtime=0))
save('source-files.json', json.dumps(files, indent=2).encode() + b'\n')
go_files = []
for name in subprocess.check_output(['git', 'ls-files', '*.go'], cwd=root, text=True).splitlines():
    data = (root / name).read_bytes()
    go_files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
save('go-source-files.json.gz', gzip.compress(json.dumps(go_files, indent=2).encode() + b'\n', mtime=0))
patch = subprocess.check_output(['git', 'diff', '--binary', base, core], cwd=root)
subprocess.run(['git', 'apply', '--reverse', '--check', '-'], input=patch, cwd=root, check=True)
save('change.patch.gz', gzip.compress(patch, mtime=0))
for name in ['bootstrap/bootstrap.json', 'bootstrap/stage1.log', 'bootstrap/stage2.log', 'bootstrap/stage3.log', 'compiler-followup.jsonl', 'go-regressions.jsonl', 'missing-block-value-tests.jsonl', 'driver-builds.json', 'driver-sizes.txt', 'driver-gate.log', 'check-sizes.py', 'matrix.json', 'matrix.py', 'matrix.log', 'diagnostics.json', 'diagnostics.py', 'diagnostics.log', 'format.log', 'gofmt.log', 'vet.log', 'oracle-version.txt', 'record-proofs.py']:
    take(name)
stream = io.BytesIO()
logs = []
with tarfile.open(fileobj=stream, mode='w:gz') as archive:
    for folder in ['matrix', 'diagnostics']:
        for p in sorted((out / folder).glob('*')):
            if p.suffix not in ['.stdout', '.stderr', '.fern']:
                continue
            data = p.read_bytes()
            info = tarfile.TarInfo(folder + '/' + p.name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
            logs.append(str(p))
save('execution-inputs-logs.tar.gz', stream.getvalue())
(dest / 'artifacts.json').write_text(json.dumps({'source_commit': core, 'dependency_base': base, 'native_sha256': boot['stages'][2]['sha256'], 'tests': tests, 'source_sha256': digest.hexdigest(), 'oracle_sha256': matrix['oracle_sha256'], 'artifacts': artifacts, 'archived_inputs_and_logs': len(logs)}, indent=2) + '\n')
print('Verified', len(files), 'native source files,', len(go_files), 'Go files,', len(artifacts), 'artifacts and', len(logs), 'inputs and logs')
