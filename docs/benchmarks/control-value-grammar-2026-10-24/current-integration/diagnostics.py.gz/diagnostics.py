from pathlib import Path
import hashlib,json,re,subprocess,time
root=Path('/workspace/lang-grammar-publish');scratch=Path('/workspace/scratch/lang-grammar/csv-path-diagnostic-integration');out=scratch/'diagnostics';out.mkdir(exist_ok=True);oracle=scratch/'oracle';compiler=scratch/'bootstrap/stage3';stdlib=root/'internal/stdlib';rows=[]
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'runs':rows}
def save():(scratch/'diagnostics.json').write_text(json.dumps(meta,indent=2)+'\n')
def check(name,text,code):
 path=out/(name+'.fern');path.write_text(text+'\n');sets=[]
 for engine,tool in [('go',oracle),('self',compiler)]:
  args=[str(tool),'-check',str(path)]+([str(stdlib)]if engine=='self'else[]);start=time.monotonic();r=subprocess.run(args,cwd=root,capture_output=True,timeout=90);(out/(name+'-'+engine+'.stdout')).write_bytes(r.stdout);(out/(name+'-'+engine+'.stderr')).write_bytes(r.stderr);codes=sorted(set(re.findall(r'error\[([A-Z]\d{3})\]',r.stderr.decode())));rows.append({'name':name,'engine':engine,'args':args,'exit':r.returncode,'expected_code':code,'codes':codes,'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'seconds':time.monotonic()-start});save();assert r.returncode==0 if code is None else r.returncode!=0 and code in codes,(name,engine,r.returncode,codes,r.stderr);sets.append(codes)
 assert sets[0]==sets[1],(name,'code mismatch',sets)
old=Path('/workspace/scratch/lang-grammar/committed-diags.py').read_text();start=old.index('cases={');end=old.index('\nrows=[]',start);namespace={};exec(old[start:end],namespace)
for name,(source,code)in namespace['cases'].items():check(name,source,code)
check('lambda_mixed','function main(): i32 { let f = (n: i32): i32 => { match (n) { 0 => { 1 }, _ => { print("x"); } } }; return 0; }','E061')
heads=['while (false)','loop','for (let i = 0; i < 1; i = i + 1)','for x in [1]','for x in 0..1','for x in 0..=1','for (x, y) in [(1, 2)]','outer: while (false)','outer: loop','outer: for x in [1]']
for i,head in enumerate(heads):
 for braces in [False,True]:check('loop-'+str(i)+'-'+str(braces),'function main(): i32 { '+head+(' { break; } 'if braces else' return 1; ')+'return 0; }',None if braces else'P001')
meta['complete']=True;save();print('PASS',len(rows),'checks',flush=True)
