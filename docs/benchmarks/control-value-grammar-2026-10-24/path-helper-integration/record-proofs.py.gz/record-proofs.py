from pathlib import Path
import collections, gzip, hashlib, json, subprocess

root = Path('/workspace/lang-grammar-publish')
out = Path('/workspace/scratch/lang-grammar/path-helper-integration')
old = Path('/workspace/scratch/lang-grammar/csv-path-diagnostic-integration')
prior = 'e195d3b14115941fd89583206eb72e50a6f5c4b2'
core = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
boot = json.loads((out / 'bootstrap/bootstrap.json').read_text())
old_boot = json.loads((old / 'bootstrap/bootstrap.json').read_text())
assert boot['fixedpoint'] and old_boot['fixedpoint']
archive = json.loads(Path('/workspace/scratch/lang-worktree-archives/intermediate-stage1-20261024-0943/manifest.json').read_text())
stages = []
for i, name in enumerate(['stage1', 'stage2', 'stage3']):
    current = (out / 'bootstrap' / name).read_bytes()
    old_path = old / 'bootstrap' / name
    if old_path.exists():
        previous = old_path.read_bytes()
    else:
        entry = next(e for e in archive['files'] if e['path'] == str(old_path))
        packed = Path(entry['archive']).read_bytes()
        assert hashlib.sha256(packed).hexdigest() == entry['archive_sha256']
        previous = gzip.decompress(packed)
    sha = hashlib.sha256(current).hexdigest()
    assert current == previous and sha == boot['stages'][i]['sha256'] == old_boot['stages'][i]['sha256']
    stages.append({'stage': name, 'bytes': len(current), 'sha256': sha, 'byte_identical_to_prior': True})
paths = ['internal/syntax', 'internal/check', 'internal/oracle', 'internal/pkg', 'cmd', 'conformance', 'spec', 'site', 'internal/stdlib', 'bootstrap/stage0.lock']
assert not subprocess.check_output(['git', 'diff', '--name-only', prior, 'HEAD', '--', *paths], cwd=root)
assert subprocess.check_output(['git', 'diff', '--name-only', prior, 'HEAD', '--', 'compiler'], cwd=root, text=True).splitlines() == ['compiler/parser.fern']
files = []
digest = hashlib.sha256()
for name in sorted(subprocess.check_output(['git', 'ls-files', 'compiler', 'internal/stdlib'], cwd=root, text=True).splitlines()):
    data = (root / name).read_bytes()
    digest.update(name.encode() + b'\0' + data + b'\0')
    files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert digest.hexdigest() == boot['source_sha256']
checks = []
for folder, name, expected, skips, packages in [(out, 'source-guards', 4, 0, 1), (out, 'sourcelint-final', 195, 0, 1), (old, 'compiler-followup', 563, 0, 1), (old, 'go-regressions', 3234, 11, 6)]:
    events = [json.loads(s) for s in (folder / (name + '.jsonl')).read_text().splitlines() if s.startswith('{')]
    counts = collections.Counter(e['Action'] for e in events)
    assert counts['run'] == expected and not counts['fail'] and counts['skip'] == skips
    assert len([e for e in events if 'Test' not in e and e['Action'] == 'pass']) == packages
    assert events[-1]['Action'] == 'pass'
    checks.append({'suite': name, 'source_scope': 'current' if folder == out else prior, 'cases': expected, 'intentional_skips': skips})
matrix = json.loads((old / 'matrix.json').read_text())
diags = json.loads((old / 'diagnostics.json').read_text())
assert matrix['complete'] and len(matrix['runs']) == 190 and matrix['producer_sha256'] == stages[2]['sha256']
assert matrix['oracle_sha256'] == hashlib.sha256((old / 'oracle').read_bytes()).hexdigest()
assert diags['complete'] and len(diags['runs']) == 54
for fixture in matrix['fixtures']:
    p = root / 'conformance/cases' / ('control_value_' + fixture['name']) / 'main.fern'
    assert hashlib.sha256(p.read_bytes()).hexdigest() == fixture['sha256']
assert 'Every driver measured here is within 5%' in (out / 'driver-gate.log').read_text()
assert not (out / 'format.log').read_bytes()
certificate = {'source_commit': core, 'native_checkpoint': boot['source_git'], 'prior_source': prior, 'stages': stages, 'unchanged_source_paths': paths, 'native_source_sha256': digest.hexdigest(), 'go_oracle_sha256': matrix['oracle_sha256'], 'matrix_commands': 190, 'diagnostic_commands': 54, 'checks': checks}
dest = root / 'docs/benchmarks/control-value-grammar-2026-10-24/path-helper-integration'
dest.mkdir(parents=True, exist_ok=False)
artifacts = []
def save(name, data):
    p = dest / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    artifacts.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
save('identity-certificate.json', json.dumps(certificate, indent=2).encode() + b'\n')
save('source-files.json.gz', gzip.compress(json.dumps(files, indent=2).encode() + b'\n', mtime=0))
save('parser-helper.patch.gz', gzip.compress(subprocess.check_output(['git', 'diff', prior, 'HEAD', '--', 'compiler/parser.fern'], cwd=root), mtime=0))
for name in ['bootstrap/bootstrap.json', 'bootstrap/stage1.log', 'bootstrap/stage2.log', 'bootstrap/stage3.log', 'source-guards.jsonl', 'sourcelint-final.jsonl', 'driver-builds.json', 'driver-sizes.txt', 'driver-gate.log', 'check-sizes.py', 'format.log', 'record-proofs.py']:
    save(name + '.gz', gzip.compress((out / name).read_bytes(), mtime=0))
(dest / 'artifacts.json').write_text(json.dumps({'source_commit': core, 'artifacts': artifacts}, indent=2) + '\n')
print('Verified all three compiler stages, unchanged semantic inputs and', len(artifacts), 'artifacts')
