from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-validate-os-text-publish');scratch=Path('/workspace/scratch/lang-validate-os-text/path-helper-integration');out=scratch/'matrix';out.mkdir(exist_ok=True);fixture=out/'host';fixture.mkdir(exist_ok=True)
compiler=scratch/'bootstrap/stage3';oracle=Path('/workspace/scratch/lang-validate-os-text/current-integration/oracle');stdlib=root/'internal/stdlib';rows=[]
bad=[b'\x80',b'\xff',b'\xc0\x80',b'\xc2',b'\xe0\x80\x80',b'\xe2\x82',b'\xed\xa0\x80',b'\xf0\x80\x80\x80',b'\xf0\x9f\x98',b'\xf4\x90\x80\x80',b'\xf5\x80\x80\x80',b'\xc2A',b'a'*180+b'\xff']
valid=fixture/'valid';valid.mkdir(exist_ok=True)
for name in ['é-文件','¢€𐐀','a'*180+'🙂']:(valid/name).touch()
for i,b in enumerate(bad):
 d=fixture/('bad'+str(i));d.mkdir(exist_ok=True);(d/'valid-字').touch();fd=os.open(os.fsencode(d)+b'/bad_'+b,os.O_CREAT|os.O_WRONLY,0o600);os.close(fd)
 link=fixture/('link'+str(i))
 if not link.is_symlink():os.symlink(b,os.fsencode(link))
link=fixture/'valid-link'
if not link.is_symlink():link.symlink_to('é-文件')
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'malformed_name_suffixes_hex':[b.hex()for b in bad],'runs':rows,'fixtures':[]}
def save():(scratch/'matrix.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,args,cwd=root,extra={}):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=cwd,env=dict(os.environ,**extra),capture_output=True,timeout=180);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);row={'name':name,'args':list(map(str,args)),'cwd':str(cwd),'exit':r.returncode,'seconds':time.monotonic()-start};rows.append(row);save();print(row,flush=True);assert r.returncode==0,(name,r.stdout,r.stderr);return r,row
header='''function invalid[T](r: Result[T, IoError], path: string): boolean {
 match (r) { Ok(_) => { return false; }, Err(e) => {
  match (e) { InvalidUtf8(p) => { return p == path; }, _ => { return false; } }
 } } return false;
}
function main(): i32 {
'''
for native in [True,False]:
 name='native'if native else'portable';lines=[header];step=0
 def check(s):
  global step
  step+=1;lines.append(s.replace('FAIL',str(step))+'\n')
 for op in ['read_dir','read_dir_all','read_dir_ino','read_dir_ino_all']:check('match ('+op+'("valid")) { Err(_) => { return FAIL; }, Ok(ns) => { if (ns.len() < 3) { return FAIL; } } }')
 check('match (read_dir("valid")) { Err(_) => { return FAIL; }, Ok(ns) => { let found: i32 = 0; for n in ns { if (n == "é-文件" || n == "¢€𐐀") { found = found + 1; } } if (found != 2) { return FAIL; } } }')
 for i in range(len(bad)):
  d='bad'+str(i)
  for op in ['read_dir','read_dir_all','read_dir_ino','read_dir_ino_all']:check(f'if (!invalid({op}("{d}"), "{d}")) {{ return FAIL; }}')
  if native:check(f'match (open_dir("{d}")) {{ Err(_) => {{ return FAIL; }}, Ok(d) => {{ let first: boolean = invalid(d.entries(), ""); let second: boolean = invalid(d.entries(), ""); d.close(); if (!first || !second) {{ return FAIL; }} }} }}')
  check(f'if (!invalid(read_link("link{i}"), "link{i}")) {{ return FAIL; }}')
 check('match (read_link("valid-link")) { Err(_) => { return FAIL; }, Ok(s) => { if (s != "é-文件") { return FAIL; } } }')
 check('match (read_dir("absent")) { Err(NotFound(p)) => { if (p != "absent") { return FAIL; } }, _ => { return FAIL; } }')
 if native:
  check('match (getcwd()) { Err(_) => { return FAIL; }, Ok(p) => { if (p.len() == 0) { return FAIL; } } }')
  check('if (hostname().len() < 0 || uname_field(-1) != "") { return FAIL; }')
  check('match (mounts()) { Err(_) => { return FAIL; }, Ok(ms) => { for m in ms { if (m.source.len() < 0 || m.target.len() < 0 || m.fstype.len() < 0) { return FAIL; } } } }')
 lines.append('return 0;\n}\n');path=out/(name+'.fern');path.write_text(''.join(lines));meta['fixtures'].append({'name':name,'checks':step,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for engine,tool in [('go',oracle),('self',compiler)]:
  for mode in ['-check','-interp']:run(name+'-'+engine+mode,[tool,mode,path]+([stdlib]if engine=='self'else[]),fixture if mode=='-interp'else root)
 for target in (['x86-64-linux','arm64-linux','arm64-darwin']if native else['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']):
  dest=out/(name+'-'+target);run(name+'-build-'+target,[compiler,'-target',target,'-o',dest,path,stdlib],extra={'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest]if target=='x86-64-linux'else['qemu-aarch64',dest]if target=='arm64-linux'else['wasmtime','run','--dir=.',dest]
  r,row=run(name+'-run-'+target,args,fixture);assert not r.stdout
  m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,(name,target,r.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
meta['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
