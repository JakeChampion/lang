from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile,io,collections
root=Path('/workspace/lang-validate-os-text-publish');out=Path('/workspace/scratch/lang-validate-os-text/path-helper-integration');core='0e6cb8864dfbf7a63ae1b42ffc5c29bcd1c59b1d';base='7122461ff44deeffbaaac9dede58639534ca340f';dest=root/'docs/benchmarks/os-text-2026-10-23/path-helper-integration'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==core
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==core and boot['fixedpoint'];files=[];digest=hashlib.sha256()
for n in sorted(subprocess.check_output(['git','ls-files','compiler','internal/stdlib'],cwd=root,text=True).splitlines()):
 data=(root/n).read_bytes();digest.update(n.encode()+b'\0'+data+b'\0');files.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert digest.hexdigest()==boot['source_sha256'];assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for n in ['format.log','gofmt.log','vet.log']:assert not(out/n).read_bytes()
tests=[]
for name,count,skips in [('family-tests',281,2)]:
 es=[json.loads(l)for l in(out/(name+'.jsonl')).read_text().splitlines()if l.startswith('{')];counts=collections.Counter(e['Action']for e in es);assert counts['run']==count and counts['fail']==0 and counts['skip']==skips and es[-1]['Action']=='pass',(name,counts);tests.append({'suite':name,'actions':dict(counts)})
m=json.loads((out/'matrix.json').read_text());assert m['complete']and len(m['runs'])==20 and m['source_commit']==core and m['producer_sha256']==boot['stages'][-1]['sha256'];assert m['oracle_sha256']==hashlib.sha256(Path('/workspace/scratch/lang-validate-os-text/current-integration/oracle').read_bytes()).hexdigest();assert all(r['exit']==0 for r in m['runs']);cs=[r['census']for r in m['runs']if'census'in r];assert len(cs)==5 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision=81fbf50964f8763695b04b8ceeff80dbf56517bc' in version and'vcs.modified=false'in version
baseline=json.loads((out/'public-baseline.json').read_text());assert baseline['complete']and len(baseline['runs'])==4 and all(r['exit']==r['expected_exit']for r in baseline['runs']);assert baseline['input_sha256']==m['fixtures'][0]['sha256']
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def take(n):
 data=(out/n).read_bytes();packed=len(data)>1000 or n.endswith('.py') or n.endswith('version.txt');save(n+'.gz'if packed else n,gzip.compress(data,mtime=0)if packed else data)
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=subprocess.check_output(['git','diff','--binary',base,core],cwd=root);subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','family-tests.jsonl','format.log','gofmt.log','vet.log','oracle-version.txt','matrix.json','matrix.py','matrix.log','public-baseline.json','baseline.py','baseline.log']:take(n)
stream=io.BytesIO();logs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for p in sorted((out/'matrix').glob('*'))+sorted(out.glob('public-*.stdout'))+sorted(out.glob('public-*.stderr')):
  if p.suffix not in['.stdout','.stderr','.fern']:continue
  data=p.read_bytes();logs.append(p);info=tarfile.TarInfo(('matrix/'if p.parent.name=='matrix'else'baseline/')+p.name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
assert len(logs)==50;save('output-logs-and-inputs.tar.gz',stream.getvalue());manifest={'source_commit':core,'dependency_base':base,'source_sha256':digest.hexdigest(),'source_files':len(files),'tests':tests,'oracle_source_commit':'81fbf50964f8763695b04b8ceeff80dbf56517bc','oracle_sha256':m['oracle_sha256'],'matrix_commands':20,'balanced_execution_censuses':5,'public_baseline_commands':4,'artifacts':artifacts};(dest/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified',len(artifacts),'artifacts',len(files),'source files',len(logs),'logs and inputs')
