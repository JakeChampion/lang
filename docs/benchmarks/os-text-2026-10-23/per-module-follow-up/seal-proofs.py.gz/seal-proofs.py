from pathlib import Path
import json,hashlib,gzip,subprocess,collections,tarfile,io
root=Path('/workspace/lang-validate-os-text-publish');out=Path('/workspace/scratch/lang-validate-os-text/per-module-byte-follow-up');dest=root/'docs/benchmarks/os-text-2026-10-23/per-module-follow-up';dest.mkdir(exist_ok=False);base='77602f33f56372f4eabbfc7229bd13fce2eb928d';core=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();boot=json.loads((out/'bootstrap-final/bootstrap.json').read_text());assert boot['fixedpoint']and len({s['sha256']for s in boot['stages']})==1;assert not subprocess.check_output(['git','diff',boot['source_git'],core,'--','compiler','internal/stdlib','bootstrap/stage0.lock'],cwd=root)
files=[];scope=hashlib.sha256()
for n in sorted(subprocess.check_output(['git','ls-files','compiler','internal/stdlib'],cwd=root,text=True).splitlines()):
 data=(root/n).read_bytes();scope.update(n.encode()+b'\0'+data+b'\0');files.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert scope.hexdigest()==boot['source_sha256'];tests={}
for n,want in [('all-ci-fixes.jsonl',335),('byte-results-regression.jsonl',4)]:
 ds=[json.loads(l)for l in(out/n).read_text().splitlines()if l.startswith('{')];counts=collections.Counter(d['Action']for d in ds);assert counts['run']==counts['pass']-1==want and counts['fail']==counts['skip']==0;assert ds[-1]['Action']=='pass';tests[n]={'cases':want,'source_commit':boot['source_git']if n=='all-ci-fixes.jsonl'else core}
m=json.loads((out/'byte-matrix.json').read_text());assert m['source_commit']==core and m['complete']and len(m['runs'])==38;assert all(r['code']==0 for r in m['runs']);cs=[r['census']for r in m['runs']if'census'in r];assert len(cs)==9 and all(x['allocs']==x['frees']and x['live_bytes']==0 for x in cs);assert m['compiler_sha256']==boot['stages'][-1]['sha256'];assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text();assert all((out/n).stat().st_size==0 for n in ['format.log','gofmt.log','vet.log']);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def take(n):
 data=(out/n).read_bytes();packed=len(data)>1000 or n.endswith('.py');save(n+'.gz'if packed else n,gzip.compress(data,mtime=0)if packed else data)
for n in ['all-ci-fixes.jsonl','byte-results-regression.jsonl','bootstrap-final/bootstrap.json','bootstrap-final/stage1.log','bootstrap-final/stage2.log','bootstrap-final/stage3.log','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','sizes.log','format.log','gofmt.log','vet.log','byte-matrix.json','byte-matrix.py','byte-matrix.log','seal-proofs.py']:take(n)
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=subprocess.check_output(['git','diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks'],cwd=root);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('source-change.patch.gz',gzip.compress(patch,mtime=0));stream=io.BytesIO();logs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for p in sorted((out/'byte-matrix').glob('*')):
  if p.suffix not in['.stdout','.stderr','.fern']:continue
  data=p.read_bytes();item=tarfile.TarInfo(p.name);item.size=len(data);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(data));logs.append(p.name)
save('byte-matrix-inputs-and-logs.tar.gz',stream.getvalue());manifest={'source_commit':core,'native_source_commit':boot['source_git'],'dependency_base':base,'source_sha256':scope.hexdigest(),'source_files':len(files),'native_sha256':boot['stages'][-1]['sha256'],'tests':tests,'matrix_commands':38,'balanced_censuses':9,'matrix_oracle_source':'3048da4e51442f2baa9e8b045f5003329d72d214','matrix_oracle_sha256':m['oracle_sha256'],'source_patch_excludes':['docs/benchmarks'],'artifacts':artifacts};(dest/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'source':core,'native_source':boot['source_git'],'artifacts':len(artifacts),'source_files':len(files),'matrix_logs':len(logs)}))
