from pathlib import Path
import json,hashlib,gzip,subprocess,collections,tarfile,io
root=Path('/workspace/lang-validate-os-text-publish');out=Path('/workspace/scratch/lang-validate-os-text/byte-api-sorted-final');dest=root/'docs/benchmarks/os-text-2026-10-23/byte-api-follow-up';dest.mkdir(exist_ok=False)
core='3048da4e5';core=subprocess.check_output(['git','rev-parse',core],cwd=root,text=True).strip();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==core
base='b49497ea8be5a072de645a510daaa1f7ced7f1be';artifacts=[]
def save(name,data):
 p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def take(name,path=None):
 data=(path or(out/name)).read_bytes();packed=len(data)>1200 or name.endswith('.py');save(name+'.gz'if packed else name,gzip.compress(data,mtime=0)if packed else data)
logs={}
for name,want in [('checker-regressions.jsonl',1),('go-other-regressions.jsonl',5),('family-regressions.jsonl',2),('literate-regressions.jsonl',1)]:
 ds=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];terminal=[d for d in ds if'Test'not in d and d['Action']in('pass','fail')];assert len(terminal)==want and all(d['Action']=='pass'for d in terminal),(name,terminal);assert not any(d['Action']=='fail'for d in ds),name
 logs[name]={'packages':[d['Package']for d in terminal],'cases':dict(collections.Counter(d['Action']for d in ds if'Test'in d and d['Action']in('pass','skip'))),'skips':[d['Test']for d in ds if d['Action']=='skip']};take(name)
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==core and boot['fixedpoint'];assert len({s['sha256']for s in boot['stages']})==1
matrices={}
for name,count in [('matrix.json',20),('byte-matrix.json',38)]:
 m=json.loads((out/name).read_text());assert m['source_commit']==core and m['complete'];assert len(m['runs'])==count;assert all(r.get('exit',r.get('code'))==0 for r in m['runs']);c=[r['census']for r in m['runs']if'census'in r];assert all(x['allocs']==x['frees'] and x['live_bytes']==0 for x in c);matrices[name]={'commands':count,'balanced_censuses':len(c)}
for name in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','driver-builds.json','driver-sizes.txt','driver-gate.log','sizes.log','check-sizes.py','format.log','gofmt.log','vet.log','matrix.json','matrix.py','matrix.log','byte-matrix.json','byte-matrix.py','byte-matrix.log','lint-ratchet.txt','lint-ratchet-build.log']:
 take(name)
assert all((out/n).stat().st_size==0 for n in ['format.log','gofmt.log','vet.log'])
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['matrix','byte-matrix']:
  for p in sorted((out/folder).glob('*')):
   if p.suffix not in ['.fern','.stdout','.stderr']:continue
   data=p.read_bytes();n=folder+'/'+p.name;item=tarfile.TarInfo(n);item.size=len(data);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(data));inputs.append({'path':n,'sha256':hashlib.sha256(data).hexdigest()})
save('matrix-inputs-and-logs.tar.gz',stream.getvalue());save('matrix-inputs-and-logs.json',json.dumps(inputs,indent=2).encode()+b'\n')
paths=['compiler','internal/stdlib','internal/check/checker','internal/oracle/interp','internal/pkg/caps','internal/pkg/platforms','internal/testing/e2e','internal/testing/e2ecompiler','internal/testing/e2eharness','internal/testing/sourcelint','bootstrap'];files=[];scope=hashlib.sha256()
for name in sorted(subprocess.check_output(['git','ls-files',*paths],cwd=root,text=True).splitlines()):
 data=(root/name).read_bytes();sha=hashlib.sha256(data).hexdigest();files.append({'path':name,'bytes':len(data),'sha256':sha});scope.update(name.encode()+b'\0'+data+b'\0')
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=subprocess.check_output(['git','diff','--binary',base,core],cwd=root);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
take('published-seed-release.json',Path('/workspace/scratch/lang-validate-os-text/readlink-bytes-followup/published-seed-release.json'));take('published-seed-checksums.json',Path('/workspace/scratch/lang-stage0-9eddfb5/verified.json'))
# Earlier GNU runs retain their measured source. Native byte implementations are unchanged.
earlier='705107d8fae4baff8c78e5304c11ec8861b1f387';native=['compiler/asmcore.fern','compiler/asm_ir.fern','compiler/asm_arm64_ir.fern','compiler/semsource.fern','compiler/ir.fern','compiler/ssarc.fern','coreutils/du.fern','coreutils/readlink.fern','coreutils/realpath.fern','coreutils/stat.fern','coreutils/lib/canon.fern'];identity=[]
for n in native:
 old=subprocess.check_output(['git','show',earlier+':'+n],cwd=root);now=(root/n).read_bytes();assert old==now,n;identity.append({'path':n,'sha256':hashlib.sha256(now).hexdigest()})
gnu={}
for name in ['gnu-byte-parity-host.jsonl','gnu-byte-parity-arm-native-reference.jsonl']:
 p=Path('/workspace/scratch/lang-validate-os-text/readlink-bytes-followup')/name;ds=[json.loads(l)for l in p.read_text().splitlines()if l.startswith('{')];assert all(d['Action']!='fail'for d in ds);assert any('Test'not in d and d['Action']=='pass'for d in ds);gnu[name]={'source_commit':earlier,'passed_cases':sum(d['Action']=='pass'and'Test'in d for d in ds)};take('earlier-gnu/'+name,p)
take('earlier-gnu/cross-exec.py',Path('/workspace/scratch/lang-validate-os-text/readlink-bytes-followup/cross-exec.py'));save('native-byte-implementation-identity.json',json.dumps(identity,indent=2).encode()+b'\n')
take('seal-proofs.py');manifest={'source_commit':core,'dependency_base':base,'source_sha256':scope.hexdigest(),'source_files':len(files),'bootstrap':boot,'oracle_sha256':hashlib.sha256((out/'oracle').read_bytes()).hexdigest(),'tests':logs,'matrices':matrices,'earlier_gnu':gnu,'artifacts':artifacts};(dest/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'core':core,'artifacts':len(artifacts),'source_files':len(files),'logs':logs,'matrices':matrices},indent=2))
