#!/usr/bin/env python3
import os,sys
with open(sys.argv[1],'rb') as f: header=f.read(20)
if header[:4]==b'\x7fELF' and int.from_bytes(header[18:20],'little')==183:
 os.execvp('qemu-aarch64',['qemu-aarch64','-cpu','max',*sys.argv[1:]])
os.execv(sys.argv[1],sys.argv[1:])
