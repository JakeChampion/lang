from pathlib import Path
import subprocess,hashlib,os,json,re,time
root=Path('/workspace/lang-validate-os-text-publish');out=Path('/workspace/scratch/lang-validate-os-text/byte-api-sorted-final');work=out/'byte-matrix';work.mkdir(exist_ok=False);host=work/'host';host.mkdir();(host/'names').mkdir();(host/'names'/'valid').touch();fd=os.open(os.fsencode(host/'names')+b'/\xff\xfe',os.O_CREAT|os.O_WRONLY,0o600);os.close(fd);os.symlink(b'\xff\xfe',os.fsencode(host/'bad'));os.symlink('valid-target',host/'good');(host/'valid-target').touch();(host/'valid').mkdir();(host/'valid'/'é-文件').touch();os.symlink('é-文件',host/'valid-link')
compiler=out/'bootstrap/stage3';oracle=out/'oracle';stdlib=root/'internal/stdlib';rows=[];meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows,'fixtures':[]}
def save():(out/'byte-matrix.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,args,sanitize=False,census=False):
 env=dict(os.environ)
 if sanitize:env.update(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1')
 start=time.monotonic();p=subprocess.run([str(x)for x in args],cwd=host,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180);(work/(name+'.stdout')).write_bytes(p.stdout);(work/(name+'.stderr')).write_bytes(p.stderr);row={'name':name,'args':[str(x)for x in args],'cwd':str(host),'code':p.returncode,'seconds':time.monotonic()-start};rows.append(row);save();assert p.returncode==0,(name,p.stdout,p.stderr)
 if census:
  m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);assert m,(name,p.stderr);a,f,l=map(int,m.groups());assert a==f and l==0;row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
 print(row,flush=True)
inputs=Path('/workspace/scratch/lang-validate-os-text/readlink-bytes-followup/fixtures')
for name in ['raw','directory','directory-handle','portable']:
 source=(inputs/(name+'.fern')).read_text()if name!='portable'else'''function main(): i32 {
  match (read_link_bytes("valid-link")) { Ok(b) => { if (string_from_bytes_unchecked(b) != "é-文件") { return 1; } }, Err(_) => { return 2; } }
  match (read_dir_bytes("valid")) { Ok(names) => { if (names.len() != 1 || string_from_bytes_unchecked(names[0]) != "é-文件") { return 3; } }, Err(_) => { return 4; } }
  match (read_link_bytes("absent")) { Err(NotFound(_)) => {}, _ => { return 5; } }
  match (read_dir_bytes("absent")) { Err(NotFound(_)) => {}, _ => { return 6; } }
  return 0;
}
'''
 path=work/(name+'.fern');path.write_text(source);meta['fixtures'].append({'name':name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for engine,tool in [('go',oracle),('self',compiler)]:
  for mode in ['-check','-interp']:run(name+'-'+engine+mode,[tool,mode,path]+([stdlib]if engine=='self'else[]))
 for target in ['x86-64-linux','arm64-linux','arm64-darwin']+(['wasm32-wasi']if name=='portable'else[]):
  dest=work/(name+'-'+target);run(name+'-build-'+target,[compiler,'-target',target,'-o',dest,path,stdlib],True)
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest]if target=='x86-64-linux'else['qemu-aarch64','-cpu','max',dest]if target=='arm64-linux'else['wasmtime','run','--dir=.',dest]
  run(name+'-run-'+target,args,census=True)
meta['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
