from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,hashlib,os,time
root=Path('/workspace/lang-validate-os-text-publish');out=Path('/workspace/scratch/lang-validate-os-text/byte-api-sorted-final');pin=Path('/workspace/scratch/lang-stage0-9eddfb5/fern-selfhost-x86-64-linux')
digest=hashlib.sha256(pin.read_bytes()).hexdigest();assert digest in (root/'bootstrap/stage0.lock').read_text()
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['fixedpoint'];report=out/'drivers';report.mkdir(exist_ok=False);env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')}
names=['fern.fern','drivers/asm_load_run.fern','drivers/asm_modload_run.fern','drivers/asm_ir_run.fern','drivers/asm_run.fern','drivers/wasm_ir_run.fern','drivers/wasm_run.fern','drivers/wasm_runio_run.fern','drivers/asm_pathprobe_run.fern','drivers/checker_modload_run.fern']
def build(name):
 dest=report/Path(name).stem;args=[str(pin),'-target','x86-64-linux','-o',str(dest),str(root/'compiler'/name),str(root/'internal/stdlib')];start=time.monotonic()
 with(report/(dest.name+'.log')).open('w')as log:subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 row={'source':name,'arguments':args,'producer_sha256':digest,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'seconds':time.monotonic()-start};print({k:row[k]for k in ['source','bytes','seconds']},flush=True);return row
with ThreadPoolExecutor(max_workers=2)as ex:rows=list(ex.map(build,names))
(out/'driver-builds.json').write_text(json.dumps({'source_commit':boot['source_git'],'builds':rows},indent=2)+'\n');(out/'driver-sizes.txt').write_text('fern.fern/stage2\t'+str(boot['stages'][1]['bytes'])+'\n'+''.join(r['source']+'\t'+str(r['bytes'])+'\n'for r in rows))
with(out/'driver-gate.log').open('w')as log:subprocess.run([str(root/'scripts/ci-check-driver-sizes'),str(root/'.github/selfhost-driver-sizes.txt'),str(out/'driver-sizes.txt')],cwd=root,env=dict(env,FERN_CI_SIZE_GATE_STRICT='1',FERN_SIZE_REPORT_COMPLETE='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
print('All 11 strict driver sizes pass',flush=True)
