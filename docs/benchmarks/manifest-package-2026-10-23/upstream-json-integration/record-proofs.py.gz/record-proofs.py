from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess
root=Path('/tmp/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-manifest-package/upstream-json-integration');source='5e151dec3bc91b57d372eae9a9ab8df91e64df2c';base='59372b5e2082afa6239327a45033346311fcfa1c';dest=root/'docs/benchmarks/manifest-package-2026-10-23/upstream-json-integration'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
def suite(name,count,packages=1):
 rows=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];c=collections.Counter(r['Action']for r in rows if r.get('Test'));terminal=[r for r in rows if not r.get('Test')and r['Action']in['pass','fail','skip']]
 assert c['run']==c['pass']==count and not c['fail']and not c['skip'],(name,c)
 assert len(terminal)==packages and terminal[0]['Action']=='pass'and rows[-1]['Action']=='pass'
 return dict(file=name,cases=count,passed=count,skipped=0)
tests=[suite('native-regressions.jsonl',1291),suite('go-regressions.jsonl',2461,5),suite('json-roundtrip-regression.jsonl',1)]
native=out/'bootstrap/stage3';oracle=out/'oracle';boot=json.loads((out/'bootstrap/bootstrap.json').read_text())
assert boot['source_git']==source and boot['fixedpoint']and boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f'
assert sha(native)==sha(out/'bootstrap/stage2')==boot['stages'][2]['sha256']=='a293a8b92b1f3c49ad9eeb5559ea237e4512765ca81a91a62dd2d9c8bb77fa92'
assert len((out/'final-driver-sizes.txt').read_text().splitlines())==11 and 'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text()
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+source in version and 'vcs.modified=false'in version
for name in ['compiler-source-certificate.json','native-source-certificate.json']:
 d=json.loads((out/name).read_text());assert not git('diff','--name-only',d['recorded_source'],source,'--',*d['paths'])
matrices=[]
for name,count,census in [('committed-matrix-final-results.json',90,15),('package-project-matrix-final-results.json',19,3),('reexport-matrix-final-results.json',86,12),('all-coreutils-checks.json',212,0),('json-roundtrip-matrix.json',10,3)]:
 d=json.loads((out/name).read_text());assert d.get('core_commit',d.get('source_commit'))==source and len(d['commands'])==count and all(r['pass_']for r in d['commands'])
 if 'binaries'in d:assert d['binaries'][str(native)]['sha256']==sha(native)and d['binaries'][str(oracle)]['sha256']==sha(oracle)
 else:assert d['compiler_sha256']==sha(native)and d['oracle_sha256']==sha(oracle)
 cs=[tuple(map(int,m.groups()))for r in d['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==census and all(a==b and n==0 for a,b,n in cs);matrices.append(dict(file=name,commands=count,balanced_censuses=census))
embed=json.loads((out/'embedded-results.json').read_text());assert embed['source_commit']==source and len(embed['commands'])==9 and all(r['pass_']for r in embed['commands'])and sha(Path(embed['binary']))==embed['binary_sha256'];assert sum(r.get('trace_events',0)for r in embed['commands'])==434
assert json.loads((out/'format-final.json').read_text())==dict(source_commit=source,files=1218,exit=0,selection='Makefile FERN_SRCS')
for name in ['vet.log','gofmt.log','format-check.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert 'Result: 0 errors, 0 warnings.'in(out/name).read_text()
patch=git('diff','--binary',base,source);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
files=['bootstrap/bootstrap.json', 'bootstrap/completed-intermediates.json', 'bootstrap/cross-scope-identical-images.json', 'bootstrap/stage1.log', 'bootstrap/stage2.log', 'bootstrap/stage3.log', 'native-regressions.jsonl', 'go-regressions.jsonl', 'json-roundtrip-regression.jsonl', 'json-roundtrip-matrix.json', 'compiler-source-certificate.json', 'native-source-certificate.json', 'oracle-version.txt', 'embedded-results.json', 'embedded-results.log', 'final-driver-builds.json', 'final-driver-sizes.txt', 'final-driver-gate.log', 'check-sizes.py', 'format-final.json', 'format-check.log', 'vet.log', 'gofmt.log', 'readme-ste.log', 'pr-body-ste.log', 'pr-body.md', 'record-proofs.py', 'all-coreutils-checks.json', 'check-all-coreutils.py', 'merge.log','prior-tree-identity.json']
for stem in ['committed-matrix-final','package-project-matrix-final','reexport-matrix-final']:files.extend([stem+'.py',stem+'-results.json',stem+'.log'])
for name in files:save(name.replace('/','__')+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
save('check-embedded.py.gz',gzip.compress(Path('/workspace/scratch/lang-check-package-json-embedded.py').read_bytes(),mtime=0))
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,prior_canonical_commit=base,public_head_before_update="e8c240cf3f10c10cddd4681bc656b7da3221700f",merged_main="c61e92a837387211575e57797c8eb254ef243205",tests=tests,matrices=matrices,embedded_commands=9,balanced_trace_events=434,compiler=dict(path=str(native),sha256=sha(native),bytes=native.stat().st_size),oracle=dict(path=str(oracle),sha256=sha(oracle)),artifacts=artifacts),indent=2)+'\n');print('PASS',len(artifacts),'artifacts; 3753 checks; 417 matrix and caller commands')
