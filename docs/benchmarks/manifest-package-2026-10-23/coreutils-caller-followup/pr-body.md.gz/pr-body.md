Package visibility now follows manifest roots in both frontends. A nested manifest starts a new package even if its name matches the outer package. Modules without a manifest use their directory. The configured standard library is one package.

Enum constructors and patterns follow the visibility of their enum. Invalid public re-exports report E087 before name resolution. The checks cover unused declarations and invalid chains. Public declarations retain precedence over hidden variants with the same name.

75 library helpers across seven modules use package visibility. The identity record verifies unchanged document bytes after visibility normalization and the same change to chunk labels. Generated JSON code retains access to its helpers.

Validation:

- The Go run passes 2,461 checks across five packages. The current run includes the generator and caller updates.
- All 5,786 affected GNU 9.12 parity checks pass without skips. Both frontends check all 106 coreutils programs.
- The decimal boundary probe passes ten commands on three target runtimes, with three balanced allocation counts.
- The byte-writer suite passes nine checks. Its Darwin execution check is skipped on Linux after the image builds. Two additional Darwin images build through both frontends.
- All 50 focused native checks pass. The private decimal table probe passes all 619 exponent rows.
- Three matrices pass 195 commands across both frontends and three target runtimes. All 30 runtime allocation counts balance. Darwin images are built but are not executed locally.
- The compiler with its embedded library passes five checks and records 434 balanced allocation trace events.
- A fresh three-stage bootstrap produces identical stages 2 and 3 at 14,466,048 bytes. All 11 strict driver size gates pass.
- All 1,219 source format checks pass. Go format, Go vet, feature census, and complexity checks pass. Compiler complexity is 16,320 against the unchanged limit of 16,324.35.

Coreutils owns its raw decimal helpers, drop-managed buffers, and generated extended-precision cache. The byte-writer test uses the public constructor. All 75 library helpers remain private.

The current proof capsule is `docs/benchmarks/manifest-package-2026-10-23/coreutils-caller-followup`. It includes fresh caller checks and all 195 package matrix commands. Certificates verify unchanged compiler, library, pin, and size limits against the complete `visibility-final-integration` measurement. Earlier measurements retain their recorded source scopes. Full CI must pass before merge.

Closes #12721.
Closes #13077.
Closes #13096.
