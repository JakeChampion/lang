from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path('/workspace/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-manifest-package/coreutils-caller-followup');native=out.parent/'visibility-final-integration/bootstrap/stage3';oracle=out/'oracle-current';src=out/'decimal-probe.fern';rows=[];env=dict(os.environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1')
def run(name,args,census=False):
    p=subprocess.run(list(map(str,args)),cwd=root,env=env,text=True,capture_output=True,timeout=90)
    good=p.returncode==0 and not p.stdout
    if census:
        m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);good=good and bool(m and m[1]==m[2] and m[3]=='0')
    r=dict(name=name,args=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=good);rows.append(r);print(name,'PASS'if good else 'FAIL',flush=True)
    assert good,r
for tag,cli in [('Go',oracle),('self',native)]:
    for mode in ['-check','-interp']:run(tag+mode,[cli,mode,src,root/'internal/stdlib'])
for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
    binary=out/('decimal-probe-'+target);args=[native,'-target',target,'-o',binary]
    if target=='wasm32-wasi':args+=['-emit','command-module']
    run(target+'-build',args+[src,root/'internal/stdlib']);run(target+'-run',runner+[binary],True)
(out/'decimal-probe-results.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),probe_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),compiler_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),oracle_sha256=hashlib.sha256(oracle.read_bytes()).hexdigest(),commands=rows),indent=2)+'\n')
