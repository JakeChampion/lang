from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess
root=Path('/workspace/lang-manifest-package-publish')
out=Path('/workspace/scratch/lang-manifest-package/coreutils-caller-followup')
prior=out.parent/'visibility-final-integration'
source='63dc2c64b9cc4c20c42710ad6b298608c83e94f5'
go_source='a5aca3218a868c7b85492a12b9d563a6bd9fa44b'
base='84644a66cbda19523833b497c127ad60a399def9'
dest=root/'docs/benchmarks/manifest-package-2026-10-23/coreutils-caller-followup'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
cert=json.loads((out/'native-source-certificate.json').read_text())
assert cert['current_source']==source and not git('diff','--name-only',cert['recorded_source'],source,'--',*cert['paths'])
assert sha(Path(cert['compiler']))==cert['compiler_sha256']
frontend=json.loads((out/'frontend-source-certificate.json').read_text())
assert frontend['recorded_source']==go_source and frontend['current_source']==source
assert not git('diff','--name-only',go_source,source,'--',*frontend['paths'])
version=(out/'oracle-current-version.txt').read_text()
assert 'vcs.revision='+go_source in version and 'vcs.modified=false' in version
def suite(name,cases,packages,skips=0):
    es=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')]
    c=collections.Counter(e['Action']for e in es if e.get('Test'))
    terminal=[e for e in es if not e.get('Test')and e['Action']in ['pass','fail','skip']]
    assert c['run']==cases and c['pass']==cases-skips and c['skip']==skips and not c['fail'],(name,c)
    assert len(terminal)==packages and all(e['Action']=='pass'for e in terminal),(name,terminal)
    return dict(file=name,cases=cases,skips=skips,packages=terminal)
tests=[suite('go-regressions-final.jsonl',2461,5),suite('gnu-9.12-reference-complete.jsonl',5786,1),suite('buffer-writer-regressions.jsonl',10,1,1),suite('affected-example-checks.jsonl',4,1),suite('fern-runner-regressions.jsonl',2,1),suite('pr-final-timezone-regressions.jsonl',1194,1),suite('cross-target-callers.jsonl',20,1)]
matrices=[]
for name,count,census in [('committed-matrix-final-results.json',90,15),('package-project-matrix-final-results.json',19,3),('reexport-matrix-final-results.json',86,12),('decimal-probe-results.json',10,3),('all-coreutils-checks.json',212,0)]:
    d=json.loads((out/name).read_text());assert d.get('core_commit',d.get('source_commit'))==source and len(d['commands'])==count and all(r['pass_']for r in d['commands'])
    if 'binaries'in d:
        assert d['binaries'][cert['compiler']]['sha256']==cert['compiler_sha256']
        assert d['binaries'][str(out/'oracle-current')]['sha256']==sha(out/'oracle-current')
    else:assert d['compiler_sha256']==cert['compiler_sha256']and d['oracle_sha256']==sha(out/'oracle-current')
    cs=[tuple(map(int,m.groups()))for r in d['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))]
    assert len(cs)==census and all(a==f and n==0 for a,f,n in cs)
    matrices.append(dict(file=name,commands=count,balanced_censuses=census))
darwin=json.loads((out/'buffered-writer-darwin-builds.json').read_text())
assert darwin['source_commit']==source and len(darwin['commands'])==2 and all(r['exit']==0 and not r['executed']for r in darwin['commands'])
for r in darwin['commands']:assert sha(Path(r['args'][4]))==r['binary_sha256']
boot=json.loads((prior/'bootstrap/bootstrap.json').read_text())
assert boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f'
assert boot['fixedpoint']and sha(prior/'bootstrap/stage2')==sha(prior/'bootstrap/stage3')==cert['compiler_sha256']
assert len((prior/'final-driver-sizes.txt').read_text().splitlines())==11
assert 'Every driver measured here is within 5%'in(prior/'final-driver-gate.log').read_text()
for name in ['vet.log','gofmt.log','format-check.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert 'Result: 0 errors, 0 warnings.'in(out/name).read_text()
zone=json.loads((out/'timezone-oracle-setup.json').read_text())
assert zone['system_alias_missing']and zone['reference_argv0_preserved']=='pr'and zone['relative_zoneinfo_parent_preserved']
assert sha(Path(zone['directory'])/'PST8PDT')==zone['target_sha256']
assert Path(zone['oracle_directory'],'pr').read_text()==zone['pr_wrapper']
patch=git('diff','--binary',base,source)
subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
    p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
files=['native-source-certificate.json','frontend-source-certificate.json','oracle-current-version.txt','go-regressions-final.jsonl','gnu-9.12-reference-complete.jsonl','buffer-writer-regressions.jsonl','affected-example-checks.jsonl','fern-runner-regressions.jsonl','pr-final-timezone-regressions.jsonl','cross-target-callers.jsonl','timezone-oracle-setup.json','all-coreutils-checks.json','all-coreutils-final-checks.log','check-all-coreutils.py','decimal-probe.fern','check-decimal-probe.py','decimal-probe-results.json','decimal-probe.log','buffered-writer.fern','buffered-writer-darwin-builds.json','vet.log','gofmt.log','format-check.log','readme-ste.log','pr-body-ste.log','pr-body.md','record-proofs.py']
for stem in ['committed-matrix-final','package-project-matrix-final','reexport-matrix-final']:files += [stem+'.py',stem+'-results.json',stem+'.log']
for n in files:save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
binaries={str(p):dict(bytes=p.stat().st_size,sha256=sha(p))for p in [out/'oracle-current',prior/'bootstrap/stage3',*[out/('decimal-probe-'+t)for t in ['x86-64-linux','arm64-linux','wasm32-wasi']],*[out/('buffered-writer-'+f+'-arm64-darwin')for f in ['Go','self']]]}
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,go_source=go_source,prior_public_head=base,tests=tests,matrices=matrices,darwin_builds=2,darwin_local_execution=False,native_certificate=cert,frontend_certificate=frontend,binaries=binaries,artifacts=artifacts),indent=2)+'\n')
print(json.dumps(dict(artifacts=len(artifacts),go_cases=2461,gnu_cases=5786,cli_checks=212,matrix_commands=205,balanced_censuses=33)))
