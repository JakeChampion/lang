from pathlib import Path
import os,subprocess,json,hashlib,collections
root=Path('/workspace/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-manifest-package/visibility-final-integration');cli=out/'shipped-fern-final';stage=out/'bootstrap/stage3';fixture=root/'conformance/cases/package_scoped_stdlib_helpers/main.fern';env=dict(os.environ,FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_STRICT_IR='1');rows=[]
def run(args,expected=0,stdout=None):
 p=subprocess.run(list(map(str,args)),cwd=root,env=env,capture_output=True,text=True,timeout=180);row=dict(args=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(row);assert p.returncode==expected and (stdout is None or p.stdout==stdout),row;return p
run([cli,'-check',fixture]);run([cli,'-interp',fixture],stdout='package helpers ok\n')
for name,source in [('string','import "std/string"; function main(): i32 { return string.__utf8_step("a", 0, 1); }'),('float','import "std/f64"; function main(): i32 { let n = f64.pow10_hi(0); return 0; }'),('buffer','import "std/io_buffered"; function main(): i32 { let n = io_buffered.digit_pairs(); return 0; }')]:
 src=out/('shipped-hidden-'+name+'.fern');src.write_text(source);p=run([cli,'-check',src],1);assert 'E087'in p.stderr and 'pub(package)'in p.stderr
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary=str(cli),bytes=cli.stat().st_size,sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),commands=rows)
(out/'shipped-final-results.json').write_text(json.dumps(report,indent=2)+'\n')
trace=out/'public-helpers-rctrace-final';args=[str(stage),'-target','x86-64-linux','-o',str(trace),str(fixture),str(root/'internal/stdlib')]
p=subprocess.run(args,cwd=root,env=dict(env,FERN_RC_TRACE='1'),capture_output=True,text=True,timeout=180);(out/'trace-final-build.log').write_text(p.stdout+p.stderr);assert p.returncode==0
p=subprocess.run([str(trace)],cwd=root,env=env,capture_output=True,text=True,timeout=60);(out/'trace-final.log').write_text(p.stderr);assert p.returncode==0 and p.stdout=='package helpers ok\n';live={};events=0
for line in p.stderr.splitlines():
 if not line.startswith('rctrace '):continue
 _,kind,address,size,*_=line.split();events+=1
 if kind=='a':assert address not in live;live[address]=size
 elif kind=='f':assert live.pop(address)==size
 else:raise AssertionError(line)
assert events>0 and not live
(out/'trace-final-results.json').write_text(json.dumps(dict(source_commit=report['source_commit'],arguments=args,compiler_sha256=hashlib.sha256(stage.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),exit=p.returncode,stdout=p.stdout,events=events,unpaired=len(live)),indent=2)+'\n');print('PASS 5 shipped CLI commands;',events,'balanced trace events')
