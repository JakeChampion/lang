from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io,re
root=Path('/workspace/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-manifest-package/visibility-final-integration');prior=Path('/workspace/scratch/lang-manifest-package/void-lambda-integration');source='489278fceebe29602589bddd221b4c8ae260ed2c';base='1a85a71b03e5d800e155d4b43ac4fd54084678cf';dest=root/'docs/benchmarks/manifest-package-2026-10-23/visibility-final-integration'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());native=sha(out/'bootstrap/stage3');assert boot['source_git']==source and boot['fixedpoint']and native==sha(out/'bootstrap/stage2')==boot['stages'][-1]['sha256']=='b72975f4d099ebec5b5354e0e48c0dabfe34c06e066d402085b63d437fd39a96'
files=[];h=hashlib.sha256()
for name in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/name).read_bytes();h.update(name.encode()+b'\0'+data+b'\0');files.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256']
cert=json.loads((out/'go-source-certificate.json').read_text());assert cert['current_source']==source and not git('diff','--name-only',cert['recorded_source'],source,'--',*cert['paths']);assert sha(Path(cert['original_log']))==cert['original_sha256']
tests=[]
for path,count,packages,scope in [(prior/'go-regressions.jsonl',2443,4,cert['recorded_source']),(out/'native-focused.jsonl',50,1,source),(out/'private-float-table-correct-package.jsonl',1,1,source)]:
 es=[json.loads(l)for l in path.read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es if e.get('Test'));term=[e for e in es if not e.get('Test')and e['Action']in['pass','fail','skip']];assert c['run']==c['pass']==count and not c['fail']and not c['skip']and len(term)==packages and all(e['Action']=='pass'for e in term),(str(path),c,term);tests.append(dict(file=str(path),runs=count,packages=packages,skips=0,source_commit=scope))
matrices=[]
for name,count,census in [('committed-matrix-final-results.json',90,15),('package-project-matrix-final-results.json',19,3),('reexport-matrix-final-results.json',86,12)]:
 m=json.loads((out/name).read_text());assert m.get('core_commit',m.get('source_commit'))==source and len(m['commands'])==count and all(r['pass_']for r in m['commands']);cs=[]
 for row in m['commands']:
  match=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',row['stderr'])
  if match:cs.append(tuple(map(int,match.groups())))
 assert len(cs)==census and all(a==f and n==0 for a,f,n in cs);matrices.append(dict(file=name,commands=count,balanced_censuses=census))
ship=json.loads((out/'shipped-final-results.json').read_text());trace=json.loads((out/'trace-final-results.json').read_text());assert ship['source_commit']==source and len(ship['commands'])==5 and trace['source_commit']==source and trace['compiler_sha256']==native and trace['events']==434 and trace['unpaired']==0
identity=json.loads((out/'library-visibility-identity.json').read_text());assert identity['source_commit']==source and identity['public_base']==base and len(identity['files'])==7 and sum(r['package_declarations']for r in identity['files'])==75
for row in identity['files']:
 before=git('show',base+':'+row['path']);after=(root/row['path']).read_bytes().replace(b'pub(package) ',b'pub ');assert before==after and row['only_visibility_and_matching_chunk_labels_changed']
assert json.loads((out/'format-final.json').read_text())==dict(files=1219,exit=0)
for name in ['format-final.log','gofmt-final.log','vet-final.log']:assert not(out/name).read_bytes()
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+source in version and'vcs.modified=false'in version
assert 'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text()and len((out/'final-driver-sizes.txt').read_text().splitlines())==11
assert 'tree compiler worst call_func_targs 220 excess 16320'in(out/'complexity-metrics.txt').read_text()
assert 'Result: 0 errors, 0 warnings.'in(out/'readme-ste.log').read_text()
patch=git('diff','--binary',base,source,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source-files.json.gz',gzip.compress(json.dumps(files,indent=2).encode()+b'\n',mtime=0));save('change.patch.gz',gzip.compress(patch,mtime=0));save('scoped-go-regressions.jsonl.gz',gzip.compress((prior/'go-regressions.jsonl').read_bytes(),mtime=0))
for name in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','go-source-certificate.json','native-focused.jsonl','private-float-table-correct-package.jsonl','committed-matrix-final.py','committed-matrix-final-results.json','committed-matrix-final.log','package-project-matrix-final.py','package-project-matrix-final-results.json','package-project-matrix-final.log','reexport-matrix-final.py','reexport-matrix-final-results.json','reexport-matrix-final.log','shipped-and-trace-final.py','shipped-final-results.json','trace-final-results.json','trace-final.log','trace-final-build.log','shipped-final-build.log','final-driver-sizes.txt','final-driver-builds.json','final-driver-gate.log','check-sizes.py','sizes.log','format-final.json','format-final.log','gofmt-final.log','vet-final.log','oracle-version.txt','library-visibility-identity.json','complexity-metrics.txt','readme-ste.log','record-final-proofs.py']:
 save(name.replace('/','--')+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as tar:
 for directory in ['committed-matrix-final','package-project-final','reexport-matrix-final']:
  for p in sorted((out/directory).rglob('*')):
   if not p.is_file()or p.suffix not in['.fern','.toml']:continue
   data=p.read_bytes();name=str(p.relative_to(out));info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(data);tar.addfile(info,io.BytesIO(data));inputs.append(name)
save('matrix-inputs.tar.gz',stream.getvalue())
binaries={str(p):dict(bytes=p.stat().st_size,sha256=sha(p))for p in[out/'oracle',out/'shipped-fern-final',out/'public-helpers-rctrace-final',out/'bootstrap/stage2',out/'bootstrap/stage3']}
(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=source,base=base,native_sha256=native,source_sha256=h.hexdigest(),tests=tests,matrices=matrices,shipped_commands=5,trace_events=434,package_declarations=75,inputs=inputs,binaries=binaries,artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(tests=tests,matrices=matrices,artifacts=len(artifacts))))
