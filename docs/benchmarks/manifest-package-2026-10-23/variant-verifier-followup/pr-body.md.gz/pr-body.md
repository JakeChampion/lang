Package visibility now follows manifest roots in both frontends. A nested manifest starts a new package even when its name matches the outer package. Modules without a manifest use their directory. The configured standard library is one package.

Enum constructors and patterns follow the visibility of their enum. Public constructors take precedence over hidden variants with the same name. The module drivers apply the same visibility rules as the main compiler. Invalid public re-exports report E087 before name resolution.

75 library helpers across seven modules use package visibility. Coreutils owns its decimal helpers, buffers, and generated extended-precision cache. Generated JSON code retains access to its library helpers. The comparator fixture copies its parser cache dependency.

Validation:

- All 1,264 verifier and visibility checks pass. The complete verifier corpus includes 1,078 programs. Seven new boundary checks pass.
- Three matrices pass 195 commands across both frontends and three target runtimes. All 30 runtime allocation counts balance.
- All 20 module runtime checks pass, with ARM execution and WASI module builds. Both frontends check all 106 coreutils programs.
- The compiler with its embedded library passes nine commands. All three runtime allocation counts balance. The x86 program records 434 balanced allocation trace events.
- A fresh three-stage bootstrap produces identical stages 2 and 3 at 14,466,048 bytes. All 11 strict driver size gates pass.
- All 1,218 source format checks pass. Go format, Go vet, and the complexity gate pass.

The latest proof is `docs/benchmarks/manifest-package-2026-10-23/variant-verifier-followup`. Earlier caller and comparator capsules retain their source scopes. Their results include 2,461 Go checks and all 5,786 affected GNU 9.12 parity checks without skips. The certificate verifies unchanged Go frontend, generator, library, and coreutils source bytes for this follow up.

Darwin builds are recorded in the earlier capsules. Darwin execution requires CI on Apple Silicon. Full CI must pass before merge.

Closes #12721.
Closes #13077.
Closes #13096.
