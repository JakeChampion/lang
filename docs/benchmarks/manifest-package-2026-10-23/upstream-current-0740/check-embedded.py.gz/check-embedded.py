from pathlib import Path
import subprocess,json,shutil,re,hashlib,os,sys
kind=sys.argv[1];text=kind=='text';root=Path('/tmp/lang-text-api-cohesion-publish'if text else'/tmp/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-text-api-cohesion/reverse-final-integration'if text else'/workspace/scratch/lang-manifest-package/upstream-current-0740');exe=Path('/tmp/lang-text-c2-embedded-fern'if text else'/tmp/lang-package-current-0740-embedded-fern');work=Path('/tmp/lang-text-c2-embedded-tests'if text else'/tmp/lang-package-current-0740-embedded-tests');work.mkdir(exist_ok=True);rows=[];env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')}
def run(name,args,stdout='',exit=0,error=None,flags=None):
 p=subprocess.run(list(map(str,args)),cwd='/tmp',env=dict(env,**(flags or{})),capture_output=True,text=True,timeout=180);good=p.returncode==exit and (stdout is None or p.stdout==stdout)and(error is None or error in p.stderr);row=dict(name=name,args=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=good);rows.append(row);assert good,row;return p
names=['text_api_owners','unicode_linear_transforms','primitive_protocols_and_unsigned_num','package_scoped_stdlib_helpers']if text else['package_scoped_stdlib_helpers']
for name in names:
 case=root/'conformance/cases'/name;dest=work/name;dest.mkdir(exist_ok=True)
 for p in case.glob('*.fern'):shutil.copy2(p,dest/p.name)
 source=dest/'main.fern';expected=(case/'expected.stdout').read_text()if(case/'expected.stdout').exists()else''
 for mode in ['-check','-interp']:run(name+mode,[exe,mode,source],stdout=expected if mode=='-interp'else'')
 for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
  b=dest/target;a=[exe,'-target',target,'-o',b]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[source];run(name+'-build-'+target,a,flags=dict(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_RC_TRACE='1'));p=run(name+'-run-'+target,runner+[b],stdout=expected);m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);assert m and m[1]==m[2]and m[3]=='0';live={};events=0
  for l in p.stderr.splitlines():
   if not l.startswith('rctrace '):continue
   _,op,addr,size,*_=l.split();events+=1
   if op=='a':assert addr not in live;live[addr]=size
   elif op=='f':assert live.pop(addr)==size
   else:raise AssertionError(l)
  assert not live and (events>0 or target!='x86-64-linux');rows[-1].update(trace_events=events,unpaired=0,trace_supported=target=='x86-64-linux')
run('version',[exe,'-version'],stdout=None)
(out/'embedded-results.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary=str(exe),binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),binary_bytes=exe.stat().st_size,cwd='/tmp',commands=rows),indent=2)+'\n');print('PASS',len(rows),'embedded commands')
