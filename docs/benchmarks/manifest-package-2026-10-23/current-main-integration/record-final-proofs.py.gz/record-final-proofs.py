from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io
root=Path('/workspace/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-manifest-package/current-main-integration');core='c3bfb4eb98787ace2a720ca97f273e38d7a91cd8';base='b15d4e7e10ddaec58bba62c4d3d8d8c41c06e632';dest=root/'docs/benchmarks/manifest-package-2026-10-23/current-main-integration'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core and not git('status','--porcelain')
boot=json.loads((out/'bootstrap-lsp-followup/bootstrap.json').read_text());assert boot['source_git']==core and boot['fixedpoint'];native=boot['stages'][-1]['sha256'];assert native==boot['stages'][1]['sha256']=='76e5bda0e8ad3330d4f52beb3a0f348612bb198775bc34e348c71ac7eb0492bf'
source_files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');source_files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256']
tests=[]
for n,count,pkgs in [('go-lsp-followup.jsonl',2440,4),('native-lsp-followup.jsonl',50,1),('private-float-table-final.jsonl',1,1)]:
 es=[json.loads(s)for s in(out/n).read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);ps=[e for e in es if'Test'not in e and e['Action']in['pass','fail']];assert c['run']==count and not c['fail']and not c['skip']and len(ps)==pkgs and all(e['Action']=='pass'for e in ps);tests.append(dict(file=n,runs=count,packages=pkgs,skips=0))
matrices=[]
for n,count,census in [('committed-matrix-final-results.json',90,15),('package-project-matrix-final-results.json',19,3),('reexport-matrix-final-results.json',86,12)]:
 m=json.loads((out/n).read_text());rows=m['commands'];assert m.get('core_commit',m.get('source_commit'))==core and len(rows)==count and all(r['pass_']for r in rows);cs=[]
 for r in rows:
  import re
  match=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.get('stderr',''))
  if match:cs.append(tuple(map(int,match.groups())))
 assert len(cs)==census and all(a==f and l==0 for a,f,l in cs);matrices.append(dict(file=n,commands=count,balanced_censuses=census))
ship=json.loads((out/'shipped-final-results.json').read_text());assert ship['source_commit']==core and len(ship['commands'])==5;trace=json.loads((out/'trace-final-results.json').read_text());assert trace['source_commit']==core and trace['compiler_sha256']==native and trace['events']==434 and not trace['unpaired']
assert 'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text();assert len((out/'final-driver-sizes.txt').read_text().splitlines())==11
version=(out/'oracle-lsp-followup-version.txt').read_text();assert 'vcs.revision='+core in version and 'vcs.modified=false'in version
for n in ['format-final.log','gofmt-final.log','vet-final.log']:assert not(out/n).read_bytes()
fmt=json.loads((out/'format-final.json').read_text());assert fmt['exit']==0 and fmt['count']==1204
identity=json.loads((out/'literate-library-identity.json').read_text());assert len(identity['files'])==7 and all(r['executable_tokens_unchanged']for r in identity['files'])
helpers={}
for rel in ['core/int','core/map','std/string','std/f64','std/io_buffered','std/json','std/pvec']:
 p=root/'internal/stdlib'/(rel+'.fern.md');helpers[rel]=sum(line.startswith('pub(package) ')for line in p.read_text().splitlines())
assert sum(helpers.values())==75,helpers
(dest).mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n.replace('/','-')+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(source_files,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap-lsp-followup/bootstrap.json','bootstrap-lsp-followup/stage1.log','bootstrap-lsp-followup/stage2.log','bootstrap-lsp-followup/stage3.log','go-lsp-followup.jsonl','native-lsp-followup.jsonl','private-float-table-final.jsonl','committed-matrix-final.py','committed-matrix-final-results.json','committed-matrix-final.log','package-project-matrix-final.py','package-project-matrix-final-results.json','package-project-matrix-final.log','reexport-matrix-final.py','reexport-matrix-final-results.json','reexport-matrix-final.log','shipped-and-trace-final.py','shipped-final-results.json','trace-final-results.json','trace-final.log','shipped-final-build.log','final-driver-sizes.txt','final-driver-builds.json','final-driver-gate.log','check-sizes-final.py','sizes-final.log','format-final.json','format-final.log','gofmt-final.log','vet-final.log','oracle-lsp-followup-version.txt','literate-library-identity.json','record-final-proofs.py']:take(n)
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['committed-matrix-final','package-project-final','reexport-matrix-final']:
  for p in sorted((out/folder).rglob('*')):
   if not p.is_file()or p.suffix not in['.fern','.toml']:continue
   data=p.read_bytes();name=str(p.relative_to(out));ti=tarfile.TarInfo(name);ti.mode=0o644;ti.mtime=0;ti.size=len(data);t.addfile(ti,io.BytesIO(data));inputs.append(name)
save('matrix-inputs.tar.gz',stream.getvalue());binaries={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in [out/'oracle-lsp-followup',out/'shipped-fern-final',out/'public-helpers-rctrace-final',*[out/'bootstrap-lsp-followup'/n for n in ['stage1','stage2','stage3']]]}
(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=core,dependency_base=base,source_sha256=h.hexdigest(),native_sha256=native,tests=tests,matrices=matrices,shipped_commands=5,trace_events=434,package_declarations=helpers,binaries=binaries,inputs=len(inputs),patch_excludes=['docs/benchmarks'],artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(artifacts=len(artifacts),tests=tests,helpers=helpers,matrices=matrices,inputs=len(inputs))))
