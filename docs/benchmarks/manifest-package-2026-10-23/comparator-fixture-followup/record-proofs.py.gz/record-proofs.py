from pathlib import Path
import collections,gzip,hashlib,json,subprocess
root=Path('/tmp/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-manifest-package/comparator-fixture-followup');source='fb89d886c0dbfba47a9c3778b9b2f74445e5313b';base='8697f40a1ac4d10f09fe560148b58f8cb22f2d69';dest=root/'docs/benchmarks/manifest-package-2026-10-23/comparator-fixture-followup'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
assert git('diff','--name-only',base,source).decode().splitlines()==['internal/testing/e2eharness/sort_comparator_bytes.go']
rows=[json.loads(l)for l in(out/'fixture-regressions.jsonl').read_text().splitlines()if l.startswith('{')];c=collections.Counter(r['Action']for r in rows if r.get('Test'));terminal=[r for r in rows if not r.get('Test')and r['Action']in ['pass','fail','skip']];assert c['run']==7 and c['pass']==6 and c['skip']==1 and not c['fail']and len(terminal)==1 and terminal[0]['Action']=='pass';assert[r['Test']for r in rows if r['Action']=='skip']==['TestSortComparatorBytes/arm64-darwin']
darwin=json.loads((out/'darwin-builds.json').read_text());assert darwin['source_commit']==source and 'cached_powers'in darwin['copied_modules']and len(darwin['commands'])==2
for r in darwin['commands']:assert r['exit']==0 and not r['executed']and sha(Path(r['args'][4]))==r['sha256']
assert not(out/'vet.log').read_bytes()
for n in ['readme-ste.log','pr-body-ste.log']:assert 'Result: 0 errors, 0 warnings.'in(out/n).read_text()
patch=git('diff','--binary',base,source);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
for n in ['fixture-regressions.jsonl','darwin-builds.json','vet.log','readme-ste.log','pr-body-ste.log','pr-body.md','record-proofs.py']:save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,prior_public_head=base,tests=7,passed=6,skipped=1,skip_reason='Darwin execution requires Apple Silicon',darwin_builds=2,darwin_local_execution=False,artifacts=artifacts),indent=2)+'\n');print('PASS comparator fixture, all execution variants and Darwin builds')
