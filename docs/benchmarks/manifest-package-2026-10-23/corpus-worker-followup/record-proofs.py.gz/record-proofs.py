from pathlib import Path
import json,hashlib,gzip,collections,subprocess,re
root=Path('/workspace/lang-manifest-package-publish');out=Path('/workspace/scratch/lang-manifest-package/corpus-worker-integration');prior=Path('/workspace/scratch/lang-manifest-package/visibility-final-integration');source='edcff9889c447be3ffad71709246c5056d5f4134';dest=root/'docs/benchmarks/manifest-package-2026-10-23/corpus-worker-followup'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
cert=json.loads((out/'native-source-certificate.json').read_text());cert['paths']=['*.fern','*.fern.md','bootstrap/stage0.lock','.github/selfhost-driver-sizes.txt'];assert not git('diff','--name-only',cert['recorded_source'],source,'--',*cert['paths']);assert sha(Path(cert['compiler']))==cert['compiler_sha256'];(out/'native-source-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
es=[json.loads(l)for l in(out/'go-regressions.jsonl').read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es if e.get('Test'));ps=[e for e in es if not e.get('Test')and e['Action']in['pass','fail','skip']];assert c['run']==c['pass']==2453 and not c['fail']and not c['skip']and len(ps)==4 and all(e['Action']=='pass'for e in ps)
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+source in version and'vcs.modified=false'in version
matrices=[]
for name,count,census in [('committed-matrix-final-results.json',90,15),('package-project-matrix-final-results.json',19,3),('reexport-matrix-final-results.json',86,12)]:
 d=json.loads((out/name).read_text());assert d.get('core_commit',d.get('source_commit'))==source and len(d['commands'])==count and all(r['pass_']for r in d['commands'])
 if 'binaries'in d:assert d['binaries'][cert['compiler']]['sha256']==cert['compiler_sha256']and d['binaries'][str(out/'oracle')]['sha256']==sha(out/'oracle')
 else:assert d['compiler_sha256']==cert['compiler_sha256']and d['oracle_sha256']==sha(out/'oracle')
 cs=[tuple(map(int,m.groups()))for r in d['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==census and all(a==f and n==0 for a,f,n in cs);matrices.append(dict(file=name,commands=count,balanced_censuses=census))
assert 'Every driver measured here is within 5%'in(prior/'final-driver-gate.log').read_text();assert 'Result: 0 errors, 0 warnings.'in(out/'readme-ste.log').read_text()
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes())
for name in ['native-source-certificate.json','go-regressions.jsonl','oracle-version.txt','committed-matrix-final.py','committed-matrix-final-results.json','committed-matrix-final.log','package-project-matrix-final.py','package-project-matrix-final-results.json','package-project-matrix-final.log','reexport-matrix-final.py','reexport-matrix-final-results.json','reexport-matrix-final.log','readme-ste.log','record-proofs.py']:save(name+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=source,native_certificate=cert,go_cases=2453,packages=4,skips=0,matrices=matrices,prior_native_proof='visibility-final-integration',artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(go_cases=2453,matrices=matrices,artifacts=len(artifacts))))
