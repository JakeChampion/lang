# Time and allocation measurements

This module measures execution time and memory allocations.

## Model

A benchmark records a warmup phase and a set of measured iterations. Reports combine elapsed times with allocation and fresh-byte counts.

## Contracts

Percentile methods inspect the recorded samples. Allocation counters measure runtime activity rather than process RSS. A benchmark body must perform the work that its report names.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub struct Delta>>

<<4 pub function alloc_count(): i64>>

<<5 pub struct Report>>

<<6 pub function run(name: string, warmup: i32, iterations: i32, body: ()>>

<<7 pub function csv_header(): string>>

<<8 pub struct Summary>>

<<9 function median_of(xs: i64[]): i64>>

<<10 pub function summarize(name: string, reports: Report[]): Summary>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module measures execution time and memory allocations.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/i32";
import "std/i64";
import "core/cmp";
import "std/json";
import "std/string";
```

### `3 pub struct Delta`

```fern
<<3 pub struct Delta>>=
pub struct Delta {
  allocs: i64,
  fresh_bytes: i64,
}
```

### `4 pub function alloc_count(): i64`

```fern
<<4 pub function alloc_count(): i64>>=
pub function alloc_count(): i64 {
  return __heap_alloc_count();
}

pub function bump_bytes(): i64 {
  return __heap_bump_bytes();
}

pub function allocs_after(a: i64): i64 {
  return __heap_alloc_count() - a;
}

pub function fresh_bytes_after(b: i64): i64 {
  return __heap_bump_bytes() - b;
}

pub function no_allocs_after(a: i64): boolean {
  return allocs_after(a) == 0 as i64;
}

pub function since(a: i64, b: i64): Delta {
  return Delta { allocs: allocs_after(a), fresh_bytes: fresh_bytes_after(b) };
}

pub function (d: Delta) describe(): string {
  return "allocs=" + d.allocs.to_string() + " fresh_bytes=" + d.fresh_bytes.to_string();
}
```

### `5 pub struct Report`

```fern
<<5 pub struct Report>>=
pub struct Report {
  name: string,
  iterations: i32,
  wall_ns: i64,
  samples_ns: i64[],
  allocs: i64,
  fresh_bytes: i64,
}
```

### `6 pub function run(name: string, warmup: i32, iterations: i32, body: ()`

```fern
<<6 pub function run(name: string, warmup: i32, iterations: i32, body: ()>>=
pub function run(name: string, warmup: i32, iterations: i32, body: () => void): Report {
  let w: i32 = 0;
  while (w < warmup) {
    body();
    w = w + 1;
  }
  let samples: i64[] = [];
  let p: i32 = 0;
  while (p < iterations) {
    samples = samples.append(0 as i64);
    p = p + 1;
  }
  let mark_allocs: i64 = alloc_count();
  let mark_bytes: i64 = bump_bytes();
  let started_ns: i64 = monotonic_ns();
  let i: i32 = 0;
  while (i < iterations) {
    let t0: i64 = monotonic_ns();
    body();
    samples = samples.with(i, monotonic_ns() - t0);
    i = i + 1;
  }
  let wall: i64 = monotonic_ns() - started_ns;
  let allocs: i64 = allocs_after(mark_allocs);
  let fresh: i64 = fresh_bytes_after(mark_bytes);
  return Report {
    name: name,
    iterations: iterations,
    wall_ns: wall,
    samples_ns: cmp.sort(samples),
    allocs: allocs,
    fresh_bytes: fresh,
  };
}

pub function (r: Report) percentile_ns(per_mille: i32): i64 {
  let n: i32 = r.samples_ns.len();
  if (n == 0) {
    return 0 as i64;
  }
  let rank: i32 = (per_mille * n + 999) / 1000;
  if (rank < 1) {
    rank = 1;
  }
  if (rank > n) {
    rank = n;
  }
  return r.samples_ns[rank - 1];
}

pub function (r: Report) min_ns(): i64 {
  return r.percentile_ns(0);
}

pub function (r: Report) p50_ns(): i64 {
  return r.percentile_ns(500);
}

pub function (r: Report) p95_ns(): i64 {
  return r.percentile_ns(950);
}

pub function (r: Report) p99_ns(): i64 {
  return r.percentile_ns(990);
}

pub function (r: Report) p999_ns(): i64 {
  return r.percentile_ns(999);
}

pub function (r: Report) max_ns(): i64 {
  return r.percentile_ns(1000);
}

pub function (r: Report) mean_ns(): i64 {
  let n: i32 = r.samples_ns.len();
  if (n == 0) {
    return 0 as i64;
  }
  let sum: i64 = 0 as i64;
  let i: i32 = 0;
  while (i < n) {
    sum = sum + r.samples_ns[i];
    i = i + 1;
  }
  return sum / (n as i64);
}

pub function (r: Report) ops_per_sec(): i64 {
  if (r.wall_ns <= 0 as i64) {
    return 0 as i64;
  }
  return r.iterations as i64 * 1000000000i64 / r.wall_ns;
}

pub function (r: Report) ns_per_op(): i64 {
  if (r.iterations <= 0) {
    return 0 as i64;
  }
  return r.wall_ns / (r.iterations as i64);
}

pub function (r: Report) allocs_per_op_milli(): i64 {
  if (r.iterations <= 0) {
    return 0 as i64;
  }
  return r.allocs * 1000i64 / (r.iterations as i64);
}

pub function (r: Report) bytes_per_op_milli(): i64 {
  if (r.iterations <= 0) {
    return 0 as i64;
  }
  return r.fresh_bytes * 1000i64 / (r.iterations as i64);
}

pub function (r: Report) to_json(): string {
  return "{\"name\":\"" + json.json_escape(r.name) + "\""
    + ",\"iterations\":" + r.iterations.to_string()
    + ",\"wall_ns\":" + r.wall_ns.to_string()
    + ",\"ops_per_sec\":" + r.ops_per_sec().to_string()
    + ",\"ns_per_op\":" + r.ns_per_op().to_string()
    + ",\"min_ns\":" + r.min_ns().to_string()
    + ",\"p50_ns\":" + r.p50_ns().to_string()
    + ",\"p95_ns\":" + r.p95_ns().to_string()
    + ",\"p99_ns\":" + r.p99_ns().to_string()
    + ",\"p999_ns\":" + r.p999_ns().to_string()
    + ",\"max_ns\":" + r.max_ns().to_string()
    + ",\"mean_ns\":" + r.mean_ns().to_string()
    + ",\"allocs\":" + r.allocs.to_string()
    + ",\"allocs_per_op_milli\":" + r.allocs_per_op_milli().to_string()
    + ",\"fresh_bytes\":" + r.fresh_bytes.to_string()
    + ",\"bytes_per_op_milli\":" + r.bytes_per_op_milli().to_string()
    + "}";
}
```

### `7 pub function csv_header(): string`

```fern
<<7 pub function csv_header(): string>>=
pub function csv_header(): string {
  return "name,iterations,wall_ns,ops_per_sec,ns_per_op,min_ns,p50_ns,p95_ns,"
    + "p99_ns,p999_ns,max_ns,mean_ns,allocs,allocs_per_op_milli,fresh_bytes,"
    + "bytes_per_op_milli";
}

pub function (r: Report) to_csv_row(): string {
  return "\"" + r.name.replace("\"", "\"\"") + "\""
    + "," + r.iterations.to_string()
    + "," + r.wall_ns.to_string()
    + "," + r.ops_per_sec().to_string()
    + "," + r.ns_per_op().to_string()
    + "," + r.min_ns().to_string()
    + "," + r.p50_ns().to_string()
    + "," + r.p95_ns().to_string()
    + "," + r.p99_ns().to_string()
    + "," + r.p999_ns().to_string()
    + "," + r.max_ns().to_string()
    + "," + r.mean_ns().to_string()
    + "," + r.allocs.to_string()
    + "," + r.allocs_per_op_milli().to_string()
    + "," + r.fresh_bytes.to_string()
    + "," + r.bytes_per_op_milli().to_string();
}

pub function (r: Report) describe(): string {
  return r.name + ": " + r.iterations.to_string() + " iters"
    + " " + r.ops_per_sec().to_string() + " ops/s"
    + " p50=" + r.p50_ns().to_string() + "ns"
    + " p99=" + r.p99_ns().to_string() + "ns"
    + " p99.9=" + r.p999_ns().to_string() + "ns"
    + " allocs=" + r.allocs.to_string()
    + " fresh_bytes=" + r.fresh_bytes.to_string();
}

pub function run_repeated(name: string, warmup: i32, iterations: i32, runs: i32, body: () => void): Report[] {
  let out: Report[] = [];
  let r: i32 = 0;
  while (r < runs) {
    out = out.append(run(name, warmup, iterations, body));
    r = r + 1;
  }
  return out;
}
```

### `8 pub struct Summary`

```fern
<<8 pub struct Summary>>=
pub struct Summary {
  name: string,
  runs: i32,
  best_ops_per_sec: i64,
  median_ops_per_sec: i64,
  worst_ops_per_sec: i64,
  best_p50_ns: i64,
  median_p50_ns: i64,
  worst_p99_ns: i64,
  min_allocs: i64,
  max_allocs: i64,
}
```

### `9 function median_of(xs: i64[]): i64`

```fern
<<9 function median_of(xs: i64[]): i64>>=
function median_of(xs: i64[]): i64 {
  if (xs.len() == 0) {
    return 0 as i64;
  }
  let sorted: i64[] = cmp.sort(xs);
  return sorted[sorted.len() / 2];
}
```

### `10 pub function summarize(name: string, reports: Report[]): Summary`

```fern
<<10 pub function summarize(name: string, reports: Report[]): Summary>>=
pub function summarize(name: string, reports: Report[]): Summary {
  let throughputs: i64[] = [];
  let p50s: i64[] = [];
  let worst_p99: i64 = 0 as i64;
  let min_allocs: i64 = 0 as i64;
  let max_allocs: i64 = 0 as i64;
  let i: i32 = 0;
  while (i < reports.len()) {
    let ops: i64 = reports[i].ops_per_sec();
    throughputs = throughputs.append(ops);
    p50s = p50s.append(reports[i].p50_ns());
    if (reports[i].p99_ns() > worst_p99) {
      worst_p99 = reports[i].p99_ns();
    }
    let a: i64 = reports[i].allocs;
    if (i == 0 || a < min_allocs) {
      min_allocs = a;
    }
    if (i == 0 || a > max_allocs) {
      max_allocs = a;
    }
    i = i + 1;
  }
  let sorted_ops: i64[] = cmp.sort(throughputs);
  let sorted_p50: i64[] = cmp.sort(p50s);
  let n: i32 = sorted_ops.len();
  let best_ops: i64 = 0 as i64;
  let worst_ops: i64 = 0 as i64;
  let best_p50: i64 = 0 as i64;
  if (n > 0) {
    best_ops = sorted_ops[n - 1];
    worst_ops = sorted_ops[0];
    best_p50 = sorted_p50[0];
  }
  return Summary {
    name: name,
    runs: reports.len(),
    best_ops_per_sec: best_ops,
    median_ops_per_sec: median_of(throughputs),
    worst_ops_per_sec: worst_ops,
    best_p50_ns: best_p50,
    median_p50_ns: median_of(p50s),
    worst_p99_ns: worst_p99,
    min_allocs: min_allocs,
    max_allocs: max_allocs,
  };
}

pub function (s: Summary) to_json(): string {
  return "{\"name\":\"" + json.json_escape(s.name) + "\""
    + ",\"runs\":" + s.runs.to_string()
    + ",\"best_ops_per_sec\":" + s.best_ops_per_sec.to_string()
    + ",\"median_ops_per_sec\":" + s.median_ops_per_sec.to_string()
    + ",\"worst_ops_per_sec\":" + s.worst_ops_per_sec.to_string()
    + ",\"best_p50_ns\":" + s.best_p50_ns.to_string()
    + ",\"median_p50_ns\":" + s.median_p50_ns.to_string()
    + ",\"worst_p99_ns\":" + s.worst_p99_ns.to_string()
    + ",\"min_allocs\":" + s.min_allocs.to_string()
    + ",\"max_allocs\":" + s.max_allocs.to_string()
    + "}";
}

pub function (s: Summary) allocation_is_stable(): boolean {
  return s.min_allocs == s.max_allocs;
}
```
