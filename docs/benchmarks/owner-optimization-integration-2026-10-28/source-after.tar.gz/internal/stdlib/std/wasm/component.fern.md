# WebAssembly component binaries

This module constructs WebAssembly components in binary format.

## Model

Component helpers encode section identifiers, types, instances, aliases, and canonical operations. The output is a binary component representation.

## Contracts

Indices belong to their component index spaces. Callers must supply consistent type references and section order. Byte construction does not substitute for component validation.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub function section_core_module(): u8>>

<<4 pub function put_core_instance_section_from_func_exports(buf: u8[], export_names: string[], core_func_idxs:...>>

<<5 pub function put_type_section_one_func(buf: u8[], param_names: string[], param_valtypes: u8[], result_valty...>>

<<6 pub function put_type_section_one_flags(buf: u8[], labels: string[]): u8[]>>

<<7 pub function put_type_section_one_instance_with_func_exports(buf: u8[], export_names: string[], param_names...>>

<<8 pub function put_alias_section_core_exports(buf: u8[], core_sorts: u8[], core_instance_idxs: u32[], names: ...>>

<<9 pub function put_canon_section_lift_mem_realloc_encoding(buf: u8[], core_func_idx: u32, typeidx: u32, mem_i...>>

<<10 pub function build_wasi_imported_component(core_bytes: u8[], interface_name: string, func_name: string, was...>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module constructs WebAssembly components in binary format.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/wasm/leb128";
import "std/wasm/encode";
```

### `3 pub function section_core_module(): u8`

```fern
<<3 pub function section_core_module(): u8>>=
pub function section_core_module(): u8 {
  return 1u8;
}

pub function section_core_instance(): u8 {
  return 2u8;
}

pub function section_core_type(): u8 {
  return 3u8;
}

pub function section_instance(): u8 {
  return 5u8;
}

pub function section_alias(): u8 {
  return 6u8;
}

pub function section_type(): u8 {
  return 7u8;
}

pub function section_canon(): u8 {
  return 8u8;
}

pub function section_start(): u8 {
  return 9u8;
}

pub function section_import(): u8 {
  return 10u8;
}

pub function section_export(): u8 {
  return 11u8;
}

pub function put_component_header(buf: u8[]): u8[] {
  let out: u8[] = buf;
  out = out.append(0u8);
  out = out.append(97u8);
  out = out.append(115u8);
  out = out.append(109u8);
  out = out.append(13u8);
  out = out.append(0u8);
  out = out.append(1u8);
  out = out.append(0u8);
  return out;
}

pub function put_core_module_section(buf: u8[], core_bytes: u8[]): u8[] {
  let out: u8[] = buf;
  out = out.append(section_core_module());
  out = leb128.uleb_u32(out, core_bytes.len() as u32);
  return encode.put_bytes(out, core_bytes);
}

pub function put_core_type_section_one_func(buf: u8[], param_valtypes: u8[], result_valtypes: u8[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(96u8);
  let np: i32 = param_valtypes.len();
  body = leb128.uleb_u32(body, np as u32);
  let i: i32 = 0;
  while (i < np) {
    body = body.append(param_valtypes[i]);
    i = i + 1;
  }
  let nr: i32 = result_valtypes.len();
  body = leb128.uleb_u32(body, nr as u32);
  i = 0;
  while (i < nr) {
    body = body.append(result_valtypes[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_core_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_component_type_section(buf: u8[], payload: u8[]): u8[] {
  let body: u8[] = encode.put_name([], "component-type");
  body = encode.put_bytes(body, payload);

  let out: u8[] = buf;
  out = out.append(0u8);
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_core_instance_section_instantiate(buf: u8[], module_idx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(0u8);
  body = leb128.uleb_u32(body, module_idx);
  body = leb128.uleb_u32(body, 0u32);

  let out: u8[] = buf;
  out = out.append(section_core_instance());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function core_sort_func(): u8 {
  return 0u8;
}

pub function core_sort_table(): u8 {
  return 1u8;
}

pub function core_sort_memory(): u8 {
  return 2u8;
}

pub function core_sort_global(): u8 {
  return 3u8;
}

pub function core_sort_type(): u8 {
  return 16u8;
}

pub function core_sort_module(): u8 {
  return 17u8;
}

pub function core_sort_instance(): u8 {
  return 18u8;
}
```

### `4 pub function put_core_instance_section_from_func_exports(buf: u8[], export_names: string[], core_func_idxs:...`

```fern
<<4 pub function put_core_instance_section_from_func_exports(buf: u8[], export_names: string[], core_func_idxs:...>>=
pub function put_core_instance_section_from_func_exports(buf: u8[], export_names: string[], core_func_idxs: u32[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(1u8);
  let n: i32 = export_names.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, export_names[i]);
    body = body.append(core_sort_func());
    body = leb128.uleb_u32(body, core_func_idxs[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_core_instance());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_core_instance_section_from_one_func_export(buf: u8[], export_name: string, core_func_idx: u32): u8[] {
  let names: string[] = [export_name];
  let idxs: u32[] = [core_func_idx];
  return put_core_instance_section_from_func_exports(buf, names, idxs);
}

pub function put_core_instance_section_instantiate_with_instance_args(buf: u8[], module_idx: u32, arg_names: string[], instance_idxs: u32[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(0u8);
  body = leb128.uleb_u32(body, module_idx);
  let n: i32 = arg_names.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, arg_names[i]);
    body = body.append(core_sort_instance());
    body = leb128.uleb_u32(body, instance_idxs[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_core_instance());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_core_instance_section_instantiate_with_one_instance_arg(buf: u8[], module_idx: u32, arg_name: string, instance_idx: u32): u8[] {
  let names: string[] = [arg_name];
  let idxs: u32[] = [instance_idx];
  return put_core_instance_section_instantiate_with_instance_args(buf, module_idx, names, idxs);
}

pub function cvaltype_bool(): u8 {
  return 127u8;
}

pub function cvaltype_s8(): u8 {
  return 126u8;
}

pub function cvaltype_u8(): u8 {
  return 125u8;
}

pub function cvaltype_s16(): u8 {
  return 124u8;
}

pub function cvaltype_u16(): u8 {
  return 123u8;
}

pub function cvaltype_s32(): u8 {
  return 122u8;
}

pub function cvaltype_u32(): u8 {
  return 121u8;
}

pub function cvaltype_s64(): u8 {
  return 120u8;
}

pub function cvaltype_u64(): u8 {
  return 119u8;
}

pub function cvaltype_f32(): u8 {
  return 118u8;
}

pub function cvaltype_f64(): u8 {
  return 117u8;
}

pub function cvaltype_char(): u8 {
  return 116u8;
}

pub function cvaltype_string(): u8 {
  return 115u8;
}

pub function put_type_section_funcs(buf: u8[], param_names_per_func: string[][], param_valtypes_per_func: u8[][], result_valtype_per_func: u8[]): u8[] {
  let body: u8[] = [];
  let n: i32 = result_valtype_per_func.len();
  body = leb128.uleb_u32(body, n as u32);
  let t: i32 = 0;
  while (t < n) {
    body = body.append(64u8);
    let p_names: string[] = param_names_per_func[t];
    let p_valtypes: u8[] = param_valtypes_per_func[t];
    let pn: i32 = p_names.len();
    body = leb128.uleb_u32(body, pn as u32);
    let i: i32 = 0;
    while (i < pn) {
      body = encode.put_name(body, p_names[i]);
      body = body.append(p_valtypes[i]);
      i = i + 1;
    }
    body = body.append(0u8);
    body = body.append(result_valtype_per_func[t]);
    t = t + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}
```

### `5 pub function put_type_section_one_func(buf: u8[], param_names: string[], param_valtypes: u8[], result_valty...`

```fern
<<5 pub function put_type_section_one_func(buf: u8[], param_names: string[], param_valtypes: u8[], result_valty...>>=
pub function put_type_section_one_func(buf: u8[], param_names: string[], param_valtypes: u8[], result_valtype: u8): u8[] {
  let names_per: string[][] = [param_names];
  let valtypes_per: u8[][] = [param_valtypes];
  let results_per: u8[] = [result_valtype];
  return put_type_section_funcs(buf, names_per, valtypes_per, results_per);
}

pub function put_type_section_one_func_no_param(buf: u8[], result_valtype: u8): u8[] {
  let no_names: string[] = [];
  let no_valtypes: u8[] = [];
  return put_type_section_one_func(buf, no_names, no_valtypes, result_valtype);
}

pub function put_type_section_one_func_no_result(buf: u8[], param_names: string[], param_valtypes: u8[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(64u8);
  let n: i32 = param_names.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, param_names[i]);
    body = body.append(param_valtypes[i]);
    i = i + 1;
  }
  body = body.append(1u8);
  body = leb128.uleb_u32(body, 0u32);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_resource(buf: u8[], rep_valtype: u8): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(63u8);
  body = body.append(rep_valtype);
  body = body.append(0u8);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_list(buf: u8[], elem_valtype: u8): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(112u8);
  body = body.append(elem_valtype);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_option(buf: u8[], inner_valtype: u8): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(107u8);
  body = body.append(inner_valtype);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_tuple(buf: u8[], elem_valtypes: u8[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(111u8);
  let n: i32 = elem_valtypes.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(elem_valtypes[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_result_ok_err(buf: u8[], ok_valtype: u8, err_valtype: u8): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(106u8);
  body = body.append(1u8);
  body = body.append(ok_valtype);
  body = body.append(1u8);
  body = body.append(err_valtype);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_enum(buf: u8[], labels: string[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(109u8);
  let n: i32 = labels.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, labels[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}
```

### `6 pub function put_type_section_one_flags(buf: u8[], labels: string[]): u8[]`

```fern
<<6 pub function put_type_section_one_flags(buf: u8[], labels: string[]): u8[]>>=
pub function put_type_section_one_flags(buf: u8[], labels: string[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(110u8);
  let n: i32 = labels.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, labels[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_record(buf: u8[], field_names: string[], field_valtypes: u8[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(114u8);
  let n: i32 = field_names.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, field_names[i]);
    body = body.append(field_valtypes[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_variant(buf: u8[], case_names: string[], case_has_payload: boolean[], case_payload_valtypes: u8[]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(113u8);
  let n: i32 = case_names.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, case_names[i]);
    if (case_has_payload[i]) {
      body = body.append(1u8);
      body = body.append(case_payload_valtypes[i]);
    } else {
      body = body.append(0u8);
    }
    body = body.append(0u8);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_own(buf: u8[], resource_typeidx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(105u8);
  body = leb128.uleb_u32(body, resource_typeidx);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_borrow(buf: u8[], resource_typeidx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(104u8);
  body = leb128.uleb_u32(body, resource_typeidx);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_type_section_one_instance_one_func_export(buf: u8[], export_name: string, param_names: string[], param_valtypes: u8[]): u8[] {
  let names_per: string[][] = [param_names];
  let valtypes_per: u8[][] = [param_valtypes];
  let export_names: string[] = [export_name];
  return put_type_section_one_instance_with_func_exports(buf, export_names, names_per, valtypes_per);
}

pub function put_type_section_one_instance_one_func_with_result_export(buf: u8[], export_name: string, param_names: string[], param_valtypes: u8[], result_valtype: u8): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(66u8);
  body = leb128.uleb_u32(body, 2u32);

  body = body.append(1u8);
  body = body.append(64u8);
  let np: i32 = param_names.len();
  body = leb128.uleb_u32(body, np as u32);
  let i: i32 = 0;
  while (i < np) {
    body = encode.put_name(body, param_names[i]);
    body = body.append(param_valtypes[i]);
    i = i + 1;
  }
  body = body.append(0u8);
  body = body.append(result_valtype);

  body = body.append(4u8);
  body = body.append(0u8);
  body = encode.put_name(body, export_name);
  body = body.append(1u8);
  body = leb128.uleb_u32(body, 0u32);

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}
```

### `7 pub function put_type_section_one_instance_with_func_exports(buf: u8[], export_names: string[], param_names...`

```fern
<<7 pub function put_type_section_one_instance_with_func_exports(buf: u8[], export_names: string[], param_names...>>=
pub function put_type_section_one_instance_with_func_exports(buf: u8[], export_names: string[], param_names_per_func: string[][], param_valtypes_per_func: u8[][]): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(66u8);
  let n: i32 = export_names.len();
  body = leb128.uleb_u32(body, (n * 2) as u32);

  let f: i32 = 0;
  while (f < n) {
    body = body.append(1u8);
    body = body.append(64u8);
    let p_names: string[] = param_names_per_func[f];
    let p_valtypes: u8[] = param_valtypes_per_func[f];
    let np: i32 = p_names.len();
    body = leb128.uleb_u32(body, np as u32);
    let i: i32 = 0;
    while (i < np) {
      body = encode.put_name(body, p_names[i]);
      body = body.append(p_valtypes[i]);
      i = i + 1;
    }
    body = body.append(1u8);
    body = leb128.uleb_u32(body, 0u32);

    body = body.append(4u8);
    body = body.append(0u8);
    body = encode.put_name(body, export_names[f]);
    body = body.append(1u8);
    body = leb128.uleb_u32(body, f as u32);

    f = f + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_type());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_import_section_one_instance(buf: u8[], name: string, instance_typeidx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(0u8);
  body = encode.put_name(body, name);
  body = body.append(5u8);
  body = leb128.uleb_u32(body, instance_typeidx);

  let out: u8[] = buf;
  out = out.append(section_import());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_resource_drop(buf: u8[], resource_typeidx: u32): u8[] {
  let idxs: u32[] = [resource_typeidx];
  return put_canon_section_resource_drops(buf, idxs);
}

pub function put_canon_section_resource_drops(buf: u8[], resource_typeidxs: u32[]): u8[] {
  let body: u8[] = [];
  let n: i32 = resource_typeidxs.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(3u8);
    body = leb128.uleb_u32(body, resource_typeidxs[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_resource_new(buf: u8[], resource_typeidx: u32): u8[] {
  let idxs: u32[] = [resource_typeidx];
  return put_canon_section_resource_news(buf, idxs);
}

pub function put_canon_section_resource_news(buf: u8[], resource_typeidxs: u32[]): u8[] {
  let body: u8[] = [];
  let n: i32 = resource_typeidxs.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(2u8);
    body = leb128.uleb_u32(body, resource_typeidxs[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_resource_rep(buf: u8[], resource_typeidx: u32): u8[] {
  let idxs: u32[] = [resource_typeidx];
  return put_canon_section_resource_reps(buf, idxs);
}

pub function put_canon_section_resource_reps(buf: u8[], resource_typeidxs: u32[]): u8[] {
  let body: u8[] = [];
  let n: i32 = resource_typeidxs.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(4u8);
    body = leb128.uleb_u32(body, resource_typeidxs[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_start_section_no_args_no_results(buf: u8[], funcidx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, funcidx);
  body = leb128.uleb_u32(body, 0u32);
  body = leb128.uleb_u32(body, 0u32);

  let out: u8[] = buf;
  out = out.append(section_start());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}
```

### `8 pub function put_alias_section_core_exports(buf: u8[], core_sorts: u8[], core_instance_idxs: u32[], names: ...`

```fern
<<8 pub function put_alias_section_core_exports(buf: u8[], core_sorts: u8[], core_instance_idxs: u32[], names: ...>>=
pub function put_alias_section_core_exports(buf: u8[], core_sorts: u8[], core_instance_idxs: u32[], names: string[]): u8[] {
  let body: u8[] = [];
  let n: i32 = core_sorts.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(0u8);
    body = body.append(core_sorts[i]);
    body = body.append(1u8);
    body = leb128.uleb_u32(body, core_instance_idxs[i]);
    body = encode.put_name(body, names[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_alias());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_alias_section_core_export_func(buf: u8[], core_instance_idx: u32, name: string): u8[] {
  let sorts: u8[] = [core_sort_func()];
  let instance_idxs: u32[] = [core_instance_idx];
  let names: string[] = [name];
  return put_alias_section_core_exports(buf, sorts, instance_idxs, names);
}

pub function put_alias_section_instance_export_func(buf: u8[], instance_idx: u32, name: string): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(1u8);
  body = body.append(0u8);
  body = leb128.uleb_u32(body, instance_idx);
  body = encode.put_name(body, name);

  let out: u8[] = buf;
  out = out.append(section_alias());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_lifts_no_opts(buf: u8[], core_func_idxs: u32[], typeidxs: u32[]): u8[] {
  let body: u8[] = [];
  let n: i32 = core_func_idxs.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(0u8);
    body = body.append(0u8);
    body = leb128.uleb_u32(body, core_func_idxs[i]);
    body = leb128.uleb_u32(body, 0u32);
    body = leb128.uleb_u32(body, typeidxs[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_lift_no_opts(buf: u8[], core_func_idx: u32, typeidx: u32): u8[] {
  let core_idxs: u32[] = [core_func_idx];
  let type_idxs: u32[] = [typeidx];
  return put_canon_section_lifts_no_opts(buf, core_idxs, type_idxs);
}

pub function canonopt_string_encoding_utf8(): u8 {
  return 0u8;
}

pub function canonopt_string_encoding_utf16(): u8 {
  return 1u8;
}

pub function canonopt_string_encoding_latin1_utf16(): u8 {
  return 2u8;
}

pub function canonopt_memory(): u8 {
  return 3u8;
}

pub function canonopt_realloc(): u8 {
  return 4u8;
}

pub function canonopt_post_return(): u8 {
  return 5u8;
}

pub function put_canon_section_lower_mem_realloc(buf: u8[], func_idx: u32, mem_idx: u32, realloc_func_idx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(1u8);
  body = body.append(0u8);
  body = leb128.uleb_u32(body, func_idx);
  body = leb128.uleb_u32(body, 2u32);
  body = body.append(canonopt_memory());
  body = leb128.uleb_u32(body, mem_idx);
  body = body.append(canonopt_realloc());
  body = leb128.uleb_u32(body, realloc_func_idx);

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_lift_mem_realloc_post_return(buf: u8[], core_func_idx: u32, typeidx: u32, mem_idx: u32, realloc_func_idx: u32, post_return_func_idx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(0u8);
  body = body.append(0u8);
  body = leb128.uleb_u32(body, core_func_idx);
  body = leb128.uleb_u32(body, 3u32);
  body = body.append(canonopt_memory());
  body = leb128.uleb_u32(body, mem_idx);
  body = body.append(canonopt_realloc());
  body = leb128.uleb_u32(body, realloc_func_idx);
  body = body.append(canonopt_post_return());
  body = leb128.uleb_u32(body, post_return_func_idx);
  body = leb128.uleb_u32(body, typeidx);

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}
```

### `9 pub function put_canon_section_lift_mem_realloc_encoding(buf: u8[], core_func_idx: u32, typeidx: u32, mem_i...`

```fern
<<9 pub function put_canon_section_lift_mem_realloc_encoding(buf: u8[], core_func_idx: u32, typeidx: u32, mem_i...>>=
pub function put_canon_section_lift_mem_realloc_encoding(buf: u8[], core_func_idx: u32, typeidx: u32, mem_idx: u32, realloc_func_idx: u32, encoding_tag: u8): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(0u8);
  body = body.append(0u8);
  body = leb128.uleb_u32(body, core_func_idx);
  body = leb128.uleb_u32(body, 3u32);
  body = body.append(encoding_tag);
  body = body.append(canonopt_memory());
  body = leb128.uleb_u32(body, mem_idx);
  body = body.append(canonopt_realloc());
  body = leb128.uleb_u32(body, realloc_func_idx);
  body = leb128.uleb_u32(body, typeidx);

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_lift_mem_realloc(buf: u8[], core_func_idx: u32, typeidx: u32, mem_idx: u32, realloc_func_idx: u32): u8[] {
  let body: u8[] = [];
  body = leb128.uleb_u32(body, 1u32);
  body = body.append(0u8);
  body = body.append(0u8);
  body = leb128.uleb_u32(body, core_func_idx);
  body = leb128.uleb_u32(body, 2u32);
  body = body.append(canonopt_memory());
  body = leb128.uleb_u32(body, mem_idx);
  body = body.append(canonopt_realloc());
  body = leb128.uleb_u32(body, realloc_func_idx);
  body = leb128.uleb_u32(body, typeidx);

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_import_section_funcs(buf: u8[], names: string[], typeidxs: u32[]): u8[] {
  let body: u8[] = [];
  let n: i32 = names.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(0u8);
    body = encode.put_name(body, names[i]);
    body = body.append(1u8);
    body = leb128.uleb_u32(body, typeidxs[i]);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_import());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_import_section_one_func(buf: u8[], name: string, typeidx: u32): u8[] {
  let names: string[] = [name];
  let typeidxs: u32[] = [typeidx];
  return put_import_section_funcs(buf, names, typeidxs);
}

pub function put_canon_section_lowers_no_opts(buf: u8[], func_idxs: u32[]): u8[] {
  let body: u8[] = [];
  let n: i32 = func_idxs.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(1u8);
    body = body.append(0u8);
    body = leb128.uleb_u32(body, func_idxs[i]);
    body = leb128.uleb_u32(body, 0u32);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_canon());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_canon_section_lower_no_opts(buf: u8[], func_idx: u32): u8[] {
  let func_idxs: u32[] = [func_idx];
  return put_canon_section_lowers_no_opts(buf, func_idxs);
}

pub function put_export_section_funcs(buf: u8[], names: string[], func_idxs: u32[]): u8[] {
  let body: u8[] = [];
  let n: i32 = names.len();
  body = leb128.uleb_u32(body, n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = body.append(0u8);
    body = encode.put_name(body, names[i]);
    body = body.append(1u8);
    body = leb128.uleb_u32(body, func_idxs[i]);
    body = body.append(0u8);
    i = i + 1;
  }

  let out: u8[] = buf;
  out = out.append(section_export());
  out = leb128.uleb_u32(out, body.len() as u32);
  return encode.put_bytes(out, body);
}

pub function put_export_section_one_func(buf: u8[], name: string, func_idx: u32): u8[] {
  let names: string[] = [name];
  let func_idxs: u32[] = [func_idx];
  return put_export_section_funcs(buf, names, func_idxs);
}

pub function build_lifted_export_component(core_bytes: u8[], core_export_name: string, export_name: string, result_valtype: u8): u8[] {
  let no_names: string[] = [];
  let no_valtypes: u8[] = [];
  return build_lifted_export_component_with_params(core_bytes, core_export_name, export_name, no_names, no_valtypes, result_valtype);
}

pub function build_lifted_export_component_with_params(core_bytes: u8[], core_export_name: string, export_name: string, param_names: string[], param_valtypes: u8[], result_valtype: u8): u8[] {
  let comp: u8[] = put_component_header([]);
  comp = put_core_module_section(comp, core_bytes);
  comp = put_core_instance_section_instantiate(comp, 0u32);
  comp = put_alias_section_core_export_func(comp, 0u32, core_export_name);
  comp = put_type_section_one_func(comp, param_names, param_valtypes, result_valtype);
  comp = put_canon_section_lift_no_opts(comp, 0u32, 0u32);
  comp = put_export_section_one_func(comp, export_name, 0u32);
  return comp;
}
```

### `10 pub function build_wasi_imported_component(core_bytes: u8[], interface_name: string, func_name: string, was...`

```fern
<<10 pub function build_wasi_imported_component(core_bytes: u8[], interface_name: string, func_name: string, was...>>=
pub function build_wasi_imported_component(core_bytes: u8[], interface_name: string, func_name: string, wasi_param_names: string[], wasi_param_valtypes: u8[], core_import_module: string): u8[] {
  let interface_names: string[] = [interface_name];
  let func_names: string[] = [func_name];
  let names_per: string[][] = [wasi_param_names];
  let valtypes_per: u8[][] = [wasi_param_valtypes];
  let core_modules: string[] = [core_import_module];
  return build_wasi_multi_imported_component(core_bytes, interface_names, func_names, names_per, valtypes_per, core_modules);
}

pub function build_wasi_multi_imported_component(core_bytes: u8[], interface_names: string[], func_names: string[], wasi_param_names_per: string[][], wasi_param_valtypes_per: u8[][], core_import_modules: string[]): u8[] {
  let comp: u8[] = put_component_header([]);
  let n: i32 = interface_names.len();

  let i: i32 = 0;
  while (i < n) {
    comp = put_type_section_one_instance_one_func_export(comp, func_names[i], wasi_param_names_per[i], wasi_param_valtypes_per[i]);
    comp = put_import_section_one_instance(comp, interface_names[i], i as u32);
    comp = put_alias_section_instance_export_func(comp, i as u32, func_names[i]);
    comp = put_canon_section_lower_no_opts(comp, i as u32);
    comp = put_core_instance_section_from_one_func_export(comp, func_names[i], i as u32);
    i = i + 1;
  }

  comp = put_core_module_section(comp, core_bytes);
  let instance_idxs: u32[] = [];
  let j: i32 = 0;
  while (j < n) {
    instance_idxs = instance_idxs.append(j as u32);
    j = j + 1;
  }
  comp = put_core_instance_section_instantiate_with_instance_args(comp, 0u32, core_import_modules, instance_idxs);
  return comp;
}
```
