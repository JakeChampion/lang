# WebAssembly section payloads

This module constructs WebAssembly binary sections.

## Model

Section builders encode vectors of types, functions, exports, code, and other module entries. Custom sections combine a name with arbitrary payload bytes.

## Contracts

Each section supplies its encoded payload length. Entry counts and parallel input arrays must agree, and referenced indices must exist in the assembled module.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub function export_func(): u8>>

<<4 pub function encode_data_section(buf: u8[], offsets: i32[], init_bytes: u8[][]): u8[]>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module constructs WebAssembly binary sections.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/wasm/leb128";
import "std/wasm/encode";
```

### `3 pub function export_func(): u8`

```fern
<<3 pub function export_func(): u8>>=
pub function export_func(): u8 {
  return 0u8;
}

pub function export_table(): u8 {
  return 1u8;
}

pub function export_memory(): u8 {
  return 2u8;
}

pub function export_global(): u8 {
  return 3u8;
}

pub function encode_custom_section(buf: u8[], name: string, payload: u8[]): u8[] {
  let body: u8[] = encode.put_name([], name);
  body = encode.put_bytes(body, payload);
  return encode.put_section(buf, encode.section_custom(), body);
}

pub function encode_type_section(buf: u8[], params_per_type: u8[][], results_per_type: u8[][]): u8[] {
  let n: i32 = params_per_type.len();
  let body: u8[] = leb128.uleb_u32([], n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_func_type(body, params_per_type[i], results_per_type[i]);
    i = i + 1;
  }
  return encode.put_section(buf, encode.section_type(), body);
}

pub function encode_function_section(buf: u8[], typeidxs: u32[]): u8[] {
  let n: i32 = typeidxs.len();
  let body: u8[] = leb128.uleb_u32([], n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = leb128.uleb_u32(body, typeidxs[i]);
    i = i + 1;
  }
  return encode.put_section(buf, encode.section_function(), body);
}

pub function encode_table_section(buf: u8[], reftype: u8, min: u32, max: i32): u8[] {
  let body: u8[] = leb128.uleb_u32([], 1u32);
  body = body.append(reftype);
  if (max < 0) {
    body = body.append(0u8);
    body = leb128.uleb_u32(body, min);
  } else {
    body = body.append(1u8);
    body = leb128.uleb_u32(body, min);
    body = leb128.uleb_u32(body, max as u32);
  }
  return encode.put_section(buf, encode.section_table(), body);
}

pub function encode_memory_section(buf: u8[], min_pages: u32, max_pages: i32): u8[] {
  let body: u8[] = leb128.uleb_u32([], 1u32);
  if (max_pages < 0) {
    body = body.append(0u8);
    body = leb128.uleb_u32(body, min_pages);
  } else {
    body = body.append(1u8);
    body = leb128.uleb_u32(body, min_pages);
    body = leb128.uleb_u32(body, max_pages as u32);
  }
  return encode.put_section(buf, encode.section_memory(), body);
}

pub function encode_export_section(buf: u8[], names: string[], kinds: u8[], indices: u32[]): u8[] {
  let n: i32 = names.len();
  let body: u8[] = leb128.uleb_u32([], n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_name(body, names[i]);
    body = body.append(kinds[i]);
    body = leb128.uleb_u32(body, indices[i]);
    i = i + 1;
  }
  return encode.put_section(buf, encode.section_export(), body);
}

pub function encode_start_section(buf: u8[], funcidx: u32): u8[] {
  let body: u8[] = leb128.uleb_u32([], funcidx);
  return encode.put_section(buf, encode.section_start(), body);
}

pub function encode_element_section(buf: u8[], offsets: i32[], funcidxs_per_seg: u32[][]): u8[] {
  let n: i32 = offsets.len();
  let body: u8[] = leb128.uleb_u32([], n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = leb128.uleb_u32(body, 0u32);
    body = body.append(65u8);
    body = leb128.sleb_i32(body, offsets[i]);
    body = body.append(11u8);
    let seg: u32[] = funcidxs_per_seg[i];
    body = leb128.uleb_u32(body, seg.len() as u32);
    let j: i32 = 0;
    while (j < seg.len()) {
      body = leb128.uleb_u32(body, seg[j]);
      j = j + 1;
    }
    i = i + 1;
  }
  return encode.put_section(buf, encode.section_element(), body);
}

pub function encode_code_section(buf: u8[], bodies: u8[][]): u8[] {
  let n: i32 = bodies.len();
  let body: u8[] = leb128.uleb_u32([], n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = encode.put_bytes(body, bodies[i]);
    i = i + 1;
  }
  return encode.put_section(buf, encode.section_code(), body);
}
```

### `4 pub function encode_data_section(buf: u8[], offsets: i32[], init_bytes: u8[][]): u8[]`

```fern
<<4 pub function encode_data_section(buf: u8[], offsets: i32[], init_bytes: u8[][]): u8[]>>=
pub function encode_data_section(buf: u8[], offsets: i32[], init_bytes: u8[][]): u8[] {
  let n: i32 = offsets.len();
  let body: u8[] = leb128.uleb_u32([], n as u32);
  let i: i32 = 0;
  while (i < n) {
    body = leb128.uleb_u32(body, 0u32);
    body = body.append(65u8);
    body = leb128.sleb_i32(body, offsets[i]);
    body = body.append(11u8);
    let seg: u8[] = init_bytes[i];
    body = leb128.uleb_u32(body, seg.len() as u32);
    body = encode.put_bytes(body, seg);
    i = i + 1;
  }
  return encode.put_section(buf, encode.section_data(), body);
}
```
