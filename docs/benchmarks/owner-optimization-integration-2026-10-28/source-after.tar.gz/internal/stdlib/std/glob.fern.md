# Shell-style pattern matches

This module compares strings with shell glob patterns.

## Model

The matcher interprets shell glob syntax against a supplied string. Pattern evaluation does not access the filesystem.

## Contracts

A match tests the pattern against the complete input. Callers that require filesystem expansion must enumerate paths separately.

## Executable example

```fern test name=std-glob-example
import "std/glob";

function main(): i32 {
  if (!glob.glob_match("*.fern", "main.fern")) { return 1; }
  if (glob.glob_match("a?c", "ac")) { return 2; }
  return 0;
}
```

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<2 function __glob_class(p: string, start: i32, ch: i32): (boolean, i32)>>

<<3 pub function glob_match(pattern: string, text: string): boolean>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module compares strings with shell glob patterns.
```

### `2 function __glob_class(p: string, start: i32, ch: i32): (boolean, i32)`

```fern
<<2 function __glob_class(p: string, start: i32, ch: i32): (boolean, i32)>>=
function __glob_class(p: string, start: i32, ch: i32): (boolean, i32) {
  let i: i32 = start + 1;
  let negate: boolean = false;
  if (i < p.len() && (p[i] == 33 || p[i] == 94)) {
    negate = true;
    i = i + 1;
  }
  let matched: boolean = false;
  let first: boolean = true;
  while (i < p.len() && (p[i] != 93 || first)) {
    first = false;
    if (i + 2 < p.len() && p[i + 1] == 45 && p[i + 2] != 93) {
      if (ch >= p[i] as i32 && ch <= p[i + 2] as i32) {
        matched = true;
      }
      i = i + 3;
    } else {
      if (ch == p[i] as i32) {
        matched = true;
      }
      i = i + 1;
    }
  }
  let next: i32 = i;
  if (i < p.len()) {
    next = i + 1;
  }
  if (negate) {
    return (!matched, next);
  }
  return (matched, next);
}

function __glob_match(p: string, i: i32, t: string, j: i32): boolean {
  let pi: i32 = i;
  let tj: i32 = j;
  while (pi < p.len()) {
    let pc: i32 = p[pi] as i32;
    if (pc == 42) {
      if (pi + 1 < p.len() && p[pi + 1] == 42) {
        let ni: i32 = pi;
        while (ni < p.len() && p[ni] == 42) {
          ni = ni + 1;
        }
        if (ni < p.len() && p[ni] == 47) {
          if (__glob_match(p, ni + 1, t, tj)) {
            return true;
          }
        }
        let k: i32 = tj;
        while (k <= t.len()) {
          if (__glob_match(p, ni, t, k)) {
            return true;
          }
          k = k + 1;
        }
        return false;
      }
      let m: i32 = tj;
      let cont: boolean = true;
      while (cont) {
        if (__glob_match(p, pi + 1, t, m)) {
          return true;
        }
        if (m >= t.len() || t[m] == 47) {
          cont = false;
        } else {
          m = m + 1;
        }
      }
      return false;
    } else if (pc == 63) {
      if (tj >= t.len() || t[tj] == 47) {
        return false;
      }
      pi = pi + 1;
      tj = tj + 1;
    } else if (pc == 91) {
      if (tj >= t.len() || t[tj] == 47) {
        return false;
      }
      let res: (boolean, i32) = __glob_class(p, pi, t[tj] as i32);
      if (!res.0) {
        return false;
      }
      pi = res.1;
      tj = tj + 1;
    } else {
      if (tj >= t.len() || t[tj] as i32 != pc) {
        return false;
      }
      pi = pi + 1;
      tj = tj + 1;
    }
  }
  return tj == t.len();
}
```

### `3 pub function glob_match(pattern: string, text: string): boolean`

```fern
<<3 pub function glob_match(pattern: string, text: string): boolean>>=
pub function glob_match(pattern: string, text: string): boolean {
  return __glob_match(pattern, 0, text, 0);
}
```
