# TLS certificate and key material

This module reads TLS certificates and private keys.

## Model

An identity combines a certificate chain with a private key. Parsers accept supported PEM and DER key representations.

## Contracts

The key parser validates structure and algorithm support. Certificate trust and peer authorization require the separate verification policy.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub enum PrivateKey>>

<<4 pub function (e: KeyError) to_string(): string>>

<<5 impl error.Error for KeyError>>

<<6 pub function (e: KeyError) message(): string>>

<<7 function __d[T](r: Result[T, der.DerError]): Result[T, KeyError]>>

<<8 const P256_OID: string>>

<<9 function __curve(oid: string): Result[ecdsa.Curve, KeyError]>>

<<10 pub function private_key_from_pem(text: string): Result[PrivateKey, KeyError]>>

<<11 function __pkcs8_ec(b: [u8], alg: der.Element[], key: u8[]): Result[PrivateKey, KeyError]>>

<<12 pub function sec1(b: [u8]): Result[PrivateKey, KeyError]>>

<<13 function __ec_private_key(b: [u8], known: Option[ecdsa.Curve]): Result[PrivateKey, KeyError]>>

<<14 pub function pair(chain: u8[][], key: PrivateKey): Result[Identity, KeyError]>>

<<15 function __key_matches(public: x509.PublicKey, key: PrivateKey): boolean>>

<<16 pub function (key: PrivateKey) scheme(): i32>>

<<17 function __cat(own a: u8[], b: [u8]): u8[]>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module reads TLS certificates and private keys.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "core/int";
import "std/crypto/ecdsa";
import "std/crypto/sha2";
import "std/crypto/ed25519";
import "std/tls/der";
import "std/tls/pem";
import "std/tls/x509";
import "std/error";
import "core/cmp";
```

### `3 pub enum PrivateKey`

```fern
<<3 pub enum PrivateKey>>=
pub enum PrivateKey {
  EcdsaKey(ecdsa.PrivateKey),
  Ed25519Seed(u8[]),
}

pub struct Identity { chain: u8[][], key: PrivateKey }

pub enum KeyError {
  Pem(pem.PemError),
  BadDer(der.DerError),
  Certificate(x509.X509Error),
  Scalar(ecdsa.EcdsaError),
  Seed(ed25519.Ed25519Error),
  NoKey,
  NoCertificate,
  UnsupportedKey(string),
  BadKey(string),
  Mismatch,
  CannotSign(i32),
}
```

### `4 pub function (e: KeyError) to_string(): string`

```fern
<<4 pub function (e: KeyError) to_string(): string>>=
pub function (e: KeyError) to_string(): string {
  return e.message();
}
```

### `5 impl error.Error for KeyError`

```fern
<<5 impl error.Error for KeyError>>=
impl error.Error for KeyError {}

impl cmp.Display for KeyError {}
```

### `6 pub function (e: KeyError) message(): string`

```fern
<<6 pub function (e: KeyError) message(): string>>=
// fern-lint: allow cyclomatic-complexity
pub function (e: KeyError) message(): string {
  match (e) {
    Pem(p) => {
      return p.message();
    },
    BadDer(d) => {
      return "tls identity: " + d.message();
    },
    Certificate(c) => {
      return "tls identity: " + c.message();
    },
    Scalar(s) => {
      return "tls identity: " + s.message();
    },
    Seed(s) => {
      return "tls identity: " + s.message();
    },
    NoKey => {
      return "tls identity: no PRIVATE KEY or EC PRIVATE KEY block";
    },
    NoCertificate => {
      return "tls identity: no certificate";
    },
    UnsupportedKey(what) => {
      return "tls identity: cannot sign with " + what;
    },
    BadKey(what) => {
      return "tls identity: malformed " + what;
    },
    Mismatch => {
      return "tls identity: the key is not the leaf certificate's";
    },
    CannotSign(scheme) => {
      return "tls identity: the key does not make signature scheme " + int.int_to_string(scheme);
    }
  }
  return "";
}
```

### `7 function __d[T](r: Result[T, der.DerError]): Result[T, KeyError]`

```fern
<<7 function __d[T](r: Result[T, der.DerError]): Result[T, KeyError]>>=
function __d[T](r: Result[T, der.DerError]): Result[T, KeyError] {
  match (r) {
    Ok(v) => {
      return Ok(v);
    },
    Err(e) => {
      return Err(BadDer(e));
    }
  }
  return Err(BadKey("der"));
}
```

### `8 const P256_OID: string`

```fern
<<8 const P256_OID: string>>=
const P256_OID: string = "1.2.840.10045.3.1.7";

const P384_OID: string = "1.3.132.0.34";
```

### `9 function __curve(oid: string): Result[ecdsa.Curve, KeyError]`

```fern
<<9 function __curve(oid: string): Result[ecdsa.Curve, KeyError]>>=
function __curve(oid: string): Result[ecdsa.Curve, KeyError] {
  if (oid == P256_OID) {
    return Ok(ecdsa.P256);
  }
  if (oid == P384_OID) {
    return Ok(ecdsa.P384);
  }
  return Err(UnsupportedKey("curve " + oid));
}

function __scalar_size(c: ecdsa.Curve): i32 {
  match (c) {
    ecdsa.P256 => {
      return 32;
    },
    ecdsa.P384 => {
      return 48;
    }
  }
  return 32;
}

function __same_curve(a: ecdsa.Curve, b: ecdsa.Curve): boolean {
  return __scalar_size(a) == __scalar_size(b);
}
```

### `10 pub function private_key_from_pem(text: string): Result[PrivateKey, KeyError]`

```fern
<<10 pub function private_key_from_pem(text: string): Result[PrivateKey, KeyError]>>=
pub function private_key_from_pem(text: string): Result[PrivateKey, KeyError] {
  let blocks: pem.Block[] = [];
  match (pem.decode(text)) {
    Ok(b) => {
      blocks = b;
    },
    Err(e) => {
      return Err(Pem(e));
    }
  }
  for b in blocks {
    if (b.label == "PRIVATE KEY") {
      return pkcs8(b.bytes);
    }
    if (b.label == "EC PRIVATE KEY") {
      return sec1(b.bytes);
    }
    if (b.label == "RSA PRIVATE KEY") {
      return Err(UnsupportedKey("RSA"));
    }
  }
  return Err(NoKey);
}

pub function pkcs8(b: [u8]): Result[PrivateKey, KeyError] {
  let parts: der.Element[] = __pkcs8_parts(b)?;
  let alg: der.Element[] = __d(der.children(b, parts[1]))?;
  if (alg.len() == 0) {
    return Err(BadKey("privateKeyAlgorithm"));
  }
  let oid: string = __d(der.oid(b, alg[0]))?;
  let key: u8[] = der.bytes(b, parts[2]);
  if (oid == "1.2.840.10045.2.1") {
    return __pkcs8_ec(b, alg, key);
  }
  if (oid == "1.3.101.112") {
    let inner: der.Element = __d(der.only(key, der.OCTET_STRING))?;
    return __ed25519_seed(der.bytes(key, inner));
  }
  if (oid == "1.2.840.113549.1.1.1") {
    return Err(UnsupportedKey("RSA"));
  }
  return Err(UnsupportedKey("algorithm " + oid));
}
```

### `11 function __pkcs8_ec(b: [u8], alg: der.Element[], key: u8[]): Result[PrivateKey, KeyError]`

```fern
<<11 function __pkcs8_ec(b: [u8], alg: der.Element[], key: u8[]): Result[PrivateKey, KeyError]>>=
function __pkcs8_ec(b: [u8], alg: der.Element[], key: u8[]): Result[PrivateKey, KeyError] {
  if (alg.len() < 2) {
    return Err(BadKey("EC parameters"));
  }
  return __ec_private_key(key, Some(__curve(__d(der.oid(b, alg[1]))?)?));
}

function __pkcs8_parts(b: [u8]): Result[der.Element[], KeyError] {
  let seq: der.Element = __d(der.only(b, der.SEQUENCE))?;
  let parts: der.Element[] = __d(der.children(b, seq))?;
  if (parts.len() < 3 || parts[1].tag != der.SEQUENCE || parts[2].tag != der.OCTET_STRING) {
    return Err(BadKey("PrivateKeyInfo"));
  }
  let version: i32 = __d(der.small(b, parts[0]))?;
  if (version != 0 && version != 1) {
    return Err(BadKey("PrivateKeyInfo version"));
  }
  return Ok(parts);
}
```

### `12 pub function sec1(b: [u8]): Result[PrivateKey, KeyError]`

```fern
<<12 pub function sec1(b: [u8]): Result[PrivateKey, KeyError]>>=
pub function sec1(b: [u8]): Result[PrivateKey, KeyError] {
  return __ec_private_key(b, None);
}
```

### `13 function __ec_private_key(b: [u8], known: Option[ecdsa.Curve]): Result[PrivateKey, KeyError]`

```fern
<<13 function __ec_private_key(b: [u8], known: Option[ecdsa.Curve]): Result[PrivateKey, KeyError]>>=
function __ec_private_key(b: [u8], known: Option[ecdsa.Curve]): Result[PrivateKey, KeyError] {
  let seq: der.Element = __d(der.only(b, der.SEQUENCE))?;
  let parts: der.Element[] = __d(der.children(b, seq))?;
  if (parts.len() < 2 || parts[1].tag != der.OCTET_STRING) {
    return Err(BadKey("ECPrivateKey"));
  }
  if (__d(der.small(b, parts[0]))? != 1) {
    return Err(BadKey("ECPrivateKey version"));
  }
  let curve: ecdsa.Curve = __ec_curve(b, parts, known)?;
  match (ecdsa.private_key(curve, __padded(der.bytes(b, parts[1]), __scalar_size(curve)))) {
    Ok(k) => {
      return Ok(EcdsaKey(k));
    },
    Err(e) => {
      return Err(Scalar(e));
    }
  }
  return Err(BadKey("ECPrivateKey"));
}

function __padded(d: u8[], size: i32): u8[] {
  let out: u8[] = [];
  while (out.len() + d.len() < size) {
    out = out.append(0 as u8);
  }
  return __cat(out, d);
}

function __ec_curve(b: [u8], parts: der.Element[], known: Option[ecdsa.Curve]): Result[ecdsa.Curve, KeyError] {
  let named: Option[ecdsa.Curve] = __ec_params(b, parts)?;
  match (known) {
    Some(k) => {
      match (named) {
        Some(n) => {
          if (!__same_curve(k, n)) {
            return Err(BadKey("ECPrivateKey parameters"));
          }
        },
        None => {}
      }
      return Ok(k);
    },
    None => {
      match (named) {
        Some(n) => {
          return Ok(n);
        },
        None => {
          return Err(BadKey("ECPrivateKey parameters"));
        }
      }
    }
  }
  return Err(BadKey("ECPrivateKey parameters"));
}

function __ec_params(b: [u8], parts: der.Element[]): Result[Option[ecdsa.Curve], KeyError] {
  let i: i32 = 2;
  while (i < parts.len()) {
    if (parts[i].tag == der.context(0, true)) {
      let inner: der.Element[] = __d(der.children(b, parts[i]))?;
      if (inner.len() != 1) {
        return Err(BadKey("ECPrivateKey parameters"));
      }
      return Ok(Some(__curve(__d(der.oid(b, inner[0]))?)?));
    }
    i = i + 1;
  }
  return Ok(None);
}

function __ed25519_seed(seed: u8[]): Result[PrivateKey, KeyError] {
  match (ed25519.private_key(seed)) {
    Ok(_) => {
      return Ok(Ed25519Seed(seed));
    },
    Err(e) => {
      return Err(Seed(e));
    }
  }
  return Err(BadKey("Ed25519 seed"));
}
```

### `14 pub function pair(chain: u8[][], key: PrivateKey): Result[Identity, KeyError]`

```fern
<<14 pub function pair(chain: u8[][], key: PrivateKey): Result[Identity, KeyError]>>=
pub function pair(chain: u8[][], key: PrivateKey): Result[Identity, KeyError] {
  if (chain.len() == 0) {
    return Err(NoCertificate);
  }
  match (x509.parse(chain[0])) {
    Ok(leaf) => {
      if (!__key_matches(leaf.key, key)) {
        return Err(Mismatch);
      }
    },
    Err(e) => {
      return Err(Certificate(e));
    }
  }
  return Ok(Identity { chain: chain, key: key });
}

pub function from_pem(chain_text: string, key_text: string): Result[Identity, KeyError] {
  let key: PrivateKey = private_key_from_pem(key_text)?;
  match (pem.certificates(chain_text)) {
    Ok(chain) => {
      return pair(chain, key);
    },
    Err(e) => {
      return Err(Pem(e));
    }
  }
  return Err(NoCertificate);
}
```

### `15 function __key_matches(public: x509.PublicKey, key: PrivateKey): boolean`

```fern
<<15 function __key_matches(public: x509.PublicKey, key: PrivateKey): boolean>>=
function __key_matches(public: x509.PublicKey, key: PrivateKey): boolean {
  match (key) {
    EcdsaKey(k) => {
      match (public) {
        x509.EcKey(curve, point) => {
          return __same_curve(curve, k.curve) && __same(point, k.public_point());
        },
        _ => {
          return false;
        }
      }
    },
    Ed25519Seed(seed) => {
      match (public) {
        x509.Ed25519Key(p) => {
          match (ed25519.private_key(seed)) {
            Ok(q) => {
              return __same(p, q.public_point());
            },
            Err(_) => {
              return false;
            }
          }
        },
        _ => {
          return false;
        }
      }
    }
  }
  return false;
}
```

### `16 pub function (key: PrivateKey) scheme(): i32`

```fern
<<16 pub function (key: PrivateKey) scheme(): i32>>=
pub function (key: PrivateKey) scheme(): i32 {
  match (key) {
    EcdsaKey(k) => {
      match (k.curve) {
        ecdsa.P256 => {
          return 0x0403;
        },
        ecdsa.P384 => {
          return 0x0503;
        }
      }
    },
    Ed25519Seed(_) => {
      return 0x0807;
    }
  }
  return 0;
}

pub function (key: PrivateKey) sign(scheme: i32, content: [u8]): Result[u8[], KeyError] {
  if (scheme != key.scheme()) {
    return Err(CannotSign(scheme));
  }
  match (key) {
    EcdsaKey(k) => {
      let h: sha2.Hash = sha2.Sha256;
      if (scheme == 0x0503) {
        h = sha2.Sha384;
      }
      match (k.sign(h, content)) {
        Ok(sig) => {
          return Ok(sig);
        },
        Err(e) => {
          return Err(Scalar(e));
        }
      }
    },
    Ed25519Seed(seed) => {
      match (ed25519.private_key(seed)) {
        Ok(k) => {
          return Ok(k.sign(content));
        },
        Err(e) => {
          return Err(Seed(e));
        }
      }
    }
  }
  return Err(CannotSign(scheme));
}
```

### `17 function __cat(own a: u8[], b: [u8]): u8[]`

```fern
<<17 function __cat(own a: u8[], b: [u8]): u8[]>>=
function __cat(own a: u8[], b: [u8]): u8[] {
  let i: i32 = 0;
  while (i < b.len()) {
    a = a.append(b[i]);
    i = i + 1;
  }
  return a;
}

function __same(a: [u8], b: [u8]): boolean {
  if (a.len() != b.len()) {
    return false;
  }
  let i: i32 = 0;
  while (i < a.len()) {
    if (a[i] != b[i]) {
      return false;
    }
    i = i + 1;
  }
  return true;
}
```
