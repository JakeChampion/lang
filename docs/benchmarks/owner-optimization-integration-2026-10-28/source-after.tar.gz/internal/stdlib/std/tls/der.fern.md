# DER byte values

This module reads DER values from byte buffers.

## Model

DER readers interpret tagged values and bounded content ranges. Tag constants identify common ASN.1 forms used by certificates and keys.

## Contracts

Lengths and value forms require validation before field access. A parsed DER value alone does not establish certificate trust.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub const BOOLEAN: i32>>

<<4 pub function context(n: i32, constructed: boolean): i32>>

<<5 pub enum DerError>>

<<6 pub function (e: DerError) to_string(): string>>

<<7 impl error.Error for DerError>>

<<8 pub function (e: DerError) message(): string>>

<<9 pub struct Element>>

<<10 function __length(b: [u8], at: i32): Result[Length, DerError]>>

<<11 pub function read(b: [u8], at: i32): Result[Element, DerError]>>

<<12 function __arc(out: string, arc: i64): string>>

<<13 pub struct BitString>>

<<14 pub function bit_string(b: [u8], e: Element): Result[BitString, DerError]>>

<<15 function __digits(b: [u8], at: i32, n: i32): Result[i32, DerError]>>

<<16 pub function text(b: [u8], e: Element): Result[string, DerError]>>

<<17 function __ascii(raw: u8[]): boolean>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module reads DER values from byte buffers.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "core/int";
import "std/i64";
import "std/utf8";
import "std/error";
import "core/cmp";
```

### `3 pub const BOOLEAN: i32`

```fern
<<3 pub const BOOLEAN: i32>>=
pub const BOOLEAN: i32 = 0x01;

pub const INTEGER: i32 = 0x02;

pub const BIT_STRING: i32 = 0x03;

pub const OCTET_STRING: i32 = 0x04;

pub const NULL: i32 = 0x05;

pub const OID: i32 = 0x06;

pub const UTF8_STRING: i32 = 0x0c;

pub const PRINTABLE_STRING: i32 = 0x13;

pub const TELETEX_STRING: i32 = 0x14;

pub const IA5_STRING: i32 = 0x16;

pub const UTC_TIME: i32 = 0x17;

pub const GENERALIZED_TIME: i32 = 0x18;

pub const BMP_STRING: i32 = 0x1e;

pub const SEQUENCE: i32 = 0x30;

pub const SET: i32 = 0x31;
```

### `4 pub function context(n: i32, constructed: boolean): i32`

```fern
<<4 pub function context(n: i32, constructed: boolean): i32>>=
pub function context(n: i32, constructed: boolean): i32 {
  if (constructed) {
    return 0xa0 | n;
  }
  return 0x80 | n;
}
```

### `5 pub enum DerError`

```fern
<<5 pub enum DerError>>=
pub enum DerError {
  Truncated,
  BadLength,
  HighTag,
  UnexpectedTag(i32, i32),
  BadValue(string),
}
```

### `6 pub function (e: DerError) to_string(): string`

```fern
<<6 pub function (e: DerError) to_string(): string>>=
pub function (e: DerError) to_string(): string {
  return e.message();
}
```

### `7 impl error.Error for DerError`

```fern
<<7 impl error.Error for DerError>>=
impl error.Error for DerError {}

impl cmp.Display for DerError {}
```

### `8 pub function (e: DerError) message(): string`

```fern
<<8 pub function (e: DerError) message(): string>>=
pub function (e: DerError) message(): string {
  match (e) {
    Truncated => {
      return "der: truncated";
    },
    BadLength => {
      return "der: a length DER does not allow";
    },
    HighTag => {
      return "der: a high tag number";
    },
    UnexpectedTag(want, got) => {
      return "der: tag " + int.int_to_string(got) + " where " + int.int_to_string(want) + " was wanted";
    },
    BadValue(what) => {
      return "der: malformed " + what;
    }
  }
  return "";
}
```

### `9 pub struct Element`

```fern
<<9 pub struct Element>>=
pub struct Element { tag: i32, start: i32, from: i32, to: i32, next: i32 }

struct Length { len: i32, from: i32 }
```

### `10 function __length(b: [u8], at: i32): Result[Length, DerError]`

```fern
<<10 function __length(b: [u8], at: i32): Result[Length, DerError]>>=
function __length(b: [u8], at: i32): Result[Length, DerError] {
  if (at >= b.len()) {
    return Err(Truncated);
  }
  let first: i32 = b[at] as i32;
  if (first < 0x80) {
    return Ok(Length { len: first, from: at + 1 });
  }
  return __long_length(b, at + 1, first & 0x7f);
}

function __long_length(b: [u8], at: i32, n: i32): Result[Length, DerError] {
  if (n == 0 || n > 4) {
    return Err(BadLength);
  }
  if (at + n > b.len()) {
    return Err(Truncated);
  }
  if (b[at] == 0 || n == 4 && b[at] >= 0x80) {
    return Err(BadLength);
  }
  let len: i32 = 0;
  let i: i32 = 0;
  while (i < n) {
    len = len << 8 | b[at + i] as i32;
    i = i + 1;
  }
  if (len < 0x80) {
    return Err(BadLength);
  }
  return Ok(Length { len: len, from: at + n });
}
```

### `11 pub function read(b: [u8], at: i32): Result[Element, DerError]`

```fern
<<11 pub function read(b: [u8], at: i32): Result[Element, DerError]>>=
pub function read(b: [u8], at: i32): Result[Element, DerError] {
  if (at >= b.len()) {
    return Err(Truncated);
  }
  let tag: i32 = b[at] as i32;
  if ((tag & 0x1f) == 0x1f) {
    return Err(HighTag);
  }
  let l: Length = __length(b, at + 1)?;
  if (l.len > b.len() - l.from) {
    return Err(Truncated);
  }
  return Ok(Element { tag: tag, start: at, from: l.from, to: l.from + l.len, next: l.from + l.len });
}

pub function expect(b: [u8], at: i32, tag: i32): Result[Element, DerError] {
  let e: Element = read(b, at)?;
  if (e.tag != tag) {
    return Err(UnexpectedTag(tag, e.tag));
  }
  return Ok(e);
}

pub function only(b: [u8], tag: i32): Result[Element, DerError] {
  let e: Element = expect(b, 0, tag)?;
  if (e.next != b.len()) {
    return Err(BadValue("trailing bytes"));
  }
  return Ok(e);
}

pub function children(b: [u8], e: Element): Result[Element[], DerError] {
  let inner: [u8] = b[0:e.to];
  let out: Element[] = [];
  let at: i32 = e.from;
  while (at < e.to) {
    let c: Element = read(inner, at)?;
    out = out.append(c);
    at = c.next;
  }
  return Ok(out);
}

pub function bytes(b: [u8], e: Element): u8[] {
  let out: u8[] = __alloc_u8(e.to - e.from);
  let i: i32 = e.from;
  while (i < e.to) {
    out = out.with(i - e.from, b[i]);
    i = i + 1;
  }
  return out;
}

pub function whole(b: [u8], e: Element): u8[] {
  return bytes(b, Element { ...e, from: e.start });
}

pub function unsigned(b: [u8], e: Element): Result[u8[], DerError] {
  if (e.tag != INTEGER) {
    return Err(UnexpectedTag(INTEGER, e.tag));
  }
  let n: i32 = e.to - e.from;
  if (n == 0 || b[e.from] >= 0x80) {
    return Err(BadValue("integer"));
  }
  if (n > 1 && b[e.from] == 0 && b[e.from + 1] < 0x80) {
    return Err(BadValue("integer"));
  }
  if (n > 1 && b[e.from] == 0) {
    return Ok(bytes(b, Element { ...e, from: e.from + 1 }));
  }
  return Ok(bytes(b, e));
}

pub function small(b: [u8], e: Element): Result[i32, DerError] {
  let v: u8[] = unsigned(b, e)?;
  if (v.len() > 4 || v.len() == 4 && v[0] >= 0x80) {
    return Err(BadValue("integer"));
  }
  let out: i32 = 0;
  let i: i32 = 0;
  while (i < v.len()) {
    out = out << 8 | v[i] as i32;
    i = i + 1;
  }
  return Ok(out);
}

pub function boolean_value(b: [u8], e: Element): Result[boolean, DerError] {
  if (e.tag != BOOLEAN) {
    return Err(UnexpectedTag(BOOLEAN, e.tag));
  }
  if (e.to - e.from != 1 || b[e.from] != 0 && b[e.from] != 0xff) {
    return Err(BadValue("boolean"));
  }
  return Ok(b[e.from] == 0xff);
}

pub function oid(b: [u8], e: Element): Result[string, DerError] {
  if (e.tag != OID) {
    return Err(UnexpectedTag(OID, e.tag));
  }
  if (e.to == e.from || b[e.to - 1] >= 0x80) {
    return Err(BadValue("object identifier"));
  }
  let out: string = "";
  let arc: i64 = 0;
  let start: boolean = true;
  let i: i32 = e.from;
  while (i < e.to) {
    if (start && b[i] == 0x80) {
      return Err(BadValue("object identifier"));
    }
    arc = arc << 7 | (b[i] & 0x7f) as i64;
    if (arc > 0xffffffff) {
      return Err(BadValue("object identifier"));
    }
    start = b[i] < 0x80;
    if (start) {
      out = __arc(out, arc);
      arc = 0;
    }
    i = i + 1;
  }
  return Ok(out);
}
```

### `12 function __arc(out: string, arc: i64): string`

```fern
<<12 function __arc(out: string, arc: i64): string>>=
function __arc(out: string, arc: i64): string {
  if (out.len() > 0) {
    return out + "." + arc.to_string();
  }
  if (arc < 80) {
    return (arc / 40).to_string() + "." + (arc % 40).to_string();
  }
  return "2." + (arc - 80).to_string();
}
```

### `13 pub struct BitString`

```fern
<<13 pub struct BitString>>=
pub struct BitString { unused: i32, bytes: u8[] }
```

### `14 pub function bit_string(b: [u8], e: Element): Result[BitString, DerError]`

```fern
<<14 pub function bit_string(b: [u8], e: Element): Result[BitString, DerError]>>=
pub function bit_string(b: [u8], e: Element): Result[BitString, DerError] {
  if (e.tag != BIT_STRING) {
    return Err(UnexpectedTag(BIT_STRING, e.tag));
  }
  if (e.to == e.from) {
    return Err(BadValue("bit string"));
  }
  let unused: i32 = b[e.from] as i32;
  let n: i32 = e.to - e.from - 1;
  if (unused > 7 || n == 0 && unused != 0) {
    return Err(BadValue("bit string"));
  }
  if (n > 0 && (b[e.to - 1] as i32 & (1 << unused) - 1) != 0) {
    return Err(BadValue("bit string"));
  }
  return Ok(BitString { unused: unused, bytes: bytes(b, Element { ...e, from: e.from + 1 }) });
}

pub function time(b: [u8], e: Element): Result[i64, DerError] {
  let n: i32 = e.to - e.from;
  let at: i32 = e.from;
  let year: i32 = 0;
  if (e.tag == UTC_TIME && n == 13) {
    year = __digits(b, at, 2)?;
    year = year + 1900;
    if (year < 1950) {
      year = year + 100;
    }
    at = at + 2;
  } else if (e.tag == GENERALIZED_TIME && n == 15) {
    year = __digits(b, at, 4)?;
    at = at + 4;
  } else {
    return Err(BadValue("time"));
  }
  if (b[e.to - 1] != 0x5a) {
    return Err(BadValue("time"));
  }
  return __seconds(year, b, at);
}
```

### `15 function __digits(b: [u8], at: i32, n: i32): Result[i32, DerError]`

```fern
<<15 function __digits(b: [u8], at: i32, n: i32): Result[i32, DerError]>>=
function __digits(b: [u8], at: i32, n: i32): Result[i32, DerError] {
  let v: i32 = 0;
  let i: i32 = 0;
  while (i < n) {
    let d: i32 = b[at + i] as i32 - 48;
    if (d < 0 || d > 9) {
      return Err(BadValue("time"));
    }
    v = v * 10 + d;
    i = i + 1;
  }
  return Ok(v);
}

function __seconds(year: i32, b: [u8], at: i32): Result[i64, DerError] {
  let f: i32[] = [];
  let i: i32 = 0;
  while (i < 5) {
    f = f.append(__digits(b, at + 2 * i, 2)?);
    i = i + 1;
  }
  if (!__in_range(year, f[0], f[1], f[2], f[3], f[4])) {
    return Err(BadValue("time"));
  }
  return Ok(((__days(year, f[0], f[1]) * 24 + f[2] as i64) * 60 + f[3] as i64) * 60 + f[4] as i64);
}

function __in_range(year: i32, month: i32, day: i32, hour: i32, minute: i32, second: i32): boolean {
  if (month < 1 || month > 12 || day < 1) {
    return false;
  }
  return day <= __month_days(year, month) && hour <= 23 && minute <= 59 && second <= 59;
}

function __leap(y: i32): boolean {
  return y % 4 == 0 && (y % 100 != 0 || y % 400 == 0);
}

function __month_days(y: i32, m: i32): i32 {
  if (m == 2 && __leap(y)) {
    return 29;
  }
  let days: i32[] = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return days[m - 1];
}

function __days(y: i32, m: i32, d: i32): i64 {
  let yy: i64 = y as i64;
  if (m <= 2) {
    yy = yy - 1;
  }
  let era: i64 = yy / 400;
  let yoe: i64 = yy - era * 400;
  let mp: i64 = (m as i64 + 9) % 12;
  let doy: i64 = (153 * mp + 2) / 5 + d as i64 - 1;
  let doe: i64 = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return era * 146097 + doe - 719468;
}
```

### `16 pub function text(b: [u8], e: Element): Result[string, DerError]`

```fern
<<16 pub function text(b: [u8], e: Element): Result[string, DerError]>>=
pub function text(b: [u8], e: Element): Result[string, DerError] {
  if (e.tag == BMP_STRING) {
    return __bmp(b, e);
  }
  if (e.tag != UTF8_STRING && e.tag != PRINTABLE_STRING && e.tag != IA5_STRING && e.tag != TELETEX_STRING) {
    return Err(UnexpectedTag(UTF8_STRING, e.tag));
  }
  let raw: u8[] = bytes(b, e);
  if (e.tag != UTF8_STRING && !__ascii(raw)) {
    return Err(BadValue("string"));
  }
  match (utf8.from_bytes(raw)) {
    Ok(s) => {
      return Ok(s);
    },
    Err(_) => {
      return Err(BadValue("string"));
    }
  }
  return Err(BadValue("string"));
}
```

### `17 function __ascii(raw: u8[]): boolean`

```fern
<<17 function __ascii(raw: u8[]): boolean>>=
function __ascii(raw: u8[]): boolean {
  for c in raw {
    if (c >= 0x80) {
      return false;
    }
  }
  return true;
}

function __bmp(b: [u8], e: Element): Result[string, DerError] {
  if ((e.to - e.from) % 2 != 0) {
    return Err(BadValue("string"));
  }
  let out: u8[] = [];
  let i: i32 = e.from;
  while (i < e.to) {
    let c: i32 = b[i] as i32 << 8 | b[i + 1] as i32;
    if (c >= 0xd800 && c < 0xe000) {
      return Err(BadValue("string"));
    }
    out = __utf8(out, c);
    i = i + 2;
  }
  return Ok(string_from_bytes_unchecked(out));
}

function __utf8(own out: u8[], c: i32): u8[] {
  if (c < 0x80) {
    return out.append(c as u8);
  }
  if (c < 0x800) {
    return out.append((0xc0 | c >> 6) as u8).append((0x80 | c & 0x3f) as u8);
  }
  return out.append((0xe0 | c >> 12) as u8).append((0x80 | c >> 6 & 0x3f) as u8).append((0x80 | c & 0x3f) as u8);
}
```
