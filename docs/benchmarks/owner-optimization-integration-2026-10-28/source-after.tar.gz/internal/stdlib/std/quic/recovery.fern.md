# QUIC loss and congestion state

This module detects packet loss and controls congestion under RFC 9002.

## Model

Recovery tracks sent packets, acknowledgments, round-trip time, and congestion state. Separate packet-number spaces retain their own protocol progress.

## Contracts

The caller supplies consistent time values. Loss deadlines and probe timeouts affect retransmission decisions. Acknowledged data and lost packets require different state updates.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub const INITIAL: i32>>

<<4 pub function new(max_datagram: i32, server: boolean): Recovery>>

<<6 pub function (r: Recovery) on_ack(space: i32, ack: frames.Ack, ack_delay: Duration, now: Instant, largest_sent:...>>

<<7 function __acked_of(sent: Sent[], ack: frames.Ack): Sent[]>>

<<8 function (r: Recovery) __on_lost(lost: Sent[], now: i64): Recovery>>

<<9 pub function (r: Recovery) pto(space: i32): Duration>>

<<10 function (r: Recovery) __earliest_loss(): (i64, i32)>>

<<11 pub function (r: Recovery) on_timeout(now: Instant): Recovery>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module detects packet loss and controls congestion under RFC 9002.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/quic/frames";
import "std/array";
import "std/i64";
import "std/time";
```

### `3 pub const INITIAL: i32`

```fern
<<3 pub const INITIAL: i32>>=
pub const INITIAL: i32 = 0;

pub const HANDSHAKE: i32 = 1;

pub const APPLICATION: i32 = 2;

pub const PACKET_THRESHOLD: i64 = 3;

pub const GRANULARITY: Duration = Duration { sec: 0, nsec: 1000000 };

pub const INITIAL_RTT: Duration = Duration { sec: 0, nsec: 333000000 };

pub const PERSISTENT_CONGESTION_THRESHOLD: i64 = 3;

pub enum Resend {
  CryptoRange(i64, i32),
  StreamRange(i64, i64, i32, boolean),
  Again(frames.Frame),
}

pub struct Sent { pn: i64, at: Instant, size: i32, ack_eliciting: boolean, in_flight: boolean, resend: Resend[] }

struct Space { sent: Sent[], largest_acked: i64, loss_time: i64, last_ack_eliciting: i64 }

pub struct Recovery {
  spaces: Space[],
  latest_rtt: i64,
  smoothed_rtt: i64,
  rttvar: i64,
  min_rtt: i64,
  first_rtt_sample: i64,
  pto_count: i32,
  max_ack_delay: i64,
  max_datagram: i64,
  bytes_in_flight: i64,
  cwnd: i64,
  ssthresh: i64,
  recovery_start: i64,
  handshake_confirmed: boolean,
  peer_validated: boolean,
  // What the last on_ack or on_timeout found, until outcome_taken: the
  // packets newly acknowledged and those declared lost, the space to probe
  // or -1, and the error code of an ACK of a packet never sent or 0.
  acked: Sent[],
  lost: Sent[],
  probe: i32,
  refused: i64,
}
```

### `4 pub function new(max_datagram: i32, server: boolean): Recovery`

```fern
<<4 pub function new(max_datagram: i32, server: boolean): Recovery>>=
pub function new(max_datagram: i32, server: boolean): Recovery {
  let empty: Space = Space { sent: [], largest_acked: 0 - 1 as i64, loss_time: 0 as i64, last_ack_eliciting: 0 as i64 };
  let md: i64 = max_datagram as i64;
  let window: i64 = 14720;
  if (window < 2 * md) {
    window = 2 * md;
  }
  if (window > 10 * md) {
    window = 10 * md;
  }
  return Recovery { spaces: [empty, empty, empty], latest_rtt: 0 as i64, smoothed_rtt: INITIAL_RTT.as_nanos(), rttvar: INITIAL_RTT.as_nanos() / 2, min_rtt: 0 as i64, first_rtt_sample: 0 as i64, pto_count: 0, max_ack_delay: 0 as i64, max_datagram: md, bytes_in_flight: 0 as i64, cwnd: window, ssthresh: frames.MAX_VARINT, recovery_start: 0 - 1 as i64, handshake_confirmed: false, peer_validated: server, acked: [], lost: [], probe: 0 - 1, refused: 0 as i64 };
}

pub function (r: Recovery) with_max_ack_delay(d: Duration): Recovery {
  return Recovery { ...r, max_ack_delay: d.as_nanos() };
}

pub function (r: Recovery) confirmed(): Recovery {
  return Recovery { ...r, handshake_confirmed: true, peer_validated: true };
}

pub function (r: Recovery) validated(): Recovery {
  return Recovery { ...r, peer_validated: true };
}

pub function (r: Recovery) window(): i64 {
  let room: i64 = r.cwnd - r.bytes_in_flight;
  if (room < 0) {
    return 0 as i64;
  }
  return room;
}

pub function (r: Recovery) in_flight(): boolean {
  for s in r.spaces {
    for p in s.sent {
      if (p.ack_eliciting) {
        return true;
      }
    }
  }
  return false;
}

pub function (r: Recovery) on_sent(space: i32, p: Sent): Recovery {
  let s: Space = r.spaces[space];
  s = Space { ...s, sent: s.sent.append(p) };
  if (p.ack_eliciting) {
    s = Space { ...s, last_ack_eliciting: time.instant_nanos(p.at) };
  }
  let flight: i64 = r.bytes_in_flight;
  if (p.in_flight) {
    flight = flight + p.size as i64;
  }
  return Recovery { ...r, spaces: r.spaces.with(space, s), bytes_in_flight: flight };
}
```

### `6 pub function (r: Recovery) on_ack(space: i32, ack: frames.Ack, ack_delay: Duration, now: Instant, largest_sent:...`

```fern
<<6 pub function (r: Recovery) on_ack(space: i32, ack: frames.Ack, ack_delay: Duration, now: Instant, largest_sent:...>>=
pub function (r: Recovery) on_ack(space: i32, ack: frames.Ack, ack_delay: Duration, now: Instant, largest_sent: i64): Recovery {
  return r.__on_ack(space, ack, ack_delay.as_nanos(), time.instant_nanos(now), largest_sent);
}

function (r: Recovery) __on_ack(space: i32, ack: frames.Ack, ack_delay: i64, now: i64, largest_sent: i64): Recovery {
  let largest: i64 = ack.ranges[0].high;
  if (largest > largest_sent) {
    return Recovery { ...r, acked: [], lost: [], probe: 0 - 1, refused: frames.PROTOCOL_VIOLATION };
  }
  let acked: Sent[] = __acked_of(r.spaces[space].sent, ack);
  let cur: Recovery = Recovery { ...r, spaces: r.spaces.with(space, r.spaces[space].__after_ack(ack, largest, acked.len() > 0)), acked: acked, lost: [], probe: 0 - 1, refused: 0 as i64 };
  if (acked.len() == 0) {
    return cur;
  }
  let newest: Sent = acked[acked.len() - 1];
  if (newest.pn == largest && __any_eliciting(acked)) {
    cur = cur.__rtt_sample(now - time.instant_nanos(newest.at), ack_delay, space);
  }
  cur = cur.__on_acked(acked).__detect_lost(space, now);
  cur = cur.__on_lost(cur.lost, now);
  if (!(space == INITIAL && !cur.peer_validated)) {
    cur = Recovery { ...cur, pto_count: 0 };
  }
  return cur;
}

pub function (r: Recovery) outcome_taken(): Recovery {
  return Recovery { ...r, acked: [], lost: [], probe: 0 - 1, refused: 0 as i64 };
}

function (s: Space) __after_ack(ack: frames.Ack, largest: i64, any: boolean): Space {
  let top: i64 = s.largest_acked;
  if (largest > top) {
    top = largest;
  }
  if (!any) {
    return Space { ...s, largest_acked: top };
  }
  return Space { ...s, largest_acked: top, sent: __unacked(s.sent, ack) };
}
```

### `7 function __acked_of(sent: Sent[], ack: frames.Ack): Sent[]`

```fern
<<7 function __acked_of(sent: Sent[], ack: frames.Ack): Sent[]>>=
function __acked_of(sent: Sent[], ack: frames.Ack): Sent[] {
  if (__covers_all(sent, ack)) {
    return sent;
  }
  let acked: Sent[] = [];
  for p in sent {
    if (__covers(ack, p.pn)) {
      acked = acked.append(p);
    }
  }
  return acked;
}

function __unacked(sent: Sent[], ack: frames.Ack): Sent[] {
  if (__covers_all(sent, ack)) {
    return [];
  }
  let kept: Sent[] = [];
  for p in sent {
    if (!__covers(ack, p.pn)) {
      kept = kept.append(p);
    }
  }
  return kept;
}

function __covers_all(sent: Sent[], ack: frames.Ack): boolean {
  for p in sent {
    if (!__covers(ack, p.pn)) {
      return false;
    }
  }
  return true;
}

function __covers(ack: frames.Ack, pn: i64): boolean {
  for range in ack.ranges {
    if (pn >= range.low && pn <= range.high) {
      return true;
    }
  }
  return false;
}

function __any_eliciting(ps: Sent[]): boolean {
  for p in ps {
    if (p.ack_eliciting) {
      return true;
    }
  }
  return false;
}

function (r: Recovery) __rtt_sample(latest: i64, ack_delay: i64, space: i32): Recovery {
  if (r.first_rtt_sample == 0) {
    return Recovery { ...r, latest_rtt: latest, min_rtt: latest, smoothed_rtt: latest, rttvar: latest / 2, first_rtt_sample: 1 as i64 };
  }
  let min: i64 = r.min_rtt;
  if (latest < min) {
    min = latest;
  }
  let delay: i64 = 0;
  if (space == APPLICATION && r.handshake_confirmed) {
    delay = ack_delay;
    if (delay > r.max_ack_delay) {
      delay = r.max_ack_delay;
    }
  }
  let adjusted: i64 = latest;
  if (latest >= min + delay) {
    adjusted = latest - delay;
  }
  let diff: i64 = r.smoothed_rtt - adjusted;
  if (diff < 0) {
    diff = 0 - diff;
  }
  return Recovery { ...r, latest_rtt: latest, min_rtt: min, rttvar: (3 * r.rttvar + diff) / 4, smoothed_rtt: (7 * r.smoothed_rtt + adjusted) / 8 };
}

function (r: Recovery) __on_acked(acked: Sent[]): Recovery {
  let flight: i64 = r.bytes_in_flight;
  let cwnd: i64 = r.cwnd;
  for p in acked {
    if (!p.in_flight) {
      continue;
    }
    flight = flight - p.size as i64;
    if (time.instant_nanos(p.at) <= r.recovery_start) {
      continue;
    }
    if (cwnd < r.ssthresh) {
      cwnd = cwnd + p.size as i64;
    } else {
      cwnd = cwnd + r.max_datagram * (p.size as i64) / cwnd;
    }
  }
  return Recovery { ...r, bytes_in_flight: flight, cwnd: cwnd };
}

function (r: Recovery) __loss_delay(): i64 {
  let rtt: i64 = r.latest_rtt;
  if (r.smoothed_rtt > rtt) {
    rtt = r.smoothed_rtt;
  }
  let d: i64 = rtt * 9 / 8;
  if (d < GRANULARITY.as_nanos()) {
    return GRANULARITY.as_nanos();
  }
  return d;
}

function (r: Recovery) __detect_lost(space: i32, now: i64): Recovery {
  let delay: i64 = r.__loss_delay();
  let lost: Sent[] = __lost_of(r.spaces[space], now - delay);
  return Recovery { ...r, spaces: r.spaces.with(space, r.spaces[space].__past_loss(now - delay, delay)), lost: lost };
}

function __lost_of(s: Space, lost_before: i64): Sent[] {
  let lost: Sent[] = [];
  for p in s.sent {
    if (__is_lost(s, p, lost_before)) {
      lost = lost.append(p);
    }
  }
  return lost;
}

function __is_lost(s: Space, p: Sent, lost_before: i64): boolean {
  return p.pn <= s.largest_acked && (time.instant_nanos(p.at) <= lost_before || s.largest_acked >= p.pn + PACKET_THRESHOLD);
}

function (s: Space) __past_loss(lost_before: i64, delay: i64): Space {
  let kept: Sent[] = [];
  let loss_time: i64 = 0;
  for p in s.sent {
    if (!__is_lost(s, p, lost_before)) {
      kept = kept.append(p);
      let due: i64 = time.instant_nanos(p.at) + delay;
      if (p.pn <= s.largest_acked && (loss_time == 0 || due < loss_time)) {
        loss_time = due;
      }
    }
  }
  return Space { ...s, sent: kept, loss_time: loss_time };
}
```

### `8 function (r: Recovery) __on_lost(lost: Sent[], now: i64): Recovery`

```fern
<<8 function (r: Recovery) __on_lost(lost: Sent[], now: i64): Recovery>>=
function (r: Recovery) __on_lost(lost: Sent[], now: i64): Recovery {
  if (lost.len() == 0) {
    return r;
  }
  let flight: i64 = r.bytes_in_flight;
  let newest: i64 = 0;
  for p in lost {
    if (p.in_flight) {
      flight = flight - p.size as i64;
    }
    if (time.instant_nanos(p.at) > newest) {
      newest = time.instant_nanos(p.at);
    }
  }
  let cur: Recovery = Recovery { ...r, bytes_in_flight: flight };
  if (newest > cur.recovery_start) {
    let half: i64 = cur.cwnd / 2;
    if (half < 2 * cur.max_datagram) {
      half = 2 * cur.max_datagram;
    }
    cur = Recovery { ...cur, recovery_start: now, ssthresh: half, cwnd: half };
  }
  if (cur.__persistent(lost)) {
    cur = Recovery { ...cur, cwnd: 2 * cur.max_datagram, recovery_start: 0 - 1 as i64 };
  }
  return cur;
}

function (r: Recovery) __persistent(lost: Sent[]): boolean {
  if (r.first_rtt_sample == 0) {
    return false;
  }
  let first: i64 = 0 - 1 as i64;
  let last: i64 = 0 - 1 as i64;
  for p in lost {
    if (!p.ack_eliciting) {
      continue;
    }
    let at: i64 = time.instant_nanos(p.at);
    if (first < 0 || at < first) {
      first = at;
    }
    if (at > last) {
      last = at;
    }
  }
  let duration: i64 = (r.smoothed_rtt + __max(4 * r.rttvar, GRANULARITY.as_nanos()) + r.max_ack_delay) * PERSISTENT_CONGESTION_THRESHOLD;
  return first >= 0 && last - first > duration;
}

function __max(a: i64, b: i64): i64 {
  if (a > b) {
    return a;
  }
  return b;
}
```

### `9 pub function (r: Recovery) pto(space: i32): Duration`

```fern
<<9 pub function (r: Recovery) pto(space: i32): Duration>>=
pub function (r: Recovery) pto(space: i32): Duration {
  return time.duration_nanos(r.pto_ns(space));
}

// The connection's own nanosecond bookkeeping reads these two.
pub(package) function (r: Recovery) pto_ns(space: i32): i64 {
  let d: i64 = r.smoothed_rtt + __max(4 * r.rttvar, GRANULARITY.as_nanos());
  if (space == APPLICATION) {
    d = d + r.max_ack_delay;
  }
  return d;
}

pub(package) function (r: Recovery) timer_ns(): i64 {
  let (loss, _) = r.__earliest_loss();
  if (loss > 0) {
    return loss;
  }
  let (pto, _) = r.__pto_time();
  return pto;
}

// When the loss or probe timer fires next, if one is armed.
pub function (r: Recovery) timer(): Option[Instant] {
  let at: i64 = r.timer_ns();
  if (at == 0) {
    return None;
  }
  return Some(time.instant_from_nanos(at));
}
```

### `10 function (r: Recovery) __earliest_loss(): (i64, i32)`

```fern
<<10 function (r: Recovery) __earliest_loss(): (i64, i32)>>=
function (r: Recovery) __earliest_loss(): (i64, i32) {
  let at: i64 = 0;
  let space: i32 = 0 - 1;
  let i: i32 = 0;
  while (i < 3) {
    let t: i64 = r.spaces[i].loss_time;
    if (t > 0 && (at == 0 || t < at)) {
      at = t;
      space = i;
    }
    i = i + 1;
  }
  return (at, space);
}

function (r: Recovery) __pto_time(): (i64, i32) {
  let backoff: i64 = 1 as i64 << r.pto_count as i64;
  let at: i64 = 0;
  let space: i32 = 0 - 1;
  let i: i32 = 0;
  while (i < 3) {
    let s: Space = r.spaces[i];
    if (__eliciting_in(s) && !(i == APPLICATION && !r.handshake_confirmed)) {
      let t: i64 = s.last_ack_eliciting + r.pto_ns(i) * backoff;
      if (at == 0 || t < at) {
        at = t;
        space = i;
      }
    }
    i = i + 1;
  }
  return (at, space);
}

function __eliciting_in(s: Space): boolean {
  for p in s.sent {
    if (p.ack_eliciting) {
      return true;
    }
  }
  return false;
}
```

### `11 pub function (r: Recovery) on_timeout(now: Instant): Recovery`

```fern
<<11 pub function (r: Recovery) on_timeout(now: Instant): Recovery>>=
pub function (r: Recovery) on_timeout(at: Instant): Recovery {
  let now: i64 = time.instant_nanos(at);
  let (loss, space) = r.__earliest_loss();
  let (pto, pspace) = r.__pto_time();
  let cur: Recovery = r.outcome_taken();
  if (loss > 0 && loss <= now) {
    cur = cur.__detect_lost(space, now);
    return cur.__on_lost(cur.lost, now);
  }
  if (pto == 0 || pto > now) {
    return cur;
  }
  return Recovery { ...cur, pto_count: cur.pto_count + 1, probe: pspace };
}

pub function (r: Recovery) unacked(space: i32): Sent[] {
  return r.spaces[space].sent;
}

pub function (r: Recovery) discard(space: i32): Recovery {
  let s: Space = r.spaces[space];
  let flight: i64 = r.bytes_in_flight;
  for p in s.sent {
    if (p.in_flight) {
      flight = flight - p.size as i64;
    }
  }
  return Recovery { ...r, spaces: r.spaces.with(space, Space { sent: [], largest_acked: s.largest_acked, loss_time: 0 as i64, last_ack_eliciting: 0 as i64 }), bytes_in_flight: flight, pto_count: 0 };
}

pub function (r: Recovery) smoothed(): Duration {
  return time.duration_nanos(r.smoothed_rtt);
}
```
