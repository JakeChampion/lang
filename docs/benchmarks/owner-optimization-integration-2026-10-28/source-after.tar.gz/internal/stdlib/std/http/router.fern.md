# HTTP route selection

This module selects HTTP handlers by request method and path.

## Model

A route combines an HTTP method, a path pattern, parameter names, and a handler. A router retains routes and wrapper callbacks.

## Contracts

Route construction can record a concrete route error. Parameter access distinguishes a missing value from a value that cannot be parsed as an integer.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub struct Params>>

<<4 pub function no_params(): Params>>

<<5 pub enum Segment>>

<<6 pub function (e: RouteError) to_string(): string>>

<<7 impl error.Error for RouteError>>

<<8 pub function (e: RouteError) message(): string>>

<<9 function __wrapped[P](r: Router[P], i: i32, req: HttpRequest, plat: P): Result[HttpResponse, dyn http.ToRes...>>

<<10 pub function (r: Router[P]) handler(): (HttpRequest, P)>>

<<11 function __pick[P](r: Router[P], path: string, end: i32, method: string): i32>>

<<12 function __bind[P](route: Route[P], path: string, end: i32): Params>>

<<13 function __is_name(s: string): boolean>>

<<14 const REL_SAME: i32>>

<<15 function __conflicts(rel: i32): boolean>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module selects HTTP handlers by request method and path.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/i32";
import "std/http";
import "std/string";
import "core/int";
import "std/error";
import "core/cmp";
```

### `3 pub struct Params`

```fern
<<3 pub struct Params>>=
pub struct Params { names: string[], values: string[] }
```

### `4 pub function no_params(): Params`

```fern
<<4 pub function no_params(): Params>>=
pub function no_params(): Params {
  return Params { names: [], values: [] };
}

pub function (p: Params) get(name: string): Option[string] {
  let i: i32 = 0;
  while (i < p.names.len()) {
    if (p.names[i] == name) {
      return Some(p.values[i]);
    }
    i = i + 1;
  }
  return None;
}

pub function (p: Params) param(name: string): Result[string, http.HttpError] {
  match (p.get(name)) {
    Some(v) => {
      return Ok(v);
    },
    None => {
      return Err(http.fail(500, "the route binds no path parameter " + name));
    }
  }
  return Err(http.fail(500, "the route binds no path parameter " + name));
}

pub function (p: Params) int(name: string): Result[i32, http.HttpError] {
  let v: string = p.param(name)?;
  match (i32.parse_i32_radix(v, 10)) {
    Ok(n) => {
      return Ok(n);
    },
    Err(_) => {
      return Err(http.fail(400, "path parameter " + name + " is not an integer: " + v));
    }
  }
  return Err(http.fail(400, "path parameter " + name + " is not an integer: " + v));
}
```

### `5 pub enum Segment`

```fern
<<5 pub enum Segment>>=
pub enum Segment {
  PathLiteral(string),
  PathParam(string),
  PathRest(string),
}

pub struct Route[P] { method: string, pattern: string, segments: Segment[], params: Params, handler: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse] }

pub struct Router[P] { routes: Route[P][], wraps: ((HttpRequest, P, (HttpRequest) => Result[HttpResponse, dyn http.ToResponse]) => Result[HttpResponse, dyn http.ToResponse])[], refused: Option[RouteError] }

pub enum RouteError {
  BadPattern(string, string),
  PatternConflict(string, string),
}
```

### `6 pub function (e: RouteError) to_string(): string`

```fern
<<6 pub function (e: RouteError) to_string(): string>>=
pub function (e: RouteError) to_string(): string {
  return e.message();
}
```

### `7 impl error.Error for RouteError`

```fern
<<7 impl error.Error for RouteError>>=
impl error.Error for RouteError {}

impl cmp.Display for RouteError {}
```

### `8 pub function (e: RouteError) message(): string`

```fern
<<8 pub function (e: RouteError) message(): string>>=
pub function (e: RouteError) message(): string {
  match (e) {
    BadPattern(p, why) => {
      return "http router: pattern " + p + ": " + why;
    },
    PatternConflict(p, other) => {
      return "http router: pattern " + p + " conflicts with " + other;
    }
  }
  return "";
}

pub function new[P](): Router[P] {
  return Router { routes: [], wraps: [], refused: None };
}

pub function (r: Router[P]) route(pattern: string, handler: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse]): Router[P] {
  if let Some(_) = r.refused {
    return r;
  }
  match (__parse(pattern)) {
    Ok(parsed) => {
      let route: Route[P] = Route { method: parsed.0, pattern: pattern, segments: parsed.1, params: Params { names: __names(parsed.1), values: [] }, handler: handler };
      for other in r.routes {
        if (__conflicts(__relation(route.method, route.segments, other.method, other.segments))) {
          return Router { ...r, refused: Some(PatternConflict(pattern, other.pattern)) };
        }
      }
      return Router { ...r, routes: r.routes.append(route) };
    },
    Err(e) => {
      return Router { ...r, refused: Some(e) };
    }
  }
  return r;
}

pub function (r: Router[P]) get(path: string, handler: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse]): Router[P] {
  return r.route("GET " + path, handler);
}

pub function (r: Router[P]) post(path: string, handler: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse]): Router[P] {
  return r.route("POST " + path, handler);
}

pub function (r: Router[P]) put(path: string, handler: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse]): Router[P] {
  return r.route("PUT " + path, handler);
}

pub function (r: Router[P]) patch(path: string, handler: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse]): Router[P] {
  return r.route("PATCH " + path, handler);
}

pub function (r: Router[P]) delete(path: string, handler: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse]): Router[P] {
  return r.route("DELETE " + path, handler);
}

pub function (r: Router[P]) wrap(middleware: (HttpRequest, P, (HttpRequest) => Result[HttpResponse, dyn http.ToResponse]) => Result[HttpResponse, dyn http.ToResponse]): Router[P] {
  return Router { ...r, wraps: r.wraps.append(middleware) };
}

pub function (r: Router[P]) check(): Result[Router[P], RouteError] {
  match (r.refused) {
    Some(e) => {
      return Err(e);
    },
    None => {
      return Ok(r);
    }
  }
  return Ok(r);
}

pub function (r: Router[P]) handle(req: HttpRequest, plat: P): HttpResponse {
  if let Some(e) = r.refused {
    return http.problem(500, "", e.message());
  }
  if (r.wraps.len() == 0) {
    return http.respond(__dispatch(r, req, plat));
  }
  return http.respond(__wrapped(r, 0, req, plat));
}
```

### `9 function __wrapped[P](r: Router[P], i: i32, req: HttpRequest, plat: P): Result[HttpResponse, dyn http.ToRes...`

```fern
<<9 function __wrapped[P](r: Router[P], i: i32, req: HttpRequest, plat: P): Result[HttpResponse, dyn http.ToRes...>>=
function __wrapped[P](r: Router[P], i: i32, req: HttpRequest, plat: P): Result[HttpResponse, dyn http.ToResponse] {
  if (i >= r.wraps.len()) {
    return __dispatch(r, req, plat);
  }
  let middleware: (HttpRequest, P, (HttpRequest) => Result[HttpResponse, dyn http.ToResponse]) => Result[HttpResponse, dyn http.ToResponse] = r.wraps[i];
  return middleware(req, plat, (inner: HttpRequest): Result[HttpResponse, dyn http.ToResponse] => __wrapped(r, i + 1, inner, plat));
}

function __dispatch[P](r: Router[P], req: HttpRequest, plat: P): Result[HttpResponse, dyn http.ToResponse] {
  let end: i32 = __path_end(req.path);
  let picked: i32 = __pick(r, req.path, end, req.method);
  if (picked >= 0) {
    let route: Route[P] = r.routes[picked];
    let h: (HttpRequest, Params, P) => Result[HttpResponse, dyn http.ToResponse] = route.handler;
    return h(req, __bind(route, req.path, end), plat);
  }
  let allowed: string[] = __allowed(r, req.path, end, req.method);
  if (allowed.len() > 0) {
    return Ok(http.problem(405, "", "").with_header("allow", allowed.join(", ")));
  }
  return Ok(http.not_found());
}
```

### `10 pub function (r: Router[P]) handler(): (HttpRequest, P)`

```fern
<<10 pub function (r: Router[P]) handler(): (HttpRequest, P)>>=
pub function (r: Router[P]) handler(): (HttpRequest, P) => HttpResponse {
  if let Some(e) = r.refused {
    eprint(e.message());
    exit(2);
  }
  return (req: HttpRequest, plat: P): HttpResponse => r.handle(req, plat);
}
```

### `11 function __pick[P](r: Router[P], path: string, end: i32, method: string): i32`

```fern
<<11 function __pick[P](r: Router[P], path: string, end: i32, method: string): i32>>=
function __pick[P](r: Router[P], path: string, end: i32, method: string): i32 {
  let best: i32 = -1;
  let i: i32 = 0;
  while (i < r.routes.len()) {
    let route: Route[P] = r.routes[i];
    if (__method_allows(route.method, method) && __matches(route.segments, path, end)) {
      if (best < 0 || __relation(route.method, route.segments, r.routes[best].method, r.routes[best].segments) == REL_NARROWER) {
        best = i;
      }
    }
    i = i + 1;
  }
  return best;
}

function __allowed[P](r: Router[P], path: string, end: i32, method: string): string[] {
  let allowed: string[] = [];
  for route in r.routes {
    if (!__method_allows(route.method, method) && __matches(route.segments, path, end)) {
      allowed = __add_once(allowed, route.method);
      if (route.method == "GET") {
        allowed = __add_once(allowed, "HEAD");
      }
    }
  }
  return allowed;
}

function __add_once(xs: string[], x: string): string[] {
  for y in xs {
    if (y == x) {
      return xs;
    }
  }
  return xs.append(x);
}

function __method_allows(route: string, method: string): boolean {
  return route == "" || route == method || route == "GET" && method == "HEAD";
}

function __path_end(path: string): i32 {
  let i: i32 = 0;
  while (i < path.len()) {
    if (path[i] == b'?' || path[i] == b'#') {
      return i;
    }
    i = i + 1;
  }
  return path.len();
}

function __next_slash(path: string, from: i32, end: i32): i32 {
  let i: i32 = from;
  while (i < end) {
    if (path[i] == b'/') {
      return i;
    }
    i = i + 1;
  }
  return end;
}

function __range_is(path: string, a: i32, b: i32, s: string): boolean {
  if (b - a != s.len()) {
    return false;
  }
  let i: i32 = 0;
  while (i < s.len()) {
    if (path[a + i] != s[i]) {
      return false;
    }
    i = i + 1;
  }
  return true;
}

function __matches(segs: Segment[], path: string, end: i32): boolean {
  let pos: i32 = 0;
  let i: i32 = 0;
  while (i < segs.len()) {
    if (pos >= end || path[pos] != b'/') {
      return false;
    }
    match (segs[i]) {
      PathRest(_) => {
        return true;
      },
      PathLiteral(s) => {
        let stop: i32 = __next_slash(path, pos + 1, end);
        if (!__range_is(path, pos + 1, stop, s)) {
          return false;
        }
        pos = stop;
      },
      PathParam(_) => {
        let stop: i32 = __next_slash(path, pos + 1, end);
        if (stop == pos + 1) {
          return false;
        }
        pos = stop;
      }
    }
    i = i + 1;
  }
  return pos == end;
}

function __names(segs: Segment[]): string[] {
  let names: string[] = [];
  for seg in segs {
    let n: string = __bound_name(seg);
    if (n.len() > 0) {
      names = names.append(n);
    }
  }
  return names;
}
```

### `12 function __bind[P](route: Route[P], path: string, end: i32): Params`

```fern
<<12 function __bind[P](route: Route[P], path: string, end: i32): Params>>=
function __bind[P](route: Route[P], path: string, end: i32): Params {
  if (route.params.names.len() == 0) {
    return route.params;
  }
  let values: string[] = [];
  let pos: i32 = 0;
  let i: i32 = 0;
  while (i < route.segments.len()) {
    match (route.segments[i]) {
      PathParam(_) => {
        let stop: i32 = __next_slash(path, pos + 1, end);
        values = values.append(slice_unchecked(path, pos + 1, stop) + "");
        pos = stop;
      },
      PathRest(n) => {
        if (n.len() > 0) {
          values = values.append(slice_unchecked(path, pos + 1, end) + "");
        }
      },
      PathLiteral(_) => {
        pos = __next_slash(path, pos + 1, end);
      }
    }
    i = i + 1;
  }
  return Params { ...route.params, values: values };
}

function __parse(pattern: string): Result[(string, Segment[]), RouteError] {
  let method: string = "";
  let path: string = pattern;
  if (!pattern.starts_with("/")) {
    let parts: string[] = pattern.splitn(" ", 2);
    if (parts.len() != 2 || !__is_method(parts[0]) || !parts[1].starts_with("/")) {
      return Err(BadPattern(pattern, "expected [METHOD ]/path"));
    }
    method = parts[0];
    path = parts[1];
  }
  let segs: Segment[] = __segments(pattern, path)?;
  return Ok((method, segs));
}

function __is_method(s: string): boolean {
  if (s.len() == 0) {
    return false;
  }
  for b in s.bytes() {
    if (b as i32 < 65 || b as i32 > 90) {
      return false;
    }
  }
  return true;
}

function __segments(pattern: string, path: string): Result[Segment[], RouteError] {
  let raw: string[] = path.split("/");
  let out: Segment[] = [];
  let names: string[] = [];
  let i: i32 = 1;
  while (i < raw.len()) {
    let seg: Segment = __segment(pattern, raw[i], i == raw.len() - 1)?;
    let name: string = __bound_name(seg);
    if (name != "") {
      if (__add_once(names, name).len() == names.len()) {
        return Err(BadPattern(pattern, "parameter " + name + " is bound twice"));
      }
      names = names.append(name);
    }
    out = out.append(seg);
    i = i + 1;
  }
  return Ok(out);
}

function __bound_name(seg: Segment): string {
  match (seg) {
    PathParam(n) => {
      return n;
    },
    PathRest(n) => {
      return n;
    },
    PathLiteral(_) => {
      return "";
    }
  }
  return "";
}

function __segment(pattern: string, s: string, last: boolean): Result[Segment, RouteError] {
  if (s == "") {
    if (!last) {
      return Err(BadPattern(pattern, "empty segment"));
    }
    return Ok(PathRest(""));
  }
  if (s == "{$}") {
    if (!last) {
      return Err(BadPattern(pattern, "{$} must be the last segment"));
    }
    return Ok(PathLiteral(""));
  }
  if (s.starts_with("{") && s.ends_with("}")) {
    return __wildcard(pattern, s.slice_snap(1, s.len() - 1), last);
  }
  return __literal(pattern, s);
}

function __literal(pattern: string, s: string): Result[Segment, RouteError] {
  if (s.contains("{") || s.contains("}")) {
    return Err(BadPattern(pattern, "a brace inside the segment " + s));
  }
  if (s.contains("?") || s.contains("#")) {
    return Err(BadPattern(pattern, "a query or fragment in the segment " + s));
  }
  return Ok(PathLiteral(s));
}

function __wildcard(pattern: string, inner: string, last: boolean): Result[Segment, RouteError] {
  if (inner.ends_with("...")) {
    if (!last) {
      return Err(BadPattern(pattern, "{name...} must be the last segment"));
    }
    let name: string = inner.slice_snap(0, inner.len() - 3);
    if (!__is_name(name)) {
      return Err(BadPattern(pattern, "bad parameter name " + name));
    }
    return Ok(PathRest(name));
  }
  if (!__is_name(inner)) {
    return Err(BadPattern(pattern, "bad parameter name " + inner));
  }
  return Ok(PathParam(inner));
}
```

### `13 function __is_name(s: string): boolean`

```fern
<<13 function __is_name(s: string): boolean>>=
function __is_name(s: string): boolean {
  if (s.len() == 0) {
    return false;
  }
  let i: i32 = 0;
  for b in s.bytes() {
    if (!__name_byte(b as i32, i == 0)) {
      return false;
    }
    i = i + 1;
  }
  return true;
}

function __name_byte(c: i32, first: boolean): boolean {
  if (c >= 65 && c <= 90 || c >= 97 && c <= 122 || c == 95) {
    return true;
  }
  return !first && c >= 48 && c <= 57;
}
```

### `14 const REL_SAME: i32`

```fern
<<14 const REL_SAME: i32>>=
const REL_SAME: i32 = 0;

const REL_NARROWER: i32 = 1;

const REL_WIDER: i32 = 2;

const REL_APART: i32 = 3;

const REL_CROSSED: i32 = 4;
```

### `15 function __conflicts(rel: i32): boolean`

```fern
<<15 function __conflicts(rel: i32): boolean>>=
function __conflicts(rel: i32): boolean {
  return rel == REL_SAME || rel == REL_CROSSED;
}

function __combine(acc: i32, r: i32): i32 {
  if (acc == REL_APART || r == REL_APART) {
    return REL_APART;
  }
  if (acc == REL_SAME) {
    return r;
  }
  if (r == REL_SAME || r == acc) {
    return acc;
  }
  return REL_CROSSED;
}

function __relation(method_a: string, a: Segment[], method_b: string, b: Segment[]): i32 {
  return __combine(__method_relation(method_a, method_b), __path_relation(a, b));
}

function __method_relation(a: string, b: string): i32 {
  if (a == b) {
    return REL_SAME;
  }
  if (a == "") {
    return REL_WIDER;
  }
  if (b == "") {
    return REL_NARROWER;
  }
  if (a == "GET" && b == "HEAD") {
    return REL_WIDER;
  }
  if (a == "HEAD" && b == "GET") {
    return REL_NARROWER;
  }
  return REL_APART;
}

function __path_relation(a: Segment[], b: Segment[]): i32 {
  let acc: i32 = REL_SAME;
  let i: i32 = 0;
  while (i < a.len() && i < b.len()) {
    let step: i32 = __segment_relation(a[i], b[i]);
    if (__is_rest(a[i]) || __is_rest(b[i])) {
      return __combine(acc, step);
    }
    acc = __combine(acc, step);
    if (acc == REL_APART) {
      return REL_APART;
    }
    i = i + 1;
  }
  if (i < a.len() || i < b.len()) {
    return REL_APART;
  }
  return acc;
}

function __is_rest(s: Segment): boolean {
  match (s) {
    PathRest(_) => {
      return true;
    },
    _ => {
      return false;
    }
  }
  return false;
}

function __segment_relation(a: Segment, b: Segment): i32 {
  match (a) {
    PathRest(_) => {
      if (__is_rest(b)) {
        return REL_SAME;
      }
      return REL_WIDER;
    },
    PathLiteral(x) => {
      return __literal_relation(x, b);
    },
    PathParam(_) => {
      return __param_relation(b);
    }
  }
  return REL_APART;
}

function __literal_relation(x: string, b: Segment): i32 {
  match (b) {
    PathLiteral(y) => {
      if (x == y) {
        return REL_SAME;
      }
      return REL_APART;
    },
    PathParam(_) => {
      if (x == "") {
        return REL_APART;
      }
      return REL_NARROWER;
    },
    PathRest(_) => {
      return REL_NARROWER;
    }
  }
  return REL_APART;
}

function __param_relation(b: Segment): i32 {
  match (b) {
    PathLiteral(y) => {
      if (y == "") {
        return REL_APART;
      }
      return REL_WIDER;
    },
    PathParam(_) => {
      return REL_SAME;
    },
    PathRest(_) => {
      return REL_NARROWER;
    }
  }
  return REL_APART;
}
```
