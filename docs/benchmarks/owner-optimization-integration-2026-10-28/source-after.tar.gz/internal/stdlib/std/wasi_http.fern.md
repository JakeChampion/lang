# WASI HTTP host interfaces

This module connects HTTP clients and handlers to the `wasi:http` interfaces.

## Model

The adapter converts between Fern HTTP values and WASI HTTP resources. Client requests carry authority, transport, headers, body, timeouts, and body limits.

## Contracts

Host resource handles have explicit ownership and lifetime rules. Error values distinguish host codes, invalid fields, body limits, truncation, and lost resources.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 enum WasiHttpMethod>>

<<4 function req_method(req: i32): WasiHttpMethod>>

<<5 const WRITE_CHUNK: i32>>

<<6 pub function serve(request: i32, response_out: i32, handle: (HttpRequest, platform.Host)>>

<<7 function method_name(m: WasiHttpMethod): string>>

<<8 const READ_WHOLE: i32>>

<<9 function drain(body: i32, cap: Option[i32]): (u8[], i32)>>

<<10 function request_set_scheme(req: i32, some: i32, scheme: i32, other: string): i32>>

<<11 struct FutureGot>>

<<12 function future_get(fut: i32): FutureGot>>

<<13 pub struct Outgoing>>

<<14 pub function error_code(n: i32): ErrorCode>>

<<15 function __name_connect(c: ErrorCode): string>>

<<16 pub enum OutgoingError>>

<<17 pub function (e: OutgoingError) message(): string>>

<<18 impl error.Error for OutgoingError>>

<<19 pub function outgoing(o: Outgoing): Result[HttpResponse, OutgoingError]>>

<<20 function build_request(o: Outgoing): Result[i32, OutgoingError]>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module connects HTTP clients and handlers to the `wasi:http` interfaces.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/http";
import "std/platform";
import "std/stream";
import "std/error";
import "core/cmp";
import "core/int";
```

### `3 enum WasiHttpMethod`

```fern
<<3 enum WasiHttpMethod>>=
enum WasiHttpMethod { MethodGet, MethodHead, MethodPost, MethodPut, MethodDelete, MethodConnect, MethodOptions, MethodTrace, MethodPatch, MethodOther(string) }
```

### `4 function req_method(req: i32): WasiHttpMethod`

```fern
<<4 function req_method(req: i32): WasiHttpMethod>>=
@import("wasi:http/types@0.2.0", "[method]incoming-request.method")
function req_method(req: i32): WasiHttpMethod;

@import("wasi:http/types@0.2.0", "[method]incoming-request.path-with-query")
function req_path(req: i32): Option[string];

@import("wasi:http/types@0.2.0", "[method]incoming-request.headers")
function req_headers(req: i32): i32;

@import("wasi:http/types@0.2.0", "[method]incoming-request.consume")
function req_consume(req: i32): Result[i32, i32];

@import("wasi:http/types@0.2.0", "[resource-drop]incoming-request")
function req_drop(req: i32): void;

@import("wasi:http/types@0.2.0", "[method]incoming-body.stream")
function body_stream(body: i32): Result[i32, i32];

@import("wasi:http/types@0.2.0", "[static]incoming-body.finish")
function body_finish(body: i32): i32;

@import("wasi:http/types@0.2.0", "[resource-drop]future-trailers")
function trailers_drop(trailers: i32): void;

@import("wasi:io/streams@0.2.0", "[method]input-stream.blocking-read")
function stream_read(stream: i32, len: i64): Result[u8[], i32];

@import("wasi:io/streams@0.2.0", "[resource-drop]input-stream")
function input_stream_drop(stream: i32): void;

@import("wasi:http/types@0.2.0", "[method]fields.entries")
function fields_entries(fields: i32): (string, string)[];

@import("wasi:http/types@0.2.0", "[constructor]fields")
function fields_new(): i32;

@import("wasi:http/types@0.2.0", "[method]fields.append")
function fields_append(fields: i32, name: string, value: string): Result[i32, i32];

@import("wasi:http/types@0.2.0", "[resource-drop]fields")
function fields_drop(fields: i32): void;

@import("wasi:http/types@0.2.0", "[constructor]outgoing-response")
function response_new(headers: i32): i32;

@import("wasi:http/types@0.2.0", "[method]outgoing-response.set-status-code")
function response_set_status(resp: i32, status: i32): i32;

@import("wasi:http/types@0.2.0", "[method]outgoing-response.body")
function response_body(resp: i32): Result[i32, i32];

@import("wasi:http/types@0.2.0", "[method]outgoing-body.write")
function body_write(body: i32): Result[i32, i32];

@import("wasi:io/streams@0.2.0", "[method]output-stream.blocking-write-and-flush")
function stream_write(stream: i32, bytes: u8[]): Result[i32, i32];

@import("wasi:io/streams@0.2.0", "[resource-drop]output-stream")
function output_stream_drop(stream: i32): void;

@import("wasi:http/types@0.2.0", "[static]outgoing-body.finish")
function body_finish_out(body: i32, trailers: Option[i32]): Result[i32, i32];

@import("wasi:http/types@0.2.0", "[static]response-outparam.set")
function outparam_set(out: i32, disc: i32, resp: i32, a: i32, b: i64, c: i32, d: i32, e: i32, f: i32): void;
```

### `5 const WRITE_CHUNK: i32`

```fern
<<5 const WRITE_CHUNK: i32>>=
const WRITE_CHUNK: i32 = 4096;
```

### `6 pub function serve(request: i32, response_out: i32, handle: (HttpRequest, platform.Host)`

```fern
<<6 pub function serve(request: i32, response_out: i32, handle: (HttpRequest, platform.Host)>>=
pub function serve(request: i32, response_out: i32, handle: (HttpRequest, platform.Host) => HttpResponse): void {
  let method: string = method_name(req_method(request));
  let target: string = "/";
  match (req_path(request)) {
    Some(p) => {
      target = p;
    },
    None => {
      target = "/";
    }
  }
  let path: string = "";
  match (http.http_request_target(method, target)) {
    Ok(p) => {
      path = p;
    },
    Err(status) => {
      req_drop(request);
      send(response_out, http.text(status, ""));
      return;
    }
  }
  let fields: i32 = req_headers(request);
  let (data, how) = read_body(request);
  let headers: HeaderMap = headers_of(fields);
  req_drop(request);
  if (how == READ_PAST_CAP) {
    send(response_out, http.text(413, ""));
    return;
  }
  let req: HttpRequest = HttpRequest { method: method, path: path, body: stream.stream_from_bytes(data), headers: headers, trailers: HeaderMap { names: [], values: [] } };
  let resp: HttpResponse = handle(req, platform.host());
  send(response_out, resp);
  match (resp.background) {
    Some(work) => {
      work();
    },
    None => {}
  }
}
```

### `7 function method_name(m: WasiHttpMethod): string`

```fern
<<7 function method_name(m: WasiHttpMethod): string>>=
function method_name(m: WasiHttpMethod): string {
  match (m) {
    MethodGet => {
      return "GET";
    },
    MethodHead => {
      return "HEAD";
    },
    MethodPost => {
      return "POST";
    },
    MethodPut => {
      return "PUT";
    },
    MethodDelete => {
      return "DELETE";
    },
    MethodConnect => {
      return "CONNECT";
    },
    MethodOptions => {
      return "OPTIONS";
    },
    MethodTrace => {
      return "TRACE";
    },
    MethodPatch => {
      return "PATCH";
    },
    MethodOther(s) => {
      return s;
    }
  }
  return "";
}

function read_body(request: i32): (u8[], i32) {
  match (req_consume(request)) {
    Ok(body) => {
      return drain(body, Some(http.http_limits().body));
    },
    Err(e) => {}
  }
  return ([], READ_WHOLE);
}
```

### `8 const READ_WHOLE: i32`

```fern
<<8 const READ_WHOLE: i32>>=
const READ_WHOLE: i32 = 0;

const READ_PAST_CAP: i32 = 1;

const READ_FAILED: i32 = 2;
```

### `9 function drain(body: i32, cap: Option[i32]): (u8[], i32)`

```fern
<<9 function drain(body: i32, cap: Option[i32]): (u8[], i32)>>=
function drain(body: i32, cap: Option[i32]): (u8[], i32) {
  let data: u8[] = [];
  let how: i32 = READ_WHOLE;
  match (body_stream(body)) {
    Ok(stream) => {
      let (read, ended) = read_stream(stream, cap);
      data = read;
      how = ended;
      input_stream_drop(stream);
    },
    Err(e) => {}
  }
  trailers_drop(body_finish(body));
  return (data, how);
}

function read_stream(stream: i32, cap: Option[i32]): (u8[], i32) {
  let data: u8[] = [];
  while (true) {
    match (stream_read(stream, WRITE_CHUNK as i64)) {
      Ok(chunk) => {
        if (past(data.len() + chunk.len(), cap)) {
          return (data, READ_PAST_CAP);
        }
        let i: i32 = 0;
        while (i < chunk.len()) {
          data = data.append(chunk[i]);
          i = i + 1;
        }
      },
      Err(e) => {
        if (e == 1) {
          return (data, READ_WHOLE);
        }
        return (data, READ_FAILED);
      }
    }
  }
  return (data, READ_WHOLE);
}

function past(n: i32, cap: Option[i32]): boolean {
  match (cap) {
    Some(c) => {
      return n > c;
    },
    None => {
      return false;
    }
  }
  return false;
}

function headers_of(fields: i32): HeaderMap {
  let names: string[] = [];
  let values: string[] = [];
  for entry in fields_entries(fields) {
    let (name, value) = entry;
    names = names.append(name);
    values = values.append(value);
  }
  fields_drop(fields);
  return HeaderMap { names: names, values: values };
}

function send(response_out: i32, resp: HttpResponse): void {
  let fields: i32 = fields_new();
  let i: i32 = 0;
  while (i < resp.headers.names.len()) {
    match (fields_append(fields, resp.headers.names[i], resp.headers.values[i])) {
      Ok(v) => {},
      Err(e) => {}
    }
    i = i + 1;
  }
  let response: i32 = response_new(fields);
  response_set_status(response, resp.status);
  match (response_body(response)) {
    Ok(body) => {
      outparam_set(response_out, 0, response, 0, 0 as i64, 0, 0, 0, 0);
      write_body(body, resp.body_bytes());
    },
    Err(e) => {
      outparam_set(response_out, 0, response, 0, 0 as i64, 0, 0, 0, 0);
    }
  }
}

function write_body(body: i32, bytes: u8[]): void {
  match (body_write(body)) {
    Ok(stream) => {
      write_all(stream, bytes);
      output_stream_drop(stream);
    },
    Err(e) => {}
  }
  match (body_finish_out(body, None)) {
    Ok(v) => {},
    Err(e) => {}
  }
}

function write_all(stream: i32, body: u8[]): void {
  let off: i32 = 0;
  let n: i32 = body.len();
  if (n == 0) {
    return;
  }
  let chunk: usize = buf_new(WRITE_CHUNK);
  while (off < n) {
    let end: i32 = n;
    if (n - off > WRITE_CHUNK) {
      end = off + WRITE_CHUNK;
    }
    buf_push_bytes_range(chunk, body, off, end);
    match (stream_write(stream, buf_take_bytes(chunk))) {
      Ok(v) => {
        off = end;
      },
      Err(e) => {
        off = n;
      }
    }
  }
  buf_free(chunk);
}

// The outgoing side: host request imports.
@import("wasi:http/types@0.2.0", "[constructor]outgoing-request")
function request_new(headers: i32): i32;

@import("wasi:http/types@0.2.0", "[method]outgoing-request.set-method")
function request_set_method(req: i32, method: i32, other: string): i32;
```

### `10 function request_set_scheme(req: i32, some: i32, scheme: i32, other: string): i32`

```fern
<<10 function request_set_scheme(req: i32, some: i32, scheme: i32, other: string): i32>>=
@import("wasi:http/types@0.2.0", "[method]outgoing-request.set-scheme")
function request_set_scheme(req: i32, some: i32, scheme: i32, other: string): i32;

@import("wasi:http/types@0.2.0", "[method]outgoing-request.set-authority")
function request_set_authority(req: i32, some: i32, authority: string): i32;

@import("wasi:http/types@0.2.0", "[method]outgoing-request.set-path-with-query")
function request_set_path(req: i32, some: i32, path: string): i32;

@import("wasi:http/types@0.2.0", "[method]outgoing-request.body")
function request_body(req: i32): Result[i32, i32];

@import("wasi:http/types@0.2.0", "[resource-drop]outgoing-request")
function request_drop(req: i32): void;

@import("wasi:http/types@0.2.0", "[constructor]request-options")
function options_new(): i32;

@import("wasi:http/types@0.2.0", "[method]request-options.set-connect-timeout")
function options_set_connect_timeout(opts: i32, some: i32, ns: i64): i32;

@import("wasi:http/types@0.2.0", "[method]request-options.set-first-byte-timeout")
function options_set_first_byte_timeout(opts: i32, some: i32, ns: i64): i32;

@import("wasi:http/types@0.2.0", "[method]request-options.set-between-bytes-timeout")
function options_set_between_bytes_timeout(opts: i32, some: i32, ns: i64): i32;

@import("wasi:http/outgoing-handler@0.2.0", "handle")
function outgoing_handle(req: i32, some: i32, opts: i32): Result[i64, i64];

@import("wasi:http/types@0.2.0", "[method]future-incoming-response.subscribe")
function future_subscribe(fut: i32): i32;

@import("wasi:io/poll@0.2.0", "[method]pollable.block")
function pollable_block(ready: i32): void;

@import("wasi:io/poll@0.2.0", "[resource-drop]pollable")
function pollable_drop(ready: i32): void;
```

### `11 struct FutureGot`

```fern
<<11 struct FutureGot>>=
struct FutureGot { w0: i32, w1: i32, w2: i32, w3: i32, w4: i32, w5: i32, w6: i32, w7: i32, w8: i32, w9: i32, w10: i32, w11: i32, w12: i32, w13: i32 }
```

### `12 function future_get(fut: i32): FutureGot`

```fern
<<12 function future_get(fut: i32): FutureGot>>=
@import("wasi:http/types@0.2.0", "[method]future-incoming-response.get")
function future_get(fut: i32): FutureGot;

@import("wasi:http/types@0.2.0", "[resource-drop]future-incoming-response")
function future_drop(fut: i32): void;

@import("wasi:http/types@0.2.0", "[method]incoming-response.status")
function response_status(resp: i32): i32;

@import("wasi:http/types@0.2.0", "[method]incoming-response.headers")
function response_headers(resp: i32): i32;

@import("wasi:http/types@0.2.0", "[method]incoming-response.consume")
function response_consume(resp: i32): Result[i32, i32];

@import("wasi:http/types@0.2.0", "[resource-drop]incoming-response")
function response_drop(resp: i32): void;
```

### `13 pub struct Outgoing`

```fern
<<13 pub struct Outgoing>>=
pub struct Outgoing { method: string, authority: string, tls: boolean, target: string, headers: HeaderMap, body: u8[], connect: Duration, inactivity: Duration, body_cap: i32 }

pub enum ErrorCode {
  DnsTimeout,
  DnsError,
  DestinationNotFound,
  DestinationUnavailable,
  DestinationIpProhibited,
  DestinationIpUnroutable,
  ConnectionRefused,
  ConnectionTerminated,
  ConnectionTimeout,
  ConnectionReadTimeout,
  ConnectionWriteTimeout,
  ConnectionLimitReached,
  TlsProtocolError,
  TlsCertificateError,
  TlsAlertReceived,
  HttpRequestDenied,
  HttpRequestLengthRequired,
  HttpRequestBodySize,
  HttpRequestMethodInvalid,
  HttpRequestUriInvalid,
  HttpRequestUriTooLong,
  HttpRequestHeaderSectionSize,
  HttpRequestHeaderSize,
  HttpRequestTrailerSectionSize,
  HttpRequestTrailerSize,
  HttpResponseIncomplete,
  HttpResponseHeaderSectionSize,
  HttpResponseHeaderSize,
  HttpResponseBodySize,
  HttpResponseTrailerSectionSize,
  HttpResponseTrailerSize,
  HttpResponseTransferCoding,
  HttpResponseContentCoding,
  HttpResponseTimeout,
  HttpUpgradeFailed,
  HttpProtocolError,
  LoopDetected,
  ConfigurationError,
  InternalError,
  Unknown(i32),
}
```

### `14 pub function error_code(n: i32): ErrorCode`

```fern
<<14 pub function error_code(n: i32): ErrorCode>>=
pub function error_code(n: i32): ErrorCode {
  let all: ErrorCode[] = [ErrorCode.DnsTimeout, ErrorCode.DnsError, ErrorCode.DestinationNotFound, ErrorCode.DestinationUnavailable, ErrorCode.DestinationIpProhibited, ErrorCode.DestinationIpUnroutable, ErrorCode.ConnectionRefused, ErrorCode.ConnectionTerminated, ErrorCode.ConnectionTimeout, ErrorCode.ConnectionReadTimeout, ErrorCode.ConnectionWriteTimeout, ErrorCode.ConnectionLimitReached, ErrorCode.TlsProtocolError, ErrorCode.TlsCertificateError, ErrorCode.TlsAlertReceived, ErrorCode.HttpRequestDenied, ErrorCode.HttpRequestLengthRequired, ErrorCode.HttpRequestBodySize, ErrorCode.HttpRequestMethodInvalid, ErrorCode.HttpRequestUriInvalid, ErrorCode.HttpRequestUriTooLong, ErrorCode.HttpRequestHeaderSectionSize, ErrorCode.HttpRequestHeaderSize, ErrorCode.HttpRequestTrailerSectionSize, ErrorCode.HttpRequestTrailerSize, ErrorCode.HttpResponseIncomplete, ErrorCode.HttpResponseHeaderSectionSize, ErrorCode.HttpResponseHeaderSize, ErrorCode.HttpResponseBodySize, ErrorCode.HttpResponseTrailerSectionSize, ErrorCode.HttpResponseTrailerSize, ErrorCode.HttpResponseTransferCoding, ErrorCode.HttpResponseContentCoding, ErrorCode.HttpResponseTimeout, ErrorCode.HttpUpgradeFailed, ErrorCode.HttpProtocolError, ErrorCode.LoopDetected, ErrorCode.ConfigurationError, ErrorCode.InternalError];
  if (n >= 0 && n < all.len()) {
    return all[n];
  }
  return ErrorCode.Unknown(n);
}

pub function (c: ErrorCode) name(): string {
  match (c) {
    ErrorCode.DnsTimeout => {
      return "DNS-timeout";
    },
    ErrorCode.DnsError => {
      return "DNS-error";
    },
    ErrorCode.DestinationNotFound => {
      return "destination-not-found";
    },
    ErrorCode.DestinationUnavailable => {
      return "destination-unavailable";
    },
    ErrorCode.DestinationIpProhibited => {
      return "destination-IP-prohibited";
    },
    ErrorCode.DestinationIpUnroutable => {
      return "destination-IP-unroutable";
    },
    ErrorCode.ConnectionRefused => {
      return "connection-refused";
    },
    ErrorCode.ConnectionTerminated => {
      return "connection-terminated";
    },
    _ => {
      return __name_connect(c);
    }
  }
  return "";
}
```

### `15 function __name_connect(c: ErrorCode): string`

```fern
<<15 function __name_connect(c: ErrorCode): string>>=
function __name_connect(c: ErrorCode): string {
  match (c) {
    ErrorCode.ConnectionTimeout => {
      return "connection-timeout";
    },
    ErrorCode.ConnectionReadTimeout => {
      return "connection-read-timeout";
    },
    ErrorCode.ConnectionWriteTimeout => {
      return "connection-write-timeout";
    },
    ErrorCode.ConnectionLimitReached => {
      return "connection-limit-reached";
    },
    ErrorCode.TlsProtocolError => {
      return "TLS-protocol-error";
    },
    ErrorCode.TlsCertificateError => {
      return "TLS-certificate-error";
    },
    ErrorCode.TlsAlertReceived => {
      return "TLS-alert-received";
    },
    ErrorCode.HttpRequestDenied => {
      return "HTTP-request-denied";
    },
    _ => {
      return __name_request(c);
    }
  }
  return "";
}

function __name_request(c: ErrorCode): string {
  match (c) {
    ErrorCode.HttpRequestLengthRequired => {
      return "HTTP-request-length-required";
    },
    ErrorCode.HttpRequestBodySize => {
      return "HTTP-request-body-size";
    },
    ErrorCode.HttpRequestMethodInvalid => {
      return "HTTP-request-method-invalid";
    },
    ErrorCode.HttpRequestUriInvalid => {
      return "HTTP-request-URI-invalid";
    },
    ErrorCode.HttpRequestUriTooLong => {
      return "HTTP-request-URI-too-long";
    },
    ErrorCode.HttpRequestHeaderSectionSize => {
      return "HTTP-request-header-section-size";
    },
    ErrorCode.HttpRequestHeaderSize => {
      return "HTTP-request-header-size";
    },
    ErrorCode.HttpRequestTrailerSectionSize => {
      return "HTTP-request-trailer-section-size";
    },
    _ => {
      return __name_response(c);
    }
  }
  return "";
}

function __name_response(c: ErrorCode): string {
  match (c) {
    ErrorCode.HttpRequestTrailerSize => {
      return "HTTP-request-trailer-size";
    },
    ErrorCode.HttpResponseIncomplete => {
      return "HTTP-response-incomplete";
    },
    ErrorCode.HttpResponseHeaderSectionSize => {
      return "HTTP-response-header-section-size";
    },
    ErrorCode.HttpResponseHeaderSize => {
      return "HTTP-response-header-size";
    },
    ErrorCode.HttpResponseBodySize => {
      return "HTTP-response-body-size";
    },
    ErrorCode.HttpResponseTrailerSectionSize => {
      return "HTTP-response-trailer-section-size";
    },
    ErrorCode.HttpResponseTrailerSize => {
      return "HTTP-response-trailer-size";
    },
    ErrorCode.HttpResponseTransferCoding => {
      return "HTTP-response-transfer-coding";
    },
    _ => {
      return __name_late(c);
    }
  }
  return "";
}

function __name_late(c: ErrorCode): string {
  match (c) {
    ErrorCode.HttpResponseContentCoding => {
      return "HTTP-response-content-coding";
    },
    ErrorCode.HttpResponseTimeout => {
      return "HTTP-response-timeout";
    },
    ErrorCode.HttpUpgradeFailed => {
      return "HTTP-upgrade-failed";
    },
    ErrorCode.HttpProtocolError => {
      return "HTTP-protocol-error";
    },
    ErrorCode.LoopDetected => {
      return "loop-detected";
    },
    ErrorCode.ConfigurationError => {
      return "configuration-error";
    },
    ErrorCode.InternalError => {
      return "internal-error";
    },
    ErrorCode.Unknown(n) => {
      return "error-code " + int.int_to_string(n);
    },
    _ => {
      return "";
    }
  }
  return "";
}
```

### `16 pub enum OutgoingError`

```fern
<<16 pub enum OutgoingError>>=
pub enum OutgoingError { Code(ErrorCode), Field(string), BodyPastCap, CutShort, Lost }
```

### `17 pub function (e: OutgoingError) message(): string`

```fern
<<17 pub function (e: OutgoingError) message(): string>>=
pub function (e: OutgoingError) message(): string {
  match (e) {
    Code(code) => {
      return "outgoing HTTP request failed: " + code.name();
    },
    Field(name) => {
      return "outgoing HTTP request has an invalid field: " + name;
    },
    BodyPastCap => {
      return "outgoing HTTP response body exceeds its limit";
    },
    CutShort => {
      return "outgoing HTTP response body ended early";
    },
    Lost => {
      return "outgoing HTTP response is unavailable";
    }
  }
  return "";
}

pub function (e: OutgoingError) to_string(): string {
  return e.message();
}
```

### `18 impl error.Error for OutgoingError`

```fern
<<18 impl error.Error for OutgoingError>>=
impl error.Error for OutgoingError {}

impl cmp.Display for OutgoingError {}
```

### `19 pub function outgoing(o: Outgoing): Result[HttpResponse, OutgoingError]`

```fern
<<19 pub function outgoing(o: Outgoing): Result[HttpResponse, OutgoingError]>>=
pub function outgoing(o: Outgoing): Result[HttpResponse, OutgoingError] {
  let req: i32 = build_request(o)?;
  let body: i32 = 0;
  match (request_body(req)) {
    Ok(b) => {
      body = b;
    },
    Err(e) => {
      request_drop(req);
      return Err(Lost);
    }
  }
  let fut: i32 = 0;
  match (outgoing_handle(req, 1, options_of(o))) {
    Ok(h) => {
      fut = h as i32;
    },
    Err(e) => {
      body_finish_out(body, None);
      return Err(Code(error_code((e & 255 as i64) as i32)));
    }
  }
  write_body(body, o.body);
  let resp: i32 = await_response(fut)?;
  return read_response(resp, o.body_cap);
}
```

### `20 function build_request(o: Outgoing): Result[i32, OutgoingError]`

```fern
<<20 function build_request(o: Outgoing): Result[i32, OutgoingError]>>=
function build_request(o: Outgoing): Result[i32, OutgoingError] {
  let fields: i32 = fields_new();
  let i: i32 = 0;
  while (i < o.headers.names.len()) {
    match (fields_append(fields, o.headers.names[i], o.headers.values[i])) {
      Ok(v) => {},
      Err(e) => {
        fields_drop(fields);
        return Err(Field(o.headers.names[i]));
      }
    }
    i = i + 1;
  }
  let req: i32 = request_new(fields);
  let method: i32 = method_index(o.method);
  let other: string = "";
  if (method == 9) {
    other = o.method;
  }
  request_set_method(req, method, other);
  let scheme: i32 = 0;
  if (o.tls) {
    scheme = 1;
  }
  request_set_scheme(req, 1, scheme, "");
  request_set_authority(req, 1, o.authority);
  request_set_path(req, 1, o.target);
  return Ok(req);
}

function method_index(method: string): i32 {
  let names: string[] = ["GET", "HEAD", "POST", "PUT", "DELETE", "CONNECT", "OPTIONS", "TRACE", "PATCH"];
  let i: i32 = 0;
  while (i < names.len()) {
    if (names[i] == method) {
      return i;
    }
    i = i + 1;
  }
  return 9;
}

function options_of(o: Outgoing): i32 {
  let opts: i32 = options_new();
  options_set_connect_timeout(opts, 1, o.connect.as_nanos());
  options_set_first_byte_timeout(opts, 1, o.inactivity.as_nanos());
  options_set_between_bytes_timeout(opts, 1, o.inactivity.as_nanos());
  return opts;
}

function await_response(fut: i32): Result[i32, OutgoingError] {
  let ready: i32 = future_subscribe(fut);
  pollable_block(ready);
  pollable_drop(ready);
  let got: FutureGot = future_get(fut);
  future_drop(fut);
  if ((got.w0 & 255) == 0 || (got.w2 & 255) != 0) {
    return Err(Lost);
  }
  if ((got.w4 & 255) != 0) {
    return Err(Code(error_code(got.w6 & 255)));
  }
  return Ok(got.w6);
}

function read_response(resp: i32, cap: i32): Result[HttpResponse, OutgoingError] {
  let status: i32 = response_status(resp);
  let headers: HeaderMap = headers_of(response_headers(resp));
  let data: u8[] = [];
  let how: i32 = READ_WHOLE;
  match (response_consume(resp)) {
    Ok(body) => {
      let (read, ended) = drain(body, Some(cap));
      data = read;
      how = ended;
    },
    Err(e) => {}
  }
  response_drop(resp);
  if (how == READ_PAST_CAP) {
    return Err(BodyPastCap);
  }
  if (how == READ_FAILED) {
    return Err(CutShort);
  }
  return Ok(HttpResponse { status: status, headers: headers, body: BodyBytes(data), trailers: HeaderMap { names: [], values: [] }, background: None });
}
```
