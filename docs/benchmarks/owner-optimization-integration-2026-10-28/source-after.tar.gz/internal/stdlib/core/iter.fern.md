# Value iterators and lazy adapters

This module provides value iterators and lazy adapters.

## Model

`Iterator.next` returns an element and the next iterator state. `None` marks the end of the sequence. Adapters retain the source iterator as a value.

## Contracts

`map`, `filter`, and `take` defer their work until the consumer requests an element. Consumers such as `fold` and `collect` advance the iterator.

## Executable example

```fern test name=core-iter-example
import "core/iter";

function main(): i32 {
  let values: i32[] = iter.range(0, 4).collect();
  if (values.len() != 4 || values[3] != 3) { return 1; }
  return 0;
}
```

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub trait Iterator[T]>>

<<4 impl[I: Iterator[T], T] Iterator[T] for Filtered[I, T]>>

<<5 pub function range(lo: i32, hi: i32): Range>>

<<6 impl Iterator[i32] for Range>>

<<7 pub function of[T](xs: T[]): ArrayIter[T]>>

<<8 impl[T] Iterator[T] for ArrayIter[T]>>

<<9 pub function sum[T: num.Add + num.Zero, I: Iterator[T]](it: I): T>>

<<10 pub function last[T, I: Iterator[T]](it: I): Option[T]>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module provides value iterators and lazy adapters.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "core/cmp";
import "std/num";
```

### `3 pub trait Iterator[T]`

```fern
<<3 pub trait Iterator[T]>>=
pub trait Iterator[T] {
  function next(self: Self): Option[(T, Self)];

  function map[U](self: Self, f: (T) => U): Mapped[Self, T, U] {
    return Mapped { it: self, f: f };
  }
  function filter(self: Self, keep: (T) => boolean): Filtered[Self, T] {
    return Filtered { it: self, keep: keep };
  }
  function take(self: Self, n: i32): Taken[Self, T] {
    return Taken[Self, T] { it: self, left: n };
  }
  function skip(self: Self, n: i32): Skipped[Self, T] {
    return Skipped[Self, T] { it: self, left: n };
  }
  function flat_map[U](self: Self, f: (T) => U[]): FlatMapped[Self, T, U] {
    let none: U[] = [];
    return FlatMapped[Self, T, U] { it: self, f: f, ys: none, at: 0 };
  }
  function enumerate(self: Self): Enumerated[Self, T] {
    return Enumerated[Self, T] { it: self, at: 0 };
  }
  function zip[U, J: Iterator[U]](self: Self, other: J): Zipped[Self, T, J, U] {
    return Zipped[Self, T, J, U] { a: self, b: other };
  }

  function fold[A](self: Self, init: A, f: (A, T) => A): A {
    let acc: A = init;
    let cur: Self = self;
    let go: boolean = true;
    while (go) {
      match (cur.next()) {
        Some(t) => {
          acc = f(acc, t.0);
          cur = t.1;
        },
        None => {
          go = false;
        }
      }
    }
    return acc;
  }
  function len(self: Self): i32 {
    return self.fold(0, (n: i32, v: T): i32 => n + 1);
  }
  function collect(self: Self): T[] {
    let out: T[] = [];
    let cur: Self = self;
    let go: boolean = true;
    while (go) {
      match (cur.next()) {
        Some(t) => {
          out = out.append(t.0);
          cur = t.1;
        },
        None => {
          go = false;
        }
      }
    }
    return out;
  }
  function find(self: Self, pred: (T) => boolean): Option[T] {
    let cur: Self = self;
    let go: boolean = true;
    while (go) {
      match (cur.next()) {
        Some(t) => {
          if (pred(t.0)) {
            return Some(t.0);
          }
          cur = t.1;
        },
        None => {
          go = false;
        }
      }
    }
    return None;
  }
  function any(self: Self, pred: (T) => boolean): boolean {
    match (self.find(pred)) {
      Some(_) => {
        return true;
      },
      None => {
        return false;
      }
    }
  }
  function all(self: Self, pred: (T) => boolean): boolean {
    match (self.find((v: T): boolean => !pred(v))) {
      Some(_) => {
        return false;
      },
      None => {
        return true;
      }
    }
  }
}

pub struct Mapped[I, T, U] { it: I, f: (T) => U }

impl[I: Iterator[T], T, U] Iterator[U] for Mapped[I, T, U] {
  function next(self: Mapped[I, T, U]): Option[(U, Mapped[I, T, U])] {
    match (self.it.next()) {
      Some(t) => {
        return Some((self.f(t.0), Mapped { it: t.1, f: self.f }));
      },
      None => {
        return None;
      }
    }
  }
}

pub struct Filtered[I, T] { it: I, keep: (T) => boolean }
```

### `4 impl[I: Iterator[T], T] Iterator[T] for Filtered[I, T]`

```fern
<<4 impl[I: Iterator[T], T] Iterator[T] for Filtered[I, T]>>=
impl[I: Iterator[T], T] Iterator[T] for Filtered[I, T] {
  function next(self: Filtered[I, T]): Option[(T, Filtered[I, T])] {
    let cur: I = self.it;
    while (true) {
      match (cur.next()) {
        Some(t) => {
          if (self.keep(t.0)) {
            return Some((t.0, Filtered { it: t.1, keep: self.keep }));
          }
          cur = t.1;
        },
        None => {
          return None;
        }
      }
    }
    return None;
  }
}

pub struct Taken[I, T] { it: I, left: i32 }

impl[I: Iterator[T], T] Iterator[T] for Taken[I, T] {
  function next(self: Taken[I, T]): Option[(T, Taken[I, T])] {
    if (self.left <= 0) {
      return None;
    }
    match (self.it.next()) {
      Some(t) => {
        return Some((t.0, Taken[I, T] { it: t.1, left: self.left - 1 }));
      },
      None => {
        return None;
      }
    }
  }
}

pub struct Skipped[I, T] { it: I, left: i32 }

impl[I: Iterator[T], T] Iterator[T] for Skipped[I, T] {
  function next(self: Skipped[I, T]): Option[(T, Skipped[I, T])] {
    let cur: I = self.it;
    let left: i32 = self.left;
    while (true) {
      match (cur.next()) {
        Some(t) => {
          if (left <= 0) {
            return Some((t.0, Skipped[I, T] { it: t.1, left: 0 }));
          }
          left = left - 1;
          cur = t.1;
        },
        None => {
          return None;
        }
      }
    }
    return None;
  }
}

pub struct FlatMapped[I, T, U] { it: I, f: (T) => U[], ys: U[], at: i32 }

impl[I: Iterator[T], T, U] Iterator[U] for FlatMapped[I, T, U] {
  function next(self: FlatMapped[I, T, U]): Option[(U, FlatMapped[I, T, U])] {
    let cur: I = self.it;
    let ys: U[] = self.ys;
    let at: i32 = self.at;
    while (at >= ys.len()) {
      match (cur.next()) {
        Some(t) => {
          ys = self.f(t.0);
          at = 0;
          cur = t.1;
        },
        None => {
          return None;
        }
      }
    }
    return Some((ys[at], FlatMapped[I, T, U] { it: cur, f: self.f, ys: ys, at: at + 1 }));
  }
}

pub struct Enumerated[I, T] { it: I, at: i32 }

impl[I: Iterator[T], T] Iterator[(i32, T)] for Enumerated[I, T] {
  function next(self: Enumerated[I, T]): Option[((i32, T), Enumerated[I, T])] {
    match (self.it.next()) {
      Some(t) => {
        return Some(((self.at, t.0), Enumerated[I, T] { it: t.1, at: self.at + 1 }));
      },
      None => {
        return None;
      }
    }
  }
}

pub struct Zipped[I, T, J, U] { a: I, b: J }

impl[I: Iterator[T], T, J: Iterator[U], U] Iterator[(T, U)] for Zipped[I, T, J, U] {
  function next(self: Zipped[I, T, J, U]): Option[((T, U), Zipped[I, T, J, U])] {
    match (self.a.next()) {
      Some(x) => {
        match (self.b.next()) {
          Some(y) => {
            return Some(((x.0, y.0), Zipped[I, T, J, U] { a: x.1, b: y.1 }));
          },
          None => {
            return None;
          }
        }
      },
      None => {
        return None;
      }
    }
  }
}

pub struct Range { lo: i32, hi: i32 }
```

### `5 pub function range(lo: i32, hi: i32): Range`

```fern
<<5 pub function range(lo: i32, hi: i32): Range>>=
pub function range(lo: i32, hi: i32): Range {
  return Range { lo: lo, hi: hi };
}

pub function range_incl(lo: i32, hi: i32): Range {
  return Range { lo: lo, hi: hi + 1 };
}
```

### `6 impl Iterator[i32] for Range`

```fern
<<6 impl Iterator[i32] for Range>>=
impl Iterator[i32] for Range {
  function next(self: Range): Option[(i32, Range)] {
    if (self.lo >= self.hi) {
      return None;
    }
    return Some((self.lo, Range { lo: self.lo + 1, hi: self.hi }));
  }
}

pub struct ArrayIter[T] { xs: T[], idx: i32 }
```

### `7 pub function of[T](xs: T[]): ArrayIter[T]`

```fern
<<7 pub function of[T](xs: T[]): ArrayIter[T]>>=
pub function of[T](xs: T[]): ArrayIter[T] {
  return ArrayIter { xs: xs, idx: 0 };
}
```

### `8 impl[T] Iterator[T] for ArrayIter[T]`

```fern
<<8 impl[T] Iterator[T] for ArrayIter[T]>>=
impl[T] Iterator[T] for ArrayIter[T] {
  function next(self: ArrayIter[T]): Option[(T, ArrayIter[T])] {
    if (self.idx >= self.xs.len()) {
      return None;
    }
    return Some((self.xs[self.idx], ArrayIter { xs: self.xs, idx: self.idx + 1 }));
  }
}
```

### `9 pub function sum[T: num.Add + num.Zero, I: Iterator[T]](it: I): T`

```fern
<<9 pub function sum[T: num.Add + num.Zero, I: Iterator[T]](it: I): T>>=
pub function sum[T: num.Add + num.Zero, I: Iterator[T]](it: I): T {
  let total: T = T.zero();
  let cur = it;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        total = total.add(t.0);
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return total;
}

pub function position[T, I: Iterator[T]](it: I, pred: (T) => boolean): Option[i32] {
  let cur = it;
  let i = 0;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        if (pred(t.0)) {
          return Some(i);
        }
        i = i + 1;
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return None;
}

pub function count_where[T, I: Iterator[T]](it: I, pred: (T) => boolean): i32 {
  let cur = it;
  let n = 0;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        if (pred(t.0)) {
          n = n + 1;
        }
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return n;
}

pub function nth[T, I: Iterator[T]](it: I, n: i32): Option[T] {
  let cur = it;
  let k = n;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        if (k == 0) {
          return Some(t.0);
        }
        k = k - 1;
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return None;
}

pub function min[T: cmp.Ord, I: Iterator[T]](it: I): Option[T] {
  match (it.next()) {
    Some(first) => {
      let best: T = first.0;
      let cur = first.1;
      let go = true;
      while (go) {
        match (cur.next()) {
          Some(t) => {
            if (t.0.cmp(best) < 0) {
              best = t.0;
            }
            cur = t.1;
          },
          None => {
            go = false;
          }
        }
      }
      return Some(best);
    },
    None => {
      return None;
    }
  }
}

pub function max[T: cmp.Ord, I: Iterator[T]](it: I): Option[T] {
  match (it.next()) {
    Some(first) => {
      let best: T = first.0;
      let cur = first.1;
      let go = true;
      while (go) {
        match (cur.next()) {
          Some(t) => {
            if (t.0.cmp(best) > 0) {
              best = t.0;
            }
            cur = t.1;
          },
          None => {
            go = false;
          }
        }
      }
      return Some(best);
    },
    None => {
      return None;
    }
  }
}
```

### `10 pub function last[T, I: Iterator[T]](it: I): Option[T]`

```fern
<<10 pub function last[T, I: Iterator[T]](it: I): Option[T]>>=
pub function last[T, I: Iterator[T]](it: I): Option[T] {
  let cur = it;
  let acc: Option[T] = None;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        acc = Some(t.0);
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return acc;
}

pub function product[T: num.Mul + num.One, I: Iterator[T]](it: I): T {
  let p: T = T.one();
  let cur = it;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        p = p.mul(t.0);
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return p;
}

pub function index_of[T: cmp.Eq, I: Iterator[T]](it: I, target: T): Option[i32] {
  let cur = it;
  let i = 0;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        if (t.0.eq(target)) {
          return Some(i);
        }
        i = i + 1;
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return None;
}

pub function contains[T: cmp.Eq, I: Iterator[T]](it: I, target: T): boolean {
  let cur = it;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        if (t.0.eq(target)) {
          return true;
        }
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return false;
}

pub function count[T: cmp.Eq, I: Iterator[T]](it: I, target: T): i32 {
  let n = 0;
  let cur = it;
  let go = true;
  while (go) {
    match (cur.next()) {
      Some(t) => {
        if (t.0.eq(target)) {
          n = n + 1;
        }
        cur = t.1;
      },
      None => {
        go = false;
      }
    }
  }
  return n;
}
```
