# Floating-point text kernels

This internal module provides the decimal conversion kernels shared by primitive display and public float methods.

## Contracts

Dragonbox tables support shortest round-trip output. Fixed precision retains its separate rounding contract. Cached-power helpers belong to the library package.

## Executable example

```fern test name=core-f64-text-example
import "std/f64";
function main(): i32 { let n: f64 = 1.25; if (n.to_string() != "1.25") { return 1; } return 0; }
```

## Module assembly

The root chunk preserves declaration order.

```fern
<<*>>=
<<module introduction>>

<<1 function __float_int_part(n: f64): string>>

<<2 generated Dragonbox tables>>

<<3 function _db_log10_pow2(e: i32): i32>>

<<4 function _db_log2_pow10(e: i32): i32>>

<<5 function _db_log10_pow2_m43(e: i32): i32>>

<<6 pub(package) function _db_mul_hi(x: u64, y: u64): u64>>

<<7 function _db_mul192_lo(x: u64, chi: u64, clo: u64): u64>>

<<8 function _db_mul192_hi(x: u64, chi: u64, clo: u64): u64>>

<<9 function _db_parity64(two_f: u64, chi: u64, clo: u64, beta: i32): i32>>

<<10 function _db_rtz(sig: u64, exp: i32): (i64, i32)>>

<<11 function __db_shortest64(n: f64): (i64, i32)>>

<<12 function __db_shorter64(be: i32): (i64, i32)>>

<<13 function __db_shortest32(n: f32): (i64, i32)>>

<<14 function _db_parity32(two_f: u64, c: u64, beta: i32): i32>>

<<15 function __db_shorter32(be: i32): (i64, i32)>>

<<16 function __float_fmt_sci(sig: string, msd: i32): string>>

<<17 function __float_render(out: string, sig: i64, exp: i32): string>>

<<18 pub(package) function __primitive_f64_to_string(n: f64): string>>

<<19 pub(package) function __primitive_f32_to_string(n: f32): string>>

<<20 pub(package) function shortest_digits64(n: f64): (i64, i32)>>

<<21 pub(package) function shortest_digits32(n: f32): (i64, i32)>>

<<22 pub(package) function pow10_hi(k: i32): u64>>

<<23 pub(package) function pow10_lo(k: i32): u64>>

<<24 pub(package) function pow10_log2(k: i32): i32>>

<<25 function __db_trim(d: (i64, i32)): (i64, i32)>>

<<26 pub(package) function fixed(n: f64, prec: i32): string>>
```

### `module introduction`

```fern
<<module introduction>>=
// Shared floating-point formatting kernels.
import "core/int";

// __float_int_part renders a non-negative, integer-valued f64 that
// is too large for the i64 range (>= 2^63) as decimal digits,
// working entirely in floating point so no value ever crosses the
// trapping/non-portable `as i64` boundary. Digits are peeled off
// least-significant-first via `floor(n / 10)`; the per-step
// remainder is nominally 0..9 but `n / 10` and `* 10` each round,
// so for very large magnitudes it can land just outside that range
// — clamp before indexing the digit table. The printed digits
// reflect the f64's stored (rounded) value — exact for round
// magnitudes like 1e20, approximate where the double itself can't
// represent the integer exactly, which is inherent to f64 and not
// something this formatter can recover.
```

### `1 function __float_int_part(n: f64): string`

```fern
<<1 function __float_int_part(n: f64): string>>=
function __float_int_part(n: f64): string {
  if (n < 1.0) {
    return "0";
  }
  let digits: string = "0123456789";
  // Two-pass exact-size buffer (#4379). Digits peel off least-significant
  // first, so the old `out = digits[d] + out` prepended each one — recopying
  // the whole growing string every step, O(digits²) (up to ~309 digits for
  // the largest f64 magnitudes). Instead: a counting pass sizes the result,
  // then a fill pass writes each digit straight into its final slot from the
  // right. Byte-for-byte identical output.
  let count: i32 = 0;
  let m: f64 = n;
  while (m >= 1.0) {
    m = __floor_f64(m / 10.0);
    count = count + 1;
  }
  let buf: u8[] = __alloc_u8(count);
  let pos: i32 = count - 1;
  while (n >= 1.0) {
    let q: f64 = __floor_f64(n / 10.0);
    let d: i32 = (n - q * 10.0) as i32;
    if (d < 0) {
      d = 0;
    }
    if (d > 9) {
      d = 9;
    }
    buf = buf.with(pos, digits[d] as u8);
    pos = pos - 1;
    n = q;
  }
  return string_from_bytes_unchecked(buf);
}

// Shortest round-trip float formatting via DRAGONBOX (Junekey Jeon's
// refinement of Schubfach). For a finite non-zero float it produces the
// unique shortest decimal that parses back to exactly that float, with
// correct round-to-nearest-even rounding and no fallback path.
//
// Shape: decode the IEEE-754 fields, look up a 128-bit (f64) / 64-bit (f32)
// normalised power of ten from a static table, and take one wide multiply.
// That replaces the exact-bignum digit generation this module used to run,
// which multiplied a growing bignum once per binary exponent — 1074 limb
// passes for a subnormal, plus up to 34 bignum comparisons to pick the digit
// count, allocating an array at every step. Dragonbox is a fixed amount of
// work per call and allocates nothing.
//
// Structure follows the reference implementation (jk-jeon/dragonbox) with the
// "shortest, nearest-to-even" policy, which is the same contract Go's strconv
// shortest formatting has. Names mirror the reference so the two can be read
// side by side. The cache tables below are generated and checked against the
// upstream table by cmd/floattablegen.
```

### `2 generated Dragonbox tables`

```fern
<<2 generated Dragonbox tables>>=
// BEGIN GENERATED DRAGONBOX TABLES (cmd/floattablegen) — do not edit by hand.
// The f64 cache covers powers of ten from -292 through 326 with 619 entries.
// Each entry stores the high 64 bits before the low 64 bits.
const DB_CACHE64: u64[] = [
  0xff77b1fcbebcdc4fu64, 0x25e8e89c13bb0f7bu64,
  0x9faacf3df73609b1u64, 0x77b191618c54e9adu64,
  0xc795830d75038c1du64, 0xd59df5b9ef6a2418u64,
  0xf97ae3d0d2446f25u64, 0x4b0573286b44ad1eu64,
  0x9becce62836ac577u64, 0x4ee367f9430aec33u64,
  0xc2e801fb244576d5u64, 0x229c41f793cda740u64,
  0xf3a20279ed56d48au64, 0x6b43527578c11110u64,
  0x9845418c345644d6u64, 0x830a13896b78aaaau64,
  0xbe5691ef416bd60cu64, 0x23cc986bc656d554u64,
  0xedec366b11c6cb8fu64, 0x2cbfbe86b7ec8aa9u64,
  0x94b3a202eb1c3f39u64, 0x7bf7d71432f3d6aau64,
  0xb9e08a83a5e34f07u64, 0xdaf5ccd93fb0cc54u64,
  0xe858ad248f5c22c9u64, 0xd1b3400f8f9cff69u64,
  0x91376c36d99995beu64, 0x23100809b9c21fa2u64,
  0xb58547448ffffb2du64, 0xabd40a0c2832a78bu64,
  0xe2e69915b3fff9f9u64, 0x16c90c8f323f516du64,
  0x8dd01fad907ffc3bu64, 0xae3da7d97f6792e4u64,
  0xb1442798f49ffb4au64, 0x99cd11cfdf41779du64,
  0xdd95317f31c7fa1du64, 0x40405643d711d584u64,
  0x8a7d3eef7f1cfc52u64, 0x482835ea666b2573u64,
  0xad1c8eab5ee43b66u64, 0xda3243650005eed0u64,
  0xd863b256369d4a40u64, 0x90bed43e40076a83u64,
  0x873e4f75e2224e68u64, 0x5a7744a6e804a292u64,
  0xa90de3535aaae202u64, 0x711515d0a205cb37u64,
  0xd3515c2831559a83u64, 0x0d5a5b44ca873e04u64,
  0x8412d9991ed58091u64, 0xe858790afe9486c3u64,
  0xa5178fff668ae0b6u64, 0x626e974dbe39a873u64,
  0xce5d73ff402d98e3u64, 0xfb0a3d212dc81290u64,
  0x80fa687f881c7f8eu64, 0x7ce66634bc9d0b9au64,
  0xa139029f6a239f72u64, 0x1c1fffc1ebc44e81u64,
  0xc987434744ac874eu64, 0xa327ffb266b56221u64,
  0xfbe9141915d7a922u64, 0x4bf1ff9f0062baa9u64,
  0x9d71ac8fada6c9b5u64, 0x6f773fc3603db4aau64,
  0xc4ce17b399107c22u64, 0xcb550fb4384d21d4u64,
  0xf6019da07f549b2bu64, 0x7e2a53a146606a49u64,
  0x99c102844f94e0fbu64, 0x2eda7444cbfc426eu64,
  0xc0314325637a1939u64, 0xfa911155fefb5309u64,
  0xf03d93eebc589f88u64, 0x793555ab7eba27cbu64,
  0x96267c7535b763b5u64, 0x4bc1558b2f3458dfu64,
  0xbbb01b9283253ca2u64, 0x9eb1aaedfb016f17u64,
  0xea9c227723ee8bcbu64, 0x465e15a979c1caddu64,
  0x92a1958a7675175fu64, 0x0bfacd89ec191ecau64,
  0xb749faed14125d36u64, 0xcef980ec671f667cu64,
  0xe51c79a85916f484u64, 0x82b7e12780e7401bu64,
  0x8f31cc0937ae58d2u64, 0xd1b2ecb8b0908811u64,
  0xb2fe3f0b8599ef07u64, 0x861fa7e6dcb4aa16u64,
  0xdfbdcece67006ac9u64, 0x67a791e093e1d49bu64,
  0x8bd6a141006042bdu64, 0xe0c8bb2c5c6d24e1u64,
  0xaecc49914078536du64, 0x58fae9f773886e19u64,
  0xda7f5bf590966848u64, 0xaf39a475506a899fu64,
  0x888f99797a5e012du64, 0x6d8406c952429604u64,
  0xaab37fd7d8f58178u64, 0xc8e5087ba6d33b84u64,
  0xd5605fcdcf32e1d6u64, 0xfb1e4a9a90880a65u64,
  0x855c3be0a17fcd26u64, 0x5cf2eea09a550680u64,
  0xa6b34ad8c9dfc06fu64, 0xf42faa48c0ea481fu64,
  0xd0601d8efc57b08bu64, 0xf13b94daf124da27u64,
  0x823c12795db6ce57u64, 0x76c53d08d6b70859u64,
  0xa2cb1717b52481edu64, 0x54768c4b0c64ca6fu64,
  0xcb7ddcdda26da268u64, 0xa9942f5dcf7dfd0au64,
  0xfe5d54150b090b02u64, 0xd3f93b35435d7c4du64,
  0x9efa548d26e5a6e1u64, 0xc47bc5014a1a6db0u64,
  0xc6b8e9b0709f109au64, 0x359ab6419ca1091cu64,
  0xf867241c8cc6d4c0u64, 0xc30163d203c94b63u64,
  0x9b407691d7fc44f8u64, 0x79e0de63425dcf1eu64,
  0xc21094364dfb5636u64, 0x985915fc12f542e5u64,
  0xf294b943e17a2bc4u64, 0x3e6f5b7b17b2939eu64,
  0x979cf3ca6cec5b5au64, 0xa705992ceecf9c43u64,
  0xbd8430bd08277231u64, 0x50c6ff782a838354u64,
  0xece53cec4a314ebdu64, 0xa4f8bf5635246429u64,
  0x940f4613ae5ed136u64, 0x871b7795e136be9au64,
  0xb913179899f68584u64, 0x28e2557b59846e40u64,
  0xe757dd7ec07426e5u64, 0x331aeada2fe589d0u64,
  0x9096ea6f3848984fu64, 0x3ff0d2c85def7622u64,
  0xb4bca50b065abe63u64, 0x0fed077a756b53aau64,
  0xe1ebce4dc7f16dfbu64, 0xd3e8495912c62895u64,
  0x8d3360f09cf6e4bdu64, 0x64712dd7abbbd95du64,
  0xb080392cc4349decu64, 0xbd8d794d96aacfb4u64,
  0xdca04777f541c567u64, 0xecf0d7a0fc5583a1u64,
  0x89e42caaf9491b60u64, 0xf41686c49db57245u64,
  0xac5d37d5b79b6239u64, 0x311c2875c522ced6u64,
  0xd77485cb25823ac7u64, 0x7d633293366b828cu64,
  0x86a8d39ef77164bcu64, 0xae5dff9c02033198u64,
  0xa8530886b54dbdebu64, 0xd9f57f830283fdfdu64,
  0xd267caa862a12d66u64, 0xd072df63c324fd7cu64,
  0x8380dea93da4bc60u64, 0x4247cb9e59f71e6eu64,
  0xa46116538d0deb78u64, 0x52d9be85f074e609u64,
  0xcd795be870516656u64, 0x67902e276c921f8cu64,
  0x806bd9714632dff6u64, 0x00ba1cd8a3db53b7u64,
  0xa086cfcd97bf97f3u64, 0x80e8a40eccd228a5u64,
  0xc8a883c0fdaf7df0u64, 0x6122cd128006b2ceu64,
  0xfad2a4b13d1b5d6cu64, 0x796b805720085f82u64,
  0x9cc3a6eec6311a63u64, 0xcbe3303674053bb1u64,
  0xc3f490aa77bd60fcu64, 0xbedbfc4411068a9du64,
  0xf4f1b4d515acb93bu64, 0xee92fb5515482d45u64,
  0x991711052d8bf3c5u64, 0x751bdd152d4d1c4bu64,
  0xbf5cd54678eef0b6u64, 0xd262d45a78a0635eu64,
  0xef340a98172aace4u64, 0x86fb897116c87c35u64,
  0x9580869f0e7aac0eu64, 0xd45d35e6ae3d4da1u64,
  0xbae0a846d2195712u64, 0x8974836059cca10au64,
  0xe998d258869facd7u64, 0x2bd1a438703fc94cu64,
  0x91ff83775423cc06u64, 0x7b6306a34627ddd0u64,
  0xb67f6455292cbf08u64, 0x1a3bc84c17b1d543u64,
  0xe41f3d6a7377eecau64, 0x20caba5f1d9e4a94u64,
  0x8e938662882af53eu64, 0x547eb47b7282ee9du64,
  0xb23867fb2a35b28du64, 0xe99e619a4f23aa44u64,
  0xdec681f9f4c31f31u64, 0x6405fa00e2ec94d5u64,
  0x8b3c113c38f9f37eu64, 0xde83bc408dd3dd05u64,
  0xae0b158b4738705eu64, 0x9624ab50b148d446u64,
  0xd98ddaee19068c76u64, 0x3badd624dd9b0958u64,
  0x87f8a8d4cfa417c9u64, 0xe54ca5d70a80e5d7u64,
  0xa9f6d30a038d1dbcu64, 0x5e9fcf4ccd211f4du64,
  0xd47487cc8470652bu64, 0x7647c32000696720u64,
  0x84c8d4dfd2c63f3bu64, 0x29ecd9f40041e074u64,
  0xa5fb0a17c777cf09u64, 0xf468107100525891u64,
  0xcf79cc9db955c2ccu64, 0x7182148d4066eeb5u64,
  0x81ac1fe293d599bfu64, 0xc6f14cd848405531u64,
  0xa21727db38cb002fu64, 0xb8ada00e5a506a7du64,
  0xca9cf1d206fdc03bu64, 0xa6d90811f0e4851du64,
  0xfd442e4688bd304au64, 0x908f4a166d1da664u64,
  0x9e4a9cec15763e2eu64, 0x9a598e4e043287ffu64,
  0xc5dd44271ad3cdbau64, 0x40eff1e1853f29feu64,
  0xf7549530e188c128u64, 0xd12bee59e68ef47du64,
  0x9a94dd3e8cf578b9u64, 0x82bb74f8301958cfu64,
  0xc13a148e3032d6e7u64, 0xe36a52363c1faf02u64,
  0xf18899b1bc3f8ca1u64, 0xdc44e6c3cb279ac2u64,
  0x96f5600f15a7b7e5u64, 0x29ab103a5ef8c0bau64,
  0xbcb2b812db11a5deu64, 0x7415d448f6b6f0e8u64,
  0xebdf661791d60f56u64, 0x111b495b3464ad22u64,
  0x936b9fcebb25c995u64, 0xcab10dd900beec35u64,
  0xb84687c269ef3bfbu64, 0x3d5d514f40eea743u64,
  0xe65829b3046b0afau64, 0x0cb4a5a3112a5113u64,
  0x8ff71a0fe2c2e6dcu64, 0x47f0e785eaba72acu64,
  0xb3f4e093db73a093u64, 0x59ed216765690f57u64,
  0xe0f218b8d25088b8u64, 0x306869c13ec3532du64,
  0x8c974f7383725573u64, 0x1e414218c73a13fcu64,
  0xafbd2350644eeacfu64, 0xe5d1929ef90898fbu64,
  0xdbac6c247d62a583u64, 0xdf45f746b74abf3au64,
  0x894bc396ce5da772u64, 0x6b8bba8c328eb784u64,
  0xab9eb47c81f5114fu64, 0x066ea92f3f326565u64,
  0xd686619ba27255a2u64, 0xc80a537b0efefebeu64,
  0x8613fd0145877585u64, 0xbd06742ce95f5f37u64,
  0xa798fc4196e952e7u64, 0x2c48113823b73705u64,
  0xd17f3b51fca3a7a0u64, 0xf75a15862ca504c6u64,
  0x82ef85133de648c4u64, 0x9a984d73dbe722fcu64,
  0xa3ab66580d5fdaf5u64, 0xc13e60d0d2e0ebbbu64,
  0xcc963fee10b7d1b3u64, 0x318df905079926a9u64,
  0xffbbcfe994e5c61fu64, 0xfdf17746497f7053u64,
  0x9fd561f1fd0f9bd3u64, 0xfeb6ea8bedefa634u64,
  0xc7caba6e7c5382c8u64, 0xfe64a52ee96b8fc1u64,
  0xf9bd690a1b68637bu64, 0x3dfdce7aa3c673b1u64,
  0x9c1661a651213e2du64, 0x06bea10ca65c084fu64,
  0xc31bfa0fe5698db8u64, 0x486e494fcff30a63u64,
  0xf3e2f893dec3f126u64, 0x5a89dba3c3efccfbu64,
  0x986ddb5c6b3a76b7u64, 0xf89629465a75e01du64,
  0xbe89523386091465u64, 0xf6bbb397f1135824u64,
  0xee2ba6c0678b597fu64, 0x746aa07ded582e2du64,
  0x94db483840b717efu64, 0xa8c2a44eb4571cddu64,
  0xba121a4650e4ddebu64, 0x92f34d62616ce414u64,
  0xe896a0d7e51e1566u64, 0x77b020baf9c81d18u64,
  0x915e2486ef32cd60u64, 0x0ace1474dc1d122fu64,
  0xb5b5ada8aaff80b8u64, 0x0d819992132456bbu64,
  0xe3231912d5bf60e6u64, 0x10e1fff697ed6c6au64,
  0x8df5efabc5979c8fu64, 0xca8d3ffa1ef463c2u64,
  0xb1736b96b6fd83b3u64, 0xbd308ff8a6b17cb3u64,
  0xddd0467c64bce4a0u64, 0xac7cb3f6d05ddbdfu64,
  0x8aa22c0dbef60ee4u64, 0x6bcdf07a423aa96cu64,
  0xad4ab7112eb3929du64, 0x86c16c98d2c953c7u64,
  0xd89d64d57a607744u64, 0xe871c7bf077ba8b8u64,
  0x87625f056c7c4a8bu64, 0x11471cd764ad4973u64,
  0xa93af6c6c79b5d2du64, 0xd598e40d3dd89bd0u64,
  0xd389b47879823479u64, 0x4aff1d108d4ec2c4u64,
  0x843610cb4bf160cbu64, 0xcedf722a585139bbu64,
  0xa54394fe1eedb8feu64, 0xc2974eb4ee658829u64,
  0xce947a3da6a9273eu64, 0x733d226229feea33u64,
  0x811ccc668829b887u64, 0x0806357d5a3f5260u64,
  0xa163ff802a3426a8u64, 0xca07c2dcb0cf26f8u64,
  0xc9bcff6034c13052u64, 0xfc89b393dd02f0b6u64,
  0xfc2c3f3841f17c67u64, 0xbbac2078d443ace3u64,
  0x9d9ba7832936edc0u64, 0xd54b944b84aa4c0eu64,
  0xc5029163f384a931u64, 0x0a9e795e65d4df12u64,
  0xf64335bcf065d37du64, 0x4d4617b5ff4a16d6u64,
  0x99ea0196163fa42eu64, 0x504bced1bf8e4e46u64,
  0xc06481fb9bcf8d39u64, 0xe45ec2862f71e1d7u64,
  0xf07da27a82c37088u64, 0x5d767327bb4e5a4du64,
  0x964e858c91ba2655u64, 0x3a6a07f8d510f870u64,
  0xbbe226efb628afeau64, 0x890489f70a55368cu64,
  0xeadab0aba3b2dbe5u64, 0x2b45ac74ccea842fu64,
  0x92c8ae6b464fc96fu64, 0x3b0b8bc90012929eu64,
  0xb77ada0617e3bbcbu64, 0x09ce6ebb40173745u64,
  0xe55990879ddcaabdu64, 0xcc420a6a101d0516u64,
  0x8f57fa54c2a9eab6u64, 0x9fa946824a12232eu64,
  0xb32df8e9f3546564u64, 0x47939822dc96abfau64,
  0xdff9772470297ebdu64, 0x59787e2b93bc56f8u64,
  0x8bfbea76c619ef36u64, 0x57eb4edb3c55b65bu64,
  0xaefae51477a06b03u64, 0xede622920b6b23f2u64,
  0xdab99e59958885c4u64, 0xe95fab368e45eceeu64,
  0x88b402f7fd75539bu64, 0x11dbcb0218ebb415u64,
  0xaae103b5fcd2a881u64, 0xd652bdc29f26a11au64,
  0xd59944a37c0752a2u64, 0x4be76d3346f04960u64,
  0x857fcae62d8493a5u64, 0x6f70a4400c562ddcu64,
  0xa6dfbd9fb8e5b88eu64, 0xcb4ccd500f6bb953u64,
  0xd097ad07a71f26b2u64, 0x7e2000a41346a7a8u64,
  0x825ecc24c873782fu64, 0x8ed400668c0c28c9u64,
  0xa2f67f2dfa90563bu64, 0x728900802f0f32fbu64,
  0xcbb41ef979346bcau64, 0x4f2b40a03ad2ffbau64,
  0xfea126b7d78186bcu64, 0xe2f610c84987bfa9u64,
  0x9f24b832e6b0f436u64, 0x0dd9ca7d2df4d7cau64,
  0xc6ede63fa05d3143u64, 0x91503d1c79720dbcu64,
  0xf8a95fcf88747d94u64, 0x75a44c6397ce912bu64,
  0x9b69dbe1b548ce7cu64, 0xc986afbe3ee11abbu64,
  0xc24452da229b021bu64, 0xfbe85badce996169u64,
  0xf2d56790ab41c2a2u64, 0xfae27299423fb9c4u64,
  0x97c560ba6b0919a5u64, 0xdccd879fc967d41bu64,
  0xbdb6b8e905cb600fu64, 0x5400e987bbc1c921u64,
  0xed246723473e3813u64, 0x290123e9aab23b69u64,
  0x9436c0760c86e30bu64, 0xf9a0b6720aaf6522u64,
  0xb94470938fa89bceu64, 0xf808e40e8d5b3e6au64,
  0xe7958cb87392c2c2u64, 0xb60b1d1230b20e05u64,
  0x90bd77f3483bb9b9u64, 0xb1c6f22b5e6f48c3u64,
  0xb4ecd5f01a4aa828u64, 0x1e38aeb6360b1af4u64,
  0xe2280b6c20dd5232u64, 0x25c6da63c38de1b1u64,
  0x8d590723948a535fu64, 0x579c487e5a38ad0fu64,
  0xb0af48ec79ace837u64, 0x2d835a9df0c6d852u64,
  0xdcdb1b2798182244u64, 0xf8e431456cf88e66u64,
  0x8a08f0f8bf0f156bu64, 0x1b8e9ecb641b5900u64,
  0xac8b2d36eed2dac5u64, 0xe272467e3d222f40u64,
  0xd7adf884aa879177u64, 0x5b0ed81dcc6abb10u64,
  0x86ccbb52ea94baeau64, 0x98e947129fc2b4eau64,
  0xa87fea27a539e9a5u64, 0x3f2398d747b36225u64,
  0xd29fe4b18e88640eu64, 0x8eec7f0d19a03aaeu64,
  0x83a3eeeef9153e89u64, 0x1953cf68300424adu64,
  0xa48ceaaab75a8e2bu64, 0x5fa8c3423c052dd8u64,
  0xcdb02555653131b6u64, 0x3792f412cb06794eu64,
  0x808e17555f3ebf11u64, 0xe2bbd88bbee40bd1u64,
  0xa0b19d2ab70e6ed6u64, 0x5b6aceaeae9d0ec5u64,
  0xc8de047564d20a8bu64, 0xf245825a5a445276u64,
  0xfb158592be068d2eu64, 0xeed6e2f0f0d56713u64,
  0x9ced737bb6c4183du64, 0x55464dd69685606cu64,
  0xc428d05aa4751e4cu64, 0xaa97e14c3c26b887u64,
  0xf53304714d9265dfu64, 0xd53dd99f4b3066a9u64,
  0x993fe2c6d07b7fabu64, 0xe546a8038efe402au64,
  0xbf8fdb78849a5f96u64, 0xde98520472bdd034u64,
  0xef73d256a5c0f77cu64, 0x963e66858f6d4441u64,
  0x95a8637627989aadu64, 0xdde7001379a44aa9u64,
  0xbb127c53b17ec159u64, 0x5560c018580d5d53u64,
  0xe9d71b689dde71afu64, 0xaab8f01e6e10b4a7u64,
  0x9226712162ab070du64, 0xcab3961304ca70e9u64,
  0xb6b00d69bb55c8d1u64, 0x3d607b97c5fd0d23u64,
  0xe45c10c42a2b3b05u64, 0x8cb89a7db77c506bu64,
  0x8eb98a7a9a5b04e3u64, 0x77f3608e92adb243u64,
  0xb267ed1940f1c61cu64, 0x55f038b237591ed4u64,
  0xdf01e85f912e37a3u64, 0x6b6c46dec52f6689u64,
  0x8b61313bbabce2c6u64, 0x2323ac4b3b3da016u64,
  0xae397d8aa96c1b77u64, 0xabec975e0a0d081bu64,
  0xd9c7dced53c72255u64, 0x96e7bd358c904a22u64,
  0x881cea14545c7575u64, 0x7e50d64177da2e55u64,
  0xaa242499697392d2u64, 0xdde50bd1d5d0b9eau64,
  0xd4ad2dbfc3d07787u64, 0x955e4ec64b44e865u64,
  0x84ec3c97da624ab4u64, 0xbd5af13bef0b113fu64,
  0xa6274bbdd0fadd61u64, 0xecb1ad8aeacdd58fu64,
  0xcfb11ead453994bau64, 0x67de18eda5814af3u64,
  0x81ceb32c4b43fcf4u64, 0x80eacf948770ced8u64,
  0xa2425ff75e14fc31u64, 0xa1258379a94d028eu64,
  0xcad2f7f5359a3b3eu64, 0x096ee45813a04331u64,
  0xfd87b5f28300ca0du64, 0x8bca9d6e188853fdu64,
  0x9e74d1b791e07e48u64, 0x775ea264cf55347eu64,
  0xc612062576589ddau64, 0x95364afe032a819eu64,
  0xf79687aed3eec551u64, 0x3a83ddbd83f52205u64,
  0x9abe14cd44753b52u64, 0xc4926a9672793543u64,
  0xc16d9a0095928a27u64, 0x75b7053c0f178294u64,
  0xf1c90080baf72cb1u64, 0x5324c68b12dd6339u64,
  0x971da05074da7beeu64, 0xd3f6fc16ebca5e04u64,
  0xbce5086492111aeau64, 0x88f4bb1ca6bcf585u64,
  0xec1e4a7db69561a5u64, 0x2b31e9e3d06c32e6u64,
  0x9392ee8e921d5d07u64, 0x3aff322e62439fd0u64,
  0xb877aa3236a4b449u64, 0x09befeb9fad487c3u64,
  0xe69594bec44de15bu64, 0x4c2ebe687989a9b4u64,
  0x901d7cf73ab0acd9u64, 0x0f9d37014bf60a11u64,
  0xb424dc35095cd80fu64, 0x538484c19ef38c95u64,
  0xe12e13424bb40e13u64, 0x2865a5f206b06fbau64,
  0x8cbccc096f5088cbu64, 0xf93f87b7442e45d4u64,
  0xafebff0bcb24aafeu64, 0xf78f69a51539d749u64,
  0xdbe6fecebdedd5beu64, 0xb573440e5a884d1cu64,
  0x89705f4136b4a597u64, 0x31680a88f8953031u64,
  0xabcc77118461cefcu64, 0xfdc20d2b36ba7c3eu64,
  0xd6bf94d5e57a42bcu64, 0x3d32907604691b4du64,
  0x8637bd05af6c69b5u64, 0xa63f9a49c2c1b110u64,
  0xa7c5ac471b478423u64, 0x0fcf80dc33721d54u64,
  0xd1b71758e219652bu64, 0xd3c36113404ea4a9u64,
  0x83126e978d4fdf3bu64, 0x645a1cac083126eau64,
  0xa3d70a3d70a3d70au64, 0x3d70a3d70a3d70a4u64,
  0xccccccccccccccccu64, 0xcccccccccccccccdu64,
  0x8000000000000000u64, 0x0000000000000000u64,
  0xa000000000000000u64, 0x0000000000000000u64,
  0xc800000000000000u64, 0x0000000000000000u64,
  0xfa00000000000000u64, 0x0000000000000000u64,
  0x9c40000000000000u64, 0x0000000000000000u64,
  0xc350000000000000u64, 0x0000000000000000u64,
  0xf424000000000000u64, 0x0000000000000000u64,
  0x9896800000000000u64, 0x0000000000000000u64,
  0xbebc200000000000u64, 0x0000000000000000u64,
  0xee6b280000000000u64, 0x0000000000000000u64,
  0x9502f90000000000u64, 0x0000000000000000u64,
  0xba43b74000000000u64, 0x0000000000000000u64,
  0xe8d4a51000000000u64, 0x0000000000000000u64,
  0x9184e72a00000000u64, 0x0000000000000000u64,
  0xb5e620f480000000u64, 0x0000000000000000u64,
  0xe35fa931a0000000u64, 0x0000000000000000u64,
  0x8e1bc9bf04000000u64, 0x0000000000000000u64,
  0xb1a2bc2ec5000000u64, 0x0000000000000000u64,
  0xde0b6b3a76400000u64, 0x0000000000000000u64,
  0x8ac7230489e80000u64, 0x0000000000000000u64,
  0xad78ebc5ac620000u64, 0x0000000000000000u64,
  0xd8d726b7177a8000u64, 0x0000000000000000u64,
  0x878678326eac9000u64, 0x0000000000000000u64,
  0xa968163f0a57b400u64, 0x0000000000000000u64,
  0xd3c21bcecceda100u64, 0x0000000000000000u64,
  0x84595161401484a0u64, 0x0000000000000000u64,
  0xa56fa5b99019a5c8u64, 0x0000000000000000u64,
  0xcecb8f27f4200f3au64, 0x0000000000000000u64,
  0x813f3978f8940984u64, 0x4000000000000000u64,
  0xa18f07d736b90be5u64, 0x5000000000000000u64,
  0xc9f2c9cd04674edeu64, 0xa400000000000000u64,
  0xfc6f7c4045812296u64, 0x4d00000000000000u64,
  0x9dc5ada82b70b59du64, 0xf020000000000000u64,
  0xc5371912364ce305u64, 0x6c28000000000000u64,
  0xf684df56c3e01bc6u64, 0xc732000000000000u64,
  0x9a130b963a6c115cu64, 0x3c7f400000000000u64,
  0xc097ce7bc90715b3u64, 0x4b9f100000000000u64,
  0xf0bdc21abb48db20u64, 0x1e86d40000000000u64,
  0x96769950b50d88f4u64, 0x1314448000000000u64,
  0xbc143fa4e250eb31u64, 0x17d955a000000000u64,
  0xeb194f8e1ae525fdu64, 0x5dcfab0800000000u64,
  0x92efd1b8d0cf37beu64, 0x5aa1cae500000000u64,
  0xb7abc627050305adu64, 0xf14a3d9e40000000u64,
  0xe596b7b0c643c719u64, 0x6d9ccd05d0000000u64,
  0x8f7e32ce7bea5c6fu64, 0xe4820023a2000000u64,
  0xb35dbf821ae4f38bu64, 0xdda2802c8a800000u64,
  0xe0352f62a19e306eu64, 0xd50b2037ad200000u64,
  0x8c213d9da502de45u64, 0x4526f422cc340000u64,
  0xaf298d050e4395d6u64, 0x9670b12b7f410000u64,
  0xdaf3f04651d47b4cu64, 0x3c0cdd765f114000u64,
  0x88d8762bf324cd0fu64, 0xa5880a69fb6ac800u64,
  0xab0e93b6efee0053u64, 0x8eea0d047a457a00u64,
  0xd5d238a4abe98068u64, 0x72a4904598d6d880u64,
  0x85a36366eb71f041u64, 0x47a6da2b7f864750u64,
  0xa70c3c40a64e6c51u64, 0x999090b65f67d924u64,
  0xd0cf4b50cfe20765u64, 0xfff4b4e3f741cf6du64,
  0x82818f1281ed449fu64, 0xbff8f10e7a8921a5u64,
  0xa321f2d7226895c7u64, 0xaff72d52192b6a0eu64,
  0xcbea6f8ceb02bb39u64, 0x9bf4f8a69f764491u64,
  0xfee50b7025c36a08u64, 0x02f236d04753d5b5u64,
  0x9f4f2726179a2245u64, 0x01d762422c946591u64,
  0xc722f0ef9d80aad6u64, 0x424d3ad2b7b97ef6u64,
  0xf8ebad2b84e0d58bu64, 0xd2e0898765a7deb3u64,
  0x9b934c3b330c8577u64, 0x63cc55f49f88eb30u64,
  0xc2781f49ffcfa6d5u64, 0x3cbf6b71c76b25fcu64,
  0xf316271c7fc3908au64, 0x8bef464e3945ef7bu64,
  0x97edd871cfda3a56u64, 0x97758bf0e3cbb5adu64,
  0xbde94e8e43d0c8ecu64, 0x3d52eeed1cbea318u64,
  0xed63a231d4c4fb27u64, 0x4ca7aaa863ee4bdeu64,
  0x945e455f24fb1cf8u64, 0x8fe8caa93e74ef6bu64,
  0xb975d6b6ee39e436u64, 0xb3e2fd538e122b45u64,
  0xe7d34c64a9c85d44u64, 0x60dbbca87196b617u64,
  0x90e40fbeea1d3a4au64, 0xbc8955e946fe31ceu64,
  0xb51d13aea4a488ddu64, 0x6babab6398bdbe42u64,
  0xe264589a4dcdab14u64, 0xc696963c7eed2dd2u64,
  0x8d7eb76070a08aecu64, 0xfc1e1de5cf543ca3u64,
  0xb0de65388cc8ada8u64, 0x3b25a55f43294bccu64,
  0xdd15fe86affad912u64, 0x49ef0eb713f39ebfu64,
  0x8a2dbf142dfcc7abu64, 0x6e3569326c784338u64,
  0xacb92ed9397bf996u64, 0x49c2c37f07965405u64,
  0xd7e77a8f87daf7fbu64, 0xdc33745ec97be907u64,
  0x86f0ac99b4e8dafdu64, 0x69a028bb3ded71a4u64,
  0xa8acd7c0222311bcu64, 0xc40832ea0d68ce0du64,
  0xd2d80db02aabd62bu64, 0xf50a3fa490c30191u64,
  0x83c7088e1aab65dbu64, 0x792667c6da79e0fbu64,
  0xa4b8cab1a1563f52u64, 0x577001b891185939u64,
  0xcde6fd5e09abcf26u64, 0xed4c0226b55e6f87u64,
  0x80b05e5ac60b6178u64, 0x544f8158315b05b5u64,
  0xa0dc75f1778e39d6u64, 0x696361ae3db1c722u64,
  0xc913936dd571c84cu64, 0x03bc3a19cd1e38eau64,
  0xfb5878494ace3a5fu64, 0x04ab48a04065c724u64,
  0x9d174b2dcec0e47bu64, 0x62eb0d64283f9c77u64,
  0xc45d1df942711d9au64, 0x3ba5d0bd324f8395u64,
  0xf5746577930d6500u64, 0xca8f44ec7ee3647au64,
  0x9968bf6abbe85f20u64, 0x7e998b13cf4e1eccu64,
  0xbfc2ef456ae276e8u64, 0x9e3fedd8c321a67fu64,
  0xefb3ab16c59b14a2u64, 0xc5cfe94ef3ea101fu64,
  0x95d04aee3b80ece5u64, 0xbba1f1d158724a13u64,
  0xbb445da9ca61281fu64, 0x2a8a6e45ae8edc98u64,
  0xea1575143cf97226u64, 0xf52d09d71a3293beu64,
  0x924d692ca61be758u64, 0x593c2626705f9c57u64,
  0xb6e0c377cfa2e12eu64, 0x6f8b2fb00c77836du64,
  0xe498f455c38b997au64, 0x0b6dfb9c0f956448u64,
  0x8edf98b59a373fecu64, 0x4724bd4189bd5eadu64,
  0xb2977ee300c50fe7u64, 0x58edec91ec2cb658u64,
  0xdf3d5e9bc0f653e1u64, 0x2f2967b66737e3eeu64,
  0x8b865b215899f46cu64, 0xbd79e0d20082ee75u64,
  0xae67f1e9aec07187u64, 0xecd8590680a3aa12u64,
  0xda01ee641a708de9u64, 0xe80e6f4820cc9496u64,
  0x884134fe908658b2u64, 0x3109058d147fdcdeu64,
  0xaa51823e34a7eedeu64, 0xbd4b46f0599fd416u64,
  0xd4e5e2cdc1d1ea96u64, 0x6c9e18ac7007c91bu64,
  0x850fadc09923329eu64, 0x03e2cf6bc604ddb1u64,
  0xa6539930bf6bff45u64, 0x84db8346b786151du64,
  0xcfe87f7cef46ff16u64, 0xe612641865679a64u64,
  0x81f14fae158c5f6eu64, 0x4fcb7e8f3f60c07fu64,
  0xa26da3999aef7749u64, 0xe3be5e330f38f09eu64,
  0xcb090c8001ab551cu64, 0x5cadf5bfd3072cc6u64,
  0xfdcb4fa002162a63u64, 0x73d9732fc7c8f7f7u64,
  0x9e9f11c4014dda7eu64, 0x2867e7fddcdd9afbu64,
  0xc646d63501a1511du64, 0xb281e1fd541501b9u64,
  0xf7d88bc24209a565u64, 0x1f225a7ca91a4227u64,
  0x9ae757596946075fu64, 0x3375788de9b06959u64,
  0xc1a12d2fc3978937u64, 0x0052d6b1641c83afu64,
  0xf209787bb47d6b84u64, 0xc0678c5dbd23a49bu64,
  0x9745eb4d50ce6332u64, 0xf840b7ba963646e1u64,
  0xbd176620a501fbffu64, 0xb650e5a93bc3d899u64,
  0xec5d3fa8ce427affu64, 0xa3e51f138ab4cebfu64,
  0x93ba47c980e98cdfu64, 0xc66f336c36b10138u64,
  0xb8a8d9bbe123f017u64, 0xb80b0047445d4185u64,
  0xe6d3102ad96cec1du64, 0xa60dc059157491e6u64,
  0x9043ea1ac7e41392u64, 0x87c89837ad68db30u64,
  0xb454e4a179dd1877u64, 0x29babe4598c311fcu64,
  0xe16a1dc9d8545e94u64, 0xf4296dd6fef3d67bu64,
  0x8ce2529e2734bb1du64, 0x1899e4a65f58660du64,
  0xb01ae745b101e9e4u64, 0x5ec05dcff72e7f90u64,
  0xdc21a1171d42645du64, 0x76707543f4fa1f74u64,
  0x899504ae72497ebau64, 0x6a06494a791c53a9u64,
  0xabfa45da0edbde69u64, 0x0487db9d17636893u64,
  0xd6f8d7509292d603u64, 0x45a9d2845d3c42b7u64,
  0x865b86925b9bc5c2u64, 0x0b8a2392ba45a9b3u64,
  0xa7f26836f282b732u64, 0x8e6cac7768d7141fu64,
  0xd1ef0244af2364ffu64, 0x3207d795430cd927u64,
  0x8335616aed761f1fu64, 0x7f44e6bd49e807b9u64,
  0xa402b9c5a8d3a6e7u64, 0x5f16206c9c6209a7u64,
  0xcd036837130890a1u64, 0x36dba887c37a8c10u64,
  0x802221226be55a64u64, 0xc2494954da2c978au64,
  0xa02aa96b06deb0fdu64, 0xf2db9baa10b7bd6du64,
  0xc83553c5c8965d3du64, 0x6f92829494e5acc8u64,
  0xfa42a8b73abbf48cu64, 0xcb772339ba1f17fau64,
  0x9c69a97284b578d7u64, 0xff2a760414536efcu64,
  0xc38413cf25e2d70du64, 0xfef5138519684abbu64,
  0xf46518c2ef5b8cd1u64, 0x7eb258665fc25d6au64,
  0x98bf2f79d5993802u64, 0xef2f773ffbd97a62u64,
  0xbeeefb584aff8603u64, 0xaafb550ffacfd8fbu64,
  0xeeaaba2e5dbf6784u64, 0x95ba2a53f983cf39u64,
  0x952ab45cfa97a0b2u64, 0xdd945a747bf26184u64,
  0xba756174393d88dfu64, 0x94f971119aeef9e5u64,
  0xe912b9d1478ceb17u64, 0x7a37cd5601aab85eu64,
  0x91abb422ccb812eeu64, 0xac62e055c10ab33bu64,
  0xb616a12b7fe617aau64, 0x577b986b314d600au64,
  0xe39c49765fdf9d94u64, 0xed5a7e85fda0b80cu64,
  0x8e41ade9fbebc27du64, 0x14588f13be847308u64,
  0xb1d219647ae6b31cu64, 0x596eb2d8ae258fc9u64,
  0xde469fbd99a05fe3u64, 0x6fca5f8ed9aef3bcu64,
  0x8aec23d680043beeu64, 0x25de7bb9480d5855u64,
  0xada72ccc20054ae9u64, 0xaf561aa79a10ae6bu64,
  0xd910f7ff28069da4u64, 0x1b2ba1518094da05u64,
  0x87aa9aff79042286u64, 0x90fb44d2f05d0843u64,
  0xa99541bf57452b28u64, 0x353a1607ac744a54u64,
  0xd3fa922f2d1675f2u64, 0x42889b8997915ce9u64,
  0x847c9b5d7c2e09b7u64, 0x69956135febada12u64,
  0xa59bc234db398c25u64, 0x43fab9837e699096u64,
  0xcf02b2c21207ef2eu64, 0x94f967e45e03f4bcu64,
  0x8161afb94b44f57du64, 0x1d1be0eebac278f6u64,
  0xa1ba1ba79e1632dcu64, 0x6462d92a69731733u64,
  0xca28a291859bbf93u64, 0x7d7b8f7503cfdcffu64,
  0xfcb2cb35e702af78u64, 0x5cda735244c3d43fu64,
  0x9defbf01b061adabu64, 0x3a0888136afa64a8u64,
  0xc56baec21c7a1916u64, 0x088aaa1845b8fdd1u64,
  0xf6c69a72a3989f5bu64, 0x8aad549e57273d46u64,
  0x9a3c2087a63f6399u64, 0x36ac54e2f678864cu64,
  0xc0cb28a98fcf3c7fu64, 0x84576a1bb416a7deu64,
  0xf0fdf2d3f3c30b9fu64, 0x656d44a2a11c51d6u64,
  0x969eb7c47859e743u64, 0x9f644ae5a4b1b326u64,
  0xbc4665b596706114u64, 0x873d5d9f0dde1fefu64,
  0xeb57ff22fc0c7959u64, 0xa90cb506d155a7ebu64,
  0x9316ff75dd87cbd8u64, 0x09a7f12442d588f3u64,
  0xb7dcbf5354e9beceu64, 0x0c11ed6d538aeb30u64,
  0xe5d3ef282a242e81u64, 0x8f1668c8a86da5fbu64,
  0x8fa475791a569d10u64, 0xf96e017d694487bdu64,
  0xb38d92d760ec4455u64, 0x37c981dcc395a9adu64,
  0xe070f78d3927556au64, 0x85bbe253f47b1418u64,
  0x8c469ab843b89562u64, 0x93956d7478ccec8fu64,
  0xaf58416654a6babbu64, 0x387ac8d1970027b3u64,
  0xdb2e51bfe9d0696au64, 0x06997b05fcc0319fu64,
  0x88fcf317f22241e2u64, 0x441fece3bdf81f04u64,
  0xab3c2fddeeaad25au64, 0xd527e81cad7626c4u64,
  0xd60b3bd56a5586f1u64, 0x8a71e223d8d3b075u64,
  0x85c7056562757456u64, 0xf6872d5667844e4au64,
  0xa738c6bebb12d16cu64, 0xb428f8ac016561dcu64,
  0xd106f86e69d785c7u64, 0xe13336d701beba53u64,
  0x82a45b450226b39cu64, 0xecc0024661173474u64,
  0xa34d721642b06084u64, 0x27f002d7f95d0191u64,
  0xcc20ce9bd35c78a5u64, 0x31ec038df7b441f5u64,
  0xff290242c83396ceu64, 0x7e67047175a15272u64,
  0x9f79a169bd203e41u64, 0x0f0062c6e984d387u64,
  0xc75809c42c684dd1u64, 0x52c07b78a3e60869u64,
  0xf92e0c3537826145u64, 0xa7709a56ccdf8a83u64,
  0x9bbcc7a142b17ccbu64, 0x88a66076400bb692u64,
  0xc2abf989935ddbfeu64, 0x6acff893d00ea436u64,
  0xf356f7ebf83552feu64, 0x0583f6b8c4124d44u64,
  0x98165af37b2153deu64, 0xc3727a337a8b704bu64,
  0xbe1bf1b059e9a8d6u64, 0x744f18c0592e4c5du64,
  0xeda2ee1c7064130cu64, 0x1162def06f79df74u64,
  0x9485d4d1c63e8be7u64, 0x8addcb5645ac2ba9u64,
  0xb9a74a0637ce2ee1u64, 0x6d953e2bd7173693u64,
  0xe8111c87c5c1ba99u64, 0xc8fa8db6ccdd0438u64,
  0x910ab1d4db9914a0u64, 0x1d9c9892400a22a3u64,
  0xb54d5e4a127f59c8u64, 0x2503beb6d00cab4cu64,
  0xe2a0b5dc971f303au64, 0x2e44ae64840fd61eu64,
  0x8da471a9de737e24u64, 0x5ceaecfed289e5d3u64,
  0xb10d8e1456105dadu64, 0x7425a83e872c5f48u64,
  0xdd50f1996b947518u64, 0xd12f124e28f7771au64,
  0x8a5296ffe33cc92fu64, 0x82bd6b70d99aaa70u64,
  0xace73cbfdc0bfb7bu64, 0x636cc64d1001550cu64,
  0xd8210befd30efa5au64, 0x3c47f7e05401aa4fu64,
  0x8714a775e3e95c78u64, 0x65acfaec34810a72u64,
  0xa8d9d1535ce3b396u64, 0x7f1839a741a14d0eu64,
  0xd31045a8341ca07cu64, 0x1ede48111209a051u64,
  0x83ea2b892091e44du64, 0x934aed0aab460433u64,
  0xa4e4b66b68b65d60u64, 0xf81da84d56178540u64,
  0xce1de40642e3f4b9u64, 0x36251260ab9d668fu64,
  0x80d2ae83e9ce78f3u64, 0xc1d72b7c6b42601au64,
  0xa1075a24e4421730u64, 0xb24cf65b8612f820u64,
  0xc94930ae1d529cfcu64, 0xdee033f26797b628u64,
  0xfb9b7cd9a4a7443cu64, 0x169840ef017da3b2u64,
  0x9d412e0806e88aa5u64, 0x8e1f289560ee864fu64,
  0xc491798a08a2ad4eu64, 0xf1a6f2bab92a27e3u64,
  0xf5b5d7ec8acb58a2u64, 0xae10af696774b1dcu64,
  0x9991a6f3d6bf1765u64, 0xacca6da1e0a8ef2au64,
  0xbff610b0cc6edd3fu64, 0x17fd090a58d32af4u64,
  0xeff394dcff8a948eu64, 0xddfc4b4cef07f5b1u64,
  0x95f83d0a1fb69cd9u64, 0x4abdaf101564f98fu64,
  0xbb764c4ca7a4440fu64, 0x9d6d1ad41abe37f2u64,
  0xea53df5fd18d5513u64, 0x84c86189216dc5eeu64,
  0x92746b9be2f8552cu64, 0x32fd3cf5b4e49bb5u64,
  0xb7118682dbb66a77u64, 0x3fbc8c33221dc2a2u64,
  0xe4d5e82392a40515u64, 0x0fabaf3feaa5334bu64,
  0x8f05b1163ba6832du64, 0x29cb4d87f2a7400fu64,
  0xb2c71d5bca9023f8u64, 0x743e20e9ef511013u64,
  0xdf78e4b2bd342cf6u64, 0x914da9246b255417u64,
  0x8bab8eefb6409c1au64, 0x1ad089b6c2f7548fu64,
  0xae9672aba3d0c320u64, 0xa184ac2473b529b2u64,
  0xda3c0f568cc4f3e8u64, 0xc9e5d72d90a2741fu64,
  0x8865899617fb1871u64, 0x7e2fa67c7a658893u64,
  0xaa7eebfb9df9de8du64, 0xddbb901b98feeab8u64,
  0xd51ea6fa85785631u64, 0x552a74227f3ea566u64,
  0x8533285c936b35deu64, 0xd53a88958f872760u64,
  0xa67ff273b8460356u64, 0x8a892abaf368f138u64,
  0xd01fef10a657842cu64, 0x2d2b7569b0432d86u64,
  0x8213f56a67f6b29bu64, 0x9c3b29620e29fc74u64,
  0xa298f2c501f45f42u64, 0x8349f3ba91b47b90u64,
  0xcb3f2f7642717713u64, 0x241c70a936219a74u64,
  0xfe0efb53d30dd4d7u64, 0xed238cd383aa0111u64,
  0x9ec95d1463e8a506u64, 0xf4363804324a40abu64,
  0xc67bb4597ce2ce48u64, 0xb143c6053edcd0d6u64,
  0xf81aa16fdc1b81dau64, 0xdd94b7868e94050bu64,
  0x9b10a4e5e9913128u64, 0xca7cf2b4191c8327u64,
  0xc1d4ce1f63f57d72u64, 0xfd1c2f611f63a3f1u64,
  0xf24a01a73cf2dccfu64, 0xbc633b39673c8cedu64,
  0x976e41088617ca01u64, 0xd5be0503e085d814u64,
  0xbd49d14aa79dbc82u64, 0x4b2d8644d8a74e19u64,
  0xec9c459d51852ba2u64, 0xddf8e7d60ed1219fu64,
  0x93e1ab8252f33b45u64, 0xcabb90e5c942b504u64,
  0xb8da1662e7b00a17u64, 0x3d6a751f3b936244u64,
  0xe7109bfba19c0c9du64, 0x0cc512670a783ad5u64,
  0x906a617d450187e2u64, 0x27fb2b80668b24c6u64,
  0xb484f9dc9641e9dau64, 0xb1f9f660802dedf7u64,
  0xe1a63853bbd26451u64, 0x5e7873f8a0396974u64,
  0x8d07e33455637eb2u64, 0xdb0b487b6423e1e9u64,
  0xb049dc016abc5e5fu64, 0x91ce1a9a3d2cda63u64,
  0xdc5c5301c56b75f7u64, 0x7641a140cc7810fcu64,
  0x89b9b3e11b6329bau64, 0xa9e904c87fcb0a9eu64,
  0xac2820d9623bf429u64, 0x546345fa9fbdcd45u64,
  0xd732290fbacaf133u64, 0xa97c177947ad4096u64,
  0x867f59a9d4bed6c0u64, 0x49ed8eabcccc485eu64,
  0xa81f301449ee8c70u64, 0x5c68f256bfff5a75u64,
  0xd226fc195c6a2f8cu64, 0x73832eec6fff3112u64,
  0x83585d8fd9c25db7u64, 0xc831fd53c5ff7eacu64,
  0xa42e74f3d032f525u64, 0xba3e7ca8b77f5e56u64,
  0xcd3a1230c43fb26fu64, 0x28ce1bd2e55f35ecu64,
  0x80444b5e7aa7cf85u64, 0x7980d163cf5b81b4u64,
  0xa0555e361951c366u64, 0xd7e105bcc3326220u64,
  0xc86ab5c39fa63440u64, 0x8dd9472bf3fefaa8u64,
  0xfa856334878fc150u64, 0xb14f98f6f0feb952u64,
  0x9c935e00d4b9d8d2u64, 0x6ed1bf9a569f33d4u64,
  0xc3b8358109e84f07u64, 0x0a862f80ec4700c9u64,
  0xf4a642e14c6262c8u64, 0xcd27bb612758c0fbu64,
  0x98e7e9cccfbd7dbdu64, 0x8038d51cb897789du64,
  0xbf21e44003acdd2cu64, 0xe0470a63e6bd56c4u64,
  0xeeea5d5004981478u64, 0x1858ccfce06cac75u64,
  0x95527a5202df0ccbu64, 0x0f37801e0c43ebc9u64,
  0xbaa718e68396cffdu64, 0xd30560258f54e6bbu64,
  0xe950df20247c83fdu64, 0x47c6b82ef32a206au64,
  0x91d28b7416cdd27eu64, 0x4cdc331d57fa5442u64,
  0xb6472e511c81471du64, 0xe0133fe4adf8e953u64,
  0xe3d8f9e563a198e5u64, 0x58180fddd97723a7u64,
  0x8e679c2f5e44ff8fu64, 0x570f09eaa7ea7649u64,
  0xb201833b35d63f73u64, 0x2cd2cc6551e513dbu64,
  0xde81e40a034bcf4fu64, 0xf8077f7ea65e58d2u64,
  0x8b112e86420f6191u64, 0xfb04afaf27faf783u64,
  0xadd57a27d29339f6u64, 0x79c5db9af1f9b564u64,
  0xd94ad8b1c7380874u64, 0x18375281ae7822bdu64,
  0x87cec76f1c830548u64, 0x8f2293910d0b15b6u64,
  0xa9c2794ae3a3c69au64, 0xb2eb3875504ddb23u64,
  0xd433179d9c8cb841u64, 0x5fa60692a46151ecu64,
  0x849feec281d7f328u64, 0xdbc7c41ba6bcd334u64,
  0xa5c7ea73224deff3u64, 0x12b9b522906c0801u64,
  0xcf39e50feae16befu64, 0xd768226b34870a01u64,
  0x81842f29f2cce375u64, 0xe6a1158300d46641u64,
  0xa1e53af46f801c53u64, 0x60495ae3c1097fd1u64,
  0xca5e89b18b602368u64, 0x385bb19cb14bdfc5u64,
  0xfcf62c1dee382c42u64, 0x46729e03dd9ed7b6u64,
  0x9e19db92b4e31ba9u64, 0x6c07a2c26a8346d2u64,
  0xc5a05277621be293u64, 0xc7098b7305241886u64,
  0xf70867153aa2db38u64, 0xb8cbee4fc66d1ea8u64,
];

// The f32 cache covers powers of ten from -31 through 46 with 78 entries.
const DB_CACHE32: u64[] = [
  0x81ceb32c4b43fcf5u64, 0xa2425ff75e14fc32u64,
  0xcad2f7f5359a3b3fu64, 0xfd87b5f28300ca0eu64,
  0x9e74d1b791e07e49u64, 0xc612062576589ddbu64,
  0xf79687aed3eec552u64, 0x9abe14cd44753b53u64,
  0xc16d9a0095928a28u64, 0xf1c90080baf72cb2u64,
  0x971da05074da7befu64, 0xbce5086492111aebu64,
  0xec1e4a7db69561a6u64, 0x9392ee8e921d5d08u64,
  0xb877aa3236a4b44au64, 0xe69594bec44de15cu64,
  0x901d7cf73ab0acdau64, 0xb424dc35095cd810u64,
  0xe12e13424bb40e14u64, 0x8cbccc096f5088ccu64,
  0xafebff0bcb24aaffu64, 0xdbe6fecebdedd5bfu64,
  0x89705f4136b4a598u64, 0xabcc77118461cefdu64,
  0xd6bf94d5e57a42bdu64, 0x8637bd05af6c69b6u64,
  0xa7c5ac471b478424u64, 0xd1b71758e219652cu64,
  0x83126e978d4fdf3cu64, 0xa3d70a3d70a3d70bu64,
  0xcccccccccccccccdu64, 0x8000000000000000u64,
  0xa000000000000000u64, 0xc800000000000000u64,
  0xfa00000000000000u64, 0x9c40000000000000u64,
  0xc350000000000000u64, 0xf424000000000000u64,
  0x9896800000000000u64, 0xbebc200000000000u64,
  0xee6b280000000000u64, 0x9502f90000000000u64,
  0xba43b74000000000u64, 0xe8d4a51000000000u64,
  0x9184e72a00000000u64, 0xb5e620f480000000u64,
  0xe35fa931a0000000u64, 0x8e1bc9bf04000000u64,
  0xb1a2bc2ec5000000u64, 0xde0b6b3a76400000u64,
  0x8ac7230489e80000u64, 0xad78ebc5ac620000u64,
  0xd8d726b7177a8000u64, 0x878678326eac9000u64,
  0xa968163f0a57b400u64, 0xd3c21bcecceda100u64,
  0x84595161401484a0u64, 0xa56fa5b99019a5c8u64,
  0xcecb8f27f4200f3au64, 0x813f3978f8940985u64,
  0xa18f07d736b90be6u64, 0xc9f2c9cd04674edfu64,
  0xfc6f7c4045812297u64, 0x9dc5ada82b70b59eu64,
  0xc5371912364ce306u64, 0xf684df56c3e01bc7u64,
  0x9a130b963a6c115du64, 0xc097ce7bc90715b4u64,
  0xf0bdc21abb48db21u64, 0x96769950b50d88f5u64,
  0xbc143fa4e250eb32u64, 0xeb194f8e1ae525feu64,
  0x92efd1b8d0cf37bfu64, 0xb7abc627050305aeu64,
  0xe596b7b0c643c71au64, 0x8f7e32ce7bea5c70u64,
  0xb35dbf821ae4f38cu64, 0xe0352f62a19e306fu64,
];
// END GENERATED DRAGONBOX TABLES

// floor(log10(2^e)), floor(log2(10^e)) and floor(log10(2^e * 3/4)) — the
// magic-multiply approximations from the reference, exact over the exponent
// ranges Dragonbox uses. `>>` on a negative i32 floors, which is what these
// need. Every product stays well inside i32.
```

### `3 function _db_log10_pow2(e: i32): i32`

```fern
<<3 function _db_log10_pow2(e: i32): i32>>=
function _db_log10_pow2(e: i32): i32 {
  return e * 315653 >> 20;
}
```

### `4 function _db_log2_pow10(e: i32): i32`

```fern
<<4 function _db_log2_pow10(e: i32): i32>>=
function _db_log2_pow10(e: i32): i32 {
  return e * 1741647 >> 19;
}
```

### `5 function _db_log10_pow2_m43(e: i32): i32`

```fern
<<5 function _db_log10_pow2_m43(e: i32): i32>>=
function _db_log10_pow2_m43(e: i32): i32 {
  return e * 631305 - 261663 >> 21;
}

// _db_mul_hi is the high half of the 64x64 -> 128 widening multiply; the low
// half is the machine's wrapping product. Scalar results throughout this file
// rather than pairs, because a returned tuple is a heap cell.
```

### `6 pub(package) function _db_mul_hi(x: u64, y: u64): u64`

```fern
<<6 pub(package) function _db_mul_hi(x: u64, y: u64): u64>>=
pub(package) function _db_mul_hi(x: u64, y: u64): u64 {
  return __mulhi_u64(x, y);
}

// _db_mul192_hi / _db_mul192_lo are the upper 128 bits of (64-bit x) *
// (128-bit cache), a word each. `lo == 0` is Dragonbox's integer check.
```

### `7 function _db_mul192_lo(x: u64, chi: u64, clo: u64): u64`

```fern
<<7 function _db_mul192_lo(x: u64, chi: u64, clo: u64): u64>>=
function _db_mul192_lo(x: u64, chi: u64, clo: u64): u64 {
  return x * chi + _db_mul_hi(x, clo);
}
```

### `8 function _db_mul192_hi(x: u64, chi: u64, clo: u64): u64`

```fern
<<8 function _db_mul192_hi(x: u64, chi: u64, clo: u64): u64>>=
function _db_mul192_hi(x: u64, chi: u64, clo: u64): u64 {
  let hi: u64 = _db_mul_hi(x, chi);
  if (_db_mul192_lo(x, chi, clo) < x * chi) {  // carry out of the low half
    hi = hi + 1 as u64;
  }
  return hi;
}

// _db_parity64 answers bit 0 set for parity and bit 1 set for is_integer,
// of the lower 128 bits of two_f * cache: the tie-break probe Dragonbox
// uses at the interval endpoints. beta is in [6, 9] here, so both shifts
// stay in range.
```

### `9 function _db_parity64(two_f: u64, chi: u64, clo: u64, beta: i32): i32`

```fern
<<9 function _db_parity64(two_f: u64, chi: u64, clo: u64, beta: i32): i32>>=
function _db_parity64(two_f: u64, chi: u64, clo: u64, beta: i32): i32 {
  let hi: u64 = two_f * chi + _db_mul_hi(two_f, clo);
  let lo: u64 = two_f * clo;
  let back: u64 = (64 - beta) as u64;
  let flags: i32 = (hi >> back & 1 as u64) as i32;
  if ((hi << beta as u64 | lo >> back) == 0 as u64) {
    flags = flags + 2;
  }
  return flags;
}

// _db_rtz strips trailing zeros from the significand, folding each into the
// decimal exponent. The zero guard is unreachable for a finite non-zero
// input; it is there so a broken invariant can never hang the formatter.
```

### `10 function _db_rtz(sig: u64, exp: i32): (i64, i32)`

```fern
<<10 function _db_rtz(sig: u64, exp: i32): (i64, i32)>>=
function _db_rtz(sig: u64, exp: i32): (i64, i32) {
  while (sig != 0 as u64 && sig % (10 as u64) == 0 as u64) {
    sig = sig / (10 as u64);
    exp = exp + 1;
  }
  return (sig as i64, exp);
}

// __db_shortest64 returns (significand, decimal exponent) for a POSITIVE
// finite f64, with value == significand * 10^exponent and the significand as
// short as round-tripping allows. kappa is 2 for binary64, so the divisors
// below are 10^3 and 10^2.
```

### `11 function __db_shortest64(n: f64): (i64, i32)`

```fern
<<11 function __db_shortest64(n: f64): (i64, i32)>>=
function __db_shortest64(n: f64): (i64, i32) {
  let bits: u64 = f64_bits(n) as u64;
  let ebits: i32 = (bits >> 52 as u64 & 2047 as u64) as i32;
  let two_fc: u64 = (bits & 4503599627370495 as u64) << 1 as u64;
  // A closed interval means both endpoints round back to n, which is the
  // case exactly when the significand is even (round-half-to-even).
  let closed: boolean = (bits & 1 as u64) == 0 as u64;
  let be: i32 = 0 - 1074;
  if (ebits != 0) {
    be = ebits - 1075;
    // A power of two has a shorter interval on its left side.
    if (two_fc == 0 as u64) {
      return __db_shorter64(be);
    }
    two_fc = two_fc | 9007199254740992 as u64;  // implicit bit, << 1
  }

  let mk: i32 = _db_log10_pow2(be) - 2;
  let k: i32 = 0 - mk;
  let beta: i32 = be + _db_log2_pow10(k);
  let at: i32 = (k + 292) * 2;
  let chi: u64 = DB_CACHE64[at];
  let clo: u64 = DB_CACHE64[at + 1];

  let deltai: u64 = chi >> (63 - beta) as u64;
  let zx: u64 = (two_fc | 1 as u64) << beta as u64;
  let zi: u64 = _db_mul192_hi(zx, chi, clo);
  let z_int: boolean = _db_mul192_lo(zx, chi, clo) == 0 as u64;

  let sig: u64 = zi / (1000 as u64);
  let r: u64 = zi - 1000 as u64 * sig;

  // Step 2: try the larger divisor. Falling through to the return means the
  // shorter significand is in the interval; every other path drops to step 3.
  let smaller: boolean = false;
  if (r < deltai) {
    if (r == 0 as u64 && z_int && !closed) {
      sig = sig - 1 as u64;
      r = 1000 as u64;
      smaller = true;
    }
  } else if (r > deltai) {
    smaller = true;
  } else {
    let xp: i32 = _db_parity64(two_fc - 1 as u64, chi, clo, beta);
    if (!((xp & 1) != 0 || (xp & 2) != 0 && closed)) {
      smaller = true;
    }
  }
  if (!smaller) {
    return _db_rtz(sig, mk + 3);
  }

  // Step 3: find the significand with the smaller divisor. r >= deltai here
  // (or r was reset to 1000), and deltai < 1000, so `dist` cannot underflow.
  sig = sig * (10 as u64);
  let dist: u64 = r - deltai / (2 as u64) + 50 as u64;
  // The reference computes ((dist ^ (small_divisor / 2)) & 1) != 0; here
  // small_divisor / 2 is 50, which is even, so this is just dist's parity.
  let approx: boolean = (dist & 1 as u64) != 0 as u64;
  let divisible: boolean = dist % (100 as u64) == 0 as u64;
  sig = sig + dist / (100 as u64);
  if (divisible) {
    let yp: i32 = _db_parity64(two_fc, chi, clo, beta);
    if ((yp & 1) != 0 != approx) {
      sig = sig - 1 as u64;
    } else if (sig % (2 as u64) != 0 as u64 && (yp & 2) != 0) {
      sig = sig - 1 as u64;
    }
  }
  return (sig as i64, mk + 2);
}

// __db_shorter64 handles the asymmetric interval at a power of two, where the
// gap below n is half the gap above it. The interval is closed under
// nearest-to-even, so the right endpoint is never pulled in; the left one is
// nudged up unless it lands on an integer.
```

### `12 function __db_shorter64(be: i32): (i64, i32)`

```fern
<<12 function __db_shorter64(be: i32): (i64, i32)>>=
function __db_shorter64(be: i32): (i64, i32) {
  let mk: i32 = _db_log10_pow2_m43(be);
  let k: i32 = 0 - mk;
  let beta: i32 = be + _db_log2_pow10(k);
  let chi: u64 = DB_CACHE64[(k + 292) * 2];

  let sh: u64 = (11 - beta) as u64;
  let xi: u64 = chi - (chi >> 54 as u64) >> sh;
  let zi: u64 = chi + (chi >> 53 as u64) >> sh;
  if (!(be >= 2 && be <= 3)) {
    xi = xi + 1 as u64;
  }

  let sig: u64 = zi / (10 as u64);
  if (sig * (10 as u64) >= xi) {
    return _db_rtz(sig, mk + 1);
  }

  sig = ((chi >> (10 - beta) as u64) + 1 as u64) / (2 as u64);
  // be == -77 is the only binary exponent where the rounded-up y can tie.
  if (sig % (2 as u64) != 0 as u64 && be == 0 - 77) {
    sig = sig - 1 as u64;
  } else if (sig < xi) {
    sig = sig + 1 as u64;
  }
  return (sig as i64, mk);
}

// __db_shortest32 is the binary32 sibling: 23-bit fraction, 8-bit exponent,
// a 64-bit cache instead of 128-bit, and kappa 1 (divisors 10^2 and 10^1).
```

### `13 function __db_shortest32(n: f32): (i64, i32)`

```fern
<<13 function __db_shortest32(n: f32): (i64, i32)>>=
function __db_shortest32(n: f32): (i64, i32) {
  let bits: u64 = (f32_bits(n) as i64) as u64;
  let ebits: i32 = (bits >> 23 as u64 & 255 as u64) as i32;
  let two_fc: u64 = (bits & 8388607 as u64) << 1 as u64;
  let closed: boolean = (bits & 1 as u64) == 0 as u64;
  let be: i32 = 0 - 149;
  if (ebits != 0) {
    be = ebits - 150;
    if (two_fc == 0 as u64) {
      return __db_shorter32(be);
    }
    two_fc = two_fc | 16777216 as u64;  // implicit bit, << 1
  }

  let mk: i32 = _db_log10_pow2(be) - 1;
  let k: i32 = 0 - mk;
  let beta: i32 = be + _db_log2_pow10(k);
  let c: u64 = DB_CACHE32[k + 31];

  let deltai: u64 = c >> (63 - beta) as u64;
  // The binary32 product is 96-bit: widen the 32-bit operand into the high
  // half and keep the upper 64 bits.
  let prod: u64 = _db_mul_hi((two_fc | 1 as u64) << beta as u64 << 32 as u64, c);
  let zi: u64 = prod >> 32 as u64;
  let z_int: boolean = (prod & 4294967295 as u64) == 0 as u64;

  let sig: u64 = zi / (100 as u64);
  let r: u64 = zi - 100 as u64 * sig;

  let smaller: boolean = false;
  if (r < deltai) {
    if (r == 0 as u64 && z_int && !closed) {
      sig = sig - 1 as u64;
      r = 100 as u64;
      smaller = true;
    }
  } else if (r > deltai) {
    smaller = true;
  } else {
    let xp: i32 = _db_parity32(two_fc - 1 as u64, c, beta);
    if (!((xp & 1) != 0 || (xp & 2) != 0 && closed)) {
      smaller = true;
    }
  }
  if (!smaller) {
    return _db_rtz(sig, mk + 2);
  }

  sig = sig * (10 as u64);
  let dist: u64 = r - deltai / (2 as u64) + 5 as u64;
  // Here small_divisor / 2 is 5, which is ODD, so ((dist ^ 5) & 1) != 0
  // inverts dist's parity.
  let approx: boolean = (dist & 1 as u64) == 0 as u64;
  let divisible: boolean = dist % (10 as u64) == 0 as u64;
  sig = sig + dist / (10 as u64);
  if (divisible) {
    let yp: i32 = _db_parity32(two_fc, c, beta);
    if ((yp & 1) != 0 != approx) {
      sig = sig - 1 as u64;
    } else if (sig % (2 as u64) != 0 as u64 && (yp & 2) != 0) {
      sig = sig - 1 as u64;
    }
  }
  return (sig as i64, mk + 1);
}

// _db_parity32 is _db_parity64's 96-bit counterpart: the low 64 bits of the
// product carry everything it needs. beta is in [3, 6] here.
```

### `14 function _db_parity32(two_f: u64, c: u64, beta: i32): i32`

```fern
<<14 function _db_parity32(two_f: u64, c: u64, beta: i32): i32>>=
function _db_parity32(two_f: u64, c: u64, beta: i32): i32 {
  let r: u64 = two_f * c;
  let flags: i32 = (r >> (64 - beta) as u64 & 1 as u64) as i32;
  if ((r >> (32 - beta) as u64 & 4294967295 as u64) == 0 as u64) {
    flags = flags + 2;
  }
  return flags;
}
```

### `15 function __db_shorter32(be: i32): (i64, i32)`

```fern
<<15 function __db_shorter32(be: i32): (i64, i32)>>=
function __db_shorter32(be: i32): (i64, i32) {
  let mk: i32 = _db_log10_pow2_m43(be);
  let k: i32 = 0 - mk;
  let beta: i32 = be + _db_log2_pow10(k);
  let c: u64 = DB_CACHE32[k + 31];

  let sh: u64 = (40 - beta) as u64;
  let xi: u64 = c - (c >> 25 as u64) >> sh;
  let zi: u64 = c + (c >> 24 as u64) >> sh;
  if (!(be >= 2 && be <= 3)) {
    xi = xi + 1 as u64;
  }

  let sig: u64 = zi / (10 as u64);
  if (sig * (10 as u64) >= xi) {
    return _db_rtz(sig, mk + 1);
  }

  sig = ((c >> (39 - beta) as u64) + 1 as u64) / (2 as u64);
  if (sig % (2 as u64) != 0 as u64 && be == 0 - 35) {
    sig = sig - 1 as u64;
  } else if (sig < xi) {
    sig = sig + 1 as u64;
  }
  return (sig as i64, mk);
}

// Format shortest significand `sig` with most-significant-digit decimal
// exponent `msd`: scientific when msd < -4 or msd >= 21, else fixed-point.
// The low threshold is Go / C 'g'; the high one and the unpadded `e+`/`e-`
// spelling are JavaScript's, so 1e20 prints in full where Go %v gives 1e+20.
```

### `16 function __float_fmt_sci(sig: string, msd: i32): string`

```fern
<<16 function __float_fmt_sci(sig: string, msd: i32): string>>=
function __float_fmt_sci(sig: string, msd: i32): string {
  let nd: i32 = sig.len();
  if (msd < 0 - 4 || msd >= 21) {
    // scientific: d[.ddd]e±XX
    let out: string = "" + slice_unchecked(sig, 0, 1);
    if (nd > 1) {
      out = out + "." + slice_unchecked(sig, 1, nd);
    }
    if (msd < 0) {
      return out + "e-" + int.int_to_string(0 - msd);
    }
    return out + "e+" + int.int_to_string(msd);
  }
  if (msd < 0) {
    // 0.000sig
    let z: string = "";
    let i: i32 = 0;
    while (i < 0 - msd - 1) {
      z = z + "0";
      i = i + 1;
    }
    return "0." + z + sig;
  }
  if (msd + 1 >= nd) {
    // integer, pad trailing zeros
    let z2: string = "";
    let i2: i32 = 0;
    while (i2 < msd + 1 - nd) {
      z2 = z2 + "0";
      i2 = i2 + 1;
    }
    return sig + z2;
  }
  // point in the middle
  return "" + slice_unchecked(sig, 0, msd + 1) + "." + slice_unchecked(sig, msd + 1, nd);
}

// Render a Dragonbox result — significand `sig` with decimal exponent `exp`,
// value == sig * 10^exp — in Go %v / strconv 'g' style, prefixed by `out`
// (the already-extracted sign). Shared by the f32 and f64 formatters.
```

### `17 function __float_render(out: string, sig: i64, exp: i32): string`

```fern
<<17 function __float_render(out: string, sig: i64, exp: i32): string>>=
function __float_render(out: string, sig: i64, exp: i32): string {
  let digits: string = int.__int_to_string_u64(sig, 0);
  return out + __float_fmt_sci(digits, digits.len() - 1 + exp);
}
```

### `18 pub(package) function __primitive_f64_to_string(n: f64): string`

```fern
<<18 pub(package) function __primitive_f64_to_string(n: f64): string>>=
pub(package) function __primitive_f64_to_string(n: f64): string {
  if (n != n) {
    return "NaN";
  }
  let out: string = "";
  if (n < 0.0) {
    out = "-";
    n = 0.0 - n;
  }
  if (n != 0.0 && n * 2.0 == n) {
    return out + "Inf";
  }
  if (n == 0.0) {
    return out + "0";
  }
  let d: (i64, i32) = __db_shortest64(n);
  return __float_render(out, d.0, d.1);
}

// f32 shortest-round-trip formatter. Same shape as the f64 path — sign / NaN
// / Inf / 0 handling, then Dragonbox over the binary32 fields — so an f32
// renders with the fewest digits that still parse back to it (e.g. 0.1f32 ->
// "0.1", not "0.099999994").
```

### `19 pub(package) function __primitive_f32_to_string(n: f32): string`

```fern
<<19 pub(package) function __primitive_f32_to_string(n: f32): string>>=
pub(package) function __primitive_f32_to_string(n: f32): string {
  if (n != n) {
    return "NaN";
  }
  let out: string = "";
  if (n < 0.0) {
    out = "-";
    n = 0.0 - n;
  }
  if (n != 0.0 && n * 2.0 == n) {
    return out + "Inf";
  }
  if (n == 0.0) {
    return out + "0";
  }
  let d: (i64, i32) = __db_shortest32(n);
  return __float_render(out, d.0, d.1);
}

// `shortest_digits()` — the shortest decimal that reads back as `n`, as
// (significand, exponent) with |n| == significand × 10^exponent and no
// trailing zero on the significand, so its digit count is the fewest any
// decimal of `n` that round-trips can have. Zero, an infinity and NaN
// answer (0, 0). The sign is not part of the answer.
```

### `20 pub(package) function shortest_digits64(n: f64): (i64, i32)`

```fern
<<20 pub(package) function shortest_digits64(n: f64): (i64, i32)>>=
pub(package) function shortest_digits64(n: f64): (i64, i32) {
  if (n != n || n == 0.0 || n * 2.0 == n) {
    return (0 as i64, 0);
  }
  if (n < 0.0) {
    n = 0.0 - n;
  }
  return __db_trim(__db_shortest64(n));
}
```

### `21 pub(package) function shortest_digits32(n: f32): (i64, i32)`

```fern
<<21 pub(package) function shortest_digits32(n: f32): (i64, i32)>>=
pub(package) function shortest_digits32(n: f32): (i64, i32) {
  if (n != n || n == 0.0 || n * 2.0 == n) {
    return (0 as i64, 0);
  }
  if (n < 0.0) {
    n = 0.0 - n;
  }
  return __db_trim(__db_shortest32(n));
}

// `pow10_hi(k)` / `pow10_lo(k)` — the 128-bit significand of 10^k the
// shortest search runs on, for a caller doing its own scaled arithmetic:
// with c the two words, 10^k == (c − θ) × 2^(pow10_log2(k) − 127) for some
// 0 ≤ θ < 1 (c is 10^k rounded up), for k in -292..326.
```

### `22 pub(package) function pow10_hi(k: i32): u64`

```fern
<<22 pub(package) function pow10_hi(k: i32): u64>>=
pub(package) function pow10_hi(k: i32): u64 {
  return DB_CACHE64[(k + 292) * 2];
}
```

### `23 pub(package) function pow10_lo(k: i32): u64`

```fern
<<23 pub(package) function pow10_lo(k: i32): u64>>=
pub(package) function pow10_lo(k: i32): u64 {
  return DB_CACHE64[(k + 292) * 2 + 1];
}

// `pow10_log2(k)` — floor(log2(10^k)), the exponent `pow10_hi` is stated against.
```

### `24 pub(package) function pow10_log2(k: i32): i32`

```fern
<<24 pub(package) function pow10_log2(k: i32): i32>>=
pub(package) function pow10_log2(k: i32): i32 {
  return _db_log2_pow10(k);
}
```

### `25 function __db_trim(d: (i64, i32)): (i64, i32)`

```fern
<<25 function __db_trim(d: (i64, i32)): (i64, i32)>>=
function __db_trim(d: (i64, i32)): (i64, i32) {
  let sig: i64 = d.0;
  if (sig % (10 as i64) != 0 as i64) {
    return d;
  }
  let exp: i32 = d.1;
  while (sig % (10 as i64) == 0 as i64) {
    sig = sig / (10 as i64);
    exp = exp + 1;
  }
  return (sig, exp);
}

// __float_to_string_prec renders `n` with EXACTLY `prec` fractional
// digits — no trailing-zero trimming — rounding half away from zero.
// Unlike the default shortest formatter (which emits the fewest digits
// that round-trip), this gives the fixed-width output that table /
// currency formatting wants: `3.14159 @ prec 2` -> "3.14", `2.5 @ prec 0` ->
// "3", `1.0 @ prec 3` -> "1.000". The whole computation stays in the
// float domain via __float_int_part, so no value crosses the
// trapping/non-portable `f64 -> i64` boundary regardless of magnitude.
```

### `26 pub(package) function fixed(n: f64, prec: i32): string`

```fern
<<26 pub(package) function fixed(n: f64, prec: i32): string>>=
pub(package) function fixed(n: f64, prec: i32): string {
  if (n != n) {
    return "NaN";
  }
  let out: string = "";
  if (n < 0.0) {
    out = "-";
    n = 0.0 - n;
  }
  if (n != 0.0 && n * 2.0 == n) {
    return out + "Inf";
  }
  // mult = 10^prec.
  let mult: f64 = 1.0;
  let i: i32 = 0;
  while (i < prec) {
    mult = mult * 10.0;
    i = i + 1;
  }
  // Scale, round half away from zero, and split into integer + fraction
  // halves — both integer-valued f64s now.
  let scaled: f64 = __floor_f64(n * mult + 0.5);
  let intf: f64 = __floor_f64(scaled / mult);
  let fracf: f64 = scaled - intf * mult;
  out = out + __float_int_part(intf);
  if (prec == 0) {
    return out;
  }
  // Zero-pad the fractional digits out to `prec` places.
  let fracStr: string = __float_int_part(fracf);
  while (fracStr.len() < prec) {
    fracStr = "0" + fracStr;
  }
  return out + "." + fracStr;
}

// `to_string_prec(prec)` — fixed-precision rendering with exactly
// `prec` fractional digits (rounded half away from zero). The
// precision-controlled counterpart to `to_string()`, for the
// width/precision table output (issue #2684).
```
