from pathlib import Path
import datetime
import gzip
import hashlib
import json
import os
import re
import subprocess
import time

p = Path(__file__).parent
root = p.parent
producer = root / 'main-b024-merge/stage1-current'
subject = p / 'source-after/compiler/checker.fern'
stdlib = p / 'source-after/internal/stdlib'
expected_producer = 'e744816112dd5727b225a093ea87c39e37df54ce3d0a145a4e2675784217f26b'
sha = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
assert sha(producer) == expected_producer
state_file = p / 'pipeline-state.json'
assert not state_file.exists()
state = dict(steps=[], complete=False, runner_pid=os.getpid())

def save():
    temporary = state_file.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(state_file)

def run(name, command, env, log):
    record = dict(name=name, command=command, started_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    state['steps'].append(record)
    started = time.perf_counter()
    with log.open('wb') as output:
        process = subprocess.Popen(command, env=env, stdout=output, stderr=subprocess.STDOUT)
        record['process_id'] = process.pid
        save()
        code = process.wait()
    record.update(exit=code, seconds=time.perf_counter() - started)
    save()
    print(json.dumps(record), flush=True)
    assert code == 0, name
    return record

def archive(file):
    raw = file.read_bytes()
    compressed = file.with_name(file.name + '.gz')
    assert not compressed.exists()
    packed = gzip.compress(raw, compresslevel=1, mtime=0)
    compressed.write_bytes(packed)
    assert gzip.decompress(compressed.read_bytes()) == raw
    record = dict(original=str(file), archive=str(compressed), raw_sha256=hashlib.sha256(raw).hexdigest(), archive_sha256=sha(compressed), raw_bytes=len(raw), restore_mode=file.stat().st_mode & 0o777)
    file.unlink()
    return record

outputs = {}
builds = {}
for version in ['before', 'after']:
    folder = p / version
    env = dict(os.environ, FERN_RC_CERTIFY_MEMO=str(folder / 'memo-build'), VALGRIND_LIB=str(root / 'tools/usr/libexec/valgrind'))
    builds[version] = []
    archives = []
    for name, flags in [('stage2', []), ('stage2-g', ['-g'])]:
        command = [str(producer), '-O'] + flags + ['-target', 'x86-64-linux', '-o', str(folder / name), str(p / ('source-' + version) / 'compiler/fern.fern'), str(stdlib)]
        record = run(version + '-' + name, command, env, folder / (name + '-build.log'))
        record.update(binary_sha256=sha(folder / name), common_producer_sha256=expected_producer)
        builds[version].append(record)
        (folder / 'builds.json').write_text(json.dumps(builds[version], indent=2) + '\n')
    with (folder / 'stage2-g.nm').open('wb') as output:
        subprocess.run(['nm', '-n', str(folder / 'stage2-g')], stdout=output, check=True)
    archives.append(archive(folder / 'stage2-g'))
    env['FERN_RC_CERTIFY_MEMO'] = str(folder / 'memo-profile')
    outputs[version] = []
    for target in ['x86-64-linux', 'arm64-linux', 'wasm32-wasi']:
        output = folder / ('checker-' + target + '.s')
        command = [str(folder / 'stage2'), '-O', '-target', target, '-emit', 'asm', '-o', str(output), str(subject), str(stdlib)]
        record = run(version + '-checker-' + target, command, env, folder / ('checker-' + target + '.log'))
        raw = output.read_bytes()
        assert len(raw) > 1_000_000
        record.update(target=target, sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw))
        if version == 'after':
            prior = gzip.decompress((p / 'before' / (output.name + '.gz')).read_bytes())
            assert prior == raw, target + ' output identity'
            record['byte_identical_to_before'] = True
        outputs[version].append(record)
        (folder / 'outputs.json').write_text(json.dumps(outputs[version], indent=2) + '\n')
        archives.append(archive(output))
    (folder / 'completed-output-archive.json').write_text(json.dumps(archives, indent=2) + '\n')
(p / 'output-identity.json').write_text(json.dumps(outputs['after'], indent=2) + '\n')

metrics = {}
for version in ['before', 'after']:
    folder = p / version
    env = dict(os.environ, FERN_RC_CERTIFY_MEMO=str(folder / 'memo-profile'), VALGRIND_LIB=str(root / 'tools/usr/libexec/valgrind'))
    command = [str(root / 'tools/usr/bin/time'), '-v', str(root / 'tools/usr/bin/valgrind'), '--tool=callgrind', '--callgrind-out-file=' + str(folder / 'stage2.callgrind'), str(folder / 'stage2'), '-O', '-target', 'x86-64-linux', '-emit', 'asm', '-o', '/dev/null', str(subject), str(stdlib)]
    record = run(version + '-full-profile', command, env, folder / 'stage2-profile.log')
    record.update(valid_full_run=True, instructions=int(re.search(r'Collected\s*:\s*(\d+)', (folder / 'stage2-profile.log').read_text())[1]), binary_sha256=sha(folder / 'stage2'), common_producer_sha256=expected_producer, subject_sha256=sha(subject), memo_warmed=True, artifact_generation='stage2', subject_output_sha256=outputs[version][0]['sha256'])
    (folder / 'stage2-profile.json').write_text(json.dumps(record, indent=2) + '\n')
    subprocess.run(['python3', str(folder / 'resolve-profile.py'), 'stage2'], check=True)
    text = (folder / 'stage2.callers.resolved').read_text()
    block = next(b for b in text.split('\n\n') if re.search(r'\*.*__fern_arr_box(?:\+[^ @]+)?@', b))
    record['box_calls'] = sum(int(x.replace(',', '')) for x in re.findall(r'\(([\d,]+)x\)', block))
    (folder / 'stage2-profile-metrics.json').write_text(json.dumps(record, indent=2) + '\n')
    metrics[version] = record

before, after = metrics['before'], metrics['after']
comparison = dict(before=before, after=after, instruction_delta=after['instructions'] - before['instructions'], instruction_reduction_percent=100 * (1 - after['instructions'] / before['instructions']), box_delta=after['box_calls'] - before['box_calls'], output_identity_3targets=True, note='Controlled integration batch for owner optimizations. New producer and fixed subject group; no sum with historical groups or native latency claim.')
(p / 'comparison.json').write_text(json.dumps(comparison, indent=2) + '\n')
state.update(complete=True, comparison='comparison.json')
save()
print(json.dumps({k: value for k, value in comparison.items() if k not in ['before', 'after']}), flush=True)
