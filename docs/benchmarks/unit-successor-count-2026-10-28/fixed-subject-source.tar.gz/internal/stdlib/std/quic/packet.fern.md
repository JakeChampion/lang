# Protected QUIC packets

This module reads, writes, encrypts, and decrypts QUIC packets.

## Model

Packet headers distinguish protocol versions and packet-number spaces. Packet protection combines payload encryption with a separate header-protection step.

## Contracts

Connection identifier lengths and initial datagram size have protocol limits. Opening a packet validates protection before it exposes the payload.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub const VERSION_1: i64>>

<<4 function __initial_salt(): u8[]>>

<<5 pub function keys(suite: keyschedule.CipherSuite, secret: [u8]): Keys>>

<<6 function __gcm(suite: keyschedule.CipherSuite, key: [u8]): Option[aes_gcm.Key]>>

<<7 pub function initial_secret(dcid: [u8], client: boolean): u8[]>>

<<8 function __cid_len(datagram: [u8], p: i32, max: i32, what: string): Result[i32, string]>>

<<9 pub function mask(k: Keys, sample: [u8]): u8[]>>

<<10 const ZERO_MASK: u8[]>>

<<11 function __seal(k: Keys, pn: i64, own packet: u8[], at: i32, n: i32): u8[]>>

<<12 pub struct Unprotected>>

<<13 pub function unprotect(datagram: [u8], h: Header, k: Keys, largest: i64): Result[Unprotected, string]>>

<<14 pub struct Long>>

<<15 pub function seal_long(l: Long, payload: [u8], k: Keys): u8[]>>

<<16 function __padded_len(len: i32, n: i32): i32>>

<<17 pub function version_negotiation(h: Header): u8[]>>

<<18 function __retry_key(): u8[]>>

<<19 pub function retry(dcid: [u8], scid: [u8], odcid: [u8], token: [u8]): u8[]>>

<<20 function __be32(buf: [u8], at: i32): i64>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module reads, writes, encrypts, and decrypts QUIC packets.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/quic/frames";
import "std/tls/keyschedule";
import "std/crypto/aes_gcm";
import "std/crypto/chacha20poly1305";
import "std/array";
import "std/i64";
import "std/u32";
```

### `3 pub const VERSION_1: i64`

```fern
<<3 pub const VERSION_1: i64>>=
pub const VERSION_1: i64 = 1;

pub const MIN_INITIAL_DATAGRAM: i32 = 1200;

pub const MAX_CID_LEN: i32 = 20;

pub const TAG_LEN: i32 = 16;

pub enum Kind { Initial, ZeroRtt, Handshake, Retry, OneRtt, VersionNegotiation, UnknownVersion }

pub struct Header { kind: Kind, version: i64, dcid: u8[], scid: u8[], token: u8[], tag: u8[], versions: i64[], at: i32, pn_at: i32, end: i32 }

pub struct Keys { suite: keyschedule.CipherSuite, secret: u8[], key: u8[], iv: u8[], hp: u8[], hp_round_keys: u8[], hp_chacha: Option[chacha20poly1305.Key], gcm: Option[aes_gcm.Key], chacha: Option[chacha20poly1305.Key] }

pub struct Opened { pn: i64, payload: u8[], key_phase: boolean, spin: boolean, reserved_ok: boolean }
```

### `4 function __initial_salt(): u8[]`

```fern
<<4 function __initial_salt(): u8[]>>=
function __initial_salt(): u8[] {
  return [56 as u8, 118 as u8, 44 as u8, 247 as u8, 245 as u8, 89 as u8, 52 as u8, 179 as u8, 77 as u8, 23 as u8, 154 as u8, 230 as u8, 164 as u8, 200 as u8, 12 as u8, 173 as u8, 204 as u8, 187 as u8, 127 as u8, 10 as u8];
}
```

### `5 pub function keys(suite: keyschedule.CipherSuite, secret: [u8]): Keys`

```fern
<<5 pub function keys(suite: keyschedule.CipherSuite, secret: [u8]): Keys>>=
pub function keys(suite: keyschedule.CipherSuite, secret: [u8]): Keys {
  let h: keyschedule.Hash = suite.hash();
  let n: i32 = suite.aead().key_len();
  let hp: u8[] = keyschedule.hkdf_expand_label(h, secret, "quic hp", [], n);
  let rk: u8[] = [];
  match (suite.aead()) {
    keyschedule.ChaCha20Poly1305 => {},
    _ => {
      rk = __aes_expand_key(hp);
    }
  }
  let key: u8[] = keyschedule.hkdf_expand_label(h, secret, "quic key", [], n);
  return Keys { suite: suite, secret: __copy(secret), key: key, iv: keyschedule.hkdf_expand_label(h, secret, "quic iv", [], 12), hp: hp, hp_round_keys: rk, hp_chacha: __chacha(suite, hp), gcm: __gcm(suite, key), chacha: __chacha(suite, key) };
}
```

### `6 function __gcm(suite: keyschedule.CipherSuite, key: [u8]): Option[aes_gcm.Key]`

```fern
<<6 function __gcm(suite: keyschedule.CipherSuite, key: [u8]): Option[aes_gcm.Key]>>=
function __gcm(suite: keyschedule.CipherSuite, key: [u8]): Option[aes_gcm.Key] {
  match (suite.aead()) {
    keyschedule.ChaCha20Poly1305 => {
      return None;
    },
    _ => {}
  }
  match (aes_gcm.key(key)) {
    Ok(k) => {
      return Some(k);
    },
    Err(_) => {
      return None;
    }
  }
}

function __chacha(suite: keyschedule.CipherSuite, key: [u8]): Option[chacha20poly1305.Key] {
  match (suite.aead()) {
    keyschedule.ChaCha20Poly1305 => {},
    _ => {
      return None;
    }
  }
  match (chacha20poly1305.key(key)) {
    Ok(k) => {
      return Some(k);
    },
    Err(_) => {
      return None;
    }
  }
}
```

### `7 pub function initial_secret(dcid: [u8], client: boolean): u8[]`

```fern
<<7 pub function initial_secret(dcid: [u8], client: boolean): u8[]>>=
pub function initial_secret(dcid: [u8], client: boolean): u8[] {
  let h: keyschedule.Hash = keyschedule.Sha256;
  let base: u8[] = keyschedule.hkdf_extract(h, __initial_salt(), dcid);
  if (client) {
    return keyschedule.hkdf_expand_label(h, base, "client in", [], 32);
  }
  return keyschedule.hkdf_expand_label(h, base, "server in", [], 32);
}

pub function initial_keys(dcid: [u8], client: boolean): Keys {
  return keys(keyschedule.Aes128GcmSha256, initial_secret(dcid, client));
}

pub function (k: Keys) updated(): Keys {
  let h: keyschedule.Hash = k.suite.hash();
  let secret: u8[] = keyschedule.hkdf_expand_label(h, k.secret, "quic ku", [], h.size());
  let n: i32 = k.suite.aead().key_len();
  let key: u8[] = keyschedule.hkdf_expand_label(h, secret, "quic key", [], n);
  return Keys { ...k, secret: secret, key: key, iv: keyschedule.hkdf_expand_label(h, secret, "quic iv", [], 12), gcm: __gcm(k.suite, key), chacha: __chacha(k.suite, key) };
}

pub function pn_len(pn: i64, largest_acked: i64): i32 {
  let unacked: i64 = pn - largest_acked;
  if (largest_acked < 0) {
    unacked = pn + 1;
  }
  if (unacked < 128) {
    return 1;
  }
  if (unacked < 32768) {
    return 2;
  }
  if (unacked < 8388608) {
    return 3;
  }
  return 4;
}

pub function decode_pn(largest: i64, truncated: i64, bits: i32): i64 {
  let expected: i64 = largest + 1;
  let win: i64 = 1 as i64 << bits as i64;
  let hwin: i64 = win / 2;
  let candidate: i64 = expected - (expected & win - 1) | truncated;
  if (candidate <= expected - hwin && candidate < (1 as i64 << 62) - win) {
    return candidate + win;
  }
  if (candidate > expected + hwin && candidate >= win) {
    return candidate - win;
  }
  return candidate;
}

pub function parse(datagram: [u8], at: i32, short_dcid_len: i32): Result[Header, string] {
  if (at >= datagram.len()) {
    return Err("first byte cut short");
  }
  let b0: i32 = datagram[at] as i32;
  if ((b0 & 128) == 0) {
    return __short(datagram, b0, at, short_dcid_len);
  }
  if (at + 5 > datagram.len()) {
    return Err("version cut short");
  }
  let version: i64 = __be32(datagram, at + 1);
  let max: i32 = MAX_CID_LEN;
  if (version != VERSION_1) {
    max = 255;
  }
  let dl: i32 = __cid_len(datagram, at + 5, max, "destination connection id")?;
  let dcid_at: i32 = at + 6;
  let sl: i32 = __cid_len(datagram, dcid_at + dl, max, "source connection id")?;
  let scid_at: i32 = dcid_at + dl + 1;
  let rest: i32 = scid_at + sl;
  let h: Header = Header { kind: UnknownVersion, version: version, dcid: __slice(datagram, dcid_at, dcid_at + dl), scid: __slice(datagram, scid_at, scid_at + sl), token: [], tag: [], versions: [], at: at, pn_at: rest, end: datagram.len() };
  if (version == 0) {
    return __version_negotiation(h, datagram, rest);
  }
  if (version != VERSION_1) {
    return Ok(h);
  }
  return __long(h, datagram, b0, rest);
}
```

### `8 function __cid_len(datagram: [u8], p: i32, max: i32, what: string): Result[i32, string]`

```fern
<<8 function __cid_len(datagram: [u8], p: i32, max: i32, what: string): Result[i32, string]>>=
function __cid_len(datagram: [u8], p: i32, max: i32, what: string): Result[i32, string] {
  if (p >= datagram.len()) {
    return Err(what + " length cut short");
  }
  let n: i32 = datagram[p] as i32;
  if (n > max) {
    return Err(what + " of " + n.to_string() + " bytes");
  }
  if (p + 1 + n > datagram.len()) {
    return Err(what + " cut short");
  }
  return Ok(n);
}

function __short(datagram: [u8], b0: i32, at: i32, dcid_len: i32): Result[Header, string] {
  if ((b0 & 64) == 0) {
    return Err("fixed bit not set");
  }
  if (dcid_len < 0 || at + 1 + dcid_len > datagram.len()) {
    return Err("destination connection id cut short");
  }
  return Ok(Header { kind: OneRtt, version: VERSION_1, dcid: __slice(datagram, at + 1, at + 1 + dcid_len), scid: [], token: [], tag: [], versions: [], at: at, pn_at: at + 1 + dcid_len, end: datagram.len() });
}

function __version_negotiation(h: Header, datagram: [u8], at: i32): Result[Header, string] {
  let left: i32 = datagram.len() - at;
  if (left == 0 || left % 4 != 0) {
    return Err("version negotiation of " + left.to_string() + " bytes of versions");
  }
  let versions: i64[] = [];
  let p: i32 = at;
  while (p < datagram.len()) {
    versions = versions.append(__be32(datagram, p));
    p = p + 4;
  }
  return Ok(Header { ...h, kind: VersionNegotiation, versions: versions, pn_at: datagram.len() });
}

function __long(h: Header, datagram: [u8], b0: i32, at: i32): Result[Header, string] {
  if ((b0 & 64) == 0) {
    return Err("fixed bit not set");
  }
  let kind: i32 = b0 >> 4 & 3;
  if (kind == 3) {
    return __retry_header(h, datagram, at);
  }
  let k: Kind = Initial;
  let p: i32 = at;
  if (kind == 0) {
    let n: i64 = frames.varint_at(datagram, p);
    if (n < 0) {
      return Err("token length cut short");
    }
    let token_at: i32 = frames.varint_end(datagram, p);
    if (n > (datagram.len() - token_at) as i64) {
      return Err("token cut short");
    }
    p = token_at + n as i32;
    h = Header { ...h, token: __slice(datagram, token_at, p) };
  } else if (kind == 1) {
    k = ZeroRtt;
  } else {
    k = Handshake;
  }
  let len: i64 = frames.varint_at(datagram, p);
  if (len < 0) {
    return Err("length cut short");
  }
  let body: i32 = frames.varint_end(datagram, p);
  if (len > (datagram.len() - body) as i64) {
    return Err("packet of " + len.to_string() + " bytes past the end of the datagram");
  }
  return Ok(Header { ...h, kind: k, pn_at: body, end: body + len as i32 });
}

function __retry_header(h: Header, datagram: [u8], at: i32): Result[Header, string] {
  let rest: i32 = datagram.len() - at - TAG_LEN;
  if (rest < 1) {
    return Err("retry without a token");
  }
  return Ok(Header { ...h, kind: Retry, token: __slice(datagram, at, at + rest), tag: __slice(datagram, at + rest, datagram.len()), pn_at: datagram.len() });
}
```

### `9 pub function mask(k: Keys, sample: [u8]): u8[]`

```fern
<<9 pub function mask(k: Keys, sample: [u8]): u8[]>>=
pub function mask(k: Keys, sample: [u8]): u8[] {
  match (k.suite.aead()) {
    keyschedule.ChaCha20Poly1305 => {
      let counter: u32 = sample[0] as u32 | sample[1] as u32 << 8 | sample[2] as u32 << 16 | sample[3] as u32 << 24;
      let Some(hp) = k.hp_chacha else {
        return __copy(ZERO_MASK);
      };
      match (hp.chacha20_xor(sample[4:16], counter, ZERO_MASK)) {
        Ok(m) => {
          return m;
        },
        Err(_) => {
          return __copy(ZERO_MASK);
        }
      }
    },
    _ => {
      return __aes_ctr32(k.hp_round_keys, sample[0:16], ZERO_MASK);
    }
  }
}
```

### `10 const ZERO_MASK: u8[]`

```fern
<<10 const ZERO_MASK: u8[]>>=
const ZERO_MASK: u8[] = [0, 0, 0, 0, 0];
```

### `11 function __seal(k: Keys, pn: i64, own packet: u8[], at: i32, n: i32): u8[]`

```fern
<<11 function __seal(k: Keys, pn: i64, own packet: u8[], at: i32, n: i32): u8[]>>=
// Seals packet[at:at + n] in place under the nonce iv ^ pn, the header packet[0:at] its additional data and the tag
// behind it; an empty packet when the keys do not fit the suite.
function __seal(k: Keys, pn: i64, own packet: u8[], at: i32, n: i32): u8[] {
  match (k.suite.aead()) {
    keyschedule.ChaCha20Poly1305 => {
      let Some(c) = k.chacha else {
        return [];
      };
      match (c.seal_in_place(k.iv, pn as u64, packet, 0, at, at, n)) {
        Ok(sealed) => {
          return sealed;
        },
        Err(_) => {
          return [];
        }
      }
    },
    _ => {
      let Some(g) = k.gcm else {
        return [];
      };
      match (g.seal_in_place(k.iv, pn as u64, packet, 0, at, at, n)) {
        Ok(sealed) => {
          return sealed;
        },
        Err(_) => {
          return [];
        }
      }
    }
  }
}

// Opens buf[0:n] in place, the tag behind it and the header, the additional data, behind the tag.
function __open(k: Keys, pn: i64, own buf: u8[], n: i32): Option[u8[]] {
  let aad_n: i32 = buf.len() - n - 16;
  match (k.suite.aead()) {
    keyschedule.ChaCha20Poly1305 => {
      let Some(c) = k.chacha else {
        return None;
      };
      match (c.open_in_place(k.iv, pn as u64, buf, n + 16, aad_n, 0, n)) {
        Ok(pt) => {
          __arr_set_len(pt, n);
          return Some(pt);
        },
        Err(_) => {
          return None;
        }
      }
    },
    _ => {
      let Some(g) = k.gcm else {
        return None;
      };
      match (g.open_in_place(k.iv, pn as u64, buf, n + 16, aad_n, 0, n)) {
        Ok(pt) => {
          __arr_set_len(pt, n);
          return Some(pt);
        },
        Err(_) => {
          return None;
        }
      }
    }
  }
}
```

### `12 pub struct Unprotected`

```fern
<<12 pub struct Unprotected>>=
pub struct Unprotected { header: u8[], body_at: i32, pn: i64, key_phase: boolean, spin: boolean, reserved_ok: boolean }
```

### `13 pub function unprotect(datagram: [u8], h: Header, k: Keys, largest: i64): Result[Unprotected, string]`

```fern
<<13 pub function unprotect(datagram: [u8], h: Header, k: Keys, largest: i64): Result[Unprotected, string]>>=
pub function unprotect(datagram: [u8], h: Header, k: Keys, largest: i64): Result[Unprotected, string] {
  if (h.pn_at + 4 + 16 > h.end) {
    return Err("packet too short to sample");
  }
  let m: u8[] = mask(k, datagram[h.pn_at + 4:h.pn_at + 20]);
  let long: boolean = (datagram[h.at] as i32 & 128) != 0;
  let low: i32 = 31;
  if (long) {
    low = 15;
  }
  let b0: i32 = datagram[h.at] as i32 ^ m[0] as i32 & low;
  let n: i32 = (b0 & 3) + 1;
  let header: u8[] = __slice(datagram, h.at, h.pn_at + n);
  header = header.with(0, b0 as u8);
  let truncated: i64 = 0;
  let i: i32 = 0;
  while (i < n) {
    let at: i32 = h.pn_at - h.at + i;
    let b: u8 = (header[at] as i32 ^ m[1 + i] as i32) as u8;
    header = header.with(at, b);
    truncated = truncated << 8 | b as i64;
    i = i + 1;
  }
  let pn: i64 = decode_pn(largest, truncated, n * 8);
  let reserved: i32 = 24;
  if (long) {
    reserved = 12;
  }
  return Ok(Unprotected { header: header, body_at: h.pn_at + n, pn: pn, key_phase: (b0 & 4) != 0, spin: (b0 & 32) != 0, reserved_ok: (b0 & reserved) == 0 });
}

pub function open_unprotected(datagram: [u8], h: Header, u: Unprotected, k: Keys): Result[Opened, string] {
  let sealed: i32 = h.end - u.body_at;
  if (sealed < 16) {
    return Err("packet does not decrypt");
  }
  let buf: u8[] = __bytes_into(__bytes_into(__alloc_u8(sealed + u.header.len()), 0, datagram, u.body_at, sealed), sealed, u.header, 0, u.header.len());
  match (__open(k, u.pn, buf, sealed - 16)) {
    Some(payload) => {
      return Ok(Opened { pn: u.pn, payload: payload, key_phase: u.key_phase, spin: u.spin, reserved_ok: u.reserved_ok });
    },
    None => {
      return Err("packet does not decrypt");
    }
  }
}

pub function open(datagram: [u8], h: Header, k: Keys, largest: i64): Result[Opened, string] {
  let u: Unprotected = unprotect(datagram, h, k, largest)?;
  return open_unprotected(datagram, h, u, k);
}
```

### `14 pub struct Long`

```fern
<<14 pub struct Long>>=
pub struct Long { kind: Kind, dcid: u8[], scid: u8[], token: u8[], pn: i64, pn_len: i32 }
```

### `15 pub function seal_long(l: Long, payload: [u8], k: Keys): u8[]`

```fern
<<15 pub function seal_long(l: Long, payload: [u8], k: Keys): u8[]>>=
pub function seal_long(l: Long, payload: [u8], k: Keys): u8[] {
  let blen: i32 = __padded_len(payload.len(), l.pn_len);
  let kind: i32 = 0;
  match (l.kind) {
    ZeroRtt => {
      kind = 1;
    },
    Handshake => {
      kind = 2;
    },
    _ => {}
  }
  let head: u8[] = __empty(32 + l.dcid.len() + l.scid.len() + l.token.len() + blen + TAG_LEN);
  head = head.append((192 | kind << 4 | l.pn_len - 1) as u8);
  head = __put_be32(head, VERSION_1);
  head = head.append(l.dcid.len() as u8).concat(l.dcid).append(l.scid.len() as u8).concat(l.scid);
  if (kind == 0) {
    head = frames.put_varint(head, l.token.len() as i64).concat(l.token);
  }
  head = frames.put_varint(head, (l.pn_len + blen + 16) as i64);
  let pn_at: i32 = head.len();
  return __protect(__put_pn(head, l.pn, l.pn_len), pn_at, l.pn, l.pn_len, payload, blen, k, 15);
}

pub function seal_short(dcid: [u8], pn: i64, n: i32, key_phase: boolean, spin: boolean, payload: [u8], k: Keys): u8[] {
  let blen: i32 = __padded_len(payload.len(), n);
  let b0: i32 = 64 | n - 1;
  if (key_phase) {
    b0 = b0 | 4;
  }
  if (spin) {
    b0 = b0 | 32;
  }
  let pn_at: i32 = 1 + dcid.len();
  let head: u8[] = __empty(pn_at + n + blen + TAG_LEN).append(b0 as u8);
  __arr_set_len(head, pn_at);
  head = __bytes_into(head, 1, dcid, 0, dcid.len());
  return __protect(__put_pn(head, pn, n), pn_at, pn, n, payload, blen, k, 31);
}
```

### `16 function __padded_len(len: i32, n: i32): i32`

```fern
<<16 function __padded_len(len: i32, n: i32): i32>>=
// A payload is padded so the packet number and the payload give the header protection's sample four bytes.
function __padded_len(len: i32, n: i32): i32 {
  if (len + n < 4) {
    return 4 - n;
  }
  return len;
}

// Seals the payload, padded to blen, behind the header in the header's own buffer, which has room for the
// payload and the tag.
function __protect(own packet: u8[], pn_at: i32, pn: i64, n: i32, payload: [u8], blen: i32, k: Keys, low: i32): u8[] {
  let at: i32 = packet.len();
  __arr_set_len(packet, at + blen + TAG_LEN);
  packet = __bytes_into(packet, at, payload, 0, payload.len());
  for i in at + payload.len()..at + blen {
    packet = packet.with(i, 0 as u8);
  }
  packet = __seal(k, pn, packet, at, blen);
  let m: u8[] = mask(k, packet[pn_at + 4:pn_at + 20]);
  packet = packet.with(0, (packet[0] as i32 ^ m[0] as i32 & low) as u8);
  let i: i32 = 0;
  while (i < n) {
    packet = packet.with(pn_at + i, (packet[pn_at + i] as i32 ^ m[1 + i] as i32) as u8);
    i = i + 1;
  }
  return packet;
}
```

### `17 pub function version_negotiation(h: Header): u8[]`

```fern
<<17 pub function version_negotiation(h: Header): u8[]>>=
pub function version_negotiation(h: Header): u8[] {
  let out: u8[] = __empty(64).append(192 as u8);
  out = __put_be32(out, 0 as i64);
  out = out.append(h.scid.len() as u8).concat(h.scid).append(h.dcid.len() as u8).concat(h.dcid);
  return __put_be32(out, VERSION_1);
}
```

### `18 function __retry_key(): u8[]`

```fern
<<18 function __retry_key(): u8[]>>=
function __retry_key(): u8[] {
  return [190 as u8, 12 as u8, 105 as u8, 11 as u8, 159 as u8, 102 as u8, 87 as u8, 90 as u8, 29 as u8, 118 as u8, 107 as u8, 84 as u8, 227 as u8, 104 as u8, 200 as u8, 78 as u8];
}

function __retry_nonce(): u8[] {
  return [70 as u8, 21 as u8, 153 as u8, 211 as u8, 93 as u8, 99 as u8, 43 as u8, 242 as u8, 35 as u8, 152 as u8, 37 as u8, 187 as u8];
}

function __retry_tag(unprotected: [u8], odcid: [u8]): u8[] {
  let pseudo: u8[] = __empty(64).append(odcid.len() as u8).concat(__copy(odcid)).concat(__copy(unprotected));
  let Ok(k) = aes_gcm.key(__retry_key()) else {
    return [];
  };
  match (k.seal(__retry_nonce(), [], pseudo)) {
    Ok(tag) => {
      return tag;
    },
    Err(_) => {
      return [];
    }
  }
}
```

### `19 pub function retry(dcid: [u8], scid: [u8], odcid: [u8], token: [u8]): u8[]`

```fern
<<19 pub function retry(dcid: [u8], scid: [u8], odcid: [u8], token: [u8]): u8[]>>=
pub function retry(dcid: [u8], scid: [u8], odcid: [u8], token: [u8]): u8[] {
  let out: u8[] = __empty(64).append(255 as u8);
  out = __put_be32(out, VERSION_1);
  out = out.append(dcid.len() as u8).concat(__copy(dcid)).append(scid.len() as u8).concat(__copy(scid)).concat(__copy(token));
  return out.concat(__retry_tag(out, odcid));
}

pub function retry_valid(packet: [u8], odcid: [u8]): boolean {
  if (packet.len() < TAG_LEN + 7) {
    return false;
  }
  let at: i32 = packet.len() - TAG_LEN;
  let want: u8[] = __retry_tag(packet[0:at], odcid);
  let diff: i32 = 0;
  let i: i32 = 0;
  while (i < TAG_LEN) {
    diff = diff | want[i] as i32 ^ packet[at + i] as i32;
    i = i + 1;
  }
  return want.len() == TAG_LEN && diff == 0;
}
```

### `20 function __be32(buf: [u8], at: i32): i64`

```fern
<<20 function __be32(buf: [u8], at: i32): i64>>=
function __be32(buf: [u8], at: i32): i64 {
  return buf[at] as i64 << 24 | buf[at + 1] as i64 << 16 | buf[at + 2] as i64 << 8 | buf[at + 3] as i64;
}

function __put_be32(own out: u8[], v: i64): u8[] {
  return out.append((v >> 24 & 255) as u8).append((v >> 16 & 255) as u8).append((v >> 8 & 255) as u8).append((v & 255) as u8);
}

function __put_pn(own out: u8[], pn: i64, n: i32): u8[] {
  let i: i32 = n;
  while (i > 0) {
    i = i - 1;
    out = out.append((pn >> (i * 8) as i64 & 255) as u8);
  }
  return out;
}

function __empty(room: i32): u8[] {
  let out: u8[] = __alloc_u8(room);
  __arr_set_len(out, 0);
  return out;
}

function __copy(b: [u8]): u8[] {
  return __bytes_owned(b);
}

function __slice(buf: [u8], from: i32, to: i32): u8[] {
  return __bytes_range(buf, from, to);
}
```
