# Ranges, numeric constants, and RGB values

This module provides random integers, integer ranges, numeric constants, and RGB operations.

## Model

Range helpers construct integer sequences. Numeric helpers expose constants and angle conversion. RGB helpers use packed color values.

## Contracts

The text color parser returns an option for invalid input. Random integer generation uses the runtime source and has a different contract from deterministic ranges.

## Executable example

```fern test name=std-math-example
import "std/math";

function main(): i32 {
  let xs = math.range(2, 5);
  if (xs.len() != 3 || xs[0] != 2 || xs[2] != 4) { return 1; }
  return 0;
}
```

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<2 pub function random_int(lo: i32, hi: i32): i32>>

<<3 function __random_u32(): u32>>

<<4 pub function range(start: i32, end: i32): i32[]>>

<<5 function __hex_digit(b: i32): i32>>

<<6 pub function parse_rgb_hex(s: string): Option[i32]>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module provides random integers, integer ranges, numeric constants, and RGB operations.
```

### `2 pub function random_int(lo: i32, hi: i32): i32`

```fern
<<2 pub function random_int(lo: i32, hi: i32): i32>>=
pub function random_int(lo: i32, hi: i32): i32 {
  if (hi <= lo) {
    return lo;
  }
  let range: u32 = (hi - lo) as u32;
  return lo + __random_below(range) as i32;
}
```

### `3 function __random_u32(): u32`

```fern
<<3 function __random_u32(): u32>>=
function __random_u32(): u32 {
  let b: u8[] = random_bytes(4);
  return b[0] as u32 << 24 as u32
    | b[1] as u32 << 16 as u32
    | b[2] as u32 << 8 as u32
    | b[3] as u32;
}

function __random_below(range: u32): u32 {
  let wide: u64 = range as u64;
  let mask: u64 = (1 as u64 << 32 as u64) - 1 as u64;
  let product: u64 = __random_u32() as u64 * wide;
  let low: u64 = product & mask;
  if (low < wide) {
    let threshold: u64 = ((1 as u64 << 32 as u64) - wide) % wide;
    while (low < threshold) {
      product = __random_u32() as u64 * wide;
      low = product & mask;
    }
  }
  return (product >> 32 as u64) as u32;
}
```

### `4 pub function range(start: i32, end: i32): i32[]`

```fern
<<4 pub function range(start: i32, end: i32): i32[]>>=
pub function range(start: i32, end: i32): i32[] {
  let out: i32[] = [];
  let i: i32 = start;
  while (i < end) {
    out = out.append(i);
    i = i + 1;
  }
  return out;
}

pub function range_step(start: i32, end: i32, step: i32): i32[] {
  let out: i32[] = [];
  if (step <= 0) {
    return out;
  }
  let i: i32 = start;
  while (i < end) {
    out = out.append(i);
    i = i + step;
  }
  return out;
}

pub function i32_max(): i32 {
  return 2147483647;
}

pub function i32_min(): i32 {
  return 0 - 2147483647 - 1;
}

pub function i64_max(): i64 {
  return 9223372036854775807;
}

pub function i64_min(): i64 {
  return 0 as i64 - 9223372036854775807 - 1 as i64;
}

pub function pi(): f64 {
  return 3.141592653589793;
}

pub function tau(): f64 {
  return 6.283185307179586;
}

pub function to_radians(deg: f64): f64 {
  return deg * (pi() / 180.0);
}

pub function to_degrees(rad: f64): f64 {
  return rad * (180.0 / pi());
}

pub function lerp(a: f64, b: f64, t: f64): f64 {
  return a * (1.0 - t) + b * t;
}

pub function pack_rgb(r: i32, g: i32, b: i32): i32 {
  return (r & 255) << 16 | (g & 255) << 8 | b & 255;
}
```

### `5 function __hex_digit(b: i32): i32`

```fern
<<5 function __hex_digit(b: i32): i32>>=
function __hex_digit(b: i32): i32 {
  if (b >= 48 && b <= 57) {
    return b - 48;
  }
  if (b >= 97 && b <= 102) {
    return b - 97 + 10;
  }
  if (b >= 65 && b <= 70) {
    return b - 65 + 10;
  }
  return -1;
}
```

### `6 pub function parse_rgb_hex(s: string): Option[i32]`

```fern
<<6 pub function parse_rgb_hex(s: string): Option[i32]>>=
pub function parse_rgb_hex(s: string): Option[i32] {
  let start: i32 = 0;
  if (s.len() > 0 && s[0] == 35) {
    start = 1;
  }
  let body: i32 = s.len() - start;
  if (body == 6) {
    let v: i32 = 0;
    let i: i32 = 0;
    while (i < 6) {
      let d: i32 = __hex_digit(s[start + i] as i32);
      if (d < 0) {
        return None;
      }
      v = v << 4 | d;
      i = i + 1;
    }
    return Some(v);
  }
  if (body == 3) {
    let r: i32 = __hex_digit(s[start] as i32);
    let g: i32 = __hex_digit(s[start + 1] as i32);
    let b: i32 = __hex_digit(s[start + 2] as i32);
    if (r < 0 || g < 0 || b < 0) {
      return None;
    }
    return Some((r << 4 | r) << 16 | (g << 4 | g) << 8 | (b << 4 | b));
  }
  return None;
}

pub function rgb_luminance(rgb: i32): i32 {
  let r: i32 = rgb >> 16 & 255;
  let g: i32 = rgb >> 8 & 255;
  let b: i32 = rgb & 255;
  return (r * 299 + g * 587 + b * 114) / 1000;
}

pub function rgb_is_dark(rgb: i32): boolean {
  return rgb_luminance(rgb) < 128;
}
```
