# HTTP authentication helpers

This module authenticates HTTP requests with bearer tokens or Basic credentials.

## Model

Bearer and Basic wrappers separate credential extraction from application verification. A verification callback returns an optional user value.

## Contracts

Only a verified user reaches the next handler. A credential parser does not establish trust by itself. `token_eq` provides a dedicated token comparison.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub function bearer[U](req: HttpRequest, verify: (string)>>

<<4 function __has_control(bytes: u8[]): boolean>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module authenticates HTTP requests with bearer tokens or Basic credentials.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/http";
import "std/base64";
import "std/string";
import "std/utf8";
```

### `3 pub function bearer[U](req: HttpRequest, verify: (string)`

```fern
<<3 pub function bearer[U](req: HttpRequest, verify: (string)>>=
pub function bearer[U](req: HttpRequest, verify: (string) => Option[U], next: (U) => Result[HttpResponse, dyn http.ToResponse]): Result[HttpResponse, dyn http.ToResponse] {
  match (credential(req, "Bearer")) {
    Some(token) => {
      if (!__token68(token)) {
        return Ok(__challenge(400, "the bearer token is malformed", "Bearer error=\"invalid_request\""));
      }
      match (verify(token)) {
        Some(user) => {
          return next(user);
        },
        None => {
          return Ok(__challenge(401, "the bearer token was not accepted", "Bearer error=\"invalid_token\""));
        }
      }
    },
    None => {
      return Ok(__challenge(401, "a bearer token is required", "Bearer"));
    }
  }
  return Ok(__challenge(401, "a bearer token is required", "Bearer"));
}

pub function basic[U](req: HttpRequest, realm: string, verify: (string, string) => Option[U], next: (U) => Result[HttpResponse, dyn http.ToResponse]): Result[HttpResponse, dyn http.ToResponse] {
  let challenge: string = "Basic realm=\"" + __quoted(realm) + "\", charset=\"UTF-8\"";
  match (credential(req, "Basic")) {
    Some(encoded) => {
      match (__user_pass(encoded)) {
        Some(pair) => {
          match (verify(pair.0, pair.1)) {
            Some(user) => {
              return next(user);
            },
            None => {
              return Ok(__challenge(401, "the credentials were not accepted", challenge));
            }
          }
        },
        None => {
          return Ok(__challenge(400, "the basic credential is malformed", challenge));
        }
      }
    },
    None => {
      return Ok(__challenge(401, "credentials are required", challenge));
    }
  }
  return Ok(__challenge(401, "credentials are required", challenge));
}

pub function credential(req: HttpRequest, scheme: string): Option[string] {
  match (req.headers.get("authorization")) {
    Some(v) => {
      let value: string = v.trim();
      if (value.len() <= scheme.len() + 1 || !value.starts_with_ci(scheme) || value[scheme.len()] != b' ') {
        return None;
      }
      let rest: string = value.slice_snap(scheme.len() + 1, value.len()).trim();
      if (rest.len() == 0) {
        return None;
      }
      return Some(rest);
    },
    None => {
      return None;
    }
  }
  return None;
}

pub function token_eq(a: string, b: string): boolean {
  if (a.len() != b.len()) {
    return false;
  }
  let diff: i32 = 0;
  let i: i32 = 0;
  while (i < a.len()) {
    let x: i32 = a[i] as i32;
    let y: i32 = b[i] as i32;
    diff = diff | x ^ y;
    i = i + 1;
  }
  return diff == 0;
}
```

### `4 function __has_control(bytes: u8[]): boolean`

```fern
<<4 function __has_control(bytes: u8[]): boolean>>=
function __has_control(bytes: u8[]): boolean {
  for b in bytes {
    if (b < 32 || b == 127) {
      return true;
    }
  }
  return false;
}

function __challenge(status: i32, detail: string, challenge: string): HttpResponse {
  return http.problem(status, "", detail).with_header("WWW-Authenticate", challenge);
}

function __user_pass(encoded: string): Option[(string, string)] {
  match (base64.decode(encoded)) {
    Ok(bytes) => {
      match (utf8.from_bytes(bytes)) {
        Some(text) => {
          let Some(colon) = text.index_of(":") else {
            return None;
          };
          if (__has_control(bytes)) {
            return None;
          }
          return Some((text.slice_snap(0, colon), text.slice_snap(colon + 1, text.len())));
        },
        None => {
          return None;
        }
      }
    },
    Err(_) => {
      return None;
    }
  }
  return None;
}

function __token68(s: string): boolean {
  let i: i32 = 0;
  while (i < s.len() && __token68_byte(s[i] as i32)) {
    i = i + 1;
  }
  if (i == 0) {
    return false;
  }
  while (i < s.len()) {
    if (s[i] != b'=') {
      return false;
    }
    i = i + 1;
  }
  return true;
}

function __token68_byte(c: i32): boolean {
  return __alnum(c) || c == 45 || c == 46 || c == 95 || c == 126 || c == 43 || c == 47;
}

function __alnum(c: i32): boolean {
  return c >= 48 && c <= 57 || c >= 65 && c <= 90 || c >= 97 && c <= 122;
}

function __quoted(s: string): string {
  let out: u8[] = [];
  for b in s.bytes() {
    if (b == b'"' || b == b'\\') {
      out = out.append(b'\\');
    }
    out = out.append(b);
  }
  return string_from_bytes_unchecked(out);
}
```
