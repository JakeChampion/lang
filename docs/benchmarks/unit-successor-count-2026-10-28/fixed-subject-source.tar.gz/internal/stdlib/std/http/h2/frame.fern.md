# HTTP/2 frame representations

This module reads and writes HTTP/2 frames under RFC 9113.

## Model

Frame helpers separate the fixed frame header from type-specific payloads. Public constants identify frame kinds, settings, error codes, and protocol limits.

## Contracts

Payload validation depends on frame kind, flags, and stream identifier. The nine-byte frame header carries the payload length separately from that payload.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub const DATA: i32>>

<<4 pub function preface(): u8[]>>

<<5 pub struct Priority>>

<<6 pub function (e: FrameError) to_string(): string>>

<<7 impl error.Error for FrameError>>

<<8 pub function (e: FrameError) message(): string>>

<<9 function __connection(code: i32, reason: string): FrameError>>

<<10 pub enum Read>>

<<11 pub function read(buf: u8[], from: i32, max_frame: i32): Result[Read, FrameError]>>

<<12 function __frame(kind: i32, flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError]>>

<<13 function __setting(id: i32, value: i32): Result[Setting, FrameError]>>

<<14 pub function encode(f: Frame): u8[]>>

<<15 function __encode_rest(f: Frame): u8[]>>

<<16 pub function header_into(own out: u8[], at: i32, kind: i32, flags: i32, stream: i32, len: i32): u8[]>>

<<17 pub const BLOCK_ROOM: i32>>

<<18 pub function headers_room(data_len: i32): u8[]>>

<<19 function __priority_bytes(p: Priority): u8[]>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module reads and writes HTTP/2 frames under RFC 9113.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "core/int";
import "std/array";
import "std/string";
import "std/error";
import "core/cmp";
```

### `3 pub const DATA: i32`

```fern
<<3 pub const DATA: i32>>=
pub const DATA: i32 = 0;

pub const HEADERS: i32 = 1;

pub const PRIORITY: i32 = 2;

pub const RST_STREAM: i32 = 3;

pub const SETTINGS: i32 = 4;

pub const PUSH_PROMISE: i32 = 5;

pub const PING: i32 = 6;

pub const GOAWAY: i32 = 7;

pub const WINDOW_UPDATE: i32 = 8;

pub const CONTINUATION: i32 = 9;

pub const NO_ERROR: i32 = 0;

pub const PROTOCOL_ERROR: i32 = 1;

pub const INTERNAL_ERROR: i32 = 2;

pub const FLOW_CONTROL_ERROR: i32 = 3;

pub const SETTINGS_TIMEOUT: i32 = 4;

pub const STREAM_CLOSED: i32 = 5;

pub const FRAME_SIZE_ERROR: i32 = 6;

pub const REFUSED_STREAM: i32 = 7;

pub const CANCEL: i32 = 8;

pub const COMPRESSION_ERROR: i32 = 9;

pub const CONNECT_ERROR: i32 = 10;

pub const ENHANCE_YOUR_CALM: i32 = 11;

pub const INADEQUATE_SECURITY: i32 = 12;

pub const HTTP_1_1_REQUIRED: i32 = 13;

pub const SETTINGS_HEADER_TABLE_SIZE: i32 = 1;

pub const SETTINGS_ENABLE_PUSH: i32 = 2;

pub const SETTINGS_MAX_CONCURRENT_STREAMS: i32 = 3;

pub const SETTINGS_INITIAL_WINDOW_SIZE: i32 = 4;

pub const SETTINGS_MAX_FRAME_SIZE: i32 = 5;

pub const SETTINGS_MAX_HEADER_LIST_SIZE: i32 = 6;

pub const MIN_FRAME_SIZE: i32 = 16384;

pub const MAX_FRAME_SIZE: i32 = 16777215;

pub const MAX_WINDOW: i32 = 2147483647;

pub const HEADER_LEN: i32 = 9;
```

### `4 pub function preface(): u8[]`

```fern
<<4 pub function preface(): u8[]>>=
pub function preface(): u8[] {
  return "PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n".bytes();
}
```

### `5 pub struct Priority`

```fern
<<5 pub struct Priority>>=
pub struct Priority { exclusive: boolean, dependency: i32, weight: i32 }

pub struct Setting { id: i32, value: i32 }

pub enum Frame {
  Data(DataFrame),
  Headers(HeadersFrame),
  PriorityFrame(i32, Priority),
  RstStream(i32, i32),
  Settings(boolean, Setting[]),
  PushPromise(PushPromiseFrame),
  Ping(boolean, u8[]),
  GoAway(GoAwayFrame),
  WindowUpdate(i32, i32),
  Continuation(i32, boolean, u8[]),
  Unknown(UnknownFrame),
}

pub struct DataFrame { stream: i32, end_stream: boolean, data: u8[], padding: i32 }

pub struct HeadersFrame { stream: i32, end_stream: boolean, end_headers: boolean, priority: Option[Priority], block: u8[], padding: i32 }

pub struct PushPromiseFrame { stream: i32, promised: i32, end_headers: boolean, block: u8[] }

pub struct GoAwayFrame { last_stream: i32, code: i32, debug: u8[] }

pub struct UnknownFrame { kind: i32, flags: i32, stream: i32, payload: u8[] }

pub struct FrameError { code: i32, stream: i32, reason: string }
```

### `6 pub function (e: FrameError) to_string(): string`

```fern
<<6 pub function (e: FrameError) to_string(): string>>=
pub function (e: FrameError) to_string(): string {
  return e.message();
}
```

### `7 impl error.Error for FrameError`

```fern
<<7 impl error.Error for FrameError>>=
impl error.Error for FrameError {}

impl cmp.Display for FrameError {}
```

### `8 pub function (e: FrameError) message(): string`

```fern
<<8 pub function (e: FrameError) message(): string>>=
pub function (e: FrameError) message(): string {
  if (e.stream == 0) {
    return "h2 frame: connection error " + int.int_to_string(e.code) + ": " + e.reason;
  }
  return "h2 frame: stream " + int.int_to_string(e.stream) + " error " + int.int_to_string(e.code) + ": " + e.reason;
}
```

### `9 function __connection(code: i32, reason: string): FrameError`

```fern
<<9 function __connection(code: i32, reason: string): FrameError>>=
function __connection(code: i32, reason: string): FrameError {
  return FrameError { code: code, stream: 0, reason: reason };
}
```

### `10 pub enum Read`

```fern
<<10 pub enum Read>>=
pub enum Read { Got(Frame, i32), More }
```

### `11 pub function read(buf: u8[], from: i32, max_frame: i32): Result[Read, FrameError]`

```fern
<<11 pub function read(buf: u8[], from: i32, max_frame: i32): Result[Read, FrameError]>>=
pub function read(buf: u8[], from: i32, max_frame: i32): Result[Read, FrameError] {
  if (buf.len() - from < HEADER_LEN) {
    return Ok(More);
  }
  let len: i32 = __be24(buf, from);
  let kind: i32 = buf[from + 3] as i32;
  let flags: i32 = buf[from + 4] as i32;
  let stream: i32 = __be32(buf, from + 5) & MAX_WINDOW;
  if (len > max_frame) {
    return Err(__connection(FRAME_SIZE_ERROR, "frame of " + int.int_to_string(len) + " bytes over the " + int.int_to_string(max_frame) + " allowed"));
  }
  if (buf.len() - from - HEADER_LEN < len) {
    return Ok(More);
  }
  let payload: u8[] = __bytes_range(buf, from + HEADER_LEN, from + HEADER_LEN + len);
  return Ok(Got(__frame(kind, flags, stream, payload)?, HEADER_LEN + len));
}

pub function plain_headers_at(buf: u8[], from: i32, max_frame: i32): Option[i32] {
  if (buf.len() - from < HEADER_LEN) {
    return None;
  }
  let len: i32 = __be24(buf, from);
  let flags: i32 = buf[from + 4] as i32;
  if (buf[from + 3] as i32 != HEADERS || len > max_frame || buf.len() - from - HEADER_LEN < len) {
    return None;
  }
  if ((flags & 4) == 0 || (flags & 40) != 0 || stream_at(buf, from) == 0) {
    return None;
  }
  return Some(len);
}

pub function stream_at(buf: u8[], from: i32): i32 {
  return __be32(buf, from + 5) & MAX_WINDOW;
}

pub function end_stream_at(buf: u8[], from: i32): boolean {
  return (buf[from + 4] as i32 & 1) != 0;
}
```

### `12 function __frame(kind: i32, flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError]`

```fern
<<12 function __frame(kind: i32, flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError]>>=
function __frame(kind: i32, flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (kind == DATA) {
    return __data(flags, stream, payload);
  }
  if (kind == HEADERS) {
    return __headers(flags, stream, payload);
  }
  if (kind == PRIORITY) {
    return __priority_frame(stream, payload);
  }
  if (kind == RST_STREAM) {
    return __rst_stream(stream, payload);
  }
  if (kind == SETTINGS) {
    return __settings(flags, stream, payload);
  }
  return __frame_rest(kind, flags, stream, payload);
}

function __frame_rest(kind: i32, flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (kind == PUSH_PROMISE) {
    return __push_promise(flags, stream, payload);
  }
  if (kind == PING) {
    return __ping(flags, stream, payload);
  }
  if (kind == GOAWAY) {
    return __goaway(stream, payload);
  }
  if (kind == WINDOW_UPDATE) {
    return __window_update(stream, payload);
  }
  if (kind == CONTINUATION) {
    return __continuation(flags, stream, payload);
  }
  return Ok(Unknown(UnknownFrame { kind: kind, flags: flags, stream: stream, payload: payload }));
}

function __unpadded(flags: i32, stream: i32, payload: u8[]): Result[u8[], FrameError] {
  if ((flags & 8) == 0) {
    return Ok(payload);
  }
  if (payload.len() == 0) {
    return Err(__connection(PROTOCOL_ERROR, "a PADDED frame with no pad length"));
  }
  let pad: i32 = payload[0] as i32;
  if (pad >= payload.len()) {
    return Err(__connection(PROTOCOL_ERROR, "padding of " + int.int_to_string(pad) + " bytes in a payload of " + int.int_to_string(payload.len())));
  }
  return Ok(__bytes_range(payload, 1, payload.len() - pad));
}

function __data(flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream == 0) {
    return Err(__connection(PROTOCOL_ERROR, "DATA on stream 0"));
  }
  let n: i32 = payload.len();
  let body: u8[] = __unpadded(flags, stream, payload)?;
  return Ok(Data(DataFrame { stream: stream, end_stream: (flags & 1) != 0, padding: n - body.len(), data: body }));
}

function __headers(flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream == 0) {
    return Err(__connection(PROTOCOL_ERROR, "HEADERS on stream 0"));
  }
  let n: i32 = payload.len();
  let block: u8[] = __unpadded(flags, stream, payload)?;
  let padding: i32 = n - block.len();
  let priority: Option[Priority] = None;
  if ((flags & 32) != 0) {
    if (block.len() < 5) {
      return Err(__connection(FRAME_SIZE_ERROR, "HEADERS with PRIORITY shorter than its priority"));
    }
    priority = Some(__priority(block, 0));
    block = __bytes_range(block, 5, block.len());
  }
  return Ok(Headers(HeadersFrame { stream: stream, end_stream: (flags & 1) != 0, end_headers: (flags & 4) != 0, priority: priority, block: block, padding: padding }));
}

function __priority(payload: u8[], at: i32): Priority {
  let word: i32 = __be32(payload, at);
  return Priority { exclusive: word < 0, dependency: word & MAX_WINDOW, weight: payload[at + 4] as i32 + 1 };
}

function __priority_frame(stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream == 0) {
    return Err(__connection(PROTOCOL_ERROR, "PRIORITY on stream 0"));
  }
  if (payload.len() != 5) {
    return Err(FrameError { code: FRAME_SIZE_ERROR, stream: stream, reason: "PRIORITY of " + int.int_to_string(payload.len()) + " bytes" });
  }
  return Ok(PriorityFrame(stream, __priority(payload, 0)));
}

function __rst_stream(stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream == 0) {
    return Err(__connection(PROTOCOL_ERROR, "RST_STREAM on stream 0"));
  }
  if (payload.len() != 4) {
    return Err(__connection(FRAME_SIZE_ERROR, "RST_STREAM of " + int.int_to_string(payload.len()) + " bytes"));
  }
  return Ok(RstStream(stream, __be32(payload, 0)));
}

function __settings(flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream != 0) {
    return Err(__connection(PROTOCOL_ERROR, "SETTINGS on stream " + int.int_to_string(stream)));
  }
  let ack: boolean = (flags & 1) != 0;
  if (ack && payload.len() != 0) {
    return Err(__connection(FRAME_SIZE_ERROR, "SETTINGS ACK with a payload"));
  }
  if (payload.len() % 6 != 0) {
    return Err(__connection(FRAME_SIZE_ERROR, "SETTINGS of " + int.int_to_string(payload.len()) + " bytes"));
  }
  let settings: Setting[] = [];
  let at: i32 = 0;
  while (at < payload.len()) {
    settings = settings.append(__setting(payload[at] as i32 << 8 | payload[at + 1] as i32, __be32(payload, at + 2))?);
    at = at + 6;
  }
  return Ok(Settings(ack, settings));
}
```

### `13 function __setting(id: i32, value: i32): Result[Setting, FrameError]`

```fern
<<13 function __setting(id: i32, value: i32): Result[Setting, FrameError]>>=
function __setting(id: i32, value: i32): Result[Setting, FrameError] {
  if (id == SETTINGS_ENABLE_PUSH && value != 0 && value != 1) {
    return Err(__connection(PROTOCOL_ERROR, "SETTINGS_ENABLE_PUSH of " + int.int_to_string(value)));
  }
  if (id == SETTINGS_INITIAL_WINDOW_SIZE && value < 0) {
    return Err(__connection(FLOW_CONTROL_ERROR, "SETTINGS_INITIAL_WINDOW_SIZE over 2^31-1"));
  }
  if (id == SETTINGS_MAX_FRAME_SIZE && (value < MIN_FRAME_SIZE || value > MAX_FRAME_SIZE)) {
    return Err(__connection(PROTOCOL_ERROR, "SETTINGS_MAX_FRAME_SIZE of " + int.int_to_string(value)));
  }
  if (value < 0) {
    return Err(__connection(PROTOCOL_ERROR, "setting " + int.int_to_string(id) + " over 2^31-1"));
  }
  return Ok(Setting { id: id, value: value });
}

function __push_promise(flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream == 0) {
    return Err(__connection(PROTOCOL_ERROR, "PUSH_PROMISE on stream 0"));
  }
  let body: u8[] = __unpadded(flags, stream, payload)?;
  if (body.len() < 4) {
    return Err(__connection(FRAME_SIZE_ERROR, "PUSH_PROMISE shorter than its promised stream"));
  }
  return Ok(PushPromise(PushPromiseFrame { stream: stream, promised: __be32(body, 0) & MAX_WINDOW, end_headers: (flags & 4) != 0, block: __bytes_range(body, 4, body.len()) }));
}

function __ping(flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream != 0) {
    return Err(__connection(PROTOCOL_ERROR, "PING on stream " + int.int_to_string(stream)));
  }
  if (payload.len() != 8) {
    return Err(__connection(FRAME_SIZE_ERROR, "PING of " + int.int_to_string(payload.len()) + " bytes"));
  }
  return Ok(Ping((flags & 1) != 0, payload));
}

function __goaway(stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream != 0) {
    return Err(__connection(PROTOCOL_ERROR, "GOAWAY on stream " + int.int_to_string(stream)));
  }
  if (payload.len() < 8) {
    return Err(__connection(FRAME_SIZE_ERROR, "GOAWAY of " + int.int_to_string(payload.len()) + " bytes"));
  }
  return Ok(GoAway(GoAwayFrame { last_stream: __be32(payload, 0) & MAX_WINDOW, code: __be32(payload, 4), debug: __bytes_range(payload, 8, payload.len()) }));
}

function __window_update(stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (payload.len() != 4) {
    return Err(__connection(FRAME_SIZE_ERROR, "WINDOW_UPDATE of " + int.int_to_string(payload.len()) + " bytes"));
  }
  let increment: i32 = __be32(payload, 0) & MAX_WINDOW;
  if (increment == 0) {
    return Err(FrameError { code: PROTOCOL_ERROR, stream: stream, reason: "WINDOW_UPDATE of 0" });
  }
  return Ok(WindowUpdate(stream, increment));
}

function __continuation(flags: i32, stream: i32, payload: u8[]): Result[Frame, FrameError] {
  if (stream == 0) {
    return Err(__connection(PROTOCOL_ERROR, "CONTINUATION on stream 0"));
  }
  return Ok(Continuation(stream, (flags & 4) != 0, payload));
}
```

### `14 pub function encode(f: Frame): u8[]`

```fern
<<14 pub function encode(f: Frame): u8[]>>=
pub function encode(f: Frame): u8[] {
  match (f) {
    Data(d) => {
      return __framed(DATA, __flag(d.end_stream, 1), d.stream, d.data);
    },
    Headers(h) => {
      return __encode_headers(h);
    },
    PriorityFrame(stream, p) => {
      return __framed(PRIORITY, 0, stream, __priority_bytes(p));
    },
    RstStream(stream, code) => {
      return __framed(RST_STREAM, 0, stream, __be32_bytes([], code));
    },
    Settings(ack, settings) => {
      return __framed(SETTINGS, __flag(ack, 1), 0, __settings_bytes(settings));
    },
    _ => {
      return __encode_rest(f);
    }
  }
  return [];
}
```

### `15 function __encode_rest(f: Frame): u8[]`

```fern
<<15 function __encode_rest(f: Frame): u8[]>>=
function __encode_rest(f: Frame): u8[] {
  match (f) {
    PushPromise(p) => {
      return __framed(PUSH_PROMISE, __flag(p.end_headers, 4), p.stream, __be32_bytes([], p.promised).concat(p.block));
    },
    Ping(ack, data) => {
      return __framed(PING, __flag(ack, 1), 0, data);
    },
    GoAway(g) => {
      return __framed(GOAWAY, 0, 0, __be32_bytes(__be32_bytes([], g.last_stream), g.code).concat(g.debug));
    },
    WindowUpdate(stream, increment) => {
      return __framed(WINDOW_UPDATE, 0, stream, __be32_bytes([], increment));
    },
    Continuation(stream, end_headers, block) => {
      return __framed(CONTINUATION, __flag(end_headers, 4), stream, block);
    },
    Unknown(u) => {
      return __framed(u.kind, u.flags, u.stream, u.payload);
    },
    _ => {
      return [];
    }
  }
  return [];
}

function __encode_headers(h: HeadersFrame): u8[] {
  let flags: i32 = __flag(h.end_stream, 1) | __flag(h.end_headers, 4);
  match (h.priority) {
    Some(p) => {
      return __framed(HEADERS, flags | 32, h.stream, __priority_bytes(p).concat(h.block));
    },
    None => {
      return __framed(HEADERS, flags, h.stream, h.block);
    }
  }
  return [];
}

function __flag(on: boolean, bit: i32): i32 {
  if (on) {
    return bit;
  }
  return 0;
}

function __framed(kind: i32, flags: i32, stream: i32, payload: u8[]): u8[] {
  let n: i32 = payload.len();
  let out: u8[] = header_into(__alloc_u8(HEADER_LEN + n), 0, kind, flags, stream, n);
  if (n == 0) {
    return out;
  }
  return __bytes_into(out, HEADER_LEN, payload, 0, n);
}
```

### `16 pub function header_into(own out: u8[], at: i32, kind: i32, flags: i32, stream: i32, len: i32): u8[]`

```fern
<<16 pub function header_into(own out: u8[], at: i32, kind: i32, flags: i32, stream: i32, len: i32): u8[]>>=
pub function header_into(own out: u8[], at: i32, kind: i32, flags: i32, stream: i32, len: i32): u8[] {
  out = out.with(at, (len >> 16 & 255) as u8).with(at + 1, (len >> 8 & 255) as u8).with(at + 2, (len & 255) as u8).with(at + 3, kind as u8).with(at + 4, flags as u8);
  return out.with(at + 5, (stream >> 24 & 255) as u8).with(at + 6, (stream >> 16 & 255) as u8).with(at + 7, (stream >> 8 & 255) as u8).with(at + 8, (stream & 255) as u8);
}
```

### `17 pub const BLOCK_ROOM: i32`

```fern
<<17 pub const BLOCK_ROOM: i32>>=
pub const BLOCK_ROOM: i32 = 128;
```

### `18 pub function headers_room(data_len: i32): u8[]`

```fern
<<18 pub function headers_room(data_len: i32): u8[]>>=
pub function headers_room(data_len: i32): u8[] {
  let out: u8[] = __alloc_u8(HEADER_LEN + BLOCK_ROOM + HEADER_LEN + data_len);
  __arr_set_len(out, HEADER_LEN);
  return out;
}

// The DATA frame goes on by appends, which use the room headers_room left
// when the block still has it and grow the array when it does not.
pub function headers_data(own out: u8[], stream: i32, data: [u8], n: i32): u8[] {
  let block_len: i32 = out.len() - HEADER_LEN;
  if (n == 0) {
    return header_into(out, 0, HEADERS, 5, stream, block_len);
  }
  out = header_into(out, 0, HEADERS, 4, stream, block_len);
  let at: i32 = out.len();
  let i: i32 = 0;
  while (i < HEADER_LEN) {
    out = out.append(0 as u8);
    i = i + 1;
  }
  out = header_into(out, at, DATA, 1, stream, n);
  i = 0;
  while (i < n) {
    out = out.append(data[i]);
    i = i + 1;
  }
  return out;
}

pub function headers_bytes(stream: i32, end_stream: boolean, end_headers: boolean, block: u8[]): u8[] {
  return __framed(HEADERS, __flag(end_stream, 1) | __flag(end_headers, 4), stream, block);
}

pub function data_bytes(stream: i32, end_stream: boolean, data: u8[]): u8[] {
  return __framed(DATA, __flag(end_stream, 1), stream, data);
}
```

### `19 function __priority_bytes(p: Priority): u8[]`

```fern
<<19 function __priority_bytes(p: Priority): u8[]>>=
function __priority_bytes(p: Priority): u8[] {
  let word: i32 = p.dependency & MAX_WINDOW;
  let out: u8[] = __be32_bytes([], word);
  if (p.exclusive) {
    out = out.with(0, (out[0] as i32 | 128) as u8);
  }
  return out.append((p.weight - 1) as u8);
}

function __settings_bytes(settings: Setting[]): u8[] {
  let out: u8[] = [];
  for s in settings {
    out = __be32_bytes(out.append((s.id >> 8 & 255) as u8).append((s.id & 255) as u8), s.value);
  }
  return out;
}

function __be24(buf: u8[], at: i32): i32 {
  return buf[at] as i32 << 16 | buf[at + 1] as i32 << 8 | buf[at + 2] as i32;
}

function __be32(buf: u8[], at: i32): i32 {
  return buf[at] as i32 << 24 | buf[at + 1] as i32 << 16 | buf[at + 2] as i32 << 8 | buf[at + 3] as i32;
}

function __be32_bytes(out: u8[], v: i32): u8[] {
  return out.append((v >> 24 & 255) as u8).append((v >> 16 & 255) as u8).append((v >> 8 & 255) as u8).append((v & 255) as u8);
}
```
