# Clients behind trusted proxies

This module reads and writes the HTTP `Forwarded` header and identifies clients through trusted proxies.

## Model

A Forwarded hop separates its client node, proxy node, host, and protocol. Nodes can contain an IP address, an obfuscated name, or an unknown value.

## Contracts

Client selection uses an explicit set of trusted proxy prefixes. Header text alone does not establish proxy trust. Legacy-header support is a separate policy.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub enum Node>>

<<4 pub function hop(): Hop>>

<<5 function __with_param(h: Hop, name: string, v: string): Option[Hop]>>

<<6 pub function node_parse(s: string): Option[NodeId]>>

<<7 function __nodename(s: string): Option[Node]>>

<<8 pub struct Trust>>

<<9 pub function trust(blocks: string[]): Result[Trust, string]>>

<<10 pub struct Client>>

<<11 pub function (c: Client) ip(): Option[net.IpAddr]>>

<<12 function __trusted_hops(h: HeaderMap, t: Trust): Hop[]>>

<<13 pub function (n: NodeId) to_string(): string>>

<<14 function __node_text(n: Option[NodeId]): Option[string]>>

<<15 pub function (r: HttpRequest) with_hop(h: Hop): HttpRequest>>

<<16 pub enum ProxyHeader>>

<<17 pub function proxy_header(buf: u8[], from: i32): ProxyHeader>>

<<18 function __prefix_of(buf: u8[], from: i32, sig: u8[]): boolean>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module reads and writes the HTTP `Forwarded` header and identifies clients through trusted proxies.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/http";
import "std/headers";
import "std/net";
import "std/platform";
import "std/utf8" as utf8;
import "std/array";
```

### `3 pub enum Node`

```fern
<<3 pub enum Node>>=
pub enum Node { Ip(net.IpAddr), Obfuscated(string), Unknown }

pub struct NodeId { node: Node, port: string }

pub struct Hop { from: Option[NodeId], by: Option[NodeId], host: Option[string], proto: Option[string] }
```

### `4 pub function hop(): Hop`

```fern
<<4 pub function hop(): Hop>>=
pub function hop(): Hop {
  return Hop { from: None, by: None, host: None, proto: None };
}

pub function hops(h: HeaderMap): Option[Hop[]] {
  let out: Hop[] = [];
  for el in h.get_list("forwarded") {
    match (parse_hop(el)) {
      Some(x) => {
        out = out.append(x);
      },
      None => {
        return None;
      }
    }
  }
  return Some(out);
}

pub function parse_hop(el: string): Option[Hop] {
  let h: Hop = hop();
  let seen: string[] = [];
  for pair in __pairs(el) {
    let Some(eq) = pair.index_of("=") else {
      return None;
    };
    if (eq == 0) {
      return None;
    }
    let name: string = pair.slice_snap(0, eq).trim().to_lower();
    if (__holds(seen, name)) {
      return None;
    }
    seen = seen.append(name);
    match (__value(pair.slice_snap(eq + 1, pair.len()).trim())) {
      Some(v) => {
        match (__with_param(h, name, v)) {
          Some(next) => {
            h = next;
          },
          None => {
            return None;
          }
        }
      },
      None => {
        return None;
      }
    }
  }
  return Some(h);
}
```

### `5 function __with_param(h: Hop, name: string, v: string): Option[Hop]`

```fern
<<5 function __with_param(h: Hop, name: string, v: string): Option[Hop]>>=
function __with_param(h: Hop, name: string, v: string): Option[Hop] {
  if (name == "for" || name == "by") {
    match (node_parse(v)) {
      Some(n) => {
        if (name == "for") {
          return Some(Hop { ...h, from: Some(n) });
        }
        return Some(Hop { ...h, by: Some(n) });
      },
      None => {
        return None;
      }
    }
  }
  if (name == "proto") {
    if (!__scheme(v)) {
      return None;
    }
    return Some(Hop { ...h, proto: Some(v.to_lower()) });
  }
  if (name == "host") {
    return Some(Hop { ...h, host: Some(v) });
  }
  return Some(h);
}

function __pairs(el: string): string[] {
  let out: string[] = [];
  let start: i32 = 0;
  let quoted: boolean = false;
  let i: i32 = 0;
  while (i < el.len()) {
    let b: u8 = el[i];
    if (quoted && b == 92 as u8) {
      i = i + 1;
    } else if (b == 34 as u8) {
      quoted = !quoted;
    } else if (b == 59 as u8 && !quoted) {
      out = __pair_member(out, el, start, i);
      start = i + 1;
    }
    i = i + 1;
  }
  return __pair_member(out, el, start, el.len());
}

function __pair_member(out: string[], el: string, from: i32, to: i32): string[] {
  let m: string = el.slice_snap(from, to).trim();
  if (m.len() == 0) {
    return out;
  }
  return out.append(m);
}

function __value(raw: string): Option[string] {
  if (raw.len() >= 2 && raw[0] == 34 as u8 && raw[raw.len() - 1] == 34 as u8) {
    return Some(headers.unquote(raw));
  }
  if (raw.len() == 0) {
    return None;
  }
  for b in raw.bytes() {
    if (!__tchar(b)) {
      return None;
    }
  }
  return Some(raw);
}

function __tchar(b: u8): boolean {
  if (b >= 48 as u8 && b <= 57 as u8 || __alpha(b)) {
    return true;
  }
  for c in "!#$%&'*+-.^_`|~".bytes() {
    if (c == b) {
      return true;
    }
  }
  return false;
}

function __alpha(b: u8): boolean {
  return b >= 65 as u8 && b <= 90 as u8 || b >= 97 as u8 && b <= 122 as u8;
}

function __scheme(v: string): boolean {
  if (v.len() == 0 || !__alpha(v[0])) {
    return false;
  }
  for b in v.bytes() {
    if (!__alpha(b) && !(b >= 48 as u8 && b <= 57 as u8) && b != 43 as u8 && b != 45 as u8 && b != 46 as u8) {
      return false;
    }
  }
  return true;
}

function __holds(xs: string[], x: string): boolean {
  for s in xs {
    if (s == x) {
      return true;
    }
  }
  return false;
}
```

### `6 pub function node_parse(s: string): Option[NodeId]`

```fern
<<6 pub function node_parse(s: string): Option[NodeId]>>=
pub function node_parse(s: string): Option[NodeId] {
  if (s.len() > 0 && s[0] == 91 as u8) {
    let Some(close) = s.index_of("]") else {
      return None;
    };
    match (net.ipv6_parse(s.slice_snap(1, close))) {
      Some(ip) => {
        return __with_port(Ip(ip), s.slice_snap(close + 1, s.len()));
      },
      None => {
        return None;
      }
    }
  }
  let name: string = s;
  let rest: string = "";
  if let Some(colon) = s.index_of(":") {
    name = s.slice_snap(0, colon);
    rest = s.slice_snap(colon, s.len());
  }
  match (__nodename(name)) {
    Some(n) => {
      return __with_port(n, rest);
    },
    None => {
      return None;
    }
  }
}
```

### `7 function __nodename(s: string): Option[Node]`

```fern
<<7 function __nodename(s: string): Option[Node]>>=
function __nodename(s: string): Option[Node] {
  if (s.eq_ignore_ascii_case("unknown")) {
    return Some(Node.Unknown);
  }
  if (__obfuscated(s)) {
    return Some(Obfuscated(s));
  }
  match (net.ipv4_parse(s)) {
    Some(ip) => {
      return Some(Ip(ip));
    },
    None => {
      return None;
    }
  }
}

function __with_port(n: Node, rest: string): Option[NodeId] {
  if (rest.len() == 0) {
    return Some(NodeId { node: n, port: "" });
  }
  let port: string = rest.slice_snap(1, rest.len());
  if (rest[0] != 58 as u8 || !(__port_digits(port) || __obfuscated(port))) {
    return None;
  }
  return Some(NodeId { node: n, port: port });
}

function __port_digits(s: string): boolean {
  if (s.len() == 0 || s.len() > 5) {
    return false;
  }
  for b in s.bytes() {
    if (b < 48 as u8 || b > 57 as u8) {
      return false;
    }
  }
  return true;
}

function __obfuscated(s: string): boolean {
  if (s.len() < 2 || s[0] != 95 as u8) {
    return false;
  }
  for b in s.bytes() {
    if (!__alpha(b) && !(b >= 48 as u8 && b <= 57 as u8) && b != 46 as u8 && b != 95 as u8 && b != 45 as u8) {
      return false;
    }
  }
  return true;
}
```

### `8 pub struct Trust`

```fern
<<8 pub struct Trust>>=
pub struct Trust { proxies: net.Prefix[], legacy: boolean }
```

### `9 pub function trust(blocks: string[]): Result[Trust, string]`

```fern
<<9 pub function trust(blocks: string[]): Result[Trust, string]>>=
pub function trust(blocks: string[]): Result[Trust, string] {
  let out: net.Prefix[] = [];
  for b in blocks {
    match (net.prefix_parse(b)) {
      Some(p) => {
        out = out.append(p);
      },
      None => {
        return Err(b);
      }
    }
  }
  return Ok(Trust { proxies: out, legacy: false });
}

pub function (t: Trust) trusts(ip: net.IpAddr): boolean {
  for p in t.proxies {
    if (p.contains(ip)) {
      return true;
    }
  }
  return false;
}
```

### `10 pub struct Client`

```fern
<<10 pub struct Client>>=
pub struct Client { node: Option[NodeId], proto: Option[string], host: Option[string] }
```

### `11 pub function (c: Client) ip(): Option[net.IpAddr]`

```fern
<<11 pub function (c: Client) ip(): Option[net.IpAddr]>>=
pub function (c: Client) ip(): Option[net.IpAddr] {
  match (c.node) {
    Some(n) => {
      match (n.node) {
        Ip(ip) => {
          return Some(ip);
        },
        _ => {
          return None;
        }
      }
    },
    None => {
      return None;
    }
  }
}

pub function client(req: HttpRequest, plat: platform.Platform, t: Trust): Client {
  let own: Client = Client { node: None, proto: None, host: req.headers.get("host") };
  match (plat.peer()) {
    Some(peer) => {
      let direct: Client = Client { ...own, node: Some(NodeId { node: Ip(peer.ip), port: peer.port.to_string() }) };
      if (!t.trusts(peer.ip)) {
        return direct;
      }
      return __walk(__trusted_hops(req.headers, t), t, direct);
    },
    None => {
      return own;
    }
  }
}
```

### `12 function __trusted_hops(h: HeaderMap, t: Trust): Hop[]`

```fern
<<12 function __trusted_hops(h: HeaderMap, t: Trust): Hop[]>>=
function __trusted_hops(h: HeaderMap, t: Trust): Hop[] {
  if (t.legacy && !h.has("forwarded")) {
    return __or_none(__legacy_hops(h));
  }
  return __or_none(hops(h));
}

function __or_none(hs: Option[Hop[]]): Hop[] {
  match (hs) {
    Some(x) => {
      return x;
    },
    None => {
      let none: Hop[] = [];
      return none;
    }
  }
}

function __walk(hs: Hop[], t: Trust, direct: Client): Client {
  let i: i32 = hs.len() - 1;
  while (i >= 0) {
    if (i == 0 || !__trusted_node(hs[i].from, t)) {
      return __client_of(hs[i], direct);
    }
    i = i - 1;
  }
  return direct;
}

function __trusted_node(n: Option[NodeId], t: Trust): boolean {
  match (n) {
    Some(id) => {
      match (id.node) {
        Ip(ip) => {
          return t.trusts(ip);
        },
        _ => {
          return false;
        }
      }
    },
    None => {
      return false;
    }
  }
}

function __client_of(h: Hop, direct: Client): Client {
  let host: Option[string] = direct.host;
  match (h.host) {
    Some(x) => {
      host = Some(x);
    },
    None => {}
  }
  return Client { node: h.from, proto: h.proto, host: host };
}

function __legacy_hops(h: HeaderMap): Option[Hop[]] {
  let fors: string[] = h.get_list("x-forwarded-for");
  let protos: string[] = h.get_list("x-forwarded-proto");
  let hosts: string[] = h.get_list("x-forwarded-host");
  let out: Hop[] = [];
  let i: i32 = 0;
  while (i < fors.len()) {
    match (__legacy_node(fors[i])) {
      Some(n) => {
        let back: i32 = fors.len() - 1 - i;
        out = out.append(Hop { from: Some(n), by: None, host: __paired(hosts, back), proto: __paired(protos, back) });
      },
      None => {
        return None;
      }
    }
    i = i + 1;
  }
  return Some(out);
}

function __legacy_node(s: string): Option[NodeId] {
  match (net.ip_parse(s)) {
    Some(ip) => {
      return Some(NodeId { node: Ip(ip), port: "" });
    },
    None => {
      return node_parse(s);
    }
  }
}

function __paired(xs: string[], back: i32): Option[string] {
  if (xs.len() == 1) {
    return Some(xs[0]);
  }
  if (back < xs.len()) {
    return Some(xs[xs.len() - 1 - back]);
  }
  return None;
}
```

### `13 pub function (n: NodeId) to_string(): string`

```fern
<<13 pub function (n: NodeId) to_string(): string>>=
pub function (n: NodeId) to_string(): string {
  let name: string = "unknown";
  match (n.node) {
    Ip(ip) => {
      name = ip.to_string();
      if (ip.is_v6()) {
        name = "[" + name + "]";
      }
    },
    Obfuscated(s) => {
      name = s;
    },
    Node.Unknown => {}
  }
  if (n.port.len() == 0) {
    return name;
  }
  return name + ":" + n.port;
}

pub function (h: Hop) to_string(): string {
  let parts: string[] = [];
  parts = __param(parts, "for", __node_text(h.from));
  parts = __param(parts, "by", __node_text(h.by));
  parts = __param(parts, "host", h.host);
  parts = __param(parts, "proto", h.proto);
  return parts.join(";");
}
```

### `14 function __node_text(n: Option[NodeId]): Option[string]`

```fern
<<14 function __node_text(n: Option[NodeId]): Option[string]>>=
function __node_text(n: Option[NodeId]): Option[string] {
  match (n) {
    Some(id) => {
      return Some(id.to_string());
    },
    None => {
      return None;
    }
  }
}

function __param(parts: string[], name: string, v: Option[string]): string[] {
  match (v) {
    Some(s) => {
      return parts.append(name + "=" + __quoted_if_needed(s));
    },
    None => {
      return parts;
    }
  }
}

function __quoted_if_needed(s: string): string {
  match (__value(s)) {
    Some(_) => {
      if (s[0] != 34 as u8) {
        return s;
      }
    },
    None => {}
  }
  return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
}
```

### `15 pub function (r: HttpRequest) with_hop(h: Hop): HttpRequest`

```fern
<<15 pub function (r: HttpRequest) with_hop(h: Hop): HttpRequest>>=
pub function (r: HttpRequest) with_hop(h: Hop): HttpRequest {
  return HttpRequest { ...r, headers: r.headers.append("Forwarded", h.to_string()) };
}

pub function hop_of(req: HttpRequest, plat: platform.Platform, proto: string): Hop {
  let from: Option[NodeId] = None;
  match (plat.peer()) {
    Some(p) => {
      from = Some(NodeId { node: Ip(p.ip), port: p.port.to_string() });
    },
    None => {}
  }
  return Hop { from: from, by: None, host: req.headers.get("host"), proto: Some(proto) };
}
```

### `16 pub enum ProxyHeader`

```fern
<<16 pub enum ProxyHeader>>=
pub enum ProxyHeader { HeaderShort, HeaderBad, HeaderRead(Option[net.SocketAddr], i32) }
```

### `17 pub function proxy_header(buf: u8[], from: i32): ProxyHeader`

```fern
<<17 pub function proxy_header(buf: u8[], from: i32): ProxyHeader>>=
pub function proxy_header(buf: u8[], from: i32): ProxyHeader {
  let v1: u8[] = "PROXY ".bytes();
  let v2: u8[] = [13 as u8, 10 as u8, 13 as u8, 10 as u8, 0 as u8, 13 as u8, 10 as u8, 81 as u8, 85 as u8, 73 as u8, 84 as u8, 10 as u8];
  if (__prefix_of(buf, from, v2)) {
    return __proxy_v2(buf, from);
  }
  if (__prefix_of(buf, from, v1)) {
    return __proxy_v1(buf, from);
  }
  return HeaderBad;
}
```

### `18 function __prefix_of(buf: u8[], from: i32, sig: u8[]): boolean`

```fern
<<18 function __prefix_of(buf: u8[], from: i32, sig: u8[]): boolean>>=
function __prefix_of(buf: u8[], from: i32, sig: u8[]): boolean {
  let i: i32 = 0;
  while (i < sig.len() && from + i < buf.len()) {
    if (buf[from + i] != sig[i]) {
      return false;
    }
    i = i + 1;
  }
  return true;
}

function __proxy_v1(buf: u8[], from: i32): ProxyHeader {
  let end: i32 = from;
  while (end + 1 < buf.len() && !(buf[end] == 13 as u8 && buf[end + 1] == 10 as u8)) {
    if (end - from >= 105) {
      return HeaderBad;
    }
    end = end + 1;
  }
  if (end + 1 >= buf.len()) {
    return HeaderShort;
  }
  let fields: string[] = utf8.from_bytes_lossy(array.slice(buf, from, end)).split(" ");
  return __v1_fields(fields, end + 2 - from);
}

function __v1_fields(f: string[], len: i32): ProxyHeader {
  if (f.len() >= 2 && f[1] == "UNKNOWN") {
    return HeaderRead(None, len);
  }
  if (f.len() != 6 || f[1] != "TCP4" && f[1] != "TCP6") {
    return HeaderBad;
  }
  let v4: boolean = f[1] == "TCP4";
  let src: Option[net.SocketAddr] = __v1_addr(f[2], v4, f[4]);
  match (__v1_addr(f[3], v4, f[5])) {
    Some(_) => {
      match (src) {
        Some(a) => {
          return HeaderRead(Some(a), len);
        },
        None => {}
      }
    },
    None => {}
  }
  return HeaderBad;
}

function __v1_addr(text: string, v4: boolean, port: string): Option[net.SocketAddr] {
  let n: i32 = __v1_port(port);
  match (net.ip_parse(text)) {
    Some(ip) => {
      if (ip.is_v4() != v4 || n < 0) {
        return None;
      }
      return Some(net.socket_addr(ip, n));
    },
    None => {
      return None;
    }
  }
}

function __v1_port(s: string): i32 {
  if (!__port_digits(s) || s.len() > 1 && s[0] == b'0') {
    return 0 - 1;
  }
  let n: i32 = 0;
  for b in s.bytes() {
    n = n * 10 + (b - 48 as u8) as i32;
  }
  if (n > 65535) {
    return 0 - 1;
  }
  return n;
}

function __proxy_v2(buf: u8[], from: i32): ProxyHeader {
  if (buf.len() - from < 16) {
    return HeaderShort;
  }
  let ver_cmd: i32 = buf[from + 12] as i32;
  if (ver_cmd >> 4 != 2 || (ver_cmd & 15) > 1) {
    return HeaderBad;
  }
  let len: i32 = 16 + (buf[from + 14] as i32 << 8 | buf[from + 15] as i32);
  if (buf.len() - from < len) {
    return HeaderShort;
  }
  let proto: i32 = buf[from + 13] as i32 & 15;
  if (proto > 2) {
    return HeaderBad;
  }
  if ((ver_cmd & 15) == 0 || proto == 0) {
    return HeaderRead(None, len);
  }
  return __v2_source(buf, from, buf[from + 13] as i32 >> 4, len);
}

function __v2_source(buf: u8[], from: i32, family: i32, len: i32): ProxyHeader {
  let width: i32 = 0;
  if (family == 1) {
    width = 4;
  } else if (family == 2) {
    width = 16;
  } else if (family == 0 || family == 3) {
    return HeaderRead(None, len);
  } else {
    return HeaderBad;
  }
  let at: i32 = from + 16;
  if (len - 16 < 2 * width + 4) {
    return HeaderBad;
  }
  let port: i32 = buf[at + 2 * width] as i32 << 8 | buf[at + 2 * width + 1] as i32;
  let ip: net.IpAddr = net.ipv4(buf[at] as i32, buf[at + 1] as i32, buf[at + 2] as i32, buf[at + 3] as i32);
  if (width == 16) {
    match (net.ipv6(array.slice(buf, at, at + 16))) {
      Some(v6) => {
        ip = v6;
      },
      None => {
        return HeaderBad;
      }
    }
  }
  return HeaderRead(Some(net.socket_addr(ip, port)), len);
}
```
