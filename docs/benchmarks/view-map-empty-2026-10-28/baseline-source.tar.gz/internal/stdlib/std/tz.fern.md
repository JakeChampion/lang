# Local time-zone rules

This module provides the time-zone type and loads zones from the IANA database, from TZif files, and from POSIX rules.

## Model

A zone combines recorded transitions with a fallback rule. TZif data and POSIX text provide the offsets, abbreviations, and seasonal clock policy.
A fixed-offset zone has no transitions and no rule.
A `Zoned` value pairs a `time.Timestamp` with a zone, and gives the local civil time there.

## Contracts

Local civil-time conversion must account for transition gaps and repeated times. Generated zone data remains intact within its marked chunk.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<dependencies 1>>

<<2 pub struct Zone>>

<<3 pub function utc_rule(): Rule>>

<<4 function default_zone(): Zone>>

<<5 pub function (z: Zone) offset_at(t: time.Timestamp): i32>>

<<6 pub struct Entry>>

<<7 pub function (z: Zone) entry_at(t: time.Timestamp): Entry>>

<<8 function (z: Zone) index_at(sec: i64): i32>>

<<9 pub function iana_zone(name: string): Result[Zone, ZoneError]>>

<<10 function has_table_separator(name: string): boolean>>

<<11 struct TypeTable>>

<<12 function decode_types(s: string, from: i32): TypeTable>>

<<13 struct Counts>>

<<14 function read_counts(bs: [u8], off: i32): Counts>>

<<15 pub function parse_tzif(bs: [u8]): Result[Zone, ZoneError]>>

<<16 function read_zone_block(bs: [u8], c: Counts, off: i32, width: i32, footer: string): Option[Zone]>>

<<17 pub function parse_posix(s: string): Rule>>

<<18 function us_dst_start(): DateRule>>

<<19 function parse_date_rule(s: string, p: i32): (boolean, DateRule, i32)>>

<<20 function epoch_day(year: i32, mon: i32, day: i32): i32>>

<<24 function darwin_zone_from_tz(spec: string): Zone>>

<<25 function darwin_name(s: string, p: i32): (string, i32)>>

<<generated data 26>>
```

### `dependencies 1`

```fern
<<dependencies 1>>=
// This module provides the time-zone type and loads zones from the IANA database, from TZif files, and from POSIX rules.
import "core/cmp";
import "std/string";
import "std/array";
import "std/error";
import "std/option";
import "std/result";
import "std/time";
import "std/utf8";
import "std/i64";
```

### `2 pub struct Zone`

```fern
<<2 pub struct Zone>>=
pub struct Zone { times: i64[], offs: i32[], abbrs: string[], dsts: boolean[], first: i32, first_abbr: string, first_dst: boolean, rule: Rule }

pub struct Rule { valid: boolean, has_dst: boolean, std_off: i32, dst_off: i32, std_name: string, dst_name: string, start: DateRule, end: DateRule }

pub struct DateRule { kind: i32, mon: i32, week: i32, day: i32, n: i32, time: i32 }

pub struct Zoned { timestamp: time.Timestamp, zone: Zone }
```

### `3 pub function utc_rule(): Rule`

```fern
<<3 pub function utc_rule(): Rule>>=
pub function utc_rule(): Rule {
  let none: DateRule = DateRule { kind: 2, mon: 0, week: 0, day: 0, n: 0, time: 0 };
  return Rule { valid: false, has_dst: false, std_off: 0, dst_off: 0, std_name: "", dst_name: "", start: none, end: none };
}

pub function fixed_zone(off: i32, name: string): Zone {
  let t: i64[] = [];
  let o: i32[] = [];
  let a: string[] = [];
  let d: boolean[] = [];
  return Zone { times: t, offs: o, abbrs: a, dsts: d, first: off, first_abbr: name, first_dst: false, rule: utc_rule() };
}

pub function utc_zone(): Zone {
  return fixed_zone(0, "UTC");
}

pub function local_zone(): Zone {
  match (env("TZ")) {
    Some(spec) => {
      return zone_from_tz(spec);
    },
    None => {
      return default_zone();
    }
  }
}

pub function zone_from_tz(spec: string): Zone {
  if (target_os() == "darwin") {
    return darwin_zone_from_tz(spec);
  }
  let name: string = spec;
  if (name.len() == 0) {
    name = "Universal";
  }
  if (name[0] as i32 == 58) {
    name = slice_unchecked(name, 1, name.len()) + "";
  }
  if (name.len() == 0) {
    return default_zone();
  }
  match (read_zone_file(zone_path(name))) {
    Some(z) => {
      return z;
    },
    None => {}
  }
  let r: Rule = parse_posix(name);
  if (!r.valid) {
    return fixed_zone(0, "");
  }
  return rule_zone(r);
}
```

### `4 function default_zone(): Zone`

```fern
<<4 function default_zone(): Zone>>=
function default_zone(): Zone {
  match (read_zone_file("/etc/localtime")) {
    Some(z) => {
      return z;
    },
    None => {
      return utc_zone();
    }
  }
}

function rule_zone(r: Rule): Zone {
  let t: i64[] = [];
  let o: i32[] = [];
  let a: string[] = [];
  let d: boolean[] = [];
  return Zone { times: t, offs: o, abbrs: a, dsts: d, first: r.std_off, first_abbr: r.std_name, first_dst: false, rule: r };
}

function zone_path(name: string): string {
  if (name.len() == 0) {
    return "";
  }
  if (name[0] as i32 == 47) {
    return name;
  }
  let dir: string = "/usr/share/zoneinfo";
  match (env("TZDIR")) {
    Some(d) => {
      if (d.len() > 0) {
        dir = d;
      }
    },
    None => {}
  }
  return dir + "/" + name;
}
```

### `5 pub function (z: Zone) offset_at(t: time.Timestamp): i32`

```fern
<<5 pub function (z: Zone) offset_at(t: time.Timestamp): i32>>=
pub function (z: Zone) offset_at(t: time.Timestamp): i32 {
  return z.entry_at(t).off;
}

pub function (z: Zone) is_dst_at(t: time.Timestamp): boolean {
  return z.entry_at(t).dst;
}

pub function (z: Zone) is_fixed(): boolean {
  return z.times.len() == 0 && !(z.rule.valid && z.rule.has_dst);
}
```

### `6 pub struct Entry`

```fern
<<6 pub struct Entry>>=
pub struct Entry { off: i32, abbrev: string, dst: boolean }
```

### `7 pub function (z: Zone) entry_at(t: time.Timestamp): Entry`

```fern
<<7 pub function (z: Zone) entry_at(t: time.Timestamp): Entry>>=
pub function (z: Zone) entry_at(t: time.Timestamp): Entry {
  let sec: i64 = t.sec;
  let i: i32 = z.index_at(sec);
  if (i == 0 - 1) {
    return Entry { off: z.first, abbrev: z.first_abbr, dst: z.first_dst };
  }
  if (i == 0 - 2) {
    if (rule_dst(z.rule, sec)) {
      return Entry { off: z.rule.dst_off, abbrev: z.rule.dst_name, dst: true };
    }
    return Entry { off: z.rule.std_off, abbrev: z.rule.std_name, dst: false };
  }
  return Entry { off: z.offs[i], abbrev: z.abbrs[i], dst: z.dsts[i] };
}

pub function (z: Zone) abbrev_at(t: time.Timestamp): string {
  return z.entry_at(t).abbrev;
}

pub function (z: Zone) at(t: time.Timestamp): Zoned {
  return Zoned { timestamp: t, zone: z };
}

// The local civil date and clock time.
pub function (zt: Zoned) to_datetime(): DateTime {
  return zt.local().to_datetime();
}

pub function (zt: Zoned) format_rfc3339(): string {
  let off: i32 = zt.zone.offset_at(zt.timestamp);
  let local: string = zt.local().format_rfc3339();
  if (off == 0) {
    return local;
  }
  return slice_unchecked(local, 0, local.len() - 1) + offset_text(off);
}

// The wall-clock reading of `zt` written as if it were UTC.
function (zt: Zoned) local(): time.Timestamp {
  return time.Timestamp { sec: zt.timestamp.sec + zt.zone.offset_at(zt.timestamp) as i64, nsec: zt.timestamp.nsec };
}

// `+hh:mm` or `-hh:mm`.
function offset_text(off: i32): string {
  let mag: i32 = off;
  let sign: string = "+";
  if (off < 0) {
    mag = 0 - off;
    sign = "-";
  }
  return sign + two_digits(mag / 3600) + ":" + two_digits(mag / 60 % 60);
}

function two_digits(n: i32): string {
  if (n < 10) {
    return "0" + n.to_string();
  }
  return n.to_string();
}

// A fixed zone for an RFC 3339 time with a `Z` or `±hh:mm` offset. A nonzero offset names the zone `UTC+hh:mm` or `UTC-hh:mm`.
pub function zoned_parse_rfc3339(s: string): Result[Zoned, time.TimeParseError] {
  let parsed: (time.Timestamp, i32) = time.timestamp_parse_rfc3339_offset(s)?;
  if (parsed.1 == 0) {
    return Ok(utc_zone().at(parsed.0));
  }
  return Ok(fixed_zone(parsed.1, "UTC" + offset_text(parsed.1)).at(parsed.0));
}
```

### `8 function (z: Zone) index_at(sec: i64): i32`

```fern
<<8 function (z: Zone) index_at(sec: i64): i32>>=
function (z: Zone) index_at(sec: i64): i32 {
  let n: i32 = z.times.len();
  if (n == 0) {
    if (z.rule.valid) {
      return 0 - 2;
    }
    return 0 - 1;
  }
  if (sec < z.times[0]) {
    return 0 - 1;
  }
  if (z.rule.valid && sec >= z.times[n - 1]) {
    return 0 - 2;
  }
  let lo: i32 = 0;
  let hi: i32 = n - 1;
  while (lo < hi) {
    let mid: i32 = lo + (hi - lo + 1) / 2;
    if (z.times[mid] <= sec) {
      lo = mid;
    } else {
      hi = mid - 1;
    }
  }
  return lo;
}
```

### `9 pub function iana_zone(name: string): Result[Zone, ZoneError]`

```fern
<<9 pub function iana_zone(name: string): Result[Zone, ZoneError]>>=
// Why a zone could not be found or read.
pub enum ZoneError { UnknownZone(string), TzifHeader, TzifTruncated, TzifText }

impl error.Error for ZoneError {}

impl cmp.Display for ZoneError {}

pub function (e: ZoneError) message(): string {
  match (e) {
    UnknownZone(name) => {
      return "\"" + name + "\" is not an IANA time-zone name";
    },
    TzifHeader => {
      return "the data does not start with a valid TZif header";
    },
    TzifTruncated => {
      return "the TZif data ends before its last block";
    },
    TzifText => {
      return "a TZif zone abbreviation or footer is not UTF-8";
    }
  }
}

pub function (e: ZoneError) to_string(): string {
  return e.message();
}

pub function iana_zone(name: string): Result[Zone, ZoneError] {
  if (name.len() == 0 || has_table_separator(name)) {
    return Err(UnknownZone(name));
  }
  let names: string = iana_names();
  let Some(at) = names.index_of(";" + name + "=") else {
    return Err(UnknownZone(name));
  };
  let off: (i32, i32) = table_uint(names, at + name.len() + 2);
  return Ok(decode_record(iana_records(), off.0));
}
```

### `10 function has_table_separator(name: string): boolean`

```fern
<<10 function has_table_separator(name: string): boolean>>=
function has_table_separator(name: string): boolean {
  let i: i32 = 0;
  while (i < name.len()) {
    let c: i32 = name[i] as i32;
    if (c == 59 || c == 61) {
      return true;
    }
    i = i + 1;
  }
  return false;
}

function decode_record(s: string, at: i32): Zone {
  let p: i32 = at;
  while (s[p] as i32 != 124) {
    p = p + 1;
  }
  let rule: Rule = parse_posix(slice_unchecked(s, at, p) + "");
  let ty: TypeTable = decode_types(s, p + 1);
  let times: i64[] = [];
  let offs: i32[] = [];
  let abbrs: string[] = [];
  let dsts: boolean[] = [];
  let t: i64 = 0;
  p = ty.next;
  while (s[p] as i32 != 59) {
    let v: (i64, i32) = table_varint(s, p);
    if (v.0 % (2 as i64) == 0 as i64) {
      t = t + v.0 / (2 as i64) * (60 as i64);
    } else {
      t = t + v.0 / (2 as i64);
    }
    let k: i32 = table_digit(s[v.1] as i32);
    times = times.append(t);
    offs = offs.append(ty.offs[k]);
    abbrs = abbrs.append(ty.abbrs[k]);
    dsts = dsts.append(ty.dsts[k]);
    p = v.1 + 1;
  }
  return Zone { times: times, offs: offs, abbrs: abbrs, dsts: dsts, first: ty.offs[0], first_abbr: ty.abbrs[0], first_dst: ty.dsts[0], rule: rule };
}
```

### `11 struct TypeTable`

```fern
<<11 struct TypeTable>>=
struct TypeTable { offs: i32[], abbrs: string[], dsts: boolean[], next: i32 }
```

### `12 function decode_types(s: string, from: i32): TypeTable`

```fern
<<12 function decode_types(s: string, from: i32): TypeTable>>=
function decode_types(s: string, from: i32): TypeTable {
  let offs: i32[] = [];
  let abbrs: string[] = [];
  let dsts: boolean[] = [];
  let p: i32 = from;
  while (s[p] as i32 != 124) {
    let a: i32 = p;
    while (s[p] as i32 != 58) {
      p = p + 1;
    }
    abbrs = abbrs.append(slice_unchecked(s, a, p) + "");
    let neg: boolean = s[p + 1] as i32 == 45;
    if (neg) {
      p = p + 1;
    }
    let v: (i32, i32) = table_uint(s, p + 1);
    if (neg) {
      offs = offs.append(0 - v.0);
    } else {
      offs = offs.append(v.0);
    }
    dsts = dsts.append(s[v.1 + 1] as i32 == 49);
    p = v.1 + 2;
    if (s[p] as i32 == 44) {
      p = p + 1;
    }
  }
  return TypeTable { offs: offs, abbrs: abbrs, dsts: dsts, next: p + 1 };
}

function table_uint(s: string, p: i32): (i32, i32) {
  let i: i32 = p;
  let v: i32 = 0;
  while (is_digit(s[i] as i32)) {
    v = v * 10 + (s[i] as i32 - 48);
    i = i + 1;
  }
  return (v, i);
}

function table_varint(s: string, p: i32): (i64, i32) {
  let v: i64 = 0;
  let shift: i64 = 1;
  let i: i32 = p;
  let d: i32 = 32;
  while (d >= 32) {
    d = table_digit(s[i] as i32);
    v = v + (d % 32) as i64 * shift;
    shift = shift * (32 as i64);
    i = i + 1;
  }
  return (v, i);
}

function table_digit(c: i32): i32 {
  if (c <= 57) {
    if (c == 43) {
      return 62;
    }
    if (c == 45) {
      return 63;
    }
    return c - 48;
  }
  if (c <= 90) {
    return c - 55;
  }
  return c - 61;
}

function be32(bs: [u8], o: i32): i64 {
  let v: i64 = 0;
  let i: i32 = 0;
  while (i < 4) {
    v = v * (256 as i64) + bs[o + i] as i64;
    i = i + 1;
  }
  return v;
}

function be32s(bs: [u8], o: i32): i64 {
  let v: i64 = be32(bs, o);
  if (v > 2147483647 as i64) {
    return v - 4294967296 as i64;
  }
  return v;
}

function be64s(bs: [u8], o: i32): i64 {
  let v: i64 = 0;
  let i: i32 = 0;
  while (i < 8) {
    v = v * (256 as i64) + bs[o + i] as i64;
    i = i + 1;
  }
  return v;
}
```

### `13 struct Counts`

```fern
<<13 struct Counts>>=
struct Counts { isut: i32, isstd: i32, leap: i32, time: i32, type_: i32, chars: i32 }
```

### `14 function read_counts(bs: [u8], off: i32): Counts`

```fern
<<14 function read_counts(bs: [u8], off: i32): Counts>>=
function read_counts(bs: [u8], off: i32): Counts {
  let bad: Counts = Counts { isut: 0 - 1, isstd: 0, leap: 0, time: 0, type_: 0, chars: 0 };
  if (off < 0 || off + 44 > bs.len()) {
    return bad;
  }
  if (bs[off] as i32 != 84 || bs[off + 1] as i32 != 90 || bs[off + 2] as i32 != 105 || bs[off + 3] as i32 != 102) {
    return bad;
  }
  let c: Counts = Counts { isut: clamp(be32(bs, off + 20)), isstd: clamp(be32(bs, off + 24)), leap: clamp(be32(bs, off + 28)), time: clamp(be32(bs, off + 32)), type_: clamp(be32(bs, off + 36)), chars: clamp(be32(bs, off + 40)) };
  if (c.isut < 0 || c.isstd < 0 || c.leap < 0 || c.time < 0 || c.type_ < 0 || c.chars < 0) {
    return bad;
  }
  return c;
}

function clamp(v: i64): i32 {
  if (v > 1073741823 as i64) {
    return 0 - 1;
  }
  return v as i32;
}

function block_bytes(c: Counts, width: i32): i64 {
  return c.time as i64 * (width as i64) + c.time as i64 + c.type_ as i64 * (6 as i64) + c.chars as i64 + c.leap as i64 * ((width + 4) as i64) + c.isstd as i64 + c.isut as i64;
}

function read_zone_file(path: string): Option[Zone] {
  if (path.len() == 0) {
    return None;
  }
  match (read_file_bytes(path)) {
    Ok(bs) => {
      return parse_tzif(bs).ok();
    },
    Err(_) => {
      return None;
    }
  }
}
```

### `15 pub function parse_tzif(bs: [u8]): Result[Zone, ZoneError]`

```fern
<<15 pub function parse_tzif(bs: [u8]): Result[Zone, ZoneError]>>=
pub function parse_tzif(bs: [u8]): Result[Zone, ZoneError] {
  let h1: Counts = read_counts(bs, 0);
  if (h1.isut < 0 || h1.type_ < 1) {
    return Err(TzifHeader);
  }
  let version: i32 = bs[4] as i32;
  let off: i32 = 44;
  let width: i32 = 4;
  let c: Counts = h1;
  let footer: string = "";
  if (version != 0) {
    let first_block: i64 = off as i64 + block_bytes(h1, 4);
    if (first_block <= bs.len() as i64) {
      let second: i32 = first_block as i32;
      let h2: Counts = read_counts(bs, second);
      if (h2.isut >= 0 && h2.type_ >= 1) {
        c = h2;
        off = second + 44;
        width = 8;
        let end: i64 = off as i64 + block_bytes(h2, 8);
        if (end <= bs.len() as i64) {
          match (read_footer(bs, end as i32)) {
            Some(text) => {
              footer = text;
            },
            None => {
              return Err(TzifText);
            }
          }
        }
      }
    }
  }
  if (off as i64 + block_bytes(c, width) > bs.len() as i64) {
    return Err(TzifTruncated);
  }
  return read_zone_block(bs, c, off, width, footer).ok_or(TzifText);
}
```

### `16 function read_zone_block(bs: [u8], c: Counts, off: i32, width: i32, footer: string): Option[Zone]`

```fern
<<16 function read_zone_block(bs: [u8], c: Counts, off: i32, width: i32, footer: string): Option[Zone]>>=
function read_zone_block(bs: [u8], c: Counts, off: i32, width: i32, footer: string): Option[Zone] {
  let idx_off: i32 = off + c.time * width;
  let type_off: i32 = idx_off + c.time;
  let chars_off: i32 = type_off + c.type_ * 6;
  let offs: i32[] = [];
  let isdst: boolean[] = [];
  let names: string[] = [];
  let i: i32 = 0;
  while (i < c.type_) {
    offs = offs.append(be32s(bs, type_off + i * 6) as i32);
    isdst = isdst.append(bs[type_off + i * 6 + 4] as i32 != 0);
    match (designation(bs, chars_off, c.chars, bs[type_off + i * 6 + 5] as i32)) {
      Some(name) => {
        names = names.append(name);
      },
      None => {
        return None;
      }
    }
    i = i + 1;
  }
  let times: i64[] = [];
  let tofs: i32[] = [];
  let tabb: string[] = [];
  let tdst: boolean[] = [];
  i = 0;
  while (i < c.time) {
    let t: i64 = 0;
    if (width == 8) {
      t = be64s(bs, off + i * 8);
    } else {
      t = be32s(bs, off + i * 4);
    }
    let k: i32 = bs[idx_off + i] as i32;
    if (k >= c.type_) {
      k = 0;
    }
    times = times.append(t);
    tofs = tofs.append(offs[k]);
    tabb = tabb.append(names[k]);
    tdst = tdst.append(isdst[k]);
    i = i + 1;
  }
  let first: i32 = offs[0];
  let first_name: string = names[0];
  i = 0;
  while (i < c.type_) {
    if (!isdst[i]) {
      first = offs[i];
      first_name = names[i];
      i = c.type_;
    } else {
      i = i + 1;
    }
  }
  return Some(Zone { times: times, offs: tofs, abbrs: tabb, dsts: tdst, first: first, first_abbr: first_name, first_dst: false, rule: parse_posix(footer) });
}

function designation(bs: [u8], base: i32, len: i32, at: i32): Option[string] {
  if (at < 0 || at >= len) {
    return Some("");
  }
  let out: u8[] = [];
  let i: i32 = base + at;
  let end: i32 = base + len;
  while (i < end && i < bs.len() && bs[i] as i32 != 0) {
    out = out.append(bs[i]);
    i = i + 1;
  }
  return utf8.from_bytes(out);
}

function read_footer(bs: [u8], start: i32): Option[string] {
  if (start >= bs.len() || bs[start] as i32 != 10) {
    return Some("");
  }
  let i: i32 = start + 1;
  let out: u8[] = [];
  while (i < bs.len() && bs[i] as i32 != 10) {
    out = out.append(bs[i]);
    i = i + 1;
  }
  return utf8.from_bytes(out);
}
```

### `17 pub function parse_posix(s: string): Rule`

```fern
<<17 pub function parse_posix(s: string): Rule>>=
pub function parse_posix(s: string): Rule {
  let r: Rule = utc_rule();
  let std_name: (string, i32) = take_name(s, 0);
  if (std_name.1 <= 0) {
    return r;
  }
  let p: i32 = std_name.1;
  let std: (boolean, i32, i32) = parse_offset(s, p);
  let std_off: i32 = 0;
  if (std.0) {
    std_off = 0 - std.1;
    p = std.2;
  }
  r = Rule { ...r, valid: true, std_off: std_off, dst_off: std_off, std_name: std_name.0, dst_name: std_name.0 };
  let dst_name: (string, i32) = take_name(s, p);
  if (dst_name.1 <= p) {
    return r;
  }
  r = Rule { ...r, has_dst: true, dst_off: r.std_off + 3600, dst_name: dst_name.0 };
  p = dst_name.1;
  if (p < s.len() && s[p] as i32 != 44) {
    let d: (boolean, i32, i32) = parse_offset(s, p);
    if (!d.0) {
      return Rule { ...r, valid: false };
    }
    r = Rule { ...r, dst_off: 0 - d.1 };
    p = d.2;
  }
  let fallback: Rule = Rule { ...r, start: us_dst_start(), end: us_dst_end() };
  if (p >= s.len() || s[p] as i32 != 44) {
    return fallback;
  }
  let a: (boolean, DateRule, i32) = parse_date_rule(s, p + 1);
  if (!a.0 || a.2 >= s.len() || s[a.2] as i32 != 44) {
    return fallback;
  }
  let b: (boolean, DateRule, i32) = parse_date_rule(s, a.2 + 1);
  if (!b.0) {
    return fallback;
  }
  return Rule { ...r, start: a.1, end: b.1 };
}
```

### `18 function us_dst_start(): DateRule`

```fern
<<18 function us_dst_start(): DateRule>>=
function us_dst_start(): DateRule {
  return DateRule { kind: 0, mon: 3, week: 2, day: 0, n: 0, time: 7200 };
}

function us_dst_end(): DateRule {
  return DateRule { kind: 0, mon: 11, week: 1, day: 0, n: 0, time: 7200 };
}

function take_name(s: string, p: i32): (string, i32) {
  if (p >= s.len()) {
    return ("", p);
  }
  if (s[p] as i32 == 60) {
    let i: i32 = p + 1;
    while (i < s.len() && s[i] as i32 != 62) {
      i = i + 1;
    }
    if (i >= s.len() || i - p - 1 < 3) {
      return ("", p);
    }
    return (slice_unchecked(s, p + 1, i) + "", i + 1);
  }
  let j: i32 = p;
  while (j < s.len() && is_alpha(s[j] as i32)) {
    j = j + 1;
  }
  if (j - p < 3) {
    return ("", p);
  }
  return (slice_unchecked(s, p, j) + "", j);
}

function is_alpha(c: i32): boolean {
  return c >= 65 && c <= 90 || c >= 97 && c <= 122;
}

function is_digit(c: i32): boolean {
  return c >= 48 && c <= 57;
}

function parse_offset(s: string, p: i32): (boolean, i32, i32) {
  let i: i32 = p;
  let neg: boolean = false;
  if (i < s.len() && (s[i] as i32 == 43 || s[i] as i32 == 45)) {
    neg = s[i] as i32 == 45;
    i = i + 1;
  }
  if (i >= s.len() || !is_digit(s[i] as i32)) {
    return (false, 0, p);
  }
  let h: i32 = 0;
  let n: i32 = 0;
  while (i < s.len() && is_digit(s[i] as i32) && n < 3) {
    h = h * 10 + (s[i] as i32 - 48);
    i = i + 1;
    n = n + 1;
  }
  if (h > 24) {
    h = 24;
  }
  let total: i32 = h * 3600;
  let k: i32 = 0;
  while (k < 2 && i < s.len() && s[i] as i32 == 58) {
    i = i + 1;
    let v: i32 = 0;
    let d: i32 = 0;
    while (i < s.len() && is_digit(s[i] as i32) && d < 2) {
      v = v * 10 + (s[i] as i32 - 48);
      i = i + 1;
      d = d + 1;
    }
    if (d == 0) {
      return (false, 0, p);
    }
    if (v > 59) {
      v = 59;
    }
    if (k == 0) {
      total = total + v * 60;
    } else {
      total = total + v;
    }
    k = k + 1;
  }
  if (neg) {
    total = 0 - total;
  }
  return (true, total, i);
}
```

### `19 function parse_date_rule(s: string, p: i32): (boolean, DateRule, i32)`

```fern
<<19 function parse_date_rule(s: string, p: i32): (boolean, DateRule, i32)>>=
function parse_date_rule(s: string, p: i32): (boolean, DateRule, i32) {
  let bad: DateRule = DateRule { kind: 2, mon: 0, week: 0, day: 0, n: 0, time: 0 };
  let i: i32 = p;
  let out: DateRule = bad;
  if (i < s.len() && s[i] as i32 == 77) {
    let m: (boolean, i32, i32) = parse_uint(s, i + 1);
    if (!m.0 || m.2 >= s.len() || s[m.2] as i32 != 46) {
      return (false, bad, p);
    }
    let w: (boolean, i32, i32) = parse_uint(s, m.2 + 1);
    if (!w.0 || w.2 >= s.len() || s[w.2] as i32 != 46) {
      return (false, bad, p);
    }
    let d: (boolean, i32, i32) = parse_uint(s, w.2 + 1);
    if (!d.0) {
      return (false, bad, p);
    }
    if (m.1 < 1 || m.1 > 12 || w.1 < 1 || w.1 > 5 || d.1 > 6) {
      return (false, bad, p);
    }
    out = DateRule { kind: 0, mon: m.1, week: w.1, day: d.1, n: 0, time: 7200 };
    i = d.2;
  } else if (i < s.len() && s[i] as i32 == 74) {
    let j: (boolean, i32, i32) = parse_uint(s, i + 1);
    if (!j.0 || j.1 < 1 || j.1 > 365) {
      return (false, bad, p);
    }
    out = DateRule { kind: 1, mon: 0, week: 0, day: 0, n: j.1, time: 7200 };
    i = j.2;
  } else {
    let z: (boolean, i32, i32) = parse_uint(s, i);
    if (!z.0) {
      return (false, bad, p);
    }
    out = DateRule { kind: 2, mon: 0, week: 0, day: 0, n: z.1, time: 7200 };
    i = z.2;
  }
  if (i < s.len() && s[i] as i32 == 47) {
    let t: (boolean, i32, i32) = parse_rule_time(s, i + 1);
    if (!t.0) {
      return (false, bad, p);
    }
    out = DateRule { ...out, time: t.1 };
    i = t.2;
  }
  return (true, out, i);
}

function parse_rule_time(s: string, p: i32): (boolean, i32, i32) {
  let i: i32 = p;
  let sign: i32 = 1;
  if (i < s.len() && (s[i] as i32 == 43 || s[i] as i32 == 45)) {
    if (s[i] as i32 == 45) {
      sign = -1;
    }
    i = i + 1;
  }
  let h: (boolean, i32, i32) = parse_uint(s, i);
  if (!h.0 || h.1 > 167) {
    return (false, 0, p);
  }
  let total: i32 = h.1 * 3600;
  i = h.2;
  let unit: i32 = 60;
  while (unit > 0 && i < s.len() && s[i] as i32 == 58) {
    let v: (boolean, i32, i32) = parse_uint(s, i + 1);
    if (!v.0 || v.1 > 59) {
      return (false, 0, p);
    }
    total = total + v.1 * unit;
    i = v.2;
    unit = unit / 60;
  }
  return (true, sign * total, i);
}

function parse_uint(s: string, p: i32): (boolean, i32, i32) {
  let i: i32 = p;
  let v: i32 = 0;
  while (i < s.len() && is_digit(s[i] as i32)) {
    v = v * 10 + (s[i] as i32 - 48);
    i = i + 1;
  }
  if (i == p) {
    return (false, 0, p);
  }
  return (true, v, i);
}

function rule_dst(r: Rule, sec: i64): boolean {
  if (!r.has_dst) {
    return false;
  }
  let year: i32 = year_of(sec);
  let start: i64 = rule_instant(r.start, year) - r.std_off as i64;
  let end: i64 = rule_instant(r.end, year) - r.dst_off as i64;
  let on: boolean = false;
  if (start <= end) {
    on = sec >= start && sec < end;
  } else {
    on = sec >= start || sec < end;
  }
  return on;
}

function rule_instant(d: DateRule, year: i32): i64 {
  let base: i32 = 0;
  if (year > 1970) {
    base = epoch_day(year, 1, 1);
  }
  let doy: i32 = 1;
  if (d.kind == 0) {
    doy = month_week_day(year, d.mon, d.week, d.day);
  } else if (d.kind == 1) {
    doy = d.n;
    if (doy >= 60 && time.is_leap_year(year)) {
      doy = doy + 1;
    }
  } else {
    doy = d.n + 1;
  }
  return (base + doy - 1) as i64 * (86400 as i64) + d.time as i64;
}

function month_week_day(year: i32, mon: i32, week: i32, day: i32): i32 {
  let first: i64 = time.days_from_civil(year as i64, mon, 1);
  let wd: i32 = (first + 4).rem_euclid(7) as i32;
  let dom: i32 = 1 + (day - wd + 7) % 7 + (week - 1) * 7;
  let last: i32 = time.days_in_month(year, mon);
  while (dom > last) {
    dom = dom - 7;
  }
  return (first + (dom - 1) as i64 - time.days_from_civil(year as i64, 1, 1)) as i32 + 1;
}
```

### `20 function epoch_day(year: i32, mon: i32, day: i32): i32`

```fern
<<20 function epoch_day(year: i32, mon: i32, day: i32): i32>>=
function epoch_day(year: i32, mon: i32, day: i32): i32 {
  return time.days_from_civil(year as i64, mon, day) as i32;
}

function year_of(local_sec: i64): i32 {
  return time.civil_from_days(local_sec.div_euclid(86400)).0 as i32;
}
```

### `24 function darwin_zone_from_tz(spec: string): Zone`

```fern
<<24 function darwin_zone_from_tz(spec: string): Zone>>=
function darwin_zone_from_tz(spec: string): Zone {
  if (spec.len() == 0) {
    return utc_zone();
  }
  match (read_zone_file(darwin_zone_path(spec))) {
    Some(z) => {
      return z;
    },
    None => {}
  }
  if (spec[0] as i32 == 58) {
    return utc_zone();
  }
  let r: Rule = darwin_parse_posix(spec);
  if (!r.valid) {
    return utc_zone();
  }
  return darwin_rule_zone(r);
}

function darwin_zone_path(spec: string): string {
  let name: string = spec;
  if (name[0] as i32 == 58) {
    name = slice_unchecked(name, 1, name.len()) + "";
  }
  if (name.len() > 0 && name[0] as i32 == 47) {
    return name;
  }
  return "/usr/share/zoneinfo/" + name;
}

function darwin_rule_zone(r: Rule): Zone {
  if (!r.has_dst) {
    return rule_zone(r);
  }
  let times: i64[] = [];
  let offs: i32[] = [];
  let abbrs: string[] = [];
  let dsts: boolean[] = [];
  let year: i32 = 1970;
  while (year < 1970 + 600) {
    let start: i64 = rule_instant(r.start, year) - r.std_off as i64;
    let end: i64 = rule_instant(r.end, year) - r.dst_off as i64;
    if (start > end) {
      times = times.append(end).append(start);
      offs = offs.append(r.std_off).append(r.dst_off);
      abbrs = abbrs.append(r.std_name).append(r.dst_name);
      dsts = dsts.append(false).append(true);
    } else {
      times = times.append(start).append(end);
      offs = offs.append(r.dst_off).append(r.std_off);
      abbrs = abbrs.append(r.dst_name).append(r.std_name);
      dsts = dsts.append(true).append(false);
    }
    year = year + 1;
  }
  return Zone { times: times, offs: offs, abbrs: abbrs, dsts: dsts, first: r.std_off, first_abbr: r.std_name, first_dst: false, rule: utc_rule() };
}

function darwin_parse_posix(s: string): Rule {
  let bad: Rule = utc_rule();
  let std_name: (string, i32) = darwin_name(s, 0);
  if (std_name.1 >= s.len()) {
    return bad;
  }
  let std: (boolean, i32, i32) = darwin_offset(s, std_name.1);
  if (!std.0) {
    return bad;
  }
  let std_off: i32 = 0 - std.1;
  let r: Rule = Rule { ...bad, valid: true, std_off: std_off, dst_off: std_off, std_name: std_name.0, dst_name: std_name.0 };
  if (std.2 >= s.len()) {
    return r;
  }
  return darwin_parse_dst(s, std.2, r);
}

function darwin_parse_dst(s: string, from: i32, std: Rule): Rule {
  let name: (boolean, string, i32) = darwin_dst_name(s, from);
  if (!name.0) {
    return utc_rule();
  }
  let p: i32 = name.2;
  let r: Rule = Rule { ...std, has_dst: true, dst_off: std.std_off + 3600, dst_name: name.1 };
  if (p < s.len() && !is_rule_comma(s[p] as i32)) {
    let d: (boolean, i32, i32) = darwin_offset(s, p);
    if (!d.0) {
      return utc_rule();
    }
    r = Rule { ...r, dst_off: 0 - d.1 };
    p = d.2;
  }
  return darwin_rule_dates(r, s, p);
}

function darwin_rule_dates(r: Rule, s: string, p: i32): Rule {
  if (p >= s.len()) {
    return Rule { ...r, start: us_dst_start(), end: us_dst_end() };
  }
  if (!is_rule_comma(s[p] as i32)) {
    return utc_rule();
  }
  return darwin_parse_dates(s, p + 1, r);
}

function darwin_parse_dates(s: string, from: i32, r: Rule): Rule {
  let a: (boolean, DateRule, i32) = darwin_date_rule(s, from);
  if (!a.0 || a.2 >= s.len() || s[a.2] as i32 != 44) {
    return utc_rule();
  }
  let b: (boolean, DateRule, i32) = darwin_date_rule(s, a.2 + 1);
  if (!b.0 || b.2 != s.len()) {
    return utc_rule();
  }
  return Rule { ...r, start: a.1, end: b.1 };
}

function is_rule_comma(c: i32): boolean {
  return c == 44 || c == 59;
}

function darwin_dst_name(s: string, p: i32): (boolean, string, i32) {
  if (s[p] as i32 != 60) {
    let n: (string, i32) = darwin_name(s, p);
    return (true, n.0, n.1);
  }
  return darwin_quoted(s, p);
}
```

### `25 function darwin_name(s: string, p: i32): (string, i32)`

```fern
<<25 function darwin_name(s: string, p: i32): (string, i32)>>=
function darwin_name(s: string, p: i32): (string, i32) {
  let q: (boolean, string, i32) = darwin_quoted(s, p);
  if (q.0) {
    return (q.1, q.2);
  }
  let j: i32 = p;
  while (j < s.len() && !ends_name(s[j] as i32)) {
    j = j + 1;
  }
  return (slice_unchecked(s, p, j) + "", j);
}

function darwin_close(s: string, p: i32): i32 {
  let k: i32 = p;
  while (k < s.len() && s[k] as i32 != 62) {
    k = k + 1;
  }
  return k;
}

function ends_name(c: i32): boolean {
  return is_digit(c) || c == 44 || c == 43 || c == 45;
}

function darwin_quoted(s: string, p: i32): (boolean, string, i32) {
  if (p >= s.len() || s[p] as i32 != 60) {
    return (false, "", p);
  }
  let k: i32 = darwin_close(s, p + 1);
  if (k >= s.len()) {
    return (false, "", p);
  }
  return (true, slice_unchecked(s, p + 1, k) + "", k + 1);
}

function darwin_offset(s: string, p: i32): (boolean, i32, i32) {
  let i: i32 = p;
  let neg: boolean = false;
  if (i < s.len() && (s[i] as i32 == 43 || s[i] as i32 == 45)) {
    neg = s[i] as i32 == 45;
    i = i + 1;
  }
  let t: (boolean, i32, i32) = darwin_secs(s, i);
  if (!t.0 || !neg) {
    return t;
  }
  return (true, 0 - t.1, t.2);
}

function darwin_secs(s: string, p: i32): (boolean, i32, i32) {
  let h: (boolean, i32, i32) = darwin_num(s, p, 0, 167);
  if (!h.0) {
    return h;
  }
  let total: i32 = h.1 * 3600;
  let i: i32 = h.2;
  if (i < s.len() && s[i] as i32 == 58) {
    let m: (boolean, i32, i32) = darwin_num(s, i + 1, 0, 59);
    if (!m.0) {
      return m;
    }
    total = total + m.1 * 60;
    i = m.2;
    if (i < s.len() && s[i] as i32 == 58) {
      let sec: (boolean, i32, i32) = darwin_num(s, i + 1, 0, 60);
      if (!sec.0) {
        return sec;
      }
      total = total + sec.1;
      i = sec.2;
    }
  }
  return (true, total, i);
}

function darwin_num(s: string, p: i32, min: i32, max: i32): (boolean, i32, i32) {
  if (p >= s.len() || !is_digit(s[p] as i32)) {
    return (false, 0, p);
  }
  let v: i32 = 0;
  let i: i32 = p;
  while (i < s.len() && is_digit(s[i] as i32)) {
    v = v * 10 + (s[i] as i32 - 48);
    if (v > max) {
      return (false, 0, p);
    }
    i = i + 1;
  }
  if (v < min) {
    return (false, 0, p);
  }
  return (true, v, i);
}

function darwin_month_rule(s: string, p: i32): (boolean, DateRule, i32) {
  let bad: DateRule = DateRule { kind: 2, mon: 0, week: 0, day: 0, n: 0, time: 0 };
  let m: (boolean, i32, i32) = darwin_num(s, p, 1, 12);
  if (!m.0 || m.2 >= s.len() || s[m.2] as i32 != 46) {
    return (false, bad, p);
  }
  let w: (boolean, i32, i32) = darwin_num(s, m.2 + 1, 1, 5);
  if (!w.0 || w.2 >= s.len() || s[w.2] as i32 != 46) {
    return (false, bad, p);
  }
  let d: (boolean, i32, i32) = darwin_num(s, w.2 + 1, 0, 6);
  if (!d.0) {
    return (false, bad, p);
  }
  return (true, DateRule { kind: 0, mon: m.1, week: w.1, day: d.1, n: 0, time: 7200 }, d.2);
}

function darwin_date_rule(s: string, p: i32): (boolean, DateRule, i32) {
  let day: (boolean, DateRule, i32) = darwin_rule_day(s, p);
  if (!day.0 || day.2 >= s.len() || s[day.2] as i32 != 47) {
    return day;
  }
  let t: (boolean, i32, i32) = darwin_secs(s, day.2 + 1);
  if (!t.0) {
    return (false, day.1, p);
  }
  return (true, DateRule { ...day.1, time: t.1 }, t.2);
}

function darwin_rule_day(s: string, p: i32): (boolean, DateRule, i32) {
  if (p < s.len() && s[p] as i32 == 74) {
    let j: (boolean, i32, i32) = darwin_num(s, p + 1, 1, 365);
    return (j.0, DateRule { kind: 1, mon: 0, week: 0, day: 0, n: j.1, time: 7200 }, j.2);
  }
  if (p < s.len() && s[p] as i32 == 77) {
    return darwin_month_rule(s, p + 1);
  }
  let n: (boolean, i32, i32) = darwin_num(s, p, 0, 365);
  return (n.0, DateRule { kind: 2, mon: 0, week: 0, day: 0, n: n.1, time: 7200 }, n.2);
}
```

### `generated data 26`

The generator controls this chunk. Its boundary markers remain intact.

```fern
<<generated data 26>>=
// ---- BEGIN GENERATED tzdata (go run ./cmd/tzdatagen) ----
// The table contains IANA tzdata 2026c from 1970 onward.
// It has 598 zone names and 324 distinct records.
// See internal/tables/tzdata for the binary format. Do not edit by hand.
pub function iana_version(): string {
  return "2026c";
}

function iana_names(): string {
  return ";Africa/Abidjan=0;Africa/Accra=0;Africa/Addis_Ababa=14;Africa/Algiers=33;Africa/Asmara=14;Africa/Asmera=14;Africa/Bamako=0;Africa/Bangui=136;Africa/Banjul=0;Africa/Bissau=154;Africa/Blantyre=186;Africa/Brazzaville=136;Africa/Bujumbura=186;Africa/Cairo=204;Africa/Casablanca=706;Africa/Ceuta=1072;Africa/Conakry=0;Africa/Dakar=0;Africa/Dar_es_Salaam=14;Africa/Djibouti=14;Africa/Douala=136;Africa/El_Aaiun=1297;Africa/Freetown=0;Africa/Gaborone=186;Africa/Harare=186;Africa/Johannesburg=1657;Africa/Juba=1677;Africa/Kampala=14;Africa/Khartoum=1892;Africa/Kigali=186;Africa/Kinshasa=136;Africa/Lagos=136;Africa/Libreville=136;Africa/Lome=0;Africa/Luanda=136;Africa/Lubumbashi=186;Africa/Lusaka=186;Africa/Malabo=136;Africa/Maputo=186;Africa/Maseru=1657;Africa/Mbabane=1657;Africa/Mogadishu=14;Africa/Monrovia=2107;Africa/Nairobi=14;Africa/Ndjamena=2140;Africa/Niamey=136;Africa/Nouakchott=0;Africa/Ouagadougou=0;Africa/Porto-Novo=136;Africa/Sao_Tome=2181;Africa/Timbuktu=0;Africa/Tripoli=2219;Africa/Tunis=2383;Africa/Windhoek=2506;America/Adak=2794;America/Anchorage=3265;America/Anguilla=3740;America/Antigua=3740;America/Araguaina=3759;America/Argentina/Buenos_Aires=3935;America/Argentina/Catamarca=4075;America/Argentina/ComodRivadavia=4075;America/Argentina/Cordoba=4229;America/Argentina/Jujuy=4382;America/Argentina/La_Rioja=4525;America/Argentina/Mendoza=4684;America/Argentina/Rio_Gallegos=4838;America/Argentina/Salta=4992;America/Argentina/San_Juan=5135;America/Argentina/San_Luis=5294;America/Argentina/Tucuman=5453;America/Argentina/Ushuaia=5617;America/Aruba=3740;America/Asuncion=5771;America/Atikokan=6330;America/Atka=2794;America/Bahia=6349;America/Bahia_Banderas=6574;America/Barbados=6903;America/Belem=6976;America/Belize=7040;America/Blanc-Sablon=3740;America/Boa_Vista=7094;America/Bogota=7179;America/Boise=7224;America/Buenos_Aires=3935;America/Cambridge_Bay=7649;America/Campo_Grande=8098;America/Cancun=8473;America/Caracas=8744;America/Catamarca=4075;America/Cayenne=8793;America/Cayman=6330;America/Chicago=8814;America/Chihuahua=9239;America/Ciudad_Juarez=9568;America/Coral_Harbour=6330;America/Cordoba=4229;America/Costa_Rica=9920;America/Coyhaique=9994;America/Creston=10587;America/Cuiaba=10606;America/Curacao=3740;America/Danmarkshavn=10972;America/Dawson=11177;America/Dawson_Creek=11652;America/Denver=11727;America/Detroit=12152;America/Dominica=3740;America/Edmonton=12548;America/Eirunepe=13144;America/El_Salvador=13245;America/Ensenada=13298;America/Fort_Nelson=13753;America/Fort_Wayne=14253;America/Fortaleza=14330;America/Glace_Bay=14445;America/Godthab=14851;America/Goose_Bay=15362;America/Grand_Turk=15845;America/Grenada=3740;America/Guadeloupe=3740;America/Guatemala=16280;America/Guayaquil=16356;America/Guyana=16401;America/Halifax=16462;America/Havana=16887;America/Hermosillo=17352;America/Indiana/Indianapolis=14253;America/Indiana/Knox=17415;America/Indiana/Marengo=17714;America/Indiana/Petersburg=17853;America/Indiana/Tell_City=18017;America/Indiana/Vevay=18120;America/Indiana/Vincennes=18217;America/Indiana/Winamac=18325;America/Indianapolis=14253;America/Inuvik=18428;America/Iqaluit=18860;America/Jamaica=19292;America/Jujuy=4382;America/Juneau=19425;America/Kentucky/Louisville=19911;America/Kentucky/Monticello=20349;America/Knox_IN=17415;America/Kralendijk=3740;America/La_Paz=20800;America/Lima=20821;America/Los_Angeles=20898;America/Louisville=19911;America/Lower_Princes=3740;America/Maceio=21323;America/Managua=21449;America/Manaus=21570;America/Marigot=3740;America/Martinique=21646;America/Matamoros=21689;America/Mazatlan=21896;America/Mendoza=4684;America/Menominee=22199;America/Merida=22608;America/Metlakatla=22935;America/Mexico_City=23197;America/Miquelon=23500;America/Moncton=23778;America/Monterrey=24194;America/Montevideo=24508;America/Montreal=24829;America/Montserrat=3740;America/Nassau=24829;America/New_York=25254;America/Nipigon=24829;America/Nome=25679;America/Noronha=26152;America/North_Dakota/Beulah=26265;America/North_Dakota/Center=26738;America/North_Dakota/New_Salem=27189;America/Nuuk=14851;America/Ojinaga=27640;America/Panama=6330;America/Pangnirtung=18860;America/Paramaribo=27992;America/Phoenix=10587;America/Port-au-Prince=28034;America/Port_of_Spain=3740;America/Porto_Acre=28303;America/Porto_Velho=28393;America/Puerto_Rico=3740;America/Punta_Arenas=28458;America/Rainy_River=28971;America/Rankin_Inlet=29396;America/Recife=29815;America/Regina=29929;America/Resolute=29948;America/Rio_Branco=28303;America/Rosario=4229;America/Santa_Isabel=13298;America/Santarem=30367;America/Santiago=30451;America/Santo_Domingo=31036;America/Sao_Paulo=31144;America/Scoresbysund=31518;America/Shiprock=11727;America/Sitka=32041;America/St_Barthelemy=3740;America/St_Johns=32514;America/St_Kitts=3740;America/St_Lucia=3740;America/St_Thomas=3740;America/St_Vincent=3740;America/Swift_Current=32999;America/Tegucigalpa=33037;America/Thule=33101;America/Thunder_Bay=24829;America/Tijuana=13298;America/Toronto=24829;America/Tortola=3740;America/Vancouver=33317;America/Virgin=3740;America/Whitehorse=33932;America/Winnipeg=28971;America/Yakutat=34388;America/Yellowknife=12548;Antarctica/Casey=34848;Antarctica/Davis=34966;Antarctica/DumontDUrville=35022;Antarctica/Macquarie=35044;Antarctica/Mawson=35506;Antarctica/McMurdo=35546;Antarctica/Palmer=35937;Antarctica/Rothera=36354;Antarctica/South_Pole=35546;Antarctica/Syowa=36389;Antarctica/Troll=36410;Antarctica/Vostok=36467;Arctic/Longyearbyen=36525;Asia/Aden=36389;Asia/Almaty=36742;Asia/Amman=37051;Asia/Anadyr=37529;Asia/Aqtau=37922;Asia/Aqtobe=38232;Asia/Ashgabat=38547;Asia/Ashkhabad=38547;Asia/Atyrau=38720;Asia/Baghdad=39030;Asia/Bahrain=39324;Asia/Baku=39363;Asia/Bangkok=39742;Asia/Barnaul=39763;Asia/Beirut=40148;Asia/Bishkek=40429;Asia/Brunei=40737;Asia/Calcutta=40758;Asia/Chita=40780;Asia/Choibalsan=41172;Asia/Chongqing=41466;Asia/Chungking=41466;Asia/Colombo=41558;Asia/Dacca=41629;Asia/Damascus=41674;Asia/Dhaka=41629;Asia/Dili=42201;Asia/Dubai=42246;Asia/Dushanbe=42267;Asia/Famagusta=42435;Asia/Gaza=42928;Asia/Harbin=41466;Asia/Hebron=44372;Asia/Ho_Chi_Minh=45826;Asia/Hong_Kong=45865;Asia/Hovd=45978;Asia/Irkutsk=46272;Asia/Istanbul=46658;Asia/Jakarta=47113;Asia/Jayapura=47132;Asia/Jerusalem=47151;Asia/Kabul=47530;Asia/Kamchatka=47558;Asia/Karachi=47927;Asia/Kashgar=48009;Asia/Kathmandu=48030;Asia/Katmandu=48030;Asia/Khandyga=48078;Asia/Kolkata=40758;Asia/Krasnoyarsk=48498;Asia/Kuala_Lumpur=48884;Asia/Kuching=40737;Asia/Kuwait=36389;Asia/Macao=48925;Asia/Macau=48925;Asia/Magadan=49037;Asia/Makassar=49430;Asia/Manila=49451;Asia/Muscat=42246;Asia/Nicosia=49504;Asia/Novokuznetsk=49799;Asia/Novosibirsk=50167;Asia/Omsk=50552;Asia/Oral=50938;Asia/Phnom_Penh=39742;Asia/Pontianak=51253;Asia/Pyongyang=51291;Asia/Qatar=39324;Asia/Qostanay=51335;Asia/Qyzylorda=51656;Asia/Rangoon=51965;Asia/Riyadh=36389;Asia/Saigon=45826;Asia/Sakhalin=51993;Asia/Samarkand=52374;Asia/Seoul=52530;Asia/Shanghai=41466;Asia/Singapore=48884;Asia/Srednekolymsk=52582;Asia/Taipei=52969;Asia/Tashkent=53032;Asia/Tbilisi=53200;Asia/Tehran=53499;Asia/Tel_Aviv=47151;Asia/Thimbu=53913;Asia/Thimphu=53913;Asia/Tokyo=53954;Asia/Tomsk=53973;Asia/Ujung_Pandang=49430;Asia/Ulaanbaatar=41172;Asia/Ulan_Bator=41172;Asia/Urumqi=48009;Asia/Ust-Nera=54358;Asia/Vientiane=39742;Asia/Vladivostok=54762;Asia/Yakutsk=55149;Asia/Yangon=51965;Asia/Yekaterinburg=55535;Asia/Yerevan=55921;Atlantic/Azores=56280;Atlantic/Bermuda=56508;Atlantic/Canary=56894;Atlantic/Cape_Verde=57107;Atlantic/Faeroe=57145;Atlantic/Faroe=57145;Atlantic/Jan_Mayen=36525;Atlantic/Madeira=57348;Atlantic/Reykjavik=0;Atlantic/South_Georgia=57541;Atlantic/St_Helena=0;Atlantic/Stanley=57561;Australia/ACT=57901;Australia/Adelaide=58328;Australia/Brisbane=58757;Australia/Broken_Hill=58834;Australia/Canberra=57901;Australia/Currie=59263;Australia/Darwin=59699;Australia/Eucla=59723;Australia/Hobart=59263;Australia/LHI=59829;Australia/Lindeman=60196;Australia/Lord_Howe=59829;Australia/Melbourne=60293;Australia/NSW=57901;Australia/North=59699;Australia/Perth=60720;Australia/Queensland=58757;Australia/South=58328;Australia/Sydney=57901;Australia/Tasmania=59263;Australia/Victoria=60293;Australia/West=60720;Australia/Yancowinna=58834;Brazil/Acre=28303;Brazil/DeNoronha=26152;Brazil/East=31144;Brazil/West=21570;CET=60818;CST6CDT=8814;Canada/Atlantic=16462;Canada/Central=28971;Canada/Eastern=24829;Canada/Mountain=12548;Canada/Newfoundland=32514;Canada/Pacific=33317;Canada/Saskatchewan=29929;Canada/Yukon=33932;Chile/Continental=30451;Chile/EasterIsland=61065;Cuba=16887;EET=61676;EST=6330;EST5EDT=25254;Egypt=204;Eire=61946;Etc/GMT=0;Etc/GMT+0=0;Etc/GMT+1=62244;Etc/GMT+10=62264;Etc/GMT+11=62286;Etc/GMT+12=62308;Etc/GMT+2=57541;Etc/GMT+3=8793;Etc/GMT+4=20800;Etc/GMT+5=62330;Etc/GMT+6=62351;Etc/GMT+7=62372;Etc/GMT+8=62393;Etc/GMT+9=62414;Etc/GMT-0=0;Etc/GMT-1=62435;Etc/GMT-10=35022;Etc/GMT-11=62455;Etc/GMT-12=62477;Etc/GMT-13=62499;Etc/GMT-14=62521;Etc/GMT-2=62543;Etc/GMT-3=36389;Etc/GMT-4=42246;Etc/GMT-5=62563;Etc/GMT-6=48009;Etc/GMT-7=39742;Etc/GMT-8=40737;Etc/GMT-9=62584;Etc/GMT0=0;Etc/Greenwich=0;Etc/UCT=62605;Etc/UTC=62605;Etc/Universal=62605;Etc/Zulu=62605;Europe/Amsterdam=60818;Europe/Andorra=62619;Europe/Astrakhan=62786;Europe/Athens=61676;Europe/Belfast=63156;Europe/Belgrade=63463;Europe/Berlin=36525;Europe/Bratislava=63650;Europe/Brussels=60818;Europe/Bucharest=63877;Europe/Budapest=64117;Europe/Busingen=64334;Europe/Chisinau=64541;Europe/Copenhagen=36525;Europe/Dublin=61946;Europe/Gibraltar=65040;Europe/Guernsey=63156;Europe/Helsinki=65237;Europe/Isle_of_Man=63156;Europe/Istanbul=46658;Europe/Jersey=63156;Europe/Kaliningrad=65447;Europe/Kiev=65826;Europe/Kirov=66061;Europe/Kyiv=65826;Europe/Lisbon=66435;Europe/Ljubljana=63463;Europe/London=63156;Europe/Luxembourg=60818;Europe/Madrid=66706;Europe/Malta=66983;Europe/Mariehamn=65237;Europe/Minsk=67299;Europe/Monaco=67665;Europe/Moscow=67922;Europe/Nicosia=49504;Europe/Oslo=36525;Europe/Paris=67665;Europe/Podgorica=63463;Europe/Prague=63650;Europe/Riga=68306;Europe/Rome=68581;Europe/Samara=68897;Europe/San_Marino=68581;Europe/Sarajevo=63463;Europe/Saratov=69277;Europe/Simferopol=69647;Europe/Skopje=63463;Europe/Sofia=70046;Europe/Stockholm=36525;Europe/Tallinn=70286;Europe/Tirane=70561;Europe/Tiraspol=64541;Europe/Ulyanovsk=70838;Europe/Uzhgorod=65826;Europe/Vaduz=64334;Europe/Vatican=68581;Europe/Vienna=71241;Europe/Vilnius=71458;Europe/Volgograd=71756;Europe/Warsaw=72142;Europe/Zagreb=63463;Europe/Zaporozhye=65826;Europe/Zurich=64334;Factory=72389;GB=63156;GB-Eire=63156;GMT=0;GMT+0=0;GMT-0=0;GMT0=0;Greenwich=0;HST=72405;Hongkong=45865;Iceland=0;Indian/Antananarivo=14;Indian/Chagos=72425;Indian/Christmas=39742;Indian/Cocos=51965;Indian/Comoro=14;Indian/Kerguelen=62563;Indian/Mahe=42246;Indian/Maldives=62563;Indian/Mauritius=72464;Indian/Mayotte=14;Indian/Reunion=42246;Iran=53499;Israel=47151;Jamaica=19292;Japan=53954;Kwajalein=72519;Libya=2219;MET=60818;MST=10587;MST7MDT=11727;Mexico/BajaNorte=13298;Mexico/BajaSur=21896;Mexico/General=23197;NZ=35546;NZ-CHAT=72560;Navajo=11727;PRC=41466;PST8PDT=20898;Pacific/Apia=72970;Pacific/Auckland=35546;Pacific/Bougainville=73147;Pacific/Chatham=72560;Pacific/Chuuk=35022;Pacific/Easter=61065;Pacific/Efate=73188;Pacific/Enderbury=73334;Pacific/Fakaofo=73394;Pacific/Fiji=73436;Pacific/Funafuti=62477;Pacific/Galapagos=73612;Pacific/Gambier=62414;Pacific/Guadalcanal=62455;Pacific/Guam=73676;Pacific/Honolulu=72405;Pacific/Johnston=72405;Pacific/Kanton=73334;Pacific/Kiritimati=73780;Pacific/Kosrae=73842;Pacific/Kwajalein=72519;Pacific/Majuro=62477;Pacific/Marquesas=73882;Pacific/Midway=73910;Pacific/Nauru=73930;Pacific/Niue=62286;Pacific/Norfolk=73972;Pacific/Noumea=74068;Pacific/Pago_Pago=73910;Pacific/Palau=62584;Pacific/Pitcairn=74134;Pacific/Pohnpei=62455;Pacific/Ponape=62455;Pacific/Port_Moresby=35022;Pacific/Rarotonga=74176;Pacific/Saipan=73676;Pacific/Samoa=73910;Pacific/Tahiti=62264;Pacific/Tarawa=62477;Pacific/Tongatapu=74359;Pacific/Truk=35022;Pacific/Wake=62477;Pacific/Wallis=62477;Pacific/Yap=35022;Poland=72142;Portugal=66435;ROC=52969;ROK=52530;Singapore=48884;Turkey=46658;UCT=62605;US/Alaska=3265;US/Aleutian=2794;US/Arizona=10587;US/Central=8814;US/East-Indiana=14253;US/Eastern=25254;US/Hawaii=72405;US/Indiana-Starke=17415;US/Michigan=12152;US/Mountain=11727;US/Pacific=20898;US/Samoa=73910;UTC=62605;Universal=62605;W-SU=67922;WET=66435;Zulu=62605;";
}

function iana_records(): string {
  return "GMT0|GMT:0:0|;EAT-3|EAT:10800:0|;CET-1|WET:0:0,WEST:3600:1,CET:3600:0,CEST:7200:1|eybg11WanD0uZWq51eiuE2udnD3u--F2m+XZ10u--F1urpG0eu-F2;WAT-1|WAT:3600:0|;GMT0|-01:-3600:0,GMT:0:0|utlW51;CAT-2|CAT:7200:0|;EET-2EEST,M4.5.5/0,M10.5.4/24|EET:7200:0,EEST:10800:1|einA1ujkD0eaqI1ujkD0e+sI1ujkD0eaqI1ujkD0eaqI1ujkD0eaqI1ujkD0e+sI1ujkD0eaqI1ujkD0eaqI1ujkD0eaqI1ujkD0e+sI1ujkD0eaqI1ujkD0ecZQ1uh-50eq+O1uzZ70e+sI1ujkD0eaqI1ujkD0eaqI1ujkD0eaqI1ujkD0e+sI1ujkD0ecYJ1uhWD0eaqI1ujkD0eaqI1ujkD0e+sI1ujkD0eaqI1ujkD0eaqI1ujkD0mohI1eWnD0utkI1eWnD0utkI1eWnD0utkI1eWnD0ujYJ1eWnD0utkI1eWnD0utkI1eWnD0utkI1eWnD0utkI1eWnD0ujYJ1eWnD0utkI1eWnD0utkI1egzC0ujYJ1e+rB0uvfK1eeYB0ulzK1eokA0uxaM1eoX90ulq21e+w10uXfq31eWs30unY31eiz40uZqp81;<+00>0|+00:0:0,+01:3600:1,+01:3600:0,+00:0:1|Wksl41e+X60uZkr11eqY80uz-N1eubD0u-pL1eyp50uneq52eyqv10uXolM1eqY80uz-N1esZ70ulgM1emp80ulzK1eokA0ebWO1Wqc70Wct21Wgp30WqkI1Wya60Wq-21Wix60WanD1Waz70WkY31WYl70WanD1Wou60WkY31Wqp80WanD1Wya60WkY31WWx90WkzC1Wmz40Was31WskA0WkzC1Wwf40WkY31WYsB2WopG3WkY32W+rR3Was32W+rR3WkY32W+rR3Was32W+rR3WkY32WqfS3WkY32W+rR3Was32W+rR3WkY32eu-F0;CET-1CEST,M3.5.0,M10.5.0/3|WET:0:0,WEST:3600:1,CET:3600:0,CEST:7200:1|Wksl41e+X60uZkr11eqY80uz-N1eubD0u-pL1eyp50uneq52upiX23Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2WopG3;<+00>0|-01:-3600:0,+00:0:0,+01:3600:1,+01:3600:0,+00:0:1|uvsf61esl12eqY81uz-N2eubD1u-pL2eyp51ullzT2eqY81uz-N2esZ71ulgM2emp81ulzK2eokA1ebWO2Wqc71Wct22Wgp31WqkI2Wya61Wq-22Wix61WanD2Waz71WkY32WYl71WanD2Wou61WkY32Wqp81WanD2Wya61WkY32WWx91WkzC2Wmz41Was32WskA1WkzC2Wwf41WkY32WYsB3WopG4WkY33W+rR4Was33W+rR4WkY33W+rR4Was33W+rR4WkY33WqfS4WkY33W+rR4Was33W+rR4WkY33eu-F1;SAST-2|SAST:7200:0|;CAT-2|CAT:7200:0,CAST:10800:1,EAT:10800:0|menA1eorE0ubgH1eiuE0u-iH1eiuE0uhdH1ecxE0unaH1eW+E0utXH1ewWF0uz+G1ekcF0ufvG1eefF0ubgH1eiuE0uhdH1ecxE0unaH1ewWF0uz+G1eqZF0uZyG1ekcF0ufvG1eefF0ubgH1ecxE0unaH1eW+E0uomfE2e-qZL0;CAT-2|CAT:7200:0,CAST:10800:1,EAT:10800:0|menA1eorE0ubgH1eiuE0u-iH1eiuE0uhdH1ecxE0unaH1eW+E0utXH1ewWF0uz+G1ekcF0ufvG1eefF0ubgH1eiuE0uhdH1ecxE0unaH1ewWF0uz+G1eqZF0uZyG1ekcF0ufvG1eefF0ubgH1ecxE0unaH1eW+E0uomfE2etdxH0;GMT0|MMT:-2670:0,GMT:0:0|zcjfv31;WAT-1|WAT:3600:0,WAST:7200:1|e+Ww91emwC0;GMT0|GMT:0:0,WAT:3600:0|uxyam11WoYW10;EET-2|EET:7200:0,CET:3600:0,CEST:7200:1|m+cXC1udz72eoYG1u--F2eoYG1uvYG2eoYG1uXkG2emqF1ujeG2eu-F1uhwF2eoYG1uvYG2eoYG1u--F2eoYG1uvyI0e+tj61udhG2eoYG0m-vaF1W+cC2WqkI0;CET-1|CET:3600:0,CEST:7200:1|each71WkzC0W+dJ1WgkD0W+gs91WecA0Wy-F1Wy-F0W+dJ1WmhD0WccqE1uphD0uznF1WgYJ0WkzC1WgYJ0WanD1WqkI0;CAT-2|SAST:7200:0,CAT:7200:0,WAT:3600:1|me-eK1WYjW42eXsE1emkI2udnD1ecYJ2unzC1ecYJ2udnD1emkI2udnD1emkI2udnD1emkI2udnD1emkI2udnD1ecYJ2unzC1ecYJ2udnD1emkI2udnD1emkI2udnD1emkI2udnD1emkI2udnD1ecYJ2udnD1emkI2udnD1emkI2udnD1emkI2udnD1emkI2udnD1ecYJ2unzC1ecYJ2udnD1emkI2udnD1emkI2udnD1emkI2udnD1;HST10HDT,M3.2.0,M11.1.0|BST:-39600:0,BDT:-36000:1,AHST:-36000:0,HST:-36000:0,HDT:-32400:1|u+aA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG2m+s23mzeD4eu-F3u--F4eu-F3u--F4eu-F3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3ubsB4;AKST9AKDT,M3.2.0,M11.1.0|AHST:-36000:0,AHDT:-32400:1,YST:-32400:0,AKST:-32400:0,AKDT:-28800:1|WxaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG2m+s23mzeD4eu-F3u--F4eu-F3u--F4eu-F3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3ubsB4;AST4|AST:-14400:0|;<-03>3|-03:-10800:0,-02:-7200:1|exhyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0upZs51eokA0ulzK1e+rB0upiK1emwC0uZsJ1e+rB0uZsJ1egzC0uZsJ1e+rB0ulzK1eeYB0unuM1ecd90ufss91eokA0;<-03>3|-03:-10800:0,-02:-7200:1,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1e+rB0uvfK1e+rB0uvfK1eqfC0uzWp62WmhD0Wacx71eku60ujYJ1egzC0;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1e+rB2mzfK1mwrB0uvfK1eqfC0uzWp63WmhD0Wcge42unr10eicn31eku60;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1e+rB2mzfK1mwrB0uvfK1eqfC0uzWp63WmhD0Wacx71eku60ujYJ1egzC0;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC2mpzK3eqfC2uXxH1mczC0uvfK1eqfC0uzWp63WmhD0Wacx71eku60;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1egmB2mry50euoE1e+rB0uvfK1eqfC0uzWp63WmhD0Wcge42unr10eicn31eku60;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC2mXvJ3ecXC2uhXK3eWaC2uvfK1mmfC0uzWp63WmhD0Wymd42ulYB0euoe31eku60;<-03>3|-03:-10800:0,-02:-7200:1,-03:-10800:1,-04:-14400:0|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1e+rB0uvfK1e+rB0uvfK1eqfC0uzWp62WmhD0Wcge43unr10eicn31eku60;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1e+rB2mzfK1mwrB0uvfK1eqfC0uzWp63WmhD0Wacx71eku60;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1egmB2mry50euoE1e+rB0uvfK1eqfC0uzWp63WmhD0Wide42uvw40e+Zk31eku60;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eubD2mzyI3ecXC2uxY80eush83WmhD0Wide42uvw40e+Zk31euz13uZd42ujYJ3egzC2ujYJ0;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1e+rB2mzfK1mwrB0uvfK1eqfC0uzWp63WmhD0Wcge42uxX10eYwn31eku60ujYJ1egzC0;<-03>3|-03:-10800:0,-02:-7200:1,-03:-10800:1,-04:-14400:0|efhY41emp80uZfqE1eee80uZsJ1eqfC0uvfK1e+rB0uvfK1e+rB0uvfK1eqfC0uzWp62WmhD0Woae43ubx10eicn31eku60;<-03>3|-04:-14400:0,-03:-10800:0,-03:-10800:1|Wdeu21egYm10uhbm12eihD0u-vI2eoeD0u-vI2eoeD0u-vI2eu-F0uvYG2eoYG0uvYG2eu-F0uvYG2eu-F0uvYG2eu-F0uvYG2eoYG0uvYG2eu-F0uvYG2eu-F0uvYG2eu-F0uvYG2eoYG0uvYG2eu-F0uxzH2esaE0uvYG2eu-F0uxmG2egzC0udbJ2esnF0upbG2e+YD0up-I2eaWD0ujYJ2eihD0uXeJ2eqfC0uZsJ2egzC0ujYJ2eWnD0utkI2eWnD0utkI2eWnD0ujYJ2eu-F0unzC2ecYJ0udnD2emkI0uhdH2egzC0ujYJ2egzC0ujYJ2egzC0uZsJ2eqfC0uZsJ2eqfC0uZsJ2eYiF0ufiF2ekpG0ufiF2ekpG0u--F2eiuE0uhdH2eiuE0uhdH2eiuE0uhdH2eYiF0urpG2eYiF0urpG2eYiF0uhdH2eiuE0uhdH2eiuE0uhdH2eYiF0urpG2eYiF0urpG2eYiF0urpG2eYiF0uhdH2ecP1;EST5|EST:-18000:0|;<-03>3|-03:-10800:0,-02:-7200:1|exhyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0uxaM1eokA0ubnL1eyw90unuM1emp80unuM1eeYB0ulzK1eeYB0ulzK1eokA0ulzK1e+rB0upiK1emwC0uZsJ1e+rB0uZsJ1egzC0uZsJ1e+rB0ulzK1eeYB0unuM1ecd90uxYs81e+rB0;CST6|MST:-25200:0,MDT:-21600:1,CDT:-18000:1,CST:-21600:0|uhbhQ1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0urpG1egzC0urpG1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE2mikI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3;AST4|AST:-14400:0,ADT:-10800:1|my-k71eyw90uhdH1eiuE0uhdH1eiuE0uXxH1eeyD0;<-03>3|-03:-10800:0,-02:-7200:1|exhyF1e+rB0uZsJ1eyw90urdM1ecd90;CST6|CST:-21600:0,CDT:-18000:1|mwX+31emv50utdy81eiz40;<-04>4|-04:-14400:0,-03:-10800:1|W-hyF1e+rB0uZsJ1eyw90urdM1ecd90uZYsB1egzC0uZsJ1eoJ0;<-05>5|-05:-18000:0,-04:-14400:1|u+WjM1eipO0;MST7MDT,M3.2.0,M11.1.0|MST:-25200:0,MDT:-21600:1|ulaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0utp81eWiN0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;MST7MDT,M3.2.0,M11.1.0|MST:-25200:0,MDT:-21600:1,CST:-21600:0,CDT:-18000:1,EST:-18000:0|urtg21eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI2WanD3emkI4mkJ2WzzC1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;<-04>4|-04:-14400:0,-03:-10800:1|W-hyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0uxaM1eokA0ubnL1eyw90unuM1emp80unuM1eeYB0ulzK1eeYB0ulzK1eokA0ulzK1e+rB0upiK1emwC0uZsJ1e+rB0uZsJ1egzC0uZsJ1e+rB0ulzK1eeYB0unuM1ecd90ubnL1eokA0ub+M1eer90ulzK1eeYB0unuM1eyw90uvfK1eeYB0ubnL1eokA0ubnL1eeYB0ulzK1eeYB0ulzK1e+rB0ulzK1eokA0ubnL1eokA0ubnL1eeYB0ulzK1eeYB0ulzK1eeYB0ulzK1eeYB0unuM1ecd90;EST5|CST:-21600:0,EST:-18000:0,CDT:-18000:1,EDT:-14400:1|WetWC1umxW10elofD2ewwH0uzaE2ewwH1WwaE3eokA2uhi70uzaE2emkI0udnD2emkI0urpG2egzC0urpG2ewwH0uzaE2ewwH0uzaE2emkI0udnD2emkI0udnD2emkI0udnD2emkI0uzaE2ewwH0uzaE2ewwH0uzaE2emkI0udnD2emkI0udnD2emkI0uzaE2ewwH0uzaE2ewwH0utp81;<-04>4|-04:-14400:0,-0430:-16200:0|ewwXc11Walj80;<-03>3|-03:-10800:0|;CST6CDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1|WiaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;CST6|CST:-21600:0,CDT:-18000:1,MDT:-21600:1,MST:-25200:0|WebhQ1ewwH0uzaE1ewwH0mXbE2ewwH3uzaE2emkI3udnD2emkI3urpG2egzC3urpG2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI0;MST7MDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1,MDT:-21600:1,MST:-25200:0|WebhQ1ewwH0uzaE1ewwH0mXbE2ewwH3uzaE2emkI3udnD2emkI3urpG2egzC3urpG2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uxfC2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ubsB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ubsB2eezK3ulYB2eofK0m+s23;CST6|CST:-21600:0,CDT:-18000:1|mYub91emp80udiN1emp80uxhrA1eggE0ujrH1ecW50;<-03>3|-03:-10800:1,-04:-14400:0,-03:-10800:0|eXr71uhdH0eWnD1utkI0eWnD1ujYJ0egzC1uXxH0esaE1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0eu-F1u--F0eWnD1utkI0eWnD1ujYJ0egzC1urpG0eYiF1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0eiuE1uhdH0eWnD1uhdH0ekpG1urpG0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0eiuE1uhdH0eWnD1utkI0eYiF1urpG0emkI1ujd90eqaM1ulYB0eezK1ubsB0eofK1ubsB0eias11uXW80es-N1uXW80es-N1uXW80eezK1udnD0emkI1udnD0emkI1udnD0emkI1uzaE0ewwH1udnD0ecYJ1udnD0es+G2;MST7|MST:-25200:0|;<-04>4|-04:-14400:0,-03:-10800:1|W-hyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0uxaM1eokA0ubnL1eyw90unuM1emp80unuM1eeYB0ulzK1eeYB0ulzK1eokA0ulzK1e+rB0upiK1emwC0uZsJ1e+rB0uZsJ1egzC0uZsJ1e+rB0ulzK1eeYB0unuM1ecd90uzzs11eer90ulzK1eeYB0unuM1eyw90uvfK1eeYB0ubnL1eokA0ubnL1eeYB0ulzK1eeYB0ulzK1e+rB0ulzK1eokA0ubnL1eokA0ubnL1eeYB0ulzK1eeYB0ulzK1eeYB0ulzK1eeYB0unuM1ecd90;GMT0|-03:-10800:0,-02:-7200:1,GMT:0:0|uwjfA1WthF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0mrs82;MST7|YST:-32400:0,PST:-28800:0,PDT:-25200:1,MST:-25200:0|uftw31ubom62eu-F1u--F2eu-F1u--F2ekpG1ufiF2ekpG1u--F2eu-F1u--F2eu-F1u--F2eu-F1uzaE2ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1uzaE2ewwH1uzaE2ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1uzaE2ewwH1uzaE2ewwH1uzaE2ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1uzaE2ewwH1uzaE2ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1ubsB2eezK1ulYB2eezK1ulYB2eezK1ubsB2eezK1ulYB2eezK1ulYB2eezK1ulYB2eezK1ulYB2eezK1ulYB2eezK1ubsB2eezK1ulYB2eezK1ulYB2eezK1ulYB2eezK1ulYB2uWzK3;MST7|PST:-28800:0,PDT:-25200:1,MST:-25200:0|mpaA1eu-F0u--F1ekpG0u--F1eWtA2;MST7MDT,M3.2.0,M11.1.0|MST:-25200:0,MDT:-21600:1|ulaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1|ectg31eu-F0u-a61euwP0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;CST6|MST:-25200:0,MDT:-21600:1,CST:-21600:0|urtg21eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK2;<-05>5|-05:-18000:0,-04:-14400:1,-04:-14400:0|uYiyF1e+rB0uZsJ1eyw90urdM1ecd90ufts51eeYB0u-hiE2eksi50;CST6|CST:-21600:0,CDT:-18000:1|mqkiH1egzC0ujYJ1egzC0;PST8PDT,M3.2.0,M11.1.0|PST:-28800:0,PDT:-25200:1|mpaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0ea-50;MST7|PST:-28800:0,PDT:-25200:1,MST:-25200:0|mpaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB2;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1|eeaA1eu-F0ufonZ11emkI0ubsB1;<-03>3|-03:-10800:0,-02:-7200:1|exhyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0uzkr91egzC0uZsJ1eed10ubiV1eeYB0;AST4ADT,M3.2.0,M11.1.0|AST:-14400:0,ADT:-10800:1|mgtg21eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;<-02>2<-01>,M3.5.0/-1,M10.5.0/0|-03:-10800:0,-02:-7200:1,-02:-7200:0|uwjfA1WthF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC2WgYJ2;AST4ADT,M3.2.0,M11.1.0|AST:-14400:0,ADT:-10800:1,ADDT:-7200:1|maaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0gsaE1ewwH0uzaE2mikI0mhnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1cclK1;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1,AST:-14400:0|eifh91eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB2W+oW31;CST6|CST:-21600:0,CDT:-18000:1|msbz31ew-70urke91eqyA0untm71eiuE0ubasE1eWnD0;<-05>5|-05:-18000:0,-04:-14400:1|uui-M1e+X60;<-04>4|-0345:-13500:0,-03:-10800:0,-04:-14400:0|Ygap51+YwsG2;AST4ADT,M3.2.0,M11.1.0|AST:-14400:0,ADT:-10800:1|maaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;CST5CDT,M3.2.0/0,M11.1.0/1|CST:-18000:0,CDT:-14400:1|uWaA1eu-F0u--F1ekpG0u--F1esaE0uXxH1emdE0uduH1eggE0ujrH1eu-F0u--F1ekpG0ufiF1ekpG0urpG1eWnD0uzaE1emkI0udnD1emkI0utkI1eWnD0utkI1eWnD0utkI1eWnD0utkI1esaE0uXxH1esaE0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0ufiF1eadH0ufiF1WopG0WciF1WopG0WciF1WopG0WciF1WopG0WciF1WopG0Wy-F1Wy-F0Wy-F1WopG0WmuE1WqkI0WanD1WgYJ0WanD1WqkI0WanD1WqkI0WwaE1W+wH0WwaE1W+wH0WanD1WwXp20WYsB1WsfK0WufC1WWsJ0WYsB1WsfK0WufC1WsfK0WufC1WizK0WufC1WgYJ0;MST7|MST:-25200:0,MDT:-21600:1|uhbhQ1ewwH0uzaE1ewwH0uzaE1ewwH0;CST6CDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1,EST:-18000:0|WiaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH2WselE1WqkI0ubsB1;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1,CDT:-18000:1|eeaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a62WywP0WskA1e+mL0ux-mU1emkI0ubsB1;EST5EDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1,EST:-18000:0|WiaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG2WoimS1WqkI0ubsB1eezK2;CST6CDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1,CDT:-18000:1,CST:-21600:0|eeaA1eu-F0ufonZ12WqkI3ubsB2;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1|eeaA1eu-F0u--F1ekpG0u--F1eu-F0uZ-mX11emkI0ubsB1;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1,CDT:-18000:1,CST:-21600:0|eeaA1eu-F0ufonZ12WqkI3ubsB2eezK0;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1,CDT:-18000:1,CST:-21600:0|eeaA1eu-F0ufonZ12WqkI3ubsB1;MST7MDT,M3.2.0,M11.1.0|PST:-28800:0,PDT:-25200:1,MDT:-21600:1,MST:-25200:0|mvtg21eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F2mq-F3u--F2eu-F3u--F2eu-F3u--F2ekpG3ufiF2ekpG3u--F2eu-F3u--F2eu-F3u--F2eu-F3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3ubsB2;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1,CST:-21600:0,CDT:-18000:1|ektg21eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI2mhnD3emkI0WanD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;EST5|EST:-18000:0,EDT:-14400:1|e+xW41euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0;AKST9AKDT,M3.2.0,M11.1.0|PST:-28800:0,PDT:-25200:1,YDT:-28800:1,YST:-32400:0,AKST:-32400:0,AKDT:-28800:1|mpaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F2Wy-F0Wy-F1eu-F0u--F1ekpG0ufiF1ekpG3Wct24mzeD5eu-F4u--F5eu-F4u--F5eu-F4uzaE5ewwH4uzaE5emkI4udnD5emkI4udnD5emkI4uzaE5ewwH4uzaE5ewwH4uzaE5emkI4udnD5emkI4udnD5emkI4uzaE5ewwH4uzaE5ewwH4uzaE5ewwH4uzaE5emkI4udnD5emkI4udnD5emkI4uzaE5ewwH4uzaE5ewwH4uzaE5emkI4udnD5emkI4udnD5emkI4ubsB5;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1,CDT:-18000:1|eeaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a62WywP0WskA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;EST5EDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1,EST:-18000:0,EDT:-14400:1|WiaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI2WanD3emkI2uzaE3ewwH2uzaE3ewwH2uzaE3emkI2udnD3emkI2udnD3emkI2ubsB3;<-04>4|-04:-14400:0|;<-05>5|-05:-18000:0,-04:-14400:1|uwqXG1eWz70unbO1eWz70ulju21eWz70uXmu31eWz70;PST8PDT,M3.2.0,M11.1.0|PST:-28800:0,PDT:-25200:1|mpaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;<-03>3|-03:-10800:0,-02:-7200:1|exhyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0upZs51eokA0utyq31egzC0uZsJ1eed10ubiV1eeYB0;CST6|CST:-21600:0,EST:-18000:0,CDT:-18000:1|msyg31eyqv10unXZ42egs80ujfN2egs80ui+nB1ehkN0uns81e+iW40urmf82eYiF0e-kI2mymD0;<-04>4|-04:-14400:0,-03:-10800:1|W-hyF1e+rB0uZsJ1eyw90urdM1ecd90ufts51eeYB0;AST4|AST:-14400:0,ADT:-10800:1|WtjfA1eYiF0;CST6CDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1|Wy-fI1emkI0uxsk71ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0urpG1egzC0urpG1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0ea-50;MST7|MST:-25200:0,MDT:-21600:1|uhbhQ1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0urpG1egzC0urpG1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0;CST6CDT,M3.2.0,M11.1.0|EST:-18000:0,CDT:-18000:1,CST:-21600:0|ectg31Wy-F2u-a61euwP2uvkA1e+mL2u--F1ekpG2ufiF1ekpG2u--F1eu-F2u--F1eu-F2u--F1eu-F2u--F1eu-F2u--F1ekpG2ufiF1ekpG2u--F1eu-F2u--F1eu-F2u--F1eu-F2uzaE1ewwH2uzaE1emkI2udnD1emkI2udnD1emkI2uzaE1ewwH2uzaE1ewwH2uzaE1emkI2udnD1emkI2udnD1emkI2uzaE1ewwH2uzaE1ewwH2uzaE1ewwH2uzaE1emkI2udnD1emkI2udnD1emkI2uzaE1ewwH2uzaE1ewwH2uzaE1emkI2udnD1emkI2udnD1emkI2ubsB1;CST6|CST:-21600:0,EST:-18000:0,CDT:-18000:1|WetWC1eogR0ujZlD2ewwH0uzaE2ewwH0uzaE2ewwH0uzaE2emkI0udnD2emkI0urpG2egzC0urpG2ewwH0uzaE2ewwH0uzaE2emkI0udnD2emkI0udnD2emkI0udnD2emkI0uzaE2ewwH0uzaE2ewwH0uzaE2emkI0udnD2emkI0udnD2emkI0uzaE2ewwH0uzaE2ewwH0uzaE2ewwH0uzaE2emkI0udnD2emkI0udnD2emkI0uzaE2ewwH0uzaE2ewwH0uzaE2emkI0udnD2emkI0;AKST9AKDT,M3.2.0,M11.1.0|PST:-28800:0,PDT:-25200:1,AKST:-32400:0,AKDT:-28800:1|mpaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0udkZW12ubsB3eezK2ulYB3eezK2ulYB3eezK0Wou62;CST6|CST:-21600:0,CDT:-18000:1|WebhQ1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0urpG1egzC0urpG1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0;<-03>3<-02>,M3.2.0,M11.1.0|AST:-14400:0,-03:-10800:0,-02:-7200:1|WXqhA1uth+62ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1uzaE2ewwH1uzaE2ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1uzaE2ewwH1uzaE2ewwH1uzaE2ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1uzaE2ewwH1uzaE2ewwH1uzaE2emkI1udnD2emkI1udnD2emkI1ubsB2;AST4ADT,M3.2.0,M11.1.0|AST:-14400:0,ADT:-10800:1|maaA1eu-F0u--F1ekpG0u--F1eu-F0ut-l11eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0gsaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0sZq50;CST6|CST:-21600:0,CDT:-18000:1|Wy-fI1emkI0uxsk71ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0urpG1egzC0urpG1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0;<-03>3|-03:-10800:0,-02:-7200:1,-0130:-5400:1,-0230:-9000:1|e-WA1emi40uvrx11eai70ut-l12igz43ufiF0yXx91emp80u-ht11eku60uz-N1ew-70ufdP1eku60upz41emfS0urqu71eqr60ufdP1eai70ulzK1eokA0ulzK1e+rB0ulzK1eeYB0uvfK1e+rB0ur-oB1urpG0uhdH1eWnD0uXxH1esaE0utkI1eWnD0utkI1eWnD0utkI1esaE0uXxH1esaE0uXxH1esaE0utkI1eWnD0utkI1eWnD0utkI1eWnD0;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1|eeaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1|eeaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;AKST9AKDT,M3.2.0,M11.1.0|BST:-39600:0,BDT:-36000:1,YST:-32400:0,AKST:-32400:0,AKDT:-28800:1|u+aA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG2uws23mzeD4eu-F3u--F4eu-F3u--F4eu-F3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3ubsB4;<-02>2|-02:-7200:0,-01:-3600:1|mthyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0uzkr91egzC0uZsJ1eoJ0ux-V1eeYB0;CST6CDT,M3.2.0,M11.1.0|MST:-25200:0,MDT:-21600:1,CST:-21600:0|ulaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK2;CST6CDT,M3.2.0,M11.1.0|MST:-25200:0,MDT:-21600:1,CST:-21600:0,CDT:-18000:1|ulaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH2WwaE3emkI2udnD3emkI2udnD3emkI2uzaE3ewwH2uzaE3ewwH2uzaE3ewwH2uzaE3emkI2udnD3emkI2udnD3emkI2uzaE3ewwH2uzaE3ewwH2uzaE3emkI2udnD3emkI2udnD3emkI2ubsB3;CST6CDT,M3.2.0,M11.1.0|MST:-25200:0,MDT:-21600:1,CST:-21600:0,CDT:-18000:1|ulaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH2WwaE3emkI2udnD3emkI2udnD3emkI2ubsB3;CST6CDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1,MDT:-21600:1,MST:-25200:0|WebhQ1ewwH0uzaE1ewwH0mXbE2ewwH3uzaE2emkI3udnD2emkI3urpG2egzC3urpG2ewwH3uzaE2ewwH3uzaE2emkI3udnD2emkI3udnD2emkI3udnD2emkI3uzaE2ewwH3uzaE2ewwH3uxfC2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ubsB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ulYB2eezK3ubsB2eezK3ulYB2eofK0m+s20;<-03>3|-0330:-12600:0,-03:-10800:0|ahlvE1;EST5EDT,M3.2.0,M11.1.0|EST:-18000:0,EDT:-14400:1|umliD1eYiF0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0mXbE1WqkI0WanD1WqkI0WanD1WqkI0WwaE1W+wH0WwaE1W+wH0WwaE1WqkI0WanD1WqkI0WanD1WqkI0WwaE1W+wH0WwaE1W+wH0eqsk71emkI0udnD1emkI0exei51eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0uzrh11;<-05>5|-05:-18000:0,-04:-14400:1,-04:-14400:0|uYiyF1e+rB0uZsJ1eyw90urdM1ecd90unbkK2eksi50;<-04>4|-04:-14400:0,-03:-10800:1|W-hyF1e+rB0uZsJ1eyw90urdM1ecd90;<-03>3|-03:-10800:1,-04:-14400:0,-03:-10800:0|eXr71uhdH0eWnD1utkI0eWnD1ujYJ0egzC1uXxH0esaE1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0eu-F1u--F0eWnD1utkI0eWnD1ujYJ0egzC1urpG0eYiF1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0eiuE1uhdH0eWnD1uhdH0ekpG1urpG0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0eiuE1uhdH0eWnD1utkI0eYiF1urpG0emkI1ujd90eqaM1ulYB0eezK1ubsB0eofK1ubsB0eias11uXW80eyw92;CST6CDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1|WiaA1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0WciF1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0WciF1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WwaE1W+wH0WwaE1WqkI0WanD1WqkI0WanD1WqkI0WwaE1W+wH0WwaE1W+wH0WwaE1WqkI0WanD1WqkI0WanD1WqkI0WwaE1W+wH0WwaE1W+wH0WwaE1W+wH0WwaE1WqkI0WanD1WqkI0WanD1WqkI0WwaE1W+wH0WwaE1W+wH0WwaE1WqkI0WanD1WqkI0WanD1emkI0ubsB1;CST6CDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1,EST:-18000:0|Wotg21eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI2udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;<-03>3|-03:-10800:0,-02:-7200:1|exhyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0uzkr91egzC0uZsJ1eoJ0ux-V1eeYB0;CST6|CST:-21600:0|;CST6CDT,M3.2.0,M11.1.0|CST:-21600:0,CDT:-18000:1,EST:-18000:0|Wotg21eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI2udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI2ubsB1;<-03>3|-04:-14400:0,-03:-10800:1,-03:-10800:0|W-hyF1e+rB0uZsJ1eyw90urdM1ecd90unbkK2;<-04>4<-03>,M9.1.6/24,M4.1.6/24|-03:-10800:1,-04:-14400:0|eXr71uhdH0eWnD1utkI0eWnD1ujYJ0egzC1uXxH0esaE1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0eu-F1u--F0eWnD1utkI0eWnD1ujYJ0egzC1urpG0eYiF1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0eiuE1uhdH0eWnD1uhdH0ekpG1urpG0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0eiuE1uhdH0eWnD1utkI0eYiF1urpG0emkI1ujd90eqaM1ulYB0eezK1ubsB0eofK1ubsB0eias11uXW80es-N1uXW80es-N1uXW80eezK1udnD0emkI1udnD0emkI1udnD0emkI1uzaE0ewwH1;AST4|-0430:-16200:1,EST:-18000:0,AST:-14400:0|y+l41yzpL0aqq71yv+O0aoc71ybvO0aci71ynpO0aWl71ytmO2uXyYQ1WkY32;<-03>3|-03:-10800:0,-02:-7200:1|exhyF1e+rB0uZsJ1eyw90urdM1ecd90uxaM1ecd90unuM1eokA0uxaM1eokA0ubnL1eyw90unuM1emp80unuM1eeYB0ulzK1eeYB0ulzK1eokA0ulzK1e+rB0upiK1emwC0uZsJ1e+rB0uZsJ1egzC0uZsJ1e+rB0ulzK1eeYB0unuM1ecd90ubnL1eokA0ub+M1eer90ulzK1eeYB0unuM1eyw90uvfK1eeYB0ubnL1eokA0ubnL1eeYB0ulzK1eeYB0ulzK1e+rB0ulzK1eokA0ubnL1eokA0ubnL1eeYB0ulzK1eeYB0ulzK1eeYB0ulzK1eeYB0unuM1ecd90;<-02>2<-01>,M3.5.0/-1,M10.5.0/0|-02:-7200:0,-01:-3600:1,+00:0:1,-01:-3600:0|WtjfA1WciF0mq-F2eu-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2WopG3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2WopG3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD1;AKST9AKDT,M3.2.0,M11.1.0|PST:-28800:0,PDT:-25200:1,YST:-32400:0,AKST:-32400:0,AKDT:-28800:1|mpaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG2Wct23mzeD4eu-F3u--F4eu-F3u--F4eu-F3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3uzaE4ewwH3uzaE4ewwH3uzaE4emkI3udnD4emkI3udnD4emkI3ubsB4;NST3:30NDT,M3.2.0,M11.1.0|NST:-12600:0,NDT:-9000:1,NDDT:-5400:1|qYaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0gsaE1ewwH0uzaE2mikI0mhnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1cclK1;CST6|MST:-25200:0,CST:-21600:0|urtg21;CST6|CST:-21600:0,CDT:-18000:1|mqkiH1egzC0ujYJ1egzC0uzirH1eqY80;AST4ADT,M3.2.0,M11.1.0|AST:-14400:0,ADT:-10800:1|my+fL1eu-F0u--F1eu-F0urpG1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;MST7|PST:-28800:0,PDT:-25200:1,MST:-25200:0|mpaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK2;MST7|PST:-28800:0,PDT:-25200:1,MST:-25200:0|mlfhA1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ubsB1eezK0ulYB1eezK0ulYB1eezK0ulYB1eezK0ulYB1uWzK2;AKST9AKDT,M3.2.0,M11.1.0|YST:-32400:0,YDT:-28800:1,AKST:-32400:0,AKDT:-28800:1|etaA1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u-a61euwP0uvkA1e+mL0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0eYt22mzeD3eu-F2u--F3eu-F2u--F3eu-F2uzaE3ewwH2uzaE3emkI2udnD3emkI2udnD3emkI2uzaE3ewwH2uzaE3ewwH2uzaE3emkI2udnD3emkI2udnD3emkI2uzaE3ewwH2uzaE3ewwH2uzaE3ewwH2uzaE3emkI2udnD3emkI2udnD3emkI2uzaE3ewwH2uzaE3ewwH2uzaE3emkI2udnD3emkI2udnD3emkI2ubsB3;<+08>-8|+08:28800:0,+11:39600:0|m-kzd11uuZC0elzq11e+eA0eiur41ujii10e-kI1WhaE0errH1uisD0YqkI1skaE0gfxH1skaE0gfxH1+hyD0;<+07>-7|+07:25200:0,+05:18000:0|eZlzd11uZrC0eaiq11ubfA0;<+10>-10|+10:36000:0|;AEST-10AEDT,M10.1.0,M4.1.0/3|AEDT:39600:1,AEST:36000:0|Wsu51WsfK0WufC1WsfK0WskA1WYnL0WiYB1WizK0WiYB1WizK0WiYB1WizK0WYsB1WizK0WiYB1WizK0WiYB1WizK0WiYB1WizK0WiYB1WizK0WiYB1WizK0WanD1WgYJ0WkzC1WgYJ0WiYB1WizK0WiYB1WizK0WiYB1WsfK0WkzC1WWsJ0WkzC1WWsJ0WufC1WWsJ0WufC1WWsJ0WanD1WopG0WciF1WopG0WciF1WopG0WciF1WopG0WciF1WopG0Wy-F1WopG0WciF1WopG0WciF1WopG0WciF1WopG0WciF1WanD0WqkI1WedH0WciF1WopG0WciF1WopG0WciF1WopG0WciF1WopG0Wy-F1Wy-F0WciF1WedH0Wy-F1Wy-F0Wy-F1Wy-F0umyd10;<+05>-5|+06:21600:0,+05:18000:0|Wdlzd11;NZST-12NZDT,M9.5.0,M4.1.0/3|NZST:43200:0,NZDT:46800:1|mmex41WWx90WYnL1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WgYJ1WwaE0W+wH1WwaE0W+wH1WwaE0W+wH1WmuE0WedH1WmuE0WedH1WmuE0WedH1WmuE0W+wH1WwaE0W+wH1WwaE0W+wH1WmuE0WedH1WmuE0WedH1WmuE0W+wH1WwaE0W+wH1WwaE0W+wH1WmuE0WedH1WmuE0WedH1WmuE0WedH1WmuE0WedH1;<-03>3|-03:-10800:0,-02:-7200:1,-04:-14400:0,-03:-10800:1|efhY41emp80udwW82utdE3eWnD2utkI3eWnD2ujYJ3egzC2ujYJ3egzC2ujYJ3eu-F2u--F3eWnD2utkI3eWnD2ujYJ3egzC2urpG3eYiF2ujYJ3eWnD2utkI3eWnD2utkI3eWnD2utkI3eWnD2ujYJ3egzC2ujYJ3eiuE2uhdH3eWnD2uhdH3ekpG2urpG3eWnD2ujYJ3egzC2ujYJ3egzC2ujYJ3egzC2ujYJ3eWnD2utkI3eWnD2utkI3eWnD2ujYJ3egzC2ujYJ3eiuE2uhdH3eWnD2utkI3eYiF2urpG3emkI2ujd93eqaM2ulYB3eezK2ubsB3eofK2ubsB3eias12uXW83eyw90;<-03>3|-00:0:0,-03:-10800:0|WiW+61;<+03>-3|+03:10800:0|;<+00>0<+02>-2,M3.5.0/1,M10.5.0/3|-00:0:0,+00:0:0|WafdZ11;<+05>-5|+07:25200:0,-00:0:0,+05:18000:0|utabO1eqWO0epXdT2;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|uhjfA1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<+05>-5|+06:21600:0,+07:25200:1,+06:21600:1,+05:18000:0|mXXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0mwoiJ3;<+03>-3|EET:7200:0,EEST:10800:1,+03:10800:0|mWXk31e+eA0uhqI1eckD0uhqI1eckD0ubtI1eibG0ubzF1eckD0unnI1eckD0uvtm61eoYG0ujeG1eu-F0u--F1eu-F0u--F1ekpG0ubtI1eoeD0uXxH1esaE0utXH1eggE0uhdH1eYiF0u--F1eu-F0u--F1eiuE0uXxH1WwaE0W+wH1WmuE0WedH1WmuE0WedH1WmuE0WiaP1WYl70WumG1WsYG0WYzF1WsYG0Wy-F1Wy-F0Wy-F1WqkI0WanD1W+wH0WmuE1Wy-F0Wy-F1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1euht10utp81WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WskA1WYnL2;<+12>-12|+13:46800:0,+14:50400:1,+13:46800:1,+12:43200:0,+12:43200:1,+11:39600:0|edWfB1eoYG0u--F2WsYG3u--F2eoYG3uvYG2mZWG3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2WopG3Wy-F4u--F5WWx93eua62Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD4ujYJ5WkzC3;<+05>-5|+05:18000:0,+06:21600:0,+06:21600:1,+05:18000:1,+04:14400:0|exZvB1eu-F2WsYG0u--F2eoYG0uvYG2mZWG0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2WopG0Wy-F3u--F4WWx90eua62Wy-F0Wy-F2Wy-F0Wy-F2Wy-F4u--F3Wy-F4WopG3WqkI4WanD3WqkI4WanD3WqkI4WanD3WgYJ4WkzC3WgYJ4WkzC3WgYJ4WanD3WqkI4WanD3WqkI4WanD3WgYJ0;<+05>-5|+05:18000:0,+06:21600:1,+06:21600:0,+05:18000:1,+04:14400:0|ebXfB1eoYG2Wy-F1WsYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F3u--F4WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0;<+05>-5|+05:18000:0,+06:21600:1,+05:18000:1,+04:14400:0|ebXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90;<+05>-5|+05:18000:0,+06:21600:0,+06:21600:1,+05:18000:1,+04:14400:0|exZvB1eu-F2WsYG0u--F2eoYG0uvYG2mZWG0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2WopG0Wy-F3u--F4WWx90eua62Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0Wy-F2Wy-F0WopG2WqkI0WanD2WqkI0WanD2WqkI0WanD3ujYJ4WkzC3WgYJ4WkzC3WgYJ4WanD3WqkI4WanD3WqkI4WanD3WgYJ0;<+03>-3|+03:10800:0,+04:14400:1|uguhC1eckD0ubzF1eibG0uvYG1eoYG0u--F1ubzF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0mzYG1WsYG0WsYG1WsYG0Wy-F1WsYG0Wy-F1WsYG0Wy-F1WsYG0WsYG1WsYG0Wy-F1WsYG0Wy-F1WsYG0Wy-F1WsYG0WsYG1WsYG0Wy-F1WsYG0Wy-F1WsYG0Wy-F1WsYG0WsYG1WsYG0Wy-F1WsYG0Wy-F1WsYG0Wy-F1WsYG0;<+03>-3|+04:14400:0,+03:10800:0|Wbmj21;<+04>-4|+04:14400:0,+05:18000:1,+04:14400:1,+03:10800:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3Wy-F2Wy-F0mXpm31WqkI0eWnD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WqkI0;<+07>-7|+07:25200:0|;<+07>-7|+07:25200:0,+08:28800:1,+07:25200:1,+06:21600:0|uzWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1uwm52WblA3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC0ekXp33u-mj10;EET-2EEST,M3.5.0/0,M10.5.0/0|EET:7200:0,EEST:10800:1|mkhl21e+x80uhqI1eckD0uhqI1eckD0uhqI1eckD0ubtI1eckD0uhqI1eckD0unnI1eckD0upfp51eiuE0ubgH1eiuE0ubgH1eiuE0ubgH1eiuE0ubaK1ecXC0ulZI1eY-D0ubgH1eiuE0ubgH1eiuE0u-iH1eqsD0ufiF1eu-F0u--F1eu-F0u--F1eu-F0urpG1eu-F0u--F1eu-F0u--F1eu-F0u--F1;<+06>-6|+06:21600:0,+07:25200:1,+06:21600:1,+05:18000:0|mXXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2WgkD3esuJ2eiuE3uhdH2eiuE3uhdH2eiuE3uhdH2eiuE3uhdH2eYiF3afWG2emkI3udnD2emkI3udnD2ecYJ3unzC2ecYJ3unzC2ecYJ3udnD2emkI3udnD2emkI3udnD2ecYJ3unzC2ysZC0;<+08>-8|+08:28800:0|;IST-5:30|IST:19800:0|;<+09>-9|+09:32400:0,+10:36000:1,+09:32400:1,+08:28800:0,+10:36000:0|esWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp33mZnj10;<+08>-8|+07:25200:0,+08:28800:0,+09:32400:1|ufvW81eqie52eoYG1uvYG2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2ekpG1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1urpG2eu-F1u--F2eu-F1u--F2eu-F1eh-o22eWnD1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2ekpG1urnm82um-F1edWG2um-F1;CST-8|CST:28800:0,CDT:32400:1|mljiG1e+rB0utkI1eWnD0ujYJ1egzC0ujYJ1eWnD0utkI1eWnD0utkI1eWnD0;<+0530>-5:30|+0530:19800:0,+0630:23400:0,+06:21600:0|irglQ1aYnD2yrzl90;<+06>-6|+06:21600:0,+07:25200:1|uhzod11WkaH0;<+03>-3|EET:7200:0,EEST:10800:1,+03:10800:0|WmnA1eckD0uhqI1eckD0ubtI1eckD0uhqI1eckD0uhqI1eckD0uhqI1eckD0ubtI1eckD0uhqI1ewvA0uteL1ewvA0uztp41eYiF0ufvG1eYiF0uvci11ewqK0ufoC1eakL0up+B1eucK0uveD1eibG0u--F1eu-F0eoYG1eoYG0ulsG1eykF0uZlF1eoYG0uxmG1eoYG0u--F1eoYG0uvYG1eoYG0ubzF1eibG0uhwF1eceG0u--F1eoYG0uvYG1eoYG0u--F1eoYG0u--F1eoYG0u--F1eoYG0uvYG1eoYG0u--F1eoYG0u--F1eefF0urpG1ecYJ0udnD1egnI0utwC1ecYJ0udnD1emkI0udnD1emkI0udnD1emkI0udnD1emkI0udnD1ecYJ0unzC1ecYJ0unzC1ecYJ0udnD1emkI0udnD1emkI0udnD1emkI0udnD1ecYJ0unzC1ecYJ0unzC1ecYJ2;<+09>-9|+09:32400:0,+08:28800:0|eYhh61uvlkO0;<+04>-4|+04:14400:0|;<+05>-5|+06:21600:0,+07:25200:1,+06:21600:1,+05:18000:0|mXXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2utdE3;EET-2EEST,M3.5.0/3,M10.5.0/4|EET:7200:0,EEST:10800:1,+03:10800:0|mekf51eu-F0up-I1e+YD0ulfF1eYiF0urpG1eoYG0ubzF1eu-F0urpG1eYiF0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0urpG1eu-F0u--F1eu-F0u--F1e-kI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WqkI0WanD1WplE2Wloa10;EET-2EEST,M3.4.4/50,M10.4.4/50|IST:7200:0,IDT:10800:1,EET:7200:0,EEST:10800:1|muwm41emp80urpG1e+rB0uvZ+41Was30Wqyq31WWx90WsfK1eqfC0unuM1eyw90uxgJ1eoeD0utkI1egzC0ulzK1eeYB0uXxH1eWnD0utkI1esaE0utkI1esaE0uZfI1eqsD0uZfI1e+YD0uvyI1eqsD0upnA2Wch83WmuE2WedH3WmuE2WedH3WmuE2WqkI3eu-F2urpG3eu-F2u--F3eu-F2u--F3eu-F2u--F3eu-F2u--F3WmuE2WedH3uxZF2egtF3eefF2ufvG3ubmE2e+fH3eWnD2utkI3WwaE2YuzH3ccXC2wjlK3cWtA2uteL3WciF2WopG3eu-F2u--F3emkI2uXqD3WwhI2uXqD3ecYJ2unzC3ecYJ2unzC3ecYJ2WgkD3egnI2udnD3WqkI2WanD3Wm-I2WYZD3up-I2u--F3eu-F2ufiF3ekpG2upuE3eadH2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3ecYJ2udnD3emkI2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3ecYJ2unzC3ecYJ2udnD3ewwH2uzaE3eadH2upuE3eu-F2u--F3eYiF2urpG3esaE2uzf43eoJ2udnD3egzC2uds33e+w12udnD3eqfC2uds33eqk22udnD3eeYB2uzf43egY32udnD3eokA2uds33eiz42unzC3eyw92uds33eYn52unzC3emp82uzf43eua62udnD3eai72uds33eai72udnD3eua62uzf43ew-72udnD3eYn52uds33eyw92unzC3eiz42uds33eokA2unzC3eWs32uzf43eeYB2udnD3eqk22uds33eqfC2udnD3eed12uzf43egzC2udnD3eoJ2uzf43eWnD2uhdH3eYiF2u--F3eu-F2upuE3eadH2uzaE3ewwH2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3ecYJ2unzC3ecYJ2udnD3emkI2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3emkI2uzaE3eadH2upuE3ekpG2ufiF3eYiF2urpG3eiuE2uds33eoJ2unzC3esaE2uds33eed12unzC3egzC2uzf43e+w12udnD3e+rB2uds33egY32udnD3eokA2uzf43eWs32udnD3eyw92uzf43eiz42unzC3ecd92uds33eua62unzC3ew-72uzf43eku62udnD3eku62uds33ew-72udnD3eua62uds33emp82udnD3eiz42uzf43ecd92udnD3esf42uds33eeYB2unzC3egY32uzf43e+rB2unzC3eqk22uzf43eqfC2udnD3eed12uds33eWnD2;EET-2EEST,M3.4.4/50,M10.4.4/50|IST:7200:0,IDT:10800:1,EET:7200:0,EEST:10800:1|muwm41emp80urpG1e+rB0uvZ+41Was30Wqyq31WWx90WsfK1eqfC0unuM1eyw90uxgJ1eoeD0utkI1egzC0ulzK1eeYB0uXxH1eWnD0utkI1esaE0utkI1esaE0uZfI1eqsD0uZfI1e+YD0uvyI1eqsD0upnA2Wch83WmuE2WedH3WmuE2WedH3WmuE2WqkI3eu-F2urpG3eu-F2u--F3eu-F2u--F3eu-F2u--F3eu-F2u--F3WmuE2WedH3uxZF2egtF3eefF2ufvG3ubmE2e+fH3ekvD2ufcI3WwaE2W+wH3eWaC2wjlK3cWtA2urn23eYt22u--F3WciF2WopG3eu-F2u--F3emkI2uXqD3WwhI2uXqD3ecYJ2unzC3ecYJ2unzC3ecYJ2WgkD3egnI2udnD3WqkI2WanD3Wm-I2WYZD3up-I2u--F3eu-F2ufiF3ekpG2upuE3eadH2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3ecYJ2udnD3emkI2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3ecYJ2unzC3ecYJ2udnD3ewwH2uzaE3eadH2upuE3eu-F2u--F3eYiF2urpG3esaE2uzf43eoJ2udnD3egzC2uds33e+w12udnD3eqfC2uds33eqk22udnD3eeYB2uzf43egY32udnD3eokA2uds33eiz42unzC3eyw92uds33eYn52unzC3emp82uzf43eua62udnD3eai72uds33eai72udnD3eua62uzf43ew-72udnD3eYn52uds33eyw92unzC3eiz42uds33eokA2unzC3eWs32uzf43eeYB2udnD3eqk22uds33eqfC2udnD3eed12uzf43egzC2udnD3eoJ2uzf43eWnD2uhdH3eYiF2u--F3eu-F2upuE3eadH2uzaE3ewwH2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3ecYJ2unzC3ecYJ2udnD3emkI2udnD3emkI2udnD3ecYJ2unzC3ecYJ2unzC3emkI2uzaE3eadH2upuE3ekpG2ufiF3eYiF2urpG3eiuE2uds33eoJ2unzC3esaE2uds33eed12unzC3egzC2uzf43e+w12udnD3e+rB2uds33egY32udnD3eokA2uzf43eWs32udnD3eyw92uzf43eiz42unzC3ecd92uds33eua62unzC3ew-72uzf43eku62udnD3eku62uds33ew-72udnD3eua62uds33emp82udnD3eiz42uzf43ecd92udnD3esf42uds33eeYB2unzC3egY32uzf43e+rB2unzC3eqk22uzf43eqfC2udnD3eed12uds33eWnD2;<+07>-7|+08:28800:0,+07:25200:0|Wavk51;HKT-8|HKT:28800:0,HKST:32400:1|adl91eu-F0u--F1eu-F0u--F1ekpG0u--F1eu-F0u-a61euwP0u--F1eu-F0u--F1eu-F0udko21esaE0;<+07>-7|+06:21600:0,+07:25200:0,+08:28800:1|mjvW81eqie52eoYG1uvYG2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2ekpG1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1urpG2eu-F1u--F2eu-F1u--F2eu-F1eh-o22eWnD1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2eu-F1u--F2ekpG1urnm82um-F1edWG2um-F1;<+08>-8|+08:28800:0,+09:32400:1,+08:28800:1,+07:25200:0,+09:32400:0|WwWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;<+03>-3|EET:7200:0,EEST:10800:1,+03:10800:0,+04:14400:1|esuj31WanD0unzC1ecYJ0uXdC1esuJ0uxfC1eyrJ0udnD1eadH0upuE1uat72mxfZ53eYn52uxvY10Wa+E1WwaE0WsYG1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WciF1WopG0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0mrzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WeWD1Wm-I0WkzC1WgYJ0WanD1WqkI0W+pD1WwhI0WanD1WWsJ0WufC1WviE2;WIB-7|WIB:25200:0|;WIT-9|WIT:32400:0|;IST-2IDT,M3.4.4/26,M10.5.0|IST:7200:0,IDT:10800:1|muwm41emp80urpG1e+rB0uvZ+41Was30Wqyq31WWx90WsfK1eqfC0unuM1eyw90uxgJ1eoeD0utkI1egzC0ulzK1eeYB0uXxH1eWnD0utkI1esaE0utkI1esaE0uZfI1eqsD0uZfI1e+YD0uvyI1eqsD0utXH1eceG0udhG1esnF0uXkG1eW+E0ehfI1eWnD0uZsJ1m+hF0ujeG1eiuE0udhG1eyxG0uxZF1ekpG0uXkG1eiuE0mjvG1eYvG0urcF1eibG0uhwF1eW+E0utXH1eYvG0urcF1eibG0uhwF1eW+E0ujrH1eibG0uhwF1esnF0uXkG1;<+0430>-4:30|+0430:16200:0|;<+12>-12|+12:43200:0,+13:46800:1,+12:43200:1,+11:39600:0|WhWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD2ujYJ3WkzC0;PKT-5|+05:18000:0,PKT:18000:0,PKST:21600:1|edkd11WsdaV2eu-F1uzlr52eckD1ubmE2eioH1;<+06>-6|+06:21600:0|;<+0545>-5:45|+0530:19800:0,+0545:20700:0|ippXG1;<+09>-9|+09:32400:0,+10:36000:1,+09:32400:1,+08:28800:0,+10:36000:0,+11:39600:1,+11:39600:0|esWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0mcy54uvq75WgYJ4WkzC5WgYJ4WkzC5WgYJ4WkzC5WgYJ4WanD5WqkI4WanD5WqkI4WanD5WgYJ4WkzC6uuzE4evZa30;<+07>-7|+07:25200:0,+08:28800:1,+07:25200:1,+06:21600:0,+08:28800:0|uzWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;<+08>-8|+0730:27000:0,+08:28800:0|WecXC1;CST-8|CST:28800:0,CDT:32400:1|adl91eu-F0u--F1eu-F0u--F1ekpG0u--F1eu-F0u-a61euwP0u--F1eu-F0u--F1eu-F0udko21esaE0;<+11>-11|+11:39600:0,+12:43200:1,+11:39600:1,+10:36000:0,+12:43200:0|ukWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp33mx-l10;WITA-8|WITA:28800:0|;PST-8|PST:28800:0,PDT:32400:1|Wmee71emqF0uZjsC1e+X60;EET-2EEST,M3.5.0/3,M10.5.0/4|EET:7200:0,EEST:10800:1|mekf51eu-F0up-I1e+YD0ulfF1eYiF0urpG1eoYG0ubzF1eu-F0urpG1eYiF0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0urpG1eu-F0u--F1eu-F0u--F1eqsD1;<+07>-7|+07:25200:0,+08:28800:1,+07:25200:1,+06:21600:0|uzWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD2ujYJ3WkzC0;<+07>-7|+07:25200:0,+08:28800:1,+07:25200:1,+06:21600:0|uzWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1uaz42WxYB3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC0ekXp33ur-t10;<+06>-6|+06:21600:0,+07:25200:1,+06:21600:1,+05:18000:0,+07:25200:0|mXXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;<+05>-5|+05:18000:0,+06:21600:1,+06:21600:0,+05:18000:1,+04:14400:0|ebXfB1eoYG2Wy-F1WsYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F3u--F4Wy-F3WopG4Wy-F3Wy-F4WWx90eua63u--F4Wy-F3Wy-F4Wy-F3Wy-F4Wy-F3Wy-F4WopG3WqkI4WanD3WqkI4WanD3WqkI4WanD3WgYJ4WkzC3WgYJ4WkzC3WgYJ4WanD3WqkI4WanD3WqkI4WanD3WgYJ0;WIB-7|WITA:28800:0,WIB:25200:0|WkuXI1;KST-9|KST:32400:0,KST:30600:0|ewiuj11Wqht20;<+05>-5|+05:18000:0,+06:21600:1,+06:21600:0,+05:18000:1,+04:14400:0|ebXfB1eoYG2Wy-F1WsYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F3u--F4WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ2usoiJ0;<+05>-5|+05:18000:0,+06:21600:1,+06:21600:0,+05:18000:1|ebXfB1eoYG2Wy-F1WsYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F3u--F0eyw92eua61u--F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ2uixbE0;<+0630>-6:30|+0630:23400:0|;<+11>-11|+11:39600:0,+12:43200:1,+11:39600:1,+10:36000:0|ukWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD2utkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC0ekXp33u-mj10;<+05>-5|+05:18000:0,+06:21600:1,+06:21600:0|ebXfB1eoYG2Wy-F1WsYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0;KST-9|KST:32400:0,KDT:36000:1|uvWjH1WanD0WqkI1WanD0;<+11>-11|+11:39600:0,+12:43200:1,+11:39600:1,+10:36000:0,+12:43200:0|ukWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;CST-8|CST:28800:0,CDT:32400:1|Wefe41eoYG0u--F1eoYG0ujgu31eqY80;<+05>-5|+06:21600:0,+07:25200:1,+06:21600:1,+05:18000:0|mXXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3;<+04>-4|+04:14400:0,+05:18000:1,+04:14400:1,+03:10800:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3mq-F2eu-F3u--F2eu-F3u--F2eu-F0Wy-F1eu-F0urpG1eeko10udnD1emkI0udnD1ecYJ0unzC1ecYJ0unzC1ecYJ0udnD1emkI0udnD1emkI0udnD1ew-72WxYB3WkzC0;<+0330>-3:30|+0330:12600:0,+0430:16200:1,+04:14400:0,+05:18000:1|aXud71WYtI2y-pD3WYsB2Wqp80yZgH1egZA0upbG1eWhG0utlqA1eelC0u--F1eibG0ubzF1eibG0ubzF1eibG0ubzF1eibG0ubzF1eibG0u--F1eibG0ubzF1eibG0ubzF1eibG0ubzF1eibG0u--F1eibG0ubzF1eibG0ubzF1eibG0ubzF1eibG0u--F1eibG0ufYm21eibG0u--F1eibG0ubzF1eibG0ubzF1eibG0ubzF1eibG0u--F1eibG0ubzF1eibG0ubzF1eibG0ubzF1eibG0u--F1eibG0ubzF1eibG0ubzF1eibG0ubzF1eibG0u--F1eibG0ubzF1eibG0;<+06>-6|+0530:19800:0,+06:21600:0|i-rvH1;JST-9|JST:32400:0|;<+07>-7|+07:25200:0,+08:28800:1,+07:25200:1,+06:21600:0|uzWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1Wct22untF3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC0ekXp33ubYp10;<+10>-10|+09:32400:0,+12:43200:1,+11:39600:0,+11:39600:1,+10:36000:0,+12:43200:0|esWfB1ugYG2u--F1eoYG2u--F1eoYG2uvYG1mZWG2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1WopG2Wy-F3u--F4WWx92eua61Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2WopG1WqkI2WanD1WqkI2WanD1WqkI2WanD1WgYJ2WkzC1WgYJ2WkzC1WgYJ2WanD1WqkI2WanD1WqkI2WanD1WgYJ2WkzC1WgYJ2WkzC1WgYJ2WkzC1WgYJ2WanD1WqkI2WanD1WqkI2WanD1WgYJ2WkzC5uuzE2evZa34;<+10>-10|+10:36000:0,+11:39600:1,+10:36000:1,+09:32400:0,+11:39600:0|moWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;<+09>-9|+09:32400:0,+10:36000:1,+09:32400:1,+08:28800:0,+10:36000:0|esWfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;<+05>-5|+05:18000:0,+06:21600:1,+05:18000:1,+04:14400:0,+06:21600:0|ebXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;<+04>-4|+04:14400:0,+05:18000:1,+04:14400:1,+03:10800:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F0ecpm11WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0;<-01>1<+00>,M3.5.0/0,M10.5.0/1|-01:-3600:0,+00:0:1,WET:0:0,WEST:3600:1|ubveC1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0uXW82ew-73WwZ71WYy80Wy-F1Wy-F0Wy-F1Wy-F0WopG1;AST4ADT,M3.2.0,M11.1.0|AST:-14400:0,ADT:-10800:1|mwsg41eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1ekpG0ufiF1ekpG0u--F1eu-F0u--F1eu-F0u--F1eu-F0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0uzaE1ewwH0uzaE1ewwH0uzaE1emkI0udnD1emkI0udnD1emkI0ubsB1;WET0WEST,M3.5.0/1,M10.5.0|WET:0:0,WEST:3600:1|WejfA1ufiF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<-01>1|-02:-7200:0,-01:-3600:0|Wpgz51;WET0WEST,M3.5.0/1,M10.5.0|WET:0:0,WEST:3600:1|ujveB1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;WET0WEST,M3.5.0/1,M10.5.0|WET:0:0,WEST:3600:1|WuifC1WciF0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1u--F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<-02>2|-02:-7200:0|;<-03>3|-04:-14400:0,-03:-10800:0,-02:-7200:1,-03:-10800:1|WtxhD1egzC2ecYJ1uxfC2eyrJ1uxfC3WgYJ0unzC3ecYJ0unzC3ecYJ0unzC3ecYJ0unzC3eyrJ0uxfC3eyrJ0unzC3ecYJ0unzC3ecYJ0unzC3ecYJ0unzC3ecYJ0unzC3eyrJ0unzC3ecYJ0unzC3ecYJ0unzC3ecYJ0unzC3ecYJ0unzC3ujYJ0uxfC3eofK0ubsB3eofK0uxfC3eyrJ0uxfC3eyrJ0uxfC3eyrJ0uxfC3eyrJ0uxfC3eofK0uxfC3eyrJ0uxfC3eyrJ0uxfC1;AEST-10AEDT,M10.1.0,M4.1.0/3|AEST:36000:0,AEDT:39600:1|Wwrw11WskA0WYnL1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WwaE0WqkI1WiYB0WizK1WiYB0WizK1WiYB0WizK1WufC0WgYJ1WkzC0WWsJ1WkzC0WWsJ1WufC0WWsJ1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WanD1WqkI0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WgYJ1WanD0WqkI1WkzC0WgYJ1WwaE0;ACST-9:30ACDT,M10.1.0,M4.1.0/3|ACST:34200:0,ACDT:37800:1|yxrw11WskA0WYnL1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WufC0WgYJ1WkzC0WWsJ1WkzC0WWsJ1WufC0WWsJ1WufC0WWsJ1WiYB0WizK1WkzC0WgYJ1WYsB0WizK1WufC0WWsJ1WkzC0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WgYJ1WkzC0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WgYJ1WanD0WqkI1WkzC0WgYJ1WwaE0;AEST-10|AEST:36000:0,AEDT:39600:1|Wwrw11WskA0WydtH1WiYB0WizK1WiYB0WizK1WiYB0;ACST-9:30ACDT,M10.1.0,M4.1.0/3|ACST:34200:0,ACDT:37800:1|yxrw11WskA0WYnL1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WwaE0WqkI1WiYB0WizK1WiYB0WizK1WiYB0WizK1WufC0WgYJ1WkzC0WWsJ1WkzC0WWsJ1WufC0WWsJ1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WgYJ1WkzC0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WgYJ1WanD0WqkI1WkzC0WgYJ1WwaE0;AEST-10AEDT,M10.1.0,M4.1.0/3|AEDT:39600:1,AEST:36000:0|Wsu51WsfK0WufC1WsfK0WskA1WYnL0WiYB1WizK0WiYB1WizK0WiYB1WizK0WYsB1WizK0WiYB1WizK0WiYB1WizK0WiYB1WizK0WiYB1WizK0WiYB1WizK0WanD1WgYJ0WkzC1WgYJ0WiYB1WizK0WiYB1WizK0WiYB1WsfK0WkzC1WWsJ0WkzC1WWsJ0WufC1WWsJ0WufC1WWsJ0WanD1WopG0WciF1WopG0WciF1WopG0WciF1WopG0WciF1WopG0Wy-F1WopG0WciF1WopG0WciF1WopG0WciF1WopG0WciF1WanD0WqkI1WedH0WciF1WopG0WciF1WopG0WciF1WopG0WciF1WopG0Wy-F1Wy-F0WciF1WedH0;ACST-9:30|ACST:34200:0|;<+0845>-8:45|+0845:31500:0,+0945:35100:1|scrw41WiYB0WuYs81WiYB0Wigt71Wgd90WitvE1WWx90WgYJ1WanD0WqkI1WanD0;<+1030>-10:30<+11>-11,M10.1.0,M4.1.0|AEST:36000:0,+1030:37800:0,+1130:41400:1,+11:39600:1|mifcB1qnzK2e+rB1ulzK2eeYB1ulzK2eeYB1ulzK2eeYB1ulzK3asfC1yhYJ3aizC1yXsJ3aizC1yXsJ3asfC1yXsJ3agYB1yjzK3agYB1yjzK3agYB1yjzK3aWsB1yjzK3agYB1yjzK3agYB1yjzK3aYnD1yrkI3aYnD1yrkI3aYnD1yrkI3aYnD1yhYJ3aizC1ybnD3aokI1yhYJ3aYnD1yrkI3aYnD1yrkI3aYnD1yhYJ3aizC1yhYJ3aYnD1yrkI3aizC1yhYJ3auaE1;AEST-10|AEST:36000:0,AEDT:39600:1|Wwrw11WskA0WydtH1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0;AEST-10AEDT,M10.1.0,M4.1.0/3|AEST:36000:0,AEDT:39600:1|Wwrw11WskA0WYnL1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WufC0WgYJ1WkzC0WgYJ1WanD0WWsJ1WufC0WWsJ1WufC0WWsJ1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WkzC0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WanD1WqkI0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WgYJ1WanD0WqkI1WkzC0WgYJ1WwaE0;AWST-8|AWST:28800:0,AWDT:32400:1|mfrw41WiYB0WuYs81WiYB0Wigt71Wgd90WitvE1WWx90WgYJ1WanD0WqkI1WanD0;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|ujwe71WciF0WopG1Wy-F0Wy-F1Wy-F0WopG1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<-06>6<-05>,M9.1.6/22,M4.1.6/22|-06:-21600:1,-07:-25200:0,-06:-21600:0,-05:-18000:1|eXr71uhdH0eWnD1utkI0eWnD1ujYJ0egzC1uXxH0esaE1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD1utkI0eWnD1ujYJ0egzC1ujYJ0egzC1ujYJ0eWnD1utkI0eWnD2utkI3eWnD2utkI3eWnD2ujYJ3egzC2ujYJ3egzC2ujYJ3eu-F2u--F3eWnD2utkI3eWnD2ujYJ3egzC2urpG3eYiF2ujYJ3eWnD2utkI3eWnD2utkI3eWnD2utkI3eWnD2ujYJ3egzC2ujYJ3eiuE2uhdH3eWnD2uhdH3ekpG2urpG3eWnD2ujYJ3egzC2ujYJ3egzC2ujYJ3egzC2ujYJ3eWnD2utkI3eWnD2utkI3eWnD2ujYJ3egzC2ujYJ3eiuE2uhdH3eWnD2utkI3eYiF2urpG3emkI2ujd93eqaM2ulYB3eezK2ubsB3eofK2ubsB3eias12uXW83es-N2uXW83es-N2uXW83eezK2udnD3emkI2udnD3emkI2udnD3emkI2uzaE3ewwH2;EET-2EEST,M3.5.0/3,M10.5.0/4|EET:7200:0,EEST:10800:1|mkhf51WeXK0mnXC1Wy-F0WciF1WWlF0WumG1ufiF0meqG1WayF0eceG1eawF0WhWG1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;IST-1GMT0,M10.5.0,M3.5.0/1|IST:3600:0,GMT:0:1|m-sw11WufC0WWsJ1WufC0WWsJ1WufC0WWsJ1WufC0WWsJ1WkzC0WgYJ1WkzC0WgYJ1WkzC0WWsJ1WufC0WWsJ1WufC0WWsJ1eWnD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WgYJ1WkzC0WgYJ1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WqkI1WanD0WqkI1WwaE0;<-01>1|-01:-3600:0|;<-10>10|-10:-36000:0|;<-11>11|-11:-39600:0|;<-12>12|-12:-43200:0|;<-05>5|-05:-18000:0|;<-06>6|-06:-21600:0|;<-07>7|-07:-25200:0|;<-08>8|-08:-28800:0|;<-09>9|-09:-32400:0|;<+01>-1|+01:3600:0|;<+11>-11|+11:39600:0|;<+12>-12|+12:43200:0|;<+13>-13|+13:46800:0|;<+14>-14|+14:50400:0|;<+02>-2|+02:7200:0|;<+05>-5|+05:18000:0|;<+09>-9|+09:32400:0|;UTC0|UTC:0:0|;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|uZifF1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<+04>-4|+04:14400:0,+05:18000:1,+04:14400:1,+03:10800:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F0eq-V2u--F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC0ekXp33u-mj10;GMT0BST,M3.5.0/1,M10.5.0|BST:3600:0,GMT:0:0,BST:3600:1|m-sw11WufC2WWsJ1WufC2WWsJ1WufC2WWsJ1WufC2WWsJ1WkzC2WgYJ1WkzC2WgYJ1WkzC2WWsJ1WufC2WWsJ1WufC2WWsJ1eWnD2WqkI1WanD2WqkI1WanD2WqkI1WanD2WgYJ1WanD2WqkI1WanD2WqkI1WanD2WqkI1WanD2WqkI1WanD2WgYJ1WkzC2WgYJ1WanD2WqkI1WanD2WqkI1WanD2WqkI1WanD2WqkI1WanD2WqkI1eod61;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|uzueD1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|uzve91Wy-F0WopG1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;EET-2EEST,M3.5.0/3,M10.5.0/4|EET:7200:0,EEST:10800:1|mYtj91eeYB0WopG1ufiF0mZWG1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0mq-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1eu-F0u--F1eu-F0urpG1emkI0utv50;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|eajfA1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0mZWG1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|ujveB1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;EET-2EEST,M3.5.0/3,M10.5.0/4|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1eWs32mrzC3Wy-F2Wy-F3mq-F2eu-F3u--F2eu-F3u--F2eu-F3u--F2eu-F3urpG2emkI3elnD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3mak53;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|ubveC1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;EET-2EEST,M3.5.0/3,M10.5.0/4|EET:7200:0,EEST:10800:1|WgveB1Wy-F0Wy-F1Wy-F0u--F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;EET-2|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0,+03:10800:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC4ekXp33;EET-2EEST,M3.5.0/3,M10.5.0/4|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1emp82mz-d13Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2uou32;MSK-3|+04:14400:0,+05:18000:1,MSD:14400:1,MSK:10800:0,MSK:14400:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F0eq-V2u--F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC4ekXp33;WET0WEST,M3.5.0/1,M10.5.0|CET:3600:0,WET:0:0,WEST:3600:1,CEST:7200:1|Wucu61Wy-F2Wy-F1urpG2Wy-F1Wy-F2Wy-F1WopG2WciF1eu-F2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2WopG1Wy-F2Wy-F1u--F2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2Wy-F1Wy-F2WopG1Wy-F2Wy-F1Wy-F2Wy-F0Wy-F3Wy-F0Wy-F3Wy-F0Wy-F3Wy-F0WopG2;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|mmkf41ufiF0ekpG1ufiF0eYiF1u--F0ekpG1ufiF0mvpG1Wy-F0Wy-F1Wy-F0WopG1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|eubD1WskA0WizK1WiYB0WYnL1WiYB0WYzF1Wy-F0WuzH1WeWD0mt-I1eWnD0utkI1eWnD0utkI1eWnD0utkI1eWnD0utkI1eWnD0ubgH1eefF0urpG1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<+03>-3|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0,+03:10800:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wgpm12u--F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC4;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|Wyce61eu-F0mvpG1WciF0WopG1Wy-F0Wy-F1Wy-F0WopG1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;MSK-3|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0,MSK:14400:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F2u--F3WWx90eua61Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC4ekXp30;EET-2EEST,M3.5.0/3,M10.5.0/4|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2Wy-F3u--F2WqkI3WanD2WqkI3WanD2WgYJ3ucsb13;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|eubD1WskA0WizK1WiYB0WYnL1WiYB0WYnL1WskA0WizK1WiYB0WYnL1WskA0WYnL1WskA0WizK1WiYB0WYnL1WiYB0WizK1WiYB0mvpG1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<+04>-4|+04:14400:0,+05:18000:1,+04:14400:1,+03:10800:0,+03:10800:1|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F4u--F3WYx10moaE1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1WqkI0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WkzC1WgYJ0WanD1WqkI0WanD1WqkI0WanD2ujYJ3WkzC0;<+04>-4|+04:14400:0,+05:18000:1,+04:14400:1,+03:10800:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2Wy-F3Wy-F2WopG3Wy-F0eq-V2u--F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC0ekXp33utrZ20;MSK-3|MSK:10800:0,MSD:14400:1,EET:7200:0,EEST:10800:1,MSK:14400:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WmpO2ur-t13Wy-F2Wy-F3Wy-F2Wy-F3uYY31mrzC0Wy-F1Wy-F0mgpG1e-kI0udnD3WqkI2WanD3WqkI2WanD3WgYJ2WkzC3WgYJ2WkzC3WgYJ2WanD3WqkI2WanD3WqkI2WanD3WgYJ2WkzC3WgYJ2WkzC3WgYJ2WkzC3WgYJ2WanD3WqkI2WanD3WqkI2WanD3WgYJ2WkzC3WgYJ2WkzC3WgYJ2WanD3WqkI2eWnD4mikI0;EET-2EEST,M3.5.0/3,M10.5.0/4|EET:7200:0,EEST:10800:1|ukve91uvYG0eqmG1uZlF0eqmG1mjiF0mgpG1eniF0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0mq-F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0urpG1emkI0utv50;EET-2EEST,M3.5.0/3,M10.5.0/4|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2utkI3WanD2WgYJ3uibg23;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|eych41eoeD0unnI1eWnD0ubtI1eWnD0ujYJ1egzC0up-I1eaWD0up-I1eaWD0up-I1eWnD0uxzH1eWnD0ujYJ1eWnD0ubgH1euoE0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<+04>-4|+04:14400:0,+05:18000:1,+04:14400:1,+03:10800:0,+03:10800:1,+02:7200:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F4u--F5WWx93eua62Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC0ekXp33u-mj10;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|eajfA1eYiF0edWG1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;EET-2EEST,M3.5.0/3,M10.5.0/4|MSK:10800:0,MSD:14400:1,EEST:10800:1,EET:7200:0,CEST:7200:1,CET:3600:0|uiXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2WopG3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3udnD4WqkI5WanD4WgYJ3umub33;MSK-3|+04:14400:0,+05:18000:1,MSD:14400:1,MSK:10800:0,MSK:14400:0|WfXfB1eoYG0u--F1eoYG0u--F1eoYG0uvYG1mZWG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F2u--F3Wy-F2Wy-F3Wy-F2WopG3Wy-F0eq-V2u--F3Wy-F2Wy-F3Wy-F2Wy-F3Wy-F2Wy-F3WopG2WqkI3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WkzC2WgYJ3WanD2WqkI3WanD2WqkI3WanD2WgYJ3WkzC4ekXp33uvoW40eomb23;CET-1CEST,M3.5.0,M10.5.0/3|CET:3600:0,CEST:7200:1|Wgwe71WciF0WopG1Wy-F0Wy-F1Wy-F0WopG1WciF0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0u--F1Wy-F0Wy-F1Wy-F0Wy-F1WopG0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0Wy-F1Wy-F0WopG1;<-00>0|-00:0:0|;HST10|HST:-36000:0|;<+06>-6|+05:18000:0,+06:21600:0|ezoYQ1;<+04>-4|+04:14400:0,+05:18000:1|Wx-vC1emdE0eXyrP1eWnD0;<+12>-12|-12:-43200:0,+12:43200:0|WtvsN1;<+1245>-12:45<+1345>,M9.5.0/2:45,M4.1.0/3:45|+1245:45900:0,+1345:49500:1|mmex41WWx90WYnL1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WiYB0WizK1WYsB0WizK1WiYB0WgYJ1WwaE0W+wH1WwaE0W+wH1WwaE0W+wH1WmuE0WedH1WmuE0WedH1WmuE0WedH1WmuE0W+wH1WwaE0W+wH1WwaE0W+wH1WmuE0WedH1WmuE0WedH1WmuE0W+wH1WwaE0W+wH1WwaE0W+wH1WmuE0WedH1WmuE0WedH1WmuE0WedH1WmuE0WedH1;<+13>-13|-11:-39600:0,-10:-36000:1,+14:50400:1,+13:46800:0|errxe11eZnG0WciF1Whm82WdZ83Wy-F2WopG3WciF2WopG3WciF2WopG3WciF2WopG3WciF2WopG3WciF2WopG3Wy-F2WopG3WciF2WopG3WciF2WopG3;<+11>-11|+10:36000:0,+11:39600:0|WYcaj11;<+11>-11|+11:39600:0,+12:43200:1|Who-31Wqp80ujnm91eu-F0u--F1eu-F0urpG1eYiF0urpG1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0u--F1eu-F0urpG1eokA0uz-N1ew-70;<+13>-13|-12:-43200:0,-11:-39600:0,+13:46800:0|Wzzu91emnfF2;<+13>-13|-11:-39600:0,+13:46800:0|ejZag11;<+12>-12|+12:43200:0,+13:46800:1|menzS1WskA0WuaM1WWx90W+av91WskA0WqkI1WYsB0WsfK1W+-70Ww-N1W+-70WmpO1eai70ufdP1Wou60WcdP1Wou60WywP1Wya60WywP1Wya60WywP1Wya60WokQ1Wcn50WsaU1Wuk20;<-06>6|-05:-18000:0,-06:-21600:0,-05:-18000:1|uwqXG1uXuz62e+X61;ChST-10|GST:36000:0,GDT:39600:1,ChST:36000:0|WmYA1e+rB0uvfK1e+rB0uzcf21eua60u-de21git70sbnL1eeYB0euqiN2;<+14>-14|-1040:-38400:0,-10:-36000:0,+14:50400:0|Wuzu91mnnfF2;<+11>-11|+12:43200:0,+11:39600:0|WpyYT1;<-0930>9:30|-0930:-34200:0|;SST11|SST:-39600:0|;<+12>-12|+1130:41400:0,+12:43200:0|iYia91;<+11>-11<+12>,M10.1.0,M4.1.0/3|+1130:41400:0,+1230:45000:1,+11:39600:0|iyqw41WiYB0WaYte12isXu32;<+11>-11|+11:39600:0,+12:43200:1|uYg+71e+k70uvmO1eun70eXbwH1W+-70;<-08>8|-0830:-30600:0,-08:-28800:0|yrYjS1;<-10>10|-1030:-37800:0,-0930:-34200:1,-10:-36000:0|ifny81eyw92yjzK1agYB2yjzK1agYB2yjzK1aWsB2yjzK1agYB2yjzK1agYB2yjzK1agYB2yjzK1agYB2yjzK1agYB2yjzK1aWsB2yjzK1agYB2yjzK1agYB2yjzK1agYB2;<+13>-13|+13:46800:0,+14:50400:1|uijxT1WejE0WsfK1eai70uppO1eai70ubhwE1Wya60;";
}
// ---- END GENERATED tzdata ----
```
