# HTTP client requests

This module provides an HTTP client.

## Model

A request value combines its method, URL, headers, body, timeouts, and decode policy. Response logic coordinates redirects and protocol transport.

## Contracts

Connection, inactivity, and total timeouts describe different phases. Body and decode limits bound resource use. Network operations return concrete fetch errors.

## Module assembly

The root chunk preserves the declaration order. The chunks below contain the complete implementation.

```fern
<<*>>=
<<module introduction>>

<<dependencies 2>>

<<3 pub enum Phase>>

<<4 pub function (p: Phase) message(): string>>

<<5 function __later_message(e: FetchError): string>>

<<6 pub function (e: FetchError) to_string(): string>>

<<7 impl error.Error for FetchError>>

<<8 pub function timeouts(): Timeouts>>

<<9 pub struct Request>>

<<10 pub function decoding(): Decoding>>

<<11 struct __Target>>

<<12 function __target_of(raw: string, policy: Policy): Result[__Target, FetchError]>>

<<13 function __wire(req: Request, t: __Target, body: u8[]): u8[]>>

<<14 pub trait Transport>>

<<15 pub function (p: Idle) proxy_env(): ProxyEnv>>

<<16 pub struct Kept>>

<<17 pub function idle(): Idle>>

<<18 function __has_fd(fds: i32[], fd: i32): boolean>>

<<19 pub function (p: Idle) armed(fd: i32): boolean>>

<<20 pub struct Shared>>

<<21 pub function (sh: Shared) quiet(): boolean>>

<<22 pub function (sh: Shared) unwatched(): i32[]>>

<<23 function __driven_kernel(sh: Shared, at: i32, d: Driven, bytes: u8[]): Option[i32]>>

<<24 pub function (sh: Shared) event(fd: i32, readable: boolean): Option[i32]>>

<<25 function __driven_read_failed(sh: Shared, at: i32, d: Driven, e: net.NetError): Option[i32]>>

<<26 pub function (sh: Shared) expired(now: Instant, idle: Duration): i32[]>>

<<27 function __mail_answered(sh: Shared, fd: i32, events: h2.Event[], streams: i32): i32>>

<<28 pub function close_idle[T: Transport](tr: T): void>>

<<29 struct __Place>>

<<30 function __place_of(t: __Target, guard: boolean, roots: Option[verify.Roots]): __Place>>

<<31 pub struct Lookup>>

<<32 pub function sockets(): Sockets>>

<<33 impl Transport for Sockets>>

<<34 pub function send(req: Request): Result[HttpResponse, FetchError]>>

<<35 function __send_closing(policy: Policy, req: Request): Result[HttpResponse, FetchError]>>

<<36 pub struct Policy>>

<<37 pub function public_policy(): Policy>>

<<38 pub struct Allow>>

<<39 pub function allow(entries: string[]): Result[Allow, AllowError]>>

<<40 function __allow_rule(e: string): Option[__AllowRule]>>

<<41 pub function send_on[T: Transport](tr: T, req: Request, policy: Policy): Result[HttpResponse, FetchError]>>

<<42 function __with_jar[T: Transport](tr: T, req: Request, jar: Option[cookie.Jar]): Request>>

<<43 function __send_once[T: Transport](tr: T, req: Request, started: i64, policy: Policy): Result[HttpResponse,...>>

<<44 enum __SharedPick>>

<<45 function __shared_socket[T: Transport](tr: T, req: Request, t: __Target, started: i64, key: string, guard: ...>>

<<46 struct __H2Call>>

<<47 function __h2_answered[T: Transport](tr: T, req: Request, started: i64, call: __H2Call, stream: i32): Resul...>>

<<48 struct __Conn>>

<<49 function __has_tls(conn: __Conn): boolean>>

<<50 enum __Record>>

<<51 function __kernel_record(sock: i32, s: client.Session, now: time.Timestamp): __Record>>

<<52 function __handshake_read(got: Result[net.Recv, net.NetError]): Result[u8[], FetchError]>>

<<53 function __host_code(code: wasi_http.ErrorCode): FetchError>>

<<54 struct __Read>>

<<55 function __reusable(framed: http.HttpResponseFramed, from: i32, read: i32, eof: boolean): boolean>>

<<56 function __codings(h: HeaderMap): string[]>>

<<57 struct __Got>>

<<58 function __recv_bounded[T: Transport](tr: T, conn: __Conn, timeouts: Timeouts, started: i64, size: i32): Re...>>

<<59 pub struct ProxyEnv>>

<<60 pub function proxies(http_proxy: string, https_proxy: string, no_proxy: string): ProxyEnv>>

<<61 function __either(first: Option[string], second: Option[string]): Option[string]>>

<<62 pub function (p: ProxyEnv) proxy_for(target_url: string): Option[string]>>

<<63 function __proxy_for_url(p: ProxyEnv, u: Url): Option[string]>>

<<64 struct __Rule>>

<<65 function __rules_of(no_proxy: string): __Rule[]>>

<<66 function __rule_port(rest: string): i32>>

<<67 struct __Proxy>>

<<68 function __proxy_of(spec: string, name: string): Result[__Proxy, FetchError]>>
```

### `module introduction`

```fern
<<module introduction>>=
// This module provides an HTTP client.

import "std/i32";
import "std/unicode";
// This module provides an HTTP client.
```

### `dependencies 2`

```fern
<<dependencies 2>>=
import "std/string";
import "std/async";
import "std/time";
import "std/clock";
import "std/http";
import "std/headers";
import "std/http/cookie";
import "std/url";
import "std/dns";
import "std/net";
import "std/errno";
import "std/error";
import "std/base64";
import "std/brotli";
import "std/deflate";
import "std/zstd";
import "std/wasi_http";
import "std/tls";
import "std/tls/client";
import "std/tls/ktls";
import "std/tls/verify";
import "std/crypto";
import "std/hex";
import "std/envflag";
import "std/http/h2";
import "core/int";
import "core/cmp";
```

### `3 pub enum Phase`

```fern
<<3 pub enum Phase>>=
pub enum Phase { Connecting, Inactivity, Total }

// FetchError is why a request failed. `InvalidUrl`: a URL with no scheme
// or host, a scheme other than http and https, or a path that cannot stand
// on a request line. `InvalidRequest`: a method that is not a token or a
// header that cannot be one line. `Dns`: a name that did not resolve.
// `Connect`: every address failed. `Blocked`: a host that resolves to an
// address the route may not reach. `Tls`: the TLS connection failed, with
// its `tls.TlsError`. `Timeout`: a bound passed. `Protocol`: a response
// this client cannot read. `Io`: a send or read the kernel refused.
// `Redirect`: a redirect the client would not follow. `BodyLimit`: a body
// past `HttpLimits.body`. `Decode`: a content coding the client could not
// undo. `Host`: a failure the wasi:http host reported that no other variant
// fits, with its `wasi_http.ErrorCode`. `Cancelled`: the request's task was
// cancelled while it waited.
pub enum FetchError {
  InvalidUrl(string),
  InvalidRequest(string),
  Dns(dns.DnsError),
  Connect(net.NetError),
  Blocked(string),
  Tls(tls.TlsError),
  Timeout(Phase),
  Protocol(string),
  Io(net.NetError),
  Redirect(string),
  BodyLimit,
  Decode(string),
  Host(wasi_http.ErrorCode),
  Cancelled,
}

impl cmp.Display for FetchError {}
```

### `4 pub function (p: Phase) message(): string`

```fern
<<4 pub function (p: Phase) message(): string>>=
pub function (p: Phase) message(): string {
  match (p) {
    Connecting => {
      return "connecting";
    },
    Inactivity => {
      return "waiting for the response";
    },
    Total => {
      return "in all";
    }
  }
  return "";
}

pub function (e: FetchError) message(): string {
  match (e) {
    InvalidUrl(what) => {
      return "invalid URL: " + what;
    },
    InvalidRequest(what) => {
      return "invalid request: " + what;
    },
    Dns(d) => {
      return "resolve: " + d.message();
    },
    Connect(n) => {
      return "connect: " + n.message();
    },
    Tls(t) => {
      return "TLS: " + t.message();
    },
    Timeout(p) => {
      return "timed out " + p.message();
    },
    _ => {
      return __later_message(e);
    }
  }
  return "";
}
```

### `5 function __later_message(e: FetchError): string`

```fern
<<5 function __later_message(e: FetchError): string>>=
function __later_message(e: FetchError): string {
  match (e) {
    Protocol(what) => {
      return "protocol: " + what;
    },
    Io(n) => {
      return "i/o: " + n.message();
    },
    Blocked(what) => {
      return "blocked: " + what;
    },
    Redirect(what) => {
      return "redirect: " + what;
    },
    BodyLimit => {
      return "response body past its limit";
    },
    Decode(what) => {
      return "decode: " + what;
    },
    Host(code) => {
      return "host: " + code.name();
    },
    Cancelled => {
      return "cancelled";
    },
    _ => {
      return "";
    }
  }
  return "";
}
```

### `6 pub function (e: FetchError) to_string(): string`

```fern
<<6 pub function (e: FetchError) to_string(): string>>=
pub function (e: FetchError) to_string(): string {
  return e.message();
}
```

### `7 impl error.Error for FetchError`

```fern
<<7 impl error.Error for FetchError>>=
impl error.Error for FetchError {}

impl http.ToResponse for FetchError {
  function to_response(self: FetchError): HttpResponse {
    match (self) {
      Timeout(_) => {
        return http.problem(504, "", "");
      },
      InvalidRequest(_) => {
        return http.problem(500, "", "");
      },
      _ => {
        return http.problem(502, "", "");
      }
    }
    return http.problem(502, "", "");
  }
}

pub struct Timeouts { connect: Duration, inactivity: Duration, total: Duration }
```

### `8 pub function timeouts(): Timeouts`

```fern
<<8 pub function timeouts(): Timeouts>>=
pub function timeouts(): Timeouts {
  return Timeouts { connect: time.duration_seconds(10 as i64), inactivity: time.duration_seconds(30 as i64), total: time.duration_seconds(60 as i64) };
}
```

### `9 pub struct Request`

```fern
<<9 pub struct Request>>=
pub struct Request { method: string, url: string, headers: HeaderMap, body: Body, timeouts: Timeouts, limits: http.HttpLimits, redirects: i32, decoding: Decoding, ktls: boolean }

pub struct Decoding { depth: i32, ratio: i32 }

const RATIO_FLOOR: i32 = 65536;
```

### `10 pub function decoding(): Decoding`

```fern
<<10 pub function decoding(): Decoding>>=
pub function decoding(): Decoding {
  return Decoding { depth: 1, ratio: 100 };
}

pub function request(method: string, url: string): Request {
  let none: u8[] = [];
  return Request { method: method, url: url, headers: headers.header_map_new(), body: BodyBytes(none), timeouts: timeouts(), limits: http.http_limits(), redirects: 10, decoding: decoding(), ktls: false };
}

pub function get(url: string): Request {
  return request("GET", url);
}

pub function (r: Request) with_header(name: string, value: string): Request {
  return Request { ...r, headers: r.headers.append(name, value) };
}

pub function (r: Request) with_body(body: Body): Request {
  return Request { ...r, body: body };
}

pub function (r: Request) with_text(s: string): Request {
  return Request { ...r, body: BodyText(s) };
}

pub function (r: Request) with_bytes(bs: u8[]): Request {
  return Request { ...r, body: BodyBytes(bs) };
}

pub function (r: Request) with_timeouts(t: Timeouts): Request {
  return Request { ...r, timeouts: t };
}

pub function (r: Request) with_limits(l: http.HttpLimits): Request {
  return Request { ...r, limits: l };
}

pub function (r: Request) with_redirects(hops: i32): Request {
  return Request { ...r, redirects: hops };
}

pub function (r: Request) with_decoding(d: Decoding): Request {
  return Request { ...r, decoding: d };
}

pub function (r: Request) with_ktls(): Request {
  return Request { ...r, ktls: true };
}

pub function (r: HttpResponse) ok_or_status(): Result[HttpResponse, i32] {
  if (r.status >= 200 && r.status < 300) {
    return Ok(r);
  }
  return Err(r.status);
}
```

### `11 struct __Target`

```fern
<<11 struct __Target>>=
struct __Target { host: string, port: i32, target: string, host_field: string, proxy_auth: string, direct: boolean, origin: string, authority: string, tls: boolean }
```

### `12 function __target_of(raw: string, policy: Policy): Result[__Target, FetchError]`

```fern
<<12 function __target_of(raw: string, policy: Policy): Result[__Target, FetchError]>>=
function __target_of(raw: string, policy: Policy): Result[__Target, FetchError] {
  let u: Url = __http_url(raw)?;
  let port: i32 = __permitted(policy, u.host, __effective_port(u))?;
  let tls: boolean = u.scheme == "https";
  let host_field: string = __host_field(u.host, port, tls);
  let target: string = __request_target(u)?;
  let authority: string = "";
  if (tls) {
    authority = u.host + ":" + int.int_to_string(port);
  }
  match (__proxy_for_url(policy.proxies, u)) {
    Some(spec) => {
      let p: __Proxy = __proxy_named(policy.proxies, spec, tls)?;
      if (!tls) {
        target = "http://" + host_field + target;
      }
      return Ok(__Target { host: p.host, port: p.port, target: target, host_field: host_field, proxy_auth: p.auth, direct: false, origin: u.host, authority: authority, tls: tls });
    },
    None => {}
  }
  return Ok(__Target { host: u.host, port: port, target: target, host_field: host_field, proxy_auth: "", direct: true, origin: u.host, authority: authority, tls: tls });
}

function __http_url(raw: string): Result[Url, FetchError] {
  match (url.url_parse(raw)) {
    Ok(parsed) => {
      return __http_url_checked(raw, parsed);
    },
    Err(_) => {
      return Err(InvalidUrl(raw));
    }
  }
  return Err(InvalidUrl(raw));
}

function __http_url_checked(raw: string, u: Url): Result[Url, FetchError] {
  if (u.scheme.len() == 0) {
    return Err(InvalidUrl("no scheme in " + raw));
  }
  if (u.scheme != "http" && u.scheme != "https") {
    return Err(InvalidUrl("scheme " + u.scheme + " is not http"));
  }
  if (u.host.len() == 0) {
    return Err(InvalidUrl("no host in " + raw));
  }
  if (__ambiguous_ipv4(u.host)) {
    return Err(InvalidUrl("an IPv4 address that is not four decimal octets"));
  }
  return Ok(u);
}

function __ambiguous_ipv4(host: string): boolean {
  if (host.contains(":")) {
    return false;
  }
  let end: i32 = host.len();
  if (end > 0 && host[end - 1] == 46) {
    end = end - 1;
  }
  let start: i32 = end;
  while (start > 0 && host[start - 1] != 46 as u8) {
    start = start - 1;
  }
  if (start >= end || host[start] < 48 || host[start] > 57) {
    return false;
  }
  return !net.is_ipv4(host);
}

function __request_target(u: Url): Result[string, FetchError] {
  let target: string = u.path;
  if (target.len() == 0) {
    target = "/";
  }
  if (u.query.len() > 0) {
    target = target + "?" + u.query;
  }
  if (!http.http_target_ok(target)) {
    return Err(InvalidUrl("a path or query that cannot be written on a request line"));
  }
  return Ok(target);
}

function __request_ok(req: Request): Result[void, FetchError] {
  if (!http.http_method_ok(req.method)) {
    return Err(InvalidRequest("the method is not a token"));
  }
  let i: i32 = 0;
  while (i < req.headers.names.len()) {
    if (!http.http_field_name_ok(req.headers.names[i])) {
      return Err(InvalidRequest("a header name is not a token"));
    }
    if (!http.http_field_value_ok(req.headers.values[i])) {
      return Err(InvalidRequest("a header value has a byte that cannot be written"));
    }
    i = i + 1;
  }
  match (req.body) {
    BodyFile(path) => {
      return Err(InvalidRequest("a file body cannot be sent"));
    },
    BodyFileRanges(path, ranges, seams) => {
      return Err(InvalidRequest("a file body cannot be sent"));
    },
    _ => {}
  }
  return Ok(());
}

function __host_field(host: string, port: i32, tls: boolean): string {
  let h: string = host;
  if (h.contains(":")) {
    h = "[" + h + "]";
  }
  let default_port: i32 = 80;
  if (tls) {
    default_port = 443;
  }
  if (port != default_port) {
    return h + ":" + int.int_to_string(port);
  }
  return h;
}
```

### `13 function __wire(req: Request, t: __Target, body: u8[]): u8[]`

```fern
<<13 function __wire(req: Request, t: __Target, body: u8[]): u8[]>>=
function __wire(req: Request, t: __Target, body: u8[]): u8[] {
  let b: usize = buf_new(256 + body.len());
  buf_push(b, req.method);
  buf_push(b, " ");
  buf_push(b, t.target);
  buf_push(b, " HTTP/1.1\r\nHost: ");
  buf_push(b, t.host_field);
  buf_push(b, "\r\n");
  let h: HeaderMap = req.headers;
  let i: i32 = 0;
  while (i < h.names.len()) {
    if (__sent(h, i)) {
      buf_push(b, h.names[i]);
      buf_push(b, ": ");
      buf_push(b, h.values[i]);
      buf_push(b, "\r\n");
    }
    i = i + 1;
  }
  if (__carries_length(req, body.len())) {
    buf_push(b, "Content-Length: ");
    buf_push(b, int.int_to_string(body.len()));
    buf_push(b, "\r\n");
  }
  if (__asks_codings(req)) {
    buf_push(b, "Accept-Encoding: gzip, zstd, br\r\n");
  }
  if (__sends_proxy_auth(req, t)) {
    buf_push(b, "Proxy-Authorization: ");
    buf_push(b, t.proxy_auth);
    buf_push(b, "\r\n");
  }
  buf_push(b, "\r\n");
  buf_push_bytes_range(b, body, 0, body.len());
  let out: u8[] = buf_take_bytes(b);
  buf_free(b);
  return out;
}

function __sent_fields(req: Request, t: __Target, body_len: i32): HeaderMap {
  let out: HeaderMap = headers.header_map_new();
  let i: i32 = 0;
  while (i < req.headers.names.len()) {
    if (__sent(req.headers, i)) {
      out = out.append(req.headers.names[i], req.headers.values[i]);
    }
    i = i + 1;
  }
  if (__carries_length(req, body_len)) {
    out = out.append("Content-Length", int.int_to_string(body_len));
  }
  if (__asks_codings(req)) {
    out = out.append("Accept-Encoding", "gzip, zstd, br");
  }
  if (__sends_proxy_auth(req, t)) {
    out = out.append("Proxy-Authorization", t.proxy_auth);
  }
  return out;
}

function __sent(h: HeaderMap, i: i32): boolean {
  let name: string = h.names[i];
  if (http.http_hop_by_hop(name) || http.http_connection_names(h, name)) {
    return false;
  }
  let n: i32 = name.len();
  if (n == 4) {
    return !name.eq_ignore_ascii_case("host");
  }
  if (n == 14) {
    return !name.eq_ignore_ascii_case("content-length");
  }
  return true;
}

function __carries_length(req: Request, body_len: i32): boolean {
  return body_len > 0 || req.method == "POST" || req.method == "PUT" || req.method == "PATCH";
}

function __sends_proxy_auth(req: Request, t: __Target): boolean {
  return t.proxy_auth.len() > 0 && !t.tls && !__holds(req.headers.names, "proxy-authorization");
}

function __asks_codings(req: Request): boolean {
  return req.decoding.depth > 0 && !__holds(req.headers.names, "accept-encoding");
}
```

### `14 pub trait Transport`

```fern
<<14 pub trait Transport>>=
pub trait Transport {
  function now(self: Self): Instant;
  function wall(self: Self): time.Timestamp;
  function random_bytes(self: Self, n: i32): u8[];
  function lookup(self: Self, host: string, checked: boolean): Result[Lookup, dns.DnsError];
  function connect(self: Self, addrs: net.IpAddr[], port: i32, timeout: Duration): Result[i32, net.NetError];
  function write(self: Self, conn: i32, data: u8[]): i32;
  function read(self: Self, conn: i32, max: i32, wait: Duration): Result[net.Recv, net.NetError];
  function close(self: Self, conn: i32): i32;
  function idle(self: Self): Idle;
  function socket(self: Self, conn: i32): i32;
}

pub struct Idle { kept: Cell[Kept[]], max: i32, idle: Duration, shared: Option[Shared], names: dns.Resolver, proxies: Cell[Option[ProxyEnv]], armed: Option[Cell[i32[]]] }
```

### `15 pub function (p: Idle) proxy_env(): ProxyEnv`

```fern
<<15 pub function (p: Idle) proxy_env(): ProxyEnv>>=
pub function (p: Idle) proxy_env(): ProxyEnv {
  match (p.proxies.get()) {
    Some(env) => {
      return env;
    },
    None => {}
  }
  let env: ProxyEnv = __proxies();
  p.proxies.set(Some(env));
  return env;
}
```

### `16 pub struct Kept`

```fern
<<16 pub struct Kept>>=
pub struct Kept { place: __Place, fd: i32, since: Instant, tls: Option[client.Session], h2: Option[h2.Conn] }
```

### `17 pub function idle(): Idle`

```fern
<<17 pub function idle(): Idle>>=
pub function idle(): Idle {
  return idle_limited(64, time.duration_seconds(90 as i64));
}

pub function idle_limited(max: i32, idle: Duration): Idle {
  let none: Kept[] = [];
  return Idle { kept: cell_new(none), max: max, idle: idle, shared: None, names: dns.resolver(), proxies: cell_new(None), armed: None };
}

pub function idle_shared(): Idle {
  let rows: Driven[] = [];
  let mail: Mail[] = [];
  let dialing: string[] = [];
  let fds: i32[] = [];
  return Idle { ...idle(), shared: Some(Shared { rows: cell_new(rows), mail: cell_new(mail), next: cell_new(3), dialing: cell_new(dialing) }), armed: Some(cell_new(fds)) };
}

pub function (p: Idle) read_interest(fd: i32): i32 {
  match (p.armed) {
    Some(c) => {
      let fds: i32[] = c.get();
      if (__has_fd(fds, fd)) {
        return 1 | async.WATCHED;
      }
      c.set(fds.append(fd));
      return 1 | async.KEEP;
    },
    None => {
      return 1;
    }
  }
  return 1;
}
```

### `18 function __has_fd(fds: i32[], fd: i32): boolean`

```fern
<<18 function __has_fd(fds: i32[], fd: i32): boolean>>=
function __has_fd(fds: i32[], fd: i32): boolean {
  let i: i32 = 0;
  while (i < fds.len()) {
    if (fds[i] == fd) {
      return true;
    }
    i = i + 1;
  }
  return false;
}

function __without_fd(fds: i32[], fd: i32): i32[] {
  let out: i32[] = [];
  for f in fds {
    if (f != fd) {
      out = out.append(f);
    }
  }
  return out;
}
```

### `19 pub function (p: Idle) armed(fd: i32): boolean`

```fern
<<19 pub function (p: Idle) armed(fd: i32): boolean>>=
pub function (p: Idle) armed(fd: i32): boolean {
  match (p.armed) {
    Some(c) => {
      return __has_fd(c.get(), fd);
    },
    None => {
      return false;
    }
  }
  return false;
}

pub function (p: Idle) disarm(fd: i32): void {
  match (p.armed) {
    Some(c) => {
      c.set(__without_fd(c.get(), fd));
    },
    None => {}
  }
  let rows: Kept[] = p.kept.get();
  let i: i32 = 0;
  while (i < rows.len()) {
    if (rows[i].fd == fd) {
      p.kept.set(__kept_without(rows, i));
      tcp_close(fd);
      return;
    }
    i = i + 1;
  }
}

pub function shared_of(pool: Idle): Shared {
  match (pool.shared) {
    Some(sh) => {
      return sh;
    },
    None => {
      let rows: Driven[] = [];
      let mail: Mail[] = [];
      let dialing: string[] = [];
      return Shared { rows: cell_new(rows), mail: cell_new(mail), next: cell_new(3), dialing: cell_new(dialing) };
    }
  }
  return shared_of(pool);
}
```

### `20 pub struct Shared`

```fern
<<20 pub struct Shared>>=
pub struct Shared { rows: Cell[Driven[]], mail: Cell[Mail[]], next: Cell[i32], dialing: Cell[string[]] }

pub struct Driven { key: string, fd: i32, tls: client.Session, h2: h2.Conn, out: u8[], wire: u8[], streams: i32, since: Instant, watched: boolean, writing: boolean }

pub struct Mail { id: i32, fd: i32, stream: i32, key: string, answer: Option[Result[Answer, FetchError]] }

pub struct Answer { status: i32, headers: HeaderMap, body: u8[], trailers: HeaderMap }

pub const MAIL_INTEREST: i32 = 4;

pub const SHARED_STREAMS: i32 = 100;
```

### `21 pub function (sh: Shared) quiet(): boolean`

```fern
<<21 pub function (sh: Shared) quiet(): boolean>>=
pub function (sh: Shared) quiet(): boolean {
  return sh.rows.get().len() == 0 && sh.mail.get().len() == 0 && sh.dialing.get().len() == 0;
}

pub function (sh: Shared) owns(fd: i32): boolean {
  return __driven_at(sh.rows.get(), fd) >= 0;
}

pub function (sh: Shared) adopt(key: string, fd: i32, tls: client.Session, hc: h2.Conn, now: Instant): void {
  sh.rows.set(sh.rows.get().append(Driven { key: key, fd: fd, tls: tls, h2: hc, out: [], wire: [], streams: 0, since: now, watched: false, writing: false }));
}

pub function (sh: Shared) pick(key: string): Option[i32] {
  for d in sh.rows.get() {
    if (d.key == key && d.streams < SHARED_STREAMS && !d.h2.closed() && !d.h2.going_away()) {
      return Some(d.fd);
    }
  }
  return None;
}

pub function (sh: Shared) submit(fd: i32, out: h2.Outgoing): i32 {
  let rows: Driven[] = sh.rows.get();
  let at: i32 = __driven_at(rows, fd);
  if (at < 0) {
    return 0;
  }
  let d: Driven = rows[at];
  let (sent, stream) = d.h2.request(out);
  if (stream < 0) {
    return 0;
  }
  sh.rows.set(rows.with(at, Driven { ...d, h2: sent.conn, out: d.out.concat(sent.output), streams: d.streams + 1 }));
  let id: i32 = 0 - sh.next.get();
  sh.next.set(sh.next.get() + 1);
  sh.mail.set(sh.mail.get().append(Mail { id: id, fd: fd, stream: stream, key: "", answer: None }));
  return id;
}

pub function (sh: Shared) dialing(key: string): boolean {
  for k in sh.dialing.get() {
    if (k == key) {
      return false;
    }
  }
  sh.dialing.set(sh.dialing.get().append(key));
  return true;
}

pub function (sh: Shared) dialed(key: string): void {
  let kept: string[] = [];
  for k in sh.dialing.get() {
    if (k != key) {
      kept = kept.append(k);
    }
  }
  sh.dialing.set(kept);
  let mail: Mail[] = sh.mail.get();
  let i: i32 = 0;
  while (i < mail.len()) {
    if (mail[i].fd < 0 && mail[i].key == key) {
      mail = mail.with(i, Mail { ...mail[i], answer: Some(Ok(Answer { status: 0, headers: headers.header_map_new(), body: [], trailers: headers.header_map_new() })) });
    }
    i = i + 1;
  }
  sh.mail.set(mail);
}

pub function (sh: Shared) await_connection(key: string): i32 {
  let id: i32 = 0 - sh.next.get();
  sh.next.set(sh.next.get() + 1);
  sh.mail.set(sh.mail.get().append(Mail { id: id, fd: 0 - 1, stream: 0, key: key, answer: None }));
  return id;
}

pub function (sh: Shared) take(id: i32): Option[Result[Answer, FetchError]] {
  let mail: Mail[] = sh.mail.get();
  let at: i32 = __mail_at(mail, id);
  if (at < 0) {
    return Some(Err(Protocol("HTTP/2: the stream's slot is gone")));
  }
  match (mail[at].answer) {
    Some(a) => {
      sh.mail.set(__mail_without(mail, at));
      return Some(a);
    },
    None => {
      return None;
    }
  }
  return None;
}

pub function (sh: Shared) abandon(id: i32): void {
  let mail: Mail[] = sh.mail.get();
  let at: i32 = __mail_at(mail, id);
  if (at < 0) {
    return;
  }
  let m: Mail = mail[at];
  sh.mail.set(__mail_without(mail, at));
  if (m.fd < 0) {
    return;
  }
  let rows: Driven[] = sh.rows.get();
  let row: i32 = __driven_at(rows, m.fd);
  if (row < 0) {
    return;
  }
  let d: Driven = rows[row];
  let step: h2.Step = d.h2.reset(m.stream, 8);
  sh.rows.set(rows.with(row, Driven { ...d, h2: step.conn, out: d.out.concat(step.output), streams: d.streams - 1, since: clock.instant() }));
}

pub function (sh: Shared) answered(): i32[] {
  let out: i32[] = [];
  for m in sh.mail.get() {
    match (m.answer) {
      Some(_) => {
        out = out.append(m.id);
      },
      None => {}
    }
  }
  return out;
}
```

### `22 pub function (sh: Shared) unwatched(): i32[]`

```fern
<<22 pub function (sh: Shared) unwatched(): i32[]>>=
pub function (sh: Shared) unwatched(): i32[] {
  let rows: Driven[] = sh.rows.get();
  let out: i32[] = [];
  let i: i32 = 0;
  while (i < rows.len()) {
    if (!rows[i].watched) {
      out = out.append(rows[i].fd);
      rows = rows.with(i, Driven { ...rows[i], watched: true });
    }
    i = i + 1;
  }
  sh.rows.set(rows);
  return out;
}

pub function (sh: Shared) flush(): (i32[], i32[]) {
  let rows: Driven[] = sh.rows.get();
  let now_waiting: i32[] = [];
  let drained: i32[] = [];
  let i: i32 = 0;
  while (i < rows.len()) {
    let d: Driven = __sealed(rows[i]);
    if (d.wire.len() > 0) {
      match (net.write_rest(d.fd, d.wire)) {
        Ok(rest) => {
          d = Driven { ...d, wire: rest };
        },
        Err(e) => {
          sh.rows.set(rows);
          __driven_failed(sh, d.fd, Io(e));
          return sh.flush();
        }
      }
    }
    let waits: boolean = d.wire.len() > 0;
    if (waits && !d.writing) {
      now_waiting = now_waiting.append(d.fd);
    }
    if (!waits && d.writing) {
      drained = drained.append(d.fd);
    }
    rows = rows.with(i, Driven { ...d, writing: waits });
    i = i + 1;
  }
  sh.rows.set(rows);
  return (now_waiting, drained);
}

pub function (sh: Shared) sockets(): i32[] {
  let out: i32[] = [];
  for d in sh.rows.get() {
    out = out.append(d.fd);
  }
  return out;
}
```

### `23 function __driven_kernel(sh: Shared, at: i32, d: Driven, bytes: u8[]): Option[i32]`

```fern
<<23 function __driven_kernel(sh: Shared, at: i32, d: Driven, bytes: u8[]): Option[i32]>>=
function __driven_kernel(sh: Shared, at: i32, d: Driven, bytes: u8[]): Option[i32] {
  let session: client.Session = d.tls;
  if (bytes.len() == 0) {
    match (__kernel_record(d.fd, d.tls, clock.now())) {
      RecordTaken(step) => {
        session = step.session;
        if (step.closed) {
          __driven_failed(sh, d.fd, __closed_early(0));
          return Some(d.fd);
        }
      },
      RecordAwaited => {
        return None;
      },
      RecordsEnded => {
        __driven_failed(sh, d.fd, __closed_early(0));
        return Some(d.fd);
      },
      RecordFailed(e) => {
        __driven_failed(sh, d.fd, e);
        return Some(d.fd);
      }
    }
  }
  let fed: h2.Step = d.h2.read(bytes);
  let streams: i32 = __mail_answered(sh, d.fd, fed.events, d.streams);
  sh.rows.set(sh.rows.get().with(at, Driven { ...d, tls: session, h2: fed.conn, out: d.out.concat(fed.output), streams: streams, since: clock.instant() }));
  if (fed.conn.closed()) {
    __driven_failed(sh, d.fd, Protocol("HTTP/2: the connection closed before the response ended"));
    return Some(d.fd);
  }
  return None;
}

function __sealed(d: Driven): Driven {
  if (d.out.len() == 0) {
    return d;
  }
  if (d.tls.offloaded()) {
    return Driven { ...d, out: [], wire: d.wire.concat(d.out) };
  }
  match (d.tls.write(d.out)) {
    Ok(step) => {
      return Driven { ...d, tls: step.session, out: [], wire: d.wire.concat(step.output) };
    },
    Err(e) => {
      return Driven { ...d, out: [] };
    }
  }
  return d;
}
```

### `24 pub function (sh: Shared) event(fd: i32, readable: boolean): Option[i32]`

```fern
<<24 pub function (sh: Shared) event(fd: i32, readable: boolean): Option[i32]>>=
pub function (sh: Shared) event(fd: i32, readable: boolean): Option[i32] {
  if (!readable) {
    return None;
  }
  let rows: Driven[] = sh.rows.get();
  let at: i32 = __driven_at(rows, fd);
  if (at < 0) {
    return None;
  }
  let d: Driven = rows[at];
  let bytes: u8[] = [];
  match (net.read_up_to(fd, 65536)) {
    Ok(got) => {
      bytes = got;
    },
    Err(e) => {
      return __driven_read_failed(sh, at, d, e);
    }
  }
  if (d.tls.offloaded()) {
    return __driven_kernel(sh, at, d, bytes);
  }
  if (bytes.len() == 0) {
    __driven_failed(sh, fd, __closed_early(0));
    return Some(fd);
  }
  return __driven_feed(sh, at, d, bytes);
}
```

### `25 function __driven_read_failed(sh: Shared, at: i32, d: Driven, e: net.NetError): Option[i32]`

```fern
<<25 function __driven_read_failed(sh: Shared, at: i32, d: Driven, e: net.NetError): Option[i32]>>=
function __driven_read_failed(sh: Shared, at: i32, d: Driven, e: net.NetError): Option[i32] {
  if (d.tls.offloaded()) {
    let none: u8[] = [];
    return __driven_kernel(sh, at, d, none);
  }
  if (e.eq(net.WouldBlock)) {
    return None;
  }
  __driven_failed(sh, d.fd, Io(e));
  return Some(d.fd);
}

function __driven_feed(sh: Shared, at: i32, d: Driven, bytes: u8[]): Option[i32] {
  let fd: i32 = d.fd;
  match (d.tls.read(bytes, clock.now())) {
    Ok(step) => {
      let fed: h2.Step = d.h2.read(step.data);
      let streams: i32 = __mail_answered(sh, fd, fed.events, d.streams);
      sh.rows.set(sh.rows.get().with(at, Driven { ...d, tls: step.session, h2: fed.conn, out: d.out.concat(step.output).concat(fed.output), streams: streams, since: clock.instant() }));
      if (fed.conn.closed() || step.closed) {
        __driven_failed(sh, fd, Protocol("HTTP/2: the connection closed before the response ended"));
        return Some(fd);
      }
      return None;
    },
    Err(f) => {
      let sent: i32 = tcp_send_bytes(fd, f.alert);
      __driven_failed(sh, fd, Tls(f.error));
      return Some(fd);
    }
  }
  return None;
}
```

### `26 pub function (sh: Shared) expired(now: Instant, idle: Duration): i32[]`

```fern
<<26 pub function (sh: Shared) expired(now: Instant, idle: Duration): i32[]>>=
// Drops and returns the idle connections quiet for longer than `idle`, and those the peer is closing.
pub function (sh: Shared) expired(now: Instant, idle: Duration): i32[] {
  let rows: Driven[] = sh.rows.get();
  let kept: Driven[] = [];
  let gone: i32[] = [];
  for d in rows {
    if (d.streams == 0 && (now.since(d.since).cmp(idle) > 0 || d.h2.going_away() || d.h2.closed())) {
      gone = gone.append(d.fd);
    } else {
      kept = kept.append(d);
    }
  }
  sh.rows.set(kept);
  return gone;
}
```

### `27 function __mail_answered(sh: Shared, fd: i32, events: h2.Event[], streams: i32): i32`

```fern
<<27 function __mail_answered(sh: Shared, fd: i32, events: h2.Event[], streams: i32): i32>>=
function __mail_answered(sh: Shared, fd: i32, events: h2.Event[], streams: i32): i32 {
  for e in events {
    match (e) {
      h2.Answered(sid, resp) => {
        streams = streams - __mail_deliver(sh, fd, sid, Ok(Answer { status: resp.status, headers: http.http_end_to_end(resp.headers), body: resp.body_bytes(), trailers: resp.trailers }));
      },
      h2.Reset(sid, code) => {
        streams = streams - __mail_deliver(sh, fd, sid, Err(Protocol("HTTP/2: the server reset the stream with code " + int.int_to_string(code))));
      },
      _ => {}
    }
  }
  return streams;
}

function __mail_deliver(sh: Shared, fd: i32, stream: i32, answer: Result[Answer, FetchError]): i32 {
  let mail: Mail[] = sh.mail.get();
  let i: i32 = 0;
  while (i < mail.len()) {
    if (mail[i].fd == fd && mail[i].stream == stream) {
      sh.mail.set(mail.with(i, Mail { ...mail[i], answer: Some(answer) }));
      return 1;
    }
    i = i + 1;
  }
  return 0;
}

function __driven_failed(sh: Shared, fd: i32, e: FetchError): void {
  let rows: Driven[] = sh.rows.get();
  let at: i32 = __driven_at(rows, fd);
  if (at >= 0) {
    sh.rows.set(__driven_without(rows, at));
  }
  let mail: Mail[] = sh.mail.get();
  let i: i32 = 0;
  while (i < mail.len()) {
    if (mail[i].fd == fd) {
      match (mail[i].answer) {
        Some(_) => {},
        None => {
          mail = mail.with(i, Mail { ...mail[i], answer: Some(Err(e)) });
        }
      }
    }
    i = i + 1;
  }
  sh.mail.set(mail);
}

function __driven_at(rows: Driven[], fd: i32): i32 {
  let i: i32 = 0;
  while (i < rows.len()) {
    if (rows[i].fd == fd) {
      return i;
    }
    i = i + 1;
  }
  return 0 - 1;
}

function __driven_without(rows: Driven[], skip: i32): Driven[] {
  let out: Driven[] = [];
  let i: i32 = 0;
  while (i < rows.len()) {
    if (i != skip) {
      out = out.append(rows[i]);
    }
    i = i + 1;
  }
  return out;
}

function __mail_at(mail: Mail[], id: i32): i32 {
  let i: i32 = 0;
  while (i < mail.len()) {
    if (mail[i].id == id) {
      return i;
    }
    i = i + 1;
  }
  return 0 - 1;
}

function __mail_without(mail: Mail[], skip: i32): Mail[] {
  let out: Mail[] = [];
  let i: i32 = 0;
  while (i < mail.len()) {
    if (i != skip) {
      out = out.append(mail[i]);
    }
    i = i + 1;
  }
  return out;
}
```

### `28 pub function close_idle[T: Transport](tr: T): void`

```fern
<<28 pub function close_idle[T: Transport](tr: T): void>>=
pub function close_idle[T: Transport](tr: T): void {
  let pool: Idle = tr.idle();
  for k in pool.kept.get() {
    __close(tr, __kept_conn(k));
  }
  let none: Kept[] = [];
  pool.kept.set(none);
}
```

### `29 struct __Place`

```fern
<<29 struct __Place>>=
struct __Place { guard: boolean, host: string, port: i32, tls: string }
```

### `30 function __place_of(t: __Target, guard: boolean, roots: Option[verify.Roots]): __Place`

```fern
<<30 function __place_of(t: __Target, guard: boolean, roots: Option[verify.Roots]): __Place>>=
function __place_of(t: __Target, guard: boolean, roots: Option[verify.Roots]): __Place {
  let tls: string = "";
  if (t.tls) {
    tls = t.authority + " " + __roots_key(roots);
  }
  return __Place { guard: guard, host: t.host, port: t.port, tls: tls };
}

function __place_eq(a: __Place, b: __Place): boolean {
  return a.port == b.port && a.guard == b.guard && a.host == b.host && a.tls == b.tls;
}

function __place_key(p: __Place): string {
  let route: string = "open ";
  if (p.guard) {
    route = "global ";
  }
  let key: string = route + p.host + " " + int.int_to_string(p.port);
  if (p.tls.len() > 0) {
    key = key + " tls " + p.tls;
  }
  return key;
}

function __roots_key(roots: Option[verify.Roots]): string {
  match (roots) {
    Some(r) => {
      let h: crypto.Sha256 = crypto.sha256_new();
      for c in r.certs {
        h = h.update(c.raw);
      }
      return hex.encode(h.finish());
    },
    None => {
      return "system";
    }
  }
  return "system";
}

function __take_idle[T: Transport](tr: T, place: __Place): __Conn {
  let rows: Kept[] = __live_kept(tr);
  let pick: i32 = rows.len() - 1;
  while (pick >= 0 && !__place_eq(rows[pick].place, place)) {
    pick = pick - 1;
  }
  if (pick < 0) {
    return __no_conn();
  }
  let conn: __Conn = __kept_conn(rows[pick]);
  tr.idle().kept.set(__kept_without(rows, pick));
  return conn;
}

function __park[T: Transport](tr: T, place: __Place, conn: __Conn): void {
  let rows: Kept[] = __live_kept(tr).append(Kept { place: place, fd: conn.fd, since: tr.now(), tls: conn.tls, h2: conn.h2 });
  let from: i32 = 0;
  while (rows.len() - from > tr.idle().max) {
    __close(tr, __kept_conn(rows[from]));
    from = from + 1;
  }
  if (from > 0) {
    rows = __kept_from(rows, from);
  }
  tr.idle().kept.set(rows);
}

function __live_kept[T: Transport](tr: T): Kept[] {
  let pool: Idle = tr.idle();
  let rows: Kept[] = pool.kept.get();
  if (rows.len() == 0) {
    return rows;
  }
  let now: Instant = tr.now();
  let from: i32 = 0;
  while (from < rows.len() && now.since(rows[from].since).cmp(pool.idle) > 0) {
    __close(tr, __kept_conn(rows[from]));
    from = from + 1;
  }
  if (from == 0) {
    return rows;
  }
  let out: Kept[] = __kept_from(rows, from);
  pool.kept.set(out);
  return out;
}

function __kept_conn(k: Kept): __Conn {
  return __Conn { fd: k.fd, tls: k.tls, closed: false, h2: k.h2 };
}

function __kept_without(rows: Kept[], skip: i32): Kept[] {
  let out: Kept[] = [];
  let i: i32 = 0;
  while (i < rows.len()) {
    if (i != skip) {
      out = out.append(rows[i]);
    }
    i = i + 1;
  }
  return out;
}

function __kept_from(rows: Kept[], from: i32): Kept[] {
  let out: Kept[] = [];
  while (from < rows.len()) {
    out = out.append(rows[from]);
    from = from + 1;
  }
  return out;
}
```

### `31 pub struct Lookup`

```fern
<<31 pub struct Lookup>>=
pub struct Lookup { dial: net.IpAddr[], named: net.IpAddr[], judged: net.IpAddr[] }

pub struct Sockets { pool: Idle }
```

### `32 pub function sockets(): Sockets`

```fern
<<32 pub function sockets(): Sockets>>=
pub function sockets(): Sockets {
  return sockets_with(idle());
}

pub function sockets_with(pool: Idle): Sockets {
  return Sockets { pool: pool };
}
```

### `33 impl Transport for Sockets`

```fern
<<33 impl Transport for Sockets>>=
impl Transport for Sockets {
  function now(self: Sockets): Instant {
    return clock.instant();
  }
  function wall(self: Sockets): time.Timestamp {
    return clock.now();
  }
  function random_bytes(self: Sockets, n: i32): u8[] {
    return random_bytes(n);
  }
  function lookup(self: Sockets, host: string, checked: boolean): Result[Lookup, dns.DnsError] {
    let none: net.IpAddr[] = [];
    let names: dns.Resolver = self.pool.names;
    if (!checked) {
      let found: net.IpAddr[] = names.resolve(host)?;
      return Ok(Lookup { dial: found, named: none, judged: none });
    }
    let plain: net.IpAddr[] = names.resolve_plain(host)?;
    let carried: net.IpAddr[] = [];
    for a in plain {
      match (names.nat64_carried(a)) {
        Some(v4) => {
          carried = carried.append(v4);
        },
        None => {
          carried = carried.append(a);
        }
      }
    }
    return Ok(Lookup { dial: names.synthesized(plain), named: plain, judged: carried });
  }
  function connect(self: Sockets, addrs: net.IpAddr[], port: i32, timeout: Duration): Result[i32, net.NetError] {
    return dns.connect_race(addrs, port, dns.DialOptions { ...dns.dial_options(), timeout: timeout });
  }
  function write(self: Sockets, conn: i32, data: u8[]): i32 {
    return tcp_send_bytes(conn, data);
  }
  function read(self: Sockets, conn: i32, max: i32, wait: Duration): Result[net.Recv, net.NetError] {
    return net.read_watched(conn, max, wait, self.pool.read_interest(conn));
  }
  function close(self: Sockets, conn: i32): i32 {
    match (self.pool.armed) {
      Some(c) => {
        c.set(__without_fd(c.get(), conn));
      },
      None => {}
    }
    tcp_close(conn);
    return 0;
  }
  function idle(self: Sockets): Idle {
    return self.pool;
  }
  function socket(self: Sockets, conn: i32): i32 {
    return conn;
  }
}
```

### `34 pub function send(req: Request): Result[HttpResponse, FetchError]`

```fern
<<34 pub function send(req: Request): Result[HttpResponse, FetchError]>>=
pub function send(req: Request): Result[HttpResponse, FetchError] {
  return __send_closing(Policy { ...public_policy(), public_only: false }, req);
}

pub function send_public(req: Request): Result[HttpResponse, FetchError] {
  return __send_closing(public_policy(), req);
}

pub function send_public_on[T: Transport](tr: T, req: Request): Result[HttpResponse, FetchError] {
  return send_on(tr, req, public_policy());
}
```

### `35 function __send_closing(policy: Policy, req: Request): Result[HttpResponse, FetchError]`

```fern
<<35 function __send_closing(policy: Policy, req: Request): Result[HttpResponse, FetchError]>>=
function __send_closing(policy: Policy, req: Request): Result[HttpResponse, FetchError] {
  let tr: Sockets = sockets();
  if (target_os() == "wasi-http") {
    return send_on(tr, req, policy);
  } else {
    let answer: Result[HttpResponse, FetchError] = send_on(tr, req, policy);
    close_idle(tr);
    return answer;
  }
}

function __proxies(): ProxyEnv {
  if (target_os() == "wasi-http") {
    return proxies("", "", "");
  } else {
    return proxy_env();
  }
}
```

### `36 pub struct Policy`

```fern
<<36 pub struct Policy>>=
pub struct Policy { public_only: boolean, proxies: ProxyEnv, roots: Option[verify.Roots], jar: Option[cookie.Jar], allow: Option[Allow] }
```

### `37 pub function public_policy(): Policy`

```fern
<<37 pub function public_policy(): Policy>>=
pub function public_policy(): Policy {
  return public_policy_via(__proxies());
}

pub function public_policy_via(proxies: ProxyEnv): Policy {
  return Policy { public_only: true, proxies: proxies, roots: None, jar: None, allow: None };
}
```

### `38 pub struct Allow`

```fern
<<38 pub struct Allow>>=
pub struct Allow { rules: __AllowRule[] }

// AllowError is the allow-list entry `allow` refused.
pub struct AllowError { entry: string }

pub function (e: AllowError) message(): string {
  return "allow-list entry \"" + e.entry + "\" is not a host, a host:port or a *.domain";
}

pub function (e: AllowError) to_string(): string {
  return e.message();
}

impl error.Error for AllowError {}

impl cmp.Display for AllowError {}

struct __AllowRule { host: string, sub: boolean, port: i32 }
```

### `39 pub function allow(entries: string[]): Result[Allow, AllowError]`

```fern
<<39 pub function allow(entries: string[]): Result[Allow, AllowError]>>=
pub function allow(entries: string[]): Result[Allow, AllowError] {
  let rules: __AllowRule[] = [];
  for e in entries {
    match (__allow_rule(e.to_lower())) {
      Some(r) => {
        rules = rules.append(r);
      },
      None => {
        return Err(AllowError { entry: e });
      }
    }
  }
  return Ok(Allow { rules: rules });
}
```

### `40 function __allow_rule(e: string): Option[__AllowRule]`

```fern
<<40 function __allow_rule(e: string): Option[__AllowRule]>>=
function __allow_rule(e: string): Option[__AllowRule] {
  match (__allow_parts(e)) {
    Some(parts) => {
      let (named, port) = parts;
      let p: i32 = 0 - 1;
      if (port.len() > 0) {
        p = __allow_port(port);
        if (p < 0) {
          return None;
        }
      }
      return __allow_host(named, e.starts_with("["), p);
    },
    None => {}
  }
  return None;
}

function __allow_host(named: string, bracketed: boolean, port: i32): Option[__AllowRule] {
  let host: string = named;
  let sub: boolean = !bracketed && host.starts_with("*.");
  if (sub) {
    host = host.drop(2);
  }
  if (host.ends_with(".")) {
    host = host.take(host.len() - 1);
  }
  if (host.len() == 0 || !(bracketed || host.contains_only("abcdefghijklmnopqrstuvwxyz0123456789-."))) {
    return None;
  }
  return Some(__AllowRule { host: host, sub: sub, port: port });
}

function __allow_parts(e: string): Option[(string, string)] {
  if (e.ends_with(":")) {
    return None;
  }
  if (!e.starts_with("[")) {
    if (e.contains(":")) {
      return Some((e.before(":"), e.after(":")));
    }
    return Some((e, ""));
  }
  let Some(close) = e.index_of("]") else {
    return None;
  };
  let host: string = e.take(close).drop(1);
  let rest: string = e.drop(close + 1);
  if (rest.len() > 0 && !rest.starts_with(":")) {
    return None;
  }
  if (!host.contains(":") || !host.contains_only("0123456789abcdef:.")) {
    return None;
  }
  return Some((host, rest.drop(1)));
}

function __allow_port(s: string): i32 {
  if (s.len() == 0 || s.len() > 5 || s.starts_with("0") || !s.contains_only("0123456789")) {
    return 0 - 1;
  }
  match (i32.parse_i32(s)) {
    Ok(n) => {
      if (n <= 65535) {
        return n;
      }
    },
    Err(_) => {}
  }
  return 0 - 1;
}

function __permitted(policy: Policy, host: string, port: i32): Result[i32, FetchError] {
  match (policy.allow) {
    None => {
      return Ok(port);
    },
    Some(a) => {
      let h: string = host.to_lower();
      if (h.ends_with(".")) {
        h = h.take(h.len() - 1);
      }
      for r in a.rules {
        let named: boolean = h == r.host;
        if (r.sub) {
          named = h.ends_with("." + r.host);
        }
        if (named && (r.port < 0 || r.port == port)) {
          return Ok(port);
        }
      }
      return Err(Blocked(host + ":" + int.int_to_string(port) + " is not on the allow-list"));
    }
  }
  return Ok(port);
}
```

### `41 pub function send_on[T: Transport](tr: T, req: Request, policy: Policy): Result[HttpResponse, FetchError]`

```fern
<<41 pub function send_on[T: Transport](tr: T, req: Request, policy: Policy): Result[HttpResponse, FetchError]>>=
pub function send_on[T: Transport](tr: T, req: Request, policy: Policy): Result[HttpResponse, FetchError] {
  let started: i64 = time.instant_nanos(tr.now());
  let cur: Request = req;
  let hops: i32 = 0;
  while (true) {
    let hop: Request = __with_jar(tr, cur, policy.jar);
    let resp: HttpResponse = __send_once(tr, hop, started, policy)?;
    __stored(tr, policy.jar, hop.url, resp.headers);
    if (!__redirects(resp.status) || req.redirects == 0) {
      return Ok(resp);
    }
    if (hops >= req.redirects) {
      return Err(Redirect("more than " + int.int_to_string(req.redirects) + " redirects"));
    }
    hops = hops + 1;
    cur = __next_hop(cur, resp)?;
  }
  return Err(Redirect("unreachable"));
}
```

### `42 function __with_jar[T: Transport](tr: T, req: Request, jar: Option[cookie.Jar]): Request`

```fern
<<42 function __with_jar[T: Transport](tr: T, req: Request, jar: Option[cookie.Jar]): Request>>=
function __with_jar[T: Transport](tr: T, req: Request, jar: Option[cookie.Jar]): Request {
  match (jar) {
    Some(j) => {
      match (j.header(req.url, tr.wall())) {
        Some(v) => {
          let all: string = v;
          match (req.headers.get("cookie")) {
            Some(given) => {
              all = given + "; " + v;
            },
            None => {}
          }
          return Request { ...req, headers: req.headers.set("Cookie", all) };
        },
        None => {
          return req;
        }
      }
    },
    None => {
      return req;
    }
  }
  return req;
}

function __stored[T: Transport](tr: T, jar: Option[cookie.Jar], request_url: string, h: HeaderMap): void {
  match (jar) {
    Some(j) => {
      j.store(request_url, h, tr.wall());
    },
    None => {}
  }
}

function __redirects(status: i32): boolean {
  return status == 301 || status == 302 || status == 303 || status == 307 || status == 308;
}

function __next_hop(cur: Request, resp: HttpResponse): Result[Request, FetchError] {
  let location: string = "";
  match (resp.headers.get("location")) {
    Some(l) => {
      location = l;
    },
    None => {
      return Err(Redirect("a " + int.int_to_string(resp.status) + " without a Location"));
    }
  }
  let target: string = "";
  match (url.url_resolve(cur.url, location)) {
    Ok(t) => {
      target = t;
    },
    Err(_) => {
      return Err(Redirect("a Location that is not a URL"));
    }
  }
  let next: Request = Request { ...cur, url: target };
  if (__rewrites_to_get(resp.status, cur.method)) {
    let none: u8[] = [];
    next = Request { ...next, method: "GET", body: BodyBytes(none), headers: __without(next.headers, ["content-type", "content-length"]) };
  }
  if (!__same_origin(cur.url, target)) {
    next = Request { ...next, headers: __without(next.headers, ["authorization", "proxy-authorization", "cookie"]) };
  }
  return Ok(next);
}

function __rewrites_to_get(status: i32, method: string): boolean {
  if (status == 303) {
    return method != "HEAD";
  }
  return (status == 301 || status == 302) && method == "POST";
}

function __without(h: HeaderMap, names: string[]): HeaderMap {
  let out: HeaderMap = headers.header_map_new();
  let i: i32 = 0;
  while (i < h.names.len()) {
    if (!__holds(names, h.names[i])) {
      out = out.append(h.names[i], h.values[i]);
    }
    i = i + 1;
  }
  return out;
}

function __holds(names: string[], name: string): boolean {
  for n in names {
    if (n.eq_ignore_ascii_case(name)) {
      return true;
    }
  }
  return false;
}

function __same_origin(a: string, b: string): boolean {
  let ua: Url = Url { scheme: "", host: "", port: 0, path: "", query: "", fragment: "" };
  let ub: Url = ua;
  match (url.url_parse(a)) {
    Ok(p) => {
      ua = p;
    },
    Err(_) => {
      return false;
    }
  }
  match (url.url_parse(b)) {
    Ok(p) => {
      ub = p;
    },
    Err(_) => {
      return false;
    }
  }
  return ua.scheme.to_lower() == ub.scheme.to_lower() && ua.host.to_lower() == ub.host.to_lower() && __effective_port(ua) == __effective_port(ub);
}

function __effective_port(u: Url): i32 {
  if (u.port != 0) {
    return u.port;
  }
  if (u.scheme == "https") {
    return 443;
  }
  return 80;
}
```

### `43 function __send_once[T: Transport](tr: T, req: Request, started: i64, policy: Policy): Result[HttpResponse,...`

```fern
<<43 function __send_once[T: Transport](tr: T, req: Request, started: i64, policy: Policy): Result[HttpResponse,...>>=
function __send_once[T: Transport](tr: T, req: Request, started: i64, policy: Policy): Result[HttpResponse, FetchError] {
  let t: __Target = __target_of(req.url, policy)?;
  match (__request_ok(req)) {
    Ok(_) => {},
    Err(e) => {
      return Err(e);
    }
  }
  if (target_os() == "wasi-http") {
    return __send_hosted(req, t);
  } else {
    return __send_dialled(tr, req, t, started, policy);
  }
}

function __send_dialled[T: Transport](tr: T, req: Request, t: __Target, started: i64, policy: Policy): Result[HttpResponse, FetchError] {
  __origin_checked(tr, t, policy)?;
  let guard: boolean = policy.public_only && t.direct;
  let first: Result[HttpResponse, FetchError] = __attempt(tr, req, t, started, guard, policy.roots, true);
  match (first) {
    Err(e) => {
      if (__reset(e) && http.http_method_idempotent(req.method)) {
        return __attempt(tr, req, t, started, guard, policy.roots, false);
      }
      return Err(e);
    },
    Ok(resp) => {
      return Ok(resp);
    }
  }
  return first;
}

function __origin_checked[T: Transport](tr: T, t: __Target, policy: Policy): Result[void, FetchError] {
  if (policy.public_only && !t.direct) {
    let checked: net.IpAddr[] = __resolve(tr, t.origin, true)?;
  }
  return Ok(());
}

function __reset(e: FetchError): boolean {
  match (e) {
    Io(n) => {
      return n.eq(net.ConnectionReset) || n.eq(net.ConnectionAborted) || n.eq(net.Other(errno.EPIPE));
    },
    _ => {
      return false;
    }
  }
  return false;
}

function __attempt[T: Transport](tr: T, req: Request, t: __Target, started: i64, guard: boolean, roots: Option[verify.Roots], reuse: boolean): Result[HttpResponse, FetchError] {
  let place: __Place = __place_of(t, guard, roots);
  let conn: __Conn = __no_conn();
  if (reuse && http.http_method_idempotent(req.method)) {
    conn = __take_idle(tr, place);
  }
  if (conn.fd < 0) {
    if (t.tls && async.in_task()) {
      match (tr.idle().shared) {
        Some(sh) => {
          return __attempt_shared(tr, req, t, started, place, guard, roots, sh);
        },
        None => {}
      }
    }
    conn = __connect(tr, t, req, guard, roots)?;
  }
  return __attempt_opened(tr, req, t, started, place, conn);
}

function __attempt_opened[T: Transport](tr: T, req: Request, t: __Target, started: i64, place: __Place, conn: __Conn): Result[HttpResponse, FetchError] {
  if let Some(hc) = conn.h2 {
    return __attempt_h2(tr, req, t, started, place, conn, hc);
  }
  return __attempt_h1(tr, req, t, started, place, conn);
}

function __attempt_shared[T: Transport](tr: T, req: Request, t: __Target, started: i64, place: __Place, guard: boolean, roots: Option[verify.Roots], sh: Shared): Result[HttpResponse, FetchError] {
  let fd: i32 = 0 - 1;
  match (__shared_socket(tr, req, t, started, __place_key(place), guard, roots, sh)?) {
    OnLoop(socket) => {
      fd = socket;
    },
    OnTask(conn) => {
      return __attempt_opened(tr, req, t, started, place, conn);
    }
  }
  let body: u8[] = req.body.bytes();
  let id: i32 = sh.submit(fd, h2.Outgoing { method: req.method, scheme: "https", authority: t.host_field, path: t.target, headers: __sent_fields(req, t, body.len()), body: body, trailers: headers.header_map_new() });
  if (id == 0) {
    return Err(Io(net.ConnectionReset));
  }
  let a: Answer = __shared_wait(tr, req, started, sh, id)?;
  return __decoded(HttpResponse { status: a.status, body: BodyBytes(a.body), headers: a.headers, trailers: a.trailers, background: None }, req);
}
```

### `44 enum __SharedPick`

```fern
<<44 enum __SharedPick>>=
enum __SharedPick { OnLoop(i32), OnTask(__Conn) }
```

### `45 function __shared_socket[T: Transport](tr: T, req: Request, t: __Target, started: i64, key: string, guard: ...`

```fern
<<45 function __shared_socket[T: Transport](tr: T, req: Request, t: __Target, started: i64, key: string, guard: ...>>=
function __shared_socket[T: Transport](tr: T, req: Request, t: __Target, started: i64, key: string, guard: boolean, roots: Option[verify.Roots], sh: Shared): Result[__SharedPick, FetchError] {
  while (true) {
    if let Some(fd) = sh.pick(key) {
      return Ok(OnLoop(fd));
    }
    if (sh.dialing(key)) {
      match (__connect(tr, t, req, guard, roots)) {
        Ok(conn) => {
          let adopted: i32 = __shared_adopted(sh, key, conn, tr.now());
          sh.dialed(key);
          if (adopted < 0) {
            return Ok(OnTask(conn));
          }
          return Ok(OnLoop(adopted));
        },
        Err(e) => {
          sh.dialed(key);
          return Err(e);
        }
      }
    }
    let woke: Answer = __shared_wait(tr, req, started, sh, sh.await_connection(key))?;
  }
  return Err(Protocol("unreachable"));
}

function __shared_adopted(sh: Shared, key: string, conn: __Conn, now: Instant): i32 {
  match (conn.h2) {
    Some(hc) => {
      match (conn.tls) {
        Some(s) => {
          sh.adopt(key, conn.fd, s, hc, now);
          return conn.fd;
        },
        None => {
          return 0 - 1;
        }
      }
    },
    None => {
      return 0 - 1;
    }
  }
  return 0 - 1;
}

function __shared_wait[T: Transport](tr: T, req: Request, started: i64, sh: Shared, id: i32): Result[Answer, FetchError] {
  while (true) {
    let left_ms: i64 = req.timeouts.total.as_millis() - (time.instant_nanos(tr.now()) - started) / 1000000;
    let wait_ms: i64 = req.timeouts.inactivity.as_millis();
    let bound: Phase = Inactivity;
    if (left_ms < wait_ms) {
      wait_ms = left_ms;
      bound = Total;
    }
    if (wait_ms <= 0) {
      sh.abandon(id);
      return Err(Timeout(bound));
    }
    let woke: i32 = async.wait_any([id, MAIL_INTEREST], Some(time.duration_millis(wait_ms)));
    if (woke == async.cancelled()) {
      sh.abandon(id);
      return Err(FetchError.Cancelled);
    }
    if (woke != 0) {
      sh.abandon(id);
      return Err(Timeout(bound));
    }
    match (sh.take(id)) {
      Some(answer) => {
        return answer;
      },
      None => {}
    }
  }
  return Err(Protocol("unreachable"));
}

function __attempt_h1[T: Transport](tr: T, req: Request, t: __Target, started: i64, place: __Place, conn: __Conn): Result[HttpResponse, FetchError] {
  match (__send_all(tr, conn, __wire(req, t, req.body.bytes()))) {
    Ok(c) => {
      conn = c;
    },
    Err(e) => {
      tr.close(conn.fd);
      return Err(e);
    }
  }
  match (__read_response(tr, conn, req, started)) {
    Ok(read) => {
      if (read.keep) {
        __park(tr, place, read.conn);
      } else {
        __close(tr, read.conn);
      }
      return __decoded(read.response, req);
    },
    Err(e) => {
      tr.close(conn.fd);
      return Err(e);
    }
  }
  return Err(Protocol("unreachable"));
}

function __attempt_h2[T: Transport](tr: T, req: Request, t: __Target, started: i64, place: __Place, conn: __Conn, hc: h2.Conn): Result[HttpResponse, FetchError] {
  let body: u8[] = req.body.bytes();
  let (sent, stream) = hc.request(h2.Outgoing { method: req.method, scheme: "https", authority: t.host_field, path: t.target, headers: __sent_fields(req, t, body.len()), body: body, trailers: headers.header_map_new() });
  if (stream < 0) {
    tr.close(conn.fd);
    return Err(Io(net.ConnectionReset));
  }
  match (__h2_answered(tr, req, started, __H2Call { conn: conn, h2: sent.conn, out: sent.output }, stream)) {
    Ok(done) => {
      if (done.0.h2.closed() || done.0.h2.going_away()) {
        __close(tr, done.0.conn);
      } else {
        __park(tr, place, __Conn { ...done.0.conn, h2: Some(done.0.h2) });
      }
      return __decoded(HttpResponse { ...done.1, headers: http.http_end_to_end(done.1.headers) }, req);
    },
    Err(e) => {
      tr.close(conn.fd);
      return Err(e);
    }
  }
  return Err(Protocol("unreachable"));
}
```

### `46 struct __H2Call`

```fern
<<46 struct __H2Call>>=
struct __H2Call { conn: __Conn, h2: h2.Conn, out: u8[] }
```

### `47 function __h2_answered[T: Transport](tr: T, req: Request, started: i64, call: __H2Call, stream: i32): Resul...`

```fern
<<47 function __h2_answered[T: Transport](tr: T, req: Request, started: i64, call: __H2Call, stream: i32): Resul...>>=
function __h2_answered[T: Transport](tr: T, req: Request, started: i64, call: __H2Call, stream: i32): Result[(__H2Call, HttpResponse), FetchError] {
  while (true) {
    let conn: __Conn = __send_all(tr, call.conn, call.out)?;
    let got: __Got = __recv_bounded(tr, conn, req.timeouts, started, 65536)?;
    if (got.bytes.len() == 0) {
      return Err(__closed_early(0));
    }
    let step: h2.Step = call.h2.read(got.bytes);
    call = __H2Call { conn: got.conn, h2: step.conn, out: step.output };
    match (__h2_answer(step.events, stream)) {
      Some(answer) => {
        let resp: HttpResponse = answer?;
        return Ok((__H2Call { ...call, conn: __send_all(tr, call.conn, call.out)?, out: [] }, resp));
      },
      None => {}
    }
    if (call.h2.closed()) {
      return Err(Protocol("HTTP/2: the connection closed before the response ended"));
    }
  }
  return Err(Protocol("unreachable"));
}

function __h2_answer(events: h2.Event[], stream: i32): Option[Result[HttpResponse, FetchError]] {
  for e in events {
    match (e) {
      h2.Answered(sid, resp) => {
        if (sid == stream) {
          return Some(Ok(resp));
        }
      },
      h2.Reset(sid, code) => {
        if (sid == stream) {
          return Some(Err(Protocol("HTTP/2: the server reset the stream with code " + int.int_to_string(code))));
        }
      },
      h2.Closed(code, reason) => {
        return Some(Err(Protocol("HTTP/2: " + reason)));
      },
      _ => {}
    }
  }
  return None;
}
```

### `48 struct __Conn`

```fern
<<48 struct __Conn>>=
struct __Conn { fd: i32, tls: Option[client.Session], closed: boolean, h2: Option[h2.Conn] }
```

### `49 function __has_tls(conn: __Conn): boolean`

```fern
<<49 function __has_tls(conn: __Conn): boolean>>=
function __has_tls(conn: __Conn): boolean {
  match (conn.tls) {
    Some(_) => {
      return true;
    },
    None => {
      return false;
    }
  }
  return false;
}

function __no_conn(): __Conn {
  return __Conn { fd: 0 - 1, tls: None, closed: false, h2: None };
}

function __close[T: Transport](tr: T, conn: __Conn): void {
  if let Some(s) = conn.tls {
    if let Ok(step) = s.close() {
      __send_framed(tr, conn.fd, s, step.output);
    }
  }
  tr.close(conn.fd);
}

function __send_framed[T: Transport](tr: T, fd: i32, s: client.Session, output: u8[]): void {
  if (s.offloaded()) {
    ktls.send_records(tr.socket(fd), output);
  } else {
    tr.write(fd, output);
  }
}

function __connect[T: Transport](tr: T, t: __Target, req: Request, guard: boolean, roots: Option[verify.Roots]): Result[__Conn, FetchError] {
  let timeouts: Timeouts = req.timeouts;
  let begun: i64 = time.instant_nanos(tr.now());
  let addrs: net.IpAddr[] = __resolve(tr, t.host, guard)?;
  match (tr.connect(addrs, t.port, __connect_bound(timeouts))) {
    Ok(fd) => {
      if (!t.tls) {
        return Ok(__Conn { fd: fd, tls: None, closed: false, h2: None });
      }
      match (__secured(tr, fd, t, begun + __connect_bound(timeouts).as_nanos(), roots, req)) {
        Ok(s) => {
          if (s.alpn() != "h2") {
            return Ok(__Conn { fd: fd, tls: Some(s), closed: false, h2: None });
          }
          return __h2_opened(tr, fd, s);
        },
        Err(e) => {
          tr.close(fd);
          return Err(e);
        }
      }
    },
    Err(e) => {
      if (e.eq(net.TimedOut)) {
        return Err(Timeout(Connecting));
      }
      if (e.eq(net.Interrupted)) {
        return Err(FetchError.Cancelled);
      }
      return Err(Connect(e));
    }
  }
  return Err(Timeout(Connecting));
}

function __h2_opened[T: Transport](tr: T, fd: i32, s: client.Session): Result[__Conn, FetchError] {
  let start: h2.Step = h2.client(h2.config());
  match (__send_all(tr, __Conn { fd: fd, tls: Some(s), closed: false, h2: Some(start.conn) }, start.output)) {
    Ok(c) => {
      return Ok(c);
    },
    Err(e) => {
      tr.close(fd);
      return Err(e);
    }
  }
  return Err(Protocol("unreachable"));
}

function __secured[T: Transport](tr: T, fd: i32, t: __Target, deadline: i64, roots: Option[verify.Roots], req: Request): Result[client.Session, FetchError] {
  if (!t.direct) {
    __tunnel(tr, fd, t, deadline)?;
  }
  let s: client.Session = __tls_handshake(tr, fd, t.origin, deadline, roots)?;
  return __kernel_session(tr.socket(fd), s, req);
}

function __kernel_session(sock: i32, s: client.Session, req: Request): Result[client.Session, FetchError] {
  if (sock < 0 || !__ktls_asked(req)) {
    return Ok(s);
  }
  if let Some(o) = s.offload() {
    match (ktls.attach(sock, o.keys)) {
      ktls.Kernel => {
        return Ok(o.session);
      },
      ktls.Unchanged => {},
      ktls.Broken(code) => {
        return Err(Tls(tls.OffloadRefused(code)));
      }
    }
  }
  return Ok(s);
}

function __ktls_asked(req: Request): boolean {
  return req.ktls || envflag.on("FERN_KTLS");
}
```

### `50 enum __Record`

```fern
<<50 enum __Record>>=
enum __Record { RecordTaken(client.Step), RecordsEnded, RecordAwaited, RecordFailed(FetchError) }
```

### `51 function __kernel_record(sock: i32, s: client.Session, now: time.Timestamp): __Record`

```fern
<<51 function __kernel_record(sock: i32, s: client.Session, now: time.Timestamp): __Record>>=
function __kernel_record(sock: i32, s: client.Session, now: time.Timestamp): __Record {
  match (ktls.read_now(sock)) {
    ktls.Opened(t, content) => {
      match (s.read(ktls.framed(t, content), now)) {
        Ok(step) => {
          let sent: i32 = ktls.send_records(sock, step.output);
          if (sent < 0) {
            return RecordFailed(Io(net.error_from_host(sent)));
          }
          let installed: i32 = ktls.install(sock, step.rekeyed);
          if (installed < 0) {
            return RecordFailed(Tls(tls.KeysRefused(0 - installed)));
          }
          return RecordTaken(step);
        },
        Err(f) => {
          ktls.send_records(sock, f.alert);
          return RecordFailed(Tls(f.error));
        }
      }
    },
    ktls.StreamEnded => {
      return RecordsEnded;
    },
    ktls.ReadFailed(code) => {
      if (code == 74) {
        ktls.alert(sock, 20);
      }
      return RecordFailed(Tls(tls.KernelReadFailed(code)));
    },
    _ => {
      return RecordAwaited;
    }
  }
  return RecordAwaited;
}

function __tunnel[T: Transport](tr: T, fd: i32, t: __Target, deadline: i64): Result[void, FetchError] {
  let ask: string = "CONNECT " + t.authority + " HTTP/1.1\r\nHost: " + t.authority + "\r\n";
  if (t.proxy_auth.len() > 0) {
    ask = ask + "Proxy-Authorization: " + t.proxy_auth + "\r\n";
  }
  __write_all(tr, fd, (ask + "\r\n").bytes())?;
  let got: u8[] = [];
  while (__head_end(got) < 0) {
    if (got.len() > 16384) {
      return Err(Protocol("the proxy's answer to CONNECT is past the header budget"));
    }
    let wait_ms: i64 = (deadline - time.instant_nanos(tr.now())) / 1000000;
    if (wait_ms <= 0) {
      return Err(Timeout(Connecting));
    }
    got = __append_bytes(got, __tunnel_read(__io(tr.read(fd, 16384, time.duration_millis(wait_ms)))?)?);
  }
  if (__head_end(got) != got.len()) {
    return Err(Protocol("the proxy sent bytes after its answer to CONNECT"));
  }
  return __tunnel_status(string_from_bytes_unchecked(got));
}

function __io(r: Result[net.Recv, net.NetError]): Result[net.Recv, FetchError] {
  match (r) {
    Ok(got) => {
      return Ok(got);
    },
    Err(e) => {
      return Err(Io(e));
    }
  }
}

function __tunnel_read(got: net.Recv): Result[u8[], FetchError] {
  match (got) {
    Chunk(b) => {
      if (b.len() == 0) {
        return Err(Protocol("the proxy closed the connection instead of opening a tunnel"));
      }
      return Ok(b);
    },
    Elapsed => {
      return Err(Timeout(Connecting));
    },
    Abandoned => {
      return Err(FetchError.Cancelled);
    }
  }
  return Err(FetchError.Cancelled);
}

function __head_end(b: [u8]): i32 {
  let i: i32 = 3;
  while (i < b.len()) {
    if (b[i] == 10 && b[i - 1] == 13 && b[i - 2] == 10 && b[i - 3] == 13) {
      return i + 1;
    }
    i = i + 1;
  }
  return 0 - 1;
}

function __tunnel_status(head: string): Result[void, FetchError] {
  let line: string = head.split("\r\n")[0];
  let parts: string[] = line.split(" ");
  if (parts.len() < 2 || !parts[0].starts_with("HTTP/1.")) {
    return Err(Protocol("a malformed answer to CONNECT"));
  }
  if (!parts[1].starts_with("2") || parts[1].len() != 3) {
    return Err(Protocol("the proxy refused the tunnel with " + parts[1]));
  }
  return Ok(());
}

function __tls_handshake[T: Transport](tr: T, fd: i32, host: string, deadline: i64, given: Option[verify.Roots]): Result[client.Session, FetchError] {
  let roots: verify.Roots = __roots(given)?;
  let cfg: client.Config = client.config(__tls_name(host), roots).with_alpn(["h2", "http/1.1"]);
  let step: client.Step = __tls(client.start(cfg, tr.random_bytes(client.entropy(cfg)), tr.wall()))?;
  __write_all(tr, fd, step.output)?;
  let s: client.Session = step.session;
  while (!s.connected()) {
    let wait_ms: i64 = (deadline - time.instant_nanos(tr.now())) / 1000000;
    if (wait_ms <= 0) {
      return Err(Timeout(Connecting));
    }
    let input: u8[] = __handshake_read(tr.read(fd, 65536, time.duration_millis(wait_ms)))?;
    let next: client.Step = __tls_read(tr, fd, s, input)?;
    __write_all(tr, fd, next.output)?;
    s = next.session;
  }
  return Ok(s);
}
```

### `52 function __handshake_read(got: Result[net.Recv, net.NetError]): Result[u8[], FetchError]`

```fern
<<52 function __handshake_read(got: Result[net.Recv, net.NetError]): Result[u8[], FetchError]>>=
function __handshake_read(got: Result[net.Recv, net.NetError]): Result[u8[], FetchError] {
  match (__io(got)?) {
    Chunk(b) => {
      if (b.len() == 0) {
        return Err(Tls(tls.ClosedEarly));
      }
      return Ok(b);
    },
    Elapsed => {
      return Err(Timeout(Connecting));
    },
    Abandoned => {
      return Err(FetchError.Cancelled);
    }
  }
  return Err(Timeout(Connecting));
}

function __roots(given: Option[verify.Roots]): Result[verify.Roots, FetchError] {
  if let Some(r) = given {
    return Ok(r);
  }
  match (verify.system_roots()) {
    Some(r) => {
      return Ok(r);
    },
    None => {
      return Err(Tls(tls.NoRoots));
    }
  }
  return Err(Tls(tls.NoRoots));
}

function __tls_read[T: Transport](tr: T, fd: i32, s: client.Session, input: [u8]): Result[client.Step, FetchError] {
  match (s.read(input, tr.wall())) {
    Ok(step) => {
      return Ok(step);
    },
    Err(f) => {
      tr.write(fd, f.alert);
      return Err(Tls(f.error));
    }
  }
  return Err(Tls(tls.ClosedEarly));
}

function __tls[V](r: Result[V, tls.TlsError]): Result[V, FetchError] {
  match (r) {
    Ok(v) => {
      return Ok(v);
    },
    Err(e) => {
      return Err(Tls(e));
    }
  }
  return Err(Tls(tls.ClosedEarly));
}

function __tls_name(host: string): string {
  if (host.starts_with("[") && host.ends_with("]")) {
    return slice_unchecked(host, 1, host.len() - 1).to_owned();
  }
  return __host_name(host);
}

function __connect_bound(timeouts: Timeouts): Duration {
  if (timeouts.total.as_nanos() < timeouts.connect.as_nanos()) {
    return timeouts.total;
  }
  return timeouts.connect;
}

function __resolve[T: Transport](tr: T, host: string, guard: boolean): Result[net.IpAddr[], FetchError] {
  match (tr.lookup(host, guard)) {
    Ok(found) => {
      if (guard) {
        __global_only(found)?;
      }
      return Ok(found.dial);
    },
    Err(e) => {
      return Err(Dns(e));
    }
  }
  return Err(Dns(dns.NoData));
}

function __global_only(found: Lookup): Result[void, FetchError] {
  let i: i32 = 0;
  while (i < found.named.len()) {
    if (!found.judged[i].is_global()) {
      return Err(Blocked(found.named[i].to_string() + " is not a global address"));
    }
    i = i + 1;
  }
  return Ok(());
}

function __send_hosted(req: Request, t: __Target): Result[HttpResponse, FetchError] {
  let body: u8[] = req.body.bytes();
  let o: wasi_http.Outgoing = wasi_http.Outgoing { method: req.method, authority: t.host_field, tls: t.tls, target: t.target, headers: __sent_fields(req, t, body.len()), body: body, connect: __connect_bound(req.timeouts), inactivity: req.timeouts.inactivity, body_cap: req.limits.body };
  match (wasi_http.outgoing(o)) {
    Ok(resp) => {
      return __decoded(HttpResponse { ...resp, headers: http.http_end_to_end(resp.headers) }, req);
    },
    Err(e) => {
      return Err(__hosted_error(e));
    }
  }
  return Err(FetchError.Cancelled);
}

function __hosted_error(e: wasi_http.OutgoingError): FetchError {
  match (e) {
    Code(code) => {
      return __host_code(code);
    },
    Field(name) => {
      return InvalidRequest("a field the host refuses to carry: " + name);
    },
    BodyPastCap => {
      return BodyLimit;
    },
    CutShort => {
      return Protocol("the response ended before it was complete");
    },
    Lost => {
      return Protocol("the host gave no response");
    }
  }
  return FetchError.Cancelled;
}
```

### `53 function __host_code(code: wasi_http.ErrorCode): FetchError`

```fern
<<53 function __host_code(code: wasi_http.ErrorCode): FetchError>>=
function __host_code(code: wasi_http.ErrorCode): FetchError {
  match (code) {
    wasi_http.DnsTimeout => {
      return Dns(dns.NoReply);
    },
    wasi_http.DnsError => {
      return Dns(dns.ServerFailure);
    },
    wasi_http.DestinationNotFound => {
      return Dns(dns.NoSuchName);
    },
    wasi_http.DestinationUnavailable => {
      return Connect(net.HostUnreachable);
    },
    wasi_http.DestinationIpProhibited => {
      return Blocked("an address the host refuses to reach");
    },
    wasi_http.DestinationIpUnroutable => {
      return Connect(net.NetworkUnreachable);
    },
    _ => {
      return __host_connect_code(code);
    }
  }
  return Host(code);
}

function __host_connect_code(code: wasi_http.ErrorCode): FetchError {
  match (code) {
    wasi_http.ConnectionRefused => {
      return Connect(net.ConnectionRefused);
    },
    wasi_http.ConnectionTerminated => {
      return Io(net.ConnectionReset);
    },
    wasi_http.ConnectionTimeout => {
      return Timeout(Connecting);
    },
    wasi_http.ConnectionReadTimeout | wasi_http.ConnectionWriteTimeout => {
      return Timeout(Inactivity);
    },
    _ => {
      return __host_request_code(code);
    }
  }
  return Host(code);
}

function __host_request_code(code: wasi_http.ErrorCode): FetchError {
  match (code) {
    wasi_http.HttpRequestLengthRequired => {
      return InvalidRequest("the host requires a length");
    },
    wasi_http.HttpRequestBodySize => {
      return InvalidRequest("the body is larger than the host sends");
    },
    wasi_http.HttpRequestMethodInvalid => {
      return InvalidRequest("the method is not one the host sends");
    },
    wasi_http.HttpRequestUriInvalid | wasi_http.HttpRequestUriTooLong => {
      return InvalidUrl("not one the host sends");
    },
    wasi_http.HttpRequestHeaderSectionSize | wasi_http.HttpRequestHeaderSize | wasi_http.HttpRequestTrailerSectionSize | wasi_http.HttpRequestTrailerSize => {
      return InvalidRequest("the fields are larger than the host sends");
    },
    _ => {
      return __host_response_code(code);
    }
  }
  return Host(code);
}

function __host_response_code(code: wasi_http.ErrorCode): FetchError {
  match (code) {
    wasi_http.HttpResponseIncomplete => {
      return Protocol("the response ended before it was complete");
    },
    wasi_http.HttpResponseHeaderSectionSize | wasi_http.HttpResponseHeaderSize | wasi_http.HttpResponseTrailerSectionSize | wasi_http.HttpResponseTrailerSize => {
      return Protocol("the response fields are larger than the host reads");
    },
    wasi_http.HttpResponseBodySize => {
      return BodyLimit;
    },
    wasi_http.HttpResponseTransferCoding => {
      return Protocol("a transfer coding the host could not read");
    },
    wasi_http.HttpResponseContentCoding => {
      return Decode("a content coding the host could not undo");
    },
    _ => {
      return __host_late_code(code);
    }
  }
  return Host(code);
}

function __host_late_code(code: wasi_http.ErrorCode): FetchError {
  match (code) {
    wasi_http.HttpResponseTimeout => {
      return Timeout(Inactivity);
    },
    wasi_http.HttpUpgradeFailed => {
      return Protocol("the upgrade failed");
    },
    wasi_http.HttpProtocolError => {
      return Protocol("the host read a malformed response");
    },
    _ => {
      return Host(code);
    }
  }
  return Host(code);
}
```

### `54 struct __Read`

```fern
<<54 struct __Read>>=
struct __Read { response: HttpResponse, keep: boolean, conn: __Conn }
```

### `55 function __reusable(framed: http.HttpResponseFramed, from: i32, read: i32, eof: boolean): boolean`

```fern
<<55 function __reusable(framed: http.HttpResponseFramed, from: i32, read: i32, eof: boolean): boolean>>=
function __reusable(framed: http.HttpResponseFramed, from: i32, read: i32, eof: boolean): boolean {
  return framed.keep_alive && !eof && from + framed.len == read;
}

function __send_all[T: Transport](tr: T, conn: __Conn, payload: u8[]): Result[__Conn, FetchError] {
  if let Some(s) = conn.tls {
    if (s.offloaded()) {
      __write_all(tr, conn.fd, payload)?;
      return Ok(conn);
    }
    let step: client.Step = __tls(s.write(payload))?;
    __write_all(tr, conn.fd, step.output)?;
    return Ok(__Conn { ...conn, tls: Some(step.session) });
  }
  __write_all(tr, conn.fd, payload)?;
  return Ok(conn);
}

function __write_all[T: Transport](tr: T, conn: i32, payload: u8[]): Result[void, FetchError] {
  let at: i32 = 0;
  while (at < payload.len()) {
    let rest: u8[] = payload;
    if (at > 0) {
      let b: usize = buf_new(payload.len() - at);
      buf_push_bytes_range(b, payload, at, payload.len());
      rest = buf_take_bytes(b);
      buf_free(b);
    }
    let n: i32 = tr.write(conn, rest);
    if (n < 0) {
      return Err(Io(net.error_from_host(0 - n)));
    }
    if (n == 0) {
      return Err(Io(net.ConnectionReset));
    }
    at = at + n;
  }
  return Ok(());
}

function __read_response[T: Transport](tr: T, conn: __Conn, req: Request, started: i64): Result[__Read, FetchError] {
  let buf: u8[] = [];
  let from: i32 = 0;
  let eof: boolean = false;
  while (true) {
    match (http.http_parse_response_framed_from(buf, from, req.method, eof, req.limits)) {
      Complete(framed) => {
        let next: i32 = __after_interim(framed, from, req.limits)?;
        if (next < 0) {
          let response: HttpResponse = HttpResponse { ...framed.response, headers: http.http_end_to_end(framed.response.headers) };
          return Ok(__Read { response: response, keep: __reusable(framed, from, buf.len(), eof || conn.closed), conn: conn });
        }
        from = next;
        continue;
      },
      Unfinished => {
        if (eof) {
          return Err(__closed_early(buf.len() - from));
        }
      },
      Rejected(code) => {
        return Err(__rejected(code));
      }
    }
    let got: __Got = __recv_bounded(tr, conn, req.timeouts, started, __read_size(buf.len()))?;
    conn = got.conn;
    let chunk: u8[] = got.bytes;
    if (chunk.len() == 0) {
      eof = true;
    } else {
      buf = __append_bytes(buf, chunk);
    }
  }
  return Err(Protocol("unreachable"));
}

function __append_bytes(own buf: u8[], chunk: u8[]): u8[] {
  if (buf.len() == 0) {
    return chunk;
  }
  return buf.concat(chunk);
}

// The first read of a response asks for 8 KiB. A later read asks for what is held, up to 64 KiB.
function __read_size(held: i32): i32 {
  if (held < 8192) {
    return 8192;
  }
  if (held > 65536) {
    return 65536;
  }
  return held;
}

function __closed_early(got: i32): FetchError {
  if (got == 0) {
    return Io(net.ConnectionReset);
  }
  return Protocol("the connection closed before the response ended");
}

function __decoded(resp: HttpResponse, req: Request): Result[HttpResponse, FetchError] {
  let codings: string[] = __codings(resp.headers);
  let body: u8[] = resp.body_bytes();
  if (!__asks_codings(req) || codings.len() == 0 || body.len() == 0 || !__all_asked(codings)) {
    return Ok(resp);
  }
  if (codings.len() > req.decoding.depth) {
    return Err(Decode("content codings past the depth of " + int.int_to_string(req.decoding.depth)));
  }
  let encoded: i32 = body.len();
  let left: i32 = codings.len();
  while (left > 0) {
    left = left - 1;
    body = __undone(codings[left], body, req.limits.body)?;
  }
  let allowed: i64 = __allowed(encoded, req.decoding.ratio);
  if (body.len() as i64 > allowed) {
    return Err(Decode("a body of " + int.int_to_string(body.len()) + " bytes from " + int.int_to_string(encoded) + " encoded, past the " + int.int_to_string(allowed as i32) + " allowed"));
  }
  return Ok(HttpResponse { ...resp, body: BodyBytes(body), headers: __without(resp.headers, ["content-encoding", "content-length"]) });
}

function __allowed(encoded: i32, ratio: i32): i64 {
  let allowed: i64 = encoded as i64 * (ratio as i64);
  if (allowed < RATIO_FLOOR as i64) {
    return RATIO_FLOOR as i64;
  }
  return allowed;
}
```

### `56 function __codings(h: HeaderMap): string[]`

```fern
<<56 function __codings(h: HeaderMap): string[]>>=
function __codings(h: HeaderMap): string[] {
  let out: string[] = [];
  for v in h.get_all("content-encoding") {
    for c in v.split(",") {
      let name: string = c.trim().to_lower();
      if (name.len() > 0 && name != "identity") {
        out = out.append(name);
      }
    }
  }
  return out;
}

function __all_asked(codings: string[]): boolean {
  for c in codings {
    if (c != "gzip" && c != "x-gzip" && c != "zstd" && c != "br") {
      return false;
    }
  }
  return true;
}

function __undone(coding: string, body: u8[], max_out: i32): Result[u8[], FetchError] {
  if (coding == "zstd") {
    return __unzstd(body, max_out);
  }
  if (coding == "br") {
    return __unbrotli(body, max_out);
  }
  match (deflate.gunzip(body, max_out)) {
    Ok(out) => {
      return Ok(out);
    },
    Err(e) => {
      match (e) {
        deflate.OutputLimit => {
          return Err(BodyLimit);
        },
        _ => {
          return Err(Decode("a gzip body that does not decode: " + e.message()));
        }
      }
    }
  }
  return Ok(body);
}

function __unzstd(body: u8[], max_out: i32): Result[u8[], FetchError] {
  match (zstd.decompress(body, max_out)) {
    Ok(out) => {
      return Ok(out);
    },
    Err(e) => {
      match (e) {
        zstd.ZstdTooLarge => {
          return Err(BodyLimit);
        },
        _ => {
          return Err(Decode("a zstd body that does not decode: " + e.message()));
        }
      }
    }
  }
  return Ok(body);
}

function __unbrotli(body: u8[], max_out: i32): Result[u8[], FetchError] {
  match (brotli.decompress(body, max_out)) {
    Ok(out) => {
      return Ok(out);
    },
    Err(e) => {
      match (e) {
        brotli.BrotliTooLarge => {
          return Err(BodyLimit);
        },
        _ => {
          return Err(Decode("a br body that does not decode: " + e.message()));
        }
      }
    }
  }
  return Ok(body);
}

function __after_interim(framed: http.HttpResponseFramed, from: i32, limits: http.HttpLimits): Result[i32, FetchError] {
  if (framed.response.status == 101) {
    return Err(Protocol("a protocol switch the client did not ask for"));
  }
  if (!__interim(framed.response.status)) {
    return Ok(0 - 1);
  }
  let next: i32 = from + framed.len;
  if (next > limits.header_bytes) {
    return Err(Protocol("interim responses past the header budget"));
  }
  return Ok(next);
}

function __interim(status: i32): boolean {
  return status >= 100 && status < 200;
}
```

### `57 struct __Got`

```fern
<<57 struct __Got>>=
struct __Got { conn: __Conn, bytes: u8[] }
```

### `58 function __recv_bounded[T: Transport](tr: T, conn: __Conn, timeouts: Timeouts, started: i64, size: i32): Re...`

```fern
<<58 function __recv_bounded[T: Transport](tr: T, conn: __Conn, timeouts: Timeouts, started: i64, size: i32): Re...>>=
function __recv_bounded[T: Transport](tr: T, conn: __Conn, timeouts: Timeouts, started: i64, size: i32): Result[__Got, FetchError] {
  if (conn.closed) {
    return Ok(__Got { conn: conn, bytes: [] });
  }
  match (conn.tls) {
    Some(s) => {
      if (s.offloaded()) {
        return __recv_kernel(tr, conn, s, timeouts, started, size);
      }
      let session: client.Session = s;
      while (true) {
        let raw: u8[] = __recv_raw(tr, conn.fd, timeouts, started, size)?;
        if (raw.len() == 0) {
          if (session.held.len() > 0) {
            return Err(Tls(tls.RecordCut));
          }
          return Ok(__Got { conn: __Conn { ...conn, tls: Some(session) }, bytes: [] });
        }
        let step: client.Step = __tls_read(tr, conn.fd, session, raw)?;
        __write_all(tr, conn.fd, step.output)?;
        session = step.session;
        if (step.data.len() > 0 || step.closed) {
          return Ok(__Got { conn: __Conn { ...conn, tls: Some(session), closed: step.closed }, bytes: step.data });
        }
      }
    },
    None => {
      return Ok(__Got { conn: conn, bytes: __recv_raw(tr, conn.fd, timeouts, started, size)? });
    }
  }
  return Ok(__Got { conn: conn, bytes: [] });
}

function __recv_kernel[T: Transport](tr: T, conn: __Conn, s: client.Session, timeouts: Timeouts, started: i64, size: i32): Result[__Got, FetchError] {
  let session: client.Session = s;
  while (true) {
    let raw: u8[] = __recv_raw(tr, conn.fd, timeouts, started, size)?;
    if (raw.len() > 0) {
      return Ok(__Got { conn: __Conn { ...conn, tls: Some(session) }, bytes: raw });
    }
    match (__kernel_record(tr.socket(conn.fd), session, tr.wall())) {
      RecordTaken(step) => {
        session = step.session;
        if (step.closed) {
          return Ok(__Got { conn: __Conn { ...conn, tls: Some(session), closed: true }, bytes: [] });
        }
      },
      RecordsEnded => {
        return Ok(__Got { conn: __Conn { ...conn, tls: Some(session) }, bytes: [] });
      },
      RecordAwaited => {},
      RecordFailed(e) => {
        return Err(e);
      }
    }
  }
  return Ok(__Got { conn: conn, bytes: [] });
}

function __recv_raw[T: Transport](tr: T, conn: i32, timeouts: Timeouts, started: i64, size: i32): Result[u8[], FetchError] {
  let ns_per_ms: i64 = 1000000;
  let left_ms: i64 = timeouts.total.as_millis() - (time.instant_nanos(tr.now()) - started) / ns_per_ms;
  if (left_ms <= 0) {
    return Err(Timeout(Total));
  }
  let wait_ms: i64 = timeouts.inactivity.as_millis();
  let bound: Phase = Inactivity;
  if (left_ms < wait_ms) {
    wait_ms = left_ms;
    bound = Total;
  }
  match (__io(tr.read(conn, size, time.duration_millis(wait_ms)))?) {
    Chunk(chunk) => {
      return Ok(chunk);
    },
    Elapsed => {
      return Err(Timeout(bound));
    },
    Abandoned => {
      return Err(FetchError.Cancelled);
    }
  }
  return Err(Timeout(bound));
}

function __rejected(code: i32): FetchError {
  if (code == 413) {
    return BodyLimit;
  }
  if (code == 431) {
    return Protocol("the header block or chunk framing is past its limit");
  }
  if (code == 501) {
    return Protocol("a transfer coding other than chunked");
  }
  if (code == 505) {
    return Protocol("an HTTP version other than 1");
  }
  return Protocol("a malformed response");
}
```

### `59 pub struct ProxyEnv`

```fern
<<59 pub struct ProxyEnv>>=
pub struct ProxyEnv { http_proxy: string, https_proxy: string, no_proxy: string, rules: __Rule[], http: Option[__Proxy], https: Option[__Proxy] }
```

### `60 pub function proxies(http_proxy: string, https_proxy: string, no_proxy: string): ProxyEnv`

```fern
<<60 pub function proxies(http_proxy: string, https_proxy: string, no_proxy: string): ProxyEnv>>=
pub function proxies(http_proxy: string, https_proxy: string, no_proxy: string): ProxyEnv {
  return ProxyEnv { http_proxy: http_proxy, https_proxy: https_proxy, no_proxy: no_proxy, rules: __rules_of(no_proxy), http: __proxy_read(http_proxy), https: __proxy_read(https_proxy) };
}

pub function proxy_env(): ProxyEnv {
  return proxy_env_from(config_get("http_proxy"), config_get("https_proxy"), config_get("HTTPS_PROXY"), config_get("no_proxy"), config_get("NO_PROXY"), config_get("REQUEST_METHOD"));
}

pub function proxy_env_from(http_proxy: Option[string], https_proxy: Option[string], https_proxy_upper: Option[string], no_proxy: Option[string], no_proxy_upper: Option[string], request_method: Option[string]): ProxyEnv {
  let skip: string = __or_empty(__either(no_proxy, no_proxy_upper));
  match (request_method) {
    Some(m) => {
      return proxies("", "", skip);
    },
    None => {}
  }
  return proxies(__or_empty(http_proxy), __or_empty(__either(https_proxy, https_proxy_upper)), skip);
}
```

### `61 function __either(first: Option[string], second: Option[string]): Option[string]`

```fern
<<61 function __either(first: Option[string], second: Option[string]): Option[string]>>=
function __either(first: Option[string], second: Option[string]): Option[string] {
  match (first) {
    Some(v) => {
      return Some(v);
    },
    None => {
      return second;
    }
  }
  return second;
}

function __or_empty(v: Option[string]): string {
  match (v) {
    Some(s) => {
      return s;
    },
    None => {
      return "";
    }
  }
  return "";
}
```

### `62 pub function (p: ProxyEnv) proxy_for(target_url: string): Option[string]`

```fern
<<62 pub function (p: ProxyEnv) proxy_for(target_url: string): Option[string]>>=
pub function (p: ProxyEnv) proxy_for(target_url: string): Option[string] {
  match (url.url_parse(target_url)) {
    Ok(u) => {
      return __proxy_for_url(p, u);
    },
    Err(_) => {
      return None;
    }
  }
  return None;
}
```

### `63 function __proxy_for_url(p: ProxyEnv, u: Url): Option[string]`

```fern
<<63 function __proxy_for_url(p: ProxyEnv, u: Url): Option[string]>>=
function __proxy_for_url(p: ProxyEnv, u: Url): Option[string] {
  let proxy: string = p.http_proxy;
  if (u.scheme == "https") {
    proxy = p.https_proxy;
  }
  if (proxy.len() == 0) {
    return None;
  }
  let host: string = __host_name(u.host);
  let ip: Option[net.IpAddr] = None;
  if (__address_shaped(host)) {
    ip = __canonical_ip(host);
  }
  if (__never_proxied(host, ip)) {
    return None;
  }
  let port: i32 = __effective_port(u);
  for rule in p.rules {
    if (__no_proxy_matches(rule, host, port, ip)) {
      return None;
    }
  }
  return Some(proxy);
}

function __address_shaped(host: string): boolean {
  if (host.len() == 0) {
    return false;
  }
  let b: u8 = host[0];
  return b >= 48 as u8 && b <= 57 as u8 || host.contains(":");
}

function __never_proxied(host: string, ip: Option[net.IpAddr]): boolean {
  if (host == "localhost" || host.ends_with(".localhost")) {
    return true;
  }
  match (ip) {
    Some(a) => {
      return a.is_loopback();
    },
    None => {
      return false;
    }
  }
  return false;
}

function __host_name(h: string): string {
  let end: i32 = h.len();
  if (end > 1 && h[end - 1] == 46 as u8) {
    end = end - 1;
  }
  let i: i32 = 0;
  while (i < end && (h[i] < 65 as u8 || h[i] > 90 as u8)) {
    i = i + 1;
  }
  if (i == end && end == h.len()) {
    return h;
  }
  return slice_unchecked(h, 0, end).to_owned().to_lower();
}

function __canonical_ip(text: string): Option[net.IpAddr] {
  match (net.ip_parse(text)) {
    Some(a) => {
      return Some(a.to_canonical());
    },
    None => {
      return None;
    }
  }
  return None;
}
```

### `64 struct __Rule`

```fern
<<64 struct __Rule>>=
struct __Rule { what: __Match, port: i32 }

enum __Match { Every, Named(string), Under(string), Addr(net.IpAddr), Block(u8[], i32), Nothing }
```

### `65 function __rules_of(no_proxy: string): __Rule[]`

```fern
<<65 function __rules_of(no_proxy: string): __Rule[]>>=
function __rules_of(no_proxy: string): __Rule[] {
  let out: __Rule[] = [];
  if (no_proxy.len() == 0) {
    return out;
  }
  for entry in no_proxy.split(",") {
    let e: string = entry.trim();
    if (e.len() > 0) {
      out = out.append(__rule_of(e));
    }
  }
  return out;
}

function __rule_of(entry: string): __Rule {
  if (entry == "*") {
    return __Rule { what: Every, port: 0 };
  }
  let split: (string, i32) = __entry_split(entry);
  let name: string = __host_name(split.0);
  if (name.contains("/")) {
    return __Rule { what: __block_of(name), port: split.1 };
  }
  match (__canonical_ip(name)) {
    Some(a) => {
      return __Rule { what: Addr(a), port: split.1 };
    },
    None => {}
  }
  if (name.starts_with(".")) {
    return __Rule { what: Under(name), port: split.1 };
  }
  return __Rule { what: Named(name), port: split.1 };
}

function __block_of(block: string): __Match {
  let Some(slash) = block.index_of("/") else {
    return Nothing;
  };
  let bits: i32 = -1;
  match (i32.parse_i32_radix(slice_unchecked(block, slash + 1, block.len()).to_owned(), 10)) {
    Ok(n) => {
      bits = n;
    },
    Err(_) => {}
  }
  match (__canonical_ip(slice_unchecked(block, 0, slash).to_owned())) {
    Some(p) => {
      let pb: u8[] = p.bytes();
      if (bits < 0 || bits > pb.len() * 8) {
        return Nothing;
      }
      return Block(pb, bits);
    },
    None => {
      return Nothing;
    }
  }
  return Nothing;
}

function __no_proxy_matches(rule: __Rule, host: string, port: i32, ip: Option[net.IpAddr]): boolean {
  if (rule.port != 0 && rule.port != port) {
    return false;
  }
  match (rule.what) {
    Every => {
      return true;
    },
    Named(name) => {
      return host == name || __under(host, name);
    },
    Under(suffix) => {
      return host.ends_with(suffix);
    },
    Addr(a) => {
      return __same_ip(ip, a);
    },
    Block(prefix, bits) => {
      return __in_block(ip, prefix, bits);
    },
    Nothing => {
      return false;
    }
  }
  return false;
}

function __under(host: string, name: string): boolean {
  let at: i32 = host.len() - name.len() - 1;
  return at >= 0 && host[at] == 46 as u8 && host.ends_with(name);
}

function __entry_split(entry: string): (string, i32) {
  let name: string = entry;
  let rest: string = "";
  if (entry.starts_with("[")) {
    let Some(close) = entry.index_of("]") else {
      return (entry, -1);
    };
    name = slice_unchecked(entry, 1, close).to_owned();
    rest = slice_unchecked(entry, close + 1, entry.len()).to_owned();
  } else {
    if let Some(colon) = entry.index_of(":") {
      if let Some(last) = entry.last_index_of(":") {
        if (colon == last) {
          name = slice_unchecked(entry, 0, colon).to_owned();
          rest = slice_unchecked(entry, colon, entry.len()).to_owned();
        }
      }
    }
  }
  return (__without_zone(name), __rule_port(rest));
}

function __without_zone(name: string): string {
  let Some(zone) = name.index_of("%") else {
    return name;
  };
  let after: string = slice_unchecked(name, zone, name.len()).to_owned();
  let Some(slash) = after.index_of("/") else {
    return slice_unchecked(name, 0, zone).to_owned();
  };
  return slice_unchecked(name, 0, zone).to_owned() + slice_unchecked(after, slash, after.len()).to_owned();
}
```

### `66 function __rule_port(rest: string): i32`

```fern
<<66 function __rule_port(rest: string): i32>>=
function __rule_port(rest: string): i32 {
  if (rest.len() == 0) {
    return 0;
  }
  if (!rest.starts_with(":")) {
    return -1;
  }
  match (i32.parse_i32_radix(slice_unchecked(rest, 1, rest.len()).to_owned(), 10)) {
    Ok(n) => {
      if (n > 0 && n < 65536) {
        return n;
      }
      return -1;
    },
    Err(_) => {
      return -1;
    }
  }
  return -1;
}

function __same_ip(ip: Option[net.IpAddr], a: net.IpAddr): boolean {
  match (ip) {
    Some(h) => {
      return h.eq(a);
    },
    None => {
      return false;
    }
  }
  return false;
}

function __in_block(ip: Option[net.IpAddr], prefix: u8[], bits: i32): boolean {
  match (ip) {
    Some(a) => {
      return __prefix_matches(a.bytes(), prefix, bits);
    },
    None => {
      return false;
    }
  }
  return false;
}

function __prefix_matches(ab: u8[], pb: u8[], bits: i32): boolean {
  if (ab.len() != pb.len()) {
    return false;
  }
  let i: i32 = 0;
  while (i * 8 + 8 <= bits) {
    if (ab[i] != pb[i]) {
      return false;
    }
    i = i + 1;
  }
  let rem: i32 = bits - i * 8;
  if (rem == 0) {
    return true;
  }
  let mask: i32 = 255 << 8 - rem & 255;
  return (ab[i] as i32 & mask) == (pb[i] as i32 & mask);
}
```

### `67 struct __Proxy`

```fern
<<67 struct __Proxy>>=
struct __Proxy { host: string, port: i32, auth: string }
```

### `68 function __proxy_of(spec: string, name: string): Result[__Proxy, FetchError]`

```fern
<<68 function __proxy_of(spec: string, name: string): Result[__Proxy, FetchError]>>=
function __proxy_of(spec: string, name: string): Result[__Proxy, FetchError] {
  let full: string = spec;
  if (!full.contains("://")) {
    full = "http://" + full;
  }
  let u: Url = Url { scheme: "", host: "", port: 0, path: "", query: "", fragment: "" };
  match (url.url_parse(full)) {
    Ok(parsed) => {
      u = parsed;
    },
    Err(_) => {
      return Err(InvalidUrl(name + " is not a URL"));
    }
  }
  if (u.scheme != "http" || u.host.len() == 0) {
    return Err(InvalidUrl(name + " is not an http URL with a host"));
  }
  let port: i32 = u.port;
  if (port == 0) {
    port = 80;
  }
  return Ok(__Proxy { host: u.host, port: port, auth: __proxy_auth(full) });
}

function __proxy_read(spec: string): Option[__Proxy] {
  if (spec.len() == 0) {
    return None;
  }
  match (__proxy_of(spec, "")) {
    Ok(p) => {
      return Some(p);
    },
    Err(e) => {
      return None;
    }
  }
  return None;
}

function __proxy_named(p: ProxyEnv, spec: string, tls: boolean): Result[__Proxy, FetchError] {
  let read: Option[__Proxy] = p.http;
  let name: string = "http_proxy";
  if (tls) {
    read = p.https;
    name = "https_proxy";
  }
  match (read) {
    Some(proxy) => {
      return Ok(proxy);
    },
    None => {
      return __proxy_of(spec, name);
    }
  }
  return __proxy_of(spec, name);
}

function __proxy_auth(full: string): string {
  let Some(scheme) = full.index_of("://") else {
    return "";
  };
  let start: i32 = scheme + 3;
  let end: i32 = full.len();
  if let Some(slash) = slice_unchecked(full, start, end).to_owned().index_of("/") {
    end = start + slash;
  }
  let authority: string = slice_unchecked(full, start, end).to_owned();
  let Some(at) = authority.last_index_of("@") else {
    return "";
  };
  let userinfo: string = slice_unchecked(authority, 0, at).to_owned();
  if (!userinfo.contains(":")) {
    userinfo = userinfo + ":";
  }
  return "Basic " + base64.encode(userinfo.bytes());
}
```
