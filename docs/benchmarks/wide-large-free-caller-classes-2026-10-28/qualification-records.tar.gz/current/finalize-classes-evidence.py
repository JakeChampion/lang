from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile,io,time
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-integration');folder=Path('/tmp/image-wide-integration-evidence-secondary');source=(folder/'source-sha.txt').read_text().strip();git=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest();assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
for name in ['current-build','final-Go','final-gates']:
 j=json.loads((folder/(name+'.json')).read_text());assert j['source']==source and j['sources_unchanged']
 if name=='current-build':assert j['make_exit']==j['version_exit']==0 and j['worktree_clean']
 else:assert all(c['exit']==c['FAIL']==c['SKIP']==0 for c in j['checks'])and j['worktree_still_clean']and j['binaries_unchanged']
targets=['x86-64-linux','wasm32-wasi','arm64-linux'];rows=[json.loads((folder/('final-corpus-'+t+'.json')).read_text())for t in targets]
assert all(r['source']==source and r['qualified']and r['sources_unchanged']and r['compiler_unchanged']and not r['feature_uncommitted']and len(r['records'])==1566 and len(r['workers'])==196 for r in rows)
assert all(r['records']==rows[0]['records']for r in rows)
tools=json.loads((folder/'final-current-tool-identities-before.json').read_text())
for item in tools['tools'].values():assert sha(Path(item['selected_path']).read_bytes())==item['sha256']
tools['observed_after_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());tools['all_before_hashes_unchanged']=True
(folder/'final-current-tool-identities-after.json').write_text(json.dumps(tools,indent=2)+'\n')
base=root/'docs/benchmarks/wide-large-free-caller-classes-2026-10-28';assert not base.exists();relative=str(base.relative_to(root));assert subprocess.run(['git','cat-file','-e','HEAD:'+relative],cwd=root,stderr=subprocess.DEVNULL).returncode!=0 and not git('ls-files','--',relative);base.mkdir(parents=True);manifest=[];omitted=[]
def publish(origin,data,name,original_sha=None,members=None):
 path=base/name;assert not path.exists();path.write_bytes(data);item=dict(original=str(origin),published=name,original_sha256=original_sha,published_sha256=sha(data),published_bytes=len(data));manifest.append(item)
 if members is not None:item['member_count']=members
for target in targets:
 p=folder/('final-corpus-'+target+'.json');raw=p.read_bytes();publish(p,gzip.compress(raw,mtime=0),'large-free-wide-classes-'+target+'.json.gz',sha(raw))
payload=io.BytesIO();count=0
with tarfile.open(fileobj=payload,mode='w')as tar:
 for p in sorted(folder.rglob('*')):
  if not p.is_file()or p.is_symlink():continue
  rel=p.relative_to(folder)
  if any((folder/Path(*rel.parts[:i])).is_symlink()for i in range(1,len(rel.parts))):continue
  if p.name in ['final-corpus-'+t+'.json'for t in targets]:continue
  raw=p.read_bytes()
  source_copy=rel.parts[0].startswith('private-')and len(rel.parts)>1 and rel.parts[1]=='compiler'and p.name!='ssalargefreewideclasses.fern'
  if raw.startswith(b'\x7fELF')or p.suffix in ['.elf','.wasm','.wat']or source_copy:
   omitted.append(dict(path=str(p),bytes=len(raw),sha256=sha(raw),kind='unchanged private source copy'if source_copy else'executable'));continue
  info=tarfile.TarInfo('current/'+str(rel));info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw));count+=1
publish('Complete qualification logs, inputs, private overrides, failures, and corrections',gzip.compress(payload.getvalue(),mtime=0),'qualification-records.tar.gz',members=count)
(base/'omitted-file-identities.json').write_text(json.dumps(omitted,indent=2)+'\n')
build=json.loads((folder/'current-build.json').read_text());gates=json.loads((folder/'final-gates.json').read_text());go=json.loads((folder/'final-Go.json').read_text());equal=json.loads((folder/'final-record-equality.json').read_text());assert gates['Fern_format_files']==2109
modified=git('diff','--name-only','--diff-filter=MDR','7aded8a6ca65677ee5b01db9dfe7ad95d3d50ebb','HEAD').splitlines();assert modified==['Makefile']
assert build['binaries']['bin/fern-selfhost']=='db42054a760c888b803ac61d1cdc625c79add769062463cb50878ce50097c544'
refpath=root/'internal/testing/e2ecompiler/testdata/large_free_wide_classes.json.gz';ref=json.loads(gzip.decompress(refpath.read_bytes()))
evidence=dict(source=source,PR=13752,native_issue=13750,source_commit_precedes_final_campaigns=True,reference_uncompressed_sha256=sha(gzip.decompress(refpath.read_bytes())),reference_gzip_sha256=sha(refpath.read_bytes()),case_count_per_target=1566,workers_per_target=196,total_workers=588,records_exactly_equal=True,all_workers_nonzero_balanced_zero_live=True,partition_counts=dict(old=[54,87,87],current=[70,103,103]),legacy_source_hashes=ref['legacy_sources'],build={k:v for k,v in build.items()if k!='source_hashes'},checks=[{k:v for k,v in c.items()if k!='command'}for c in gates['checks']],Go_oracle_actual_build=go['oracle_actual_build'],Go_oracle_postrun_sha256=go['oracle_sha256'],tools_sampled_before_final_campaigns_and_after=True,sourcegate_node_count_unclaimed=True,initial_source='7aded8a6ca65677ee5b01db9dfe7ad95d3d50ebb + UNCOMMITTED',old_models_and_domains_unchanged=True,retained_driver_integration=False,machine_call_summary_integration=False,full_CI_recovery=False,M5_epic_gates='OPEN',manifest=manifest)
(base/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
text=(root/'docs/rc-log/2026-10-28-wide-caller-classes.md').read_text()+'''\n## Final qualification\n
The final campaigns use source `'''+source+'''`.
The clean standard compiler build passed make, version, and smoke checks in '''+format(build['seconds'],'.3f')+''' seconds with pin 919.
The raw compiler matches the prior qualified production compiler byte for byte.
The CLI records its actual source version.

All three targets completed the same 1566 cases with exact integer results.
All 588 fresh workers exited successfully with nonzero balanced censuses and zero live bytes.
Every result matches exactly across native, Wasm, and ARM64.
All 3849 campaign source hashes and all compiler and worker binary hashes remained unchanged.
The tool snapshots precede the final campaigns and confirm unchanged bytes after all checks.

Final stock driver and packet checks passed 29 nodes, and unchanged complexity checks passed three nodes, with zero skips.
The source gate passed all five runtime sets, fixture checks, compiler modules, standard library modules, and all 84 standalone drivers.
The nonverbose source-gate command does not establish a separate test-node count.
Format covered 2109 inputs.
Build, vet, workflow lint, test names, CI self-tests, and all 219 source-audit nodes passed.
A fresh Go oracle from the qualified source passed check and interpreter commands.

The fixed reference reproduced exactly, and all eight collector self-tests passed.
The three private faults compiled and ran normally with nonzero balanced zero-live censuses.
The strict collector rejected the old ceiling at 4 GiB, the missing first partition, and the incorrect fused offset.
The real collector preserved 40 completed records, its checkpoint, and the failed batch output.
A second attempt rejected existing output without changes.

The first independent grid construction added an incorrect cut at 256.
Its assertion stopped before reference output or Fern execution.
The correction preserves the original interval from one through 256.
The generator also reproduces the canonical source format without a numeric change.
An initial formatter command lacked the secondary cache exports and failed before format work.
A later build setup command found an existing pin directory and stopped before the build.

The archive preserves those setup failures, original scripts, corrections, provisional results, and the published policy.
The local policy draft received a formula clarification before publication.
The fresh stock retained-machine command still fails with exit 166.
The source-pinned diagnostic confirms the admitted 4 GiB counterexample and the distinct fused and separate grid endpoints.
Its 1310 allocations balanced with zero live bytes.
The early-exit stock census alone does not establish a persistent compiler leak.

`evidence.json` binds the archive hashes and qualification facts.
The compressed target records preserve their exact original bytes.
Executables and unchanged private source copies remain at their original paths with identities in `omitted-file-identities.json`.
All old models, interfaces, domains, assertions, production instructions, baselines, and thresholds remain unchanged.

The raw production compiler is unchanged, so this scope does not repeat the separate image corpus from PR #13734.
Retained-driver integration and machine call summaries require later work after this merge.
Full recovery, native milestones, actual CI recovery, M5, and epic acceptance remain open.
'''
(base/'README.md').write_text(text)
(folder/'finalization-record.json').write_text(json.dumps(dict(source=source,destination=str(base),archive_members=count,published_bytes=sum(p.stat().st_size for p in base.iterdir())),indent=2)+'\n');print('Prepared',base,count,'archive members')
