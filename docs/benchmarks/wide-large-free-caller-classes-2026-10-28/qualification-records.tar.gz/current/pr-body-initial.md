Closes #13750.

The old caller classification treats admitted 4 GiB allocations as oversized.
The current helper uses class 52 for those allocations.
This change adds standalone current classification and partition adapters across the original caller domains.
All old models, APIs, assertions, production instructions, baselines, and thresholds remain unchanged.
Retained-driver integration and machine call summaries remain separate.

The independent catalog contains 1566 exact integer cases with explicit old results.
The refined grids contain 70 array rows and 103 rows for each string form.
They preserve every original boundary and residue range.

Initial Go check and interpreter runs passed.
The stock driver passed on native, Wasm, and ARM64 with strict sanitizer and leak checks.
All 1566 provisional native worker cases passed across 196 fresh workers with nonzero balanced zero-live censuses.
The worker protocol passed on all three targets.
Three private faults compiled and ran, but the collector rejected their incorrect records.
The full collector preserved 40 completed records before its failing batch and rejected an output overwrite.

Source commit: 7872a0970739ed6cfc100b48750f1bfb5716a4bb.
A clean standard compiler build is in progress with pin 9193717cfa8ddce4927761cc5ff5d47faf29b473.
Final immutable corpus, source, runtime, audit, format, and complexity qualification remains in progress.
No pending CI result counts as a pass.
Full recovery, M5, and epic acceptance remain open.

