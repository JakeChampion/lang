#!/usr/bin/env python3
import os,sys
a=sys.argv[1:];a[-1]='/tmp/image-wide-integration-evidence-secondary/private-old-ceiling/compiler/drivers/ssalargefreewideclasses_worker.fern'
os.execv('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-proof/bin/fern',['/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-proof/bin/fern']+a)
