from pathlib import Path
import subprocess,json,time,hashlib,sys,os
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-integration');folder=Path('/tmp/image-wide-integration-evidence-secondary');mode=sys.argv[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','compiler','internal','scripts','Makefile'],cwd=root,text=True).splitlines();before={p:sha(root/p)for p in paths if(root/p).is_file()}
commands={'Go':[['/tmp/image-wide-machine-proof-evidence-secondary/fern-oracle-12129f769f','-check','compiler/drivers/ssalargefreewideclasses_run.fern'],['/tmp/image-wide-machine-proof-evidence-secondary/fern-oracle-12129f769f','-interp','compiler/drivers/ssalargefreewideclasses_run.fern']],'targets':[['go','test','-v','./internal/testing/e2ecompiler','-run','^TestSelfHostLargeFreeWideClasses$','-count=1','-timeout=15m']]}
prefix=folder/('initial-'+mode);assert not prefix.with_suffix('.json').exists();record=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),feature_uncommitted=True,checks=[],source_hashes=before);start=time.time()
for at,cmd in enumerate(commands[mode]):
 log=folder/('initial-'+mode+'-'+str(at)+'.log');assert not log.exists();t=time.time()
 with log.open('w')as out:p=subprocess.run(cmd,cwd=root,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,GOFLAGS=''))
 record['checks'].append(dict(command=cmd,exit=p.returncode,seconds=time.time()-t));prefix.with_suffix('.checkpoint.json').write_text(json.dumps(record,indent=2)+'\n');print(record['checks'][-1],flush=True)
 if p.returncode:break
record.update(seconds=time.time()-start,sources_unchanged=before=={p:sha(root/p)for p in before});prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n');assert all(c['exit']==0 for c in record['checks'])and len(record['checks'])==len(commands[mode])and record['sources_unchanged']
