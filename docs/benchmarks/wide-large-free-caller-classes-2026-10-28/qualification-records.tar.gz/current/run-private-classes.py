from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess,time,argparse
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-integration');folder=Path('/tmp/image-wide-integration-evidence-secondary')
spec=importlib.util.spec_from_file_location('collector',root/'scripts/qualify_large_free_wide_classes.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not(folder/'private-controls.json').exists();before=c.inventory();compiler=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-proof/bin/fern');ch=sha(compiler);env=dict(os.environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1');source=(root/'compiler/ssalargefreewideclasses.fern').read_text();cases=c.GEN.catalog()['cases'];records=[];start=time.time()
faults=[('old-ceiling','  for at in 0..bins.len() {','  for at in 0..45 {',next(x for x in cases if x['input']==[0,536870909,536870909,0,7])),('missing-partition','    result = result.append(array.Interval { low: low, high: old.high });','    if (old.low != 65533 as i64) { result = result.append(array.Interval { low: low, high: old.high }); }',next(x for x in cases if x['name']=='0-grid-0')),('swapped-fused-offset','let extra = if (fused) { 3 as i64 } else { 0 as i64 };','let extra = if (!fused) { 3 as i64 } else { 0 as i64 };',next(x for x in cases if x['name']=='2-boundary-0-0'))]
for name,old,new,case in faults:
 work=folder/('private-'+name);assert not work.exists();work.mkdir();shutil.copytree(root/'compiler',work/'compiler');assert old in source
 private=source.replace(old,new,1);(work/'compiler/ssalargefreewideclasses.fern').write_text(private)
 binary=work/'worker.elf';cmd=[str(compiler),'-target','x86-64-linux','-sanitize','-o',str(binary),str(work/'compiler/drivers/ssalargefreewideclasses_worker.fern')]
 with(work/'compile.log').open('w')as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record=dict(name=name,case_id=case['id'],case_name=case['name'],compile_exit=p.returncode,command=cmd,source_sha256=sha(work/'compiler/ssalargefreewideclasses.fern'));records.append(record);assert p.returncode==0
 bh=sha(binary);p=subprocess.run([str(binary)],input=c.GEN.packet(case),capture_output=True,env=env);(work/'stdout.log').write_bytes(p.stdout);(work/'stderr.log').write_bytes(p.stderr);record.update(runtime_exit=p.returncode,binary_sha256_before=bh,binary_sha256_after=sha(binary));assert p.returncode==0 and bh==sha(binary)
 # The same strict collector validates the actual census and complete wrong record.
 fields=p.stdout.decode().splitlines()[0].split();actual=[int(n)for n in fields[2:]];assert fields[:2]==['class',str(case['id'])]and len(actual)==6 and actual!=case['expected']
 witness=dict(case,expected=actual);c.check_output(p.stdout.decode(),p.stderr.decode(),[witness],p.returncode)
 try:c.check_output(p.stdout.decode(),p.stderr.decode(),[case],p.returncode)
 except ValueError as e:record.update(rejected=True,reason=str(e),actual=actual,expected=case['expected'])
 else:raise AssertionError('collector accepted private fault')
 if name=='old-ceiling':
  wrapper=work/'compiler-wrapper.py';wrapper.write_text('#!/usr/bin/env python3\nimport os,sys\na=sys.argv[1:];a[-1]='+repr(str(work/'compiler/drivers/ssalargefreewideclasses_worker.fern'))+'\nos.execv('+repr(str(compiler))+',['+repr(str(compiler))+']+a)\n');wrapper.chmod(0o755)
  options=argparse.Namespace(output=str(work/'full-collector.json'),work=str(work/'full-worker'),source_commit='7aded8a6ca65677ee5b01db9dfe7ad95d3d50ebb',allow_dirty=True,reference=str(c.GEN.REFERENCE),compiler=str(wrapper),target='x86-64-linux')
  try:c.run(options)
  except ValueError as e:
   j=json.loads(Path(options.output).read_text());assert not j['qualified']and len(j['records'])==40 and len(j['workers'])==6 and 'exact class or grid mismatch' in str(e)
   assert j['records']==[dict(id=x['id'],values=x['expected'])for x in cases[:40]]
   assert Path(options.output+'.checkpoint').exists()and(work/'full-worker/worker-00040.stdout.log').exists()
   oldbytes=Path(options.output).read_bytes()
   try:c.run(options)
   except ValueError as again:assert 'refuse existing' in str(again)and Path(options.output).read_bytes()==oldbytes
   else:raise AssertionError('existing output accepted')
   record.update(full_collector_rejected=True,preserved_complete_prefix=40,failed_worker_stdout=True,output_existing_rejected=True)
  else:raise AssertionError('full collector accepted private fault')
record=dict(compiler_actual_build='12129f769fa75a9327892e6535dbef12f7b51a27',compiler_sha256=ch,compiler_unchanged=ch==sha(compiler),source_hashes=before,sources_unchanged=before==c.inventory(),controls=records,seconds=time.time()-start)
(folder/'private-controls.json').write_text(json.dumps(record,indent=2)+'\n');print({k:v for k,v in record.items()if k!='source_hashes'});assert record['sources_unchanged']and record['compiler_unchanged']and all(x['rejected']for x in records)
