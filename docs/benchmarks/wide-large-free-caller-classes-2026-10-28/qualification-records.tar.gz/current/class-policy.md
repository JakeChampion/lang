Parent: #13717.

Fresh main 7aded8a6ca65677ee5b01db9dfe7ad95d3d50ebb still fails the unchanged retained-machine driver with exit 166.
The current helper proof passed separately in #13744.
The caller models still use the old 45-bin classification through 1 GiB.
A source-pinned diagnostic confirms that their existing domains include 4 GiB allocations.
Those allocations require current class 52.
The old classification returns the oversized sentinel.

This scope adds standalone current caller classification and partition adapters.
Retained-driver integration and machine call summaries remain separate.

Predeclared numeric policy:

- Preserve every old model, validator, value operation, API, driver assertion, production instruction, baseline, and threshold.
- Preserve the array capacity domain from 65533 through 4294967295, with allocation bytes equal to eight times capacity plus three.
- Preserve the string validator domain through 2305843009213693948 words and its existing residue restrictions.
- Preserve the actual fused grid through that validator maximum.
- Preserve the actual separate grid through 1152921504606846975 words plus its final 1152921504606846976 singleton with residues one through seven.
- Use the accepted 61 capacities through 17179869184 bytes without signed multiplication overflow.
- Return class zero through sixty for a uniform current large class.
- Preserve sentinel minus three for uniform small string allocations, minus two for uniform oversized allocations, and minus one for invalid or mixed intervals.
- Refine each original partition only at current class boundaries.
- Preserve every original partition boundary and residue range, without gaps, overlap, filtering, or an input-domain change.
- Keep every old classification result as explicit legacy provenance in the independent reference catalog.
- Use independent Python integer byte arithmetic for expected classes and set-based boundary construction for expected partitions.
- Include every old partition, every refined partition, class-boundary neighbors, mixed intervals, maximum values, malformed intervals, and residue controls.
- Use a real framed worker and strict collector with exact integer records.
- Require private old-ceiling, missing-partition, and swapped-fused-offset controls to fail for their declared reasons.
- Add no threshold change, numerical waiver, seed filter, helper instruction change, or machine-summary substitution.

Acceptance:

- [ ] Preserve fresh failure, diagnostic output, old source identities, and exact numeric policy before implementation.
- [ ] Pass an independent reproducible catalog and exact partition coverage checks.
- [ ] Pass the complete catalog on native, Wasm, and ARM64 with nonzero balanced zero-live censuses.
- [ ] Reject meaningful private faults and malformed worker records without loss of completed evidence.
- [ ] Complete a clean standard compiler build and appropriate Go, source, format, runtime, audit, and unchanged complexity gates.
- [ ] Preserve old interfaces, domains, assertions, production code, baselines, and thresholds byte for byte.
- [ ] Merge one READY PR normally at the exact full head and publish bounded evidence.

The full retained-driver recovery, native milestones, M5, and epic acceptance remain open.

