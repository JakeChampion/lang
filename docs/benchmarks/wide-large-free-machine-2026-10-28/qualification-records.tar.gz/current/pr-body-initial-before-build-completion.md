The current large-free helper uses a 16 GiB guard and full-width values that the bounded predecessor cannot represent.
This change adds a separate symbolic machine with a full numeric fact independent of its two word projections.
It preserves all old models, driver assertions, entry points, production instructions, domains, baselines, and thresholds.
Retained-driver integration requires a later scope after this proof merge.

The proof covers all 61 capacities, all 77 normal partitions, and the complete oversized unsigned predicate.
It establishes the exact register and memory postconditions declared in #13744.
The independent integer and bit-vector reference contains 336 programs, with 160 proofs and 176 rejections.
Three former positive expectations remain explicit legacy provenance with predeclared current counterexamples.

Initial stock tests passed four model nodes and 25 packet-worker nodes across native, ARM64, and Wasm with zero skips.
Go check and interpreter commands passed.
The provisional native catalog completed 42 fresh workers with exact results and nonzero balanced zero-live censuses.
Private unsafe-scale, missing-partition, and wrong-oversized-register defects compiled and ran normally before exact collector rejection.

Source commit: `12129f769fa75a9327892e6535dbef12f7b51a27`.
The clean standard two-stage build is in progress with bootstrap pin 919.
Final source-pinned campaigns and the source, format, build, vet, audit, and unchanged complexity checks remain pending.
Actual CI recovery, full retained-machine recovery, and all actual M5 and epic gates remain open.
