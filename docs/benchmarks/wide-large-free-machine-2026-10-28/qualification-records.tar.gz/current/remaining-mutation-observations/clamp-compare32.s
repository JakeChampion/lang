.text
.globl _start
_start:
leaq probe_inputs(%rip), %r12
leaq probe_inputs_end(%rip), %r13
.Lprobe_loop:
leaq __fern_large_freelist(%rip), %rdx
movabs $0x7000000000000000, %rax
movq $64, %rcx
.Lprobe_reset:
movq %rax, (%rdx)
addq $16, %rax
addq $8, %rdx
decq %rcx
jnz .Lprobe_reset
movabs $0x1122334455667788, %rax
movq %rax, probe_block(%rip)
movabs $0x8877665544332211, %rax
movq %rax, probe_block+8(%rip)
movabs $0x1100110011001100, %rax
movabs $0x1101120112011201, %rcx
movabs $0x1102130213021302, %rdx
movabs $0x1103140314031403, %rbx
movabs $0x1105160516051605, %rbp
movabs $0x1107180718071807, %rdi
movabs $0x11091a091a091a09, %r9
movabs $0x110a1b0a1b0a1b0a, %r10
movabs $0x110b1c0b1c0b1c0b, %r11
movabs $0x110e1f0e1f0e1f0e, %r14
movabs $0x110f200f200f200f, %r15
movq (%r12), %rsi
leaq probe_block(%rip), %r8
movq %rax, probe_before+0(%rip)
movq %rcx, probe_before+8(%rip)
movq %rdx, probe_before+16(%rip)
movq %rbx, probe_before+24(%rip)
movq %rsp, probe_before+32(%rip)
movq %rbp, probe_before+40(%rip)
movq %rsi, probe_before+48(%rip)
movq %rdi, probe_before+56(%rip)
movq %r8, probe_before+64(%rip)
movq %r9, probe_before+72(%rip)
movq %r10, probe_before+80(%rip)
movq %r11, probe_before+88(%rip)
movq %r12, probe_before+96(%rip)
movq %r13, probe_before+104(%rip)
movq %r14, probe_before+112(%rip)
movq %r15, probe_before+120(%rip)
call __fern_large_push
movq %rax, probe_after+0(%rip)
movq %rcx, probe_after+8(%rip)
movq %rdx, probe_after+16(%rip)
movq %rbx, probe_after+24(%rip)
movq %rsp, probe_after+32(%rip)
movq %rbp, probe_after+40(%rip)
movq %rsi, probe_after+48(%rip)
movq %rdi, probe_after+56(%rip)
movq %r8, probe_after+64(%rip)
movq %r9, probe_after+72(%rip)
movq %r10, probe_after+80(%rip)
movq %r11, probe_after+88(%rip)
movq %r12, probe_after+96(%rip)
movq %r13, probe_after+104(%rip)
movq %r14, probe_after+112(%rip)
movq %r15, probe_after+120(%rip)
movq $1, %rax
movq $1, %rdi
leaq probe_record(%rip), %rsi
movq $784, %rdx
syscall
cmpq $784, %rax
jne .Lprobe_io_failure
addq $8, %r12
cmpq %r13, %r12
jb .Lprobe_loop
xorq %rdi, %rdi
jmp .Lprobe_exit
.Lprobe_io_failure:
movq $2, %rdi
.Lprobe_exit:
movq $60, %rax
syscall
__fern_large_push:
movabs $17179869184, %rax
cmpq %rax, %rsi
ja .Llpush_ret
movq %rsi, %rax
cmpl $524288, %eax
jae .L2
movl $524288, %eax
.L2:
bsrq %rax, %rcx
subl $2, %ecx
movl $1, %edx
shlq %cl, %rdx
leaq -1(%rax,%rdx), %rax
negq %rdx
andq %rdx, %rax
bsrq %rax, %rcx
subl $2, %ecx
movq %rax, %rdx
shrq %cl, %rdx
shlq $2, %rcx
addq %rcx, %rdx
subq $72, %rdx
movq %rdx, %rax
leaq __fern_large_freelist(%rip), %rdx
movq (%rdx,%rax,8), %rcx
movq %rcx, (%r8)
movq %r8, (%rdx,%rax,8)
.Llpush_ret:
ret
.section .data
.balign 8
probe_inputs:
.quad 0x0
.quad 0x1
.quad 0x3ffff
.quad 0x40000
.quad 0x40001
.quad 0x7ffff
.quad 0x80000
.quad 0x80001
.quad 0x90000
.quad 0x9ffff
.quad 0xa0000
.quad 0xa0001
.quad 0xb0000
.quad 0xbffff
.quad 0xc0000
.quad 0xc0001
.quad 0xd0000
.quad 0xdffff
.quad 0xe0000
.quad 0xe0001
.quad 0xf0000
.quad 0xfffff
.quad 0x100000
.quad 0x100001
.quad 0x120000
.quad 0x13ffff
.quad 0x140000
.quad 0x140001
.quad 0x160000
.quad 0x17ffff
.quad 0x180000
.quad 0x180001
.quad 0x1a0000
.quad 0x1bffff
.quad 0x1c0000
.quad 0x1c0001
.quad 0x1e0000
.quad 0x1fffff
.quad 0x200000
.quad 0x200001
.quad 0x240000
.quad 0x27ffff
.quad 0x280000
.quad 0x280001
.quad 0x2c0000
.quad 0x2fffff
.quad 0x300000
.quad 0x300001
.quad 0x340000
.quad 0x37ffff
.quad 0x380000
.quad 0x380001
.quad 0x3c0000
.quad 0x3fffff
.quad 0x400000
.quad 0x400001
.quad 0x480000
.quad 0x4fffff
.quad 0x500000
.quad 0x500001
.quad 0x580000
.quad 0x5fffff
.quad 0x600000
.quad 0x600001
.quad 0x680000
.quad 0x6fffff
.quad 0x700000
.quad 0x700001
.quad 0x780000
.quad 0x7fffff
.quad 0x800000
.quad 0x800001
.quad 0x900000
.quad 0x9fffff
.quad 0xa00000
.quad 0xa00001
.quad 0xb00000
.quad 0xbfffff
.quad 0xc00000
.quad 0xc00001
.quad 0xd00000
.quad 0xdfffff
.quad 0xe00000
.quad 0xe00001
.quad 0xf00000
.quad 0xffffff
.quad 0x1000000
.quad 0x1000001
.quad 0x1200000
.quad 0x13fffff
.quad 0x1400000
.quad 0x1400001
.quad 0x1600000
.quad 0x17fffff
.quad 0x1800000
.quad 0x1800001
.quad 0x1a00000
.quad 0x1bfffff
.quad 0x1c00000
.quad 0x1c00001
.quad 0x1e00000
.quad 0x1ffffff
.quad 0x2000000
.quad 0x2000001
.quad 0x2400000
.quad 0x27fffff
.quad 0x2800000
.quad 0x2800001
.quad 0x2c00000
.quad 0x2ffffff
.quad 0x3000000
.quad 0x3000001
.quad 0x3400000
.quad 0x37fffff
.quad 0x3800000
.quad 0x3800001
.quad 0x3c00000
.quad 0x3ffffff
.quad 0x4000000
.quad 0x4000001
.quad 0x4800000
.quad 0x4ffffff
.quad 0x5000000
.quad 0x5000001
.quad 0x5800000
.quad 0x5ffffff
.quad 0x6000000
.quad 0x6000001
.quad 0x6800000
.quad 0x6ffffff
.quad 0x7000000
.quad 0x7000001
.quad 0x7800000
.quad 0x7ffffff
.quad 0x8000000
.quad 0x8000001
.quad 0x9000000
.quad 0x9ffffff
.quad 0xa000000
.quad 0xa000001
.quad 0xb000000
.quad 0xbffffff
.quad 0xc000000
.quad 0xc000001
.quad 0xd000000
.quad 0xdffffff
.quad 0xe000000
.quad 0xe000001
.quad 0xf000000
.quad 0xfffffff
.quad 0x10000000
.quad 0x10000001
.quad 0x12000000
.quad 0x13ffffff
.quad 0x14000000
.quad 0x14000001
.quad 0x16000000
.quad 0x17ffffff
.quad 0x18000000
.quad 0x18000001
.quad 0x1a000000
.quad 0x1bffffff
.quad 0x1c000000
.quad 0x1c000001
.quad 0x1e000000
.quad 0x1fffffff
.quad 0x20000000
.quad 0x20000001
.quad 0x24000000
.quad 0x27ffffff
.quad 0x28000000
.quad 0x28000001
.quad 0x2c000000
.quad 0x2fffffff
.quad 0x30000000
.quad 0x30000001
.quad 0x34000000
.quad 0x37ffffff
.quad 0x38000000
.quad 0x38000001
.quad 0x3c000000
.quad 0x3fffffff
.quad 0x40000000
.quad 0x40000001
.quad 0x48000000
.quad 0x4fffffff
.quad 0x50000000
.quad 0x50000001
.quad 0x58000000
.quad 0x5fffffff
.quad 0x60000000
.quad 0x60000001
.quad 0x68000000
.quad 0x6fffffff
.quad 0x70000000
.quad 0x70000001
.quad 0x78000000
.quad 0x7fffffff
.quad 0x80000000
.quad 0x80000001
.quad 0x90000000
.quad 0x9fffffff
.quad 0xa0000000
.quad 0xa0000001
.quad 0xb0000000
.quad 0xbfffffff
.quad 0xc0000000
.quad 0xc0000001
.quad 0xd0000000
.quad 0xdfffffff
.quad 0xe0000000
.quad 0xe0000001
.quad 0xf0000000
.quad 0xffffffff
.quad 0x100000000
.quad 0x100000001
.quad 0x120000000
.quad 0x13fffffff
.quad 0x140000000
.quad 0x140000001
.quad 0x160000000
.quad 0x17fffffff
.quad 0x180000000
.quad 0x180000001
.quad 0x1a0000000
.quad 0x1bfffffff
.quad 0x1c0000000
.quad 0x1c0000001
.quad 0x1e0000000
.quad 0x1ffffffff
.quad 0x200000000
.quad 0x200000001
.quad 0x240000000
.quad 0x27fffffff
.quad 0x280000000
.quad 0x280000001
.quad 0x2c0000000
.quad 0x2ffffffff
.quad 0x300000000
.quad 0x300000001
.quad 0x340000000
.quad 0x37fffffff
.quad 0x380000000
.quad 0x380000001
.quad 0x3c0000000
.quad 0x3ffffffff
.quad 0x400000000
.quad 0x400000001
.quad 0x800000000
.quad 0x7fffffffffffffff
.quad 0x8000000000000000
.quad 0xffffffffffffffff
probe_inputs_end:
.section .bss
.balign 8
probe_record:
probe_before: .skip 128
probe_after: .skip 128
probe_block: .skip 16
__fern_large_freelist: .skip 512
.section .note.GNU-stack,"",@progbits
