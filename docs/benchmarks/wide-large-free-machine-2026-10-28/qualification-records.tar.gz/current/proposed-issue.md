Parent: #13717 under #13687.
Prerequisites #13725 and #13738 are complete through normal merges.
Fresh main `8c688043465450e18520d7d32bfb0db8dde32ebf` still fails the unchanged second retained-machine driver with exit 166.
The fresh stock command reports two failing nodes and zero skips, with unchanged strict IR, sanitizer, and leak checks.

This scope adds a separate symbolic proof for the current large-free helper.
It preserves the old decoder, old 1 GiB model, all old driver assertions, and the retained-driver entry points.
Production emitters, runtime instructions, library files, mathematical helper domains, baselines, and thresholds remain unchanged.
Integration into the retained-driver group requires a later scope after this proof merge.

The new proof uses the accepted wide arithmetic and standalone wide decoder.
It must cover the unchanged 61 capacities and all 77 accepted partitions from zero through `2^34`, without refinement or omitted intervals.
The scalar facts retain factors zero or one and the existing offset and endpoint bound `[-(2^35-1), 2^35-1]`.
No floating tolerance, seed filter, unknown-value exemption, or domain increase changes this criterion.

A full 64-bit numeric fact must remain independent of its two 32-bit projections.
The accepted partition `10737418241..12884901888` crosses word quotients two and three while its full affine value remains valid.
Both separate projections are unknown, but its exact class remains 58 and its rounded capacity remains 12884901888.
The proof must preserve that partition and its full fact, without a special case for those endpoints.

Initial registers contain arbitrary opaque 64-bit identities, except the size, stack, and valid block pointer.
The proof assumes valid, disjoint block, stack-return, and freelist regions, as the bounded predecessor does.
The size in `rsi` covers every unsigned 64-bit value through two disjoint paths.
The normal path covers zero through `2^34`, and the oversized path represents every value above `2^34` through `2^64-1`.

On a normal return, `rax` contains the exact capacity class zero through 60.
Register `rcx` contains the prior selected freelist head, and `rdx` contains the freelist base.
The block link receives that prior head once, and the selected freelist slot receives the block pointer once.
All other registers, the stack return word, and all other freelist slots remain unchanged.

On an oversized return, `rax` contains the exact limit `17179869184` because the mandatory guard loads that register.
All other registers and memory remain unchanged, with zero block and slot writes.
The unsigned comparison result must follow from the oversized predicate and exact comparison operands.
No unconditional flag value or arbitrary external transfer establishes a proof.

Register writes at width 32 must clear the upper word.
Full-width moves preserve complete identities and full numeric facts.
Shift counts use the x86 width mask, and a zero masked count preserves flags.
Bit scans require a provably nonzero source, and unknown arithmetic or branch flags reject the path.

The proof permits only modeled safe reads and exact full-width writes to the declared regions.
It rejects incorrect slot indices, scales, offsets, widths, duplicate writes, altered return words, and changed preserved registers.
It rejects unknown instructions, invalid namespaces, unresolved transfers, unsupported effects, unknown branch outcomes, cycles, and paths without a proved return.
It adds no NOP treatment, instruction stripping, guard removal, arbitrary opcode fallback, or runtime substitute.

Fresh readonly native observations use 252 inputs and exact register, block, and freelist comparisons.
The actual helper completes with zero mismatches.
The 32-bit clamp comparison completes but produces seven mismatches, first at input 4294967296.
The 32-bit bit-scan replacement faults before the first 4294967296 record, after 214 complete records, so no normal completion is claimed.

The historical 32-bit left-shift positive remains valid for the current contract.
Below `2^34`, its count is at most 31 and both widths produce the same positive power.
At the isolated `2^34` endpoint, the masked 32-bit count is zero, but the input is already aligned and still selects class 60.
The oversized path returns before that shift.

The old 32-bit bit-scan, right-shift, and clamp-comparison positives do not define the new wider contract.
The new control catalog must retain their old source and expectation as explicit legacy provenance.
The current proof must reject those three substitutions, with preserved counterexample evidence.
No old source assertion changes in this scope.

The independent reference must use exact integer and bit-vector semantics for the current ABI contract.
It must retain the complete fixed control catalog before final campaigns.
All current positive and negative results must match exactly across native, Wasm, and ARM64, with nonzero balanced zero-live censuses.
Private accepted-fault, missing-partition, and wrong-oversized-register controls must expose incorrect verifier behavior.

Acceptance:

- [ ] Preserve fresh stock failure, exact current helper, word-projection capability, native observations, and all setup corrections with source and tool identities.
- [ ] Add only the separate wide symbolic proof while preserving old interfaces, models, assertions, instructions, domains, baselines, and thresholds.
- [ ] Prove all 77 normal partitions and the entire oversized predicate with the exact declared register and memory postconditions.
- [ ] Pass an independent fixed control catalog and meaningful verifier-defect controls without filters or unknown-value waivers.
- [ ] Pass source-pinned native, Wasm, ARM64, and Go checks with complete counts and nonzero balanced zero-live censuses.
- [ ] Complete the standard build, source, format, build, vet, audit, runtime, and unchanged complexity gates.
- [ ] Merge one scoped READY PR normally at its exact full head before retained-driver integration.

These memory regions describe the symbolic helper contract rather than physical memory, process RSS, or production capacity.
The native observations remain finite capabilities rather than Fern model qualification.
Full retained-machine recovery, actual CI recovery, and all actual M5 and epic gates remain open.
