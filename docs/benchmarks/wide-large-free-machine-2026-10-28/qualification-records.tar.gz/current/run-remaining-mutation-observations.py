from pathlib import Path
import subprocess,json,hashlib,struct,bisect
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-proof');folder=Path('/tmp/image-wide-machine-proof-evidence-secondary');old=folder/'current-mutation-capability-hash-corrected';out=folder/'remaining-mutation-observations';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
legacy=json.loads(Path('/tmp/image-retained-wide-machine-native-capability.json').read_text());samples=list(map(int,legacy['sample_inputs_decimal']));caps=legacy['capacities'];limit=1<<34;head=0x7000000000000000;block0=0x1122334455667788;block1=0x8877665544332211
actual_asm=(old/'actual.s').read_text();assert sum(line.startswith('.quad ')for line in actual_asm.splitlines())==len(samples)
def symbols(elf):
 result={}
 for line in subprocess.check_output(['nm','-n',str(elf)],text=True).splitlines():
  f=line.split()
  if len(f)==3:result[f[2]]=int(f[0],16)
 return result

def compare(raw,sym):
 assert len(raw)%784==0
 errors=[]
 for index in range(len(raw)//784):
  n=samples[index];words=struct.unpack_from('<98Q',raw,index*784);before=list(words[:16]);after=list(words[16:32]);block=list(words[32:34]);slots=list(words[34:]);expect=before.copy();es=[head+i*16 for i in range(64)];eb=[block0,block1]
  assert before[6]==n and before[8]==sym['probe_block']
  cls=None
  if n>limit:expect[0]=limit
  else:
   cls=bisect.bisect_left(caps,max(n,524288));expect[0]=cls;expect[1]=head+cls*16;expect[2]=sym['__fern_large_freelist'];es[cls]=sym['probe_block'];eb[0]=head+cls*16
  if after!=expect or slots!=es or block!=eb:errors.append(dict(input_decimal=str(n),expected_class=cls,observed_rax=str(after[0]),registers_match=after==expect,block_match=block==eb,slots_match=slots==es))
 return errors
record=dict(source='8c688043465450e18520d7d32bfb0db8dde32ebf',diagnostic_only=True,no_Fern_model_qualification=True,unchanged_current_helper_sha256=sha(root/'internal/testing/e2ecompiler/testdata/large_push_wide_decoder_current_helper.txt'),sample_count=len(samples),samples_inherited_from_explicit_historical_capability='f7bdaba5a4811476db32e137419971497e7da70f',observations=[])
raw=(old/'actual.stdout.bin').read_bytes();assert len(raw)==len(samples)*784 and not compare(raw,symbols(old/'actual.elf'))
record['observations'].append(dict(name='actual',execution_reused_without_repeat=True,compile_exit=0,runtime_exit=0,complete_records=len(samples),mismatches=[],binary_sha256_postrun_only=sha(old/'actual.elf')))
raw=(old/'wrong-bit-scan32.stdout.bin').read_bytes();count=len(raw)//784;assert count<len(samples)and count==214 and samples[count]==4294967296
record['observations'].append(dict(name='wrong-bit-scan32',execution_reused_without_repeat=True,compile_exit=0,runtime_signal=11,complete_records=count,first_uncompleted_input_decimal=str(samples[count]),completed_prefix_mismatches=compare(raw,symbols(old/'wrong-bit-scan32.elf')),binary_sha256_postrun_only=sha(old/'wrong-bit-scan32.elf'),cause='At input 2^32 the changed BSR reads zero; its destination is architecturally undefined. The actual native mutant faults before a complete record. No normal completion is claimed.'))
for name,from_,to in [('left-shift32','shlq %cl, %rdx','shll %cl, %edx'),('clamp-compare32','cmpq $524288, %rax','cmpl $524288, %eax')]:
 assert actual_asm.count(from_)==1
 asm=out/(name+'.s');asm.write_text(actual_asm.replace(from_,to));elf=out/(name+'.elf');q=subprocess.run(['gcc','-static','-nostdlib','-no-pie',str(asm),'-o',str(elf)],capture_output=True);(out/(name+'-compile.stdout')).write_bytes(q.stdout);(out/(name+'-compile.stderr')).write_bytes(q.stderr);assert q.returncode==0
 before=sha(elf);q=subprocess.run([str(elf)],capture_output=True);(out/(name+'.stdout.bin')).write_bytes(q.stdout);(out/(name+'.stderr.log')).write_bytes(q.stderr)
 item=dict(name=name,compile_exit=0,runtime_exit=q.returncode,binary_sha256_before=before,binary_sha256_after=sha(elf),complete_records=len(q.stdout)//784);record['observations'].append(item);(folder/'current-mutation-observations.checkpoint.json').write_text(json.dumps(record,indent=2)+'\n');assert q.returncode==0 and len(q.stdout)==len(samples)*784 and before==sha(elf)
 item['mismatches']=compare(q.stdout,symbols(elf));item['mismatch_count']=len(item['mismatches']);print(name,'mismatches',item['mismatch_count'],item['mismatches'][:1],flush=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root);record['worktree_clean']=True;(folder/'current-mutation-observations.json').write_text(json.dumps(record,indent=2)+'\n')
