from pathlib import Path
r=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-proof');p=r/'compiler/ssalargepushwidemachine.fern';assert not p.exists();s=(r/'compiler/ssalargepushmachine.fern').read_text()
s=s.replace('import "./ssalargepushvalue" as value;','import "./ssalargepushwidevalue" as value;').replace('import "./ssalargepushranges" as ranges;','import "./ssalargepushwideranges" as ranges;\nimport "./ssalargepushwideisa" as decoder;')
s=s.replace('struct Word { low: Half, high: Half }','struct Word { low: Half, high: Half, full: value.Value }\n\nstruct Flow { state: State, next: i32 }')
s=s.replace('return Word { low: token(kind, id, 0), high: token(kind, id, 1) };','return Word { low: token(kind, id, 0), high: token(kind, id, 1), full: value.unknown() };')
s=s.replace('return Half { kind: 1, identity: 0, part: 0, number: v };','return Half { kind: if (v.factor < 0) { 0 } else { 1 }, identity: 0, part: 0, number: v };')
s=s.replace('v.factor as i64 * (r.low as i64)', 'v.factor as i64 * r.low')
a=s.index('  let low = value.zero32(r, v);');b=s.index('\nfunction same_half',a)
s=s[:a]+'''  return Word { low: numeric_half(value.zero32(r, v)), high: numeric_half(value.high32(r, v)), full: v };
}

function number(r: ranges.Interval, w: Word, width: i32): value.Value {
  if (width == 64 && value.valid(r, w.full)) {
    return w.full;
  }
  if (w.low.kind != 1 || !nonnegative(r, w.low.number)) {
    return value.unknown();
  }
  if (width == 32) {
    return w.low.number;
  }
  return if (w.high.kind == 1) { value.join32(r, w.low.number, w.high.number) } else { value.unknown() };
}
''' + s[b:]
s=s.replace('return same_half(a.low, b.low) && same_half(a.high, b.high);','return same_half(a.low, b.low) && same_half(a.high, b.high) && a.full.factor == b.full.factor && a.full.offset == b.full.offset;')
s=s.replace('  let i = 0;\n  while (i < 16) {\n    regs = regs.append(initial_register(r, i, oversized));\n    i = i + 1;\n  }','  for reg in 0..16 {\n    regs = regs.append(initial_register(r, reg, oversized));\n  }')
s=s.replace('function write(s: State, reg: i32, w: Word): State {\n  return State { ...s, regs: s.regs.with(reg, w), ok: s.ok && w.low.kind != 0 && w.high.kind != 0 };','function write(s: State, r: ranges.Interval, reg: i32, w: Word): State {\n  let known = value.valid(r, w.full) || w.low.kind != 0 && w.high.kind != 0;\n  return State { ...s, regs: s.regs.with(reg, w), ok: s.ok && known };')
s=s.replace('  return if (width == 32) { Word { low: w.low, high: zero(r) } } else { w };','  if (width == 64) {\n    return w;\n  }\n  return if (w.low.kind == 1) { numeric(r, w.low.number) } else { Word { low: w.low, high: zero(r), full: value.unknown() } };')
s=s.replace('<= 44 as i64','<= 60 as i64')
s=s.replace('  return Word { low: s.cells[at], high: if (width == 64) { s.cells[at + 1] } else { zero(r) } };','  let low = s.cells[at];\n  let high = if (width == 64) { s.cells[at + 1] } else { zero(r) };\n  let full = if (low.kind == 1 && high.kind == 1) { value.join32(r, low.number, high.number) } else { value.unknown() };\n  return Word { low: low, high: high, full: full };')
# Each register write now checks either a full numeric fact or two known halves.
s=s.replace('write(s, op.', 'write(s, r, op.').replace('write(State { ...s, flags: flags }, op.', 'write(State { ...s, flags: flags }, r, op.').replace('write(State { ...s, flags: unknown_flags() }, op.', 'write(State { ...s, flags: unknown_flags() }, r, op.')
a=s.index('  let i = 0 as i64;\n',s.index('function shift('));b=s.index('  return value.number(r, n);',a)
s=s[:a]+'''  for bit in 0..count.offset as i32 {
    if (left && n > 17179869183 as i64) {
      return value.unknown();
    }
    n = if (left) { n * (2 as i64) } else { n / (2 as i64) };
  }
''' +s[b:]
s=s.replace('if (!value.valid(r, count) || count.factor != 0) {','if (!value.valid(r, count) || count.factor != 0 || count.offset < 0 as i64) {')
a=s.index('function comparison(');b=s.index('\nfunction step(',a)
s=s[:a]+'''function comparison(s: State, r: ranges.Interval, op: isa.Op): State {
  let operand = if (op.kind == 16) { op.source } else { op.destination };
  let threshold = if (op.kind == 16) { value.number(r, op.immediate as i64) } else { number(r, s.regs[op.source], op.width) };
  if (!nonnegative(r, threshold) || threshold.factor != 0) {
    return State { ...s, flags: unknown_flags() };
  }
  if (op.width == 64 && same_word(s.regs[operand], identity(7, 0)) && threshold.offset <= 17179869184 as i64) {
    return State { ...s, flags: value.Comparison { less: 0, equal: 0, less_equal: 0 } };
  }
  let v = number(r, s.regs[operand], op.width);
  if (!nonnegative(r, v)) {
    return State { ...s, flags: unknown_flags() };
  }
  return State { ...s, flags: value.compare(r, v, threshold.offset) };
}
''' +s[b:]
s=s.replace('if (op.kind == 16) {\n    return comparison', 'if (op.kind == 16 || op.kind == 28) {\n    return comparison')
s=s.replace('  if (!s.oversized) {\n    if (reg == 0) {\n      return numeric(r, value.number(r, ranges.expected_class(r) as i64));\n    }','  if (reg == 0) {\n    return numeric(r, value.number(r, if (s.oversized) { 17179869184 as i64 } else { ranges.expected_class(r) as i64 }));\n  }\n  if (!s.oversized) {')
s=s.replace('  let i = 0;\n  while (i < 16) {\n    if (!same_word(s.regs[i], final_register(s, r, i))) {\n      return false;\n    }\n    i = i + 1;\n  }','  for reg in 0..16 {\n    if (!same_word(s.regs[reg], final_register(s, r, reg))) {\n      return false;\n    }\n  }')
a=s.index('function path(');b=s.index('\npub function check(',a)
s=s[:a]+'''function execute(s: State, r: ranges.Interval, item: decoder.WideOp, pc: i32): Flow {
  let op = item.instruction;
  if (op.kind == 17) {
    let taken = branch(s.flags, op.condition);
    return Flow { state: State { ...s, ok: s.ok && taken >= 0 }, next: if (taken == 1) { op.target } else { pc + 1 } };
  }
  let next = if (op.kind == 41) { write(s, r, op.destination, numeric(r, value.number(r, item.immediate))) } else { step(s, r, op) };
  return Flow { state: next, next: pc + 1 };
}

function path(p: decoder.WideProgram, r: ranges.Interval, oversized: boolean): boolean {
  let s = initial(r, oversized);
  let visited: boolean[] = [];
  for op in p.ops {
    visited = visited.append(false);
  }
  let pc = 0;
  for budget in 0..p.ops.len() {
    if (pc < 0 || pc >= p.ops.len() || visited[pc]) {
      return false;
    }
    visited = visited.with(pc, true);
    let op = p.ops[pc];
    if (op.instruction.kind == 18) {
      return finished(s, r);
    }
    let flow = execute(s, r, op, pc);
    s = flow.state;
    pc = flow.next;
    if (!s.ok) {
      return false;
    }
  }
  return false;
}
''' +s[b:]
s=s.replace('let p = isa.large_program(output);','let p = decoder.large_program(output);')
p.write_text(s)
