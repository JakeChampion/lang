from pathlib import Path
import subprocess,json,time,hashlib,re,sys,os,shutil
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-proof');folder=Path('/tmp/image-wide-machine-proof-evidence-secondary');mode=sys.argv[1];prefix=folder/('final-'+mode);assert not prefix.with_suffix('.json').exists()
git=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip();source=(folder/'source-sha.txt').read_text().strip();assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();paths=git('ls-files','compiler','internal','cmd','scripts','Makefile','bootstrap').splitlines();before={p:sha(root/p)for p in paths if(root/p).is_file()};binaries={p:sha(root/p)for p in ['bin/fern','bin/fern-selfhost']};env=dict(os.environ,GOFLAGS='');checks=[]
if mode=='gates':
 fmt=[p for p in git('ls-files','*.fern','*.fern.md').splitlines()if not p.startswith('conformance/')and'/testdata/'not in p];assert all((root/p).is_file()for p in fmt)
 checks=[('source-gate',['make','check-sources']),('targets-complexity',['go','test','-v','./internal/testing/e2ecompiler','-run','^TestSelfHost(LargePushWideMachine(Worker)?|RepoComplexityRatchet)$','-count=1','-timeout=20m']),('Fern-format',['bin/fern','-fmt','-d',*fmt]),('Go-build',['go','build','./...']),('Go-vet',['go','vet','./...']),('aux',['make','actionlint','testnames','ci-selftest','runtime-bundle-check','gofmt-check']),('source-audit',['go','test','-v','./internal/testing/sourcelint','-count=1']),('reference-exact',['python3','scripts/gen-large-push-wide-machine-reference.py','--check']),('diff',['git','diff','--check'])]
elif mode=='Go':
 oracle=folder/('fern-oracle-'+source[:10]);assert not oracle.exists();entry=str(root/'compiler/drivers/ssalargepushwidemachine_run.fern')
 checks=[('build',['go','build','-o',str(oracle),'./cmd/fern']),('check',[str(oracle),'-check',entry]),('interp',[str(oracle),'-interp',entry])]
else:raise ValueError(mode)
record=dict(source=source,worktree_clean=True,source_hashes=before,binaries=binaries,mode=mode,Go_flags='',checks=[]);record['Fern_format_files']=len(fmt)if mode=='gates'else None;start=time.time()
for name,cmd in checks:
 log=folder/('final-'+mode+'-'+name+'.log');assert not log.exists();t=time.time()
 with log.open('w')as out:p=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 s=log.read_text();item=dict(name=name,command=cmd,exit=p.returncode,seconds=time.time()-t,PASS=len(re.findall(r'^\s*--- PASS:',s,re.M)),FAIL=len(re.findall(r'^\s*--- FAIL:',s,re.M)),SKIP=len(re.findall(r'^\s*--- SKIP:',s,re.M)));record['checks'].append(item);prefix.with_suffix('.checkpoint.json').write_text(json.dumps(record,indent=2)+'\n');print({k:v for k,v in item.items()if k!='command'},flush=True)
 if p.returncode or item['FAIL']or item['SKIP']:break
record.update(seconds=time.time()-start,sources_unchanged=before=={p:sha(root/p)for p in before},binaries_unchanged=binaries=={p:sha(root/p)for p in binaries},worktree_still_clean=not git('status','--porcelain'))
if mode=='Go'and oracle.exists():record.update(oracle_actual_build=source,oracle_sha256=sha(oracle),oracle_loaded_source=source)
prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n');assert len(record['checks'])==len(checks)and all(c['exit']==c['FAIL']==c['SKIP']==0 for c in record['checks'])and record['sources_unchanged']and record['binaries_unchanged']and record['worktree_still_clean']
if mode=='gates':
 assert next(c for c in record['checks']if c['name']=='targets-complexity')['PASS']==32
 assert next(c for c in record['checks']if c['name']=='source-audit')['PASS']==219
 assert (folder/'final-gates-Fern-format.log').read_bytes()==b''
if mode=='Go':assert 'wide large-push symbolic proof controls passed'in(folder/'final-Go-interp.log').read_text()
print('FINAL COMPLETE',mode,record['seconds'],flush=True)
