from pathlib import Path
import sys,json,gzip,subprocess,hashlib,re,time,argparse
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-proof');folder=Path('/tmp/image-wide-machine-proof-evidence-secondary');out=folder/'private-controls';assert not out.exists();out.mkdir();sys.path.insert(0,str(root/'scripts'))
from qualify_large_push_wide_machine import GEN,check_output,inventory,sha,run
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();before=inventory();compiler=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-health/bin/fern');ch=sha(compiler);catalog=json.loads(gzip.decompress(GEN.REFERENCE.read_bytes()));cases={c['name']:c for c in catalog['cases']};original=(root/'compiler/ssalargepushwidemachine.fern').read_text();env=dict(__import__('os').environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1');record=dict(source=source,feature_uncommitted=True,compiler_actual_build='a928e68f14ede0df5afe9b046bb866eb4455b82e',compiler_sha256=ch,source_hashes=before,controls=[]);start=time.time()
mutations=[('allow-bad-scale','op.scale != 8','op.scale != 4 && op.scale != 8','both-memory-scales-wrong'),('missing-last-partition','for r in ranges.intervals() {','let parts = ranges.intervals();\n  for at in 0..parts.len() - 1 {\n    let r = parts[at];','guard-inclusive'),('wrong-oversized-rax','if (s.oversized) { 17179869184 as i64 }','if (s.oversized) { 0 as i64 }','wrong-oversized-rax')]
for name,old,new,case_name in mutations:
 assert original.count(old)==1,(name,original.count(old));f=out/name;f.mkdir();c=f/'compiler';c.mkdir();drivers=c/'drivers';drivers.mkdir()
 for entry in (root/'compiler').iterdir():
  if entry.name not in ['ssalargepushwidemachine.fern','drivers']:(c/entry.name).symlink_to(entry.resolve(),target_is_directory=entry.is_dir())
 candidate=c/'ssalargepushwidemachine.fern';candidate.write_text(original.replace(old,new));worker=drivers/'ssalargepushwidemachine_worker.fern';worker.write_bytes((root/'compiler/drivers/ssalargepushwidemachine_worker.fern').read_bytes());binary=f/'worker.elf';case=cases[case_name];assert not case['expected'];packet=GEN.packet(case);(f/'input.bin').write_bytes(packet);item=dict(name=name,case_name=case_name,candidate_sha256=sha(candidate));record['controls'].append(item)
 with(f/'compile.log').open('wb')as log:q=subprocess.run([str(compiler),'-target','x86-64-linux','-sanitize','-o',str(binary),str(worker)],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 item['compile_exit']=q.returncode;(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n');assert q.returncode==0
 bh=sha(binary);q=subprocess.run([str(binary)],input=packet,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env);(f/'stdout.log').write_bytes(q.stdout);(f/'stderr.log').write_bytes(q.stderr);item.update(runtime_exit=q.returncode,binary_sha256_before=bh,binary_sha256_after=sha(binary));(out/'checkpoint.json').write_text(json.dumps(record,indent=2)+'\n');assert q.returncode==0 and bh==sha(binary)
 m=re.fullmatch(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)\s*',q.stderr);assert m;a,b,l=map(int,m.groups());assert a>0 and a==b and l==0;item['heap']=dict(allocs=a,frees=b,live_bytes=l);assert q.stdout.decode()==f'proof {case["id"]} 1\nend {case["id"]}\n'
 try:check_output(q.stdout.decode(),q.stderr.decode(),[case],q.returncode)
 except ValueError as error:item['collector_rejection']=str(error);assert str(error)=='exact proof mismatch: '+case_name
 else:raise AssertionError('verifier defect escaped collector')
 assert before==inventory()and sha(compiler)==ch;record.update(sources_unchanged=True,seconds=time.time()-start);(out/'record.json').write_text(json.dumps(record,indent=2)+'\n');print(name,item['collector_rejection'],item['heap'],flush=True)
# Exercise the full collector with a complete good prefix and a real false acceptance.
f=out/'checkpoint-fault';f.mkdir();baseline=cases['actual-current-helper'];selected=json.loads(json.dumps([baseline]*8+[cases['both-memory-scales-wrong']]))
for at,c in enumerate(selected):c['id']=at;c['name']=('baseline-'+str(at))if at<8 else c['name'];c['payload_sha256']=hashlib.sha256(GEN.packet(c)).hexdigest()
reference=f/'reference.json.gz';reference.write_bytes(gzip.compress(json.dumps(dict(schema=1,cases=selected)).encode(),mtime=0));mutant=out/'allow-bad-scale/compiler/drivers/ssalargepushwidemachine_worker.fern';wrapper=f/'compile-mutant';wrapper.write_text('#!/usr/bin/env python3\nimport os,sys\nos.execv('+repr(str(compiler))+',['+repr(str(compiler))+',*sys.argv[1:-1],'+repr(str(mutant))+'])\n');wrapper.chmod(0o755)
options=argparse.Namespace(output=str(f/'failed.json'),work=str(f/'worker'),source_commit=source,allow_dirty=True,reference=str(reference),compiler=str(wrapper),target='x86-64-linux')
try:run(options)
except ValueError as error:assert str(error)=='exact proof mismatch: both-memory-scales-wrong'
else:raise AssertionError('full collector accepted false proof')
d=json.loads(Path(options.output).read_text());assert not d['qualified']and d['compile_exit']==0 and len(d['workers'])==2 and len(d['records'])==8 and all(w['exit']==0 for w in d['workers'])and d['sources_unchanged'];check=json.loads(Path(options.output+'.checkpoint').read_text());assert len(check['records'])==8
preserved={str(p):sha(p)for p in f.rglob('*')if p.is_file()}
try:run(options)
except ValueError as error:assert str(error)=='refuse existing qualification output or work directory'
else:raise AssertionError('overwrote evidence')
assert preserved=={p:sha(p)for p in preserved};record['failure_prefix_control']=dict(compile_exit=0,runtime_exits=[w['exit']for w in d['workers']],completed_prefix_records=8,checkpoint_preserved=True,failed_worker_output_preserved=True,output_existing_rejected_without_changes=True);record['seconds']=time.time()-start;(out/'record.json').write_text(json.dumps(record,indent=2)+'\n');print('Full failure prefix preserved',flush=True)
