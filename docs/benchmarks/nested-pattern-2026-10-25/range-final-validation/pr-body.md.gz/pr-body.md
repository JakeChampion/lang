Document qualified constructors inside payload patterns with a complete conformance example.
Explain that a bare payload identifier binds the payload.

The native checker previously accepted a later constructor arm after a complete payload binder.
It now reports E028, as the Go checker does.
Guarded arms and partial payload patterns retain their coverage rules.

Tuple pattern shape errors retain E035.

All 2,704 Go checks and 5,626 native checks pass without skips.
The official bootstrap reaches equal stage two and stage three images.
All 24 matrix commands pass with three balanced runtime allocation counts.

Both frontends build Darwin images.
All 11 strict size gates and 1,218 source format checks pass.
The feature and complexity limits remain unchanged.

The documentation example equals the tested fixture.

Closes #13161.
