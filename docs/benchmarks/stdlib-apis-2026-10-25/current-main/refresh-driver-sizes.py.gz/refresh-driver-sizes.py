from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/tmp/lang-json-decode-publish');out=Path('/workspace/scratch/lang-stdlib-apis-6912-final');prior=Path('/workspace/scratch/lang-stdlib-apis-final-0830');pin=Path(os.environ['STAGE0']);digest=hashlib.sha256(pin.read_bytes()).hexdigest();env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
report=json.loads((prior/'final-driver-builds.json').read_text())
for row in report:row['source_commit']='9ed05eaa460d56f7184929a82c80c4fc0708db68'
for name in ['drivers/asm_load_run.fern','drivers/asm_modload_run.fern']:
 binary=Path('/tmp/lang-stdlib-apis-6912-measured-driver');args=[str(pin),'-target','x86-64-linux','-o',str(binary),str(root/'compiler'/name),str(root/'internal/stdlib')];start=time.monotonic()
 with(out/(Path(name).stem+'-final-build.log')).open('w')as log:subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 row=dict(source=name,source_commit=source,arguments=args,producer_sha256=digest,bytes=binary.stat().st_size,sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),seconds=time.monotonic()-start);report=[row if r['source']==name else r for r in report];binary.unlink();print(name,row['bytes'],flush=True)
rows=['fern.fern/stage2\t14570816']+[r['source']+'\t'+str(r['bytes'])for r in report]
(out/'final-driver-builds.json').write_text(json.dumps(report,indent=2)+'\n');(out/'final-driver-sizes.txt').write_text('\n'.join(rows)+'\n')
with(out/'final-driver-gate.log').open('w')as log:subprocess.run([str(root/'scripts/ci-check-driver-sizes'),str(root/'.github/selfhost-driver-sizes.txt'),str(out/'final-driver-sizes.txt')],cwd=root,env=dict(env,FERN_CI_SIZE_GATE_STRICT='1',FERN_SIZE_REPORT_COMPLETE='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
print('PASS all 11 strict sizes; two changed drivers refreshed',flush=True)
