Fix package visibility and shared standard library contracts.

- Use manifest boundaries for package visibility, enum constructors, and public re-exports.
- Keep scalar protocols consistent across both frontends and compiled targets.
- Align text ownership and number parsers, with direct f32 decode support.
- Return typed JSON and Protobuf errors, and report malformed regex patterns.
- Evaluate constants before acceptance, and stabilize f64 and f32 hyperbolic functions.
- Preserve divergent match arms in formatted code.

Validation: 4,801 recorded regression cases pass.
Current source, compiler, and native stdlib checks pass.
One optional two-generation test skips.
The IR sweep covers all 1,097 fixtures.
All 712 matrix commands, 136 embedded commands, and 11 strict size gates pass.

The formatter, gofmt, and vet checks pass.
Both make bootstrap and make distcheck pass with the official stage0 image.
Final stage 2 and stage 3 match at 14,570,816 bytes.

The regex reuse profile checks the same 1,024 inputs.
One compilation uses 25,120 allocations, compared with 57,856 for compilation on each call.
The validation capsules record source scopes, raw results, profiles, and artifact hashes.

An extra TAP sweep reached its ten-minute limit in digest examples.
The focused JSON, regex, and formatter checks pass.

Closes #12721.
Closes #13077.
Closes #13096.

Closes #12704.
Closes #13081.
Closes #13082.

Closes #13083.
Closes #13084.
Closes #13085.

Closes #12718.
Closes #13086.
Closes #12713.

Closes #13087.
Closes #13089.
Closes #13093.

Closes #13102.
Closes #12844.
Closes #13174.

Closes #13179.
Closes #13101.
Closes #13182.
