from pathlib import Path
import collections,gzip,hashlib,json,subprocess
root=Path('/tmp/lang-json-decode-publish');out=Path('/workspace/scratch/lang-stdlib-apis-6912-final');mid=Path('/workspace/scratch/lang-stdlib-apis-4cda-final')
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
(out/'source.txt').write_text(source+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','compiler','internal/stdlib'],cwd=root,text=True).splitlines()
cert=dict(recorded_source=source,compiled_source='4ee0c13b3055436ba026f210c5f88cc4eaa3a162',paths=paths,files=[dict(path=p,bytes=(root/p).stat().st_size,sha256=sha(root/p))for p in paths])
(out/'native-source-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
a=Path('/tmp/lang-stdlib-apis-0830-bootstrap/stage3');b=Path('/tmp/lang-stdlib-apis-6912-bootstrap/stage3');assert a.read_bytes()==b.read_bytes()
(out/'compiler-equivalence.json').write_text(json.dumps(dict(prior_source='9ed05eaa460d56f7184929a82c80c4fc0708db68',source_commit=source,compiled_source=cert['compiled_source'],prior_compiler=str(a),compiler=str(b),sha256=sha(b),bytes=b.stat().st_size),indent=2)+'\n')
body=(mid/'pr-body.md').read_text().replace('Validation: 4,801 test cases pass.','Validation: 4,801 recorded regression cases pass.\nCurrent source, compiler, and native stdlib checks pass.')
(out/'pr-body.md').write_text(body)
readme='''# Current main validation

Main base: 6912c7718d176daf8996d55e75bf60f6d52c47fb.
The source and input certificate identify the exact validated tree.
The earlier final-validation capsule retains the full batch evidence.

Upstream adds image examples, formatter coverage, and escaped regex class coverage.
The formatter repair matches the batch's repair exactly.
The checked regex implementation keeps the escaped class behavior.
The new class tests use the checked compile and group text APIs.
Five JSON assertion helpers now call JsonObject.contains.

The latest main also changes the CI queue and removes duplicate interpreter sweeps.
The batch preserves those changes.
The regex TAP suite remains in the native stdlib lane.
The focused JSON, regex, and formatter checks pass.
The source checks and compiler budgets pass.

A fresh official bootstrap produces the same final compiler bytes.
Stage 2 and stage 3 match at 14,570,816 bytes.
The source certificate records the current compiler and library inputs.
The size report refreshes the two changed test drivers.
All 11 strict size gates pass.
The earlier runtime matrix uses the identical compiler.

The rebuilt embedded compiler passes 136 commands.
Its library inputs match the current library.
The image example script also passes.
All 1,235 Fern format checks pass.
The gofmt and vet checks pass.

The extended TAP sweep hit its ten-minute limit in slow digest examples.
Completed cases passed before the timeout.
That diagnostic run is not part of the pass totals.
The focused checks cover the changed JSON and regex callers.
'''
(out/'README.md').write_text(readme)
print(source,'exact input certificate and compiler equality recorded')
