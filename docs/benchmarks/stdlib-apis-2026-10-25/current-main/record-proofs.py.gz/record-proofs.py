from pathlib import Path
import collections,gzip,hashlib,json,subprocess
root=Path('/tmp/lang-json-decode-publish');out=Path('/workspace/scratch/lang-stdlib-apis-6912-final');mid=Path('/workspace/scratch/lang-stdlib-apis-4cda-final');compat=Path('/workspace/scratch/lang-stdlib-apis-final-0830/upstream-4cda');source=(out/'source.txt').read_text().strip();base='6912c7718d176daf8996d55e75bf60f6d52c47fb';dest=root/'docs/benchmarks/stdlib-apis-2026-10-25/current-main'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
def suite(path,count,scope):
 rows=[json.loads(l)for l in path.read_text().splitlines()if l.startswith('{')];c=collections.Counter(d['Action']for d in rows if d.get('Test'));ends=[d for d in rows if not d.get('Test')and d['Action']in ['pass','fail','skip']]
 assert c['run']==c['pass']==count and not c['fail']and not c['skip']and len(ends)==1 and ends[0]['Action']=='pass'and rows[-1]['Action']=='pass',(path,c)
 return dict(file=str(path),source_commit=scope,run=count,passed=count,skipped=0,packages=1)
suites=[suite(compat/'focused-tap-regressions.jsonl',7,'2399ec3e4d2dc405bbc1b62bd1b6e3ead5b887c9'),suite(compat/'formatter-final-regressions.jsonl',2,'2399ec3e4d2dc405bbc1b62bd1b6e3ead5b887c9'),suite(out/'source-gates.jsonl',199,'4ee0c13b3055436ba026f210c5f88cc4eaa3a162'),suite(out/'compiler-gates.jsonl',8,'4ee0c13b3055436ba026f210c5f88cc4eaa3a162'),suite(out/'native-stdlib-regressions.jsonl',8,'4ee0c13b3055436ba026f210c5f88cc4eaa3a162'),suite(out/'regex-native-regressions.jsonl',3,source)]
prior=root/'docs/benchmarks/stdlib-apis-2026-10-25/final-validation/manifest.json';p=json.loads(prior.read_text());assert p['total_passed']==4792 and p['total_skipped']==1
for row in p['artifacts']:assert sha(prior.parent/row['path'])==row['sha256']
native=Path('/tmp/lang-stdlib-apis-6912-bootstrap/stage3');oracle=Path('/tmp/lang-stdlib-apis-6912-oracle');boot=json.loads((out/'bootstrap/bootstrap.json').read_text())
assert boot['fixedpoint']and boot['source_git']=='4ee0c13b3055436ba026f210c5f88cc4eaa3a162'
assert boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f'
assert sha(native)==sha(Path('/tmp/lang-stdlib-apis-0830-bootstrap/stage3'))==boot['stages'][2]['sha256']=='dda7f2ec372a444abbb8a1f6d160a3e9803ca42ab0a3a8bacdadb6ab7417c7ca'
assert 'vcs.revision='+source in(out/'oracle-version.txt').read_text()and'vcs.modified=false'in(out/'oracle-version.txt').read_text()
cert=json.loads((out/'native-source-certificate.json').read_text());assert cert['recorded_source']==source
for row in cert['files']:assert sha(root/row['path'])==row['sha256']
assert not git('diff','--name-only',boot['source_git'],source,'--',*cert['paths'])
assert 'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text()
for name in ['format-check.log','gofmt.log','vet.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert'Result: 0 errors, 0 warnings.'in(out/name).read_text()
embedded=json.loads((mid/'embedded-results.json').read_text());assert len(embedded['commands'])==136 and all(r['pass_']for r in embedded['commands'])
assert sha(Path(embedded['binary']))==embedded['binary_sha256']
assets=Path('/tmp/lang-stdlib-apis-4cda-embedded-stage')
for path in sorted((root/'internal/stdlib').rglob('*')):
 if path.is_file()and(path.name.endswith('.fern')or path.name.endswith('.fern.md')):assert path.read_bytes()==(assets/path.relative_to(root/'internal/stdlib')).read_bytes(),str(path)
assert 'Formatter match regression passed'in(mid/'fern-image.log').read_text()
assert not git('diff','--name-only','2399ec3e4d2dc405bbc1b62bd1b6e3ead5b887c9',source,'--','fern-image')
timeout=[json.loads(l)for l in(compat/'tap-regressions.jsonl').read_text().splitlines()if l.startswith('{')]
assert any('test timed out after'in d.get('Output','')for d in timeout)and not any(d.get('Action')=='fail'and d.get('Test')for d in timeout)
patch=git('diff','--binary',base,source,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
dest.mkdir(parents=True,exist_ok=False);artifacts=[]
def save(name,data,original=None):
 path=dest/name;path.write_bytes(data);row=dict(path=name,bytes=len(data),sha256=sha(path))
 if original:row['original']=str(original)
 artifacts.append(row)
save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
save('retired-interpreter-runner-2399.go.gz',gzip.compress(git('show','2399ec3e4d2dc405bbc1b62bd1b6e3ead5b887c9:internal/testing/e2e/test_runner_test.go'),mtime=0))
files=[]
for name in ['source.txt','pr-body.md','record-proofs.py','prepare-record.py','native-source-certificate.json','compiler-equivalence.json','readme-ste.log','pr-body-ste.log','bootstrap.log','oracle-version.txt','source-gates.jsonl','compiler-gates.jsonl','native-stdlib-regressions.jsonl','regex-native-regressions.jsonl','refresh-driver-sizes.py','check-sizes.log','asm_load_run-final-build.log','asm_modload_run-final-build.log','final-driver-builds.json','final-driver-sizes.txt','final-driver-gate.log','format-vet.py','format-vet.log','format-final.json','format-check.log','gofmt.log','vet.log']:
 files.append((out/name,name+'.gz'))
for name in ['bootstrap.json','completed-intermediates.json','stage1.log','stage2.log','stage3.log']:files.append((out/'bootstrap'/name,'bootstrap__'+name+'.gz'))
for name in ['focused-tap-regressions.jsonl','formatter-final-regressions.jsonl','tap-regressions.jsonl','tap-selection.json','tap-timeout-orphan-cleanup.json']:files.append((compat/name,'compatibility__'+name+'.gz'))
for name in ['embedded-results.json','embedded-results.log','embedded-build.log','embedded-asset-inventory.json','embed-stage.log','fern-image.log','check-embedded.py']:files.append((mid/name,'embedded__'+name+'.gz'))
for path,name in files:save(name,gzip.compress(path.read_bytes(),mtime=0),path)
manifest=dict(source_commit=source,compiled_source_commit=boot['source_git'],main_base=base,public_parent='445d513307cbf7e77a3951e041fa49ebf534c8a7',prior_capsule='../final-validation/manifest.json',prior_manifest_sha256=sha(prior),prior_passed=4792,prior_skipped=1,suites=suites,total_recorded_passed=4792+sum(s['passed']for s in suites),total_skipped=1,bootstrap=boot,compiler=dict(path=str(native),bytes=native.stat().st_size,sha256=sha(native)),oracle=dict(path=str(oracle),sha256=sha(oracle)),embedded=dict(binary=embedded['binary'],sha256=embedded['binary_sha256'],commands=136,stdlib_bytes_match_current=True),diagnostic_tap_sweep=dict(file='compatibility__tap-regressions.jsonl.gz',conclusion='10-minute timeout in slow digest examples; excluded from pass totals'),artifacts=artifacts)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('PASS',len(artifacts),'artifacts;',manifest['total_recorded_passed'],'recorded passes, 1 optional skip')
