from pathlib import Path
import collections,gzip,hashlib,json,os,re,shutil,subprocess,sys,time
root,out,selfarg,oraclearg,selection=map(Path,sys.argv[1:]);root=root.resolve();out=out.resolve();out.mkdir(parents=True,exist_ok=False);selfcli=selfarg.resolve();oracle=oraclearg.resolve();names=json.loads(selection.read_text());rows=[];fail=[];traces=[]
env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};env.update(FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_STRICT_IR='1',FERN_RC_TRACE='1')
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),selection=names,environment={k:v for k,v in env.items()if k.startswith('FERN_')},binaries={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in [selfcli,oracle]},commands=rows,failures=fail,traces=traces)
def run(name,args,stdout=None,exit=0,error=None,runtime=False):
 start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=root,env=env,capture_output=True,timeout=180);good=p.returncode==exit if error is None else p.returncode!=0 and all(x in p.stderr.decode(errors='replace')for x in error)
 if stdout is not None:good=good and p.stdout==stdout
 row=dict(name=name,args=list(map(str,args)),exit=p.returncode,pass_=good,seconds=time.monotonic()-start)
 for channel,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  path=name+'.'+channel+'.gz';(out/path).write_bytes(gzip.compress(data,mtime=0));row[channel+'_log']=path
 if runtime:
  text=p.stderr.decode();m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',text);good=good and bool(m and m[1]==m[2] and m[3]=='0');live=collections.Counter();events=0
  for line in text.splitlines():
   mt=re.fullmatch(r'rctrace ([af]) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16})',line)
   if mt:events+=1;live[mt[2]]+=1 if mt[1]=='a' else -1
  good=good and all(n==0 for n in live.values());row['pass_']=good;traces.append(dict(name=name,trace_events=events,unpaired_allocations=sum(n for n in live.values()if n>0),census=m[0]if m else None))
 rows.append(row)
 if not good:fail.append(row);print('FAIL',name,p.returncode,p.stderr.decode(errors='replace')[-3000:],flush=True)
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');return p
for name in names:
 case=root/'conformance/cases'/name;src=case/'main.fern';neg=case/'expected.error';expected=(case/'expected.stdout').read_bytes()if(case/'expected.stdout').exists()else b'';code=int((case/'expected.exit').read_text())if(case/'expected.exit').exists()else 0
 for tag,cli in [('Go',oracle),('self',selfcli)]:
  errs=neg.read_text().split()if neg.exists()else None
  run(name+'-'+tag+'-check',[cli,'-check',src,root/'internal/stdlib'],stdout=b'',error=errs)
  if neg.exists():continue
  run(name+'-'+tag+'-interp',[cli,'-interp',src,root/'internal/stdlib'],stdout=expected,exit=code)
  p=run(name+'-'+tag+'-fmt',[cli,'-fmt',src]);folder=out/(name+'-'+tag);shutil.copytree(case,folder);formatted=folder/'main.fern';formatted.write_bytes(p.stdout)
  run(name+'-'+tag+'-fmt-again',[cli,'-fmt',formatted],stdout=p.stdout)
  run(name+'-'+tag+'-formatted-check',[cli,'-check',formatted,root/'internal/stdlib'],stdout=b'')
 if neg.exists():continue
 for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
  binary=out/(name+'-'+target);build_source=src;runtime_exit=code
  if target=='wasm32-wasi' and code!=0:
   normalized=out/(name+'-wasi-normalized');shutil.copytree(case,normalized);build_source=normalized/'main.fern';original=src.read_text();assert original.count('function main(): i32')==1;written=original.replace('function main(): i32','function matrix_fixture_main(): i32',1)+'\nfunction main(): i32 { if (matrix_fixture_main() == '+str(code)+') { return 0; } return 1; }\n';build_source.write_text(written);runtime_exit=0
  args=[selfcli,'-target',target,'-o',binary]
  if target=='wasm32-wasi':args+=['-emit','command-module']
  p=run(name+'-build-'+target,args+[build_source,root/'internal/stdlib'],stdout=b'')
  if p.returncode==0:run(name+'-run-'+target,runner+[binary],stdout=expected,exit=runtime_exit,runtime=True)
  if binary.exists():binary.unlink()
 print('DONE',name,flush=True)
report['complete']=True;(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');assert not fail,len(fail);print('PASS',len(rows),'commands',len(traces),'balanced runtime censuses',sum(x['trace_events']for x in traces),'trace events',flush=True)
