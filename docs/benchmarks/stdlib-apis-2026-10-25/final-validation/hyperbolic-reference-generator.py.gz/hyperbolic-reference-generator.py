from pathlib import Path
import json,math,struct,platform
root=Path('/tmp/lang-hyperbolic-fix');folder=root/'conformance/cases/hyperbolic_boundaries';folder.mkdir(exist_ok=True)
base=[0.0,5e-324,2.2250738585072014e-308,1e-20,1e-10,1e-5,2**-28,math.log(2)/2,1.0,22.0,709.0,709.782712893384,710.0,710.4758600739439,711.0,1000.0,math.inf,math.nan]
xs=[]
for x in base:
 for y in ([math.nextafter(x,-math.inf),x,math.nextafter(x,math.inf)]if math.isfinite(x)and x>0 else[x]):
  xs.extend([y,-y])
base32=[0.0,2**-149,2**-126,1e-20,1e-10,1e-5,2**-28,math.log(2)/2,1.0,22.0,88.0,88.722839,89.0,89.415986,90.0,1000.0,math.inf,math.nan]
xs32=[]
def bits(x,w):
 try:return int.from_bytes(struct.pack('>d'if w==64 else'>f',x),'big')
 except OverflowError:return bits(math.copysign(math.inf,x),w)
def value(b,w):return struct.unpack('>d'if w==64 else'>f',b.to_bytes(w//8,'big'))[0]
for x in base32:
 b=bits(x,32)
 for bb in ([b-1,b,b+1]if 0<b<0x7f800000 else[b]):
  y=value(bb,32);xs32.extend([y,-y])
def lit(b,w):
 if b>=1<<(w-1):b-=1<<w
 if b==-(1<<(w-1)):return f'(-{(1<<(w-1))-1}i{w} - 1i{w})'
 return str(b)+f'i{w}'
def reference(fn,x):
 try:return fn(x)
 except OverflowError:return math.copysign(math.inf,x)if fn==math.sinh else math.inf
out=['import "std/f64";','import "std/f32";','']
for w,values in [(64,xs),(32,xs32)]:
 out += [f'struct Case{w} {{ x: f{w}, s: i{w}, c: i{w}, t: i{w} }}',f'function near{w}(got: f{w}, want: i{w}): boolean {{',f'  let actual: i{w} = f{w}_bits(got);','  if (actual == want) { return true; }',f'  let magnitude: i{w} = want & {hex((1<<(w-1))-1)};',f'  if (magnitude > {hex(0x7ff0000000000000 if w==64 else 0x7f800000)}) {{ return got != got; }}',f'  if (magnitude == 0 || magnitude == {hex(0x7ff0000000000000 if w==64 else 0x7f800000)} || (actual < 0) != (want < 0)) {{ return false; }}',f'  let delta: i{w} = (actual & {hex((1<<(w-1))-1)}) - magnitude;',f'  return delta >= -{4 if w==64 else 1} && delta <= {4 if w==64 else 1};','}',f'function check{w}(): i32 {{',f'  let cases: Case{w}[] = [']
 for x in values:
  vals=[lit(bits(reference(fn,x),w),w)for fn in [math.sinh,math.cosh,math.tanh]]
  out.append(f'    Case{w} {{ x: f{w}_from_bits({lit(bits(x,w),w)}), s: {vals[0]}, c: {vals[1]}, t: {vals[2]} }},')
 out += ['  ];','  let i: i32 = 0;','  while (i < cases.len()) {','    let row = cases[i];',f'    if (!near{w}(row.x.sinh(), row.s)) {{ print(f"sinh{w} case {{i}}: {{f{w}_bits(row.x.sinh())}} expected {{row.s}}"); return 1; }}',f'    if (!near{w}(row.x.cosh(), row.c)) {{ print(f"cosh{w} case {{i}}: {{f{w}_bits(row.x.cosh())}} expected {{row.c}}"); return 2; }}',f'    if (!near{w}(row.x.tanh(), row.t)) {{ print(f"tanh{w} case {{i}}: {{f{w}_bits(row.x.tanh())}} expected {{row.t}}"); return 3; }}','    i = i + 1;','  }','  return 0;','}']
out += ['function main(): i32 {','  let wide = check64();','  if (wide != 0) { return wide; }','  return check32();','}'];(folder/'main.fern').write_text('\n'.join(out)+'\n');(folder/'expected.exit').write_text('0\n');(folder/'expected.stdout').write_bytes(b'');Path('/workspace/scratch/lang-hyperbolic/reference-metadata.json').write_text(json.dumps(dict(reference='Python math / system libm',python=platform.python_version(),libc=platform.libc_ver(),f64_inputs=len(xs),f32_inputs=len(xs32),f64_max_ulps=4,f32_max_ulps=1),indent=2)+'\n');print(len(xs),len(xs32))
