from pathlib import Path
import collections,gzip,hashlib,json,subprocess,tarfile
root=Path('/tmp/lang-json-decode-publish');out=Path('/workspace/scratch/lang-stdlib-apis-final-0830')
old=Path('/workspace/scratch/lang-stdlib-apis-final-0822')
source='9ed05eaa460d56f7184929a82c80c4fc0708db68';tested='3846ebb92e927b6e64f5e68166741e3eee7e725c'
base='445d513307cbf7e77a3951e041fa49ebf534c8a7'
dest=root/'docs/benchmarks/stdlib-apis-2026-10-25/final-validation'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert not git('status','--porcelain')
def suite(path,run,passed,skips,packages,scope):
 rows=[json.loads(s)for s in path.read_text().splitlines()if s.startswith('{')]
 counts=collections.Counter(d['Action']for d in rows if d.get('Test'))
 terminal=[d for d in rows if not d.get('Test')and d['Action']in['pass','fail','skip']]
 assert counts['run']==run and counts['pass']==passed and counts['skip']==skips and not counts['fail'],(path,counts)
 assert len(terminal)==packages and all(d['Action']=='pass'for d in terminal)and rows[-1]['Action']=='pass'
 return dict(file=str(path),source_commit=scope,run=run,passed=passed,skipped=skips,packages=packages)
suites=[suite(old/'go-regressions.jsonl',2985,2985,0,8,tested),suite(old/'native-regressions.jsonl',1680,1679,1,1,tested),suite(out/'hint-generic-regressions.jsonl',128,128,0,1,source)]
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());native=Path('/tmp/lang-stdlib-apis-0830-bootstrap/stage3');oracle=Path('/tmp/lang-stdlib-apis-0830-oracle')
assert boot['source_git']==source and boot['fixedpoint']
assert boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f'
assert sha(native)==sha(native.with_name('stage2'))==boot['stages'][2]['sha256']=='dda7f2ec372a444abbb8a1f6d160a3e9803ca42ab0a3a8bacdadb6ab7417c7ca'
assert native.stat().st_size==14570816
assert 'vcs.revision='+source in(out/'oracle-version.txt').read_text()and'vcs.modified=false'in(out/'oracle-version.txt').read_text()
make=json.loads((out/'make-bootstrap.json').read_text());assert make['source_git']==source and make['stages'][2]['sha256']==sha(native)==sha(root/'build/bootstrap/stage3')
assert 'stage2 == stage3: fixed point reached'in(out/'make-distcheck.log').read_text()
matrix=json.loads((out/'family-matrix/report.json').read_text());assert matrix['complete']and matrix['source_commit']==source and len(matrix['commands'])==712 and len(matrix['traces'])==132 and not matrix['failures']
assert all(d['pass_']for d in matrix['commands'])and all(d['unpaired_allocations']==0 for d in matrix['traces'])
assert sum(d['trace_events']for d in matrix['traces'])==104460
assert matrix['binaries'][str(native)]['sha256']==sha(native)and matrix['binaries'][str(oracle)]['sha256']==sha(oracle)
embed=json.loads((out/'embedded-results.json').read_text());assert embed['source_commit']==source and len(embed['commands'])==136 and all(d['pass_']for d in embed['commands'])
eruns=[d for d in embed['commands']if d.get('balanced_census')];assert len(eruns)==45 and all(d['unpaired']==0 for d in eruns)
assert sha(Path(embed['binary']))==embed['binary_sha256']
assert 'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text()
assert len((out/'final-driver-sizes.txt').read_text().splitlines())==11
for name in ['format-check.log','gofmt.log','vet.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert'Result: 0 errors, 0 warnings.'in(out/name).read_text()
cert=json.loads((out/'native-source-certificate.json').read_text());assert cert['recorded_source']==source
for d in cert['files']:assert sha(root/d['path'])==d['sha256']
equivalence=json.loads((out/'canonical-footer-equivalence.json').read_text());assert equivalence['tested_source']==tested and equivalence['canonical_source']==source and equivalence['native_binary_identical']and equivalence['sha256']==sha(native)
subprocess.run(['git','diff','--ignore-blank-lines','--exit-code',tested,source,'--','compiler','internal/stdlib'],cwd=root,check=True)
patch=git('diff','--binary',base,source,'--','.',':(exclude)docs/benchmarks')
subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
profiles=json.loads((old/'regex-profiles/report.json').read_text());assert len(profiles['runs'])==2
assert all(r['checksum']==512 and r['iterations']==1024 and r['producer_sha256']==sha(native)for r in profiles['runs'])
dest.mkdir(parents=True,exist_ok=False);artifacts=[]
def save(name,data,original=None):
 p=dest/name;p.write_bytes(data);row=dict(path=name,bytes=len(data),sha256=sha(p))
 if original:row['original']=str(original)
 artifacts.append(row)
save('README.md',(out/'README.md').read_bytes())
save('source.patch.gz',gzip.compress(patch,mtime=0))
files=[
(out/'pr-body.md','pr-body.md.gz'),
(out/'record-proofs.py','record-proofs.py.gz'),
(out/'readme-ste.log','readme-ste.log.gz'),(out/'pr-body-ste.log','pr-body-ste.log.gz'),
(old/'go-regressions.jsonl','go-regressions-3846.jsonl.gz'),(old/'native-regressions.jsonl','native-regressions-3846.jsonl.gz'),
(out/'hint-generic-regressions.jsonl','hint-generic-regressions-9ed0.jsonl.gz'),
(out/'native-source-certificate.json','native-source-certificate.json.gz'),
(out/'canonical-footer-equivalence.json','canonical-footer-equivalence.json.gz'),
(out/'oracle-version.txt','oracle-version.txt.gz'),
(out/'matrix-selection.json','matrix-selection.json.gz'),
(out/'family-matrix/report.json','family-matrix-report.json.gz'),
(Path('/workspace/scratch/lang-api-family-matrix.py'),'family-matrix.py.gz'),
(out/'family-matrix.log','family-matrix.log.gz'),
(out/'embedded-asset-inventory.json','embedded-asset-inventory.json.gz'),
(out/'make-bootstrap.json','make-bootstrap.json.gz'),
(root/'bootstrap/stage0.lock','stage0.lock.gz'),
(Path('/workspace/scratch/lang-hyperbolic/reference-metadata.json'),'hyperbolic-reference-metadata.json.gz'),
(Path('/workspace/scratch/lang-hyperbolic/make-fixture.py'),'hyperbolic-reference-generator.py.gz'),
(old/'profile-regex-reuse.py','profile-regex-reuse.py.gz'),(old/'profile-regex-reuse.log','profile-regex-reuse.log.gz'),
]
for name in ['bootstrap.log','make-bootstrap.log','make-distcheck.log','check-embedded.py','embedded-results.json','embedded-results.log','embedded-build.log','embed-stage.log','check-sizes.py','check-sizes.log','final-driver-builds.json','final-driver-sizes.txt','final-driver-gate.log','format-final.json','format-vet.py','format-vet.log','format-check.log','gofmt.log','vet.log']:
 files.append((out/name,name+'.gz'))
for name in ['bootstrap.json','completed-intermediates.json','stage1.log','stage2.log','stage3.log']:
 files.append((out/'bootstrap'/name,'bootstrap__'+name+'.gz'))
for name in ['e_sinh.c','e_cosh.c','s_tanh.c']:
 files.append((Path('/workspace/scratch/lang-hyperbolic')/name,'reference__'+name+'.gz'))
for p in sorted((old/'regex-profiles').iterdir()):
 if p.is_file():files.append((p,'regex-profiles__'+p.name+'.gz'))
for p,name in files:
 data=p.read_bytes();save(name,gzip.compress(data,mtime=0),p)
logroot=out/'family-matrix';logs=[p for p in sorted(logroot.rglob('*'))if p.is_file()]
inventory=[dict(path=str(p.relative_to(logroot)),bytes=p.stat().st_size,sha256=sha(p))for p in logs]
archive=dest/'family-matrix-raw.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=3)as t:
 for p in logs:t.add(p,arcname=str(p.relative_to(logroot)),recursive=False)
with tarfile.open(archive)as t:
 actual={i.name:hashlib.sha256(t.extractfile(i).read()).hexdigest()for i in t if i.isfile()}
assert actual=={d['path']:d['sha256']for d in inventory}
artifacts.append(dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),original=str(logroot)))
save('family-matrix-raw-inventory.json.gz',gzip.compress(json.dumps(inventory,indent=2).encode()+b'\n',mtime=0))
manifest=dict(source_commit=source,tested_source_commit=tested,public_parent=base,main_base='ba2b7a8cb69a75160b6d8a9e7fcfa289ea15789d',
issues=[12721,13077,13096,12704,13081,13082,13083,13084,13085,12718,13086,12713,13087,13089,13093,13102,12844,13174,13179,13101,13182],
suites=suites,total_passed=4792,total_skipped=1,ir_fixtures=1097,matrix_commands=712,balanced_matrix_censuses=132,matrix_trace_events=104460,
embedded_commands=136,balanced_embedded_censuses=45,embedded_trace_events=sum(d['trace_events']for d in eruns),
compiler=dict(path=str(native),bytes=native.stat().st_size,sha256=sha(native)),oracle=dict(path=str(oracle),bytes=oracle.stat().st_size,sha256=sha(oracle)),
bootstrap=boot,make_bootstrap=make,format_equivalence=equivalence,regex_call_patterns=profiles,artifacts=artifacts)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('PASS',len(artifacts),'artifacts; 4792 passed cases, 1 optional skip; 712 matrix commands; 136 embedded commands')
