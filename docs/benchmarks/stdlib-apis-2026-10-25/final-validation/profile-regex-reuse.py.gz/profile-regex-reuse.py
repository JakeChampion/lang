from pathlib import Path
import hashlib,json,os,re,subprocess
out=Path('/workspace/scratch/lang-stdlib-apis-final-0822/regex-profiles');out.mkdir(exist_ok=False);root=Path('/tmp/lang-json-decode-publish');compiler=Path('/tmp/lang-stdlib-apis-0822-bootstrap/stage3');env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};rows=[]
for variant in ['compile-every-call','compile-once']:
 source='import "std/regex";\nimport "std/i64";\nfunction main(): i32 {\nlet before: i64 = __heap_alloc_count();\n';compile='let Ok(compiled) = regex.compile("^[A-Za-z]+[0-9]{2}$") else { return 2; };\n'
 if variant=='compile-once':source+=compile
 source+='let sum: i32 = 0;\nfor i in 0..1024 {\nlet text: string = if (i % 2 == 0) { "Hello42" } else { "no-match" };\n'
 if variant=='compile-every-call':source+=compile
 source+='if (compiled.is_match(text)) { sum = sum + 1; }\n}\nlet allocations: i64 = __heap_alloc_count() - before;\nprint(sum); print(allocations);\nreturn 0;\n}\n';path=out/(variant+'.fern');path.write_text(source);binary=out/variant
 with(out/(variant+'-build.log')).open('w')as log:subprocess.run([str(compiler),'-target','x86-64-linux','-o',str(binary),str(path),str(root/'internal/stdlib')],cwd=root,env=dict(env,FERN_STRICT_IR='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
 callgrind=out/(variant+'.callgrind')
 with(out/(variant+'-profile.log')).open('w')as log:p=subprocess.run(['valgrind','--tool=callgrind','--callgrind-out-file='+str(callgrind),str(binary)],cwd=root,env=env,stdout=subprocess.PIPE,stderr=log,text=True,check=True,timeout=180)
 (out/(variant+'.stdout')).write_text(p.stdout);lines=p.stdout.strip().splitlines();assert lines[0]=='512';row=dict(variant=variant,iterations=1024,checksum=int(lines[0]),allocations=int(lines[1]),instructions=int(re.search(r'(?m)^summary: (\d+)',callgrind.read_text())[1]),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size,producer_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest());rows.append(row);(out/'report.json').write_text(json.dumps(dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),scope='Two calling patterns using the same current library, compiler and 1024 inputs; this is not a before/after compiler benchmark',runs=rows),indent=2)+'\n');binary.unlink();print(row,flush=True)
