from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path('/tmp/lang-json-decode-publish');out=Path('/workspace/scratch/lang-stdlib-apis-691b-final');prior=Path('/workspace/scratch/lang-stdlib-apis-6912-final');source='798ef6e5d214da75cc8f928c5b77ecd39c7910cb';dest=root/'docs/benchmarks/stdlib-apis-2026-10-25/updated-public-head'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
paths=git('ls-files','compiler','internal/stdlib').decode().splitlines();cert=dict(recorded_source=source,paths=paths,files=[dict(path=p,sha256=sha(root/p),bytes=(root/p).stat().st_size)for p in paths]);(out/'native-source-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());native=Path('/tmp/lang-stdlib-apis-691b-bootstrap/stage3')
assert boot['fixedpoint']and boot['source_git']==source and sha(native)==boot['stages'][2]['sha256']=='dda7f2ec372a444abbb8a1f6d160a3e9803ca42ab0a3a8bacdadb6ab7417c7ca'
assert 'vcs.revision='+source in(out/'oracle-version.txt').read_text()and'vcs.modified=false'in(out/'oracle-version.txt').read_text()
matrix=json.loads((out/'hyperbolic-matrix/report.json').read_text());assert matrix['complete']and len(matrix['commands'])==16 and not matrix['failures']and all(d['pass_']for d in matrix['commands'])and len(matrix['traces'])==3 and all(d['unpaired_allocations']==0 for d in matrix['traces'])
embedded=json.loads((out/'embedded-results.json').read_text());assert len(embedded['commands'])==136 and all(d['pass_']for d in embedded['commands'])
for name in ['format-check.log','gofmt.log','vet.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert'Result: 0 errors, 0 warnings.'in(out/name).read_text()
dest.mkdir(parents=True,exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes())
for name in ['record-proofs.py','pr-body.md','readme-ste.log','pr-body-ste.log','native-source-certificate.json','bootstrap.log','oracle-version.txt','hyperbolic-matrix.log','check-embedded.py','embedded-results.json','embedded-results.log','embedded-build.log','embed-stage.log','format-vet.py','format-vet.log','format-final.json','format-check.log','gofmt.log','vet.log']:
 save(name+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
for name in ['bootstrap.json','completed-intermediates.json','stage1.log','stage2.log','stage3.log']:save('bootstrap__'+name+'.gz',gzip.compress((out/'bootstrap'/name).read_bytes(),mtime=0))
save('hyperbolic-matrix-report.json.gz',gzip.compress((out/'hyperbolic-matrix/report.json').read_bytes(),mtime=0))
manifest=dict(source_commit=source,main_base='691b32567f9d21472248fe6c4e44c1197de210ef',public_parent='cc5ca94757fbd90cae2221a991aac37ecfba5b14',prior_capsules=['../final-validation/manifest.json','../current-main/manifest.json'],hyperbolic_issue_closed_upstream=13182,hyperbolic_commands=16,balanced_hyperbolic_censuses=3,embedded_commands=136,compiler=dict(path=str(native),bytes=native.stat().st_size,sha256=sha(native)),bootstrap=boot,artifacts=artifacts)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('PASS',len(artifacts),'artifacts; current public-head integration and upstream hyperbolic coverage')
