from pathlib import Path
import re,json,os,subprocess,hashlib,datetime
p=Path(__file__).parent;r=p/'census-mutable';raw=(p/'ci/driver-130515952623.log').read_text();rows={};lines=[]
for line in raw.splitlines():
 m=re.fullmatch(r'\S+Z ((?:drivers/[^\t ]+|fern\.fern(?:/stage2)?))\t([0-9]+)',line)
 if m:
  name,value=m.group(1),int(m.group(2));assert name not in rows or rows[name]==value;rows[name]=value;lines.append(line)
report=p/'driver-full-report.tsv';report.write_text(''.join(k+'\t'+str(v)+'\n'for k,v in rows.items()));assert len(rows)==14,len(rows)
def values(path):return {a[0]:int(a[1])for line in path.read_text().splitlines()if line.strip()and not line.lstrip().startswith('#')for a in [line.split()]}
a=values(p/'driver-baseline-before-4b.txt');b=values(p/'driver-baseline-after-4b.txt');assert set(a)==set(b)==set(rows)
want={'drivers/checker_codes_run.fern':(3663328,3851760),'drivers/checker_modload_run.fern':(3913968,4147040),'drivers/asm_run.fern':(9577776,10091776),'drivers/asm_ir_run.fern':(10449984,11028400)};assert {k:(a[k],b[k])for k in a if a[k]!=b[k]}==want
for k,(old,new)in want.items():assert rows[k]==new
s={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_publication':'75dbb650647f3e97300c6dc2c9f3f734892f9489','product_source':'4e38d84c7fe34200e300ad55c05ed92d8b67c6b7','job_id':130515952623,'raw_sha256':hashlib.sha256((p/'ci/driver-130515952623.log').read_bytes()).hexdigest(),'report_origin':'Exact integer TSV lines extracted from the complete decoded CI log; not a downloaded artifact.','measured_drivers':14,'changes':want,'source_lines':lines,'runs':[]}
e=os.environ.copy();e.update(FERN_CI_SIZE_GATE_STRICT='1',FERN_SIZE_REPORT_COMPLETE='1',FERN_SIZE_TOLERANCE_PERCENT='5');e.pop('GITHUB_STEP_SUMMARY',None)
for label,baseline,expected in [('old',p/'driver-baseline-before-4b.txt',1),('updated',p/'driver-baseline-after-4b.txt',0)]:
 args=['bash','scripts/ci-check-driver-sizes',str(baseline),str(report)]
 with(p/('driver-replay-'+label+'.stdout')).open('xb')as so,(p/('driver-replay-'+label+'.stderr')).open('xb')as se:x=subprocess.run(args,cwd=r,env=e,stdout=so,stderr=se)
 s['runs'].append({'label':label,'args':args,'exit_code':x.returncode,'expected':expected});assert x.returncode==expected
 text=(p/('driver-replay-'+label+'.stdout')).read_text();assert '14 of 14 baselined drivers measured'in text and'MISSING:'not in text and'UNBASELINED:'not in text
 if label=='old':assert text.count('GREW:')==4
s['exit_code']=0;(p/'driver-bank-replay.json').write_text(json.dumps(s,indent=2)+'\n');print('complete strict replay: old1/updated0, 14/14 rows, four exact changes, unchanged 5%')
