from pathlib import Path
import os,shutil,json,hashlib
p=Path(__file__).parent;c=p/'contract';assert not c.exists();shutil.copytree(p/'source-after/compiler',c,copy_function=os.link)
(c/'ssalive_reference.fern').write_bytes((p/'before-ssalive.fern.txt').read_bytes())
source='''import "./ssa";
import "./ssalive";
import "./ssalive_reference";
'''
for name,typ in [('i32','i32'),('i64','i64'),('bool','boolean')]:
 source+=f'''function same_{name}(a: {typ}[], b: {typ}[]): boolean {{
  if (a.len() != b.len()) {{ return false; }}
  let i: i32 = 0;
  while (i < a.len()) {{ if (a[i] != b[i]) {{ return false; }} i = i + 1; }}
  return true;
}}
'''
source+='''function same_flow(a: ssalive.Flow, b: ssalive_reference.Flow): boolean {
  return a.ok == b.ok && a.why == b.why && a.words == b.words && same_i64(a.live_in, b.live_in) && same_i64(a.live_out, b.live_out) && same_i32(a.slot, b.slot) && same_i32(a.slot_value, b.slot_value) && same_i32(a.at, b.at) && same_bool(a.none, b.none);
}
function block_id(i: i32, sparse: boolean): i32 {
  if (sparse) { return 17 + 3 * i; }
  return i;
}
function graph(n: i32, sparse: boolean, reverse: boolean, phi: boolean): ssa.SFunc {
  let blocks: ssa.SBlock[] = [];
  let k: i32 = 0;
  while (k < n) {
    let i: i32 = k;
    if (reverse) { i = n - 1 - k; }
    let ins = ssa.SInst { kind_tag: 1, result: i, args: [], imm: i, str: "" };
    let preds: i32[] = [];
    if (i > 0) {
      preds = [block_id(i - 1, sparse)];
      if (phi) { ins = ssa.SInst { ...ins, kind_tag: 8, args: [i - 1] }; }
      else { ins = ssa.SInst { ...ins, kind_tag: 9, args: [i - 1, i - 1] }; }
    }
    let term = ssa.STerm { kind_tag: 1, cond: 0, target: 0, t: 0, f: 0, value: i };
    if (i + 1 < n) { term = ssa.STerm { ...term, kind_tag: 2, target: block_id(i + 1, sparse) }; }
    blocks = blocks.append(ssa.SBlock { id: block_id(i, sparse), insts: [ins], preds: preds, term: term });
    k = k + 1;
  }
  return ssa.SFunc { name: "offset_contract", nparams: 0, nvals: n, blocks: blocks, entry: block_id(0, sparse), takes_env: false };
}
function check(f: ssa.SFunc, deps: i32[][]): boolean {
  let before: string = ssa.print_func(f);
  let old = ssalive_reference.compute(f, deps);
  let result = ssalive.compute(f, deps);
  if (!same_flow(result, old)) { return false; }
  if (result.ok) {
    if (!same_flow(ssalive.compute_checked(f, deps), ssalive_reference.compute_checked(f, deps))) { return false; }
    let divisor: i32 = 1;
    while (divisor <= 3) {
      let keep: boolean[] = [];
      let i: i32 = 0;
      while (i < f.nvals) { keep = keep.append(i % divisor == 0); i = i + 1; }
      if (!same_flow(ssalive.compute_kept(f, deps, keep), ssalive_reference.compute_kept(f, deps, keep))) { return false; }
      divisor = divisor + 1;
    }
  }
  return ssa.print_func(f) == before;
}
function main(): i32 {
  let cases: i32 = 0;
  for n in [0, 1, 2, 3, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65] {
    for sparse in [false, true] {
      for reverse in [false, true] {
        for phi in [false, true] {
          for dependency in [false, true] {
            let f = graph(n, sparse, reverse, phi);
            let deps: i32[][] = [];
            let i: i32 = 0;
            while (i < n) {
              let values: i32[] = [];
              if (dependency && i > 0) { values = [i - 1]; }
              deps = deps.append(values);
              i = i + 1;
            }
            if (!check(f, deps)) { print("flow mismatch"); return 1; }
            cases = cases + 1;
          }
        }
      }
    }
  }
  print(cases);
  return 0;
}
'''
(c/'offset_contract.fern').write_text(source)
(p/'contract-provenance.json').write_text(json.dumps(dict(cases=256,targets=3,comparison='Every Flow field for compute, compute_checked and three keep masks; input SSA alias unchanged.',graphs='Chains, one-predecessor phis, reversed storage, dense/sparse ids, dependencies, absent entry, offset table growth boundaries.',limits='Synthetic SSA helper graphs, not full typed program corpus. Real lifetime and replay suites remain necessary.'),indent=2)+'\n')
print('contract source prepared; no extra build launched')
