from pathlib import Path
import gzip,hashlib,io,json,tarfile
src=Path('/workspace/lang-issue-work/perf-4412/liveness-offset-candidate')
dest=Path('/workspace/lang-perf-4412/docs/benchmarks/liveness-offset-rejected-2026-10-28');dest.mkdir(exist_ok=True)
rows=[]
def save(name,raw):
 out=dest/(name+'.gz');packed=gzip.compress(raw,compresslevel=9,mtime=0);out.write_bytes(packed);assert gzip.decompress(out.read_bytes())==raw
 rows.append(dict(archive=out.name,raw_name=name,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),archive_bytes=len(packed),archive_sha256=hashlib.sha256(packed).hexdigest()))
for f in sorted(src.iterdir()):
 if f.is_file():save(f.name,f.read_bytes())
for version in ['before','after']:
 folder=src/version
 for f in sorted(folder.iterdir()):
  if not f.is_file() or f.name in ['stage2','stage2-g.gz']:continue
  name=version+'-'+f.name
  if f.suffix=='.gz':save(name[:-3],gzip.decompress(f.read_bytes()))
  else:save(name,f.read_bytes())
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w') as tar:
  root=src/('source-'+version)
  for f in sorted(root.rglob('*')):
   if f.is_file():tar.add(f,arcname=str(f.relative_to(root)),recursive=False)
 save('source-'+version+'.tar',buffer.getvalue())
for name in ['current-cli-info.json','current-producer.json']:
 save('producer-'+name,(src.parent/'main-b024-merge'/name).read_bytes())
(dest/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
print('verified',len(rows),'archives',sum(r['archive_bytes'] for r in rows),'bytes')
