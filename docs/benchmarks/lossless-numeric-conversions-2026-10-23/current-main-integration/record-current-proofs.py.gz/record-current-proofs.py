from pathlib import Path
import subprocess,json,hashlib,gzip,collections,io,tarfile
root=Path('/workspace/lang-lossless-widening-publish');out=Path('/workspace/scratch/lang-lossless-widening/current-main-integration');compiled='ea25564792a15bd72354c56093dd320d1c7947f0'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
core=git('rev-parse','HEAD').decode().strip();base=git('rev-parse','fix/doc-paths-publish').decode().strip();assert not git('status','--porcelain')
assert not git('diff',compiled,core,'--','compiler','internal/stdlib','*.go','conformance','spec','site','.github')
boot=json.loads((out/'bootstrap-range-fixed/bootstrap.json').read_text());assert boot['source_git']==compiled and boot['fixedpoint'];assert boot['stages'][0]['producer_sha256']=='9caea1e43f0942ed9ba6fa432fcc29d9a57fce1fe35ff97716def7c2443c4faa';assert boot['stages'][1]['sha256']==boot['stages'][2]['sha256']=='7d8c54ca815ab8be6b217c34aae334d8124142c56843fa9de155555277c7c818'
files=[];digest=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();digest.update(n.encode()+b'\0'+data+b'\0');files.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert digest.hexdigest()==boot['source_sha256']
suites=[]
for name,count,skips,packages in [('go-regressions-final',2436,3,3),('numeric-properties-range-fixed',1023,0,1),('guards-range-fixed',4,0,1)]:
 es=[json.loads(s)for s in(out/(name+'.jsonl')).read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);assert c['run']==count and c['skip']==skips and not c['fail'];assert len([e for e in es if e['Action']=='pass'and'Test'not in e])==packages and es[-1]['Action']=='pass';suites.append({'suite':name,'cases':count,'skips':skips,'packages':packages})
 if name.startswith('numeric-properties'):
  leaves=collections.Counter(e['Test'].split('/')[0]for e in es if e['Action']=='run'and e.get('Test','').split('/')[-1]in['x86_64','arm64-linux','wasm32-wasi']);assert dict(leaves)=={'TestNumericProperty_Differential':180,'TestNumericProperty_FloatMathExact':504,'TestNumericProperty_Regressions':81},leaves
matrix=json.loads((out/'committed-matrix-results.json').read_text());assert matrix['core_commit']==compiled and not matrix['failures']and len(matrix['commands'])==158;assert all(r['pass_']for r in matrix['commands']);cs=[r['census']for r in matrix['commands']if'census'in r];assert len(cs)==24 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
assert matrix['binaries'][str(out/'bootstrap-range-fixed/stage3')]['sha256']==boot['stages'][2]['sha256']
for n in ['go','self']:
 rows=json.loads((out/(n+'-checks.json')).read_text());assert len(rows)==43 and all(r['pass_']for r in rows)
trace=json.loads((out/'fixture-census/report.json').read_text());assert trace['complete']and len(trace['runs'])==4 and all(r['unpaired_allocations']==0 for r in trace['runs']);assert any(r['trace_events']>0 for r in trace['runs']);assert all((root/'conformance/cases'/r['fixture']/'main.fern').read_bytes() and hashlib.sha256((root/'conformance/cases'/r['fixture']/'main.fern').read_bytes()).hexdigest()==r['source_sha256']for r in trace['runs'])
assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for n in ['format.log','gofmt.log','vet-final.log','range-fix-check.log']:assert not(out/n).read_bytes(),n
assert json.loads((out/'format.json').read_text())=={'files':490,'exit':0}
version=(out/'oracle-range-fixed-version.txt').read_text();assert 'vcs.revision='+compiled in version and'vcs.modified=false'in version
baseline=json.loads((out/'predecessor-baseline.json').read_text());assert [r['exit']for r in baseline['runs']]==[1,1,0,0]and baseline['stdlib_unchanged']
dest=root/'docs/benchmarks/lossless-numeric-conversions-2026-10-23/current-main-integration';dest.mkdir();artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def take(n):save(n.replace('/','-')+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');save('source-identity.json',json.dumps({'packaged_source':core,'compiled_and_measured_source':compiled,'dependency_base':base,'only_dependency_proof_documents_changed_after_measurement':core!=compiled,'native_source_sha256':digest.hexdigest(),'go_oracle_sha256':hashlib.sha256((out/'oracle-range-fixed').read_bytes()).hexdigest()},indent=2).encode()+b'\n')
patch=git('diff','--binary',base,core);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['record-current-proofs.py','bootstrap-range-fixed/bootstrap.json','bootstrap-range-fixed/stage1.log','bootstrap-range-fixed/stage2.log','bootstrap-range-fixed/stage3.log','go-regressions-final.jsonl','numeric-properties-range-fixed.jsonl','guards-range-fixed.jsonl','oracle-range-fixed-version.txt','committed-matrix-results.json','matrix.py','matrix.log','check-matrix.py','go-checks.json','self-checks.json','go-checks.log','self-checks.log','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','format.json','format.log','gofmt.log','vet-final.log','predecessor-baseline.json','fixture-census.py','fixture-census.log','fixture-census/report.json']:take(n)
stream=io.BytesIO();count=0
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for p in sorted((out/'fixture-census').glob('*.gz')):
  data=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));count+=1
assert count==16;save('fixture-pointer-trace-logs.tar.gz',stream.getvalue())
(dest/'artifacts.json').write_text(json.dumps({'source_commit':core,'compiled_source':compiled,'dependency_base':base,'suites':suites,'matrix_commands':158,'balanced_matrix_executions':24,'checker_cases_per_frontend':43,'backend_property_comparisons':765,'pointer_census_runs':4,'native_sha256':boot['stages'][2]['sha256'],'artifacts':artifacts},indent=2)+'\n')
(dest/'README.md').write_text('''# Numeric widening checks against the current compiler

The compiled and measured source is `ea25564792a15bd72354c56093dd320d1c7947f0`.
The source identity record names the packaged commit and dependency base.
Only dependency proof documents changed after measurement.
The compiler, Go code and test inputs retain their measured bytes.

All 2433 applicable Go cases pass across three packages. Three synthetic-AST cases skip.
All 1023 numeric property test cases pass without failures or skips.
They contain 765 backend comparisons: 180 differential, 504 exact float math and 81 regression checks.
All four feature census and complexity guard results pass with the limits unchanged.

Each frontend passes all 43 conversion checks.
The matrix passes 158 commands with eight Darwin builds and 24 balanced execution allocation checks.
Both formatters agree and preserve the result after another format pass.
Both predecessor checkers reject the representative conversion. Both candidates accept the same source.

The two new runnable fixtures have zero unpaired allocations with both compiler producers.
All four pointer traces match allocations and frees by address.
The scalar-only fixture has zero trace events. The other fixture proves that the trace is active.

The released stage0 pin produces byte-identical stages 2 and 3.
Their SHA-256 is `7d8c54ca815ab8be6b217c34aae334d8124142c56843fa9de155555277c7c818`.
All 11 strict driver size gates pass without baseline changes.
All 490 compiler and library Fern files pass the canonical format check.
Go format and Go vet pass.
''')
print('Verified',len(artifacts),'artifacts;',len(files),'native source files;',sum(s['cases']for s in suites),'test cases')
