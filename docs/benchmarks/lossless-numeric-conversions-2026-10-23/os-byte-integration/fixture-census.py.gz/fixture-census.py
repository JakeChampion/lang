from pathlib import Path
import collections, gzip, hashlib, json, os, re, subprocess, time

root = Path('/workspace/lang-lossless-widening-publish')
out = Path('/workspace/scratch/lang-lossless-widening/os-byte-integration/fixture-census')
out.mkdir(exist_ok=False)
groups = {'widening': ('/workspace/scratch/lang-lossless-widening/os-byte-integration/bootstrap', ['numeric_lossless_widening', 'literal_local_read_at_two_widths'])}

env = {k: v for k, v in os.environ.items() if not k.startswith('FERN_')}
env['FERN_RC_TRACE'] = '1'
trace = re.compile(r'^rctrace ([af]) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16})$')
rows = []
for family, (bootstrap, names) in groups.items():
    for name in names:
        folder = root / 'conformance/cases' / name
        source = folder / 'main.fern'
        expected = int((folder / 'expected.exit').read_text()) if (folder / 'expected.exit').exists() else 0
        for stage in ['stage1', 'stage3']:
            producer = Path(bootstrap) / stage
            binary = out / (name + '-' + stage)
            args = [str(producer), '-target', 'x86-64-linux', '-o', str(binary), str(source), str(root / 'internal/stdlib')]
            start = time.monotonic()
            build = subprocess.run(args, cwd=root, env=env, capture_output=True, timeout=180)
            (out / (name + '-' + stage + '-build.stdout.gz')).write_bytes(gzip.compress(build.stdout, mtime=0))
            (out / (name + '-' + stage + '-build.stderr.gz')).write_bytes(gzip.compress(build.stderr, mtime=0))
            assert build.returncode == 0, (name, stage, build.stderr)
            run = subprocess.run([str(binary)], cwd=root, capture_output=True, timeout=180)
            assert run.returncode == expected, (name, stage, run.returncode, expected)
            stdout = folder / 'expected.stdout'
            if stdout.exists():
                assert run.stdout == stdout.read_bytes(), (name, stage, run.stdout)
            live = collections.Counter()
            events = 0
            for line in run.stderr.decode().splitlines():
                match = trace.fullmatch(line)
                if match:
                    events += 1
                    live[match[2]] += 1 if match[1] == 'a' else -1
            unpaired = sum(n for n in live.values() if n > 0)
            assert unpaired == 0 and all(n == 0 for n in live.values()), (name, stage, live)
            for channel, data in [('stdout', run.stdout), ('stderr', run.stderr)]:
                (out / (name + '-' + stage + '.' + channel + '.gz')).write_bytes(gzip.compress(data, mtime=0))
            row = {'family': family, 'fixture': name, 'producer_stage': stage, 'producer_sha256': hashlib.sha256(producer.read_bytes()).hexdigest(), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'arguments': args, 'build_exit': build.returncode, 'exit': run.returncode, 'trace_events': events, 'unpaired_allocations': unpaired, 'seconds': time.monotonic() - start}
            rows.append(row)
            (out / 'report.json').write_text(json.dumps({'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'runs': rows}, indent=2) + '\n')
            print(family, name, stage, events, unpaired, flush=True)
assert len(rows) == 4
assert all(any(r['trace_events'] > 0 for r in rows if r['family'] == family) for family in groups)
(out / 'report.json').write_text(json.dumps({'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'complete': True, 'runs': rows}, indent=2) + '\n')
print('PASS all four traced fixture runs', flush=True)
