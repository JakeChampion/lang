from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io,re
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/equality-followup');prior=Path('/workspace/scratch/lang-lossless-widening/container-branch-followup');source='7f1614931b0da0849f93fd55046d82c31db77ed8';base='6b6b1f1fac1141c24adcb9239d6cc409df9cfb6b';dest=root/'docs/benchmarks/lossless-numeric-conversions-2026-10-23/branch-context-followup'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
boot=json.loads((out/'bootstrap-final/bootstrap.json').read_text());native=sha(out/'bootstrap-final/stage3');assert boot['source_git']==source and boot['fixedpoint'] and native==sha(out/'bootstrap-final/stage2')==boot['stages'][-1]['sha256']=='c7c5b910f31a3b89cabd5d8947102506df4d5c3d17e25442a10bafcbc1fbaf6a';assert sha(out/'compiler-common')==native
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 b=(root/n).read_bytes();h.update(n.encode()+b'\0'+b+b'\0');files.append(dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
assert h.hexdigest()==boot['source_sha256']
tests=json.loads((out/'validation-inventory.json').read_text())
for record in tests:
 es=[json.loads(l)for l in Path(record['file']).read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es if e.get('Test'));term=[e for e in es if not e.get('Test')and e['Action']in['pass','fail','skip']];assert c['run']==record['runs']and c['pass']==record['passes']and c['skip']==record['skips']and not c['fail']and len(term)==record['packages']and all(e['Action']=='pass'for e in term)
assert tests[0]['runs']==4858 and tests[1]['runs']==51 and tests[2]['passes']==3002 and tests[2]['skips']==19 and tests[3]['passes']==405 and tests[4]['passes']==2290 and tests[4]['packages']==3
cert=json.loads((out/'go-source-certificate.json').read_text());assert not git('diff','--name-only',cert['recorded_test_source'],source,'--',*cert['paths'])
assert not git('diff','--name-only','19f0d5ce780724f0805eb20baa9a8cf4113ba6dd',source,'--','*.go')
version=(out/'oracle-final-version.txt').read_text();assert 'vcs.revision='+source in version and'vcs.modified=false'in version
for p in [out/'format-final.log',prior/'gofmt-final.log',prior/'vet-final.log']:assert not p.read_bytes()
assert json.loads((out/'format-final.json').read_text())==dict(files=1205,exit=0)
assert 'Every driver measured here is within 5%'in(out/'final-sizes/driver-gate.log').read_text()
m=json.loads((prior/'context-runtime-final-results.json').read_text());assert m['complete']and m['source_commit']==source and m['compiler_sha256']==native and m['oracle_sha256']==sha(out/'oracle-final')and len(m['commands'])==51
censuses=[r['census']for r in m['commands']if'census'in r];assert len(censuses)==3 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in censuses)
patch=git('diff','--binary',base,source);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 (dest/n).write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(p,prefix=''):
 p=Path(p);anchor=out if p.is_relative_to(out)else prior;n=prefix+str(p.relative_to(anchor)).replace('/','--')+'.gz';save(n,gzip.compress(p.read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');save('change.patch.gz',gzip.compress(patch,mtime=0));save('README.md',(prior/'README.md').read_bytes())
for n in ['bootstrap-final/bootstrap.json','bootstrap-final/stage1.log','bootstrap-final/stage2.log','bootstrap-final/stage3.log','validation-inventory.json','go-source-certificate.json','native-final-regressions.jsonl','fixture-and-diagnostics-final.jsonl','oracle-final-version.txt','format-final.json','format-final.log','final-sizes/check-sizes.py','final-sizes/driver-builds.json','final-sizes/driver-sizes.txt','final-sizes/driver-gate.log','final-sizes/sizes.log','context-runtime-final-matrix.py','context-runtime-final-matrix.log','fixture-runtime-results.json','numeric-comparison-matrix.json','readme-ste.log','record-proofs.py']:take(out/n)
for n in ['native-production-corpus-fast.jsonl','mutants-and-fixtures-fast.jsonl','go-regressions-length-fixed.jsonl','diagnostic-goldens-final.jsonl','context-runtime-final-results.json','gofmt-final.log','vet-final.log','comparison-probes.json','native-production-corpus.jsonl','mutants-and-fixtures.jsonl']:take(prior/n,'scoped--')
excerpts=[]
for p in sorted(prior.glob('ci-failure-*.log')):
 lines=[]
 for line in p.read_text().splitlines():
  line=re.sub(r'^\d{4}-\d\d-\d\dT\S+ ','',line)
  if '--- FAIL:'in line or re.search(r'test.go:\d+:.*(?:expected|want|self-host|the Go checker|produced graphs|interp\(|answered)',line):
   if line not in lines:lines.append(line)
 excerpts.append(dict(job=int(p.stem.split('-')[-1]),run=40123841414,source=base,url='https://github.com/JakeChampion/lang/actions/runs/40123841414/job/'+p.stem.split('-')[-1],failure_lines=lines[:45]))
save('ci-failure-excerpts.json',json.dumps(excerpts,indent=2).encode()+b'\n')
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as tar:
 for folder,prefix in [(prior/'context-runtime-final','context-runtime'),(out/'numeric-comparison-matrix','numeric-comparisons')]:
  for p in sorted(folder.iterdir()):
   if not p.is_file()or p.suffix!='.fern':continue
   data=p.read_bytes();n=prefix+'/'+p.name;ti=tarfile.TarInfo(n);ti.size=len(data);ti.mode=0o644;ti.mtime=0;tar.addfile(ti,io.BytesIO(data));inputs.append(dict(path=n,sha256=hashlib.sha256(data).hexdigest()))
save('inputs.tar.gz',stream.getvalue());save('artifacts.json',json.dumps(dict(source=source,base=base,source_sha256=h.hexdigest(),native_sha256=native,oracle_sha256=sha(out/'oracle-final'),tests=tests,cli_commands=51,balanced_censuses=3,driver_count=11,format_files=1205,inputs=inputs,artifacts=artifacts,scope_note='The broad corpus and mutation runs retain source 19f0. Final focused tests and fixtures use source 7f161. The Go source certificate verifies unchanged inputs.',darwin='Built but not executed locally.',wasi_skips='Nineteen corpus cases require capabilities outside the WASI profile.'),indent=2).encode()+b'\n')
print('Saved',len(artifacts),'artifacts and',len(inputs),'fixture inputs')
