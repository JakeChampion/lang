from pathlib import Path
import subprocess,json,hashlib,re,os,time
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/printer-corpus-followup');work=out/'context-runtime-final';work.mkdir(exist_ok=False)
native=Path('/workspace/scratch/lang-lossless-widening/void-lambda-followup/bootstrap-final/stage3');oracle=Path('/workspace/scratch/lang-lossless-widening/printer-corpus-followup/oracle-current');lib=root/'internal/stdlib';rows=[]
report={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'compiler_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'commands':rows,'complete':False}
def save():(out/'context-runtime-final-results.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,codes=None,census=False):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(os.environ,FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_STRICT_IR='1'),capture_output=True,text=True,timeout=180);row={'name':name,'arguments':list(map(str,args)),'exit':r.returncode,'seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr};rows.append(row);save()
 if codes is None:assert r.returncode==0 and not r.stdout,row
 else:assert r.returncode!=0 and sorted(set(re.findall(r'error\[(E\d{3})\]',r.stderr)))==codes,row
 if census:
  m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m and m[1]==m[2] and m[3]=='0',row;row['census']={'allocs':int(m[1]),'frees':int(m[2]),'live_bytes':int(m[3])};save()
 print(name,'PASS',flush=True)
positive='''enum Bx[T] { Full(T), Empty }
function get(b: Bx[i64]): i64 { match (b) { Full(v) => { return v; }, Empty => { return 0; } } }
function variable(c: boolean, n: i32): i64 { let b: Bx[i64] = if (c) { Full(1) } else { Full(n) }; return get(b); }
function argument(c: boolean, n: i32): i64 { return get(if (c) { Full(1) } else { Full(n) }); }
function reversed(c: boolean, n: i32): i64 { return get(if (c) { Full(n) } else { Full(1) }); }
function result(k: i32, n: i32): Bx[i64] { return match (k) { 0 => Full(1), _ => Full(n) }; }
function main(): i32 {
  let n: i32 = 2000000000;
  if (variable(false, n) + argument(false, n) != 4000000000i64) { return 1; }
  if (variable(true, n) != 1 || argument(true, n) != 1) { return 2; }
  if (reversed(true, n) != n || reversed(false, n) != 1) { return 3; }
  if (get(result(0, n)) != 1 || get(result(1, n)) != n) { return 4; }
  return 0;
}
'''
p=work/'fresh-branches.fern';p.write_text(positive)
for tag,cli in [('go',oracle),('native',native)]:
 for mode in ['-check','-interp']:run('fresh-'+tag+mode,[cli,mode,p,lib])
for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run']),('arm64-darwin',None)]:
 dest=work/('fresh-'+target);args=[native,'-target',target,'-o',dest]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[p,lib];run('fresh-build-'+target,args)
 if runner is not None:run('fresh-run-'+target,runner+[dest],census=True)
 else:assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe')
for name,body in [('if-literal-first','if (c) { Some(1) } else { held }'),('if-stored-first','if (c) { held } else { Some(n) }'),('match-literal-first','match (c) { true => Some(1), false => held }'),('match-stored-first','match (c) { true => held, false => Some(1) }')]:
 p=work/(name+'.fern');p.write_text('function f(c: boolean, n: i32): Option[i64] { let held: Option[i32] = Some(n); return '+body+'; } function main(): i32 { return 0; }')
 for tag,cli in [('go',oracle),('native',native)]:
  for mode in ['-check','-interp']:run(name+'-'+tag+mode,[cli,mode,p,lib],codes=['E002'])
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=work/(name+'-'+target);assert not dest.exists();run(name+'-build-'+target,[native,'-target',target,'-o',dest,p,lib],codes=['E002']);assert not dest.exists()
for name,src,codes in [('array-primary','function main(): i32 { let xs: f64[] = [1, "x"]; return 0; }',['E034']),('array-destination','function main(): i32 { let xs: string[] = [1, "x"]; return xs.len(); }',['E003','E034'])]:
 p=work/(name+'.fern');p.write_text(src)
 for tag,cli in [('go',oracle),('native',native)]:
  for mode in ['-check','-interp']:run(name+'-'+tag+mode,[cli,mode,p,lib],codes=codes)
report['complete']=True;save();assert len(rows)==51;print('PASS',len(rows),'commands',flush=True)
