from pathlib import Path
import subprocess,json,collections,hashlib,gzip,re
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/printer-corpus-followup');source='05d1428d03ff959c91f356d188d8f938652fcfb3';base='1a85a71b03e5d800e155d4b43ac4fd54084678cf';dest=root/'docs/benchmarks/lossless-numeric-conversions-2026-10-23/printer-corpus-followup'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
cert=json.loads((out/'native-source-certificate.json').read_text());assert cert['current_source']==source and not git('diff','--name-only',cert['recorded_source'],source,'--',*cert['paths']);assert sha(Path(cert['compiler']))==cert['compiler_sha256']
assert not git('diff','--name-only','e3cff7a18658fcce0c9e12b307d962d2c5c1354b',source,'--','*.go',':(exclude)*_test.go')
records=json.loads((out/'validation-inventory.json').read_text())
for record in records:
 es=[json.loads(l)for l in(out/record['file']).read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es if e.get('Test'));ps=[e for e in es if not e.get('Test')and e['Action']in['pass','fail','skip']];assert c['run']==c['pass']==record['cases']and not c['fail']and not c['skip']and len(ps)==record['packages']and all(e['Action']=='pass'for e in ps)
shards=[]
for index in range(4):
 p=out/f'printer-shard-{index}.jsonl';es=[json.loads(l)for l in p.read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es if e.get('Test'));ps=[e for e in es if not e.get('Test')and e['Action']in['pass','fail','skip']];assert c['run']==c['pass']==269 and not c['fail']and not c['skip']and len(ps)==1 and ps[0]['Action']=='pass',(index,c,ps)
 checked=[int(m[1])for e in es if(m:=re.search(r'checked (\d+) formatted programs',e.get('Output','')))];assert len(checked)==1 and checked[0]>=75
 inventory=[tuple(map(int,m.groups()))for e in es if(m:=re.search(r'corpus shard (\d+)/(\d+): (\d+) of (\d+) files',e.get('Output','')))];assert len(inventory)==5 and all(v==(index,4,258,1032)for v in inventory)
 shards.append(dict(index=index,count=4,file=p.name,cases=269,skips=0,packages=1,files=258,total_files=1032,checked=checked[0],elapsed=ps[0].get('Elapsed')))
assert sum(r['checked']for r in shards)>=300
matrix=json.loads((out/'context-runtime-final-results.json').read_text());assert matrix['source_commit']==source and matrix['complete']and len(matrix['commands'])==51 and matrix['compiler_sha256']==cert['compiler_sha256']and matrix['oracle_sha256']==sha(out/'oracle-current');cs=[r['census']for r in matrix['commands']if'census'in r];assert len(cs)==3 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
version=(out/'oracle-current-version.txt').read_text();assert 'vcs.revision='+source in version and'vcs.modified=false'in version
assert not(out/'actionlint.log').read_bytes();assert 'Result: 0 errors, 0 warnings.'in(out/'readme-ste.log').read_text()
before=[list(map(int,l.split()))for l in(out/'field-benchmark/before.txt').read_text().splitlines()];after=[list(map(int,l.split()))for l in(out/'field-benchmark/after.txt').read_text().splitlines()];assert len(before)==len(after)==3 and [r[0]for r in before]==[32,128,512]and all(a[0]==b[0]==a[2]==b[2]for a,b in zip(before,after))
patch=git('diff','--binary',base,source);subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True)
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('change.patch.gz',gzip.compress(patch,mtime=0));save('shard-results.json',json.dumps(shards,indent=2).encode()+b'\n')
for name in ['validation-inventory.json','native-source-certificate.json','go-regressions-final.jsonl','field-read-tests.jsonl','shard-unit-tests-final.jsonl','shard-source-lint-final.jsonl','printer-shard-0.jsonl','printer-shard-1.jsonl','printer-shard-2.jsonl','printer-shard-3.jsonl','oracle-current-version.txt','context-runtime-final-matrix.py','context-runtime-final-results.json','context-runtime-final-matrix.log','field-benchmark/main.go','field-benchmark/go.mod','field-benchmark/before-overlay.json','field-benchmark/call_arg_deaths-before.go.txt','field-benchmark/before.txt','field-benchmark/after.txt','profile-probe/main.go','profile-probe/go.mod','profile-probe/sample-before.cpu','profile-probe/sample-before.log','profile-probe/sample-before-top.txt','profile-probe/sample-before-cumulative.txt','profile-probe/arg-deaths-list.txt','actionlint.log','readme-ste.log','record-proofs.py']:
 save(name.replace('/','--')+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
save('ci-unit-heavy-failure.log.gz',gzip.compress((out.parent/'void-lambda-followup/ci-unit-heavy-failure.log').read_bytes(),mtime=0))
(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=source,base=base,native_source=cert,tests=records,shards=shards,matrix_commands=51,balanced_censuses=3,field_benchmark_before=before,field_benchmark_after=after,artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(shards=shards,artifacts=len(artifacts))))
