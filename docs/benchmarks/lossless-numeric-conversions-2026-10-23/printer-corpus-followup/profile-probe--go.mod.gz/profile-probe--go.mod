module github.com/jakechampion/lang/profileprobe

go 1.26

require github.com/jakechampion/lang v0.0.0
replace github.com/jakechampion/lang => /workspace/lang-cohesion-ci-refresh
