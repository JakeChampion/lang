from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/hex-context-followup');core='059eb35055cde2b94918b4e8ba68b0b2580b06fd';compiler='805b03ab74660e5a511d86d69131b050a75904a4';base='ff87e232d6c0f2620125e2f2349047685dce2e7f';dest=root/'docs/benchmarks/lossless-numeric-conversions-2026-10-23/hex-context-followup'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core and not git('status','--porcelain');assert not git('diff',compiler,core,'--','compiler','internal/stdlib')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==compiler and boot['fixedpoint'];native=boot['stages'][-1]['sha256'];assert native==boot['stages'][1]['sha256']=='5e515d0038b8203a8f2a1457711e345886fa036ae490481b58f30873ec2c13a2'
source=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 b=(root/n).read_bytes();h.update(n.encode()+b'\0'+b+b'\0');source.append(dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
assert h.hexdigest()==boot['source_sha256'];tests=[]
for n,count,skips in [('hex-fixture-enabled.jsonl',13,0),('native-numeric-regressions.jsonl',163,0),('go-checker.jsonl',1869,0),('numeric-properties-and-consumer.jsonl',1024,1),('updated-consumer-and-diagnostics-final.jsonl',42,0),('native-reader-regressions.jsonl',32,0)]:
 es=[json.loads(s)for s in(out/n).read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);p=[e for e in es if'Test'not in e and e['Action']in['pass','fail']];assert c['run']==count and c['skip']==skips and not c['fail']and len(p)==1 and p[0]['Action']=='pass';tests.append(dict(file=n,runs=count,skips=skips,packages=1))
for n in ['format-final.log','gofmt.log','vet.log']:assert not(out/n).read_bytes()
assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text();assert 'Every metric is within tolerance'in(out/'ci-x86-replayed-gate.log').read_text()
static=json.loads((out/'static-corpus.json').read_text());assert static['complete']and not static['failures']and len(static['commands'])==78 and static['source_commit']==compiler
m=json.loads((out/'matrix.json').read_text());m2=json.loads((out/'hex-and-consumers.json').read_text());assert m['complete']and m2['complete']and len(m['runs'])==33 and len(m2['commands'])==17
cs=[r['census']for r in m['runs']+m2['commands']if'census'in r];assert len(cs)==12 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
version=(out/'oracle-final-version.txt').read_text();assert 'vcs.revision='+core in version and'vcs.modified=false'in version
cert=json.loads((out/'consumer-name-certificate.json').read_text());assert len(cert)==9 and all(r['only_bare_byte_reader_name']for r in cert)
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n.replace('/','-')+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(source,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','hex-fixture-enabled.jsonl','native-numeric-regressions.jsonl','go-checker.jsonl','numeric-properties-and-consumer.jsonl','updated-consumer-and-diagnostics-final.jsonl','native-reader-regressions.jsonl','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','sizes.log','matrix.json','cast-matrix.py','hex-and-consumers.py','hex-and-consumers.json','consumer-name-certificate.json','static-corpus.py','static-corpus.json','ci-x86-report.txt','ci-x86-replayed-gate.log','ci-hex-fixture.log','ci-stale-consumer.log','format-final.json','format-final.log','gofmt.log','vet.log','oracle-final-version.txt','ste.log','record-proofs.py']:take(n)
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as tar:
 for folder in ['static-corpus','matrix','hex-and-consumers']:
  for p in sorted((out/folder).glob('*')):
   if not p.is_file()or p.suffix not in['.gz','.fern','.stdout','.stderr']:continue
   data=p.read_bytes();n=str(p.relative_to(out));ti=tarfile.TarInfo(n);ti.size=len(data);ti.mode=0o644;ti.mtime=0;tar.addfile(ti,io.BytesIO(data));inputs.append(n)
save('inputs-logs.tar.gz',stream.getvalue());(dest/'README.md').write_bytes((out/'README.md').read_bytes());(dest/'artifacts.json').write_text(json.dumps(dict(compiler_source=compiler,test_source=core,dependency_base=base,source_sha256=h.hexdigest(),native_sha256=native,tests=tests,commands=50,balanced_censuses=12,static_rows=78,inputs_logs=len(inputs),ktls_runtime_skip='The local kernel offers no TLS upper-layer protocol; generated consumers were checked and compiled.',earlier_x86_report=dict(run=40120850761,public_source='ec1d8b869f55ea93802f868cca4ed33e993051df',artifact=12571667691,sha256='8c3b6f482f8168de3de73aa89507f321764a972da341ef91e52c03a4018c8979'),artifacts=artifacts),indent=2)+'\n');print('Saved',len(artifacts),'artifacts;',len(inputs),'inputs and logs')
