from pathlib import Path
import subprocess,json,re,os,hashlib
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/hex-context-followup');work=out/'hex-and-consumers';work.mkdir(exist_ok=False);native=out/'bootstrap/stage3';oracle=out/'oracle';rows=[];env=dict(os.environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1');report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compiler_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),oracle_sha256=hashlib.sha256(oracle.read_bytes()).hexdigest(),commands=rows)
def run(name,args,census=False):
 p=subprocess.run(list(map(str,args)),cwd=root,env=env,capture_output=True,text=True,timeout=180);row=dict(name=name,arguments=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr);rows.append(row);(out/'hex-and-consumers.json').write_text(json.dumps(report,indent=2)+'\n');assert p.returncode==0 and not p.stdout,row
 if census:
  m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);assert m and m[1]==m[2]and m[3]=='0',row;row['census']=dict(allocs=int(m[1]),frees=int(m[2]),live_bytes=0)
src=root/'conformance/cases/hex_literal_width/main.fern'
for tag,cli in [('go',oracle),('native',native)]:
 for mode in ['-check','-interp']:run('hex-'+tag+mode,[cli,mode,src,root/'internal/stdlib'])
for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run']),('arm64-darwin',None)]:
 binary=work/('hex-'+target);args=[native,'-target',target,'-o',binary]
 if target=='wasm32-wasi':args+=['-emit','command-module']
 run('hex-build-'+target,args+[src,root/'internal/stdlib'])
 if runner is not None:run('hex-run-'+target,runner+[binary],True)
for name,path,pattern in [('tls','internal/testing/e2e/serve_tls_test.go',r'const serveTLSSource = `([^`]*)`'),('stream','internal/testing/e2eharness/serve_stream_bodies.go',r'fmt.Sprintf\(`([^`]*)`')]:
 text=re.search(pattern,(root/path).read_text())[1];assert 'let s: ByteStream = req.body_stream();'in text;src=work/(name+'.fern');src.write_text(text)
 for tag,cli in [('go',oracle),('native',native)]:run(name+'-'+tag+'-check',[cli,'-check',src,root/'internal/stdlib'])
 run(name+'-build',[native,'-target','x86-64-linux','-o',work/(name+'-consumer'),src,root/'internal/stdlib'])
assert len(rows)==17;report['complete']=True;(out/'hex-and-consumers.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS 17 commands, 3 balanced runtime counts; consumer programs were compiled')
