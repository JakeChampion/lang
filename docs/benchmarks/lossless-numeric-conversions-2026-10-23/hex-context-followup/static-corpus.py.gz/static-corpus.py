from pathlib import Path
import subprocess,json,hashlib,gzip,re,os
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/hex-context-followup');work=out/'static-corpus';work.mkdir(exist_ok=False);cli=out/'bootstrap/stage3';env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};baseline={}
for line in(root/'.github/perf-baseline.txt').read_text().splitlines():
 f=line.split()
 if len(f)>1 and not line.startswith('#'):baseline[f[0]]=(int(f[1]),float(f[2])if len(f)>2 else 1.0)
rows=[];report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compiler_sha256=hashlib.sha256(cli.read_bytes()).hexdigest(),commands=rows,failures=[])
for arch,target in [('x86_64','x86-64-linux'),('aarch64','arm64-linux')]:
 for src in sorted((root/'bench').glob('*.fern')):
  args=[str(cli),'-target',target,str(src),str(root/'internal/stdlib')];p=subprocess.run(args,cwd=root,env=env,capture_output=True,check=True,timeout=120);name=arch+'/'+src.stem+'.text';value=sum(bool(re.match(rb'^[ \t\r\v\f]',line))for line in p.stdout.splitlines());b,t=baseline[name];percent=100*(value/b-1);row=dict(metric=name,value=value,baseline=b,tolerance=t,percent=percent,args=args,assembly_sha256=hashlib.sha256(p.stdout).hexdigest(),source_sha256=hashlib.sha256(src.read_bytes()).hexdigest());rows.append(row);(work/(arch+'-'+src.stem+'.s.gz')).write_bytes(gzip.compress(p.stdout,mtime=0))
  if abs(percent)>t:report['failures'].append(row);print('OUTSIDE',row,flush=True)
  (out/'static-corpus.json').write_text(json.dumps(report,indent=2)+'\n')
 print('DONE',arch,flush=True)
report['complete']=True;(out/'static-corpus.json').write_text(json.dumps(report,indent=2)+'\n');print('RESULT',len(rows),'static rows;',len(report['failures']),'outside tolerances',flush=True)
