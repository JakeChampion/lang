from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/void-lambda-followup');source='d2980e0e6575e57ecdbdc908b22a92a6f409a21d';base='c13988f697502964f9059c540667092a2e75eb26';dest=root/'docs/benchmarks/lossless-numeric-conversions-2026-10-23/nested-match-followup'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
boot=json.loads((out/'bootstrap-final/bootstrap.json').read_text());native=sha(out/'bootstrap-final/stage3');assert boot['source_git']==source and boot['fixedpoint']and native==sha(out/'bootstrap-final/stage2')==boot['stages'][-1]['sha256']=='c8f5020c3cd5894516a0b165b99c25393a4a11afdaa621c33f39425c31e1360d'
files=[];h=hashlib.sha256()
for name in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/name).read_bytes();h.update(name.encode()+b'\0'+data+b'\0');files.append(dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256']
tests=[]
for name,count,packages in [('go-final.jsonl',2290,3),('module-and-source-final.jsonl',343,2),('native-final.jsonl',4876,1),('map-final.jsonl',6,1),('format-parity-correct-selector.jsonl',3,1),('fixture-and-diagnostics-final.jsonl',51,1)]:
 es=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es if e.get('Test'));term=[e for e in es if not e.get('Test')and e['Action']in['pass','fail','skip']];assert c['run']==c['pass']==count and not c['fail']and not c['skip']and len(term)==packages and all(e['Action']=='pass'for e in term),(name,c,term);tests.append(dict(file=name,runs=count,packages=packages,skips=0))
matrices=[]
for name,count,census in [('context-runtime-final-results.json',51,3),('callback-runtime-results.json',38,6)]:
 m=json.loads((out/name).read_text());assert m['complete']and m['source_commit']==source and m['compiler_sha256']==native and m['oracle_sha256']==sha(out/'oracle-final')and len(m['commands'])==count
 cs=[r['census']for r in m['commands']if'census'in r];assert len(cs)==census and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs);assert all(r['exit']==0 for r in m['commands']if'pass_'in r);matrices.append(dict(file=name,commands=count,balanced_censuses=census))
assert json.loads((out/'format-final.json').read_text())==dict(files=1218,exit=0)
for name in ['format-final.log','gofmt-final.log','vet-final.log']:assert not(out/name).read_bytes()
assert 'vcs.revision='+source in(out/'oracle-version.txt').read_text()and'vcs.modified=false'in(out/'oracle-version.txt').read_text()
assert 'Every driver measured here is within 5%'in(out/'final-sizes/driver-gate.log').read_text()and len((out/'final-sizes/driver-sizes.txt').read_text().splitlines())==11
assert 'Result: 0 errors, 0 warnings.'in(out/'readme-ste.log').read_text()
patch=git('diff','--binary',base,source);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source-files.json.gz',gzip.compress(json.dumps(files,indent=2).encode()+b'\n',mtime=0));save('change.patch.gz',gzip.compress(patch,mtime=0))
for name in ['bootstrap-final/bootstrap.json','bootstrap-final/stage1.log','bootstrap-final/stage2.log','bootstrap-final/stage3.log','go-final.jsonl','module-and-source-final.jsonl','native-final.jsonl','map-final.jsonl','format-parity-correct-selector.jsonl','fixture-and-diagnostics-final.jsonl','oracle-version.txt','format-final.json','format-final.log','gofmt-final.log','vet-final.log','context-runtime-final-matrix.py','context-runtime-final-results.json','context-runtime-final-matrix.log','callback-runtime-matrix.py','callback-runtime-results.json','callback-runtime-matrix.log','nested.fern','go-nested-before.fern','native-nested-before.fern','nested-before.json','readme-ste.log','final-sizes/check-sizes.py','final-sizes/driver-sizes.txt','final-sizes/driver-builds.json','final-sizes/driver-gate.log','final-sizes/sizes.log','record-final-proofs.py']:
 save(name.replace('/','--')+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as tar:
 for directory in ['context-runtime-final','callback-runtime']:
  for p in sorted((out/directory).glob('*.fern')):
   data=p.read_bytes();name=str(p.relative_to(out));info=tarfile.TarInfo(name);info.mode=0o644;info.mtime=0;info.size=len(data);tar.addfile(info,io.BytesIO(data));inputs.append(name)
save('runtime-inputs.tar.gz',stream.getvalue())
(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=source,base=base,native_sha256=native,source_sha256=h.hexdigest(),tests=tests,matrices=matrices,inputs=inputs,artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(tests=tests,matrices=matrices,artifacts=len(artifacts))))
