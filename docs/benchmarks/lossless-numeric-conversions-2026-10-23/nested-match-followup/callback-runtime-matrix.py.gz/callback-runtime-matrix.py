from pathlib import Path
import subprocess,os,json,hashlib,re
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-lossless-widening/void-lambda-followup');work=out/'callback-runtime';work.mkdir(exist_ok=False)
native=out/'bootstrap-final/stage3';oracle=out/'oracle-final';lib=root/'internal/stdlib';rows=[]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compiler_sha256=hashlib.sha256(native.read_bytes()).hexdigest(),oracle_sha256=hashlib.sha256(oracle.read_bytes()).hexdigest(),commands=rows,complete=False)
def run(name,args,census=False,want=None):
 p=subprocess.run(list(map(str,args)),cwd=root,env=dict(os.environ,FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_STRICT_IR='1'),capture_output=True,text=True,timeout=180)
 row=dict(name=name,args=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=p.returncode==0 and (want is None or p.stdout==want));rows.append(row)
 if census:
  m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);row['census']=dict(allocs=int(m[1]),frees=int(m[2]),live_bytes=int(m[3]))if m else None;row['pass_']=row['pass_']and bool(m and m[1]==m[2]and m[3]=='0')
 (out/'callback-runtime-results.json').write_text(json.dumps(report,indent=2)+'\n');assert row['pass_'],row;return p.stdout
for tag,source in [('explicit',(out/'nested.fern').read_text()),('inferred',(out/'nested.fern').read_text().replace('(n: i32): void =>','(n: i32) =>'))]:
 src=work/(tag+'.fern');src.write_text(source);formats=[]
 for front,cli in [('go',oracle),('native',native)]:
  run(tag+front+'-check',[cli,'-check',src,lib],want='');run(tag+front+'-interp',[cli,'-interp',src,lib],want='')
  text=run(tag+front+'-fmt',[cli,'-fmt',src]);formats.append(text);formatted=work/(tag+front+'.fern');formatted.write_text(text)
  run(tag+front+'-fmt-again',[cli,'-fmt',formatted],want=text);run(tag+front+'-formatted-check',[cli,'-check',formatted,lib],want='');run(tag+front+'-formatted-interp',[cli,'-interp',formatted,lib],want='')
 assert formats[0]==formats[1]
 for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run']),('arm64-darwin',None)]:
  binary=work/(tag+'-'+target);args=[native,'-target',target,'-o',binary]
  if target=='wasm32-wasi':args+=['-emit','command-module']
  run(tag+'-build-'+target,args+[src,lib],want='')
  if runner is not None:run(tag+'-run-'+target,runner+[binary],census=True,want='')
report['complete']=True;(out/'callback-runtime-results.json').write_text(json.dumps(report,indent=2)+'\n');assert len(rows)==38;print('PASS',len(rows),'commands')
