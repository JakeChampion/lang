from pathlib import Path
import subprocess,json,hashlib,time,re,sys
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-health')
mode=sys.argv[1];prefix=Path('/tmp/image-wide-decoder-evidence-secondary/expanded-'+mode)
assert not prefix.with_suffix('.json').exists()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','compiler','internal/stdlib','internal/testing/e2ecompiler','scripts','Makefile'],cwd=root,text=True).splitlines()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before={p:sha(root/p)for p in set(paths)if(root/p).is_file()}
entry=str(root/'compiler/drivers/ssalargepushwideisa_run.fern')
oracle=Path('/tmp/image-current-wide-main-go-oracle')
checks=([['go','test','-v','./internal/testing/e2ecompiler','-run','^TestSelfHostLargePushWideDecoder(Worker)?$','-count=1','-timeout=20m']]if mode=='targets'else[[str(oracle),'-check',entry],[str(oracle),'-interp',entry]])
record=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),feature_uncommitted=True,source_hashes=before,oracle_actual_build='a3296b1a5694a7d456bb3d8d526d7bf381a09b8d',oracle_sha256=sha(oracle),checks=[])
start=time.time()
with prefix.with_suffix('.log').open('w')as log:
 for cmd in checks:
  t=time.time();p=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT);record['checks'].append(dict(command=cmd,exit=p.returncode,seconds=time.time()-t));log.flush()
  if p.returncode:break
s=prefix.with_suffix('.log').read_text();record.update(seconds=time.time()-start,sources_unchanged=before=={p:sha(root/p)for p in before},PASS=len(re.findall(r'^\s*--- PASS:',s,re.M)),FAIL=len(re.findall(r'^\s*--- FAIL:',s,re.M)),SKIP=len(re.findall(r'^\s*--- SKIP:',s,re.M)))
prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
print({k:v for k,v in record.items()if k not in['source_hashes','checks']},flush=True);print(record['checks'],flush=True)
assert len(record['checks'])==len(checks)and all(c['exit']==0 for c in record['checks'])and record['sources_unchanged']and record['FAIL']==record['SKIP']==0
if mode=='go':assert 'wide large-push decoder controls passed'in s
if mode=='targets':assert record['PASS']==29
