from pathlib import Path
import sys,json,gzip,argparse,hashlib,subprocess,os
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-health');sys.path.insert(0,str(root/'scripts'))
from qualify_large_push_wide_decoder import run,GEN,sha
folder=Path('/tmp/image-wide-decoder-evidence-secondary/checkpoint-fault');assert not folder.exists();folder.mkdir()
ref=json.loads(gzip.decompress(GEN.REFERENCE.read_bytes()));small=[c for c in ref['cases']if c['name'].startswith('movabs-')and c['expected']['ok']and all(-(1<<31)<=op['immediate']<(1<<31)for op in c['expected']['ops'])][:8]
assert len(small)==8
rows=json.loads(json.dumps(small+[ref['cases'][4680]]))
for index,c in enumerate(rows):c['id']=index;c['payload_sha256']=hashlib.sha256(GEN.packet(c)).hexdigest()
reference=folder/'reference.json.gz';reference.write_bytes(gzip.compress(json.dumps(dict(schema=1,cases=rows)).encode(),mtime=0))
mutant=Path('/tmp/image-wide-decoder-evidence-secondary/private-controls-cache-corrected/truncate-i64/compiler/drivers/ssalargepushwideisa_worker.fern')
wrapper=folder/'compile-mutant';wrapper.write_text('#!/usr/bin/env python3\nimport os,sys\nos.execv("/tmp/image-feature-census-current-fern-73f407b48",["/tmp/image-feature-census-current-fern-73f407b48",*sys.argv[1:-1],'+repr(str(mutant))+'])\n');wrapper.chmod(0o755)
options=argparse.Namespace(output=str(folder/'failed.json'),work=str(folder/'worker'),source_commit='f7bdaba5a4811476db32e137419971497e7da70f',allow_dirty=True,reference=str(reference),compiler=str(wrapper),target='x86-64-linux')
try:run(options)
except ValueError as e:failure=str(e)
else:raise AssertionError('mutant escaped collector')
assert failure=='exact operation mismatch: actual-current-helper/0'
data=json.loads(Path(options.output).read_text());check=Path(options.output+'.checkpoint');checkpoint=json.loads(check.read_text())
assert not data['qualified']and data['compile_exit']==0 and data['sources_unchanged']and len(data['records'])==8 and len(data['workers'])==2 and data['workers'][0]['qualified']and all(w['exit']==0 for w in data['workers'])and len(checkpoint['records'])==8
assert (Path(options.work)/'worker-00008.stdout.log').is_file()and (Path(options.work)/'worker-00000.stdout.log').is_file()
paths=[p for p in folder.rglob('*')if p.is_file()];before={str(p):sha(p)for p in paths}
try:run(options)
except ValueError as e:assert str(e)=='refuse existing qualification output or work directory'
else:raise AssertionError('overwrote prior failure')
assert before=={p:sha(p)for p in before}
record=dict(control='real compiled i64 truncation defect through full collector',failure=failure,compile_exit=0,runtime_exits=[w['exit']for w in data['workers']],complete_prefix_rows=8,failed_worker_rows=1,checkpoint_preserved=True,failed_stdout_preserved=True,output_existing_rejected_without_changes=True,underlying_compiler_sha256=sha('/tmp/image-feature-census-current-fern-73f407b48'),wrapper_sha256=sha(wrapper),private_reference_sha256=sha(reference),sources_unchanged=data['sources_unchanged'])
(folder/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
