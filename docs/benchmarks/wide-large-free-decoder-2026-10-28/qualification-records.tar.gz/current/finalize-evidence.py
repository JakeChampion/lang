from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile,io,os
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-health');folder=Path('/tmp/image-wide-decoder-evidence-secondary');source=(folder/'source-sha.txt').read_text().strip();git=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
for name in ['current-build','final-Go','final-gates']:
 d=json.loads((folder/(name+'.json')).read_text());assert d['source']==source and d['sources_unchanged']
 if name=='current-build':assert d['make_exit']==d['version_exit']==0 and d['worktree_clean']
 else:assert all(c['exit']==c['FAIL']==c['SKIP']==0 for c in d['checks'])and d['worktree_still_clean']and d['binaries_unchanged']
rows=[json.loads((folder/('final-corpus-'+t+'.json')).read_text())for t in ['x86-64-linux','wasm32-wasi','arm64-linux']]
assert all(r['source']==source and r['qualified']and r['sources_unchanged']and r['compiler_unchanged']and not r['feature_uncommitted']and len(r['records'])==4681 and len(r['workers'])==586 for r in rows)
assert all(r['records']==rows[0]['records']for r in rows)
record=json.loads((folder/'final-tool-identities-before.json').read_text())
for item in record['tools'].values():assert sha(Path(item['selected_path']).read_bytes())==item['sha256']
record['all_tool_hashes_unchanged']=True;record['oracle_identity_observation']='The final Go record contains its post-run binary hash after the fresh source build and check/interpreter commands.'
(folder/'final-tool-identities-after.json').write_text(json.dumps(record,indent=2)+'\n')
base=root/'docs/benchmarks/wide-large-free-decoder-2026-10-28';assert not base.exists()
relative=str(base.relative_to(root));assert subprocess.run(['git','cat-file','-e','HEAD:'+relative],cwd=root,stderr=subprocess.DEVNULL).returncode!=0 and not git('ls-files','--',relative)
base.mkdir(parents=True);manifest=[];executables=[]
def bound(original,data,target):
 out=base/target;assert not out.exists();out.write_bytes(data);manifest.append(dict(original=str(original),published=target,original_sha256=sha(original.read_bytes())if isinstance(original,Path)else None,published_sha256=sha(data),published_bytes=len(data)))
def compressed(path,name):bound(path,gzip.compress(path.read_bytes(),mtime=0),name)
for t in ['x86-64-linux','wasm32-wasi','arm64-linux']:compressed(folder/('final-corpus-'+t+'.json'),'large-free-wide-decoder-'+t+'.json.gz')
# Preserve all observed stdout, stderr, inputs, source copies, and coordinators.
# Executables stay at their original paths with hashes in this manifest.
def archive(name,entries):
 payload=io.BytesIO();count=0
 with tarfile.open(fileobj=payload,mode='w')as tar:
  for path,arcname in sorted(entries,key=lambda pair:pair[1]):
   if path.is_symlink()or not path.is_file():continue
   raw=path.read_bytes()
   if raw.startswith(b'\x7fELF')or path.suffix in ['.elf','.wasm','.wat','.s']and path.suffix not in ['.s']:
    executables.append(dict(path=str(path),archive_group=name,bytes=len(raw),sha256=sha(raw)));continue
   info=tarfile.TarInfo(arcname);info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw));count+=1
 out=gzip.compress(payload.getvalue(),mtime=0);bound('archive',out,name);manifest[-1]['member_count']=count
entries=[]
for path in folder.rglob('*'):
 if path.is_file()and not path.is_symlink():
  rel=path.relative_to(folder)
  if any((folder/Path(*rel.parts[:i])).is_symlink()for i in range(1,len(rel.parts))):continue
  if path.name in ['final-corpus-'+t+'.json'for t in ['x86-64-linux','wasm32-wasi','arm64-linux']]:continue
  entries.append((path,'current/'+str(rel)))
archive('qualification-records.tar.gz',entries)
entries=[]
for pattern in ['image-wide-large-free-decoder*','image-large-free-wide-decoder*','image-retained-wide-machine-*']:
 for path in Path('/tmp').glob(pattern):
  if path.is_dir():entries.extend((p,'before/'+str(p.relative_to('/tmp')))for p in path.rglob('*')if p.is_file()and not p.is_symlink())
  elif path.is_file():entries.append((path,'before/'+path.name))
for path in [Path('/tmp/image-run-retained-wide-machine-before.py'),Path('/tmp/image-run-retained-wide-machine-diagnostics.py'),Path('/tmp/image-run-large-free-wide-decoder-initial.py')]:
 assert path.is_file();entries.append((path,'before/'+path.name))
archive('before-and-initial-records.tar.gz',entries)
(base/'omitted-executable-identities.json').write_text(json.dumps(executables,indent=2)+'\n')
build=json.loads((folder/'current-build.json').read_text());gates=json.loads((folder/'final-gates.json').read_text());go=json.loads((folder/'final-Go.json').read_text());equal=json.loads((folder/'final-record-equality.json').read_text())
evidence=dict(source=source,PR=13743,native_issue=13738,source_commit_precedes_final_campaigns=True,reference_bundle='124f50eea183b4640755e2c09cbad28bdab39d7d851bf5757ef3015ce5227c5e',case_count_per_target=4681,success_per_target=4224,expected_error_per_target=457,workers_per_target=586,total_workers=1758,records_exactly_equal=True,all_workers_nonzero_balanced_zero_live=True,build={k:v for k,v in build.items()if k!='source_hashes'},checks=[{k:v for k,v in c.items()if k!='command'}for c in gates['checks']],Go_oracle_actual_build=go['oracle_actual_build'],Go_oracle_postrun_sha256=go['oracle_sha256'],sourcegate_node_count_unclaimed=True,initial_expanded_source='f7bdaba5a4811476db32e137419971497e7da70f + UNCOMMITTED',stock_retained_failure_persists=True,machine_integration=False,full_CI_recovery=False,M5_epic_gates='OPEN',manifest=manifest)
(base/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
text=(folder/'decoder-scope-draft.md').read_text()+'\n## Final qualification\n\nThe final campaigns use source `'+source+'`.\nThe standard build passed make, version, and smoke checks in '+format(build['seconds'],'.3f')+' seconds.\nIts raw compiler matches the prior qualified production compiler byte for byte.\nThe published CLI records its actual source version.\n\nAll three targets completed 4,681 cases and 586 fresh workers per target.\nAll 1,758 workers exited successfully with nonzero balanced censuses and zero live bytes.\nAll decoded records match exactly across targets.\nEvery campaign preserved its source and compiler hashes.\n\nThe final stock decoder and packet tests passed 29 nodes across the three targets.\nThe unchanged complexity checks passed three nodes.\nThe source gate passed its five runtime sets, fixture checks, compiler check, standard library checks, and standalone driver checks.\nThe nonverbose source-gate command does not establish a separate test-node count.\n\nFormat, Go build, Go vet, workflow lint, test names, CI self-tests, runtime generation, and all 219 source-audit nodes passed.\nThe reference bundle reproduced exactly, and all 12 protocol self-tests passed.\nA fresh Go oracle built from the final source passed check and interpreter commands.\nThe Go record contains its post-run binary hash.\n\nThe archives preserve the fresh stock failure, native capability, initial runs, provisional corpus, fault controls, corrections, and final records.\nExecutables remain at their original paths, with hashes in `omitted-executable-identities.json`.\nThe three final raw records use new names and preserve their exact decompressed bytes.\n`evidence.json` binds the archive hashes and qualification facts.\n\nThe first private-control compile failed before execution because the command omitted the separate cache exports.\nThe corrected command used a distinct output path and the configured cache exports.\nAll three deliberate decoder defects then compiled and ran normally before exact collector rejection.\nThe failure-prefix control preserved eight completed records, its checkpoint, and the failing worker output.\n\nThe current raw compiler is unchanged, so this scope does not repeat the separate image corpus.\nPR #13734 preserves that prior current-compiler image qualification.\nThis scope establishes the standalone decoder only.\nThe full retained-machine recovery, actual CI recovery, and all actual M5 and epic gates remain open.\n'
(base/'README.md').write_text(text)
(folder/'finalization-record.json').write_text(json.dumps(dict(source=source,destination=str(base),files=[p.name for p in base.iterdir()],published_bytes=sum(p.stat().st_size for p in base.iterdir())),indent=2)+'\n')
print('Evidence prepared',base,len(manifest),'archives/raw records')
