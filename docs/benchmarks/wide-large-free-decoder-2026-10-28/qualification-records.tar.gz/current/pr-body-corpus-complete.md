The current large-free helper starts with a 64-bit literal that the old instruction record cannot represent.
This change adds a separate wide decoder with exact signed literals, register comparisons, and complete operation records.
It preserves all old interfaces, models, assertions, production instructions, domains, baselines, and thresholds.

Source commit: `a928e68f14ede0df5afe9b046bb866eb4455b82e`.
The clean standard two-stage build passed make, version, and smoke checks in 107.742 seconds with bootstrap pin 919.
Its raw compiler is byte-identical to the previously qualified production compiler.
A fresh Go oracle from this source passed check and interpreter commands.

Final campaigns completed 4,681 cases and 586 fresh workers on each of native, ARM64, and Wasm.
All 1,758 workers exited successfully with nonzero balanced censuses and zero live bytes.
All decoded records match exactly across targets, with 4,224 successes and 457 expected errors per target.
Source and compiler hashes remained unchanged.

Private truncation, operand-swap, unknown-instruction, and checkpoint controls exposed the required defects.
The expanded stock tests passed 29 nodes with zero skips before the source commit.
The final source gate and unchanged complexity checks passed, and final stock decoder tests remain in progress.
Format, build, vet, audit, and auxiliary checks follow those tests.

Native issue: #13738 under #13717 and #13687.
Machine integration requires a later scope after this decoder merge.
CI and full retained-machine recovery remain unqualified.
All actual M5 and epic gates remain open.
