The current large-free helper starts with a 64-bit literal that the old instruction record cannot represent.
This change adds a separate wide decoder with exact signed literals, register comparisons, and complete operation records.
It preserves all old interfaces, models, assertions, production instructions, domains, baselines, and thresholds.

The independent reference contains 4,681 cases with exact integer and field expectations.
The expanded driver and real packet worker passed 29 test nodes across native, ARM64, and Wasm with zero skips.
Go check and interpreter runs passed, and the provisional native campaign completed 586 workers with nonzero balanced zero-live censuses.
Private truncation, operand-swap, unknown-instruction, and checkpoint controls exposed the required defects.

Source commit: `a928e68f14ede0df5afe9b046bb866eb4455b82e`.
The clean standard two-stage build is in progress with bootstrap pin 919.
Final source-pinned campaigns and the source, format, build, vet, audit, and complexity checks remain pending.
CI and full retained-machine recovery remain unqualified.

Native issue: #13738 under #13717 and #13687.
Machine integration requires a later scope after this decoder merge.
All actual M5 and epic gates remain open.
