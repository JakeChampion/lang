from pathlib import Path
import gzip,json,hashlib,subprocess,sys,time
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-machine-health')
sys.path.insert(0,str(root/'scripts'))
from qualify_large_push_wide_decoder import check_output,GEN,inventory,sha
out=Path('/tmp/image-wide-decoder-evidence-secondary/private-controls');assert not out.exists();out.mkdir()
compiler=Path('/tmp/image-feature-census-current-fern-73f407b48');before=inventory();compiler_hash=sha(compiler)
ref=json.loads(gzip.decompress(GEN.REFERENCE.read_bytes()));cases=[ref['cases'][4680],ref['cases'][4626]]
assert cases[0]['name']=='actual-current-helper' and not cases[1]['expected']['ok']
packet=b''.join(GEN.packet(c)for c in cases);(out/'selected-cases.json').write_text(json.dumps(cases,indent=2)+'\n');(out/'input.bin').write_bytes(packet)
mutations=[('truncate-i64','return scalar(41, 64, -1, dst, value);','return scalar(41, 64, -1, dst, (value as i32) as i64);','exact operation mismatch: actual-current-helper/0'),('swap-compare','scalar(28, width, src, dst, 0 as i64)','scalar(28, width, dst, src, 0 as i64)','exact operation mismatch: actual-current-helper/1'),('accept-unknown','return error("unsupported wide large-push instruction");','return WideProgram { ops: [], error: "" };','error result, partial operations, or error text mismatch')]
record=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),feature_uncommitted=True,source_hashes=before,compiler_sha256=compiler_hash,controls=[])
start=time.time()
for name,old,new,want in mutations:
 folder=out/name;folder.mkdir();c=folder/'compiler';c.mkdir();drivers=c/'drivers';drivers.mkdir()
 for p in (root/'compiler').iterdir():
  if p.name not in ['ssalargepushwideisa.fern','drivers']:(c/p.name).symlink_to(p.resolve(),target_is_directory=p.is_dir())
 original=(root/'compiler/ssalargepushwideisa.fern').read_text();assert original.count(old)==1
 candidate=c/'ssalargepushwideisa.fern';candidate.write_text(original.replace(old,new))
 worker=drivers/'ssalargepushwideisa_worker.fern';worker.write_bytes((root/'compiler/drivers/ssalargepushwideisa_worker.fern').read_bytes())
 elf=folder/'worker.elf';cmd=[str(compiler),'-target','x86-64-linux','-sanitize','-o',str(elf),str(worker)]
 env=dict(__import__('os').environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1')
 with (folder/'compile.log').open('wb')as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 item=dict(name=name,compile_command=cmd,compile_exit=p.returncode,candidate_sha256=sha(candidate),worker_source_sha256=sha(worker));record['controls'].append(item)
 assert p.returncode==0
 binary_before=sha(elf);p=subprocess.run([str(elf)],input=packet,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
 (folder/'stdout.log').write_bytes(p.stdout);(folder/'stderr.log').write_bytes(p.stderr)
 item.update(runtime_exit=p.returncode,binary_sha256_before=binary_before,binary_sha256_after=sha(elf),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest())
 assert p.returncode==0 and binary_before==sha(elf)
 # Establish the ordinary heap contract independently of expected data rejection.
 import re
 m=re.fullmatch(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)\s*',p.stderr);assert m
 a,f,l=map(int,m.groups());assert a>0 and a==f and l==0;item['heap']=dict(allocs=a,frees=f,live_bytes=l)
 try:check_output(p.stdout.decode(),p.stderr.decode(),cases,p.returncode)
 except ValueError as error:item['collector_rejection']=str(error);assert str(error)==want
 else:raise AssertionError('defect escaped strict collector')
 assert before==inventory()and sha(compiler)==compiler_hash
 record['sources_unchanged']=True;record['seconds']=time.time()-start;(out/'record.json').write_text(json.dumps(record,indent=2)+'\n');print(name,item['collector_rejection'],item['heap'],flush=True)
assert len(record['controls'])==3
