Parent: #13717 under #13687. Prerequisite #13725 is complete.

Fresh main `f7bdaba5a4811476db32e137419971497e7da70f` still fails the second retained-machine driver on native.
The unchanged stock test reports exit 166, two failing nodes, and zero skips.
A direct execution identifies the old dependency-boundary expectation as the first failure.
The current helper starts with `movabs $17179869184, %rax`, then a register comparison.

The old decoder reports an unknown first instruction and retains its bounded 45-class, 57-partition interface.
The accepted wide arithmetic interface has 61 classes and 77 partitions.
A fresh independent native capability probe checks 252 inputs with zero register, block, or freelist mismatches.
The deliberate 32-bit shift defect returns normally but produces 36 mismatches.

This prerequisite adds a separate typed decoder before machine integration.
It does not establish a symbolic helper proof or repair the full retained-driver group.
The native capability record remains a finite observation rather than Fern model qualification.
All production emitters, runtime instructions, library files, old decoder interfaces, existing driver assertions, and mathematical helper domains remain unchanged.

Predeclared interface and exact criterion:

- Add a separate wide program and operation record around the existing operation record.
- Store the new immediate in an `i64` field without an `i32` conversion.
- Preserve the existing `Op`, `Program`, and all old decoder entry points and behavior.
- Reuse the existing instruction decoder through a narrow additive adapter for unchanged large-free instructions.
- Decode `movabs` with a canonical signed decimal immediate and a 64-bit general-purpose destination register.
- Admit the full signed `i64` range, including both endpoints.
- Require canonical decimal spelling without a plus sign, leading zeros, negative zero, hexadecimal text, or symbolic expressions.
- Treat that spelling rule as the initial parser subset, rather than an x86 validity claim.
- Decode register comparisons with exact source, destination, and 32-bit or 64-bit width.
- Preserve each selected body line as one typed operation, including labels and returns.
- Resolve branches only to unique labels inside the selected helper body.
- Preserve all existing body and namespace isolation checks.
- Return an error with no operations for unknown instructions, malformed operands, invalid literals, duplicate labels, or unresolved transfers.
- Treat valid empty and cyclic bodies as data, without a semantic proof or termination claim.
- Add no instruction stripping, NOP interpretation, arbitrary external transfer, runtime fallback, threshold change, or emitted-code workaround.

The independent reference uses Python integers and canonical decimal checks.
It must cover both signed endpoints and neighbors of powers 31, 32, 34, 35, and 63.
It must cover all 16 destination registers and every register pair for both comparison widths.
It must include malformed, overflowing, mixed-width, namespace, alias, external-target, unknown-instruction, and shared-input controls.
Every admitted literal and operation field must match exactly, without floating tolerances, seed filters, or error exemptions.

The current emitted helper must decode all 29 selected lines without omission.
Its first operation must retain the exact 17179869184 immediate and the following register comparison operands.
Private truncation, operand-swap, and unknown-instruction controls must expose incorrect decoder behavior.
All reference expectations must precede the final source-pinned campaigns.

Acceptance:

- [ ] Preserve fresh stock failure, direct stdout, current emitted helper, native capability, and actual source and tool identities.
- [ ] Add only the separate wide decoder and additive shared adapter while preserving all old interfaces, instructions, and assertions.
- [ ] Pass exact independent reference and meaningful defect controls without missing cases or weakened expectations.
- [ ] Pass the new decoder driver on native, Wasm, and ARM64 with nonzero balanced zero-live censuses and zero skips.
- [ ] Pass Go check and interpreter runs, the clean standard build, source, format, build, vet, audit, and unchanged complexity checks.
- [ ] Merge one scoped READY PR normally at its exact full head before machine integration.

The full machine contract and current mutation expectations require a later scope after this decoder merge.
The full retained-machine recovery, actual CI recovery, and all actual M5 and epic gates remain open.
