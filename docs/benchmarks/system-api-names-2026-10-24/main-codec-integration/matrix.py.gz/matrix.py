from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-system-api-names-current');scratch=Path('/workspace/scratch/lang-system-api-names/main-codec-integration');out=scratch/'matrix';out.mkdir(exist_ok=True)
compiler=scratch/'bootstrap/stage3';oracle=scratch/'oracle';stdlib=root/'internal/stdlib';names=['path','cli','log','fuzz_example','fuzz_shrink','fuzz_corpus'];rows=[];goldens={}
metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'compiler_source_commit':'0e4dae30a8af5cad5458fbc051dcae18086878ef','producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows}
def save():(scratch/'matrix.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(name,args,extra={},isolated=False):
 cwd=root
 if isolated:cwd=out/(name+'-cwd');cwd.mkdir(exist_ok=True)
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=cwd,env=dict(os.environ,**extra),capture_output=True,timeout=180)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 row={'name':name,'args':list(map(str,args)),'cwd':str(cwd),'exit':r.returncode,'seconds':time.monotonic()-start};rows.append(row);save();print(row,flush=True);assert r.returncode==0,(name,r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace'));return r,row
for name in names:
 path=root/'tests/stdlib'/(name+'_test.fern')
 for engine,tool in [('go',oracle),('self',compiler)]:
  for mode in ['-check','-interp']:
   r,_=run(name+'-'+engine+mode,[tool,mode,path]+([stdlib]if engine=='self'else[]),isolated=mode=='-interp')
   if mode=='-interp':
    assert b'# fail 0'in r.stdout and re.search(rb'1\.\.[1-9][0-9]*',r.stdout),r.stdout
    if name in goldens:assert r.stdout==goldens[name],(name,engine,'interpreter output mismatch')
    goldens[name]=r.stdout
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=out/(name+'-'+target)
  run(name+'-build-'+target,[compiler,'-target',target,'-o',dest,path,stdlib],{'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest]if target=='x86-64-linux'else['qemu-aarch64',dest]if target=='arm64-linux'else['wasmtime','run','--dir=.',dest]
  r,row=run(name+'-run-'+target,args,isolated=True);assert r.stdout==goldens[name],(name,target,'execution output mismatch')
  m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,(name,target,r.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
metadata['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
