from pathlib import Path
import subprocess,json,hashlib,gzip
root=Path('/workspace/lang-cohesion-ci-refresh');out=Path('/workspace/scratch/lang-map-iterator/perf-ratchet-followup');dest=root/'docs/benchmarks/map-iterator-2026-10-23/perf-ratchet-followup';base='7ed3addb40a2a2814621bc60fe2011e2dc9e166b'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==base
assert git('diff','--name-only').decode().splitlines()==['.github/perf-baseline.txt']
assert not git('diff','b15d4e7e10ddaec58bba62c4d3d8d8c41c06e632','HEAD','--','compiler','internal','bench')
changes=json.loads((out/'baseline-changes.json').read_text());assert len(changes)==6 and all(c['after']<c['before']for c in changes)
assert 'Every metric is within tolerance'in(out/'arm64-gate.log').read_text()
measure=json.loads((out/'static-measurements.json').read_text());assert measure['source_commit']==base and measure['compiler_sha256']=='1d702e27210018739e3d146db95c4a573c4e81479722ae308617f71d14f34e00'
metrics=[line for line in(out/'ci-arm64-report.txt').read_text().splitlines()if line and not line.startswith('#')];assert len(metrics)==78
sources=[]
for name in ['map_int','map_probe_chain','map_string']:
 p=root/'bench'/(name+'.fern');sources.append(dict(path=str(p.relative_to(root)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
dest.mkdir(exist_ok=False);files=[]
def save(n,data):
 p=dest/n;p.write_bytes(data);files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
for name in ['ci-arm64.log','ci-arm64-report.txt','static-measurements.json','baseline-before.txt','baseline-after.txt','baseline-changes.json','arm64-gate.log','record-proofs.py',*[a+'-'+n+'.s'for a in['x86_64','aarch64']for n in['map_int','map_probe_chain','map_string']]]:save(name+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
patch=git('diff','--','.github/perf-baseline.txt');subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('baseline.patch.gz',gzip.compress(patch,mtime=0));(dest/'artifacts.json').write_text(json.dumps(dict(code_source=base,compiler_source='b15d4e7e10ddaec58bba62c4d3d8d8c41c06e632',public_source='ec1d8b869f55ea93802f868cca4ed33e993051df',ci_run=40120850761,arm64_job=120952820922,artifact_id=12570944585,artifact_sha256='7bcc1ddcebbe5cd47077a50b783832dd5f78058fef0eba4b7812524db11d488b',arm64_metrics=78,local_static_commands=6,changes=changes,sources=sources,artifacts=files),indent=2)+'\n');print('Recorded',len(files),'artifacts')
