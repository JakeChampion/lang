    .globl _start
    .text
__fn___map_pow2_ceil:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_pow2_ceil.r:
.Lssa___map_pow2_ceil_0:
    cmpq $4, %rax
    jg .Lssa___map_pow2_ceil_4
.Lssa___map_pow2_ceil_6:
    movl $4, %eax
    ret
.Lssa___map_pow2_ceil_4:
.Lssa___map_pow2_ceil_3:
    movl $4, %esi
.Lssa___map_pow2_ceil_11:
    cmpq %rax, %rsi
    jge .Lssa___map_pow2_ceil_2
.Lssa___map_pow2_ceil_14:
    cmpq $1073741824, %rsi
    jge .Lssa___map_pow2_ceil_1
.Lssa___map_pow2_ceil_12:
    movq %rsi, %rdi
    shlq $1, %rdi
    movslq %edi, %rsi
    cmpq %rax, %rsi
    jl .Lssa___map_pow2_ceil_14
.Lssa___map_pow2_ceil_2:
    movq %rsi, %rax
    ret
.Lssa___map_pow2_ceil_1:
    movq %rsi, %rax
    ret
    .cfi_endproc
__fn___map_hdr_bytes:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_hdr_bytes.r:
.Lssa___map_hdr_bytes_0:
    movl $24, %eax
    ret
    .cfi_endproc
__fn___map_hdr:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_hdr.r:
.Lssa___map_hdr_0:
    movl $24, %eax
    ret
    .cfi_endproc
__fn___map_buf_bytes:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_buf_bytes.r:
.Lssa___map_buf_bytes_0:
    movl $2, %edi
    imulq $8, %rdi, %rdi
    addq $4, %rdi
    imulq %rax, %rdi
    addq %rdi, %rsi
    addq %rax, %rsi
    addq $8, %rsi
    movslq %esi, %rax
    ret
    .cfi_endproc
__fn___map_ctrl_base:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_ctrl_base.r:
.Lssa___map_ctrl_base_0:
    movl $24, %edi
.Lssa___map_ctrl_base_1:
    movslq %edi, %rdi
    addq %rdi, %rax
    movl $2, %edi
    imulq $8, %rdi, %rdi
    addq $4, %rdi
    imulq %rdi, %rsi
    movslq %esi, %rsi
    addq %rsi, %rax
    ret
    .cfi_endproc
__fn___map_h2:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_h2.r:
.Lssa___map_h2_0:
    movl %eax, %eax
    shrq $25, %rax
    movslq %eax, %rax
    ret
    .cfi_endproc
__fn___map_swar_lo:
    .cfi_startproc
__fn___map_swar_lo.r:
.Lssa___map_swar_lo_0:
    movabsq $72340172838076673, %rax
    ret
    .cfi_endproc
__fn___map_swar_hi:
    .cfi_startproc
__fn___map_swar_hi.r:
.Lssa___map_swar_hi_0:
    movabsq $9259542123273814144, %rax
    ret
    .cfi_endproc
__fn___map_swar_all:
    .cfi_startproc
__fn___map_swar_all.r:
.Lssa___map_swar_all_0:
    movq $-1, %rax
    ret
    .cfi_endproc
__fn___map_ctrl_set:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_ctrl_set.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
.Lssa___map_ctrl_set_0:
.Lssa___map_ctrl_set_2:
.Lssa___map_ctrl_set_3:
    leaq 8(%rsi), %r9
    movslq %r9d, %r9
    cmpq %r9, %rdi
    jge .Lssa___map_ctrl_set_1
.Lssa___map_ctrl_set_4:
    movq %rdi, %r9
    andq $-4, %r9
    movq %rdi, %r10
    andq $3, %r10
    shlq $3, %r10
    movslq %r9d, %r9
    addq %rax, %r9
    movslq (%r9), %rbx
    movl $255, %r12d
    movq %r10, %rcx
    movq %r12, %r11
    andl $31, %ecx
    shlq %cl, %r11
    movq %r11, %r12
    movslq %r12d, %r12
    andnq %rbx, %r12, %rbx
    movq %r10, %rcx
    movq %r8, %r11
    andl $31, %ecx
    shlq %cl, %r11
    movq %r11, %r10
    movslq %r10d, %r10
    orq %r10, %rbx
    movl %ebx, (%r9)
    addq %rsi, %rdi
    movslq %edi, %rdi
    jmp .Lssa___map_ctrl_set_3
.Lssa___map_ctrl_set_1:
    xorl %eax, %eax
    .cfi_remember_state
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_seed:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_seed.r:
.Lssa___map_seed_0:
    addq $16, %rax
    movslq (%rax), %rax
    ret
    .cfi_endproc
__fn___map_wang_mix:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_wang_mix.r:
.Lssa___map_wang_mix_0:
    xorq $61, %rax
    movl %eax, %esi
    shrq $16, %rsi
    xorq %rsi, %rax
    movq %rax, %rsi
    shlq $3, %rsi
    addq %rsi, %rax
    movl %eax, %esi
    shrq $4, %rsi
    xorq %rsi, %rax
    imulq $668265261, %rax, %rax
    movslq %eax, %rax
    movl %eax, %esi
    shrq $15, %rsi
    movslq %esi, %rsi
    xorq %rsi, %rax
    ret
    .cfi_endproc
__fn___map_fnv_str_seeded:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_fnv_str_seeded.r:
.Lssa___map_fnv_str_seeded_0:
    movl $2166136261, %edi
    movl %esi, %esi
    xorq %rsi, %rdi
    movq 8(%rax), %rsi
.Lssa___map_fnv_str_seeded_4:
    xorl %r8d, %r8d
.Lssa___map_fnv_str_seeded_5:
    leaq 4(%r8), %r9
    movslq %r9d, %r9
    cmpq %rsi, %r9
    jg .Lssa___map_fnv_str_seeded_2
.Lssa___map_fnv_str_seeded_6:
    leaq 3(%r8), %r9
    movslq %r9d, %r9
    movq %r8, %r10
    sarq $31, %r10
    orq %r10, %r9
    cmpq 8(%rax), %r9
    jae __fern_str_oob_abort.l0
    movq 0(%rax), %r10
    movslq %r8d, %r9
    addq %r9, %r10
    movslq (%r10), %r10
    xorq %rdi, %r10
    imulq $16777619, %r10, %r10
    movl %r10d, %edi
    leaq 4(%r8), %r10
    movslq %r10d, %r8
    jmp .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmpq %rsi, %r8
    jge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    cmpq 8(%rax), %r8
    jae __fern_str_oob_abort.l0
    movq (%rax), %rdx
    movzbl (%rdx,%r8), %r10d
    xorq %rdi, %r10
    imulq $16777619, %r10, %r10
    movl %r10d, %edi
    addq $1, %r8
    cmpq %rsi, %r8
    jl .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    movq %rdi, %r8
    shrq $16, %r8
    xorq %r8, %rdi
    movl $2246822507, %r8d
    imulq %r8, %rdi
    movl %edi, %edi
    movq %rdi, %r8
    shrq $13, %r8
    xorq %r8, %rdi
    movl $3266489909, %r8d
    imulq %r8, %rdi
    movl %edi, %edi
    movq %rdi, %r8
    shrq $16, %r8
    xorq %r8, %rdi
    movslq %edi, %rax
    ret
    .cfi_endproc
__fn_map_new_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn_map_new_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rsi, %rbx
    movq %rdi, -48(%rbp)
.Lssa_map_new_impl_0:
    movq %rbx, %r13
    andq $255, %r13
.Lssa_map_new_impl_11:
    cmpq $4, %rax
    jg .Lssa_map_new_impl_8
.Lssa_map_new_impl_10:
    movl $4, %r14d
    jmp .Lssa_map_new_impl_4
.Lssa_map_new_impl_8:
.Lssa_map_new_impl_7:
    movl $4, %esi
.Lssa_map_new_impl_17:
    cmpq %rax, %rsi
    jge .Lssa_map_new_impl_6
.Lssa_map_new_impl_20:
    cmpq $1073741824, %rsi
    jge .Lssa_map_new_impl_5
.Lssa_map_new_impl_18:
    movq %rsi, %rdi
    shlq $1, %rdi
    movslq %edi, %rsi
    cmpq %rax, %rsi
    jl .Lssa_map_new_impl_20
.Lssa_map_new_impl_6:
    movq %rsi, %r14
    jmp .Lssa_map_new_impl_4
.Lssa_map_new_impl_5:
    movq %rsi, %r14
.Lssa_map_new_impl_4:
    movl $24, %r15d
    movl $2, %esi
    imulq $8, %rsi, %rsi
    addq $4, %rsi
    imulq %r14, %rsi
    addq $24, %rsi
    addq %r14, %rsi
    addq $8, %rsi
    movslq %esi, %rsi
    movq %rsi, %rdi
    call __fern_alloc
    movq %rax, %r12
    movl %r14d, (%r12)
    leaq 4(%r12), %rdi
    xorl %esi, %esi
    movl %esi, (%rdi)
    leaq 8(%r12), %r8
    movl %r13d, (%r8)
    leaq 12(%r12), %rsi
    movq -48(%rbp), %rcx
    movl %ecx, (%rsi)
    cmpq $1, %r13
    jne .Lssa_map_new_impl_2
.Lssa_map_new_impl_3:
    call __fern_map_hash_seed
    jmp .Lssa_map_new_impl_1
.Lssa_map_new_impl_2:
    xorl %eax, %eax
.Lssa_map_new_impl_1:
    leaq 16(%r12), %r8
    movl %eax, (%r8)
    leaq 20(%r12), %rsi
    sarq $8, %rbx
    movl %ebx, (%rsi)
    movslq %r15d, %r15
    addq %r12, %r15
    movq %r14, %r8
    shlq $2, %r8
    movslq %r8d, %r8
    movl $255, %esi
    movq %r8, %rcx
    movq %rsi, %rax
    movq %r15, %rdi
    cld
    rep stosb
    pushq $0
    popq %rax
    movl $2, %esi
    imulq $8, %rsi, %rsi
    addq $4, %rsi
    imulq %r14, %rsi
    movslq %esi, %rsi
    addq %rsi, %r15
    movq %r15, %rsi
    addq $8, %r14
    movslq %r14d, %r14
    movl $128, %r8d
    movq %r14, %rcx
    movq %r8, %rax
    movq %rsi, %rdi
    cld
    rep stosb
    pushq $0
    popq %rax
    movl $16, %edi
    call __fern_alloc
    movl $1, %edi
    movl %edi, (%rax)
    addq $8, %rax
    movq %r12, 0(%rax)
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_cow_inplace:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_cow_inplace.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
.Lssa___map_cow_inplace_0:
    leaq -8(%rax), %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jg .Lssa___map_cow_inplace_1
.Lssa___map_cow_inplace_3:
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_cow_inplace_1:
    movq 0(%rax), %rbx
    movslq (%rbx), %rsi
.Lssa___map_cow_inplace_8:
    movl $2, %edi
    imulq $8, %rdi, %rdi
    addq $4, %rdi
    imulq %rsi, %rdi
    addq $24, %rdi
    addq %rsi, %rdi
    addq $8, %rdi
    movslq %edi, %rdi
    movq %rdi, %r12
    movq %r12, %rdi
    call __fern_alloc
    movq %rax, %r13
    movq %r12, %rcx
    movq %rbx, %rsi
    movq %r13, %rdi
    rep movsb
    pushq $0
    popq %rax
    movq %r13, %rax
    call __fn___map_own_copied_cols.r
    movl $16, %edi
    call __fern_alloc
    movl $1, %edi
    movl %edi, (%rax)
    addq $8, %rax
    movq %r13, 0(%rax)
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_own_copied_cols:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_own_copied_cols.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $88, %rsp
    movq %rax, -48(%rbp)
.Lssa___map_own_copied_cols_0:
    movq -48(%rbp), %rsi
    addq $8, %rsi
    movslq (%rsi), %rdi
    movq %rdi, %r11
    cmpq $1, %r11
    sete %r11b
    movzbq %r11b, %r11
    movq %r11, -56(%rbp)
    movslq (%rsi), %rdi
    movq %rdi, %r11
    cmpq $4, %r11
    sete %r11b
    movzbq %r11b, %r11
    movq %r11, -64(%rbp)
    movslq (%rsi), %rsi
    cmpq $2, %rsi
    jne .Lssa___map_own_copied_cols_15
.Lssa___map_own_copied_cols_16:
    movq -48(%rbp), %rsi
    addq $20, %rsi
    movslq (%rsi), %rdi
.Lssa___map_own_copied_cols_21:
    movq %rdi, -72(%rbp)
    jmp .Lssa___map_own_copied_cols_14
.Lssa___map_own_copied_cols_15:
    movq $0, -72(%rbp)
.Lssa___map_own_copied_cols_14:
    movq -48(%rbp), %rdi
    addq $12, %rdi
    movslq (%rdi), %rdi
    andq $255, %rdi
.Lssa___map_own_copied_cols_24:
    movq %rdi, %r11
    cmpq $5, %r11
    sete %r11b
    movzbq %r11b, %r11
    movq %r11, -80(%rbp)
    movq -80(%rbp), %rsi
    testq %rsi, %rsi
    setz %sil
    movzbq %sil, %rsi
    xorl %r8d, %r8d
    cmpq $2, %rdi
    movq %rsi, %r11
    cmovlq %r8, %r11
    movq %r11, -88(%rbp)
.Lssa___map_own_copied_cols_11:
    movq -48(%rbp), %rax
    call __fn___map_val_cell_bytes.r
    movq %rax, -96(%rbp)
    movq -56(%rbp), %r11
    testq %r11, %r11
    jnz .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_10:
    movq -64(%rbp), %r11
    testq %r11, %r11
    jnz .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_9:
    movq -80(%rbp), %r11
    testq %r11, %r11
    jnz .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_8:
    movq -88(%rbp), %r11
    testq %r11, %r11
    jnz .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_7:
    cmpq $0, -96(%rbp)
    jne .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_6:
    cmpq $0, -72(%rbp)
    jne .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_5:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_own_copied_cols_3:
    movq -48(%rbp), %rdi
    movslq (%rdi), %rdi
    movq -48(%rbp), %r8
    addq $4, %r8
    movslq (%r8), %r11
    movq %r11, -104(%rbp)
    movl $8, %r12d
    movl $2, %r8d
    movq %r8, %r11
    imulq %r12, %r11
    movq %r11, -112(%rbp)
    movl $24, %r8d
.Lssa___map_own_copied_cols_55:
    movslq %r8d, %r8
    addq -48(%rbp), %r8
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%r8,%rdi), %r11
    movq %r11, -120(%rbp)
.Lssa___map_own_copied_cols_2:
    xorl %r15d, %r15d
.Lssa___map_own_copied_cols_57:
    cmpq -104(%rbp), %r15
    jge .Lssa___map_own_copied_cols_1
.Lssa___map_own_copied_cols_76:
    movq %r15, %rdi
    imulq -112(%rbp), %rdi
    movslq %edi, %rdi
    movq -120(%rbp), %rbx
    addq %rdi, %rbx
    movq -56(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_own_copied_cols_73
.Lssa___map_own_copied_cols_75:
    movq 0(%rbx), %rax
    call __fn___map_own_str_slot.r
    movq %rax, 0(%rbx)
.Lssa___map_own_copied_cols_73:
    movq -64(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_own_copied_cols_70
.Lssa___map_own_copied_cols_72:
    movq 0(%rbx), %rdi
    testb $1, %dil
    jnz .Lssa___map_own_copied_cols_rcinc189
    cmpq $0x10000, %rdi
    jb .Lssa___map_own_copied_cols_rcinc189
    movq %rdi, %rdx
    andq $-3, %rdx
    cmpl $0, -8(%rdx)
    js .Lssa___map_own_copied_cols_rcinc189
    addl $1, -8(%rdx)
.Lssa___map_own_copied_cols_rcinc189:
    movq %rdi, %rax
.Lssa___map_own_copied_cols_70:
    movq -80(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_own_copied_cols_67
.Lssa___map_own_copied_cols_69:
    movslq %r12d, %rdi
    leaq (%rbx,%rdi), %r14
    movq 0(%r14), %rax
    call __fn___map_own_str_slot.r
    movq %rax, 0(%r14)
.Lssa___map_own_copied_cols_67:
    movq -88(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_own_copied_cols_64
.Lssa___map_own_copied_cols_66:
    movslq %r12d, %rdi
    addq %rbx, %rdi
    movq 0(%rdi), %rsi
    movq -48(%rbp), %rax
    call __fn___map_retain_val.r
.Lssa___map_own_copied_cols_64:
    cmpq $0, -96(%rbp)
    je .Lssa___map_own_copied_cols_61
.Lssa___map_own_copied_cols_63:
    movq -96(%rbp), %rdi
    call __fern_alloc
    movq %rax, %r14
    movslq %r12d, %rsi
    leaq (%rbx,%rsi), %r13
    movq 0(%r13), %rsi
    movq -96(%rbp), %rcx
    movq %r14, %rdi
    rep movsb
    pushq $0
    popq %rax
    movq %r14, 0(%r13)
.Lssa___map_own_copied_cols_61:
    cmpq $0, -72(%rbp)
    je .Lssa___map_own_copied_cols_58
.Lssa___map_own_copied_cols_60:
    movq -72(%rbp), %rdi
    call __fern_alloc
    movq %rax, %r13
    movq 0(%rbx), %rsi
    movq -72(%rbp), %rcx
    movq %r13, %rdi
    rep movsb
    pushq $0
    popq %rax
    movq %r13, 0(%rbx)
.Lssa___map_own_copied_cols_58:
    addq $1, %r15
    cmpq -104(%rbp), %r15
    jl .Lssa___map_own_copied_cols_76
.Lssa___map_own_copied_cols_1:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_own_str_slot:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_own_str_slot.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_own_str_slot_0:
    cmpq %rbx, %rbx
    jne .Lssa___map_own_str_slot_4
.Lssa___map_own_str_slot_6:
    testb $1, %bl
    jnz .Lssa___map_own_str_slot_rcinc18
    cmpq $0x10000, %rbx
    jb .Lssa___map_own_str_slot_rcinc18
    movq %rbx, %rdx
    andq $-3, %rdx
    cmpl $0, -8(%rdx)
    js .Lssa___map_own_str_slot_rcinc18
    addl $1, -8(%rdx)
.Lssa___map_own_str_slot_rcinc18:
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_own_str_slot_4:
    movl $2, %esi
    imulq $8, %rsi, %rsi
    subq $4, %rsi
    movslq %esi, %rsi
    addq %rbx, %rsi
    movslq (%rsi), %rsi
    cmpq $0, %rsi
    jge .Lssa___map_own_str_slot_1
.Lssa___map_own_str_slot_3:
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_own_str_slot_1:
    movq 0(%rbx), %rsi
    testb $1, %sil
    jnz .Lssa___map_own_str_slot_rcinc31
    cmpq $0x10000, %rsi
    jb .Lssa___map_own_str_slot_rcinc31
    movq %rsi, %rdx
    andq $-3, %rdx
    cmpl $0, -8(%rdx)
    js .Lssa___map_own_str_slot_rcinc31
    addl $1, -8(%rdx)
.Lssa___map_own_str_slot_rcinc31:
    movq %rsi, %rax
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_len_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_len_impl.r:
.Lssa___map_len_impl_0:
    movq 0(%rax), %rsi
    addq $4, %rsi
    movslq (%rsi), %rax
    ret
    .cfi_endproc
__fn___map_hash_scalar:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_hash_scalar.r:
.Lssa___map_hash_scalar_0:
    xorq $61, %rax
    movl %eax, %esi
    shrq $16, %rsi
    xorq %rsi, %rax
    movq %rax, %rsi
    shlq $3, %rsi
    addq %rsi, %rax
    movl %eax, %esi
    shrq $4, %rsi
    xorq %rsi, %rax
    imulq $668265261, %rax, %rax
    movslq %eax, %rax
    movl %eax, %esi
    shrq $15, %rsi
    movslq %esi, %rsi
    xorq %rsi, %rax
    ret
    .cfi_endproc
__fn___map_eq_scalar:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_eq_scalar.r:
.Lssa___map_eq_scalar_0:
    cmpq %rsi, %rax
    sete %al
    movzbq %al, %rax
    ret
    .cfi_endproc
__fn___map_hash_wide:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_hash_wide.r:
.Lssa___map_hash_wide_0:
    movq 0(%rax), %rsi
    movq %rsi, %rdi
    sarq $32, %rdi
    xorq %rdi, %rsi
    xorq $61, %rsi
    movl %esi, %edi
    shrq $16, %rdi
    xorq %rdi, %rsi
    movq %rsi, %rdi
    shlq $3, %rdi
    addq %rdi, %rsi
    movl %esi, %edi
    shrq $4, %rdi
    xorq %rdi, %rsi
    imulq $668265261, %rsi, %rsi
    movslq %esi, %rsi
    movl %esi, %edi
    shrq $15, %rdi
    movslq %edi, %rdi
    movq %rsi, %rax
    xorq %rdi, %rax
    ret
    .cfi_endproc
__fn___map_eq_wide:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_eq_wide.r:
.Lssa___map_eq_wide_0:
    movq 0(%rax), %rdi
    movq 0(%rsi), %r8
    movq %rdi, %rax
    cmpq %r8, %rax
    sete %al
    movzbq %al, %rax
    ret
    .cfi_endproc
__fn___map_hash_str:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_hash_str.r:
.Lssa___map_hash_str_0:
    xorl %esi, %esi
    jmp __fn___map_fnv_str_seeded.r
    .cfi_endproc
__fn___map_eq_str:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_eq_str.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___map_eq_str_0:
    movq 8(%rax), %rdx
    cmpq 8(%rsi), %rdx
    jne .Lssa___map_eq_str_streqn5
    call __fn___fern_str_eq.r
    jmp .Lssa___map_eq_str_streqd5
.Lssa___map_eq_str_streqn5:
    xorl %eax, %eax
.Lssa___map_eq_str_streqd5:
    movq %rax, %rdi
    movq %rdi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_bucket_hash:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_bucket_hash.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___map_bucket_hash_0:
    cmpq $0, %rdi
    je .Lssa___map_bucket_hash_1
.Lssa___map_bucket_hash_3:
    movq %rdi, %rsi
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    jmp __fn___map_fnv_str_seeded.r
    .cfi_restore_state
.Lssa___map_bucket_hash_1:
    movq %rsi, %r11
    movq %rax, %rsi
    movq %r11, %rax
    call *8(%rax)
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_lookup:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_lookup.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa___map_lookup_0:
    movq 0(%rbx), %rsi
    addq $8, %rsi
    movslq (%rsi), %r13
    cmpq $0, %r13
    jne .Lssa___map_lookup_4
.Lssa___map_lookup_6:
    leaq .K0(%rip), %r14
    leaq .K1(%rip), %r15
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq %r14, %rdi
    movq %r15, %r8
    call __fn___map_lookup_keyed.r
    movq %rax, %r12
    cmpq $0x10000, %r14
    jb .Lssa___map_lookup_rcdeck28
    cmpl $1, -8(%r14)
    jg .Lssa___map_lookup_rcdecd28
    cmpl $0, -8(%r14)
    js .Lssa___map_lookup_rcdeck28
    movq %r14, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_lookup_rcdece28
.Lssa___map_lookup_rcdecd28:
    subl $1, -8(%r14)
.Lssa___map_lookup_rcdeck28:
    movq %r14, %rax
.Lssa___map_lookup_rcdece28:
    cmpq $0x10000, %r15
    jb .Lssa___map_lookup_rcdeck29
    cmpl $1, -8(%r15)
    jg .Lssa___map_lookup_rcdecd29
    cmpl $0, -8(%r15)
    js .Lssa___map_lookup_rcdeck29
    movq %r15, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_lookup_rcdece29
.Lssa___map_lookup_rcdecd29:
    subl $1, -8(%r15)
.Lssa___map_lookup_rcdeck29:
    movq %r15, %rax
.Lssa___map_lookup_rcdece29:
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_4:
    cmpq $2, %r13
    jne .Lssa___map_lookup_1
.Lssa___map_lookup_3:
    leaq .K2(%rip), %r13
    leaq .K3(%rip), %r12
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq %r13, %rdi
    movq %r12, %r8
    call __fn___map_lookup_keyed.r
    movq %rax, %r15
    cmpq $0x10000, %r13
    jb .Lssa___map_lookup_rcdeck35
    cmpl $1, -8(%r13)
    jg .Lssa___map_lookup_rcdecd35
    cmpl $0, -8(%r13)
    js .Lssa___map_lookup_rcdeck35
    movq %r13, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_lookup_rcdece35
.Lssa___map_lookup_rcdecd35:
    subl $1, -8(%r13)
.Lssa___map_lookup_rcdeck35:
    movq %r13, %rax
.Lssa___map_lookup_rcdece35:
    cmpq $0x10000, %r12
    jb .Lssa___map_lookup_rcdeck36
    cmpl $1, -8(%r12)
    jg .Lssa___map_lookup_rcdecd36
    cmpl $0, -8(%r12)
    js .Lssa___map_lookup_rcdeck36
    movq %r12, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_lookup_rcdece36
.Lssa___map_lookup_rcdecd36:
    subl $1, -8(%r12)
.Lssa___map_lookup_rcdeck36:
    movq %r12, %rax
.Lssa___map_lookup_rcdece36:
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_1:
    leaq .K4(%rip), %r15
    leaq .K5(%rip), %r12
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq %r15, %rdi
    movq %r12, %r8
    call __fn___map_lookup_keyed.r
    movq %rax, %r13
    cmpq $0x10000, %r15
    jb .Lssa___map_lookup_rcdeck40
    cmpl $1, -8(%r15)
    jg .Lssa___map_lookup_rcdecd40
    cmpl $0, -8(%r15)
    js .Lssa___map_lookup_rcdeck40
    movq %r15, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_lookup_rcdece40
.Lssa___map_lookup_rcdecd40:
    subl $1, -8(%r15)
.Lssa___map_lookup_rcdeck40:
    movq %r15, %rax
.Lssa___map_lookup_rcdece40:
    cmpq $0x10000, %r12
    jb .Lssa___map_lookup_rcdeck41
    cmpl $1, -8(%r12)
    jg .Lssa___map_lookup_rcdecd41
    cmpl $0, -8(%r12)
    js .Lssa___map_lookup_rcdeck41
    movq %r12, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_lookup_rcdece41
.Lssa___map_lookup_rcdecd41:
    subl $1, -8(%r12)
.Lssa___map_lookup_rcdeck41:
    movq %r12, %rax
.Lssa___map_lookup_rcdece41:
    movq %r13, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_has_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_has_impl.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___map_has_impl_0:
    call __fn___map_lookup.r
    cmpq $-1, %rax
    setne %al
    movzbq %al, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_val_kind:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_val_kind.r:
.Lssa___map_val_kind_0:
    addq $12, %rax
    movslq (%rax), %rax
    andq $255, %rax
    ret
    .cfi_endproc
__fn___map_val_stride:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_val_stride.r:
.Lssa___map_val_stride_0:
    addq $12, %rax
    movslq (%rax), %rax
    sarq $8, %rax
    ret
    .cfi_endproc
__fn___map_val_cell_bytes:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_val_cell_bytes.r:
.Lssa___map_val_cell_bytes_0:
    leaq 12(%rax), %rsi
    movslq (%rsi), %rsi
    andq $255, %rsi
.Lssa___map_val_cell_bytes_4:
    cmpq $0, %rsi
    je .Lssa___map_val_cell_bytes_1
.Lssa___map_val_cell_bytes_3:
    xorl %eax, %eax
    ret
.Lssa___map_val_cell_bytes_1:
    addq $12, %rax
    movslq (%rax), %rax
    sarq $8, %rax
    ret
    .cfi_endproc
__fn___map_key_cell_bytes:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_key_cell_bytes.r:
.Lssa___map_key_cell_bytes_0:
    addq $20, %rax
    movslq (%rax), %rax
    ret
    .cfi_endproc
__fn___map_free_key_cell:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_free_key_cell.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rsi, %rbx
.Lssa___map_free_key_cell_0:
    leaq 20(%rax), %rsi
    movslq (%rsi), %r12
.Lssa___map_free_key_cell_10:
    cmpq $0, %r12
    jne .Lssa___map_free_key_cell_7
.Lssa___map_free_key_cell_9:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_free_key_cell_7:
    cmpq $0, %rbx
    jne .Lssa___map_free_key_cell_4
.Lssa___map_free_key_cell_6:
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_free_key_cell_4:
    addq $8, %rax
    movslq (%rax), %rax
    cmpq $1, %rax
    jne .Lssa___map_free_key_cell_1
.Lssa___map_free_key_cell_3:
    testb $1, %bl
    jnz .Lssa___map_free_key_cell_rcdeck34
    cmpq $0x10000, %rbx
    jb .Lssa___map_free_key_cell_rcdeck34
    cmpl $1, -8(%rbx)
    jg .Lssa___map_free_key_cell_rcdecd34
    cmpl $0, -8(%rbx)
    js .Lssa___map_free_key_cell_rcdeck34
    movq %rbx, %rax
    call __fn___fern_str_free.u
    jmp .Lssa___map_free_key_cell_rcdece34
.Lssa___map_free_key_cell_rcdecd34:
    subl $1, -8(%rbx)
.Lssa___map_free_key_cell_rcdeck34:
    movq %rbx, %rax
.Lssa___map_free_key_cell_rcdece34:
.Lssa___map_free_key_cell_1:
    movq %r12, %rsi
    movq %rbx, %rdi
    call __fern_raw_free
    pushq $0
    popq %rax
    xorl %eax, %eax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_free_val_cell:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_free_val_cell.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rsi, %rbx
.Lssa___map_free_val_cell_0:
    call __fn___map_val_cell_bytes.r
    cmpq $0, %rax
    jne .Lssa___map_free_val_cell_4
.Lssa___map_free_val_cell_6:
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_free_val_cell_4:
    cmpq $0, %rbx
    jne .Lssa___map_free_val_cell_1
.Lssa___map_free_val_cell_3:
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_free_val_cell_1:
    movq %rax, %rsi
    movq %rbx, %rdi
    call __fern_raw_free
    pushq $0
    popq %rax
    movq %rax, %rsi
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_str_val_cell_bytes:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_str_val_cell_bytes.r:
.Lssa___map_str_val_cell_bytes_0:
    leaq 12(%rax), %rsi
    movslq (%rsi), %rsi
    andq $255, %rsi
.Lssa___map_str_val_cell_bytes_4:
    cmpq $5, %rsi
    je .Lssa___map_str_val_cell_bytes_1
.Lssa___map_str_val_cell_bytes_3:
    xorl %eax, %eax
    ret
.Lssa___map_str_val_cell_bytes_1:
    addq $12, %rax
    movslq (%rax), %rax
    sarq $8, %rax
    ret
    .cfi_endproc
__fn___map_dec_value:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_dec_value.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
    movq %rsi, %r12
.Lssa___map_dec_value_0:
    leaq 12(%rbx), %rsi
    movslq (%rsi), %rsi
    movq %rsi, %r13
    andq $255, %r13
.Lssa___map_dec_value_20:
    cmpq $0, %r13
    jne .Lssa___map_dec_value_17
.Lssa___map_dec_value_19:
    movq %rbx, %rax
    movq %r12, %rsi
    call __fn___map_free_val_cell.r
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_dec_value_17:
    cmpq $5, %r13
    jne .Lssa___map_dec_value_8
.Lssa___map_dec_value_16:
    cmpq $0, %r12
    jne .Lssa___map_dec_value_13
.Lssa___map_dec_value_15:
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_dec_value_13:
    testb $1, %r12b
    jnz .Lssa___map_dec_value_rcdeck53
    cmpq $0x10000, %r12
    jb .Lssa___map_dec_value_rcdeck53
    cmpl $1, -8(%r12)
    jg .Lssa___map_dec_value_rcdecd53
    cmpl $0, -8(%r12)
    js .Lssa___map_dec_value_rcdeck53
    movq %r12, %rax
    call __fn___fern_str_free.u
    jmp .Lssa___map_dec_value_rcdece53
.Lssa___map_dec_value_rcdecd53:
    subl $1, -8(%r12)
.Lssa___map_dec_value_rcdeck53:
    movq %r12, %rax
.Lssa___map_dec_value_rcdece53:
    movq %rbx, %rax
    call __fn___map_str_val_cell_bytes.r
    cmpq $0, %rax
    je .Lssa___map_dec_value_10
.Lssa___map_dec_value_12:
    movq %rax, %rsi
    movq %r12, %rdi
    call __fern_raw_free
    pushq $0
    popq %rax
    movq %rax, %rsi
.Lssa___map_dec_value_10:
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_dec_value_8:
    cmpq $2, %r13
    je .Lssa___map_dec_value_47
.Lssa___map_dec_value_7:
    cmpq $3, %r13
    je .Lssa___map_dec_value_47
.Lssa___map_dec_value_6:
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_dec_value_47:
    cmpq $3, %r13
    sete %r13b
    movzbq %r13b, %r13
.Lssa___map_dec_value_1:
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_retain_val:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_retain_val.r:
.Lssa___map_retain_val_0:
    addq $12, %rax
    movslq (%rax), %rax
    andq $255, %rax
.Lssa___map_retain_val_5:
    cmpq $2, %rax
    jl .Lssa___map_retain_val_1
.Lssa___map_retain_val_4:
    cmpq $5, %rax
    je .Lssa___map_retain_val_1
.Lssa___map_retain_val_3:
    testb $1, %sil
    jnz .Lssa___map_retain_val_rcinc24
    cmpq $0x10000, %rsi
    jb .Lssa___map_retain_val_rcinc24
    movq %rsi, %rdx
    andq $-3, %rdx
    cmpl $0, -8(%rdx)
    js .Lssa___map_retain_val_rcinc24
    addl $1, -8(%rdx)
.Lssa___map_retain_val_rcinc24:
    movq %rsi, %rax
    ret
.Lssa___map_retain_val_1:
    movq %rsi, %rax
    ret
    .cfi_endproc
__fn___map_val_at:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_val_at.r:
.Lssa___map_val_at_0:
    movq 0(%rax), %rdi
    movslq (%rdi), %r8
    movl $8, %r9d
    movl $24, %r10d
.Lssa___map_val_at_1:
    movslq %r10d, %r10
    addq %r10, %rdi
    shlq $2, %r8
    movslq %r8d, %r8
    addq %r8, %rdi
    movl $2, %r8d
    imulq %r9, %r8
    imulq %r8, %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movslq %r9d, %r9
    addq %r9, %rdi
    movq 0(%rdi), %rax
    ret
    .cfi_endproc
__fn___map_get_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_get_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
.Lssa___map_get_impl_0:
    movq %rbx, %rax
    call __fn___map_lookup.r
    cmpq $-1, %rax
    jne .Lssa___map_get_impl_1
.Lssa___map_get_impl_3:
    leaq .K6(%rip), %rsi
    movq %rsi, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_get_impl_1:
    movq 0(%rbx), %r12
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq %rax, %rsi
    movq %r12, %rax
    call __fn___map_retain_val.r
    movq %rax, %rbx
    movq $2, %rdi
    call __fern_arr_box
    xorl %esi, %esi
    movq %rsi, 0(%rax)
    movq %rbx, 8(%rax)
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_get_or_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_get_or_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa___map_get_or_impl_0:
    movq %rbx, %rax
    call __fn___map_lookup.r
    cmpq $-1, %rax
    jne .Lssa___map_get_or_impl_1
.Lssa___map_get_or_impl_3:
    movq 0(%rbx), %rsi
    movq %rsi, %rax
    movq %r12, %rsi
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    jmp __fn___map_retain_val.r
    .cfi_restore_state
.Lssa___map_get_or_impl_1:
    movq 0(%rbx), %r12
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq %rax, %rsi
    movq %r12, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    jmp __fn___map_retain_val.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_lookup_val:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_lookup_val.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_lookup_val_0:
    movq %rbx, %rax
    call __fn___map_lookup.r
    cmpq $-1, %rax
    jne .Lssa___map_lookup_val_1
.Lssa___map_lookup_val_3:
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_val_1:
    movq %rax, %rsi
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    jmp __fn___map_val_at.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_put_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_put_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $24, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
    movq %rdi, -56(%rbp)
.Lssa___map_put_impl_0:
    movq 0(%rbx), %rsi
    addq $8, %rsi
    movslq (%rsi), %r14
    cmpq $0, %r14
    jne .Lssa___map_put_impl_4
.Lssa___map_put_impl_6:
    leaq .K0(%rip), %r15
    leaq .K1(%rip), %r12
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq -56(%rbp), %rdi
    movq %r15, %r8
    movq %r12, %r9
    call __fn___map_put_keyed.r
    movq %rax, %r13
    cmpq $0x10000, %r15
    jb .Lssa___map_put_impl_rcdeck29
    cmpl $1, -8(%r15)
    jg .Lssa___map_put_impl_rcdecd29
    cmpl $0, -8(%r15)
    js .Lssa___map_put_impl_rcdeck29
    movq %r15, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_put_impl_rcdece29
.Lssa___map_put_impl_rcdecd29:
    subl $1, -8(%r15)
.Lssa___map_put_impl_rcdeck29:
    movq %r15, %rax
.Lssa___map_put_impl_rcdece29:
    cmpq $0x10000, %r12
    jb .Lssa___map_put_impl_rcdeck30
    cmpl $1, -8(%r12)
    jg .Lssa___map_put_impl_rcdecd30
    cmpl $0, -8(%r12)
    js .Lssa___map_put_impl_rcdeck30
    movq %r12, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_put_impl_rcdece30
.Lssa___map_put_impl_rcdecd30:
    subl $1, -8(%r12)
.Lssa___map_put_impl_rcdeck30:
    movq %r12, %rax
.Lssa___map_put_impl_rcdece30:
    movq %r13, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_put_impl_4:
    cmpq $2, %r14
    jne .Lssa___map_put_impl_1
.Lssa___map_put_impl_3:
    leaq .K2(%rip), %r14
    leaq .K3(%rip), %r13
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq -56(%rbp), %rdi
    movq %r14, %r8
    movq %r13, %r9
    call __fn___map_put_keyed.r
    movq %rax, %r12
    cmpq $0x10000, %r14
    jb .Lssa___map_put_impl_rcdeck36
    cmpl $1, -8(%r14)
    jg .Lssa___map_put_impl_rcdecd36
    cmpl $0, -8(%r14)
    js .Lssa___map_put_impl_rcdeck36
    movq %r14, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_put_impl_rcdece36
.Lssa___map_put_impl_rcdecd36:
    subl $1, -8(%r14)
.Lssa___map_put_impl_rcdeck36:
    movq %r14, %rax
.Lssa___map_put_impl_rcdece36:
    cmpq $0x10000, %r13
    jb .Lssa___map_put_impl_rcdeck37
    cmpl $1, -8(%r13)
    jg .Lssa___map_put_impl_rcdecd37
    cmpl $0, -8(%r13)
    js .Lssa___map_put_impl_rcdeck37
    movq %r13, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_put_impl_rcdece37
.Lssa___map_put_impl_rcdecd37:
    subl $1, -8(%r13)
.Lssa___map_put_impl_rcdeck37:
    movq %r13, %rax
.Lssa___map_put_impl_rcdece37:
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_put_impl_1:
    leaq .K4(%rip), %r12
    leaq .K5(%rip), %r13
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq -56(%rbp), %rdi
    movq %r12, %r8
    movq %r13, %r9
    call __fn___map_put_keyed.r
    movq %rax, %r14
    cmpq $0x10000, %r12
    jb .Lssa___map_put_impl_rcdeck41
    cmpl $1, -8(%r12)
    jg .Lssa___map_put_impl_rcdecd41
    cmpl $0, -8(%r12)
    js .Lssa___map_put_impl_rcdeck41
    movq %r12, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_put_impl_rcdece41
.Lssa___map_put_impl_rcdecd41:
    subl $1, -8(%r12)
.Lssa___map_put_impl_rcdeck41:
    movq %r12, %rax
.Lssa___map_put_impl_rcdece41:
    cmpq $0x10000, %r13
    jb .Lssa___map_put_impl_rcdeck42
    cmpl $1, -8(%r13)
    jg .Lssa___map_put_impl_rcdecd42
    cmpl $0, -8(%r13)
    js .Lssa___map_put_impl_rcdeck42
    movq %r13, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_put_impl_rcdece42
.Lssa___map_put_impl_rcdecd42:
    subl $1, -8(%r13)
.Lssa___map_put_impl_rcdeck42:
    movq %r13, %rax
.Lssa___map_put_impl_rcdece42:
    movq %r14, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_i32_column:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_i32_column.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rsi, -48(%rbp)
.Lssa___map_i32_column_0:
    movq 0(%rax), %rsi
    movslq (%rsi), %rdi
    leaq 4(%rsi), %r8
    movslq (%r8), %r12
    movl $2, %r8d
    imulq $8, %r8, %r13
    movl $24, %r8d
.Lssa___map_i32_column_3:
    movslq %r8d, %r8
    addq %r8, %rsi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r14
    leaq .K7(%rip), %rdi
.Lssa___map_i32_column_2:
    movq %rdi, %r15
    xorl %ebx, %ebx
.Lssa___map_i32_column_5:
    cmpq %r12, %rbx
    jge .Lssa___map_i32_column_1
.Lssa___map_i32_column_6:
    movq %rbx, %rdi
    imulq %r13, %rdi
    movslq %edi, %rdi
    addq %r14, %rdi
    movq -48(%rbp), %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movslq (%rdi), %rsi
    movq %r15, %rdi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_i32_column_apush75s
.Lssa___map_i32_column_apush75o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_i32_column_apush75e
.Lssa___map_i32_column_apush75s:
    call __fern_arr_push_owned
.Lssa___map_i32_column_apush75e:
    movq %rax, %r15
    addq $1, %rbx
    cmpq %r12, %rbx
    jl .Lssa___map_i32_column_6
.Lssa___map_i32_column_1:
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_cell:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_cell.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_cell_0:
    movl $8, %edi
    call __fern_alloc
    movq %rbx, 0(%rax)
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_cell_load:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_cell_load.r:
.Lssa___map_cell_load_0:
    movq 0(%rax), %rsi
    movq %rsi, %rax
    ret
    .cfi_endproc
__fn___map_cell_free:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_cell_free.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_cell_free_0:
    movl $8, %esi
    movq %rbx, %rdi
    call __fern_raw_free
    pushq $0
    popq %rax
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_get_cell_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_get_cell_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_get_cell_impl_0:
    movq %rbx, %rax
    call __fn___map_lookup.r
    cmpq $-1, %rax
    jne .Lssa___map_get_cell_impl_1
.Lssa___map_get_cell_impl_3:
    leaq .K6(%rip), %rsi
    movq %rsi, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_get_cell_impl_1:
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq 0(%rax), %rbx
    movq $2, %rdi
    call __fern_arr_box
    xorl %esi, %esi
    movq %rsi, 0(%rax)
    movq %rbx, 8(%rax)
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_get_cell_f64_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_get_cell_f64_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_get_cell_f64_impl_0:
    movq %rbx, %rax
    call __fn___map_lookup.r
    cmpq $-1, %rax
    jne .Lssa___map_get_cell_f64_impl_1
.Lssa___map_get_cell_f64_impl_3:
    leaq .K6(%rip), %rsi
    movq %rsi, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_get_cell_f64_impl_1:
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq 0(%rax), %rsi
    movq %rsi, %rbx
    movq $2, %rdi
    call __fern_arr_box
    xorl %esi, %esi
    movq %rsi, 0(%rax)
    movq %rbx, 8(%rax)
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_get_cell_keyed_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_get_cell_keyed_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_get_cell_keyed_impl_0:
    movq %rbx, %rax
    call __fn___map_lookup_keyed.r
    cmpq $-1, %rax
    jne .Lssa___map_get_cell_keyed_impl_1
.Lssa___map_get_cell_keyed_impl_3:
    leaq .K6(%rip), %r8
    movq %r8, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_get_cell_keyed_impl_1:
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq 0(%rax), %rbx
    movq $2, %rdi
    call __fern_arr_box
    xorl %r8d, %r8d
    movq %r8, 0(%rax)
    movq %rbx, 8(%rax)
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_get_cell_f64_keyed_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_get_cell_f64_keyed_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_get_cell_f64_keyed_impl_0:
    movq %rbx, %rax
    call __fn___map_lookup_keyed.r
    cmpq $-1, %rax
    jne .Lssa___map_get_cell_f64_keyed_impl_1
.Lssa___map_get_cell_f64_keyed_impl_3:
    leaq .K6(%rip), %r8
    movq %r8, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_get_cell_f64_keyed_impl_1:
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq 0(%rax), %r8
    movq %r8, %rbx
    movq $2, %rdi
    call __fern_arr_box
    xorl %r8d, %r8d
    movq %r8, 0(%rax)
    movq %rbx, 8(%rax)
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_cell_column:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_cell_column.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rsi, -48(%rbp)
.Lssa___map_cell_column_0:
    movq 0(%rax), %rsi
    movslq (%rsi), %rdi
    leaq 4(%rsi), %r8
    movslq (%r8), %r12
    movl $2, %r8d
    imulq $8, %r8, %r13
    movl $24, %r8d
.Lssa___map_cell_column_3:
    movslq %r8d, %r8
    addq %r8, %rsi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r14
    leaq .K7(%rip), %rdi
.Lssa___map_cell_column_2:
    movq %rdi, %r15
    xorl %ebx, %ebx
.Lssa___map_cell_column_5:
    cmpq %r12, %rbx
    jge .Lssa___map_cell_column_1
.Lssa___map_cell_column_6:
    movq %rbx, %rdi
    imulq %r13, %rdi
    movslq %edi, %rdi
    addq %r14, %rdi
    movq -48(%rbp), %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movq 0(%rdi), %rsi
    movq 0(%rsi), %rdi
    movq %rdi, %rsi
    movq %r15, %rdi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_cell_column_apush77s
.Lssa___map_cell_column_apush77o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_cell_column_apush77e
.Lssa___map_cell_column_apush77s:
    call __fern_arr_push_owned
.Lssa___map_cell_column_apush77e:
    movq %rax, %r15
    addq $1, %rbx
    cmpq %r12, %rbx
    jl .Lssa___map_cell_column_6
.Lssa___map_cell_column_1:
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_cell_f64_column:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_cell_f64_column.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rsi, -48(%rbp)
.Lssa___map_cell_f64_column_0:
    movq 0(%rax), %rsi
    movslq (%rsi), %rdi
    leaq 4(%rsi), %r8
    movslq (%r8), %r12
    movl $2, %r8d
    imulq $8, %r8, %r13
    movl $24, %r8d
.Lssa___map_cell_f64_column_3:
    movslq %r8d, %r8
    addq %r8, %rsi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r14
    leaq .K7(%rip), %rdi
.Lssa___map_cell_f64_column_2:
    movq %rdi, %r15
    xorl %ebx, %ebx
.Lssa___map_cell_f64_column_5:
    cmpq %r12, %rbx
    jge .Lssa___map_cell_f64_column_1
.Lssa___map_cell_f64_column_6:
    movq %rbx, %rdi
    imulq %r13, %rdi
    movslq %edi, %rdi
    addq %r14, %rdi
    movq -48(%rbp), %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movq 0(%rdi), %rsi
    movq 0(%rsi), %rdi
    movq %rdi, %rsi
    movq %r15, %rdi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_cell_f64_column_apush79s
.Lssa___map_cell_f64_column_apush79o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_cell_f64_column_apush79e
.Lssa___map_cell_f64_column_apush79s:
    call __fern_arr_push_owned
.Lssa___map_cell_f64_column_apush79e:
    movq %rax, %r15
    addq $1, %rbx
    cmpq %r12, %rbx
    jl .Lssa___map_cell_f64_column_6
.Lssa___map_cell_f64_column_1:
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_bool_column:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_bool_column.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rsi, -48(%rbp)
.Lssa___map_bool_column_0:
    movq 0(%rax), %rsi
    movslq (%rsi), %rdi
    leaq 4(%rsi), %r8
    movslq (%r8), %r12
    movl $2, %r8d
    imulq $8, %r8, %r13
    movl $24, %r8d
.Lssa___map_bool_column_3:
    movslq %r8d, %r8
    addq %r8, %rsi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r14
    leaq .K7(%rip), %rdi
.Lssa___map_bool_column_2:
    movq %rdi, %r15
    xorl %ebx, %ebx
.Lssa___map_bool_column_5:
    cmpq %r12, %rbx
    jge .Lssa___map_bool_column_1
.Lssa___map_bool_column_6:
    movq %rbx, %rdi
    imulq %r13, %rdi
    movslq %edi, %rdi
    addq %r14, %rdi
    movq -48(%rbp), %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movslq (%rdi), %rdi
    movq %rdi, %rsi
    cmpq $0, %rsi
    setne %sil
    movzbq %sil, %rsi
    movq %r15, %rdi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_bool_column_apush79s
.Lssa___map_bool_column_apush79o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_bool_column_apush79e
.Lssa___map_bool_column_apush79s:
    call __fern_arr_push_owned
.Lssa___map_bool_column_apush79e:
    movq %rax, %r15
    addq $1, %rbx
    cmpq %r12, %rbx
    jl .Lssa___map_bool_column_6
.Lssa___map_bool_column_1:
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_u8_column:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_u8_column.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %rcx
    .cfi_def_cfa_offset 48
    movq %rsi, %rbx
.Lssa___map_u8_column_0:
    movq 0(%rax), %rsi
    movslq (%rsi), %rdi
    leaq 4(%rsi), %r8
    movslq (%r8), %r12
    movl $2, %r8d
    imulq $8, %r8, %r13
    movl $24, %r8d
.Lssa___map_u8_column_3:
    movslq %r8d, %r8
    addq %r8, %rsi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r14
    movq %r12, %rdi
    call __fern_alloc_bytes
.Lssa___map_u8_column_2:
    xorl %edi, %edi
.Lssa___map_u8_column_5:
    cmpq %r12, %rdi
    jge .Lssa___map_u8_column_1
.Lssa___map_u8_column_6:
    movq %rdi, %rsi
    imulq %r13, %rsi
    movslq %esi, %rsi
    addq %r14, %rsi
    movslq %ebx, %r8
    addq %r8, %rsi
    movslq (%rsi), %rsi
    andq $255, %rsi
    movb %sil, 8(%rax,%rdi)
    addq $1, %rdi
    cmpq %r12, %rdi
    jl .Lssa___map_u8_column_6
.Lssa___map_u8_column_1:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_string_column:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_string_column.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $24, %rsp
    movq %rsi, -48(%rbp)
.Lssa___map_string_column_0:
    movq 0(%rax), %rsi
    movslq (%rsi), %rdi
    leaq 4(%rsi), %r8
    movslq (%r8), %r11
    movq %r11, -56(%rbp)
    movl $2, %r8d
    imulq $8, %r8, %r11
    movq %r11, -64(%rbp)
    movl $24, %r8d
.Lssa___map_string_column_3:
    movslq %r8d, %r8
    addq %r8, %rsi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r14
    movq $4, %rdi
    call __fern_arr_box
    movq %rax, %rdi
    xorl %esi, %esi
    movq %rsi, 0(%rdi)
.Lssa___map_string_column_2:
    movq %rdi, %r15
    xorl %ebx, %ebx
.Lssa___map_string_column_5:
    cmpq -56(%rbp), %rbx
    jge .Lssa___map_string_column_1
.Lssa___map_string_column_6:
    movq %rbx, %r8
    imulq -64(%rbp), %r8
    movslq %r8d, %r8
    addq %r14, %r8
    movq -48(%rbp), %rsi
    movslq %esi, %rsi
    addq %rsi, %r8
    movq 0(%r8), %r12
    testb $1, %r12b
    jnz .Lssa___map_string_column_rcinc84
    cmpq $0x10000, %r12
    jb .Lssa___map_string_column_rcinc84
    cmpl $0, -8(%r12)
    js .Lssa___map_string_column_rcinc84
    addl $1, -8(%r12)
.Lssa___map_string_column_rcinc84:
    movq %r12, %rax
    testb $1, %r15b
    jnz .Lssa___map_string_column_uq6
    cmpq $0x10000, %r15
    jb .Lssa___map_string_column_uq6
    cmpl $1, -8(%r15)
.Lssa___map_string_column_uq6:
    jne .Lssa___map_string_column_12
.Lssa___map_string_column_11:
    movq %r15, %rdi
    movq %r12, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_string_column_apush86s
.Lssa___map_string_column_apush86o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_string_column_apush86e
.Lssa___map_string_column_apush86s:
    call __fern_arr_push_owned
.Lssa___map_string_column_apush86e:
    movq %rax, %r15
    jmp .Lssa___map_string_column_13
.Lssa___map_string_column_12:
    movq %r15, %rdi
    movq %r12, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_string_column_apush87s
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lssa___map_string_column_apush87o
    testl %ecx, %ecx
    jns .Lssa___map_string_column_apush87s
.Lssa___map_string_column_apush87o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_string_column_apush87e
.Lssa___map_string_column_apush87s:
    call __fern_arr_push
.Lssa___map_string_column_apush87e:
    movq %rax, %r13
    movq %r15, %rax
    call __fn___fern_arr_inc_elems.r
    cmpq $0x10000, %r15
    jb .Lssa___map_string_column_rcdeck89
    cmpl $1, -8(%r15)
    jg .Lssa___map_string_column_rcdecd89
    cmpl $0, -8(%r15)
    js .Lssa___map_string_column_rcdeck89
    movq %r15, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_string_column_rcdece89
.Lssa___map_string_column_rcdecd89:
    subl $1, -8(%r15)
.Lssa___map_string_column_rcdeck89:
    movq %r15, %rax
.Lssa___map_string_column_rcdece89:
    movq %r13, %r15
.Lssa___map_string_column_13:
    addq $1, %rbx
    cmpq -56(%rbp), %rbx
    jl .Lssa___map_string_column_6
.Lssa___map_string_column_1:
    testb $1, %r15b
    jnz .Lssa___map_string_column_rcinc94
    cmpq $0x10000, %r15
    jb .Lssa___map_string_column_rcinc94
    movq %r15, %rdx
    andq $-3, %rdx
    cmpl $0, -8(%rdx)
    js .Lssa___map_string_column_rcinc94
    addl $1, -8(%rdx)
.Lssa___map_string_column_rcinc94:
    movq %r15, %rbx
    testb $1, %r15b
    jnz .Lssa___map_string_column_uq1
    cmpq $0x10000, %r15
    jb .Lssa___map_string_column_uq1
    cmpl $1, -8(%r15)
.Lssa___map_string_column_uq1:
    jne .Lssa___map_string_column_18
.Lssa___map_string_column_16:
    xorl %r14d, %r14d
.Lssa___map_string_column_20:
    movq 0(%r15), %r8
    cmpq %r8, %r14
    jge .Lssa___map_string_column_18
.Lssa___map_string_column_21:
    movq 8(%r15,%r14,8), %r8
    testb $1, %r8b
    jnz .Lssa___map_string_column_rcdeck101
    cmpq $0x10000, %r8
    jb .Lssa___map_string_column_rcdeck101
    cmpl $1, -8(%r8)
    jg .Lssa___map_string_column_rcdecd101
    cmpl $0, -8(%r8)
    js .Lssa___map_string_column_rcdeck101
    movq %r8, %rax
    call __fn___fern_str_free.u
    jmp .Lssa___map_string_column_rcdece101
.Lssa___map_string_column_rcdecd101:
    subl $1, -8(%r8)
.Lssa___map_string_column_rcdeck101:
    movq %r8, %rax
.Lssa___map_string_column_rcdece101:
    addq $1, %r14
    jmp .Lssa___map_string_column_20
.Lssa___map_string_column_18:
    cmpq $0x10000, %r15
    jb .Lssa___map_string_column_rcdeck105
    cmpl $1, -8(%r15)
    jg .Lssa___map_string_column_rcdecd105
    cmpl $0, -8(%r15)
    js .Lssa___map_string_column_rcdeck105
    movq %r15, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_string_column_rcdece105
.Lssa___map_string_column_rcdecd105:
    subl $1, -8(%r15)
.Lssa___map_string_column_rcdeck105:
    movq %r15, %rax
.Lssa___map_string_column_rcdece105:
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_box_column:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_box_column.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rsi, -48(%rbp)
    movq %rdi, -56(%rbp)
.Lssa___map_box_column_0:
    movq 0(%rax), %rsi
    movslq (%rsi), %rdi
    leaq 4(%rsi), %r8
    movslq (%r8), %r11
    movq %r11, -64(%rbp)
    movl $2, %r8d
    imulq $8, %r8, %r11
    movq %r11, -72(%rbp)
    movl $24, %r8d
.Lssa___map_box_column_3:
    movslq %r8d, %r8
    addq %r8, %rsi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r15
    movq $4, %rdi
    call __fern_arr_box
    movq %rax, %rdi
    xorl %esi, %esi
    movq %rsi, 0(%rdi)
.Lssa___map_box_column_2:
    movq %rdi, %rbx
    xorl %r12d, %r12d
.Lssa___map_box_column_5:
    cmpq -64(%rbp), %r12
    jge .Lssa___map_box_column_1
.Lssa___map_box_column_9:
    movq %r12, %r8
    imulq -72(%rbp), %r8
    movslq %r8d, %r8
    addq %r15, %r8
    movq -48(%rbp), %rsi
    movslq %esi, %rsi
    addq %rsi, %r8
    movq 0(%r8), %r13
    movq -56(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_box_column_7
.Lssa___map_box_column_8:
    testb $1, %r13b
    jnz .Lssa___map_box_column_rcinc86
    cmpq $0x10000, %r13
    jb .Lssa___map_box_column_rcinc86
    movq %r13, %rdx
    andq $-3, %rdx
    cmpl $0, -8(%rdx)
    js .Lssa___map_box_column_rcinc86
    addl $1, -8(%rdx)
.Lssa___map_box_column_rcinc86:
    movq %r13, %rsi
    movq %rsi, %r13
    jmp .Lssa___map_box_column_6
.Lssa___map_box_column_7:
.Lssa___map_box_column_6:
    testb $1, %bl
    jnz .Lssa___map_box_column_uq6
    cmpq $0x10000, %rbx
    jb .Lssa___map_box_column_uq6
    cmpl $1, -8(%rbx)
.Lssa___map_box_column_uq6:
    jne .Lssa___map_box_column_20
.Lssa___map_box_column_19:
    movq %rbx, %rdi
    movq %r13, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_box_column_apush89s
.Lssa___map_box_column_apush89o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_box_column_apush89e
.Lssa___map_box_column_apush89s:
    call __fern_arr_push_owned
.Lssa___map_box_column_apush89e:
    movq %rax, %rbx
    jmp .Lssa___map_box_column_21
.Lssa___map_box_column_20:
    movq %rbx, %rdi
    movq %r13, %rsi
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lssa___map_box_column_apush90s
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lssa___map_box_column_apush90o
    testl %ecx, %ecx
    jns .Lssa___map_box_column_apush90s
.Lssa___map_box_column_apush90o:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    jmp .Lssa___map_box_column_apush90e
.Lssa___map_box_column_apush90s:
    call __fern_arr_push
.Lssa___map_box_column_apush90e:
    movq %rax, %r14
    cmpq $0x10000, %rbx
    jb .Lssa___map_box_column_rcdeck91
    cmpl $1, -8(%rbx)
    jg .Lssa___map_box_column_rcdecd91
    cmpl $0, -8(%rbx)
    js .Lssa___map_box_column_rcdeck91
    movq %rbx, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_box_column_rcdece91
.Lssa___map_box_column_rcdecd91:
    subl $1, -8(%rbx)
.Lssa___map_box_column_rcdeck91:
    movq %rbx, %rax
.Lssa___map_box_column_rcdece91:
    movq %r14, %rbx
.Lssa___map_box_column_21:
    addq $1, %r12
    cmpq -64(%rbp), %r12
    jl .Lssa___map_box_column_9
.Lssa___map_box_column_1:
    testb $1, %bl
    jnz .Lssa___map_box_column_rcinc96
    cmpq $0x10000, %rbx
    jb .Lssa___map_box_column_rcinc96
    movq %rbx, %rdx
    andq $-3, %rdx
    cmpl $0, -8(%rdx)
    js .Lssa___map_box_column_rcinc96
    addl $1, -8(%rdx)
.Lssa___map_box_column_rcinc96:
    movq %rbx, %r12
    cmpq $0x10000, %rbx
    jb .Lssa___map_box_column_rcdeck97
    cmpl $1, -8(%rbx)
    jg .Lssa___map_box_column_rcdecd97
    cmpl $0, -8(%rbx)
    js .Lssa___map_box_column_rcdeck97
    movq %rbx, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_box_column_rcdece97
.Lssa___map_box_column_rcdecd97:
    subl $1, -8(%rbx)
.Lssa___map_box_column_rcdeck97:
    movq %rbx, %rax
.Lssa___map_box_column_rcdece97:
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_drop_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_drop_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, -48(%rbp)
.Lssa___map_drop_impl_0:
    cmpq $0, -48(%rbp)
    jne .Lssa___map_drop_impl_11
.Lssa___map_drop_impl_13:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_drop_impl_11:
    movq -48(%rbp), %rsi
    subq $8, %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jne .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_10:
    movq -48(%rbp), %r11
    movq 0(%r11), %r12
    cmpq $0, %r12
    je .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_9:
    leaq 8(%r12), %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    je .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_8:
    leaq 20(%r12), %rsi
    movslq (%rsi), %rsi
.Lssa___map_drop_impl_30:
    cmpq $0, %rsi
    je .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_7:
    leaq 4(%r12), %rsi
    movslq (%rsi), %r13
    movl $2, %esi
    imulq $8, %rsi, %r14
    movl $24, %esi
.Lssa___map_drop_impl_36:
    movslq %esi, %rsi
    addq %r12, %rsi
    movslq (%r12), %rdi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r15
.Lssa___map_drop_impl_6:
    xorl %ebx, %ebx
.Lssa___map_drop_impl_38:
    cmpq %r13, %rbx
    jge .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_39:
    movq %rbx, %rdi
    imulq %r14, %rdi
    movslq %edi, %rdi
    addq %r15, %rdi
    movq 0(%rdi), %rsi
    movq %r12, %rax
    call __fn___map_free_key_cell.r
    addq $1, %rbx
    cmpq %r13, %rbx
    jl .Lssa___map_drop_impl_39
.Lssa___map_drop_impl_1:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    jmp __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_free_table:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_free_table.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_free_table_0:
    cmpq $0, %rbx
    jne .Lssa___map_free_table_7
.Lssa___map_free_table_9:
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_free_table_7:
    leaq -8(%rbx), %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    je .Lssa___map_free_table_4
.Lssa___map_free_table_6:
    cmpq $0x10000, %rbx
    jb .Lssa___map_free_table_rcdeck33
    cmpl $1, -8(%rbx)
    jg .Lssa___map_free_table_rcdecd33
    cmpl $0, -8(%rbx)
    js .Lssa___map_free_table_rcdeck33
    movq %rbx, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_free_table_rcdece33
.Lssa___map_free_table_rcdecd33:
    subl $1, -8(%rbx)
.Lssa___map_free_table_rcdeck33:
    movq %rbx, %rax
.Lssa___map_free_table_rcdece33:
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_free_table_4:
    movq 0(%rbx), %rsi
    cmpq $0, %rsi
    je .Lssa___map_free_table_1
.Lssa___map_free_table_3:
    movslq (%rsi), %rdi
.Lssa___map_free_table_22:
    movl $2, %r8d
    imulq $8, %r8, %r8
    addq $4, %r8
    imulq %rdi, %r8
    addq $24, %r8
    addq %rdi, %r8
    addq $8, %r8
    movslq %r8d, %r8
    movq %r8, %rdi
    xchgq %rdi, %rsi
    call __fern_raw_free
    pushq $0
    popq %rax
.Lssa___map_free_table_1:
    leaq -8(%rbx), %rdi
    movl $16, %esi
    call __fern_raw_free
    pushq $0
    popq %rax
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_key_of:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_key_of.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_key_of_0:
    movq %rbx, %rax
    call __fn___map_lookup.r
    cmpq $-1, %rax
    jne .Lssa___map_key_of_1
.Lssa___map_key_of_3:
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_key_of_1:
    movq 0(%rbx), %rsi
    movl $24, %edi
.Lssa___map_key_of_8:
    movslq %edi, %rdi
    addq %rsi, %rdi
    movslq (%rsi), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movl $2, %esi
    imulq $8, %rsi, %rsi
    imulq %rsi, %rax
    movslq %eax, %rax
    addq %rax, %rdi
    movq 0(%rdi), %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_key_of_keyed:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_key_of_keyed.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_key_of_keyed_0:
    movq %rbx, %rax
    call __fn___map_lookup_keyed.r
    cmpq $-1, %rax
    jne .Lssa___map_key_of_keyed_1
.Lssa___map_key_of_keyed_3:
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_key_of_keyed_1:
    movq 0(%rbx), %r8
    movl $24, %edi
.Lssa___map_key_of_keyed_8:
    movslq %edi, %rdi
    addq %r8, %rdi
    movslq (%r8), %r8
    shlq $2, %r8
    movslq %r8d, %r8
    addq %r8, %rdi
    movl $2, %r8d
    imulq $8, %r8, %r8
    imulq %r8, %rax
    movslq %eax, %rax
    addq %rax, %rdi
    movq 0(%rdi), %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_drop_keyed_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_drop_keyed_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $24, %rsp
    movq %rax, -48(%rbp)
    movq %rsi, %r12
    movq %rdi, %r13
.Lssa___map_drop_keyed_impl_0:
    cmpq $0, -48(%rbp)
    jne .Lssa___map_drop_keyed_impl_6
.Lssa___map_drop_keyed_impl_8:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_drop_keyed_impl_6:
    movq -48(%rbp), %rsi
    subq $8, %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jne .Lssa___map_drop_keyed_impl_1
.Lssa___map_drop_keyed_impl_5:
    movq -48(%rbp), %r11
    movq 0(%r11), %rsi
    leaq 4(%rsi), %rdi
    movslq (%rdi), %r11
    movq %r11, -56(%rbp)
    movl $8, %r15d
    movl $24, %edi
.Lssa___map_drop_keyed_impl_17:
    movslq %edi, %rdi
    addq %rsi, %rdi
    movslq (%rsi), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    leaq (%rdi,%rsi), %r11
    movq %r11, -64(%rbp)
.Lssa___map_drop_keyed_impl_4:
    xorl %r14d, %r14d
.Lssa___map_drop_keyed_impl_19:
    cmpq -56(%rbp), %r14
    jge .Lssa___map_drop_keyed_impl_1
.Lssa___map_drop_keyed_impl_20:
    movl $2, %esi
    imulq %r15, %rsi
    imulq %r14, %rsi
    movslq %esi, %rsi
    movq -64(%rbp), %rbx
    addq %rsi, %rbx
    movq 0(%rbx), %rsi
    movq %r12, %rax
    call *8(%rax)
    movslq %r15d, %rsi
    addq %rsi, %rbx
    movq 0(%rbx), %rsi
    movq %r13, %rax
    call *8(%rax)
    addq $1, %r14
    cmpq -56(%rbp), %r14
    jl .Lssa___map_drop_keyed_impl_20
.Lssa___map_drop_keyed_impl_1:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    jmp __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_drop_strcols_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___map_drop_strcols_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rax, -48(%rbp)
.Lssa___map_drop_strcols_impl_0:
    cmpq $0, -48(%rbp)
    jne .Lssa___map_drop_strcols_impl_6
.Lssa___map_drop_strcols_impl_8:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_drop_strcols_impl_6:
    movq -48(%rbp), %rsi
    subq $8, %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jne .Lssa___map_drop_strcols_impl_1
.Lssa___map_drop_strcols_impl_5:
    movq -48(%rbp), %r11
    movq 0(%r11), %r12
    leaq 8(%r12), %rsi
    movslq (%rsi), %rsi
    movq %rsi, %r11
    cmpq $1, %r11
    sete %r11b
    movzbq %r11b, %r11
    movq %r11, -56(%rbp)
    leaq 12(%r12), %rsi
    movslq (%rsi), %rsi
    andq $255, %rsi
.Lssa___map_drop_strcols_impl_17:
    movq %rsi, %r11
    cmpq $5, %r11
    sete %r11b
    movzbq %r11b, %r11
    movq %r11, -64(%rbp)
    leaq 4(%r12), %rsi
    movslq (%rsi), %r11
    movq %r11, -72(%rbp)
    movl $8, %ebx
    movl $24, %esi
.Lssa___map_drop_strcols_impl_19:
    movslq %esi, %rsi
    addq %r12, %rsi
    movslq (%r12), %rdi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r13
.Lssa___map_drop_strcols_impl_4:
    xorl %r14d, %r14d
.Lssa___map_drop_strcols_impl_21:
    cmpq -72(%rbp), %r14
    jge .Lssa___map_drop_strcols_impl_1
.Lssa___map_drop_strcols_impl_28:
    movl $2, %edi
    imulq %rbx, %rdi
    imulq %r14, %rdi
    movslq %edi, %rdi
    leaq (%r13,%rdi), %r15
    movq -56(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_drop_strcols_impl_26
.Lssa___map_drop_strcols_impl_27:
    movq 0(%r15), %rdi
    testb $1, %dil
    jnz .Lssa___map_drop_strcols_impl_rcdeck121
    cmpq $0x10000, %rdi
    jb .Lssa___map_drop_strcols_impl_rcdeck121
    cmpl $1, -8(%rdi)
    jg .Lssa___map_drop_strcols_impl_rcdecd121
    cmpl $0, -8(%rdi)
    js .Lssa___map_drop_strcols_impl_rcdeck121
    movq %rdi, %rax
    call __fn___fern_str_free.u
    jmp .Lssa___map_drop_strcols_impl_rcdece121
.Lssa___map_drop_strcols_impl_rcdecd121:
    subl $1, -8(%rdi)
.Lssa___map_drop_strcols_impl_rcdeck121:
    movq %rdi, %rax
.Lssa___map_drop_strcols_impl_rcdece121:
    jmp .Lssa___map_drop_strcols_impl_25
.Lssa___map_drop_strcols_impl_26:
    movq 0(%r15), %rsi
    movq %r12, %rax
    call __fn___map_free_key_cell.r
.Lssa___map_drop_strcols_impl_25:
    movq -64(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_drop_strcols_impl_23
.Lssa___map_drop_strcols_impl_24:
    movslq %ebx, %rsi
    addq %r15, %rsi
    movq 0(%rsi), %rdi
    testb $1, %dil
    jnz .Lssa___map_drop_strcols_impl_rcdeck128
    cmpq $0x10000, %rdi
    jb .Lssa___map_drop_strcols_impl_rcdeck128
    cmpl $1, -8(%rdi)
    jg .Lssa___map_drop_strcols_impl_rcdecd128
    cmpl $0, -8(%rdi)
    js .Lssa___map_drop_strcols_impl_rcdeck128
    movq %rdi, %rax
    call __fn___fern_str_free.u
    jmp .Lssa___map_drop_strcols_impl_rcdece128
.Lssa___map_drop_strcols_impl_rcdecd128:
    subl $1, -8(%rdi)
.Lssa___map_drop_strcols_impl_rcdeck128:
    movq %rdi, %rax
.Lssa___map_drop_strcols_impl_rcdece128:
    jmp .Lssa___map_drop_strcols_impl_22
.Lssa___map_drop_strcols_impl_23:
    movslq %ebx, %rdi
    addq %rdi, %r15
    movq 0(%r15), %rsi
    movq %r12, %rax
    call __fn___map_free_val_cell.r
.Lssa___map_drop_strcols_impl_22:
    addq $1, %r14
    cmpq -72(%rbp), %r14
    jl .Lssa___map_drop_strcols_impl_28
.Lssa___map_drop_strcols_impl_1:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    jmp __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_drop_boxes_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_drop_boxes_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $40, %rsp
    movq %rax, -48(%rbp)
    movq %rsi, %r12
.Lssa___map_drop_boxes_impl_0:
    cmpq $0, -48(%rbp)
    jne .Lssa___map_drop_boxes_impl_6
.Lssa___map_drop_boxes_impl_8:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_drop_boxes_impl_6:
    movq -48(%rbp), %rsi
    subq $8, %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jne .Lssa___map_drop_boxes_impl_1
.Lssa___map_drop_boxes_impl_5:
    movq -48(%rbp), %r11
    movq 0(%r11), %r13
    leaq 8(%r13), %rsi
    movslq (%rsi), %rsi
    movq %rsi, %r11
    cmpq $1, %r11
    sete %r11b
    movzbq %r11b, %r11
    movq %r11, -56(%rbp)
    leaq 4(%r13), %rsi
    movslq (%rsi), %r11
    movq %r11, -64(%rbp)
    movl $8, %ebx
    movl $24, %esi
.Lssa___map_drop_boxes_impl_17:
    movslq %esi, %rsi
    addq %r13, %rsi
    movslq (%r13), %rdi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r11
    movq %r11, -72(%rbp)
.Lssa___map_drop_boxes_impl_4:
    xorl %r15d, %r15d
.Lssa___map_drop_boxes_impl_19:
    cmpq -64(%rbp), %r15
    jge .Lssa___map_drop_boxes_impl_1
.Lssa___map_drop_boxes_impl_23:
    movl $2, %edi
    imulq %rbx, %rdi
    imulq %r15, %rdi
    movslq %edi, %rdi
    movq -72(%rbp), %r14
    addq %rdi, %r14
    movq -56(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_drop_boxes_impl_21
.Lssa___map_drop_boxes_impl_22:
    movq 0(%r14), %rdi
    testb $1, %dil
    jnz .Lssa___map_drop_boxes_impl_rcdeck99
    cmpq $0x10000, %rdi
    jb .Lssa___map_drop_boxes_impl_rcdeck99
    cmpl $1, -8(%rdi)
    jg .Lssa___map_drop_boxes_impl_rcdecd99
    cmpl $0, -8(%rdi)
    js .Lssa___map_drop_boxes_impl_rcdeck99
    movq %rdi, %rax
    call __fn___fern_str_free.u
    jmp .Lssa___map_drop_boxes_impl_rcdece99
.Lssa___map_drop_boxes_impl_rcdecd99:
    subl $1, -8(%rdi)
.Lssa___map_drop_boxes_impl_rcdeck99:
    movq %rdi, %rax
.Lssa___map_drop_boxes_impl_rcdece99:
    jmp .Lssa___map_drop_boxes_impl_20
.Lssa___map_drop_boxes_impl_21:
    movq 0(%r14), %rsi
    movq %r13, %rax
    call __fn___map_free_key_cell.r
.Lssa___map_drop_boxes_impl_20:
    movslq %ebx, %rsi
    addq %rsi, %r14
    movq 0(%r14), %rsi
    movq %r12, %rax
    call *8(%rax)
    addq $1, %r15
    cmpq -64(%rbp), %r15
    jl .Lssa___map_drop_boxes_impl_23
.Lssa___map_drop_boxes_impl_1:
    movq -48(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    jmp __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_delete_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_delete_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
.Lssa___map_delete_impl_0:
    movq 0(%rbx), %rsi
    addq $8, %rsi
    movslq (%rsi), %r13
    cmpq $0, %r13
    jne .Lssa___map_delete_impl_4
.Lssa___map_delete_impl_6:
    leaq .K0(%rip), %r14
    leaq .K1(%rip), %r15
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq %r14, %rdi
    movq %r15, %r8
    call __fn___map_delete_keyed_impl.r
    movq %rax, %r12
    cmpq $0x10000, %r14
    jb .Lssa___map_delete_impl_rcdeck28
    cmpl $1, -8(%r14)
    jg .Lssa___map_delete_impl_rcdecd28
    cmpl $0, -8(%r14)
    js .Lssa___map_delete_impl_rcdeck28
    movq %r14, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_delete_impl_rcdece28
.Lssa___map_delete_impl_rcdecd28:
    subl $1, -8(%r14)
.Lssa___map_delete_impl_rcdeck28:
    movq %r14, %rax
.Lssa___map_delete_impl_rcdece28:
    cmpq $0x10000, %r15
    jb .Lssa___map_delete_impl_rcdeck29
    cmpl $1, -8(%r15)
    jg .Lssa___map_delete_impl_rcdecd29
    cmpl $0, -8(%r15)
    js .Lssa___map_delete_impl_rcdeck29
    movq %r15, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_delete_impl_rcdece29
.Lssa___map_delete_impl_rcdecd29:
    subl $1, -8(%r15)
.Lssa___map_delete_impl_rcdeck29:
    movq %r15, %rax
.Lssa___map_delete_impl_rcdece29:
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_delete_impl_4:
    cmpq $2, %r13
    jne .Lssa___map_delete_impl_1
.Lssa___map_delete_impl_3:
    leaq .K2(%rip), %r13
    leaq .K3(%rip), %r12
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq %r13, %rdi
    movq %r12, %r8
    call __fn___map_delete_keyed_impl.r
    movq %rax, %r15
    cmpq $0x10000, %r13
    jb .Lssa___map_delete_impl_rcdeck35
    cmpl $1, -8(%r13)
    jg .Lssa___map_delete_impl_rcdecd35
    cmpl $0, -8(%r13)
    js .Lssa___map_delete_impl_rcdeck35
    movq %r13, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_delete_impl_rcdece35
.Lssa___map_delete_impl_rcdecd35:
    subl $1, -8(%r13)
.Lssa___map_delete_impl_rcdeck35:
    movq %r13, %rax
.Lssa___map_delete_impl_rcdece35:
    cmpq $0x10000, %r12
    jb .Lssa___map_delete_impl_rcdeck36
    cmpl $1, -8(%r12)
    jg .Lssa___map_delete_impl_rcdecd36
    cmpl $0, -8(%r12)
    js .Lssa___map_delete_impl_rcdeck36
    movq %r12, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_delete_impl_rcdece36
.Lssa___map_delete_impl_rcdecd36:
    subl $1, -8(%r12)
.Lssa___map_delete_impl_rcdeck36:
    movq %r12, %rax
.Lssa___map_delete_impl_rcdece36:
    movq %r15, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_delete_impl_1:
    leaq .K4(%rip), %r15
    leaq .K5(%rip), %r12
    movq %rbx, %rax
    movq -48(%rbp), %rsi
    movq %r15, %rdi
    movq %r12, %r8
    call __fn___map_delete_keyed_impl.r
    movq %rax, %r13
    cmpq $0x10000, %r15
    jb .Lssa___map_delete_impl_rcdeck40
    cmpl $1, -8(%r15)
    jg .Lssa___map_delete_impl_rcdecd40
    cmpl $0, -8(%r15)
    js .Lssa___map_delete_impl_rcdeck40
    movq %r15, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_delete_impl_rcdece40
.Lssa___map_delete_impl_rcdecd40:
    subl $1, -8(%r15)
.Lssa___map_delete_impl_rcdeck40:
    movq %r15, %rax
.Lssa___map_delete_impl_rcdece40:
    cmpq $0x10000, %r12
    jb .Lssa___map_delete_impl_rcdeck41
    cmpl $1, -8(%r12)
    jg .Lssa___map_delete_impl_rcdecd41
    cmpl $0, -8(%r12)
    js .Lssa___map_delete_impl_rcdeck41
    movq %r12, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___map_delete_impl_rcdece41
.Lssa___map_delete_impl_rcdecd41:
    subl $1, -8(%r12)
.Lssa___map_delete_impl_rcdeck41:
    movq %r12, %rax
.Lssa___map_delete_impl_rcdece41:
    movq %r13, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_lookup_keyed:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_lookup_keyed.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $88, %rsp
    movq %rsi, -48(%rbp)
    movq %rdi, -56(%rbp)
    movq %r8, %r13
.Lssa___map_lookup_keyed_0:
    movq 0(%rax), %r11
    movq %r11, -64(%rbp)
    movslq (%r11), %r11
    movq %r11, -72(%rbp)
    subq $1, %r11
    movq %r11, -80(%rbp)
    movl $2, %esi
    imulq $8, %rsi, %r15
    movl $24, %esi
.Lssa___map_lookup_keyed_20:
    movslq %esi, %rsi
    addq -64(%rbp), %rsi
    movq -72(%rbp), %rdi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r14
    movq -64(%rbp), %rdi
    addq $4, %rdi
    movslq (%rdi), %r11
    movq %r11, -88(%rbp)
    cmpq $8, %r11
    jg .Lssa___map_lookup_keyed_14
.Lssa___map_lookup_keyed_19:
.Lssa___map_lookup_keyed_18:
    xorl %ebx, %ebx
.Lssa___map_lookup_keyed_26:
    cmpq -88(%rbp), %rbx
    jge .Lssa___map_lookup_keyed_17
.Lssa___map_lookup_keyed_29:
    movq %rbx, %rdi
    imulq %r15, %rdi
    movslq %edi, %rdi
    addq %r14, %rdi
    movq 0(%rdi), %rsi
    movq %r13, %rax
    movq -48(%rbp), %rdi
    call *8(%rax)
    testq %rax, %rax
    jnz .Lssa___map_lookup_keyed_16
.Lssa___map_lookup_keyed_27:
    addq $1, %rbx
    cmpq -88(%rbp), %rbx
    jl .Lssa___map_lookup_keyed_29
.Lssa___map_lookup_keyed_17:
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_16:
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_14:
    movq -64(%rbp), %rsi
    addq $16, %rsi
    movslq (%rsi), %rdi
.Lssa___map_lookup_keyed_40:
    movq -48(%rbp), %rax
    movq -56(%rbp), %rsi
    call __fn___map_bucket_hash.r
    movq %rax, -56(%rbp)
    movq -56(%rbp), %r11
    andq -80(%rbp), %r11
    movq %r11, -88(%rbp)
    movl $24, %edi
.Lssa___map_lookup_keyed_42:
    movslq %edi, %rdi
    addq -64(%rbp), %rdi
    movq -88(%rbp), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movslq (%rdi), %rbx
    cmpq $-1, %rbx
    jne .Lssa___map_lookup_keyed_11
.Lssa___map_lookup_keyed_13:
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_11:
    cmpq $0, %rbx
    jl .Lssa___map_lookup_keyed_5
.Lssa___map_lookup_keyed_10:
    movq %rbx, %rdi
    imulq %r15, %rdi
    movslq %edi, %rdi
    addq %r14, %rdi
    movq 0(%rdi), %rsi
    movq %r13, %rax
    movq -48(%rbp), %rdi
    call *8(%rax)
    testq %rax, %rax
    jz .Lssa___map_lookup_keyed_5
.Lssa___map_lookup_keyed_9:
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_5:
    movl $24, %esi
    movslq %esi, %rsi
    addq -64(%rbp), %rsi
    movl $2, %edi
    imulq $8, %rdi, %rdi
    addq $4, %rdi
    imulq -72(%rbp), %rdi
    movslq %edi, %rdi
    addq %rdi, %rsi
    movq %rsi, %r11
    movq %r11, -96(%rbp)
    movabsq $9259542123273814144, %r11
    movq %r11, -104(%rbp)
    movq -56(%rbp), %rsi
    movl %esi, %esi
    shrq $25, %rsi
    movslq %esi, %rsi
    movabsq $72340172838076673, %rdi
    movq %rsi, %r11
    imulq %rdi, %r11
    movq %r11, -56(%rbp)
.Lssa___map_lookup_keyed_4:
    movq $0, -112(%rbp)
.Lssa___map_lookup_keyed_57:
    movq -112(%rbp), %r11
    cmpq -72(%rbp), %r11
    jge .Lssa___map_lookup_keyed_3
.Lssa___map_lookup_keyed_62:
    movq -88(%rbp), %rdi
    movslq %edi, %rdi
    addq -96(%rbp), %rdi
    movq 0(%rdi), %r11
    movq %r11, -120(%rbp)
    movq %r11, %rdi
    xorq -56(%rbp), %rdi
    movabsq $72340172838076673, %rsi
    movq %rdi, %r11
    subq %rsi, %r11
    movq %r11, %rsi
    andnq %rsi, %rdi, %rsi
    andq -104(%rbp), %rsi
.Lssa___map_lookup_keyed_61:
    movq %rsi, %rbx
.Lssa___map_lookup_keyed_67:
    cmpq $0, %rbx
    je .Lssa___map_lookup_keyed_60
.Lssa___map_lookup_keyed_70:
    tzcntq %rbx, %rsi
    sarq $3, %rsi
    addq -88(%rbp), %rsi
    andq -80(%rbp), %rsi
    movl $24, %edi
.Lssa___map_lookup_keyed_75:
    movslq %edi, %rdi
    addq -64(%rbp), %rdi
    shlq $2, %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movslq (%rdi), %r12
    movq %r12, %rdi
    imulq %r15, %rdi
    movslq %edi, %rdi
    addq %r14, %rdi
    movq 0(%rdi), %rsi
    movq %r13, %rax
    movq -48(%rbp), %rdi
    call *8(%rax)
    testq %rax, %rax
    jnz .Lssa___map_lookup_keyed_2
.Lssa___map_lookup_keyed_68:
    leaq -1(%rbx), %rsi
    andq %rsi, %rbx
    cmpq $0, %rbx
    jne .Lssa___map_lookup_keyed_70
.Lssa___map_lookup_keyed_60:
    movabsq $-9187201950435737472, %rsi
    xorq -120(%rbp), %rsi
    movabsq $72340172838076673, %rdi
    movq %rsi, %r11
    subq %rdi, %r11
    movq %r11, %rdi
    andnq %rdi, %rsi, %rdi
    andq -104(%rbp), %rdi
    cmpq $0, %rdi
    jne .Lssa___map_lookup_keyed_1
.Lssa___map_lookup_keyed_58:
    movq -88(%rbp), %rdi
    addq $8, %rdi
    movq %rdi, %r11
    andq -80(%rbp), %r11
    movq %r11, -88(%rbp)
    movq -112(%rbp), %rdi
    addq $8, %rdi
    movslq %edi, %r11
    movq %r11, -112(%rbp)
    movq -112(%rbp), %r11
    cmpq -72(%rbp), %r11
    jl .Lssa___map_lookup_keyed_62
.Lssa___map_lookup_keyed_3:
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_2:
    movq %r12, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_1:
    movq $-1, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_has_keyed_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_has_keyed_impl.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___map_has_keyed_impl_0:
    call __fn___map_lookup_keyed.r
    cmpq $-1, %rax
    setne %al
    movzbq %al, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_get_keyed_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_get_keyed_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
.Lssa___map_get_keyed_impl_0:
    movq %rbx, %rax
    call __fn___map_lookup_keyed.r
    cmpq $-1, %rax
    jne .Lssa___map_get_keyed_impl_1
.Lssa___map_get_keyed_impl_3:
    leaq .K6(%rip), %r8
    movq %r8, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_get_keyed_impl_1:
    movq 0(%rbx), %r12
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq %rax, %rsi
    movq %r12, %rax
    call __fn___map_retain_val.r
    movq %rax, %rbx
    movq $2, %rdi
    call __fern_arr_box
    xorl %esi, %esi
    movq %rsi, 0(%rax)
    movq %rbx, 8(%rax)
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_get_or_keyed_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn___map_get_or_keyed_impl.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %rcx
    .cfi_def_cfa_offset 32
    movq %rax, %rbx
    movq %rdi, %r12
.Lssa___map_get_or_keyed_impl_0:
    movq %rbx, %rax
    movq %r8, %rdi
    movq %r9, %r8
    call __fn___map_lookup_keyed.r
    cmpq $-1, %rax
    jne .Lssa___map_get_or_keyed_impl_1
.Lssa___map_get_or_keyed_impl_3:
    movq 0(%rbx), %r9
    movq %r9, %rax
    movq %r12, %rsi
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    jmp __fn___map_retain_val.r
    .cfi_restore_state
.Lssa___map_get_or_keyed_impl_1:
    movq 0(%rbx), %r12
    movq %rax, %rsi
    movq %rbx, %rax
    call __fn___map_val_at.r
    movq %rax, %rsi
    movq %r12, %rax
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    jmp __fn___map_retain_val.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_lookup_val_keyed:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_lookup_val_keyed.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    movq %rax, %rbx
.Lssa___map_lookup_val_keyed_0:
    movq %rbx, %rax
    call __fn___map_lookup_keyed.r
    cmpq $-1, %rax
    jne .Lssa___map_lookup_val_keyed_1
.Lssa___map_lookup_val_keyed_3:
    xorl %eax, %eax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
.Lssa___map_lookup_val_keyed_1:
    movq %rax, %rsi
    movq %rbx, %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    jmp __fn___map_val_at.r
    .cfi_restore_state
    .cfi_endproc
__fn___map_grow_keyed:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_grow_keyed.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $104, %rsp
    movq %rax, -48(%rbp)
    movq %rsi, -56(%rbp)
.Lssa___map_grow_keyed_0:
    movq -48(%rbp), %r11
    movq 0(%r11), %r11
    movq %r11, -64(%rbp)
    movq %r11, %rsi
    addq $16, %rsi
    movslq (%rsi), %r11
    movq %r11, -72(%rbp)
.Lssa___map_grow_keyed_6:
    movq -64(%rbp), %r11
    movslq (%r11), %r11
    movq %r11, -80(%rbp)
    movq -64(%rbp), %rsi
    addq $4, %rsi
    movslq (%rsi), %r11
    movq %r11, -88(%rbp)
    movq -64(%rbp), %rsi
    addq $8, %rsi
    movslq (%rsi), %r11
    movq %r11, -96(%rbp)
    movq -64(%rbp), %rsi
    addq $12, %rsi
    movslq (%rsi), %r11
    movq %r11, -104(%rbp)
    movl $24, %r15d
    movl $8, %r11d
    movq %r11, -112(%rbp)
    movl $2, %esi
    movq %rsi, %r11
    imulq -112(%rbp), %r11
    movq %r11, -120(%rbp)
    movq -64(%rbp), %rsi
    addq $24, %rsi
    movq -80(%rbp), %rdi
    shlq $2, %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r11
    movq %r11, -128(%rbp)
    movl $4, %edi
    movq -80(%rbp), %rsi
    shlq $1, %rsi
    movslq %esi, %rsi
    cmpq $0, -80(%rbp)
    movq %rsi, %r12
    cmoveq %rdi, %r12
.Lssa___map_grow_keyed_3:
    leaq -1(%r12), %r8
    movslq %r8d, %r14
    movl $2, %r8d
    imulq $8, %r8, %r8
    addq $4, %r8
    movq %r12, %r11
    imulq %r8, %r11
    movq %r11, -136(%rbp)
    movq %r15, %r8
    addq %r11, %r8
    addq %r12, %r8
    addq $8, %r8
    movslq %r8d, %r8
    movq %r8, %rdi
    call __fern_alloc
    movq %rax, %rbx
    movl %r12d, (%rbx)
    leaq 4(%rbx), %rdi
    movq -88(%rbp), %rcx
    movl %ecx, (%rdi)
    leaq 8(%rbx), %r8
    movq -96(%rbp), %rcx
    movl %ecx, (%r8)
    leaq 12(%rbx), %rdi
    movq -104(%rbp), %rcx
    movl %ecx, (%rdi)
    leaq 16(%rbx), %r8
    movq -72(%rbp), %rcx
    movl %ecx, (%r8)
    leaq 20(%rbx), %rdi
    movq -64(%rbp), %r8
    addq $20, %r8
    movslq (%r8), %r8
    movl %r8d, (%rdi)
    movslq %r15d, %rsi
    leaq (%rbx,%rsi), %r11
    movq %r11, -96(%rbp)
    movq %r12, %rsi
    shlq $2, %rsi
    movslq %esi, %r11
    movq %r11, -104(%rbp)
    movl $255, %esi
    movq -104(%rbp), %rcx
    movq %rsi, %rax
    movq -96(%rbp), %rdi
    cld
    rep stosb
    pushq $0
    popq %rax
    movq -136(%rbp), %rsi
    movslq %esi, %rsi
    addq -96(%rbp), %rsi
    movq %rsi, %r11
    movq %r11, -136(%rbp)
    leaq 8(%r12), %rsi
    movslq %esi, %rsi
    movl $128, %r8d
    movq %rsi, %rcx
    movq %r8, %rax
    movq -136(%rbp), %rdi
    cld
    rep stosb
    pushq $0
    popq %rax
    movq -96(%rbp), %r11
    addq -104(%rbp), %r11
    movq %r11, -96(%rbp)
.Lssa___map_grow_keyed_2:
    xorl %r13d, %r13d
.Lssa___map_grow_keyed_13:
    cmpq -88(%rbp), %r13
    jge .Lssa___map_grow_keyed_1
.Lssa___map_grow_keyed_17:
    movq %r13, %r8
    imulq -120(%rbp), %r8
    movslq %r8d, %r8
    movq -128(%rbp), %rsi
    addq %r8, %rsi
    movq 0(%rsi), %rax
    movq -112(%rbp), %rdi
    movslq %edi, %rdi
    addq %rdi, %rsi
    movq 0(%rsi), %r9
    addq -96(%rbp), %r8
    movq %rax, 0(%r8)
    addq %rdi, %r8
    movq %r9, 0(%r8)
    movq -56(%rbp), %rsi
    movq -72(%rbp), %rdi
    call __fn___map_bucket_hash.r
    movq %rax, %rdi
    andq %r14, %rdi
.Lssa___map_grow_keyed_16:
.Lssa___map_grow_keyed_22:
.Lssa___map_grow_keyed_25:
    movslq %r15d, %r8
    addq %rbx, %r8
    movq %rdi, %r9
    shlq $2, %r9
    movslq %r9d, %r9
    addq %r9, %r8
    movslq (%r8), %r8
    cmpq $-1, %r8
    je .Lssa___map_grow_keyed_15
.Lssa___map_grow_keyed_23:
    leaq 1(%rdi), %r8
    movslq %r8d, %r8
    movq %r8, %rdi
    andq %r14, %rdi
    jmp .Lssa___map_grow_keyed_22
.Lssa___map_grow_keyed_15:
    movslq %r15d, %r8
    addq %rbx, %r8
    movq %rdi, %r9
    shlq $2, %r9
    movslq %r9d, %r9
    addq %r9, %r8
    movl %r13d, (%r8)
    movl %eax, %eax
    shrq $25, %rax
    movslq %eax, %r8
    movq -136(%rbp), %rax
    movq %r12, %rsi
    call __fn___map_ctrl_set.r
.Lssa___map_grow_keyed_14:
    addq $1, %r13
    cmpq -88(%rbp), %r13
    jl .Lssa___map_grow_keyed_17
.Lssa___map_grow_keyed_1:
    movq -48(%rbp), %r11
    movq %rbx, 0(%r11)
    movl $2, %r8d
    imulq $8, %r8, %r8
    addq $4, %r8
    imulq -80(%rbp), %r8
    addq %r8, %r15
    addq -80(%rbp), %r15
    addq $8, %r15
    movslq %r15d, %r15
    movq %r15, %r8
    movq %r8, %rsi
    movq -64(%rbp), %rdi
    call __fern_raw_free
    pushq $0
    popq %rax
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_put_keyed:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
    movq 40(%rsp), %r9
__fn___map_put_keyed.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $136, %rsp
    movq %rax, %rbx
    movq %rsi, -48(%rbp)
    movq %rdi, -56(%rbp)
    movq %r8, -64(%rbp)
    movq %r9, %r15
.Lssa___map_put_keyed_0:
    movq 0(%rbx), %r13
    movslq (%r13), %r11
    movq %r11, -72(%rbp)
    leaq 4(%r13), %rsi
    movslq (%rsi), %r14
    leaq 1(%r14), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    movq %r11, %rdi
    imulq $3, %rdi, %rdi
    movslq %edi, %rdi
    cmpq %rdi, %rsi
    jl .Lssa___map_put_keyed_12
.Lssa___map_put_keyed_13:
    movq %rbx, %rax
    movq -64(%rbp), %rsi
    call __fn___map_grow_keyed.r
    movq 0(%rbx), %rax
    movslq (%rax), %rsi
    leaq 4(%rax), %rdi
    movslq (%rdi), %rdi
    movq %rax, %r13
    movq %rsi, -72(%rbp)
    movq %rdi, -80(%rbp)
    jmp .Lssa___map_put_keyed_11
.Lssa___map_put_keyed_12:
    movq %r14, -80(%rbp)
.Lssa___map_put_keyed_11:
    movq -72(%rbp), %rdi
    subq $1, %rdi
    movslq %edi, %rbx
    movl $8, %r11d
    movq %r11, -88(%rbp)
    movl $2, %edi
    movq %rdi, %r11
    imulq -88(%rbp), %r11
    movq %r11, -96(%rbp)
    movl $24, %edi
.Lssa___map_put_keyed_19:
    movslq %edi, %rdi
    addq %r13, %rdi
    movq -72(%rbp), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    leaq (%rdi,%rsi), %r11
    movq %r11, -104(%rbp)
    leaq 16(%r13), %rsi
    movslq (%rsi), %rdi
.Lssa___map_put_keyed_21:
    movq -48(%rbp), %rax
    movq -64(%rbp), %rsi
    call __fn___map_bucket_hash.r
    movq %rax, %r11
    andq %rbx, %r11
    movq %r11, -64(%rbp)
    movl %eax, %eax
    shrq $25, %rax
    movslq %eax, %r11
    movq %r11, -112(%rbp)
    movl $24, %edi
    movslq %edi, %rdi
    addq %r13, %rdi
    movl $2, %esi
    imulq $8, %rsi, %rsi
    addq $4, %rsi
    imulq -72(%rbp), %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movq %rdi, %r11
    movq %r11, -120(%rbp)
    movl $24, %edi
.Lssa___map_put_keyed_23:
    movslq %edi, %rdi
    addq %r13, %rdi
    movq -64(%rbp), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    addq %rsi, %rdi
    movslq (%rdi), %r11
    movq %r11, -128(%rbp)
    cmpq $-1, %r11
    jne .Lssa___map_put_keyed_9
.Lssa___map_put_keyed_10:
    movq -64(%rbp), %rdi
    jmp .Lssa___map_put_keyed_4
.Lssa___map_put_keyed_9:
    cmpq $0, -128(%rbp)
    jl .Lssa___map_put_keyed_5
.Lssa___map_put_keyed_8:
    movq -128(%rbp), %rdi
    imulq -96(%rbp), %rdi
    movslq %edi, %rdi
    addq -104(%rbp), %rdi
    movq 0(%rdi), %rsi
    movq %r15, %rax
    movq -48(%rbp), %rdi
    call *8(%rax)
    testq %rax, %rax
    jz .Lssa___map_put_keyed_5
.Lssa___map_put_keyed_7:
    movq -128(%rbp), %rsi
    imulq -96(%rbp), %rsi
    movslq %esi, %rsi
    addq -104(%rbp), %rsi
    movq -88(%rbp), %rdi
    movslq %edi, %rdi
    leaq (%rsi,%rdi), %r11
    movq %r11, -128(%rbp)
    movq 0(%r11), %r11
    movq %r11, -136(%rbp)
    movq %r13, %rax
    movq -136(%rbp), %rsi
    call __fn___map_dec_value.r
    movq -128(%rbp), %r11
    movq -56(%rbp), %rcx
    movq %rcx, 0(%r11)
    movq -136(%rbp), %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_put_keyed_5:
    movq $-1, %rdi
.Lssa___map_put_keyed_4:
    movabsq $9259542123273814144, %r11
    movq %r11, -128(%rbp)
    movq -112(%rbp), %rsi
    movslq %esi, %rsi
    movabsq $72340172838076673, %r8
    movq %rsi, %r11
    imulq %r8, %r11
    movq %r11, -136(%rbp)
    movq %rdi, %r8
    cmpq $-1, %r8
    setne %r8b
    movzbq %r8b, %r8
.Lssa___map_put_keyed_3:
    movq %rdi, -144(%rbp)
    movq %r8, -160(%rbp)
    movq $0, -152(%rbp)
.Lssa___map_put_keyed_38:
    movq -160(%rbp), %r11
    testq %r11, %r11
    jnz .Lssa___map_put_keyed_2
.Lssa___map_put_keyed_51:
    movq -152(%rbp), %r11
    cmpq -72(%rbp), %r11
    jge .Lssa___map_put_keyed_2
.Lssa___map_put_keyed_50:
    movq -64(%rbp), %r8
    movslq %r8d, %r8
    addq -120(%rbp), %r8
    movq 0(%r8), %r11
    movq %r11, -168(%rbp)
    movq %r11, %r8
    xorq -136(%rbp), %r8
    movabsq $72340172838076673, %rdi
    movq %r8, %r11
    subq %rdi, %r11
    movq %r11, %rdi
    andnq %rdi, %r8, %rdi
    andq -128(%rbp), %rdi
.Lssa___map_put_keyed_49:
    movq %rdi, %r14
.Lssa___map_put_keyed_60:
    cmpq $0, %r14
    je .Lssa___map_put_keyed_48
.Lssa___map_put_keyed_63:
    tzcntq %r14, %rdi
    sarq $3, %rdi
    addq -64(%rbp), %rdi
    andq %rbx, %rdi
    movl $24, %r8d
.Lssa___map_put_keyed_68:
    movslq %r8d, %r8
    addq %r13, %r8
    shlq $2, %rdi
    movslq %edi, %rdi
    addq %rdi, %r8
    movslq (%r8), %r12
    movq %r12, %r8
    imulq -96(%rbp), %r8
    movslq %r8d, %r8
    addq -104(%rbp), %r8
    movq 0(%r8), %rdi
    movq %r15, %rax
    movq %rdi, %rsi
    movq -48(%rbp), %rdi
    call *8(%rax)
    testq %rax, %rax
    jnz .Lssa___map_put_keyed_1
.Lssa___map_put_keyed_61:
    leaq -1(%r14), %rdi
    andq %rdi, %r14
    cmpq $0, %r14
    jne .Lssa___map_put_keyed_63
.Lssa___map_put_keyed_48:
    movabsq $-9187201950435737472, %rdi
    xorq -168(%rbp), %rdi
    movabsq $72340172838076673, %r8
    movq %rdi, %r11
    subq %r8, %r11
    movq %r11, %r8
    andnq %r8, %rdi, %r8
    andq -128(%rbp), %r8
    cmpq $-1, -144(%rbp)
    jne .Lssa___map_put_keyed_43
.Lssa___map_put_keyed_47:
    movabsq $-72340172838076674, %rdi
    xorq -168(%rbp), %rdi
    movabsq $72340172838076673, %rsi
    movq %rdi, %r11
    subq %rsi, %r11
    movq %r11, %rsi
    andnq %rsi, %rdi, %rsi
    andq -128(%rbp), %rsi
    orq %r8, %rsi
    cmpq $0, %rsi
    je .Lssa___map_put_keyed_45
.Lssa___map_put_keyed_46:
    tzcntq %rsi, %rsi
    sarq $3, %rsi
    addq -64(%rbp), %rsi
    movslq %esi, %rsi
    andq %rbx, %rsi
    movq %rsi, -144(%rbp)
    jmp .Lssa___map_put_keyed_44
.Lssa___map_put_keyed_45:
.Lssa___map_put_keyed_44:
    jmp .Lssa___map_put_keyed_42
.Lssa___map_put_keyed_43:
.Lssa___map_put_keyed_42:
    cmpq $0, %r8
    je .Lssa___map_put_keyed_40
.Lssa___map_put_keyed_41:
    movq $1, -160(%rbp)
    jmp .Lssa___map_put_keyed_39
.Lssa___map_put_keyed_40:
    movq -64(%rbp), %r8
    addq $8, %r8
    andq %rbx, %r8
    movq -152(%rbp), %rsi
    addq $8, %rsi
    movslq %esi, %rsi
    movq %r8, -64(%rbp)
    movq %rsi, -152(%rbp)
.Lssa___map_put_keyed_39:
    movq -160(%rbp), %r11
    testq %r11, %r11
    jz .Lssa___map_put_keyed_51
.Lssa___map_put_keyed_2:
    movq -80(%rbp), %rsi
    imulq -96(%rbp), %rsi
    movslq %esi, %rsi
    addq -104(%rbp), %rsi
    movq -48(%rbp), %rcx
    movq %rcx, 0(%rsi)
    movq -88(%rbp), %r8
    movslq %r8d, %r8
    addq %r8, %rsi
    movq -56(%rbp), %rcx
    movq %rcx, 0(%rsi)
    movl $24, %r8d
.Lssa___map_put_keyed_93:
    movslq %r8d, %r8
    addq %r13, %r8
    movq -144(%rbp), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    addq %rsi, %r8
    movq -80(%rbp), %rcx
    movl %ecx, (%r8)
    movq -120(%rbp), %rax
    movq -72(%rbp), %rsi
    movq -144(%rbp), %rdi
    movq -112(%rbp), %r8
    call __fn___map_ctrl_set.r
    leaq 4(%r13), %rsi
    movq -80(%rbp), %r8
    addq $1, %r8
    movslq %r8d, %r8
    movl %r8d, (%rsi)
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_put_keyed_1:
    imulq -96(%rbp), %r12
    movslq %r12d, %r12
    addq -104(%rbp), %r12
    movq -88(%rbp), %rdi
    movslq %edi, %rdi
    addq %rdi, %r12
    movq 0(%r12), %rbx
    movq %r13, %rax
    movq %rbx, %rsi
    call __fn___map_dec_value.r
    movq -56(%rbp), %rcx
    movq %rcx, 0(%r12)
    movq %rbx, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_delete_keyed_impl:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
    movq 32(%rsp), %r8
__fn___map_delete_keyed_impl.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $152, %rsp
    movq %rsi, -48(%rbp)
    movq %rdi, -56(%rbp)
    movq %r8, -64(%rbp)
.Lssa___map_delete_keyed_impl_0:
    movq 0(%rax), %r11
    movq %r11, -72(%rbp)
    movq %r11, %rsi
    addq $16, %rsi
    movslq (%rsi), %r11
    movq %r11, -80(%rbp)
.Lssa___map_delete_keyed_impl_20:
    movq -72(%rbp), %r11
    movslq (%r11), %r11
    movq %r11, -88(%rbp)
    movq -72(%rbp), %rsi
    addq $4, %rsi
    movslq (%rsi), %r11
    movq %r11, -96(%rbp)
    movq -88(%rbp), %rsi
    subq $1, %rsi
    movslq %esi, %r11
    movq %r11, -104(%rbp)
    movl $8, %r11d
    movq %r11, -112(%rbp)
    movl $2, %esi
    movq %rsi, %r11
    imulq -112(%rbp), %r11
    movq %r11, -120(%rbp)
    movl $24, %esi
.Lssa___map_delete_keyed_impl_22:
    movslq %esi, %rsi
    movq -72(%rbp), %r11
    addq %rsi, %r11
    movq %r11, -128(%rbp)
    movq -88(%rbp), %rsi
    shlq $2, %rsi
    movslq %esi, %rsi
    addq %rsi, %r11
    movq %r11, -136(%rbp)
    movq -48(%rbp), %rax
    movq -56(%rbp), %rsi
    movq -80(%rbp), %rdi
    call __fn___map_bucket_hash.r
    movq %rax, -144(%rbp)
    movq -144(%rbp), %r11
    andq -104(%rbp), %r11
    movq %r11, -152(%rbp)
    movl $2, %esi
    imulq $8, %rsi, %rsi
    addq $4, %rsi
    imulq -88(%rbp), %rsi
    movslq %esi, %rsi
    addq -128(%rbp), %rsi
    movq %rsi, %r11
    movq %r11, -128(%rbp)
    movl $24, %esi
.Lssa___map_delete_keyed_impl_24:
    movslq %esi, %rsi
    addq -72(%rbp), %rsi
    movq -152(%rbp), %rdi
    shlq $2, %rdi
    movslq %edi, %rdi
    addq %rdi, %rsi
    movslq (%rsi), %r11
    movq %r11, -160(%rbp)
    cmpq $-1, %r11
    jne .Lssa___map_delete_keyed_impl_17
.Lssa___map_delete_keyed_impl_19:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_delete_keyed_impl_17:
    cmpq $0, -160(%rbp)
    jl .Lssa___map_delete_keyed_impl_12
.Lssa___map_delete_keyed_impl_16:
    movq -160(%rbp), %rsi
    imulq -120(%rbp), %rsi
    movslq %esi, %rsi
    addq -136(%rbp), %rsi
    movq 0(%rsi), %rdi
    movq -64(%rbp), %rax
    movq %rdi, %rsi
    movq -48(%rbp), %rdi
    call *8(%rax)
    testq %rax, %rax
    jz .Lssa___map_delete_keyed_impl_14
.Lssa___map_delete_keyed_impl_15:
    movq -152(%rbp), %rdi
    movq -160(%rbp), %rsi
    movl $1, %r8d
    jmp .Lssa___map_delete_keyed_impl_13
.Lssa___map_delete_keyed_impl_14:
    movq $-1, %rdi
    xorl %esi, %esi
    xorl %r8d, %r8d
.Lssa___map_delete_keyed_impl_13:
    jmp .Lssa___map_delete_keyed_impl_11
.Lssa___map_delete_keyed_impl_12:
    movq $-1, %rdi
    xorl %esi, %esi
    xorl %r8d, %r8d
.Lssa___map_delete_keyed_impl_11:
    movabsq $9259542123273814144, %r11
    movq %r11, -160(%rbp)
    movq -144(%rbp), %r9
    movl %r9d, %r9d
    shrq $25, %r9
    movslq %r9d, %r9
    movabsq $72340172838076673, %r10
    movq %r9, %r11
    imulq %r10, %r11
    movq %r11, -144(%rbp)
.Lssa___map_delete_keyed_impl_10:
    movq %rdi, -168(%rbp)
    movq %rsi, -176(%rbp)
    movq $0, -184(%rbp)
.Lssa___map_delete_keyed_impl_40:
    testq %r8, %r8
    jnz .Lssa___map_delete_keyed_impl_9
.Lssa___map_delete_keyed_impl_50:
    movq -184(%rbp), %r11
    cmpq -88(%rbp), %r11
    jge .Lssa___map_delete_keyed_impl_9
.Lssa___map_delete_keyed_impl_49:
    movq -152(%rbp), %r10
    movslq %r10d, %r10
    addq -128(%rbp), %r10
    movq 0(%r10), %r11
    movq %r11, -192(%rbp)
    movq %r11, %r10
    xorq -144(%rbp), %r10
    movabsq $72340172838076673, %r9
    movq %r10, %r11
    subq %r9, %r11
    movq %r11, %r9
    andnq %r9, %r10, %r9
    andq -160(%rbp), %r9
.Lssa___map_delete_keyed_impl_48:
    movq -176(%rbp), %rbx
    movq %r8, %r14
    movq %r9, %r15
.Lssa___map_delete_keyed_impl_59:
    cmpq $0, %r15
    je .Lssa___map_delete_keyed_impl_47
.Lssa___map_delete_keyed_impl_63:
    tzcntq %r15, %r9
    sarq $3, %r9
    addq -152(%rbp), %r9
    movslq %r9d, %r9
    movq %r9, %r13
    andq -104(%rbp), %r13
    movl $24, %r9d
.Lssa___map_delete_keyed_impl_68:
    movslq %r9d, %r9
    addq -72(%rbp), %r9
    movq %r13, %r8
    shlq $2, %r8
    movslq %r8d, %r8
    addq %r8, %r9
    movslq (%r9), %r12
    movq %r12, %r9
    imulq -120(%rbp), %r9
    movslq %r9d, %r9
    addq -136(%rbp), %r9
    movq 0(%r9), %r8
    movq -64(%rbp), %rax
    movq %r8, %rsi
    movq -48(%rbp), %rdi
    call *8(%rax)
    testq %rax, %rax
    jz .Lssa___map_delete_keyed_impl_61
.Lssa___map_delete_keyed_impl_62:
    movq %r13, -168(%rbp)
    movq %r12, %rbx
    movl $1, %r14d
    xorl %r15d, %r15d
    jmp .Lssa___map_delete_keyed_impl_60
.Lssa___map_delete_keyed_impl_61:
    leaq -1(%r15), %r8
    andq %r8, %r15
.Lssa___map_delete_keyed_impl_60:
    cmpq $0, %r15
    jne .Lssa___map_delete_keyed_impl_63
.Lssa___map_delete_keyed_impl_47:
    testq %r14, %r14
    jz .Lssa___map_delete_keyed_impl_45
.Lssa___map_delete_keyed_impl_46:
    movq %r14, %r8
    jmp .Lssa___map_delete_keyed_impl_41
.Lssa___map_delete_keyed_impl_45:
    movabsq $-9187201950435737472, %r8
    xorq -192(%rbp), %r8
    movabsq $72340172838076673, %r9
    movq %r8, %r11
    subq %r9, %r11
    movq %r11, %r9
    andnq %r9, %r8, %r9
    andq -160(%rbp), %r9
    cmpq $0, %r9
    je .Lssa___map_delete_keyed_impl_43
.Lssa___map_delete_keyed_impl_44:
    movq -152(%rbp), %r9
    movq -184(%rbp), %r8
    movl $1, %r14d
    jmp .Lssa___map_delete_keyed_impl_42
.Lssa___map_delete_keyed_impl_43:
    movq -152(%rbp), %r9
    addq $8, %r9
    andq -104(%rbp), %r9
    movq -184(%rbp), %r8
    addq $8, %r8
    movslq %r8d, %r8
.Lssa___map_delete_keyed_impl_42:
    movq %r9, -152(%rbp)
    movq %r8, -184(%rbp)
    movq %r14, %r8
.Lssa___map_delete_keyed_impl_41:
    movq %rbx, -176(%rbp)
    testq %r8, %r8
    jz .Lssa___map_delete_keyed_impl_50
.Lssa___map_delete_keyed_impl_9:
    cmpq $-1, -168(%rbp)
    jne .Lssa___map_delete_keyed_impl_6
.Lssa___map_delete_keyed_impl_8:
    xorl %eax, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
.Lssa___map_delete_keyed_impl_6:
    movq -176(%rbp), %r8
    imulq -120(%rbp), %r8
    movslq %r8d, %r8
    movq -136(%rbp), %rbx
    addq %r8, %rbx
    movq -112(%rbp), %r8
    movslq %r8d, %r8
    addq %rbx, %r8
    movq 0(%r8), %rsi
    movq -72(%rbp), %rax
    call __fn___map_free_val_cell.r
    movq 0(%rbx), %rsi
    movq -72(%rbp), %rax
    call __fn___map_free_key_cell.r
    movl $24, %esi
.Lssa___map_delete_keyed_impl_93:
    movslq %esi, %rsi
    addq -72(%rbp), %rsi
    movq -168(%rbp), %r8
    shlq $2, %r8
    movslq %r8d, %r8
    addq %r8, %rsi
    movq $-2, %r8
    movl %r8d, (%rsi)
    movl $254, %r8d
    movq -128(%rbp), %rax
    movq -88(%rbp), %rsi
    movq -168(%rbp), %rdi
    call __fn___map_ctrl_set.r
    movq -96(%rbp), %r8
    subq $1, %r8
    movslq %r8d, %rbx
    cmpq %rbx, -176(%rbp)
    je .Lssa___map_delete_keyed_impl_1
.Lssa___map_delete_keyed_impl_5:
    movq %rbx, %r8
    imulq -120(%rbp), %r8
    movslq %r8d, %r8
    addq -136(%rbp), %r8
    movq 0(%r8), %r14
    movq %r14, %rax
    movq -56(%rbp), %rsi
    movq -80(%rbp), %rdi
    call __fn___map_bucket_hash.r
    andq -104(%rbp), %rax
.Lssa___map_delete_keyed_impl_4:
.Lssa___map_delete_keyed_impl_99:
    movl $24, %r8d
.Lssa___map_delete_keyed_impl_101:
    movslq %r8d, %r8
    addq -72(%rbp), %r8
    movq %rax, %r9
    shlq $2, %r9
    movslq %r9d, %r9
    addq %r9, %r8
    movslq (%r8), %r8
    cmpq %rbx, %r8
    je .Lssa___map_delete_keyed_impl_3
.Lssa___map_delete_keyed_impl_100:
    leaq 1(%rax), %r8
    movq %r8, %rax
    andq -104(%rbp), %rax
    jmp .Lssa___map_delete_keyed_impl_99
.Lssa___map_delete_keyed_impl_3:
    movq %rbx, %r8
    imulq -120(%rbp), %r8
    movslq %r8d, %r8
    addq -136(%rbp), %r8
    movq -112(%rbp), %r9
    movslq %r9d, %r9
    addq %r9, %r8
    movq 0(%r8), %rsi
    movq -176(%rbp), %r8
    imulq -120(%rbp), %r8
    movslq %r8d, %r8
    addq -136(%rbp), %r8
    movq %r14, 0(%r8)
    addq %r9, %r8
    movq %rsi, 0(%r8)
    movl $24, %r9d
.Lssa___map_delete_keyed_impl_109:
    movslq %r9d, %r9
    addq -72(%rbp), %r9
    shlq $2, %rax
    movslq %eax, %rax
    addq %rax, %r9
    movq -176(%rbp), %rcx
    movl %ecx, (%r9)
.Lssa___map_delete_keyed_impl_1:
    movq -72(%rbp), %r8
    addq $4, %r8
    movl %ebx, (%r8)
    movl $1, %eax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn_main:
    .cfi_startproc
__fn_main.r:
    pushq %rbp
    .cfi_def_cfa_offset 16
    .cfi_offset %rbp, -16
    movq %rsp, %rbp
    .cfi_def_cfa_register %rbp
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    subq $8, %rsp
.Lssa_main_0:
    movl $8, %eax
    xorl %esi, %esi
    xorl %edi, %edi
    call __fn_map_new_impl.r
.Lssa_main_4:
    movq %rax, %rbx
    xorl %r12d, %r12d
.Lssa_main_5:
    cmpq $190000, %r12
    jge .Lssa_main_3
.Lssa_main_6:
    movq %r12, %r13
    shlq $1, %r13
    movq %rbx, %rax
    call __fn___map_cow_inplace.r
    movq %rax, %r14
    cmpq %rbx, %r14
    je .Lssa_main_13
.Lssa_main_11:
    cmpq $0x10000, %rbx
    jb .Lssa_main_rcdeck68
    cmpl $1, -8(%rbx)
    jg .Lssa_main_rcdecd68
    cmpl $0, -8(%rbx)
    js .Lssa_main_rcdeck68
    movq %rbx, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa_main_rcdece68
.Lssa_main_rcdecd68:
    subl $1, -8(%rbx)
.Lssa_main_rcdeck68:
    movq %rbx, %rax
.Lssa_main_rcdece68:
.Lssa_main_13:
    movslq %r13d, %rsi
    movslq %r12d, %rdi
    movq %r14, %rax
    call __fn___map_put_impl.r
    addq $1, %r12
    movq %r14, %rbx
    cmpq $190000, %r12
    jl .Lssa_main_6
.Lssa_main_3:
.Lssa_main_2:
    xorl %r12d, %r12d
    movq $0, -48(%rbp)
.Lssa_main_16:
    cmpq $3, -48(%rbp)
    jl .Lssa_main_19
.Lssa_main_21:
    movq %rbx, %rax
    call __fn___map_drop_impl.r
    jmp .Lssa_main_1
.Lssa_main_19:
.Lssa_main_18:
    xorl %r13d, %r13d
.Lssa_main_24:
    cmpq $190000, %r13
    jge .Lssa_main_17
.Lssa_main_25:
    movq %r13, %rdi
    shlq $1, %rdi
    movslq %edi, %r15
    xorl %edi, %edi
    movq %rbx, %rax
    movq %r15, %rsi
    call __fn___map_get_or_impl.r
    movslq %eax, %rax
    leaq (%r12,%rax), %r14
    addq $1, %r15
    movslq %r15d, %rsi
    movabsq $-1, %rdi
    movq %rbx, %rax
    call __fn___map_get_or_impl.r
    movslq %eax, %rax
    leaq (%r14,%rax), %r12
    addq $1, %r13
    cmpq $190000, %r13
    jl .Lssa_main_25
.Lssa_main_17:
    movq -48(%rbp), %r11
    addq $1, %r11
    movq %r11, -48(%rbp)
    cmpq $3, -48(%rbp)
    jge .Lssa_main_21
    jmp .Lssa_main_19
.Lssa_main_1:
    movq %r12, %rax
    movq %rax, %rcx
    movabsq $-6275696437447579415, %rax
    imulq %rcx
    addq %rcx, %rdx
    sarq $6, %rdx
    movq %rdx, %rax
    shrq $63, %rdx
    addq %rdx, %rax
    imulq $97, %rax, %rax
    subq %rax, %rcx
    movq %rcx, %rax
    movq %rax, %rdi
    movslq %edi, %rax
    .cfi_remember_state
    leaq -40(%rbp), %rsp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    popq %rbp
    .cfi_def_cfa %rsp, 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___map_hash_scalar$wrap:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_hash_scalar$wrap.r:
.Lssa___map_hash_scalar$wrap_0:
    xorq $61, %rsi
    movl %esi, %edi
    shrq $16, %rdi
    xorq %rdi, %rsi
    movq %rsi, %rdi
    shlq $3, %rdi
    addq %rdi, %rsi
    movl %esi, %edi
    shrq $4, %rdi
    xorq %rdi, %rsi
    imulq $668265261, %rsi, %rsi
    movslq %esi, %rsi
    movl %esi, %edi
    shrq $15, %rdi
    movslq %edi, %rdi
    movq %rsi, %rax
    xorq %rdi, %rax
    ret
    .cfi_endproc
__fn___map_eq_scalar$wrap:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_eq_scalar$wrap.r:
.Lssa___map_eq_scalar$wrap_0:
    movq %rsi, %rax
    cmpq %rdi, %rax
    sete %al
    movzbq %al, %rax
    ret
    .cfi_endproc
__fn___map_hash_wide$wrap:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_hash_wide$wrap.r:
.Lssa___map_hash_wide$wrap_0:
    movq %rsi, %rax
    jmp __fn___map_hash_wide.r
    .cfi_endproc
__fn___map_eq_wide$wrap:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_eq_wide$wrap.r:
.Lssa___map_eq_wide$wrap_0:
    movq 0(%rsi), %r8
    movq 0(%rdi), %rsi
    movq %r8, %rax
    cmpq %rsi, %rax
    sete %al
    movzbq %al, %rax
.Lssa___map_eq_wide$wrap_1:
    ret
    .cfi_endproc
__fn___map_hash_str$wrap:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___map_hash_str$wrap.r:
.Lssa___map_hash_str$wrap_0:
    movq %rsi, %rax
    jmp __fn___map_hash_str.r
    .cfi_endproc
__fn___map_eq_str$wrap:
    .cfi_startproc
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
    movq 24(%rsp), %rdi
__fn___map_eq_str$wrap.r:
    pushq %rcx
    .cfi_def_cfa_offset 16
.Lssa___map_eq_str$wrap_0:
    movq 8(%rsi), %rdx
    cmpq 8(%rdi), %rdx
    jne .Lssa___map_eq_str$wrap_streqn9
    movq %rdi, %rax
    call __fn___fern_str_eq.r
    jmp .Lssa___map_eq_str$wrap_streqd9
.Lssa___map_eq_str$wrap_streqn9:
    xorl %eax, %eax
.Lssa___map_eq_str$wrap_streqd9:
    .cfi_remember_state
    leaq 8(%rsp), %rsp
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
_start:
    xorl %edi, %edi
    movq $1073741824, %rsi
    movl $3, %edx
    movl $0x24022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $-4096, %rax
    ja .Lfern_stack_kept
    movq %rax, %rbx
    movq %rax, %rdi
    movq $1048576, %rsi
    xorl %edx, %edx
    movl $10, %eax
    syscall
    leaq 1073741808(%rbx), %rsp
.Lfern_stack_kept:
    xorl %edi, %edi
    movq $65536, %rsi
    movl $3, %edx
    movl $0x24022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $-4096, %rax
    ja .Lfern_segv_skip
    subq $32, %rsp
    movq %rax, (%rsp)
    movq $0, 8(%rsp)
    movq $65536, 16(%rsp)
    movq %rsp, %rdi
    xorl %esi, %esi
    movl $131, %eax
    syscall
    leaq __fern_segv(%rip), %rax
    movq %rax, (%rsp)
    movq $0x0c000004, 8(%rsp)
    leaq .Lfern_segv_restorer(%rip), %rax
    movq %rax, 16(%rsp)
    movq $0, 24(%rsp)
    movl $11, %edi
    movq %rsp, %rsi
    xorl %edx, %edx
    movl $8, %r10d
    movl $13, %eax
    syscall
    addq $32, %rsp
.Lfern_segv_skip:
    pushq %rbp
    movq %rsp, %rbp
    call __fn_main
    movq %rax, %rdi
    movq $231, %rax
    syscall
    .section .data
    .align 8
    .quad 2
    .quad -1
.K0:
    .quad 1
    .quad __fn___map_hash_scalar$wrap.r
    .quad 2
    .quad -1
.K1:
    .quad 1
    .quad __fn___map_eq_scalar$wrap.r
    .quad 2
    .quad -1
.K2:
    .quad 1
    .quad __fn___map_hash_wide$wrap.r
    .quad 2
    .quad -1
.K3:
    .quad 1
    .quad __fn___map_eq_wide$wrap.r
    .quad 2
    .quad -1
.K4:
    .quad 1
    .quad __fn___map_hash_str$wrap.r
    .quad 2
    .quad -1
.K5:
    .quad 1
    .quad __fn___map_eq_str$wrap.r
    .quad 2
    .quad -1
.K6:
    .quad 1
    .quad 0
    .quad 0
    .quad -1
.K7:
    .quad 0
    .section .bss
    .align 8
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 8
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 8
__fern_heap_base: .quad 0
    .align 8
__fern_rc_underflow: .quad 0
    .align 8
__fern_map_seed: .quad 0
    .align 8
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 8
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 8
__fern_freelist_shadow: .skip 524288
    .align 8
__fern_large_freelist_shadow: .skip 20480
    .section .text
__fern_alloc:
    addq $7, %rdi
    andq $-8, %rdi
    cmpq $2048, %rdi
    ja .Lalloc_full
    leaq __fern_freelist(%rip), %rax
    addq %rax, %rdi
    movq (%rdi), %rax
    testq %rax, %rax
    jz .Lalloc_fast_miss
    pushq (%rax)
    popq (%rdi)
    ret
.Lalloc_fast_miss:
    leaq __fern_freelist(%rip), %rax
    subq %rax, %rdi
    movq __fern_heap_ptr(%rip), %rax
    testq %rax, %rax
    jz .Lalloc_full
    addq %rax, %rdi
    cmpq __fern_heap_end(%rip), %rdi
    ja .Lalloc_oom
    movq %rdi, __fern_heap_ptr(%rip)
    ret
.Lalloc_full:
    pushq %rbp
    movq %rsp, %rbp
    pushq %rcx
    pushq %rdx
    movq %rdi, %rcx
    shrq $3, %rcx
    cmpq $65536, %rcx
    jae .Lalloc_large
    cmpq $256, %rcx
    jbe .L0
    pushq %rcx
    call __fern_capw
    popq %rcx
.L0:
    leaq 0(,%rcx,8), %rdi
    leaq __fern_freelist(%rip), %rdx
    movq (%rdx,%rcx,8), %rax
    testq %rax, %rax
    jz .Lalloc_nofl
    movq (%rax), %rdi
    movq %rdi, (%rdx,%rcx,8)
    popq %rdx
    popq %rcx
    popq %rbp
    ret
.Lalloc_large:
    cmpq $0x40000000, %rdi
    ja .Lalloc_nofl
    movq %rdi, %rax
    cmpq $524288, %rax
    jae .L1
    movl $524288, %eax
.L1:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    movq %rax, %rdi
    movq %rdx, %rax
    leaq __fern_large_freelist(%rip), %rdx
    movq (%rdx,%rax,8), %rcx
    testq %rcx, %rcx
    jz .Lalloc_nofl
    movq (%rcx), %rdi
    movq %rdi, (%rdx,%rax,8)
    movq %rcx, %rax
    popq %rdx
    popq %rcx
    popq %rbp
    ret
.Lalloc_nofl:
    popq %rdx
    popq %rcx
    movq __fern_heap_ptr(%rip), %rax
    testq %rax, %rax
    jne .Lalloc_inited
    pushq %rdi
    pushq %rsi
    pushq %rcx
    pushq %rdx
    pushq %r8
    pushq %r9
    pushq %r10
    pushq %r11
    movl $0x10000000, %edi
    movabs $17179869184, %rsi
    movl $3, %edx
    movl $0x4022, %r10d
    movq $-1, %r8
    xorl %r9d, %r9d
    movl $9, %eax
    syscall
    cmpq $0, %rax
    jl .Lalloc_map_fail
    movq %rax, __fern_heap_ptr(%rip)
    movq %rax, __fern_heap_base(%rip)
    movabs $17179869184, %rcx
    addq %rax, %rcx
    movq %rcx, __fern_heap_end(%rip)
    popq %r11
    popq %r10
    popq %r9
    popq %r8
    popq %rdx
    popq %rcx
    popq %rsi
    popq %rdi
.Lalloc_inited:
    movq __fern_heap_ptr(%rip), %rax
    addq %rax, %rdi
    cmpq __fern_heap_end(%rip), %rdi
    ja .Lalloc_oom
    movq %rdi, __fern_heap_ptr(%rip)
    popq %rbp
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .section .text
.Lalloc_oom:
    leaq .Lmsg_oom(%rip), %rsi
    movq $43, %rdx
    movq $125, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .section .text
.Lalloc_map_fail:
    negq %rax
    subq $96, %rsp
    leaq 96(%rsp), %rdi
    movl $10, %edx
    decq %rdi
    movb %dl, (%rdi)
    movl $41, %edx
    decq %rdi
    movb %dl, (%rdi)
    movl $10, %ecx
.Lmap_fail_digit:
    xorl %edx, %edx
    divq %rcx
    addl $48, %edx
    decq %rdi
    movb %dl, (%rdi)
    testq %rax, %rax
    jne .Lmap_fail_digit
    leaq .Lmsg_map_fail(%rip), %rsi
    addq $42, %rsi
    movl $42, %ecx
.Lmap_fail_copy:
    decq %rsi
    movb (%rsi), %dl
    decq %rdi
    movb %dl, (%rdi)
    decq %rcx
    jne .Lmap_fail_copy
    movq %rdi, %rsi
    leaq 96(%rsp), %rdx
    subq %rsi, %rdx
    movq $123, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .section .text
__fern_oob_abort:
    leaq .Lmsg_arr_oob(%rip), %rsi
    movq $31, %rdx
    movq $134, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .section .text
__fern_str_oob_abort:
    leaq .Lmsg_str_oob(%rip), %rsi
    movq $32, %rdx
    movq $134, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .section .text
__fern_slice_abort:
    leaq .Lmsg_slice(%rip), %rsi
    movq $32, %rdx
    movq $134, %rdi
    jmp __fern_report
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .section .text
__fern_alloc_size_abort:
    leaq .Lmsg_alloc_size(%rip), %rsi
    movq $35, %rdx
    movq $134, %rdi
    jmp __fern_report
__fern_str_oob_abort.l0:
    pushq 0(%rsp)
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_str_oob_abort
__fern_alloc_size_abort.c:
    pushq %rbp
    movq %rsp, %rbp
    jmp __fern_alloc_size_abort
__fern_arr_box:
    pushq %rdi
    leaq 24(,%rdi,8), %rdi
    cmpq $2048, %rdi
    ja .Larrbox_alloc
    leaq __fern_freelist(%rip), %rax
    addq %rax, %rdi
    movq (%rdi), %rax
    testq %rax, %rax
    jz .Larrbox_miss
    pushq (%rax)
    popq (%rdi)
.Larrbox_hdr:
    popq %rdi
    movq %rdi, (%rax)
    movq $1, 8(%rax)
    movq %rdi, 16(%rax)
    addq $16, %rax
    ret
.Larrbox_miss:
    leaq __fern_freelist(%rip), %rax
    subq %rax, %rdi
.Larrbox_alloc:
    call __fern_alloc
    jmp .Larrbox_hdr
__fern_str_box:
    pushq %rsi
    pushq %rdi
    movq $24, %rdi
    call __fern_alloc
    movq $1, (%rax)
    popq %rdi
    popq %rsi
    movq %rdi, 8(%rax)
    movq %rsi, 16(%rax)
    addq $8, %rax
    ret
__fern_str_box_hdr:
    leaq -24(%rdi), %rax
    movl $1, (%rax)
    movl $1934589965, 4(%rax)
    movq %rdi, 8(%rax)
    movq %rsi, 16(%rax)
    addq $8, %rax
    ret
__fn___fern_rc_inc:
    movq 8(%rsp), %rax
    testb $1, %al
    jnz .Lshrcinc_ret
    cmpq $0x10000, %rax
    jb .Lshrcinc_ret
    andq $-3, %rax
    movl -8(%rax), %ecx
    testl %ecx, %ecx
    js .Lshrcinc_ret
    addl $1, %ecx
    movl %ecx, -8(%rax)
.Lshrcinc_ret:
    movq 8(%rsp), %rax
    ret
__fn___fern_rc_underflow_count:
    movl __fern_rc_underflow(%rip), %eax
    ret
__fern_large_push:
    cmpq $0x40000000, %rsi
    ja .Llpush_ret
    movq %rsi, %rax
    cmpq $524288, %rax
    jae .L2
    movl $524288, %eax
.L2:
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    bsrq %rax, %rcx
    subl $2, %ecx
    movq %rax, %rdx
    shrq %cl, %rdx
    shlq $2, %rcx
    addq %rcx, %rdx
    subq $72, %rdx
    movq %rdx, %rax
    leaq __fern_large_freelist(%rip), %rdx
    movq (%rdx,%rax,8), %rcx
    movq %rcx, (%r8)
    movq %r8, (%rdx,%rax,8)
.Llpush_ret:
    ret
__fern_capw:
    pushq %rax
    pushq %rcx
    pushq %rdx
    movq 32(%rsp), %rax
    cmpq $256, %rax
    jbe .Lcapw_ret
    bsrq %rax, %rcx
    subl $2, %ecx
    movl $1, %edx
    shlq %cl, %rdx
    leaq -1(%rax,%rdx), %rax
    negq %rdx
    andq %rdx, %rax
    cmpq $65536, %rax
    jb .Lcapw_store
    movl $65535, %eax
.Lcapw_store:
    movq %rax, 32(%rsp)
.Lcapw_ret:
    popq %rdx
    popq %rcx
    popq %rax
    ret
__fern_raw_free:
    testq %rdi, %rdi
    jz .Lrawfree_ret
    addq $7, %rsi
    andq $-8, %rsi
    cmpq $8, %rsi
    jb .Lrawfree_ret
    movq %rsi, %rcx
    shrq $3, %rcx
    cmpq $65536, %rcx
    jae .Lrawfree_large
    cmpq $256, %rcx
    jbe .L3
    pushq %rcx
    call __fern_capw
    popq %rcx
.L3:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rdx
    movq %rdx, (%rdi)
    movq %rdi, (%r8,%rcx,8)
.Lrawfree_ret:
    ret
.Lrawfree_large:
    movq %rdi, %r8
    call __fern_large_push
    ret
__fn___fern_arr_dec:
    movq 8(%rsp), %rax
__fn___fern_arr_dec.r:
    cmpq $0x10000, %rax
    jb .Larrdec_ret
__fn___fern_arr_dec.u:
    movl -8(%rax), %ecx
    cmpl $1, %ecx
    jne .Larrdec_shared
    movl $0, -8(%rax)
    movl -16(%rax), %ecx
    addq $3, %rcx
    leaq -16(%rax), %rdx
    cmpq $256, %rcx
    ja .Larrdec_big
.Larrdec_push:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rdi
    movq %rdi, (%rdx)
    movq %rdx, (%r8,%rcx,8)
.Larrdec_ret:
    ret
.Larrdec_shared:
    testl %ecx, %ecx
    js .Larrdec_ret
    jg .Larrdec_dec
    incl __fern_rc_underflow(%rip)
    jmp .Larrdec_ret
.Larrdec_dec:
    subl $1, %ecx
    movl %ecx, -8(%rax)
    ret
.Larrdec_big:
    cmpq $65536, %rcx
    jae .Larrdec_large
    pushq %rcx
    call __fern_capw
    popq %rcx
    jmp .Larrdec_push
.Larrdec_large:
    leaq -16(%rax), %r8
    leaq 0(,%rcx,8), %rsi
    call __fern_large_push
    ret
__fn___fern_str_free:
    movq 8(%rsp), %rax
__fn___fern_str_free.r:
    testb $1, %al
    jnz .Lstrfree_ret
    cmpq $0x10000, %rax
    jb .Lstrfree_ret
__fn___fern_str_free.u:
    movl -8(%rax), %ecx
    cmpl $1, %ecx
    jne .Lstrfree_shared
    movl -4(%rax), %edx
    cmpl $1934589965, %edx
    je .Lstrfree_fused
    cmpl $1196576599, %edx
    je .Lstrfree_grown
    cmpl $1112494674, %edx
    je .Lstrfree_box
    movq (%rax), %rcx
    movq 8(%rax), %rdx
    movq __fern_heap_base(%rip), %rsi
    cmpq %rsi, %rcx
    jb .Lstrfree_box
    cmpq __fern_heap_end(%rip), %rcx
    jae .Lstrfree_box
    testq %rdx, %rdx
    jle .Lstrfree_box
    addq $7, %rdx
    shrq $3, %rdx
    cmpq $65536, %rdx
    jae .Lstrfree_large
    cmpq $256, %rdx
    jbe .L4
    pushq %rdx
    call __fern_capw
    popq %rdx
.L4:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rdx,8), %rsi
    movq %rsi, (%rcx)
    movq %rcx, (%r8,%rdx,8)
.Lstrfree_box:
    movl $0, -8(%rax)
    leaq -8(%rax), %rdx
    leaq __fern_freelist(%rip), %r8
    movq 24(%r8), %rsi
    movq %rsi, (%rdx)
    movq %rdx, 24(%r8)
    jmp .Lstrfree_ret
.Lstrfree_large:
    movq %rcx, %r8
    leaq 0(,%rdx,8), %rsi
    pushq %rax
    call __fern_large_push
    popq %rax
    jmp .Lstrfree_box
.Lstrfree_grown:
    movq -16(%rax), %rdx
    leaq -16(%rax), %rcx
    jmp .Lstrfree_block
.Lstrfree_fused:
    movq 8(%rax), %rdx
    addq $7, %rdx
    shrq $3, %rdx
    addq $3, %rdx
    leaq -8(%rax), %rcx
.Lstrfree_block:
    movl $0, -8(%rax)
    cmpq $256, %rdx
    ja .Lstrfree_fused_big
.Lstrfree_fused_push:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rdx,8), %rsi
    movq %rsi, (%rcx)
    movq %rcx, (%r8,%rdx,8)
    jmp .Lstrfree_ret
.Lstrfree_fused_big:
    cmpq $65536, %rdx
    jae .Lstrfree_fused_large
    pushq %rdx
    call __fern_capw
    popq %rdx
    jmp .Lstrfree_fused_push
.Lstrfree_fused_large:
    movq %rcx, %r8
    leaq 0(,%rdx,8), %rsi
    call __fern_large_push
    jmp .Lstrfree_ret
.Lstrfree_shared:
    testl %ecx, %ecx
    js .Lstrfree_ret
    je .Lstrfree_uf
    subl $1, %ecx
    movl %ecx, -8(%rax)
    ret
.Lstrfree_uf:
    incl __fern_rc_underflow(%rip)
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    movq 8(%rsp), %rax
    testb $1, %al
    jnz .Lstrvfree_ret
    cmpq $0x10000, %rax
    jb .Lstrvfree_ret
    movl -8(%rax), %ecx
    testl %ecx, %ecx
    js .Lstrvfree_view
    jmp __fn___fern_str_free
.Lstrvfree_view:
    leaq -8(%rax), %rdx
    movq __fern_heap_base(%rip), %rsi
    cmpq %rsi, %rdx
    jb .Lstrvfree_ret
    cmpq __fern_heap_end(%rip), %rdx
    jae .Lstrvfree_ret
    movl $0, -8(%rax)
    leaq __fern_freelist(%rip), %r8
    movq 24(%r8), %rsi
    movq %rsi, (%rdx)
    movq %rdx, 24(%r8)
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    movq 8(%rsp), %rax
__fn___fern_str_arr_free.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    movq %rax, %rbx
.Lssa___fern_str_arr_free_0:
    cmpq $65536, %rbx
    jb .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    leaq -8(%rbx), %rsi
    movslq (%rsi), %rsi
    cmpq $1, %rsi
    jne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    movslq (%rbx), %r12
.Lssa___fern_str_arr_free_4:
    xorl %esi, %esi
.Lssa___fern_str_arr_free_15:
    cmpq %r12, %rsi
    jge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    leaq 1(%rsi), %r13
    movq (%rbx,%r13,8), %rsi
    testb $1, %sil
    jnz .Lssa___fern_str_arr_free_rcdeck36
    cmpq $0x10000, %rsi
    jb .Lssa___fern_str_arr_free_rcdeck36
    cmpl $1, -8(%rsi)
    jg .Lssa___fern_str_arr_free_rcdecd36
    cmpl $0, -8(%rsi)
    js .Lssa___fern_str_arr_free_rcdeck36
    movq %rsi, %rax
    call __fn___fern_str_free.u
    jmp .Lssa___fern_str_arr_free_rcdece36
.Lssa___fern_str_arr_free_rcdecd36:
    subl $1, -8(%rsi)
.Lssa___fern_str_arr_free_rcdeck36:
    movq %rsi, %rax
.Lssa___fern_str_arr_free_rcdece36:
    movq %r13, %rsi
    cmpq %r12, %rsi
    jl .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    cmpq $0x10000, %rbx
    jb .Lssa___fern_str_arr_free_rcdeck40
    cmpl $1, -8(%rbx)
    jg .Lssa___fern_str_arr_free_rcdecd40
    cmpl $0, -8(%rbx)
    js .Lssa___fern_str_arr_free_rcdeck40
    movq %rbx, %rax
    call __fn___fern_arr_dec.u
    jmp .Lssa___fern_str_arr_free_rcdece40
.Lssa___fern_str_arr_free_rcdecd40:
    subl $1, -8(%rbx)
.Lssa___fern_str_arr_free_rcdeck40:
    movq %rbx, %rax
.Lssa___fern_str_arr_free_rcdece40:
    xorl %eax, %eax
    .cfi_remember_state
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fn___fern_rc_is_unique:
    movq 8(%rsp), %rcx
    movq $0, %rax
    testb $1, %cl
    jnz .Lshuniq_ret
    cmpq $0x10000, %rcx
    jb .Lshuniq_ret
    andq $-3, %rcx
    movl -8(%rcx), %edx
    testl %edx, %edx
    js .Lshuniq_ret
    cmpl $1, %edx
    jne .Lshuniq_ret
    movq $1, %rax
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    movq 8(%rsp), %rax
__fn___fern_arr_inc_elems.r:
    cmpq $0x10000, %rax
    jb .Laie_ret
    movl -8(%rax), %ecx
    testl %ecx, %ecx
    js .Laie_ret
    movq (%rax), %rsi
    xorl %edx, %edx
.Laie_loop:
    cmpq %rsi, %rdx
    jge .Laie_ret
    movq 8(%rax,%rdx,8), %rcx
    incq %rdx
    testb $1, %cl
    jnz .Laie_loop
    cmpq $0x10000, %rcx
    jb .Laie_loop
    andq $-3, %rcx
    movl -8(%rcx), %edi
    testl %edi, %edi
    js .Laie_loop
    addl $1, -8(%rcx)
    jmp .Laie_loop
.Laie_ret:
    ret
__fn___fern_alloc_reuse:
    movq 16(%rsp), %rax
    movq 8(%rsp), %rsi
__fn___fern_alloc_reuse.r:
    testq %rax, %rax
    jz .Lsarelo_fresh
    cmpq %rsi, -16(%rax)
    je .Lsarelo_ret
    pushq %rsi
    call __fn___fern_arr_dec.r
    popq %rsi
.Lsarelo_fresh:
    movq %rsi, %rdi
    jmp __fern_arr_box
.Lsarelo_ret:
    ret
__fern_arr_push:
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Larr_push_slow
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Larr_push_slow_ok
    testl %ecx, %ecx
    jns .Larr_push_slow
.Larr_push_slow_ok:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    ret
.Larr_push_slow:
    cmpq $0, (%rdi)
    jne .Larr_push_frame
    cmpq $0, -16(%rdi)
    jne .Larr_push_frame
    leaq __fern_freelist(%rip), %rcx
    movq 56(%rcx), %rax
    testq %rax, %rax
    jz .Larr_push_fresh
    movq (%rax), %rdx
    movq %rdx, 56(%rcx)
    movq $4, (%rax)
    movq $1, 8(%rax)
    movq $1, 16(%rax)
    movq %rsi, 24(%rax)
    addq $16, %rax
    ret
.Larr_push_fresh:
    pushq %rsi
    movl $4, %edi
    call __fern_arr_box
    popq %rsi
    movq $1, (%rax)
    movq %rsi, 8(%rax)
    ret
.Larr_push_frame:
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    movq %rdi, %r12
    movq %rsi, %r13
    movq (%r12), %r14
    movq -16(%r12), %r15
    jmp .Larr_push_grow
    movl -8(%r12), %ecx
    cmpl $1, %ecx
    je .Larr_push_rc_ok
    testl %ecx, %ecx
    js .Larr_push_rc_ok
    jmp .Larr_push_grow
.Larr_push_rc_ok:
    cmpq %r15, %r14
    jge .Larr_push_grow
    movq %r14, %rcx
    incq %rcx
    movq %r13, (%r12,%rcx,8)
    incq %r14
    movq %r14, (%r12)
    movq %r12, %rax
    jmp .Larr_push_ret
.Larr_push_grow:
    movq %r15, %rcx
    cmpq %r15, %r14
    jl .Larr_push_shared_cliff
    cmpq $0, %rcx
    jne .Larr_push_dbl
    movq $4, %rcx
    jmp .Larr_push_cap
.Larr_push_shared_cliff:
    incq __fern_arr_push_shared(%rip)
    movq %r14, %rax
    shlq $3, %rax
    addq %rax, __fern_arr_push_copied(%rip)
    jmp .Larr_push_cap
.Larr_push_dbl:
    shlq $1, %rcx
.Larr_push_cap:
    movq %rcx, %r15
    movq %r15, %rdi
    call __fern_arr_box
    movq %r14, %rcx
    incq %rcx
    movq %rcx, (%rax)
    leaq 8(%r12), %rsi
    leaq 8(%rax), %rdi
    movq %r14, %rcx
    subq $8, %rcx
    jl .Larr_push_copy_lt8
.Larr_push_copy8:
    vmovdqu (%rsi), %ymm0
    vmovdqu 32(%rsi), %ymm1
    vmovdqu %ymm0, (%rdi)
    vmovdqu %ymm1, 32(%rdi)
    addq $64, %rsi
    addq $64, %rdi
    subq $8, %rcx
    jge .Larr_push_copy8
    vzeroupper
.Larr_push_copy_lt8:
    addq $8, %rcx
    cmpq $4, %rcx
    jl .Larr_push_copy1
    movdqu (%rsi), %xmm0
    movdqu 16(%rsi), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, 16(%rdi)
    addq $32, %rsi
    addq $32, %rdi
    subq $4, %rcx
.Larr_push_copy1:
    testq %rcx, %rcx
    jz .Larr_push_copy_done
.Larr_push_copy1_loop:
    movq (%rsi), %rdx
    movq %rdx, (%rdi)
    addq $8, %rsi
    addq $8, %rdi
    decq %rcx
    jnz .Larr_push_copy1_loop
.Larr_push_copy_done:
    movq %r14, %rcx
    incq %rcx
    movq %r13, (%rax,%rcx,8)
.Larr_push_ret:
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    leave
    ret
__fern_arr_push_owned:
    movq (%rdi), %rdx
    cmpq -16(%rdi), %rdx
    jge .Lapo_slow
    movl -8(%rdi), %ecx
    cmpl $1, %ecx
    je .Lapo_slow_ok
    testl %ecx, %ecx
    jns .Lapo_slow
.Lapo_slow_ok:
    movq %rsi, 8(%rdi,%rdx,8)
    incq %rdx
    movq %rdx, (%rdi)
    movq %rdi, %rax
    ret
.Lapo_slow:
    movl -8(%rdi), %ecx
    testl %ecx, %ecx
    js .Larr_push_slow
    cmpl $1, %ecx
    jne .Larr_push_slow
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    movq %rdi, %r12
    movq %rsi, %r13
    movq (%r12), %r14
    movq -16(%r12), %r15
    leaq (%r15,%r15), %rcx
    testq %rcx, %rcx
    jnz .Lapo_cap
    movq $4, %rcx
.Lapo_cap:
    leaq 24(,%rcx,8), %rdi
    cmpq $2048, %rdi
    ja .Lapo_alloc
    leaq __fern_freelist(%rip), %rax
    addq %rax, %rdi
    movq (%rdi), %rax
    testq %rax, %rax
    jz .Lapo_miss
    movq (%rax), %rdx
    movq %rdx, (%rdi)
.Lapo_box:
    movq %rcx, (%rax)
    movq $1, 8(%rax)
    addq $16, %rax
    leaq 1(%r14), %rcx
    movq %rcx, (%rax)
    leaq 8(%r12), %rsi
    leaq 8(%rax), %rdi
    movq %r14, %rcx
    subq $8, %rcx
    jl .Lapo_copy_lt8
.Lapo_copy8:
    vmovdqu (%rsi), %ymm0
    vmovdqu 32(%rsi), %ymm1
    vmovdqu %ymm0, (%rdi)
    vmovdqu %ymm1, 32(%rdi)
    addq $64, %rsi
    addq $64, %rdi
    subq $8, %rcx
    jge .Lapo_copy8
    vzeroupper
.Lapo_copy_lt8:
    addq $8, %rcx
    cmpq $4, %rcx
    jl .Lapo_copy1
    movdqu (%rsi), %xmm0
    movdqu 16(%rsi), %xmm1
    movdqu %xmm0, (%rdi)
    movdqu %xmm1, 16(%rdi)
    addq $32, %rsi
    addq $32, %rdi
    subq $4, %rcx
.Lapo_copy1:
    testq %rcx, %rcx
    jz .Lapo_copy_done
.Lapo_copy1_loop:
    movq (%rsi), %rdx
    movq %rdx, (%rdi)
    addq $8, %rsi
    addq $8, %rdi
    decq %rcx
    jnz .Lapo_copy1_loop
.Lapo_copy_done:
    movq %r13, 8(%rax,%r14,8)
    leaq 3(%r15), %rcx
    cmpq $65536, %rcx
    jae .Lapo_large
    movl $0, -8(%r12)
    leaq -16(%r12), %rdx
    cmpq $256, %rcx
    jbe .L5
    pushq %rcx
    call __fern_capw
    popq %rcx
.L5:
    leaq __fern_freelist(%rip), %r8
    movq (%r8,%rcx,8), %rdi
    movq %rdi, (%rdx)
    movq %rdx, (%r8,%rcx,8)
.Lapo_ret:
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    leave
    ret
.Lapo_miss:
    leaq __fern_freelist(%rip), %rax
    subq %rax, %rdi
.Lapo_alloc:
    call __fern_alloc
    jmp .Lapo_box
.Lapo_large:
    movl $0, -8(%r12)
    leaq -16(%r12), %r8
    leaq 0(,%rcx,8), %rsi
    pushq %rax
    call __fern_large_push
    popq %rax
    jmp .Lapo_ret
    .section .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .section .text
__fern_alloc_bytes:
    testl %edi, %edi
    js __fern_alloc_size_abort.c
    jz .Lfern_alloc_bytes_empty
    pushq %rbp
    movq %rsp, %rbp
    pushq %r12
    pushq %r13
    movq %rdi, %r12
    leaq 7(%rdi), %rdi
    shrq $3, %rdi
    movq %rdi, %r13
    call __fern_arr_box
    movq %r12, (%rax)
    movq %rax, %rdx
    leaq 8(%rax), %rdi
    movq %r13, %rcx
    xorl %eax, %eax
    rep stosq
    movq %rdx, %rax
    popq %r13
    popq %r12
    popq %rbp
    ret
.Lfern_alloc_bytes_empty:
    leaq .Lfern_empty_bytes(%rip), %rax
    ret
    .text
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
    .text
__fern_segv:
    movq 16(%rsi), %rax
    subq 160(%rdx), %rax
    addq $1048576, %rax
    cmpq $2097152, %rax
    jae .Lfern_segv_other
    movq 168(%rdx), %rax
    movq 120(%rdx), %rcx
    subq $16, %rsp
    movq %rcx, (%rsp)
    movq %rax, 8(%rsp)
    movq %rsp, %rbp
    leaq .Lmsg_stack_overflow(%rip), %rsi
    movq $21, %rdx
    movq $134, %rdi
    jmp __fern_report
.Lfern_segv_other:
    subq $32, %rsp
    movq $0, (%rsp)
    movq $0x04000000, 8(%rsp)
    leaq .Lfern_segv_restorer(%rip), %rax
    movq %rax, 16(%rsp)
    movq $0, 24(%rsp)
    movl $11, %edi
    movq %rsp, %rsi
    xorl %edx, %edx
    movl $8, %r10d
    movl $13, %eax
    syscall
    addq $32, %rsp
    ret
.Lfern_segv_restorer:
    movl $15, %eax
    syscall
__fern_report:
    movq %rdi, %r15
    movq $2, %rdi
    movq $1, %rax
    syscall
    jmp __fern_bt_exit
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .section .text
    .globl __fern_bt_exit
__fern_bt_exit:
    andq $-16, %rsp
    movq %rsp, %r13
    leaq .Lmsg_bt(%rip), %rsi
    movq $11, %rdx
    movq $2, %rdi
    movq $1, %rax
    syscall
    movq %rbp, %rbx
    movl $64, %r14d
.Lbt_loop:
    testl %r14d, %r14d
    jz .Lbt_done
    cmpq %r13, %rbx
    jb .Lbt_done
    testq $7, %rbx
    jnz .Lbt_done
    movq 8(%rbx), %rsi
    cmpq $0x10000, %rsi
    jb .Lbt_done
    call .Lbt_hex
    movq %rbx, %r13
    movq (%rbx), %rbx
    decl %r14d
    jmp .Lbt_loop
.Lbt_done:
    movq %r15, %rdi
    movq $231, %rax
    syscall
.Lbt_hex:
    subq $32, %rsp
    movb $32, (%rsp)
    movb $32, 1(%rsp)
    movb $48, 2(%rsp)
    movb $120, 3(%rsp)
    movb $10, 20(%rsp)
    movl $16, %ecx
    leaq 19(%rsp), %rdi
.Lbt_hloop:
    movq %rsi, %rax
    andl $15, %eax
    cmpb $10, %al
    jb .Lbt_hdec
    addb $87, %al
    jmp .Lbt_hput
.Lbt_hdec:
    addb $48, %al
.Lbt_hput:
    movb %al, (%rdi)
    decq %rdi
    shrq $4, %rsi
    decl %ecx
    jnz .Lbt_hloop
    movq $1, %rax
    movq $2, %rdi
    movq %rsp, %rsi
    movq $21, %rdx
    syscall
    addq $32, %rsp
    ret
    .text
__fn___fern_str_eq:
    movq 8(%rsp), %rax
    movq 16(%rsp), %rsi
__fn___fern_str_eq.r:
    cmpq %rsi, %rax
    jz .Lseq_yes
    movq 8(%rax), %rdx
    cmpq 8(%rsi), %rdx
    jnz .Lseq_no
    movq (%rax), %rcx
    movq (%rsi), %rsi
    cmpq %rsi, %rcx
    jz .Lseq_yes
    cmpq $8, %rdx
    jb .Lseq_short
    leaq -8(%rcx,%rdx), %r8
    leaq -8(%rsi,%rdx), %r9
.Lseq_word:
    movq (%rcx), %rax
    cmpq (%rsi), %rax
    jnz .Lseq_no
    addq $8, %rcx
    addq $8, %rsi
    cmpq %r8, %rcx
    jb .Lseq_word
    movq (%r8), %rax
    cmpq (%r9), %rax
    jnz .Lseq_no
    jmp .Lseq_yes
.Lseq_short:
    testq %rdx, %rdx
    jz .Lseq_yes
    cmpq $4, %rdx
    jb .Lseq_byte
    movl (%rcx), %eax
    cmpl (%rsi), %eax
    jnz .Lseq_no
    movl -4(%rcx,%rdx), %eax
    cmpl -4(%rsi,%rdx), %eax
    jnz .Lseq_no
    jmp .Lseq_yes
.Lseq_byte:
    movzbl (%rcx), %eax
    cmpb (%rsi), %al
    jnz .Lseq_no
    movzbl -1(%rcx,%rdx), %eax
    cmpb -1(%rsi,%rdx), %al
    jnz .Lseq_no
    cmpq $3, %rdx
    jb .Lseq_yes
    movzbl 1(%rcx), %eax
    cmpb 1(%rsi), %al
    jnz .Lseq_no
.Lseq_yes:
    movl $1, %eax
    ret
.Lseq_no:
    xorl %eax, %eax
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .text
__fn___fern_random_i32:
    .cfi_startproc
__fn___fern_random_i32.r:
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
.Lssa___fern_random_i32_0:
    movl $4, %esi
    leaq __fern_scratch(%rip), %rbx
    movl $318, %esi
    movl $4, %edi
    xorl %r8d, %r8d
    pushq %rsi
    pushq %rbx
    pushq %rdi
    pushq %r8
    popq %rdx
    popq %rsi
    popq %rdi
    popq %rax
    syscall
    movslq (%rbx), %rax
    .cfi_remember_state
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
    .cfi_restore_state
    .cfi_endproc
__fern_map_hash_seed:
    movl __fern_map_seed(%rip), %eax
    testl %eax, %eax
    jne .Lmapseed_ret
    pushq %rbp
    movq %rsp, %rbp
    call __fn___fern_random_i32
    orl $1, %eax
    movl %eax, __fern_map_seed(%rip)
    leave
.Lmapseed_ret:
    ret
    .section .bss
    .align 8
__fern_scratch: .skip 256
    .text
