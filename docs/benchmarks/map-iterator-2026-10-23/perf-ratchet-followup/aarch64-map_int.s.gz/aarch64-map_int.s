    .globl _start
    .text
__fn___map_pow2_ceil:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_pow2_ceil.k:
__fn___map_pow2_ceil.r:
.Lssa___map_pow2_ceil_0:
    cmp x0, #4
    b.gt .Lssa___map_pow2_ceil_4
.Lssa___map_pow2_ceil_6:
    mov x0, #4
    ret
.Lssa___map_pow2_ceil_4:
.Lssa___map_pow2_ceil_3:
    mov x9, #4
.Lssa___map_pow2_ceil_11:
    cmp x9, x0
    b.ge .Lssa___map_pow2_ceil_2
.Lssa___map_pow2_ceil_14:
    movz x10, #16384, lsl #16
    cmp x9, x10
    b.ge .Lssa___map_pow2_ceil_1
.Lssa___map_pow2_ceil_12:
    lsl x10, x9, #1
    sxtw x9, w10
    cmp x9, x0
    b.lt .Lssa___map_pow2_ceil_14
.Lssa___map_pow2_ceil_2:
    mov x0, x9
    ret
.Lssa___map_pow2_ceil_1:
    mov x0, x9
    ret
    .cfi_endproc
    .ltorg
__fn___map_hdr_bytes:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_hdr_bytes.k:
__fn___map_hdr_bytes.r:
.Lssa___map_hdr_bytes_0:
    mov x0, #24
    ret
    .cfi_endproc
    .ltorg
__fn___map_hdr:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_hdr.k:
__fn___map_hdr.r:
.Lssa___map_hdr_0:
    mov x0, #24
    ret
    .cfi_endproc
    .ltorg
__fn___map_buf_bytes:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_buf_bytes.k:
__fn___map_buf_bytes.r:
.Lssa___map_buf_bytes_0:
    mov x10, #8
    mov x11, #2
    mul x11, x11, x10
    add x11, x11, #4
    mul x11, x0, x11
    add x9, x9, x11
    add x9, x9, x0
    add x9, x9, #8
    sxtw x0, w9
    ret
    .cfi_endproc
    .ltorg
__fn___map_ctrl_base:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_ctrl_base.k:
__fn___map_ctrl_base.r:
.Lssa___map_ctrl_base_0:
    mov x10, #24
.Lssa___map_ctrl_base_1:
    sxtw x10, w10
    add x0, x0, x10
    mov x10, #8
    mov x11, #2
    mul x11, x11, x10
    add x11, x11, #4
    mul x9, x9, x11
    sxtw x9, w9
    add x0, x0, x9
    ret
    .cfi_endproc
    .ltorg
__fn___map_h2:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_h2.k:
__fn___map_h2.r:
.Lssa___map_h2_0:
    mov w0, w0
    lsr x0, x0, #25
    sxtw x0, w0
    ret
    .cfi_endproc
    .ltorg
__fn___map_swar_lo:
    .cfi_startproc
__fn___map_swar_lo.k:
__fn___map_swar_lo.r:
.Lssa___map_swar_lo_0:
    ldr x0, =72340172838076673
    ret
    .cfi_endproc
    .ltorg
__fn___map_swar_hi:
    .cfi_startproc
__fn___map_swar_hi.k:
__fn___map_swar_hi.r:
.Lssa___map_swar_hi_0:
    ldr x0, =9259542123273814144
    ret
    .cfi_endproc
    .ltorg
__fn___map_swar_all:
    .cfi_startproc
__fn___map_swar_all.k:
__fn___map_swar_all.r:
.Lssa___map_swar_all_0:
    ldr x0, =18446744073709551615
    ret
    .cfi_endproc
    .ltorg
__fn___map_ctrl_set:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_ctrl_set.k:
__fn___map_ctrl_set.r:
.Lssa___map_ctrl_set_0:
.Lssa___map_ctrl_set_2:
.Lssa___map_ctrl_set_3:
    add x12, x9, #8
    sxtw x12, w12
    cmp x10, x12
    b.ge .Lssa___map_ctrl_set_1
.Lssa___map_ctrl_set_4:
    mov x12, #-4
    and x12, x10, x12
    mov x13, #3
    and x13, x10, x13
    lsl x13, x13, #3
    sxtw x12, w12
    add x12, x0, x12
    ldrsw x14, [x12]
    mov x15, #255
    mov x4, x15
    mov x5, x13
    and x5, x5, #31
    lsl x4, x4, x5
    mov x15, x4
    sxtw x15, w15
    bic x14, x14, x15
    mov x4, x11
    mov x5, x13
    and x5, x5, #31
    lsl x4, x4, x5
    mov x13, x4
    sxtw x13, w13
    orr x14, x14, x13
    str w14, [x12]
    add x10, x10, x9
    sxtw x10, w10
    b .Lssa___map_ctrl_set_3
.Lssa___map_ctrl_set_1:
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn___map_seed:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_seed.k:
__fn___map_seed.r:
.Lssa___map_seed_0:
    add x0, x0, #16
    ldrsw x0, [x0]
    ret
    .cfi_endproc
    .ltorg
__fn___map_wang_mix:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_wang_mix.k:
__fn___map_wang_mix.r:
.Lssa___map_wang_mix_0:
    mov x9, #61
    eor x0, x0, x9
    mov w9, w0
    lsr x9, x9, #16
    eor x0, x0, x9
    lsl x9, x0, #3
    add x0, x0, x9
    mov w9, w0
    lsr x9, x9, #4
    eor x0, x0, x9
    ldr x9, =668265261
    mul x0, x0, x9
    sxtw x0, w0
    mov w9, w0
    lsr x9, x9, #15
    sxtw x9, w9
    eor x0, x0, x9
    ret
    .cfi_endproc
    .ltorg
__fn___map_fnv_str_seeded:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_fnv_str_seeded.k:
__fn___map_fnv_str_seeded.r:
.Lssa___map_fnv_str_seeded_0:
    ldr x10, =2166136261
    mov w9, w9
    eor x10, x10, x9
    ldr x9, =16777619
    ldr x11, [x0, #8]
.Lssa___map_fnv_str_seeded_4:
    mov x12, #0
.Lssa___map_fnv_str_seeded_5:
    add x13, x12, #4
    sxtw x13, w13
    cmp x13, x11
    b.gt .Lssa___map_fnv_str_seeded_2
.Lssa___map_fnv_str_seeded_6:
    add x13, x12, #3
    sxtw x13, w13
    asr x14, x12, #31
    orr x13, x13, x14
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x14, [x0, #0]
    sxtw x13, w12
    add x14, x14, x13
    ldrsw x14, [x14]
    eor x14, x10, x14
    ldr x13, =16777619
    mul x14, x14, x13
    mov w10, w14
    add x14, x12, #4
    sxtw x12, w14
    b .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmp x12, x11
    b.ge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
    eor x14, x10, x14
    mul x14, x14, x9
    mov w10, w14
    add x12, x12, #1
    cmp x12, x11
    b.lt .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    lsr x12, x10, #16
    eor x10, x10, x12
    ldr x12, =2246822507
    mul x10, x10, x12
    mov w10, w10
    lsr x12, x10, #13
    eor x10, x10, x12
    ldr x12, =3266489909
    mul x10, x10, x12
    mov w10, w10
    lsr x12, x10, #16
    eor x10, x10, x12
    sxtw x0, w10
    ret
    .cfi_endproc
    .ltorg
__fn_map_new_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_map_new_impl.k:
__fn_map_new_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x9
    mov x20, x10
.Lssa_map_new_impl_0:
    mov x9, #255
    and x21, x19, x9
.Lssa_map_new_impl_11:
    cmp x0, #4
    b.gt .Lssa_map_new_impl_8
.Lssa_map_new_impl_10:
    mov x22, #4
    b .Lssa_map_new_impl_4
.Lssa_map_new_impl_8:
.Lssa_map_new_impl_7:
    mov x9, #4
.Lssa_map_new_impl_17:
    cmp x9, x0
    b.ge .Lssa_map_new_impl_6
.Lssa_map_new_impl_20:
    movz x10, #16384, lsl #16
    cmp x9, x10
    b.ge .Lssa_map_new_impl_5
.Lssa_map_new_impl_18:
    lsl x10, x9, #1
    sxtw x9, w10
    cmp x9, x0
    b.lt .Lssa_map_new_impl_20
.Lssa_map_new_impl_6:
    mov x22, x9
    b .Lssa_map_new_impl_4
.Lssa_map_new_impl_5:
    mov x22, x9
.Lssa_map_new_impl_4:
    mov x23, #24
    mov x9, #8
    mov x10, #2
    mul x10, x10, x9
    add x10, x10, #4
    mul x10, x22, x10
    add x10, x10, #24
    add x10, x10, x22
    add x10, x10, #8
    sxtw x10, w10
    mov x9, x10
    mov x0, x9
    bl __fern_alloc
    mov x24, x0
    str w22, [x24]
    add x9, x24, #4
    mov x10, #0
    str w10, [x9]
    add x11, x24, #8
    str w21, [x11]
    add x10, x24, #12
    str w20, [x10]
    cmp x21, #1
    b.ne .Lssa_map_new_impl_2
.Lssa_map_new_impl_3:
    bl __fern_map_hash_seed
    b .Lssa_map_new_impl_1
.Lssa_map_new_impl_2:
    mov x0, #0
.Lssa_map_new_impl_1:
    add x11, x24, #16
    str w0, [x11]
    add x10, x24, #20
    asr x19, x19, #8
    str w19, [x10]
    sxtw x23, w23
    add x23, x24, x23
    lsl x11, x22, #2
    sxtw x11, w11
    mov x10, #255
    mov x2, x11
    mov x1, x10
    mov x0, x23
.Lssa_map_new_impl_ms149:
    cbz x2, .Lssa_map_new_impl_msd149
    strb w1, [x0], #1
    sub x2, x2, #1
    b .Lssa_map_new_impl_ms149
.Lssa_map_new_impl_msd149:
    mov x0, #0
    mov x10, #8
    mov x11, #2
    mul x11, x11, x10
    add x11, x11, #4
    mul x11, x22, x11
    sxtw x11, w11
    add x23, x23, x11
    mov x11, x23
    add x22, x22, #8
    sxtw x22, w22
    mov x10, #128
    mov x2, x22
    mov x1, x10
    mov x0, x11
.Lssa_map_new_impl_ms163:
    cbz x2, .Lssa_map_new_impl_msd163
    strb w1, [x0], #1
    sub x2, x2, #1
    b .Lssa_map_new_impl_ms163
.Lssa_map_new_impl_msd163:
    mov x0, #0
    mov x10, #16
    mov x0, x10
    bl __fern_alloc
    mov x10, #1
    str w10, [x0]
    add x0, x0, #8
    str x24, [x0, #0]
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_cow_inplace:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_cow_inplace.k:
__fn___map_cow_inplace.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
.Lssa___map_cow_inplace_0:
    sub x9, x0, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.gt .Lssa___map_cow_inplace_1
.Lssa___map_cow_inplace_3:
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_cow_inplace_1:
    ldr x19, [x0, #0]
    ldrsw x9, [x19]
.Lssa___map_cow_inplace_8:
    mov x10, #8
    mov x11, #2
    mul x11, x11, x10
    add x11, x11, #4
    mul x11, x9, x11
    add x11, x11, #24
    add x11, x11, x9
    add x11, x11, #8
    sxtw x11, w11
    mov x20, x11
    mov x0, x20
    bl __fern_alloc
    mov x21, x0
    mov x2, x20
    mov x1, x19
    mov x0, x21
    cbz x2, .Lssa___map_cow_inplace_mcd45
    cmp x2, #8
    b.lo .Lssa___map_cow_inplace_mcb45
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___map_cow_inplace_mc45:
    cmp x0, x10
    b.hs .Lssa___map_cow_inplace_mct45
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___map_cow_inplace_mc45
.Lssa___map_cow_inplace_mct45:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___map_cow_inplace_mcd45
.Lssa___map_cow_inplace_mcb45:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___map_cow_inplace_mcb45
.Lssa___map_cow_inplace_mcd45:
    mov x0, #0
    mov x0, x21
    bl __fn___map_own_copied_cols.r
    mov x11, #16
    mov x0, x11
    bl __fern_alloc
    mov x11, #1
    str w11, [x0]
    add x0, x0, #8
    str x21, [x0, #0]
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_own_copied_cols:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_own_copied_cols.k:
__fn___map_own_copied_cols.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #96
    mov x19, x0
.Lssa___map_own_copied_cols_0:
    add x9, x19, #8
    ldrsw x10, [x9]
    cmp x10, #1
    cset x4, eq
    str x4, [sp, #88]
    ldrsw x10, [x9]
    cmp x10, #4
    cset x4, eq
    str x4, [sp, #80]
    ldrsw x9, [x9]
    cmp x9, #2
    b.ne .Lssa___map_own_copied_cols_15
.Lssa___map_own_copied_cols_16:
    add x9, x19, #20
    ldrsw x9, [x9]
.Lssa___map_own_copied_cols_21:
    mov x22, x9
    b .Lssa___map_own_copied_cols_14
.Lssa___map_own_copied_cols_15:
    mov x22, #0
.Lssa___map_own_copied_cols_14:
    add x9, x19, #12
    ldrsw x9, [x9]
    mov x10, #255
    and x9, x9, x10
.Lssa___map_own_copied_cols_24:
    cmp x9, #5
    cset x23, eq
    cmp x23, #0
    cset x10, eq
    mov x11, #0
    cmp x9, #2
    csel x4, x10, x11, ge
    str x4, [sp, #72]
.Lssa___map_own_copied_cols_11:
    mov x0, x19
    bl __fn___map_val_cell_bytes.r
    mov x25, x0
    ldr x4, [sp, #88]
    cbnz x4, .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_10:
    ldr x4, [sp, #80]
    cbnz x4, .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_9:
    cbnz x23, .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_8:
    ldr x4, [sp, #72]
    cbnz x4, .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_7:
    cmp x25, #0
    b.ne .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_6:
    cmp x22, #0
    b.ne .Lssa___map_own_copied_cols_3
.Lssa___map_own_copied_cols_5:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_own_copied_cols_3:
    ldrsw x9, [x19]
    add x11, x19, #4
    ldrsw x26, [x11]
    mov x27, #8
    mov x11, #2
    mul x28, x11, x27
    mov x11, #24
.Lssa___map_own_copied_cols_55:
    sxtw x11, w11
    add x11, x19, x11
    lsl x9, x9, #2
    sxtw x9, w9
    add x20, x11, x9
.Lssa___map_own_copied_cols_2:
    mov x21, #0
.Lssa___map_own_copied_cols_57:
    cmp x21, x26
    b.ge .Lssa___map_own_copied_cols_1
.Lssa___map_own_copied_cols_76:
    mul x9, x21, x28
    sxtw x9, w9
    add x24, x20, x9
    ldr x4, [sp, #88]
    cbz x4, .Lssa___map_own_copied_cols_73
.Lssa___map_own_copied_cols_75:
    ldr x0, [x24, #0]
    bl __fn___map_own_str_slot.r
    str x0, [x24, #0]
.Lssa___map_own_copied_cols_73:
    ldr x4, [sp, #80]
    cbz x4, .Lssa___map_own_copied_cols_70
.Lssa___map_own_copied_cols_72:
    ldr x9, [x24, #0]
    tbnz x9, #0, .Lssa___map_own_copied_cols_rcinc189
    cmp x9, #16, lsl #12
    b.lo .Lssa___map_own_copied_cols_rcinc189
    and x7, x9, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    tbnz w5, #31, .Lssa___map_own_copied_cols_rcinc189
    add w5, w5, #1
    stur w5, [x7, #-8]
.Lssa___map_own_copied_cols_rcinc189:
    mov x0, x9
.Lssa___map_own_copied_cols_70:
    cbz x23, .Lssa___map_own_copied_cols_67
.Lssa___map_own_copied_cols_69:
    sxtw x9, w27
    add x9, x24, x9
    ldr x0, [x9, #0]
    str x9, [sp, #64]
    bl __fn___map_own_str_slot.r
    ldr x9, [sp, #64]
    str x0, [x9, #0]
.Lssa___map_own_copied_cols_67:
    ldr x4, [sp, #72]
    cbz x4, .Lssa___map_own_copied_cols_64
.Lssa___map_own_copied_cols_66:
    sxtw x11, w27
    add x11, x24, x11
    ldr x9, [x11, #0]
    mov x0, x19
    bl __fn___map_retain_val.r
.Lssa___map_own_copied_cols_64:
    cmp x25, #0
    b.eq .Lssa___map_own_copied_cols_61
.Lssa___map_own_copied_cols_63:
    mov x0, x25
    bl __fern_alloc
    mov x9, x0
    sxtw x11, w27
    add x11, x24, x11
    ldr x10, [x11, #0]
    str x9, [sp, #64]
    str x11, [sp, #56]
    mov x2, x25
    mov x1, x10
    mov x0, x9
    cbz x2, .Lssa___map_own_copied_cols_mcd334
    cmp x2, #8
    b.lo .Lssa___map_own_copied_cols_mcb334
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___map_own_copied_cols_mc334:
    cmp x0, x10
    b.hs .Lssa___map_own_copied_cols_mct334
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___map_own_copied_cols_mc334
.Lssa___map_own_copied_cols_mct334:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___map_own_copied_cols_mcd334
.Lssa___map_own_copied_cols_mcb334:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___map_own_copied_cols_mcb334
.Lssa___map_own_copied_cols_mcd334:
    mov x0, #0
    ldr x9, [sp, #64]
    ldr x11, [sp, #56]
    str x9, [x11, #0]
.Lssa___map_own_copied_cols_61:
    cmp x22, #0
    b.eq .Lssa___map_own_copied_cols_58
.Lssa___map_own_copied_cols_60:
    mov x0, x22
    bl __fern_alloc
    mov x10, x0
    ldr x11, [x24, #0]
    str x10, [sp, #64]
    mov x2, x22
    mov x1, x11
    mov x0, x10
    cbz x2, .Lssa___map_own_copied_cols_mcd366
    cmp x2, #8
    b.lo .Lssa___map_own_copied_cols_mcb366
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___map_own_copied_cols_mc366:
    cmp x0, x10
    b.hs .Lssa___map_own_copied_cols_mct366
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___map_own_copied_cols_mc366
.Lssa___map_own_copied_cols_mct366:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___map_own_copied_cols_mcd366
.Lssa___map_own_copied_cols_mcb366:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___map_own_copied_cols_mcb366
.Lssa___map_own_copied_cols_mcd366:
    mov x0, #0
    ldr x10, [sp, #64]
    str x10, [x24, #0]
.Lssa___map_own_copied_cols_58:
    add x21, x21, #1
    cmp x21, x26
    b.lt .Lssa___map_own_copied_cols_76
.Lssa___map_own_copied_cols_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_own_str_slot:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_own_str_slot.k:
__fn___map_own_str_slot.r:
.Lssa___map_own_str_slot_0:
    cmp x0, x0
    b.ne .Lssa___map_own_str_slot_4
.Lssa___map_own_str_slot_6:
    tbnz x0, #0, .Lssa___map_own_str_slot_rcinc18
    cmp x0, #16, lsl #12
    b.lo .Lssa___map_own_str_slot_rcinc18
    and x7, x0, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    tbnz w5, #31, .Lssa___map_own_str_slot_rcinc18
    add w5, w5, #1
    stur w5, [x7, #-8]
.Lssa___map_own_str_slot_rcinc18:
    mov x9, x0
    mov x0, x9
    ret
.Lssa___map_own_str_slot_4:
    mov x9, #8
    mov x10, #2
    mul x10, x10, x9
    sub x10, x10, #4
    sxtw x10, w10
    add x10, x0, x10
    ldrsw x10, [x10]
    cmp x10, #0
    b.ge .Lssa___map_own_str_slot_1
.Lssa___map_own_str_slot_3:
    ret
.Lssa___map_own_str_slot_1:
    ldr x10, [x0, #0]
    tbnz x10, #0, .Lssa___map_own_str_slot_rcinc31
    cmp x10, #16, lsl #12
    b.lo .Lssa___map_own_str_slot_rcinc31
    and x7, x10, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    tbnz w5, #31, .Lssa___map_own_str_slot_rcinc31
    add w5, w5, #1
    stur w5, [x7, #-8]
.Lssa___map_own_str_slot_rcinc31:
    mov x9, x10
    ret
    .cfi_endproc
    .ltorg
__fn___map_len_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_len_impl.k:
__fn___map_len_impl.r:
.Lssa___map_len_impl_0:
    ldr x9, [x0, #0]
    add x9, x9, #4
    ldrsw x0, [x9]
    ret
    .cfi_endproc
    .ltorg
__fn___map_hash_scalar:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_hash_scalar.k:
__fn___map_hash_scalar.r:
.Lssa___map_hash_scalar_0:
    mov x9, #61
    eor x0, x0, x9
    mov w9, w0
    lsr x9, x9, #16
    eor x0, x0, x9
    lsl x9, x0, #3
    add x0, x0, x9
    mov w9, w0
    lsr x9, x9, #4
    eor x0, x0, x9
    ldr x9, =668265261
    mul x0, x0, x9
    sxtw x0, w0
    mov w9, w0
    lsr x9, x9, #15
    sxtw x9, w9
    eor x0, x0, x9
    ret
    .cfi_endproc
    .ltorg
__fn___map_eq_scalar:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_eq_scalar.k:
__fn___map_eq_scalar.r:
.Lssa___map_eq_scalar_0:
    cmp x0, x9
    cset x0, eq
    ret
    .cfi_endproc
    .ltorg
__fn___map_hash_wide:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_hash_wide.k:
__fn___map_hash_wide.r:
.Lssa___map_hash_wide_0:
    ldr x9, [x0, #0]
    asr x10, x9, #32
    eor x9, x9, x10
    mov x10, #61
    eor x9, x9, x10
    mov w10, w9
    lsr x10, x10, #16
    eor x9, x9, x10
    lsl x10, x9, #3
    add x9, x9, x10
    mov w10, w9
    lsr x10, x10, #4
    eor x9, x9, x10
    ldr x10, =668265261
    mul x9, x9, x10
    sxtw x9, w9
    mov w10, w9
    lsr x10, x10, #15
    sxtw x10, w10
    eor x0, x9, x10
    ret
    .cfi_endproc
    .ltorg
__fn___map_eq_wide:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_eq_wide.k:
__fn___map_eq_wide.r:
.Lssa___map_eq_wide_0:
    ldr x10, [x0, #0]
    ldr x11, [x9, #0]
    cmp x10, x11
    cset x0, eq
    ret
    .cfi_endproc
    .ltorg
__fn___map_hash_str:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_hash_str.k:
__fn___map_hash_str.r:
.Lssa___map_hash_str_0:
    mov x9, #0
    b __fn___map_fnv_str_seeded.r
    .cfi_endproc
    .ltorg
__fn___map_eq_str:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_eq_str.k:
__fn___map_eq_str.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___map_eq_str_0:
    ldr x6, [x0, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa___map_eq_str_streqn5
    bl __fn___fern_str_eq.r
    b .Lssa___map_eq_str_streqd5
.Lssa___map_eq_str_streqn5:
    mov x0, #0
.Lssa___map_eq_str_streqd5:
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_bucket_hash:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_bucket_hash.k:
__fn___map_bucket_hash.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___map_bucket_hash_0:
    cmp x10, #0
    b.eq .Lssa___map_bucket_hash_1
.Lssa___map_bucket_hash_3:
    mov x9, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_fnv_str_seeded.r
    .cfi_restore_state
.Lssa___map_bucket_hash_1:
    mov x4, x9
    mov x9, x0
    mov x0, x4
    ldr x6, [x0, #8]
    blr x6
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_lookup:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_lookup.k:
__fn___map_lookup.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___map_lookup_0:
    ldr x9, [x19, #0]
    add x9, x9, #8
    ldrsw x21, [x9]
    cmp x21, #0
    b.ne .Lssa___map_lookup_4
.Lssa___map_lookup_6:
    adrp x22, .K0
    add x22, x22, :lo12:.K0
    adrp x23, .K1
    add x23, x23, :lo12:.K1
    mov x0, x19
    mov x9, x20
    mov x10, x22
    mov x11, x23
    bl __fn___map_lookup_keyed.r
    mov x24, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa___map_lookup_rcdeck28
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa___map_lookup_rcdecd28
    tbnz w5, #31, .Lssa___map_lookup_rcdeck28
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa___map_lookup_rcdece28
.Lssa___map_lookup_rcdecd28:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa___map_lookup_rcdeck28:
    mov x0, x22
.Lssa___map_lookup_rcdece28:
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_lookup_rcdeck29
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___map_lookup_rcdecd29
    tbnz w5, #31, .Lssa___map_lookup_rcdeck29
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___map_lookup_rcdece29
.Lssa___map_lookup_rcdecd29:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___map_lookup_rcdeck29:
    mov x0, x23
.Lssa___map_lookup_rcdece29:
    mov x0, x24
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_4:
    cmp x21, #2
    b.ne .Lssa___map_lookup_1
.Lssa___map_lookup_3:
    adrp x21, .K2
    add x21, x21, :lo12:.K2
    adrp x24, .K3
    add x24, x24, :lo12:.K3
    mov x0, x19
    mov x9, x20
    mov x10, x21
    mov x11, x24
    bl __fn___map_lookup_keyed.r
    mov x23, x0
    cmp x21, #16, lsl #12
    b.lo .Lssa___map_lookup_rcdeck35
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa___map_lookup_rcdecd35
    tbnz w5, #31, .Lssa___map_lookup_rcdeck35
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa___map_lookup_rcdece35
.Lssa___map_lookup_rcdecd35:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa___map_lookup_rcdeck35:
    mov x0, x21
.Lssa___map_lookup_rcdece35:
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_lookup_rcdeck36
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_lookup_rcdecd36
    tbnz w5, #31, .Lssa___map_lookup_rcdeck36
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_lookup_rcdece36
.Lssa___map_lookup_rcdecd36:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_lookup_rcdeck36:
    mov x0, x24
.Lssa___map_lookup_rcdece36:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_1:
    adrp x23, .K4
    add x23, x23, :lo12:.K4
    adrp x24, .K5
    add x24, x24, :lo12:.K5
    mov x0, x19
    mov x9, x20
    mov x10, x23
    mov x11, x24
    bl __fn___map_lookup_keyed.r
    mov x21, x0
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_lookup_rcdeck40
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___map_lookup_rcdecd40
    tbnz w5, #31, .Lssa___map_lookup_rcdeck40
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___map_lookup_rcdece40
.Lssa___map_lookup_rcdecd40:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___map_lookup_rcdeck40:
    mov x0, x23
.Lssa___map_lookup_rcdece40:
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_lookup_rcdeck41
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_lookup_rcdecd41
    tbnz w5, #31, .Lssa___map_lookup_rcdeck41
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_lookup_rcdece41
.Lssa___map_lookup_rcdecd41:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_lookup_rcdeck41:
    mov x0, x24
.Lssa___map_lookup_rcdece41:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_has_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_has_impl.k:
__fn___map_has_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___map_has_impl_0:
    bl __fn___map_lookup.r
    mov x9, #-1
    cmp x0, x9
    cset x0, ne
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_val_kind:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_val_kind.k:
__fn___map_val_kind.r:
.Lssa___map_val_kind_0:
    add x0, x0, #12
    ldrsw x0, [x0]
    mov x9, #255
    and x0, x0, x9
    ret
    .cfi_endproc
    .ltorg
__fn___map_val_stride:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_val_stride.k:
__fn___map_val_stride.r:
.Lssa___map_val_stride_0:
    add x0, x0, #12
    ldrsw x0, [x0]
    asr x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
__fn___map_val_cell_bytes:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_val_cell_bytes.k:
__fn___map_val_cell_bytes.r:
.Lssa___map_val_cell_bytes_0:
    add x9, x0, #12
    ldrsw x9, [x9]
    mov x10, #255
    and x9, x9, x10
.Lssa___map_val_cell_bytes_4:
    cmp x9, #0
    b.eq .Lssa___map_val_cell_bytes_1
.Lssa___map_val_cell_bytes_3:
    mov x0, #0
    ret
.Lssa___map_val_cell_bytes_1:
    add x0, x0, #12
    ldrsw x0, [x0]
    asr x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
__fn___map_key_cell_bytes:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_key_cell_bytes.k:
__fn___map_key_cell_bytes.r:
.Lssa___map_key_cell_bytes_0:
    add x0, x0, #20
    ldrsw x0, [x0]
    ret
    .cfi_endproc
    .ltorg
__fn___map_free_key_cell:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_free_key_cell.k:
__fn___map_free_key_cell.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x9
.Lssa___map_free_key_cell_0:
    add x9, x0, #20
    ldrsw x20, [x9]
.Lssa___map_free_key_cell_10:
    cmp x20, #0
    b.ne .Lssa___map_free_key_cell_7
.Lssa___map_free_key_cell_9:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_free_key_cell_7:
    cmp x19, #0
    b.ne .Lssa___map_free_key_cell_4
.Lssa___map_free_key_cell_6:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_free_key_cell_4:
    add x0, x0, #8
    ldrsw x0, [x0]
    cmp x0, #1
    b.ne .Lssa___map_free_key_cell_1
.Lssa___map_free_key_cell_3:
    tbnz x19, #0, .Lssa___map_free_key_cell_rcdeck34
    cmp x19, #16, lsl #12
    b.lo .Lssa___map_free_key_cell_rcdeck34
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___map_free_key_cell_rcdecd34
    tbnz w5, #31, .Lssa___map_free_key_cell_rcdeck34
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa___map_free_key_cell_rcdece34
.Lssa___map_free_key_cell_rcdecd34:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___map_free_key_cell_rcdeck34:
    mov x0, x19
.Lssa___map_free_key_cell_rcdece34:
.Lssa___map_free_key_cell_1:
    mov x1, x20
    mov x0, x19
    bl __fern_raw_free
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_free_val_cell:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_free_val_cell.k:
__fn___map_free_val_cell.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x9
.Lssa___map_free_val_cell_0:
    bl __fn___map_val_cell_bytes.r
    cmp x0, #0
    b.ne .Lssa___map_free_val_cell_4
.Lssa___map_free_val_cell_6:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_free_val_cell_4:
    cmp x19, #0
    b.ne .Lssa___map_free_val_cell_1
.Lssa___map_free_val_cell_3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_free_val_cell_1:
    mov x1, x0
    mov x0, x19
    bl __fern_raw_free
    mov x0, #0
    mov x9, x0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_str_val_cell_bytes:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_str_val_cell_bytes.k:
__fn___map_str_val_cell_bytes.r:
.Lssa___map_str_val_cell_bytes_0:
    add x9, x0, #12
    ldrsw x9, [x9]
    mov x10, #255
    and x9, x9, x10
.Lssa___map_str_val_cell_bytes_4:
    cmp x9, #5
    b.eq .Lssa___map_str_val_cell_bytes_1
.Lssa___map_str_val_cell_bytes_3:
    mov x0, #0
    ret
.Lssa___map_str_val_cell_bytes_1:
    add x0, x0, #12
    ldrsw x0, [x0]
    asr x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
__fn___map_dec_value:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_dec_value.k:
__fn___map_dec_value.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___map_dec_value_0:
    add x9, x19, #12
    ldrsw x9, [x9]
    mov x10, #255
    and x21, x9, x10
.Lssa___map_dec_value_20:
    cmp x21, #0
    b.ne .Lssa___map_dec_value_17
.Lssa___map_dec_value_19:
    mov x0, x19
    mov x9, x20
    bl __fn___map_free_val_cell.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_dec_value_17:
    cmp x21, #5
    b.ne .Lssa___map_dec_value_8
.Lssa___map_dec_value_16:
    cmp x20, #0
    b.ne .Lssa___map_dec_value_13
.Lssa___map_dec_value_15:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_dec_value_13:
    tbnz x20, #0, .Lssa___map_dec_value_rcdeck53
    cmp x20, #16, lsl #12
    b.lo .Lssa___map_dec_value_rcdeck53
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___map_dec_value_rcdecd53
    tbnz w5, #31, .Lssa___map_dec_value_rcdeck53
    mov x0, x20
    bl __fn___fern_str_free.u
    b .Lssa___map_dec_value_rcdece53
.Lssa___map_dec_value_rcdecd53:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___map_dec_value_rcdeck53:
    mov x0, x20
.Lssa___map_dec_value_rcdece53:
    mov x0, x19
    bl __fn___map_str_val_cell_bytes.r
    cmp x0, #0
    b.eq .Lssa___map_dec_value_10
.Lssa___map_dec_value_12:
    mov x1, x0
    mov x0, x20
    bl __fern_raw_free
    mov x0, #0
    mov x10, x0
.Lssa___map_dec_value_10:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_dec_value_8:
    cmp x21, #2
    b.eq .Lssa___map_dec_value_47
.Lssa___map_dec_value_7:
    cmp x21, #3
    b.eq .Lssa___map_dec_value_47
.Lssa___map_dec_value_6:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_dec_value_47:
    cmp x21, #3
    cset x21, eq
.Lssa___map_dec_value_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_retain_val:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_retain_val.k:
__fn___map_retain_val.r:
.Lssa___map_retain_val_0:
    add x0, x0, #12
    ldrsw x0, [x0]
    mov x10, #255
    and x0, x0, x10
.Lssa___map_retain_val_5:
    cmp x0, #2
    b.lt .Lssa___map_retain_val_1
.Lssa___map_retain_val_4:
    cmp x0, #5
    b.eq .Lssa___map_retain_val_1
.Lssa___map_retain_val_3:
    tbnz x9, #0, .Lssa___map_retain_val_rcinc24
    cmp x9, #16, lsl #12
    b.lo .Lssa___map_retain_val_rcinc24
    and x7, x9, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    tbnz w5, #31, .Lssa___map_retain_val_rcinc24
    add w5, w5, #1
    stur w5, [x7, #-8]
.Lssa___map_retain_val_rcinc24:
    mov x0, x9
    ret
.Lssa___map_retain_val_1:
    mov x0, x9
    ret
    .cfi_endproc
    .ltorg
__fn___map_val_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_val_at.k:
__fn___map_val_at.r:
.Lssa___map_val_at_0:
    ldr x10, [x0, #0]
    ldrsw x11, [x10]
    mov x12, #8
    mov x13, #24
.Lssa___map_val_at_1:
    sxtw x13, w13
    add x10, x10, x13
    lsl x11, x11, #2
    sxtw x11, w11
    add x10, x10, x11
    mov x11, #2
    mul x11, x11, x12
    mul x9, x9, x11
    sxtw x9, w9
    add x10, x10, x9
    sxtw x12, w12
    add x10, x10, x12
    ldr x0, [x10, #0]
    ret
    .cfi_endproc
    .ltorg
__fn___map_get_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_get_impl.k:
__fn___map_get_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
.Lssa___map_get_impl_0:
    mov x0, x19
    bl __fn___map_lookup.r
    mov x9, #-1
    cmp x0, x9
    b.ne .Lssa___map_get_impl_1
.Lssa___map_get_impl_3:
    adrp x9, .K6
    add x9, x9, :lo12:.K6
    mov x0, x9
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_get_impl_1:
    ldr x20, [x19, #0]
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    mov x9, x0
    mov x0, x20
    bl __fn___map_retain_val.r
    mov x19, x0
    mov x0, #2
    bl __fern_arr_box
    mov x9, #0
    str x9, [x0, #0]
    str x19, [x0, #8]
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_get_or_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_get_or_impl.k:
__fn___map_get_or_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa___map_get_or_impl_0:
    mov x0, x19
    bl __fn___map_lookup.r
    mov x9, #-1
    cmp x0, x9
    b.ne .Lssa___map_get_or_impl_1
.Lssa___map_get_or_impl_3:
    ldr x9, [x19, #0]
    mov x0, x9
    mov x9, x20
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_retain_val.r
    .cfi_restore_state
.Lssa___map_get_or_impl_1:
    ldr x20, [x19, #0]
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    mov x9, x0
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_retain_val.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_lookup_val:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_lookup_val.k:
__fn___map_lookup_val.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_lookup_val_0:
    mov x0, x19
    bl __fn___map_lookup.r
    mov x9, #-1
    cmp x0, x9
    b.ne .Lssa___map_lookup_val_1
.Lssa___map_lookup_val_3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_val_1:
    mov x9, x0
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_val_at.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_put_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_put_impl.k:
__fn___map_put_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    str x25, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___map_put_impl_0:
    ldr x9, [x19, #0]
    add x9, x9, #8
    ldrsw x22, [x9]
    cmp x22, #0
    b.ne .Lssa___map_put_impl_4
.Lssa___map_put_impl_6:
    adrp x23, .K0
    add x23, x23, :lo12:.K0
    adrp x24, .K1
    add x24, x24, :lo12:.K1
    mov x0, x19
    mov x9, x20
    mov x10, x21
    mov x11, x23
    mov x12, x24
    bl __fn___map_put_keyed.r
    mov x25, x0
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_put_impl_rcdeck29
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___map_put_impl_rcdecd29
    tbnz w5, #31, .Lssa___map_put_impl_rcdeck29
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___map_put_impl_rcdece29
.Lssa___map_put_impl_rcdecd29:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___map_put_impl_rcdeck29:
    mov x0, x23
.Lssa___map_put_impl_rcdece29:
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_put_impl_rcdeck30
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_put_impl_rcdecd30
    tbnz w5, #31, .Lssa___map_put_impl_rcdeck30
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_put_impl_rcdece30
.Lssa___map_put_impl_rcdecd30:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_put_impl_rcdeck30:
    mov x0, x24
.Lssa___map_put_impl_rcdece30:
    mov x0, x25
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_put_impl_4:
    cmp x22, #2
    b.ne .Lssa___map_put_impl_1
.Lssa___map_put_impl_3:
    adrp x22, .K2
    add x22, x22, :lo12:.K2
    adrp x25, .K3
    add x25, x25, :lo12:.K3
    mov x0, x19
    mov x9, x20
    mov x10, x21
    mov x11, x22
    mov x12, x25
    bl __fn___map_put_keyed.r
    mov x24, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa___map_put_impl_rcdeck36
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa___map_put_impl_rcdecd36
    tbnz w5, #31, .Lssa___map_put_impl_rcdeck36
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa___map_put_impl_rcdece36
.Lssa___map_put_impl_rcdecd36:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa___map_put_impl_rcdeck36:
    mov x0, x22
.Lssa___map_put_impl_rcdece36:
    cmp x25, #16, lsl #12
    b.lo .Lssa___map_put_impl_rcdeck37
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa___map_put_impl_rcdecd37
    tbnz w5, #31, .Lssa___map_put_impl_rcdeck37
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa___map_put_impl_rcdece37
.Lssa___map_put_impl_rcdecd37:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa___map_put_impl_rcdeck37:
    mov x0, x25
.Lssa___map_put_impl_rcdece37:
    mov x0, x24
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_put_impl_1:
    adrp x24, .K4
    add x24, x24, :lo12:.K4
    adrp x25, .K5
    add x25, x25, :lo12:.K5
    mov x0, x19
    mov x9, x20
    mov x10, x21
    mov x11, x24
    mov x12, x25
    bl __fn___map_put_keyed.r
    mov x22, x0
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_put_impl_rcdeck41
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_put_impl_rcdecd41
    tbnz w5, #31, .Lssa___map_put_impl_rcdeck41
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_put_impl_rcdece41
.Lssa___map_put_impl_rcdecd41:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_put_impl_rcdeck41:
    mov x0, x24
.Lssa___map_put_impl_rcdece41:
    cmp x25, #16, lsl #12
    b.lo .Lssa___map_put_impl_rcdeck42
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa___map_put_impl_rcdecd42
    tbnz w5, #31, .Lssa___map_put_impl_rcdeck42
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa___map_put_impl_rcdece42
.Lssa___map_put_impl_rcdecd42:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa___map_put_impl_rcdeck42:
    mov x0, x25
.Lssa___map_put_impl_rcdece42:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_i32_column:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_i32_column.k:
__fn___map_i32_column.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    sub sp, sp, #64
.Lssa___map_i32_column_0:
    ldr x10, [x0, #0]
    ldrsw x11, [x10]
    add x12, x10, #4
    ldrsw x12, [x12]
    mov x13, #8
    mov x14, #2
    mul x14, x14, x13
    mov x13, #24
.Lssa___map_i32_column_3:
    sxtw x13, w13
    add x10, x10, x13
    lsl x11, x11, #2
    sxtw x11, w11
    add x10, x10, x11
    adrp x0, .K7
    add x0, x0, :lo12:.K7
.Lssa___map_i32_column_2:
    mov x11, x0
    mov x13, #0
.Lssa___map_i32_column_5:
    cmp x13, x12
    b.ge .Lssa___map_i32_column_1
.Lssa___map_i32_column_6:
    mul x15, x13, x14
    sxtw x15, w15
    add x15, x10, x15
    sxtw x1, w9
    add x15, x15, x1
    ldrsw x15, [x15]
    mov x0, x11
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_i32_column_apush75s
.Lssa___map_i32_column_apush75o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_i32_column_apush75e
.Lssa___map_i32_column_apush75s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
.Lssa___map_i32_column_apush75e:
    mov x11, x0
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___map_i32_column_6
.Lssa___map_i32_column_1:
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_cell:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_cell.k:
__fn___map_cell.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_cell_0:
    mov x9, #8
    mov x0, x9
    bl __fern_alloc
    str x19, [x0, #0]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_cell_load:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_cell_load.k:
__fn___map_cell_load.r:
.Lssa___map_cell_load_0:
    ldr x9, [x0, #0]
    mov x0, x9
    ret
    .cfi_endproc
    .ltorg
__fn___map_cell_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_cell_free.k:
__fn___map_cell_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_cell_free_0:
    mov x9, #8
    mov x1, x9
    mov x0, x19
    bl __fern_raw_free
    mov x0, #0
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_get_cell_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_get_cell_impl.k:
__fn___map_get_cell_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_get_cell_impl_0:
    mov x0, x19
    bl __fn___map_lookup.r
    mov x9, #-1
    cmp x0, x9
    b.ne .Lssa___map_get_cell_impl_1
.Lssa___map_get_cell_impl_3:
    adrp x9, .K6
    add x9, x9, :lo12:.K6
    mov x0, x9
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_get_cell_impl_1:
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    ldr x19, [x0, #0]
    mov x0, #2
    bl __fern_arr_box
    mov x9, #0
    str x9, [x0, #0]
    str x19, [x0, #8]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_get_cell_f64_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_get_cell_f64_impl.k:
__fn___map_get_cell_f64_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_get_cell_f64_impl_0:
    mov x0, x19
    bl __fn___map_lookup.r
    mov x9, #-1
    cmp x0, x9
    b.ne .Lssa___map_get_cell_f64_impl_1
.Lssa___map_get_cell_f64_impl_3:
    adrp x9, .K6
    add x9, x9, :lo12:.K6
    mov x0, x9
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_get_cell_f64_impl_1:
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    ldr x9, [x0, #0]
    mov x19, x9
    mov x0, #2
    bl __fern_arr_box
    mov x9, #0
    str x9, [x0, #0]
    str x19, [x0, #8]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_get_cell_keyed_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_get_cell_keyed_impl.k:
__fn___map_get_cell_keyed_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_get_cell_keyed_impl_0:
    mov x0, x19
    bl __fn___map_lookup_keyed.r
    mov x11, #-1
    cmp x0, x11
    b.ne .Lssa___map_get_cell_keyed_impl_1
.Lssa___map_get_cell_keyed_impl_3:
    adrp x11, .K6
    add x11, x11, :lo12:.K6
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_get_cell_keyed_impl_1:
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    ldr x19, [x0, #0]
    mov x0, #2
    bl __fern_arr_box
    mov x11, #0
    str x11, [x0, #0]
    str x19, [x0, #8]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_get_cell_f64_keyed_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_get_cell_f64_keyed_impl.k:
__fn___map_get_cell_f64_keyed_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_get_cell_f64_keyed_impl_0:
    mov x0, x19
    bl __fn___map_lookup_keyed.r
    mov x11, #-1
    cmp x0, x11
    b.ne .Lssa___map_get_cell_f64_keyed_impl_1
.Lssa___map_get_cell_f64_keyed_impl_3:
    adrp x11, .K6
    add x11, x11, :lo12:.K6
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_get_cell_f64_keyed_impl_1:
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    ldr x11, [x0, #0]
    mov x19, x11
    mov x0, #2
    bl __fern_arr_box
    mov x11, #0
    str x11, [x0, #0]
    str x19, [x0, #8]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_cell_column:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_cell_column.k:
__fn___map_cell_column.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    sub sp, sp, #64
.Lssa___map_cell_column_0:
    ldr x10, [x0, #0]
    ldrsw x11, [x10]
    add x12, x10, #4
    ldrsw x12, [x12]
    mov x13, #8
    mov x14, #2
    mul x14, x14, x13
    mov x13, #24
.Lssa___map_cell_column_3:
    sxtw x13, w13
    add x10, x10, x13
    lsl x11, x11, #2
    sxtw x11, w11
    add x10, x10, x11
    adrp x0, .K7
    add x0, x0, :lo12:.K7
.Lssa___map_cell_column_2:
    mov x11, x0
    mov x13, #0
.Lssa___map_cell_column_5:
    cmp x13, x12
    b.ge .Lssa___map_cell_column_1
.Lssa___map_cell_column_6:
    mul x15, x13, x14
    sxtw x15, w15
    add x15, x10, x15
    sxtw x1, w9
    add x15, x15, x1
    ldr x1, [x15, #0]
    ldr x15, [x1, #0]
    mov x0, x11
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_cell_column_apush77s
.Lssa___map_cell_column_apush77o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_cell_column_apush77e
.Lssa___map_cell_column_apush77s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
.Lssa___map_cell_column_apush77e:
    mov x11, x0
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___map_cell_column_6
.Lssa___map_cell_column_1:
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_cell_f64_column:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_cell_f64_column.k:
__fn___map_cell_f64_column.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    sub sp, sp, #64
.Lssa___map_cell_f64_column_0:
    ldr x10, [x0, #0]
    ldrsw x11, [x10]
    add x12, x10, #4
    ldrsw x12, [x12]
    mov x13, #8
    mov x14, #2
    mul x14, x14, x13
    mov x13, #24
.Lssa___map_cell_f64_column_3:
    sxtw x13, w13
    add x10, x10, x13
    lsl x11, x11, #2
    sxtw x11, w11
    add x10, x10, x11
    adrp x0, .K7
    add x0, x0, :lo12:.K7
.Lssa___map_cell_f64_column_2:
    mov x11, x0
    mov x13, #0
.Lssa___map_cell_f64_column_5:
    cmp x13, x12
    b.ge .Lssa___map_cell_f64_column_1
.Lssa___map_cell_f64_column_6:
    mul x15, x13, x14
    sxtw x15, w15
    add x15, x10, x15
    sxtw x1, w9
    add x15, x15, x1
    ldr x1, [x15, #0]
    ldr x15, [x1, #0]
    mov x0, x11
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_cell_f64_column_apush79s
.Lssa___map_cell_f64_column_apush79o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_cell_f64_column_apush79e
.Lssa___map_cell_f64_column_apush79s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
.Lssa___map_cell_f64_column_apush79e:
    mov x11, x0
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___map_cell_f64_column_6
.Lssa___map_cell_f64_column_1:
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_bool_column:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_bool_column.k:
__fn___map_bool_column.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    sub sp, sp, #64
.Lssa___map_bool_column_0:
    ldr x10, [x0, #0]
    ldrsw x11, [x10]
    add x12, x10, #4
    ldrsw x12, [x12]
    mov x13, #8
    mov x14, #2
    mul x14, x14, x13
    mov x13, #24
.Lssa___map_bool_column_3:
    sxtw x13, w13
    add x10, x10, x13
    lsl x11, x11, #2
    sxtw x11, w11
    add x10, x10, x11
    adrp x0, .K7
    add x0, x0, :lo12:.K7
.Lssa___map_bool_column_2:
    mov x11, x0
    mov x13, #0
.Lssa___map_bool_column_5:
    cmp x13, x12
    b.ge .Lssa___map_bool_column_1
.Lssa___map_bool_column_6:
    mul x15, x13, x14
    sxtw x15, w15
    add x15, x10, x15
    sxtw x1, w9
    add x15, x15, x1
    ldrsw x15, [x15]
    cmp x15, #0
    cset x15, ne
    mov x0, x11
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_bool_column_apush79s
.Lssa___map_bool_column_apush79o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_bool_column_apush79e
.Lssa___map_bool_column_apush79s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
.Lssa___map_bool_column_apush79e:
    mov x11, x0
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___map_bool_column_6
.Lssa___map_bool_column_1:
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_u8_column:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_u8_column.k:
__fn___map_u8_column.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
.Lssa___map_u8_column_0:
    ldr x9, [x0, #0]
    ldrsw x10, [x9]
    add x11, x9, #4
    ldrsw x20, [x11]
    mov x11, #8
    mov x12, #2
    mul x21, x12, x11
    mov x12, #24
.Lssa___map_u8_column_3:
    sxtw x12, w12
    add x9, x9, x12
    lsl x10, x10, #2
    sxtw x10, w10
    add x22, x9, x10
    mov x0, x20
    bl __fern_alloc_bytes
.Lssa___map_u8_column_2:
    mov x10, #0
.Lssa___map_u8_column_5:
    cmp x10, x20
    b.ge .Lssa___map_u8_column_1
.Lssa___map_u8_column_6:
    mul x9, x10, x21
    sxtw x9, w9
    add x9, x22, x9
    sxtw x12, w19
    add x9, x9, x12
    ldrsw x9, [x9]
    and x9, x9, #255
    add x5, x0, x10
    strb w9, [x5, #8]
    add x10, x10, #1
    cmp x10, x20
    b.lt .Lssa___map_u8_column_6
.Lssa___map_u8_column_1:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_string_column:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_string_column.k:
__fn___map_string_column.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    str x25, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x9
.Lssa___map_string_column_0:
    ldr x9, [x0, #0]
    ldrsw x10, [x9]
    add x11, x9, #4
    ldrsw x20, [x11]
    mov x11, #8
    mov x12, #2
    mul x21, x12, x11
    mov x12, #24
.Lssa___map_string_column_3:
    sxtw x12, w12
    add x9, x9, x12
    lsl x10, x10, #2
    sxtw x10, w10
    add x22, x9, x10
    mov x0, #4
    bl __fern_arr_box
    mov x10, #0
    str x10, [x0, #0]
.Lssa___map_string_column_2:
    mov x23, x0
    mov x24, #0
.Lssa___map_string_column_5:
    cmp x24, x20
    b.ge .Lssa___map_string_column_1
.Lssa___map_string_column_6:
    mul x9, x24, x21
    sxtw x9, w9
    add x9, x22, x9
    sxtw x10, w19
    add x9, x9, x10
    ldr x10, [x9, #0]
    tbnz x10, #0, .Lssa___map_string_column_rcinc84
    cmp x10, #16, lsl #12
    b.lo .Lssa___map_string_column_rcinc84
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa___map_string_column_rcinc84
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa___map_string_column_rcinc84:
    mov x0, x10
    tst x23, #1
    b.ne .Lssa___map_string_column_uq6
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_string_column_uq6
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa___map_string_column_uq6:
    b.ne .Lssa___map_string_column_12
.Lssa___map_string_column_11:
    mov x0, x23
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_string_column_apush86s
.Lssa___map_string_column_apush86o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_string_column_apush86e
.Lssa___map_string_column_apush86s:
    str x10, [sp, #56]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
.Lssa___map_string_column_apush86e:
    mov x23, x0
    b .Lssa___map_string_column_13
.Lssa___map_string_column_12:
    mov x0, x23
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_string_column_apush87s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa___map_string_column_apush87o
    tbz w3, #31, .Lssa___map_string_column_apush87s
.Lssa___map_string_column_apush87o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_string_column_apush87e
.Lssa___map_string_column_apush87s:
    bl __fern_arr_push
.Lssa___map_string_column_apush87e:
    mov x25, x0
    mov x0, x23
    bl __fn___fern_arr_inc_elems.r
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_string_column_rcdeck89
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___map_string_column_rcdecd89
    tbnz w5, #31, .Lssa___map_string_column_rcdeck89
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___map_string_column_rcdece89
.Lssa___map_string_column_rcdecd89:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___map_string_column_rcdeck89:
    mov x0, x23
.Lssa___map_string_column_rcdece89:
    mov x23, x25
.Lssa___map_string_column_13:
    add x24, x24, #1
    cmp x24, x20
    b.lt .Lssa___map_string_column_6
.Lssa___map_string_column_1:
    tbnz x23, #0, .Lssa___map_string_column_rcinc94
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_string_column_rcinc94
    and x7, x23, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    tbnz w5, #31, .Lssa___map_string_column_rcinc94
    add w5, w5, #1
    stur w5, [x7, #-8]
.Lssa___map_string_column_rcinc94:
    mov x24, x23
    tst x23, #1
    b.ne .Lssa___map_string_column_uq1
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_string_column_uq1
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa___map_string_column_uq1:
    b.ne .Lssa___map_string_column_18
.Lssa___map_string_column_16:
    mov x22, #0
.Lssa___map_string_column_20:
    ldr x10, [x23, #0]
    cmp x22, x10
    b.ge .Lssa___map_string_column_18
.Lssa___map_string_column_21:
    add x5, x22, #1
    ldr x10, [x23, x5, lsl #3]
    tbnz x10, #0, .Lssa___map_string_column_rcdeck101
    cmp x10, #16, lsl #12
    b.lo .Lssa___map_string_column_rcdeck101
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa___map_string_column_rcdecd101
    tbnz w5, #31, .Lssa___map_string_column_rcdeck101
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa___map_string_column_rcdece101
.Lssa___map_string_column_rcdecd101:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa___map_string_column_rcdeck101:
    mov x0, x10
.Lssa___map_string_column_rcdece101:
    add x22, x22, #1
    b .Lssa___map_string_column_20
.Lssa___map_string_column_18:
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_string_column_rcdeck105
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___map_string_column_rcdecd105
    tbnz w5, #31, .Lssa___map_string_column_rcdeck105
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___map_string_column_rcdece105
.Lssa___map_string_column_rcdecd105:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___map_string_column_rcdeck105:
    mov x0, x23
.Lssa___map_string_column_rcdece105:
    mov x0, x24
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_box_column:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_box_column.k:
__fn___map_box_column.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x9
    mov x20, x10
.Lssa___map_box_column_0:
    ldr x9, [x0, #0]
    ldrsw x10, [x9]
    add x11, x9, #4
    ldrsw x21, [x11]
    mov x11, #8
    mov x12, #2
    mul x22, x12, x11
    mov x12, #24
.Lssa___map_box_column_3:
    sxtw x12, w12
    add x9, x9, x12
    lsl x10, x10, #2
    sxtw x10, w10
    add x23, x9, x10
    mov x0, #4
    bl __fern_arr_box
    mov x10, #0
    str x10, [x0, #0]
.Lssa___map_box_column_2:
    mov x24, x0
    mov x25, #0
.Lssa___map_box_column_5:
    cmp x25, x21
    b.ge .Lssa___map_box_column_1
.Lssa___map_box_column_9:
    mul x9, x25, x22
    sxtw x9, w9
    add x9, x23, x9
    sxtw x10, w19
    add x9, x9, x10
    ldr x10, [x9, #0]
    cbz x20, .Lssa___map_box_column_7
.Lssa___map_box_column_8:
    tbnz x10, #0, .Lssa___map_box_column_rcinc86
    cmp x10, #16, lsl #12
    b.lo .Lssa___map_box_column_rcinc86
    and x7, x10, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    tbnz w5, #31, .Lssa___map_box_column_rcinc86
    add w5, w5, #1
    stur w5, [x7, #-8]
.Lssa___map_box_column_rcinc86:
    mov x0, x10
    mov x10, x0
    b .Lssa___map_box_column_6
.Lssa___map_box_column_7:
.Lssa___map_box_column_6:
    tst x24, #1
    b.ne .Lssa___map_box_column_uq6
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_box_column_uq6
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa___map_box_column_uq6:
    b.ne .Lssa___map_box_column_20
.Lssa___map_box_column_19:
    mov x0, x24
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_box_column_apush89s
.Lssa___map_box_column_apush89o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_box_column_apush89e
.Lssa___map_box_column_apush89s:
    str x10, [sp, #56]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
.Lssa___map_box_column_apush89e:
    mov x24, x0
    b .Lssa___map_box_column_21
.Lssa___map_box_column_20:
    mov x0, x24
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___map_box_column_apush90s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa___map_box_column_apush90o
    tbz w3, #31, .Lssa___map_box_column_apush90s
.Lssa___map_box_column_apush90o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___map_box_column_apush90e
.Lssa___map_box_column_apush90s:
    bl __fern_arr_push
.Lssa___map_box_column_apush90e:
    mov x26, x0
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_box_column_rcdeck91
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_box_column_rcdecd91
    tbnz w5, #31, .Lssa___map_box_column_rcdeck91
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_box_column_rcdece91
.Lssa___map_box_column_rcdecd91:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_box_column_rcdeck91:
    mov x0, x24
.Lssa___map_box_column_rcdece91:
    mov x24, x26
.Lssa___map_box_column_21:
    add x25, x25, #1
    cmp x25, x21
    b.lt .Lssa___map_box_column_9
.Lssa___map_box_column_1:
    tbnz x24, #0, .Lssa___map_box_column_rcinc96
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_box_column_rcinc96
    and x7, x24, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    tbnz w5, #31, .Lssa___map_box_column_rcinc96
    add w5, w5, #1
    stur w5, [x7, #-8]
.Lssa___map_box_column_rcinc96:
    mov x25, x24
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_box_column_rcdeck97
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_box_column_rcdecd97
    tbnz w5, #31, .Lssa___map_box_column_rcdeck97
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_box_column_rcdece97
.Lssa___map_box_column_rcdecd97:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_box_column_rcdeck97:
    mov x0, x24
.Lssa___map_box_column_rcdece97:
    mov x0, x25
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_drop_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_drop_impl.k:
__fn___map_drop_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
.Lssa___map_drop_impl_0:
    cmp x19, #0
    b.ne .Lssa___map_drop_impl_11
.Lssa___map_drop_impl_13:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_drop_impl_11:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_10:
    ldr x20, [x19, #0]
    cmp x20, #0
    b.eq .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_9:
    add x9, x20, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.eq .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_8:
    add x9, x20, #20
    ldrsw x9, [x9]
.Lssa___map_drop_impl_30:
    cmp x9, #0
    b.eq .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_7:
    add x9, x20, #4
    ldrsw x21, [x9]
    mov x9, #8
    mov x10, #2
    mul x22, x10, x9
    mov x10, #24
.Lssa___map_drop_impl_36:
    sxtw x10, w10
    add x10, x20, x10
    ldrsw x9, [x20]
    lsl x9, x9, #2
    sxtw x9, w9
    add x23, x10, x9
.Lssa___map_drop_impl_6:
    mov x24, #0
.Lssa___map_drop_impl_38:
    cmp x24, x21
    b.ge .Lssa___map_drop_impl_1
.Lssa___map_drop_impl_39:
    mul x9, x24, x22
    sxtw x9, w9
    add x9, x23, x9
    ldr x10, [x9, #0]
    mov x0, x20
    mov x9, x10
    bl __fn___map_free_key_cell.r
    add x24, x24, #1
    cmp x24, x21
    b.lt .Lssa___map_drop_impl_39
.Lssa___map_drop_impl_1:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_free_table:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_free_table.k:
__fn___map_free_table.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_free_table_0:
    cmp x19, #0
    b.ne .Lssa___map_free_table_7
.Lssa___map_free_table_9:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_free_table_7:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.eq .Lssa___map_free_table_4
.Lssa___map_free_table_6:
    cmp x19, #16, lsl #12
    b.lo .Lssa___map_free_table_rcdeck33
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___map_free_table_rcdecd33
    tbnz w5, #31, .Lssa___map_free_table_rcdeck33
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___map_free_table_rcdece33
.Lssa___map_free_table_rcdecd33:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___map_free_table_rcdeck33:
    mov x0, x19
.Lssa___map_free_table_rcdece33:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_free_table_4:
    ldr x9, [x19, #0]
    cmp x9, #0
    b.eq .Lssa___map_free_table_1
.Lssa___map_free_table_3:
    ldrsw x10, [x9]
.Lssa___map_free_table_22:
    mov x11, #8
    mov x12, #2
    mul x12, x12, x11
    add x12, x12, #4
    mul x12, x10, x12
    add x12, x12, #24
    add x12, x12, x10
    add x12, x12, #8
    sxtw x12, w12
    mov x10, x12
    mov x1, x10
    mov x0, x9
    bl __fern_raw_free
    mov x0, #0
.Lssa___map_free_table_1:
    sub x10, x19, #8
    mov x9, #16
    mov x1, x9
    mov x0, x10
    bl __fern_raw_free
    mov x0, #0
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_key_of:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_key_of.k:
__fn___map_key_of.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_key_of_0:
    mov x0, x19
    bl __fn___map_lookup.r
    mov x9, #-1
    cmp x0, x9
    b.ne .Lssa___map_key_of_1
.Lssa___map_key_of_3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_key_of_1:
    ldr x9, [x19, #0]
    mov x10, #24
.Lssa___map_key_of_8:
    sxtw x10, w10
    add x10, x9, x10
    ldrsw x9, [x9]
    lsl x9, x9, #2
    sxtw x9, w9
    add x10, x10, x9
    mov x9, #8
    mov x11, #2
    mul x11, x11, x9
    mul x0, x0, x11
    sxtw x0, w0
    add x10, x10, x0
    ldr x0, [x10, #0]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_key_of_keyed:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_key_of_keyed.k:
__fn___map_key_of_keyed.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_key_of_keyed_0:
    mov x0, x19
    bl __fn___map_lookup_keyed.r
    mov x11, #-1
    cmp x0, x11
    b.ne .Lssa___map_key_of_keyed_1
.Lssa___map_key_of_keyed_3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_key_of_keyed_1:
    ldr x11, [x19, #0]
    mov x10, #24
.Lssa___map_key_of_keyed_8:
    sxtw x10, w10
    add x10, x11, x10
    ldrsw x11, [x11]
    lsl x11, x11, #2
    sxtw x11, w11
    add x10, x10, x11
    mov x11, #8
    mov x9, #2
    mul x9, x9, x11
    mul x0, x0, x9
    sxtw x0, w0
    add x10, x10, x0
    ldr x0, [x10, #0]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_drop_keyed_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_drop_keyed_impl.k:
__fn___map_drop_keyed_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___map_drop_keyed_impl_0:
    cmp x19, #0
    b.ne .Lssa___map_drop_keyed_impl_6
.Lssa___map_drop_keyed_impl_8:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_drop_keyed_impl_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___map_drop_keyed_impl_1
.Lssa___map_drop_keyed_impl_5:
    ldr x9, [x19, #0]
    add x10, x9, #4
    ldrsw x22, [x10]
    mov x23, #8
    mov x10, #24
.Lssa___map_drop_keyed_impl_17:
    sxtw x10, w10
    add x10, x9, x10
    ldrsw x9, [x9]
    lsl x9, x9, #2
    sxtw x9, w9
    add x24, x10, x9
.Lssa___map_drop_keyed_impl_4:
    mov x25, #0
.Lssa___map_drop_keyed_impl_19:
    cmp x25, x22
    b.ge .Lssa___map_drop_keyed_impl_1
.Lssa___map_drop_keyed_impl_20:
    mov x9, #2
    mul x9, x9, x23
    mul x9, x25, x9
    sxtw x9, w9
    add x26, x24, x9
    ldr x9, [x26, #0]
    mov x0, x20
    ldr x6, [x0, #8]
    blr x6
    sxtw x9, w23
    add x26, x26, x9
    ldr x9, [x26, #0]
    mov x0, x21
    ldr x6, [x0, #8]
    blr x6
    add x25, x25, #1
    cmp x25, x22
    b.lt .Lssa___map_drop_keyed_impl_20
.Lssa___map_drop_keyed_impl_1:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #64
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_drop_strcols_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___map_drop_strcols_impl.k:
__fn___map_drop_strcols_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    mov x19, x0
.Lssa___map_drop_strcols_impl_0:
    cmp x19, #0
    b.ne .Lssa___map_drop_strcols_impl_6
.Lssa___map_drop_strcols_impl_8:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_drop_strcols_impl_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___map_drop_strcols_impl_1
.Lssa___map_drop_strcols_impl_5:
    ldr x20, [x19, #0]
    add x9, x20, #8
    ldrsw x9, [x9]
    cmp x9, #1
    cset x21, eq
    add x9, x20, #12
    ldrsw x9, [x9]
    mov x10, #255
    and x9, x9, x10
.Lssa___map_drop_strcols_impl_17:
    cmp x9, #5
    cset x22, eq
    add x9, x20, #4
    ldrsw x23, [x9]
    mov x24, #8
    mov x9, #24
.Lssa___map_drop_strcols_impl_19:
    sxtw x9, w9
    add x9, x20, x9
    ldrsw x10, [x20]
    lsl x10, x10, #2
    sxtw x10, w10
    add x25, x9, x10
.Lssa___map_drop_strcols_impl_4:
    mov x26, #0
.Lssa___map_drop_strcols_impl_21:
    cmp x26, x23
    b.ge .Lssa___map_drop_strcols_impl_1
.Lssa___map_drop_strcols_impl_28:
    mov x10, #2
    mul x10, x10, x24
    mul x10, x26, x10
    sxtw x10, w10
    add x27, x25, x10
    cbz x21, .Lssa___map_drop_strcols_impl_26
.Lssa___map_drop_strcols_impl_27:
    ldr x10, [x27, #0]
    tbnz x10, #0, .Lssa___map_drop_strcols_impl_rcdeck121
    cmp x10, #16, lsl #12
    b.lo .Lssa___map_drop_strcols_impl_rcdeck121
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa___map_drop_strcols_impl_rcdecd121
    tbnz w5, #31, .Lssa___map_drop_strcols_impl_rcdeck121
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa___map_drop_strcols_impl_rcdece121
.Lssa___map_drop_strcols_impl_rcdecd121:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa___map_drop_strcols_impl_rcdeck121:
    mov x0, x10
.Lssa___map_drop_strcols_impl_rcdece121:
    b .Lssa___map_drop_strcols_impl_25
.Lssa___map_drop_strcols_impl_26:
    ldr x9, [x27, #0]
    mov x0, x20
    bl __fn___map_free_key_cell.r
.Lssa___map_drop_strcols_impl_25:
    cbz x22, .Lssa___map_drop_strcols_impl_23
.Lssa___map_drop_strcols_impl_24:
    sxtw x9, w24
    add x9, x27, x9
    ldr x10, [x9, #0]
    tbnz x10, #0, .Lssa___map_drop_strcols_impl_rcdeck128
    cmp x10, #16, lsl #12
    b.lo .Lssa___map_drop_strcols_impl_rcdeck128
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa___map_drop_strcols_impl_rcdecd128
    tbnz w5, #31, .Lssa___map_drop_strcols_impl_rcdeck128
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa___map_drop_strcols_impl_rcdece128
.Lssa___map_drop_strcols_impl_rcdecd128:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa___map_drop_strcols_impl_rcdeck128:
    mov x0, x10
.Lssa___map_drop_strcols_impl_rcdece128:
    b .Lssa___map_drop_strcols_impl_22
.Lssa___map_drop_strcols_impl_23:
    sxtw x10, w24
    add x27, x27, x10
    ldr x9, [x27, #0]
    mov x0, x20
    bl __fn___map_free_val_cell.r
.Lssa___map_drop_strcols_impl_22:
    add x26, x26, #1
    cmp x26, x23
    b.lt .Lssa___map_drop_strcols_impl_28
.Lssa___map_drop_strcols_impl_1:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_drop_boxes_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_drop_boxes_impl.k:
__fn___map_drop_boxes_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___map_drop_boxes_impl_0:
    cmp x19, #0
    b.ne .Lssa___map_drop_boxes_impl_6
.Lssa___map_drop_boxes_impl_8:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_drop_boxes_impl_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___map_drop_boxes_impl_1
.Lssa___map_drop_boxes_impl_5:
    ldr x21, [x19, #0]
    add x9, x21, #8
    ldrsw x9, [x9]
    cmp x9, #1
    cset x22, eq
    add x9, x21, #4
    ldrsw x23, [x9]
    mov x24, #8
    mov x9, #24
.Lssa___map_drop_boxes_impl_17:
    sxtw x9, w9
    add x9, x21, x9
    ldrsw x10, [x21]
    lsl x10, x10, #2
    sxtw x10, w10
    add x25, x9, x10
.Lssa___map_drop_boxes_impl_4:
    mov x26, #0
.Lssa___map_drop_boxes_impl_19:
    cmp x26, x23
    b.ge .Lssa___map_drop_boxes_impl_1
.Lssa___map_drop_boxes_impl_23:
    mov x10, #2
    mul x10, x10, x24
    mul x10, x26, x10
    sxtw x10, w10
    add x27, x25, x10
    cbz x22, .Lssa___map_drop_boxes_impl_21
.Lssa___map_drop_boxes_impl_22:
    ldr x10, [x27, #0]
    tbnz x10, #0, .Lssa___map_drop_boxes_impl_rcdeck99
    cmp x10, #16, lsl #12
    b.lo .Lssa___map_drop_boxes_impl_rcdeck99
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa___map_drop_boxes_impl_rcdecd99
    tbnz w5, #31, .Lssa___map_drop_boxes_impl_rcdeck99
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa___map_drop_boxes_impl_rcdece99
.Lssa___map_drop_boxes_impl_rcdecd99:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa___map_drop_boxes_impl_rcdeck99:
    mov x0, x10
.Lssa___map_drop_boxes_impl_rcdece99:
    b .Lssa___map_drop_boxes_impl_20
.Lssa___map_drop_boxes_impl_21:
    ldr x9, [x27, #0]
    mov x0, x21
    bl __fn___map_free_key_cell.r
.Lssa___map_drop_boxes_impl_20:
    sxtw x9, w24
    add x27, x27, x9
    ldr x9, [x27, #0]
    mov x0, x20
    ldr x6, [x0, #8]
    blr x6
    add x26, x26, #1
    cmp x26, x23
    b.lt .Lssa___map_drop_boxes_impl_23
.Lssa___map_drop_boxes_impl_1:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_free_table.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_delete_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_delete_impl.k:
__fn___map_delete_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___map_delete_impl_0:
    ldr x9, [x19, #0]
    add x9, x9, #8
    ldrsw x21, [x9]
    cmp x21, #0
    b.ne .Lssa___map_delete_impl_4
.Lssa___map_delete_impl_6:
    adrp x22, .K0
    add x22, x22, :lo12:.K0
    adrp x23, .K1
    add x23, x23, :lo12:.K1
    mov x0, x19
    mov x9, x20
    mov x10, x22
    mov x11, x23
    bl __fn___map_delete_keyed_impl.r
    mov x24, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa___map_delete_impl_rcdeck28
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa___map_delete_impl_rcdecd28
    tbnz w5, #31, .Lssa___map_delete_impl_rcdeck28
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa___map_delete_impl_rcdece28
.Lssa___map_delete_impl_rcdecd28:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa___map_delete_impl_rcdeck28:
    mov x0, x22
.Lssa___map_delete_impl_rcdece28:
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_delete_impl_rcdeck29
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___map_delete_impl_rcdecd29
    tbnz w5, #31, .Lssa___map_delete_impl_rcdeck29
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___map_delete_impl_rcdece29
.Lssa___map_delete_impl_rcdecd29:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___map_delete_impl_rcdeck29:
    mov x0, x23
.Lssa___map_delete_impl_rcdece29:
    mov x0, x24
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_delete_impl_4:
    cmp x21, #2
    b.ne .Lssa___map_delete_impl_1
.Lssa___map_delete_impl_3:
    adrp x21, .K2
    add x21, x21, :lo12:.K2
    adrp x24, .K3
    add x24, x24, :lo12:.K3
    mov x0, x19
    mov x9, x20
    mov x10, x21
    mov x11, x24
    bl __fn___map_delete_keyed_impl.r
    mov x23, x0
    cmp x21, #16, lsl #12
    b.lo .Lssa___map_delete_impl_rcdeck35
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa___map_delete_impl_rcdecd35
    tbnz w5, #31, .Lssa___map_delete_impl_rcdeck35
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa___map_delete_impl_rcdece35
.Lssa___map_delete_impl_rcdecd35:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa___map_delete_impl_rcdeck35:
    mov x0, x21
.Lssa___map_delete_impl_rcdece35:
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_delete_impl_rcdeck36
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_delete_impl_rcdecd36
    tbnz w5, #31, .Lssa___map_delete_impl_rcdeck36
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_delete_impl_rcdece36
.Lssa___map_delete_impl_rcdecd36:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_delete_impl_rcdeck36:
    mov x0, x24
.Lssa___map_delete_impl_rcdece36:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_delete_impl_1:
    adrp x23, .K4
    add x23, x23, :lo12:.K4
    adrp x24, .K5
    add x24, x24, :lo12:.K5
    mov x0, x19
    mov x9, x20
    mov x10, x23
    mov x11, x24
    bl __fn___map_delete_keyed_impl.r
    mov x21, x0
    cmp x23, #16, lsl #12
    b.lo .Lssa___map_delete_impl_rcdeck40
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___map_delete_impl_rcdecd40
    tbnz w5, #31, .Lssa___map_delete_impl_rcdeck40
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___map_delete_impl_rcdece40
.Lssa___map_delete_impl_rcdecd40:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___map_delete_impl_rcdeck40:
    mov x0, x23
.Lssa___map_delete_impl_rcdece40:
    cmp x24, #16, lsl #12
    b.lo .Lssa___map_delete_impl_rcdeck41
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa___map_delete_impl_rcdecd41
    tbnz w5, #31, .Lssa___map_delete_impl_rcdeck41
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa___map_delete_impl_rcdece41
.Lssa___map_delete_impl_rcdecd41:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa___map_delete_impl_rcdeck41:
    mov x0, x24
.Lssa___map_delete_impl_rcdece41:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_lookup_keyed:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_lookup_keyed.k:
__fn___map_lookup_keyed.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #48
    mov x19, x9
    mov x20, x10
    mov x21, x11
.Lssa___map_lookup_keyed_0:
    ldr x22, [x0, #0]
    ldrsw x4, [x22]
    str x4, [sp, #40]
    sub x24, x4, #1
    mov x9, #8
    mov x10, #2
    mul x25, x10, x9
    mov x10, #24
.Lssa___map_lookup_keyed_20:
    sxtw x10, w10
    add x10, x22, x10
    ldr x4, [sp, #40]
    lsl x9, x4, #2
    sxtw x9, w9
    add x26, x10, x9
    add x9, x22, #4
    ldrsw x27, [x9]
    cmp x27, #8
    b.gt .Lssa___map_lookup_keyed_14
.Lssa___map_lookup_keyed_19:
.Lssa___map_lookup_keyed_18:
    mov x28, #0
.Lssa___map_lookup_keyed_26:
    cmp x28, x27
    b.ge .Lssa___map_lookup_keyed_17
.Lssa___map_lookup_keyed_29:
    mul x9, x28, x25
    sxtw x9, w9
    add x9, x26, x9
    ldr x10, [x9, #0]
    mov x0, x21
    mov x9, x10
    mov x10, x19
    ldr x6, [x0, #8]
    blr x6
    cbnz x0, .Lssa___map_lookup_keyed_16
.Lssa___map_lookup_keyed_27:
    add x28, x28, #1
    cmp x28, x27
    b.lt .Lssa___map_lookup_keyed_29
.Lssa___map_lookup_keyed_17:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_16:
    mov x0, x28
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_14:
    add x10, x22, #16
    ldrsw x10, [x10]
.Lssa___map_lookup_keyed_40:
    mov x0, x19
    mov x9, x20
    bl __fn___map_bucket_hash.r
    mov x28, x0
    and x4, x28, x24
    str x4, [sp, #32]
    mov x10, #24
.Lssa___map_lookup_keyed_42:
    sxtw x10, w10
    add x10, x22, x10
    ldr x4, [sp, #32]
    lsl x9, x4, #2
    sxtw x9, w9
    add x10, x10, x9
    ldrsw x27, [x10]
    mov x10, #-1
    cmp x27, x10
    b.ne .Lssa___map_lookup_keyed_11
.Lssa___map_lookup_keyed_13:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_11:
    cmp x27, #0
    b.lt .Lssa___map_lookup_keyed_5
.Lssa___map_lookup_keyed_10:
    mul x10, x27, x25
    sxtw x10, w10
    add x10, x26, x10
    ldr x9, [x10, #0]
    mov x0, x21
    mov x10, x19
    ldr x6, [x0, #8]
    blr x6
    cbz x0, .Lssa___map_lookup_keyed_5
.Lssa___map_lookup_keyed_9:
    mov x0, x27
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_5:
    mov x9, #24
    sxtw x9, w9
    add x9, x22, x9
    mov x10, #8
    mov x11, #2
    mul x11, x11, x10
    add x11, x11, #4
    ldr x4, [sp, #40]
    mul x11, x4, x11
    sxtw x11, w11
    add x9, x9, x11
    mov x4, x9
    str x4, [sp, #24]
    ldr x4, =9259542123273814144
    str x4, [sp, #16]
    mov w28, w28
    lsr x28, x28, #25
    sxtw x28, w28
    ldr x9, =72340172838076673
    mul x4, x28, x9
    str x4, [sp, #8]
.Lssa___map_lookup_keyed_4:
    ldr x23, [sp, #32]
    mov x5, #0
    str x5, [sp, #32]
.Lssa___map_lookup_keyed_57:
    ldr x4, [sp, #32]
    ldr x5, [sp, #40]
    cmp x4, x5
    b.ge .Lssa___map_lookup_keyed_3
.Lssa___map_lookup_keyed_62:
    sxtw x9, w23
    ldr x4, [sp, #24]
    add x9, x4, x9
    ldr x28, [x9, #0]
    ldr x5, [sp, #8]
    eor x9, x28, x5
    ldr x11, =72340172838076673
    sub x11, x9, x11
    bic x11, x11, x9
    ldr x5, [sp, #16]
    and x11, x11, x5
.Lssa___map_lookup_keyed_61:
    mov x20, x11
.Lssa___map_lookup_keyed_67:
    cmp x20, #0
    b.eq .Lssa___map_lookup_keyed_60
.Lssa___map_lookup_keyed_70:
    rbit x11, x20
    clz x11, x11
    asr x11, x11, #3
    add x11, x23, x11
    and x11, x11, x24
    mov x9, #24
.Lssa___map_lookup_keyed_75:
    sxtw x9, w9
    add x9, x22, x9
    lsl x11, x11, #2
    sxtw x11, w11
    add x9, x9, x11
    ldrsw x27, [x9]
    mul x9, x27, x25
    sxtw x9, w9
    add x9, x26, x9
    ldr x11, [x9, #0]
    mov x0, x21
    mov x9, x11
    mov x10, x19
    ldr x6, [x0, #8]
    blr x6
    cbnz x0, .Lssa___map_lookup_keyed_2
.Lssa___map_lookup_keyed_68:
    sub x11, x20, #1
    and x20, x20, x11
    cmp x20, #0
    b.ne .Lssa___map_lookup_keyed_70
.Lssa___map_lookup_keyed_60:
    ldr x11, =-9187201950435737472
    eor x28, x28, x11
    ldr x11, =72340172838076673
    sub x11, x28, x11
    bic x11, x11, x28
    ldr x5, [sp, #16]
    and x11, x11, x5
    cmp x11, #0
    b.ne .Lssa___map_lookup_keyed_1
.Lssa___map_lookup_keyed_58:
    add x23, x23, #8
    and x23, x23, x24
    ldr x4, [sp, #32]
    add x11, x4, #8
    sxtw x4, w11
    str x4, [sp, #32]
    ldr x4, [sp, #32]
    ldr x5, [sp, #40]
    cmp x4, x5
    b.lt .Lssa___map_lookup_keyed_62
.Lssa___map_lookup_keyed_3:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_2:
    mov x0, x27
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_keyed_1:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_has_keyed_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_has_keyed_impl.k:
__fn___map_has_keyed_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___map_has_keyed_impl_0:
    bl __fn___map_lookup_keyed.r
    mov x11, #-1
    cmp x0, x11
    cset x0, ne
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_get_keyed_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_get_keyed_impl.k:
__fn___map_get_keyed_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
.Lssa___map_get_keyed_impl_0:
    mov x0, x19
    bl __fn___map_lookup_keyed.r
    mov x11, #-1
    cmp x0, x11
    b.ne .Lssa___map_get_keyed_impl_1
.Lssa___map_get_keyed_impl_3:
    adrp x11, .K6
    add x11, x11, :lo12:.K6
    mov x0, x11
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_get_keyed_impl_1:
    ldr x20, [x19, #0]
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    mov x9, x0
    mov x0, x20
    bl __fn___map_retain_val.r
    mov x19, x0
    mov x0, #2
    bl __fern_arr_box
    mov x9, #0
    str x9, [x0, #0]
    str x19, [x0, #8]
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_get_or_keyed_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___map_get_or_keyed_impl.k:
__fn___map_get_or_keyed_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa___map_get_or_keyed_impl_0:
    mov x0, x19
    mov x10, x11
    mov x11, x12
    bl __fn___map_lookup_keyed.r
    mov x12, #-1
    cmp x0, x12
    b.ne .Lssa___map_get_or_keyed_impl_1
.Lssa___map_get_or_keyed_impl_3:
    ldr x12, [x19, #0]
    mov x0, x12
    mov x9, x20
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_retain_val.r
    .cfi_restore_state
.Lssa___map_get_or_keyed_impl_1:
    ldr x20, [x19, #0]
    mov x9, x0
    mov x0, x19
    bl __fn___map_val_at.r
    mov x9, x0
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_retain_val.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_lookup_val_keyed:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_lookup_val_keyed.k:
__fn___map_lookup_val_keyed.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___map_lookup_val_keyed_0:
    mov x0, x19
    bl __fn___map_lookup_keyed.r
    mov x11, #-1
    cmp x0, x11
    b.ne .Lssa___map_lookup_val_keyed_1
.Lssa___map_lookup_val_keyed_3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_lookup_val_keyed_1:
    mov x9, x0
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    b __fn___map_val_at.r
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_grow_keyed:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_grow_keyed.k:
__fn___map_grow_keyed.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #80
    str x0, [sp, #72]
    str x9, [sp, #64]
.Lssa___map_grow_keyed_0:
    ldr x4, [sp, #72]
    ldr x4, [x4, #0]
    str x4, [sp, #56]
    add x9, x4, #16
    ldrsw x22, [x9]
.Lssa___map_grow_keyed_6:
    ldr x4, [sp, #56]
    ldrsw x4, [x4]
    str x4, [sp, #48]
    ldr x4, [sp, #56]
    add x9, x4, #4
    ldrsw x24, [x9]
    add x9, x4, #8
    ldrsw x4, [x9]
    str x4, [sp, #40]
    ldr x4, [sp, #56]
    add x9, x4, #12
    ldrsw x4, [x9]
    str x4, [sp, #32]
    mov x27, #24
    mov x28, #8
    mov x9, #2
    mul x4, x9, x28
    str x4, [sp, #24]
    ldr x4, [sp, #56]
    add x9, x4, #24
    ldr x4, [sp, #48]
    lsl x10, x4, #2
    sxtw x10, w10
    add x4, x9, x10
    str x4, [sp, #16]
    mov x10, #4
    ldr x4, [sp, #48]
    lsl x9, x4, #1
    sxtw x9, w9
    cmp x4, #0
    csel x25, x9, x10, ne
.Lssa___map_grow_keyed_3:
    sub x11, x25, #1
    sxtw x23, w11
    mov x11, #8
    mov x9, #2
    mul x9, x9, x11
    add x9, x9, #4
    mul x4, x25, x9
    str x4, [sp, #8]
    add x9, x27, x4
    add x9, x9, x25
    add x9, x9, #8
    sxtw x9, w9
    mov x11, x9
    mov x0, x11
    bl __fern_alloc
    mov x21, x0
    str w25, [x21]
    add x11, x21, #4
    str w24, [x11]
    add x9, x21, #8
    ldr x5, [sp, #40]
    str w5, [x9]
    add x11, x21, #12
    ldr x5, [sp, #32]
    str w5, [x11]
    add x9, x21, #16
    str w22, [x9]
    add x11, x21, #20
    ldr x4, [sp, #56]
    add x9, x4, #20
    ldrsw x9, [x9]
    str w9, [x11]
    sxtw x10, w27
    add x20, x21, x10
    lsl x10, x25, #2
    sxtw x19, w10
    mov x10, #255
    mov x2, x19
    mov x1, x10
    mov x0, x20
.Lssa___map_grow_keyed_ms150:
    cbz x2, .Lssa___map_grow_keyed_msd150
    strb w1, [x0], #1
    sub x2, x2, #1
    b .Lssa___map_grow_keyed_ms150
.Lssa___map_grow_keyed_msd150:
    mov x0, #0
    ldr x10, [sp, #8]
    sxtw x10, w10
    add x10, x20, x10
    mov x26, x10
    add x10, x25, #8
    sxtw x10, w10
    mov x9, #128
    mov x2, x10
    mov x1, x9
    mov x0, x26
.Lssa___map_grow_keyed_ms164:
    cbz x2, .Lssa___map_grow_keyed_msd164
    strb w1, [x0], #1
    sub x2, x2, #1
    b .Lssa___map_grow_keyed_ms164
.Lssa___map_grow_keyed_msd164:
    mov x0, #0
    add x20, x20, x19
.Lssa___map_grow_keyed_2:
    mov x19, #0
.Lssa___map_grow_keyed_13:
    cmp x19, x24
    b.ge .Lssa___map_grow_keyed_1
.Lssa___map_grow_keyed_17:
    ldr x5, [sp, #24]
    mul x9, x19, x5
    sxtw x9, w9
    ldr x4, [sp, #16]
    add x10, x4, x9
    ldr x0, [x10, #0]
    sxtw x11, w28
    add x10, x10, x11
    ldr x12, [x10, #0]
    add x9, x20, x9
    str x0, [x9, #0]
    add x9, x9, x11
    str x12, [x9, #0]
    ldr x9, [sp, #64]
    mov x10, x22
    bl __fn___map_bucket_hash.r
    and x10, x0, x23
.Lssa___map_grow_keyed_16:
.Lssa___map_grow_keyed_22:
.Lssa___map_grow_keyed_25:
    sxtw x11, w27
    add x11, x21, x11
    lsl x9, x10, #2
    sxtw x9, w9
    add x11, x11, x9
    ldrsw x11, [x11]
    mov x9, #-1
    cmp x11, x9
    b.eq .Lssa___map_grow_keyed_15
.Lssa___map_grow_keyed_23:
    add x11, x10, #1
    sxtw x11, w11
    and x10, x11, x23
    b .Lssa___map_grow_keyed_22
.Lssa___map_grow_keyed_15:
    sxtw x11, w27
    add x11, x21, x11
    lsl x9, x10, #2
    sxtw x9, w9
    add x11, x11, x9
    str w19, [x11]
    mov w0, w0
    lsr x0, x0, #25
    sxtw x11, w0
    mov x0, x26
    mov x9, x25
    bl __fn___map_ctrl_set.r
.Lssa___map_grow_keyed_14:
    add x19, x19, #1
    cmp x19, x24
    b.lt .Lssa___map_grow_keyed_17
.Lssa___map_grow_keyed_1:
    ldr x4, [sp, #72]
    str x21, [x4, #0]
    mov x11, #8
    mov x10, #2
    mul x10, x10, x11
    add x10, x10, #4
    ldr x4, [sp, #48]
    mul x10, x4, x10
    add x27, x27, x10
    add x27, x27, x4
    add x27, x27, #8
    sxtw x27, w27
    mov x10, x27
    mov x1, x10
    ldr x0, [sp, #56]
    bl __fern_raw_free
    mov x0, #0
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_put_keyed:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___map_put_keyed.k:
__fn___map_put_keyed.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #96
    mov x19, x0
    mov x20, x9
    str x10, [sp, #88]
    mov x22, x11
    mov x23, x12
.Lssa___map_put_keyed_0:
    ldr x24, [x19, #0]
    ldrsw x25, [x24]
    add x9, x24, #4
    ldrsw x26, [x9]
    add x9, x26, #1
    lsl x9, x9, #2
    sxtw x9, w9
    mov x10, #3
    mul x10, x25, x10
    sxtw x10, w10
    cmp x9, x10
    b.lt .Lssa___map_put_keyed_12
.Lssa___map_put_keyed_13:
    mov x0, x19
    mov x9, x22
    bl __fn___map_grow_keyed.r
    ldr x0, [x19, #0]
    ldrsw x9, [x0]
    add x10, x0, #4
    ldrsw x10, [x10]
    mov x24, x0
    str x9, [sp, #80]
    str x10, [sp, #72]
    b .Lssa___map_put_keyed_11
.Lssa___map_put_keyed_12:
    str x25, [sp, #80]
    str x26, [sp, #72]
.Lssa___map_put_keyed_11:
    ldr x4, [sp, #80]
    sub x10, x4, #1
    sxtw x19, w10
    mov x4, #8
    str x4, [sp, #64]
    mov x10, #2
    mul x28, x10, x4
    mov x10, #24
.Lssa___map_put_keyed_19:
    sxtw x10, w10
    add x10, x24, x10
    ldr x4, [sp, #80]
    lsl x9, x4, #2
    sxtw x9, w9
    add x21, x10, x9
    add x9, x24, #16
    ldrsw x10, [x9]
.Lssa___map_put_keyed_21:
    mov x0, x20
    mov x9, x22
    bl __fn___map_bucket_hash.r
    and x4, x0, x19
    str x4, [sp, #56]
    mov w0, w0
    lsr x0, x0, #25
    sxtw x4, w0
    str x4, [sp, #48]
    mov x10, #24
    sxtw x10, w10
    add x10, x24, x10
    mov x9, #8
    mov x11, #2
    mul x11, x11, x9
    add x11, x11, #4
    ldr x4, [sp, #80]
    mul x11, x4, x11
    sxtw x11, w11
    add x10, x10, x11
    mov x4, x10
    str x4, [sp, #40]
    mov x4, #-1
    str x4, [sp, #32]
    mov x10, #24
.Lssa___map_put_keyed_23:
    sxtw x10, w10
    add x10, x24, x10
    ldr x4, [sp, #56]
    lsl x11, x4, #2
    sxtw x11, w11
    add x10, x10, x11
    ldrsw x27, [x10]
    mov x10, #-1
    cmp x27, x10
    b.ne .Lssa___map_put_keyed_9
.Lssa___map_put_keyed_10:
    ldr x5, [sp, #56]
    str x5, [sp, #32]
    b .Lssa___map_put_keyed_4
.Lssa___map_put_keyed_9:
    cmp x27, #0
    b.lt .Lssa___map_put_keyed_5
.Lssa___map_put_keyed_8:
    mul x10, x27, x28
    sxtw x10, w10
    add x10, x21, x10
    ldr x11, [x10, #0]
    mov x0, x23
    mov x9, x11
    mov x10, x20
    ldr x6, [x0, #8]
    blr x6
    cbz x0, .Lssa___map_put_keyed_5
.Lssa___map_put_keyed_7:
    mul x27, x27, x28
    sxtw x27, w27
    add x27, x21, x27
    ldr x11, [sp, #64]
    sxtw x11, w11
    add x27, x27, x11
    ldr x22, [x27, #0]
    mov x0, x24
    mov x9, x22
    bl __fn___map_dec_value.r
    ldr x5, [sp, #88]
    str x5, [x27, #0]
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_put_keyed_5:
.Lssa___map_put_keyed_4:
    ldr x4, =9259542123273814144
    str x4, [sp, #24]
    ldr x11, [sp, #48]
    sxtw x11, w11
    ldr x10, =72340172838076673
    mul x4, x11, x10
    str x4, [sp, #16]
    mov x10, #-1
    ldr x4, [sp, #32]
    cmp x4, x10
    cset x10, ne
.Lssa___map_put_keyed_3:
    ldr x26, [sp, #56]
    str x10, [sp, #8]
    mov x5, #0
    str x5, [sp, #56]
.Lssa___map_put_keyed_38:
    ldr x4, [sp, #8]
    cbnz x4, .Lssa___map_put_keyed_2
.Lssa___map_put_keyed_51:
    ldr x4, [sp, #56]
    ldr x5, [sp, #80]
    cmp x4, x5
    b.ge .Lssa___map_put_keyed_2
.Lssa___map_put_keyed_50:
    sxtw x10, w26
    ldr x4, [sp, #40]
    add x10, x4, x10
    ldr x22, [x10, #0]
    ldr x5, [sp, #16]
    eor x10, x22, x5
    ldr x11, =72340172838076673
    sub x11, x10, x11
    bic x11, x11, x10
    ldr x5, [sp, #24]
    and x11, x11, x5
.Lssa___map_put_keyed_49:
    mov x27, x11
.Lssa___map_put_keyed_60:
    cmp x27, #0
    b.eq .Lssa___map_put_keyed_48
.Lssa___map_put_keyed_63:
    rbit x11, x27
    clz x11, x11
    asr x11, x11, #3
    add x11, x26, x11
    and x11, x11, x19
    mov x10, #24
.Lssa___map_put_keyed_68:
    sxtw x10, w10
    add x10, x24, x10
    lsl x11, x11, #2
    sxtw x11, w11
    add x10, x10, x11
    ldrsw x25, [x10]
    mul x10, x25, x28
    sxtw x10, w10
    add x10, x21, x10
    ldr x11, [x10, #0]
    mov x0, x23
    mov x9, x11
    mov x10, x20
    ldr x6, [x0, #8]
    blr x6
    cbnz x0, .Lssa___map_put_keyed_1
.Lssa___map_put_keyed_61:
    sub x11, x27, #1
    and x27, x27, x11
    cmp x27, #0
    b.ne .Lssa___map_put_keyed_63
.Lssa___map_put_keyed_48:
    ldr x11, =-9187201950435737472
    eor x11, x22, x11
    ldr x10, =72340172838076673
    sub x10, x11, x10
    bic x10, x10, x11
    ldr x5, [sp, #24]
    and x10, x10, x5
    mov x11, #-1
    ldr x4, [sp, #32]
    cmp x4, x11
    b.ne .Lssa___map_put_keyed_43
.Lssa___map_put_keyed_47:
    ldr x11, =-72340172838076674
    eor x22, x22, x11
    ldr x11, =72340172838076673
    sub x11, x22, x11
    bic x11, x11, x22
    ldr x5, [sp, #24]
    and x11, x11, x5
    orr x11, x10, x11
    cmp x11, #0
    b.eq .Lssa___map_put_keyed_45
.Lssa___map_put_keyed_46:
    rbit x11, x11
    clz x11, x11
    asr x11, x11, #3
    add x11, x26, x11
    sxtw x11, w11
    and x11, x11, x19
    str x11, [sp, #32]
    b .Lssa___map_put_keyed_44
.Lssa___map_put_keyed_45:
.Lssa___map_put_keyed_44:
    b .Lssa___map_put_keyed_42
.Lssa___map_put_keyed_43:
.Lssa___map_put_keyed_42:
    cmp x10, #0
    b.eq .Lssa___map_put_keyed_40
.Lssa___map_put_keyed_41:
    mov x5, #1
    str x5, [sp, #8]
    b .Lssa___map_put_keyed_39
.Lssa___map_put_keyed_40:
    add x26, x26, #8
    and x26, x26, x19
    ldr x4, [sp, #56]
    add x10, x4, #8
    sxtw x10, w10
    str x10, [sp, #56]
.Lssa___map_put_keyed_39:
    ldr x4, [sp, #8]
    cbz x4, .Lssa___map_put_keyed_51
.Lssa___map_put_keyed_2:
    ldr x4, [sp, #72]
    mul x10, x4, x28
    sxtw x10, w10
    add x10, x21, x10
    str x20, [x10, #0]
    ldr x11, [sp, #64]
    sxtw x11, w11
    add x10, x10, x11
    ldr x5, [sp, #88]
    str x5, [x10, #0]
    mov x11, #24
.Lssa___map_put_keyed_93:
    sxtw x11, w11
    add x11, x24, x11
    ldr x4, [sp, #32]
    lsl x10, x4, #2
    sxtw x10, w10
    add x11, x11, x10
    ldr x5, [sp, #72]
    str w5, [x11]
    ldr x0, [sp, #40]
    ldr x9, [sp, #80]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    bl __fn___map_ctrl_set.r
    add x10, x24, #4
    ldr x4, [sp, #72]
    add x11, x4, #1
    sxtw x11, w11
    str w11, [x10]
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_put_keyed_1:
    mul x25, x25, x28
    sxtw x25, w25
    add x21, x21, x25
    ldr x9, [sp, #64]
    sxtw x9, w9
    add x21, x21, x9
    ldr x25, [x21, #0]
    mov x0, x24
    mov x9, x25
    bl __fn___map_dec_value.r
    ldr x5, [sp, #88]
    str x5, [x21, #0]
    mov x0, x25
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_delete_keyed_impl:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn___map_delete_keyed_impl.k:
__fn___map_delete_keyed_impl.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #112
    str x9, [sp, #104]
    str x10, [sp, #96]
    mov x21, x11
.Lssa___map_delete_keyed_impl_0:
    ldr x22, [x0, #0]
    add x9, x22, #16
    ldrsw x4, [x9]
    str x4, [sp, #88]
.Lssa___map_delete_keyed_impl_20:
    ldrsw x4, [x22]
    str x4, [sp, #80]
    add x9, x22, #4
    ldrsw x4, [x9]
    str x4, [sp, #72]
    ldr x4, [sp, #80]
    sub x9, x4, #1
    sxtw x26, w9
    mov x4, #8
    str x4, [sp, #64]
    mov x9, #2
    mul x4, x9, x4
    str x4, [sp, #56]
    mov x9, #24
.Lssa___map_delete_keyed_impl_22:
    sxtw x9, w9
    add x25, x22, x9
    ldr x4, [sp, #80]
    lsl x9, x4, #2
    sxtw x9, w9
    add x4, x25, x9
    str x4, [sp, #48]
    ldr x0, [sp, #104]
    ldr x9, [sp, #96]
    ldr x10, [sp, #88]
    bl __fn___map_bucket_hash.r
    str x0, [sp, #40]
    ldr x4, [sp, #40]
    and x4, x4, x26
    str x4, [sp, #32]
    mov x9, #8
    mov x10, #2
    mul x10, x10, x9
    add x10, x10, #4
    ldr x4, [sp, #80]
    mul x10, x4, x10
    sxtw x10, w10
    add x25, x25, x10
    mov x4, x25
    str x4, [sp, #24]
    mov x4, #-1
    str x4, [sp, #16]
    mov x10, #24
.Lssa___map_delete_keyed_impl_24:
    sxtw x10, w10
    add x10, x22, x10
    ldr x4, [sp, #32]
    lsl x9, x4, #2
    sxtw x9, w9
    add x10, x10, x9
    ldrsw x25, [x10]
    mov x10, #-1
    cmp x25, x10
    b.ne .Lssa___map_delete_keyed_impl_17
.Lssa___map_delete_keyed_impl_19:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_delete_keyed_impl_17:
    cmp x25, #0
    b.lt .Lssa___map_delete_keyed_impl_12
.Lssa___map_delete_keyed_impl_16:
    ldr x5, [sp, #56]
    mul x10, x25, x5
    sxtw x10, w10
    ldr x4, [sp, #48]
    add x10, x4, x10
    ldr x9, [x10, #0]
    mov x0, x21
    ldr x10, [sp, #104]
    ldr x6, [x0, #8]
    blr x6
    cbz x0, .Lssa___map_delete_keyed_impl_14
.Lssa___map_delete_keyed_impl_15:
    ldr x10, [sp, #32]
    mov x9, #1
    b .Lssa___map_delete_keyed_impl_13
.Lssa___map_delete_keyed_impl_14:
    ldr x10, [sp, #16]
    mov x25, #0
    mov x9, #0
.Lssa___map_delete_keyed_impl_13:
    str x10, [sp, #16]
    str x25, [sp, #8]
    b .Lssa___map_delete_keyed_impl_11
.Lssa___map_delete_keyed_impl_12:
    mov x5, #0
    str x5, [sp, #8]
    mov x9, #0
.Lssa___map_delete_keyed_impl_11:
    ldr x4, =9259542123273814144
    str x4, [sp, #0]
    ldr x10, [sp, #40]
    mov w10, w10
    lsr x10, x10, #25
    sxtw x10, w10
    ldr x11, =72340172838076673
    mul x4, x10, x11
    str x4, [sp, #40]
.Lssa___map_delete_keyed_impl_10:
    ldr x23, [sp, #32]
    ldr x24, [sp, #16]
    mov x5, #0
    str x5, [sp, #32]
.Lssa___map_delete_keyed_impl_40:
    cbnz x9, .Lssa___map_delete_keyed_impl_9
.Lssa___map_delete_keyed_impl_50:
    ldr x4, [sp, #32]
    ldr x5, [sp, #80]
    cmp x4, x5
    b.ge .Lssa___map_delete_keyed_impl_9
.Lssa___map_delete_keyed_impl_49:
    sxtw x11, w23
    ldr x4, [sp, #24]
    add x11, x4, x11
    ldr x4, [x11, #0]
    str x4, [sp, #16]
    ldr x5, [sp, #40]
    eor x11, x4, x5
    ldr x10, =72340172838076673
    sub x10, x11, x10
    bic x10, x10, x11
    ldr x5, [sp, #0]
    and x10, x10, x5
.Lssa___map_delete_keyed_impl_48:
    ldr x27, [sp, #8]
    mov x25, x9
    mov x28, x10
.Lssa___map_delete_keyed_impl_59:
    cmp x28, #0
    b.eq .Lssa___map_delete_keyed_impl_47
.Lssa___map_delete_keyed_impl_63:
    rbit x10, x28
    clz x10, x10
    asr x10, x10, #3
    add x10, x23, x10
    sxtw x10, w10
    and x20, x10, x26
    mov x10, #24
.Lssa___map_delete_keyed_impl_68:
    sxtw x10, w10
    add x10, x22, x10
    lsl x9, x20, #2
    sxtw x9, w9
    add x10, x10, x9
    ldrsw x19, [x10]
    ldr x5, [sp, #56]
    mul x10, x19, x5
    sxtw x10, w10
    ldr x4, [sp, #48]
    add x10, x4, x10
    ldr x9, [x10, #0]
    mov x0, x21
    ldr x10, [sp, #104]
    ldr x6, [x0, #8]
    blr x6
    cbz x0, .Lssa___map_delete_keyed_impl_61
.Lssa___map_delete_keyed_impl_62:
    mov x24, x20
    mov x27, x19
    mov x25, #1
    mov x28, #0
    b .Lssa___map_delete_keyed_impl_60
.Lssa___map_delete_keyed_impl_61:
    sub x9, x28, #1
    and x28, x28, x9
.Lssa___map_delete_keyed_impl_60:
    cmp x28, #0
    b.ne .Lssa___map_delete_keyed_impl_63
.Lssa___map_delete_keyed_impl_47:
    cbz x25, .Lssa___map_delete_keyed_impl_45
.Lssa___map_delete_keyed_impl_46:
    mov x9, x25
    b .Lssa___map_delete_keyed_impl_41
.Lssa___map_delete_keyed_impl_45:
    ldr x9, =-9187201950435737472
    ldr x4, [sp, #16]
    eor x9, x4, x9
    ldr x10, =72340172838076673
    sub x10, x9, x10
    bic x10, x10, x9
    ldr x5, [sp, #0]
    and x10, x10, x5
    cmp x10, #0
    b.eq .Lssa___map_delete_keyed_impl_43
.Lssa___map_delete_keyed_impl_44:
    ldr x10, [sp, #32]
    mov x25, #1
    b .Lssa___map_delete_keyed_impl_42
.Lssa___map_delete_keyed_impl_43:
    add x23, x23, #8
    and x23, x23, x26
    ldr x4, [sp, #32]
    add x10, x4, #8
    sxtw x10, w10
.Lssa___map_delete_keyed_impl_42:
    mov x9, x25
    str x10, [sp, #32]
.Lssa___map_delete_keyed_impl_41:
    str x27, [sp, #8]
    cbz x9, .Lssa___map_delete_keyed_impl_50
.Lssa___map_delete_keyed_impl_9:
    mov x9, #-1
    cmp x24, x9
    b.ne .Lssa___map_delete_keyed_impl_6
.Lssa___map_delete_keyed_impl_8:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___map_delete_keyed_impl_6:
    ldr x4, [sp, #8]
    ldr x5, [sp, #56]
    mul x9, x4, x5
    sxtw x9, w9
    ldr x4, [sp, #48]
    add x23, x4, x9
    ldr x9, [sp, #64]
    sxtw x9, w9
    add x9, x23, x9
    ldr x10, [x9, #0]
    mov x0, x22
    mov x9, x10
    bl __fn___map_free_val_cell.r
    ldr x9, [x23, #0]
    mov x0, x22
    bl __fn___map_free_key_cell.r
    mov x9, #24
.Lssa___map_delete_keyed_impl_93:
    sxtw x9, w9
    add x9, x22, x9
    lsl x10, x24, #2
    sxtw x10, w10
    add x9, x9, x10
    mov x10, #-2
    str w10, [x9]
    mov x11, #254
    ldr x0, [sp, #24]
    ldr x9, [sp, #80]
    mov x10, x24
    bl __fn___map_ctrl_set.r
    ldr x4, [sp, #72]
    sub x11, x4, #1
    sxtw x24, w11
    ldr x4, [sp, #8]
    cmp x4, x24
    b.eq .Lssa___map_delete_keyed_impl_1
.Lssa___map_delete_keyed_impl_5:
    ldr x5, [sp, #56]
    mul x11, x24, x5
    sxtw x11, w11
    ldr x4, [sp, #48]
    add x11, x4, x11
    ldr x23, [x11, #0]
    mov x0, x23
    ldr x9, [sp, #96]
    ldr x10, [sp, #88]
    bl __fn___map_bucket_hash.r
    and x0, x0, x26
.Lssa___map_delete_keyed_impl_4:
.Lssa___map_delete_keyed_impl_99:
    mov x11, #24
.Lssa___map_delete_keyed_impl_101:
    sxtw x11, w11
    add x11, x22, x11
    lsl x10, x0, #2
    sxtw x10, w10
    add x11, x11, x10
    ldrsw x11, [x11]
    cmp x11, x24
    b.eq .Lssa___map_delete_keyed_impl_3
.Lssa___map_delete_keyed_impl_100:
    add x11, x0, #1
    and x0, x11, x26
    b .Lssa___map_delete_keyed_impl_99
.Lssa___map_delete_keyed_impl_3:
    ldr x5, [sp, #56]
    mul x11, x24, x5
    sxtw x11, w11
    ldr x4, [sp, #48]
    add x11, x4, x11
    ldr x10, [sp, #64]
    sxtw x10, w10
    add x11, x11, x10
    ldr x9, [x11, #0]
    ldr x4, [sp, #8]
    ldr x5, [sp, #56]
    mul x11, x4, x5
    sxtw x11, w11
    ldr x4, [sp, #48]
    add x11, x4, x11
    str x23, [x11, #0]
    add x11, x11, x10
    str x9, [x11, #0]
    mov x10, #24
.Lssa___map_delete_keyed_impl_109:
    sxtw x10, w10
    add x10, x22, x10
    lsl x0, x0, #2
    sxtw x0, w0
    add x10, x10, x0
    ldr x5, [sp, #8]
    str w5, [x10]
.Lssa___map_delete_keyed_impl_1:
    add x22, x22, #4
    str w24, [x22]
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_main:
    .cfi_startproc
__fn_main.k:
__fn_main.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
.Lssa_main_0:
    mov x0, #8
    mov x9, #0
    mov x10, #0
    bl __fn_map_new_impl.r
.Lssa_main_4:
    mov x19, x0
    mov x20, #0
.Lssa_main_5:
    cmp x20, #4000
    b.ge .Lssa_main_3
.Lssa_main_6:
    mov x10, #7
    mul x21, x20, x10
    mov x0, x19
    bl __fn___map_cow_inplace.r
    mov x22, x0
    cmp x22, x19
    b.eq .Lssa_main_13
.Lssa_main_11:
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck58
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd58
    tbnz w5, #31, .Lssa_main_rcdeck58
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece58
.Lssa_main_rcdecd58:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck58:
    mov x0, x19
.Lssa_main_rcdece58:
.Lssa_main_13:
    sxtw x9, w21
    sxtw x10, w20
    mov x0, x22
    bl __fn___map_put_impl.r
    add x20, x20, #1
    mov x19, x22
    cmp x20, #4000
    b.lt .Lssa_main_6
.Lssa_main_3:
.Lssa_main_2:
    mov x20, #0
    mov x22, #0
.Lssa_main_16:
    cmp x22, #40
    b.lt .Lssa_main_19
.Lssa_main_21:
    mov x0, x19
    bl __fn___map_drop_impl.r
    b .Lssa_main_1
.Lssa_main_19:
.Lssa_main_18:
    mov x21, #0
.Lssa_main_24:
    cmp x21, #4000
    b.ge .Lssa_main_17
.Lssa_main_25:
    mov x10, #7
    mul x10, x21, x10
    sxtw x9, w10
    mov x10, #0
    mov x0, x19
    bl __fn___map_get_or_impl.r
    sxtw x0, w0
    add x20, x20, x0
    add x21, x21, #1
    cmp x21, #4000
    b.lt .Lssa_main_25
.Lssa_main_17:
    add x22, x22, #1
    cmp x22, #40
    b.ge .Lssa_main_21
    b .Lssa_main_19
.Lssa_main_1:
    mov x10, #97
    mov x4, x20
    mov x5, x10
    sdiv x6, x4, x5
    msub x4, x6, x5, x4
    mov x9, x4
    sxtw x0, w9
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_hash_scalar$wrap:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_hash_scalar$wrap.k:
__fn___map_hash_scalar$wrap.r:
.Lssa___map_hash_scalar$wrap_0:
    mov x10, #61
    eor x9, x9, x10
    mov w10, w9
    lsr x10, x10, #16
    eor x9, x9, x10
    lsl x10, x9, #3
    add x9, x9, x10
    mov w10, w9
    lsr x10, x10, #4
    eor x9, x9, x10
    ldr x10, =668265261
    mul x9, x9, x10
    sxtw x9, w9
    mov w10, w9
    lsr x10, x10, #15
    sxtw x10, w10
    eor x0, x9, x10
    ret
    .cfi_endproc
    .ltorg
__fn___map_eq_scalar$wrap:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_eq_scalar$wrap.k:
__fn___map_eq_scalar$wrap.r:
.Lssa___map_eq_scalar$wrap_0:
    cmp x9, x10
    cset x0, eq
    ret
    .cfi_endproc
    .ltorg
__fn___map_hash_wide$wrap:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_hash_wide$wrap.k:
__fn___map_hash_wide$wrap.r:
.Lssa___map_hash_wide$wrap_0:
    mov x0, x9
    b __fn___map_hash_wide.r
    .cfi_endproc
    .ltorg
__fn___map_eq_wide$wrap:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_eq_wide$wrap.k:
__fn___map_eq_wide$wrap.r:
.Lssa___map_eq_wide$wrap_0:
    ldr x11, [x9, #0]
    ldr x9, [x10, #0]
    cmp x11, x9
    cset x0, eq
.Lssa___map_eq_wide$wrap_1:
    ret
    .cfi_endproc
    .ltorg
__fn___map_hash_str$wrap:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_hash_str$wrap.k:
__fn___map_hash_str$wrap.r:
.Lssa___map_hash_str$wrap_0:
    mov x0, x9
    b __fn___map_hash_str.r
    .cfi_endproc
    .ltorg
__fn___map_eq_str$wrap:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___map_eq_str$wrap.k:
__fn___map_eq_str$wrap.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___map_eq_str$wrap_0:
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa___map_eq_str$wrap_streqn9
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa___map_eq_str$wrap_streqd9
.Lssa___map_eq_str$wrap_streqn9:
    mov x0, #0
.Lssa___map_eq_str$wrap_streqd9:
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
_start:
    adrp x9, .Lfern_relanchor
    add x9, x9, :lo12:.Lfern_relanchor
    ldr x10, [x9]
    sub x9, x9, x10
    cbz x9, .Lfern_reloc_done
    adrp x11, .Lfern_sbox_begin
    add x11, x11, :lo12:.Lfern_sbox_begin
    adrp x12, .Lfern_sbox_end
    add x12, x12, :lo12:.Lfern_sbox_end
.Lfern_sbox_loop:
    cmp x11, x12
    b.hs .Lfern_sbox_done
    ldr x13, [x11, #8]
    add x13, x13, x9
    str x13, [x11, #8]
    add x11, x11, #24
    b .Lfern_sbox_loop
.Lfern_sbox_done:
    adrp x11, .Lfern_cagg_begin
    add x11, x11, :lo12:.Lfern_cagg_begin
    adrp x12, .Lfern_cagg_end
    add x12, x12, :lo12:.Lfern_cagg_end
.Lfern_cagg_loop:
    cmp x11, x12
    b.hs .Lfern_cagg_done
    ldr x13, [x11, #16]
    add x13, x13, x9
    str x13, [x11, #16]
    ldr x14, [x11]
    add x11, x11, #16
    add x11, x11, x14, lsl #3
    b .Lfern_cagg_loop
.Lfern_cagg_done:
    adrp x11, .Lfern_cfn_begin
    add x11, x11, :lo12:.Lfern_cfn_begin
    adrp x12, .Lfern_cfn_end
    add x12, x12, :lo12:.Lfern_cfn_end
.Lfern_cfn_loop:
    cmp x11, x12
    b.hs .Lfern_cfn_done
    ldr x13, [x11, #24]
    add x13, x13, x9
    str x13, [x11, #24]
    add x11, x11, #32
    b .Lfern_cfn_loop
.Lfern_cfn_done:
    adrp x11, .Lfern_cref_begin
    add x11, x11, :lo12:.Lfern_cref_begin
    adrp x12, .Lfern_cref_end
    add x12, x12, :lo12:.Lfern_cref_end
.Lfern_cref_loop:
    cmp x11, x12
    b.hs .Lfern_reloc_done
    ldr x13, [x11]
    add x13, x13, x9
    ldr x14, [x13]
    add x14, x14, x9
    str x14, [x13]
    add x11, x11, #8
    b .Lfern_cref_loop
.Lfern_reloc_done:
    ldr x0, [sp]
    lsl x0, x0, #3
    add x0, x0, #16
    add x0, sp, x0
    adrp x1, __fern_envp
    add x1, x1, :lo12:__fern_envp
    str x0, [x1]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #30
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_stack_kept
    mov x19, x0
    mov x1, #1
    lsl x1, x1, #20
    mov x2, #0
    mov x8, #226
    svc #0
    mov x9, #1
    lsl x9, x9, #30
    add x9, x19, x9
    sub sp, x9, #16
.Lfern_stack_kept:
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #16
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_segv_skip
    mov x9, #1
    lsl x9, x9, #16
    sub sp, sp, #32
    stp x0, xzr, [sp]
    str x9, [sp, #16]
    mov x0, sp
    mov x1, #0
    mov x8, #132
    svc #0
    adrp x9, __fern_segv
    add x9, x9, :lo12:__fern_segv
    mov x10, #4
    movk x10, #0x800, lsl #16
    mov x11, #0
    stp x9, x10, [sp]
    stp x11, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    add sp, sp, #32
.Lfern_segv_skip:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    bl __fn_main
    mov x8, #94
    svc #0
    .section .bss
    .align 8
__fern_scratch: .skip 256
    .section .text
__fn___fern_str_eq:
    ldr x0, [sp]
    ldr x9, [sp, #16]
__fn___fern_str_eq.r:
    cmp x0, x9
    b.eq .Lseq_yes
    ldr x4, [x0, #8]
    ldr x5, [x9, #8]
    cmp x4, x5
    b.ne .Lseq_no
    ldr x2, [x0]
    ldr x3, [x9]
    cmp x2, x3
    b.eq .Lseq_yes
    add x6, x2, x4
    add x7, x3, x4
    cmp x4, #8
    b.lo .Lseq_short
    sub x6, x6, #8
    sub x7, x7, #8
.Lseq_word:
    ldr x0, [x2]
    ldr x1, [x3]
    cmp x0, x1
    b.ne .Lseq_no
    add x2, x2, #8
    add x3, x3, #8
    cmp x2, x6
    b.lo .Lseq_word
    ldr x0, [x6]
    ldr x1, [x7]
    cmp x0, x1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_short:
    cbz x4, .Lseq_yes
    cmp x4, #4
    b.lo .Lseq_byte
    ldr w0, [x2]
    ldr w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #4
    sub x7, x7, #4
    ldr w0, [x6]
    ldr w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_byte:
    ldrb w0, [x2]
    ldrb w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #1
    sub x7, x7, #1
    ldrb w0, [x6]
    ldrb w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    cmp x4, #3
    b.lo .Lseq_yes
    ldrb w0, [x2, #1]
    ldrb w1, [x3, #1]
    cmp w0, w1
    b.ne .Lseq_no
.Lseq_yes:
    mov x0, #1
    ret
.Lseq_no:
    mov x0, #0
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .bss
    .align 3
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 3
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 3
__fern_heap_base: .quad 0
    .align 3
__fern_rc_underflow: .quad 0
    .align 3
__fern_map_seed: .quad 0
    .align 3
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 3
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 3
__fern_freelist_shadow: .skip 524288
    .align 3
__fern_large_freelist_shadow: .skip 20480
    .text
.globl __fern_capw
__fern_capw:
    stp x9, x10, [sp, #-32]!
    str x11, [sp, #16]
    ldr x9, [sp, #32]
    cmp x9, #256
    b.ls .Lcapw_ret
    clz x10, x9
    mov x11, #61
    sub x10, x11, x10
    mov x11, #1
    lsl x11, x11, x10
    add x9, x9, x11
    sub x9, x9, #1
    neg x11, x11
    and x9, x9, x11
    mov x10, #0x10000
    cmp x9, x10
    b.lo .Lcapw_store
    mov x9, #65535
.Lcapw_store:
    str x9, [sp, #32]
.Lcapw_ret:
    ldr x11, [sp, #16]
    ldp x9, x10, [sp], #32
    ret
.globl __fern_alloc
.type __fern_alloc, %function
__fern_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    add x0, x0, #7
    lsr x3, x0, #3
    lsl x0, x3, #3
    mov x2, #0x10000
    cmp x3, x2
    b.hs .Lalloc_large
    cmp x3, #256
    b.ls .L0
    str x3, [sp, #-16]!
    bl __fern_capw
    ldr x3, [sp], #16
.L0:
    lsl x0, x3, #3
    adrp x1, __fern_freelist
    add x1, x1, :lo12:__fern_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_large:
    mov x1, #1
    lsl x1, x1, #30
    cmp x0, x1
    b.hi .Lalloc_nofl
    mov x1, #1
    lsl x1, x1, #19
    cmp x0, x1
    csel x0, x1, x0, lo
    clz x1, x0
    mov x3, #61
    sub x3, x3, x1
    mov x1, #1
    lsl x1, x1, x3
    sub x1, x1, #1
    add x0, x0, x1
    bic x0, x0, x1
    clz x1, x0
    mov x3, #61
    sub x1, x3, x1
    lsr x3, x0, x1
    add x3, x3, x1, lsl #2
    sub x3, x3, #72
    adrp x1, __fern_large_freelist
    add x1, x1, :lo12:__fern_large_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_nofl:
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    ldr x2, [x1]
    cbnz x2, .Lalloc_inited
    stp x4, x5, [sp, #-16]!
    stp x8, x9, [sp, #-16]!
    mov x9, x0
    mov x0, #1
    lsl x0, x0, #28
    mov x1, #1
    lsl x1, x1, #34
    mov x2, #3
    mov x3, #0x4022
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    cmn x0, #0
    b.mi .Lalloc_map_fail
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    str x0, [x1]
    adrp x1, __fern_heap_base
    add x1, x1, :lo12:__fern_heap_base
    str x0, [x1]
    mov x2, #1
    lsl x2, x2, #34
    add x2, x0, x2
    adrp x3, __fern_heap_end
    add x3, x3, :lo12:__fern_heap_end
    str x2, [x3]
    mov x0, x9
    ldp x8, x9, [sp], #16
    ldp x4, x5, [sp], #16
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
.Lalloc_inited:
    ldr x2, [x1]
    add x3, x2, x0
    str x4, [sp, #-16]!
    adrp x4, __fern_heap_end
    add x4, x4, :lo12:__fern_heap_end
    ldr x4, [x4]
    cmp x3, x4
    ldr x4, [sp], #16
    b.hi .Lalloc_oom
    str x3, [x1]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .text
.Lalloc_oom:
    adrp x1, .Lmsg_oom
    add x1, x1, :lo12:.Lmsg_oom
    mov x2, #43
    mov x0, #125
    b __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .text
.Lalloc_map_fail:
    neg x9, x0
    sub sp, sp, #96
    add x10, sp, #96
    mov x12, #10
    sub x10, x10, #1
    strb w12, [x10]
    mov x11, #41
    sub x10, x10, #1
    strb w11, [x10]
.Lmap_fail_digit:
    udiv x13, x9, x12
    msub x14, x13, x12, x9
    add x14, x14, #48
    sub x10, x10, #1
    strb w14, [x10]
    mov x9, x13
    cbnz x9, .Lmap_fail_digit
    adrp x15, .Lmsg_map_fail
    add x15, x15, :lo12:.Lmsg_map_fail
    add x15, x15, #42
    mov x11, #42
.Lmap_fail_copy:
    sub x15, x15, #1
    ldrb w14, [x15]
    sub x10, x10, #1
    strb w14, [x10]
    subs x11, x11, #1
    b.ne .Lmap_fail_copy
    mov x1, x10
    add x2, sp, #96
    sub x2, x2, x10
    mov x0, #123
    b __fern_report
.size __fern_alloc, .-__fern_alloc
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .text
.globl __fern_oob_abort
.type __fern_oob_abort, %function
__fern_oob_abort:
    adrp x1, .Lmsg_arr_oob
    add x1, x1, :lo12:.Lmsg_arr_oob
    mov x2, #31
    mov x0, #134
    b __fern_report
.size __fern_oob_abort, .-__fern_oob_abort
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .text
.globl __fern_str_oob_abort
.type __fern_str_oob_abort, %function
__fern_str_oob_abort:
    adrp x1, .Lmsg_str_oob
    add x1, x1, :lo12:.Lmsg_str_oob
    mov x2, #32
    mov x0, #134
    b __fern_report
.size __fern_str_oob_abort, .-__fern_str_oob_abort
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .text
.globl __fern_slice_abort
.type __fern_slice_abort, %function
__fern_slice_abort:
    adrp x1, .Lmsg_slice
    add x1, x1, :lo12:.Lmsg_slice
    mov x2, #32
    mov x0, #134
    b __fern_report
.size __fern_slice_abort, .-__fern_slice_abort
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .text
.globl __fern_alloc_size_abort
.type __fern_alloc_size_abort, %function
__fern_alloc_size_abort:
    adrp x1, .Lmsg_alloc_size
    add x1, x1, :lo12:.Lmsg_alloc_size
    mov x2, #35
    mov x0, #134
    b __fern_report
.size __fern_alloc_size_abort, .-__fern_alloc_size_abort
__fern_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    b __fern_oob_abort
__fern_str_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    b __fern_str_oob_abort
__fern_slice_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    b __fern_slice_abort
__fern_alloc_size_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    b __fern_alloc_size_abort
__fern_arr_box:
    add x1, x0, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Larrbox_alloc
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    add x1, x2, x1
    ldr x2, [x1]
    cbz x2, .Larrbox_miss
    ldr x3, [x2]
    str x3, [x1]
    str x0, [x2]
    mov w3, #1
    str w3, [x2, #8]
    str x0, [x2, #16]
    add x0, x2, #16
    ret
.Larrbox_miss:
    add x1, x0, #3
    lsl x1, x1, #3
.Larrbox_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    mov x0, x1
    bl __fern_alloc
    ldr x1, [sp]
    str x1, [x0]
    mov w2, #1
    str w2, [x0, #8]
    str x1, [x0, #16]
    add x0, x0, #16
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
__fern_str_box:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x0, #24
    bl __fern_alloc
    mov x2, #1
    str x2, [x0]
    ldp x2, x3, [sp], #16
    str x2, [x0, #8]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fern_str_box_hdr:
    sub x2, x0, #24
    mov w3, #1
    str w3, [x2]
    mov w4, #32781
    movk w4, #29519, lsl #16
    stur w4, [x2, #4]
    str x0, [x2, #8]
    str x1, [x2, #16]
    add x0, x2, #8
    ret
__fn___alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    bl __fern_alloc
    ldp x29, x30, [sp], #16
    ret
__fn___free:
    ret
__fn___memset:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    ldr x2, [x29, #48]
    cbz x2, .Lfnmemset_done
.Lfnmemset_loop:
    strb w1, [x0], #1
    subs x2, x2, #1
    bne .Lfnmemset_loop
.Lfnmemset_done:
    ldp x29, x30, [sp], #16
    ret
__fn___load_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldrsw x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str w1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_i64:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str x1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___ptr_width:
    mov x0, #8
    ret
__fn___fern_rc_inc:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcinc_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcinc_ret
    and x0, x0, #0xfffffffffffffffd
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcinc_ret
    add w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcinc_ret:
    ldr x0, [sp]
    ret
__fn___fern_rc_dec:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcdec_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcdec_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcdec_ret
    cmp w1, #0
    bgt .Lshrcdec_dec
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w11, [x10]
    add w11, w11, #1
    str w11, [x10]
.Lshrcdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcdec_ret:
    ret
__fn___fern_rc_is_unique:
    ldr x2, [sp]
    mov x0, #0
    tbnz x2, #0, .Lshuniq_ret
    mov x9, #0x10000
    cmp x2, x9
    blo .Lshuniq_ret
    and x2, x2, #0xfffffffffffffffd
    ldur w3, [x2, #-8]
    tbnz w3, #31, .Lshuniq_ret
    cmp w3, #1
    bne .Lshuniq_ret
    mov x0, #1
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    ldr x0, [sp]
__fn___fern_arr_inc_elems.r:
    mov x9, #0x10000
    cmp x0, x9
    blo .Laie_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Laie_ret
    stp x19, x30, [sp, #-16]!
    stp x20, x21, [sp, #-16]!
    mov x19, x0
    ldr x20, [x19]
    mov x21, #0
.Laie_loop:
    cmp x21, x20
    bge .Laie_done
    add x9, x21, #1
    ldr x0, [x19, x9, lsl #3]
    str x0, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    add x21, x21, #1
    b .Laie_loop
.Laie_done:
    mov x0, x19
    ldp x20, x21, [sp], #16
    ldp x19, x30, [sp], #16
.Laie_ret:
    ret
__fn___fern_alloc_reuse:
    ldr x0, [sp, #16]
    cbz x0, .Lsarelo_fresh
    ldr x1, [sp]
    ldur x2, [x0, #-16]
    cmp x2, x1
    beq .Lsarelo_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_arr_dec.r
    ldp x29, x30, [sp], #16
.Lsarelo_fresh:
    ldr x0, [sp]
    b __fern_arr_box
.Lsarelo_ret:
    ret
__fn___fern_rc_underflow_count:
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w0, [x10]
    ret
__fern_large_push:
    mov x3, #1
    lsl x3, x3, #30
    cmp x2, x3
    b.hi .Llpush_ret
    mov x3, #1
    lsl x3, x3, #19
    cmp x2, x3
    csel x2, x3, x2, lo
    clz x3, x2
    mov x4, #61
    sub x4, x4, x3
    mov x3, #1
    lsl x3, x3, x4
    sub x3, x3, #1
    add x2, x2, x3
    bic x2, x2, x3
    clz x3, x2
    mov x4, #61
    sub x3, x4, x3
    lsr x4, x2, x3
    add x4, x4, x3, lsl #2
    sub x4, x4, #72
    mov x2, x4
    adrp x3, __fern_large_freelist
    add x3, x3, :lo12:__fern_large_freelist
    ldr x4, [x3, x2, lsl #3]
    str x4, [x1]
    str x1, [x3, x2, lsl #3]
.Llpush_ret:
    ret
__fern_raw_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    cbz x0, .Lrawfree_done
    add x1, x1, #7
    lsr x5, x1, #3
    cbz x5, .Lrawfree_done
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lrawfree_b_large
    cmp x5, #256
    b.ls .L1
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x5, x30, [sp], #16
.L1:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x5, lsl #3]
    str x10, [x0]
    str x0, [x3, x5, lsl #3]
    b .Lrawfree_b_done
.Lrawfree_b_large:
    mov x1, x0
    lsl x2, x5, #3
    bl __fern_large_push
.Lrawfree_b_done:
.Lrawfree_done:
    ldp x29, x30, [sp], #16
    ret
__fn___fern_arr_dec:
    ldr x0, [sp]
__fn___fern_arr_dec.r:
    cmp x0, #16, lsl #12
    blo .Larrdec_ret
__fn___fern_arr_dec.u:
    ldur w1, [x0, #-8]
    cmp w1, #1
    bne .Larrdec_shared
    stur wzr, [x0, #-8]
    ldur x1, [x0, #-16]
    add x1, x1, #3
    sub x2, x0, #16
    cmp x1, #256
    b.hi .Larrdec_big
.Larrdec_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Larrdec_ret:
    ret
.Larrdec_shared:
    tbnz w1, #31, .Larrdec_ret
    bgt .Larrdec_dec
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    ret
.Larrdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
    ret
.Larrdec_big:
    mov x9, #0x10000
    cmp x1, x9
    bhs .Larrdec_large
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
    b .Larrdec_push
.Larrdec_large:
    lsl x2, x1, #3
    sub x1, x0, #16
    b __fern_large_push
__fn___fern_str_free:
    ldr x0, [sp]
__fn___fern_str_free.r:
    tbnz x0, #0, .Lstrfree_ret
    cmp x0, #16, lsl #12
    blo .Lstrfree_ret
__fn___fern_str_free.u:
    mov x9, #0x10000
    ldur w4, [x0, #-8]
    cmp w4, #1
    bne .Lstrfree_shared
    ldur w2, [x0, #-4]
    mov w3, #32781
    movk w3, #29519, lsl #16
    cmp w2, w3
    beq .Lstrfree_fused
    mov w3, #0x4F57
    movk w3, #0x4752, lsl #16
    cmp w2, w3
    beq .Lstrfree_grown
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    cmp w2, w3
    beq .Lstrfree_box
    ldr x1, [x0]
    ldr x2, [x0, #8]
    cmp x1, x9
    blo .Lstrfree_box
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrfree_box
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrfree_box
    cmp x2, #0
    ble .Lstrfree_box
    add x2, x2, #7
    lsr x2, x2, #3
    cmp x2, x9
    bhs .Lstrfree_box
    cmp x2, #256
    b.ls .L2
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
.L2:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
.Lstrfree_box:
    stur wzr, [x0, #-8]
    sub x1, x0, #8
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
    b .Lstrfree_ret
.Lstrfree_grown:
    ldur x2, [x0, #-16]
    stur wzr, [x0, #-8]
    sub x1, x0, #16
    b .Lstrfree_block
.Lstrfree_fused:
    ldr x2, [x0, #8]
    add x2, x2, #7
    lsr x2, x2, #3
    add x2, x2, #3
    stur wzr, [x0, #-8]
    sub x1, x0, #8
.Lstrfree_block:
    cmp x2, #256
    b.hi .Lstrfree_fused_big
.Lstrfree_fused_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
    b .Lstrfree_ret
.Lstrfree_fused_big:
    cmp x2, x9
    bhs .Lstrfree_fused_large
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
    b .Lstrfree_fused_push
.Lstrfree_fused_large:
    lsl x2, x2, #3
    b __fern_large_push
.Lstrfree_shared:
    tbnz w4, #31, .Lstrfree_ret
    blt .Lstrfree_uf
    sub w4, w4, #1
    stur w4, [x0, #-8]
    ret
.Lstrfree_uf:
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    ldr x0, [sp]
    tbnz x0, #0, .Lstrvfree_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lstrvfree_ret
    ldur w4, [x0, #-8]
    tbnz w4, #31, .Lstrvfree_view
    b __fn___fern_str_free
.Lstrvfree_view:
    sub x1, x0, #8
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrvfree_ret
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrvfree_ret
    stur wzr, [x0, #-8]
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_arr_free.k:
__fn___fern_str_arr_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_arr_free_0:
    movz x9, #1, lsl #16
    cmp x19, x9
    b.lo .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    ldrsw x20, [x19]
.Lssa___fern_str_arr_free_4:
    mov x9, #0
.Lssa___fern_str_arr_free_15:
    cmp x9, x20
    b.ge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    add x21, x9, #1
    ldr x9, [x19, x21, lsl #3]
    tbnz x9, #0, .Lssa___fern_str_arr_free_rcdeck36
    cmp x9, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck36
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd36
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck36
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___fern_str_arr_free_rcdece36
.Lssa___fern_str_arr_free_rcdecd36:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___fern_str_arr_free_rcdeck36:
    mov x0, x9
.Lssa___fern_str_arr_free_rcdece36:
    mov x9, x21
    cmp x9, x20
    b.lt .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    cmp x19, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck40
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd40
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck40
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___fern_str_arr_free_rcdece40
.Lssa___fern_str_arr_free_rcdecd40:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___fern_str_arr_free_rcdeck40:
    mov x0, x19
.Lssa___fern_str_arr_free_rcdece40:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_drop_arr_ptr:
    ret
    .section .bss
    .align 8
__fern_envp: .quad 0
    .section .text
    .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_u8:
    .quad 0
    .text
.globl __fern_alloc_u8
.type __fern_alloc_u8, %function
__fern_alloc_u8:
    tbz w0, #31, .Lfern_alloc_u8_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_u8_sized:
    cbz w0, .Lfern_alloc_u8_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x0, x19
    bl __fern_arr_box
    add x2, x0, #8
    mov w1, w19
.Lfern_alloc_u8_zero:
    cbz x1, .Lfern_alloc_u8_done
    str xzr, [x2], #8
    sub x1, x1, #1
    b .Lfern_alloc_u8_zero
.Lfern_alloc_u8_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_u8_empty:
    adrp x0, .Lfern_empty_u8
    add x0, x0, :lo12:.Lfern_empty_u8
    ret
.size __fern_alloc_u8, .-__fern_alloc_u8
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
    .text
__fern_segv:
    ldr x9, [x1, #16]
    ldr x10, [x2, #432]
    sub x9, x9, x10
    mov x10, #1
    lsl x10, x10, #20
    add x9, x9, x10
    lsl x10, x10, #1
    cmp x9, x10
    b.hs .Lfern_segv_other
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    adrp x1, .Lmsg_stack_overflow
    add x1, x1, :lo12:.Lmsg_stack_overflow
    mov x2, #21
    mov x0, #134
    b __fern_report
.Lfern_segv_other:
    stp x29, x30, [sp, #-16]!
    sub sp, sp, #32
    stp xzr, xzr, [sp]
    stp xzr, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    add sp, sp, #32
    ldp x29, x30, [sp], #16
    ret
    .text
.globl __fern_report
.type __fern_report, %function
__fern_report:
    mov x19, x0
    mov x0, #2
    mov x8, #64
    svc #0
    b __fern_bt_exit
.size __fern_report, .-__fern_report
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .text
    .globl __fern_bt_exit
__fern_bt_exit:
    adrp x1, .Lmsg_bt
    add x1, x1, :lo12:.Lmsg_bt
    mov x2, #11
    mov x0, #2
    mov x8, #64
    svc #0
    mov x20, x29
    mov x21, #64
    mov x22, sp
.Lbt_loop:
    cbz x21, .Lbt_done
    cmp x20, x22
    b.lo .Lbt_done
    and x23, x20, #7
    cbnz x23, .Lbt_done
    ldr x1, [x20, #8]
    cmp x1, #16, lsl #12
    b.lo .Lbt_done
    bl .Lbt_hex
    mov x22, x20
    ldr x20, [x20]
    sub x21, x21, #1
    b .Lbt_loop
.Lbt_done:
    mov x0, x19
    mov x8, #94
    svc #0
.Lbt_hex:
    sub sp, sp, #32
    mov w2, #32
    strb w2, [sp]
    strb w2, [sp, #1]
    mov w2, #48
    strb w2, [sp, #2]
    mov w2, #120
    strb w2, [sp, #3]
    mov w2, #10
    strb w2, [sp, #20]
    mov x3, #16
    add x4, sp, #19
.Lbt_hloop:
    and x2, x1, #15
    cmp x2, #10
    b.lo .Lbt_hdec
    add x2, x2, #87
    b .Lbt_hput
.Lbt_hdec:
    add x2, x2, #48
.Lbt_hput:
    strb w2, [x4]
    sub x4, x4, #1
    lsr x1, x1, #4
    subs x3, x3, #1
    b.ne .Lbt_hloop
    mov x0, #2
    mov x1, sp
    mov x2, #21
    mov x8, #64
    svc #0
    add sp, sp, #32
    ret
__fern_arr_push:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Larr_push_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_slow_ok
    tbz w3, #31, .Larr_push_slow
.Larr_push_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Larr_push_slow:
    ldr x2, [x0]
    cbnz x2, .Larr_push_frame
    ldur x2, [x0, #-16]
    cbnz x2, .Larr_push_frame
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    ldr x3, [x2, #56]
    cbz x3, .Larr_push_fresh
    ldr x4, [x3]
    str x4, [x2, #56]
    mov x2, #4
    str x2, [x3]
    mov w2, #1
    str w2, [x3, #8]
    mov x2, #1
    str x2, [x3, #16]
    str x1, [x3, #24]
    add x0, x3, #16
    ret
.Larr_push_fresh:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x1, [sp, #-16]!
    mov x0, #4
    bl __fern_arr_box
    ldr x1, [sp], #16
    mov x2, #1
    str x2, [x0]
    str x1, [x0, #8]
    ldp x29, x30, [sp], #16
    ret
.Larr_push_frame:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_rc_ok
    tbnz w2, #31, .Larr_push_rc_ok
    b .Larr_push_grow
.Larr_push_rc_ok:
    cmp x21, x22
    b.ge .Larr_push_grow
    add x1, x21, #1
    str x20, [x19, x1, lsl #3]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_ret
.Larr_push_grow:
    mov x2, x22
    cmp x21, x22
    b.lt .Larr_push_shared_cliff
    cmp x22, #0
    b.ne .Larr_push_dbl
    mov x2, #4
    b .Larr_push_cap
.Larr_push_shared_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21, lsl #3
    str x4, [x3]
    b .Larr_push_cap
.Larr_push_dbl:
    lsl x2, x22, #1
.Larr_push_cap:
    mov x22, x2
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Larr_push_copy4:
    cmp x4, #4
    b.lt .Larr_push_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Larr_push_copy4
.Larr_push_copy1:
    cbz x4, .Larr_push_copy_done
.Larr_push_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Larr_push_copy1_loop
.Larr_push_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
.Larr_push_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lapo_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapo_slow_ok
    tbz w3, #31, .Lapo_slow
.Lapo_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Lapo_slow:
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.eq .Lapo_own
    b .Larr_push_slow
.Lapo_own:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    lsl x8, x22, #1
    cbnz x8, .Lapo_cap
    mov x8, #4
.Lapo_cap:
    add x1, x8, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Lapo_alloc
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    add x1, x3, x1
    ldr x3, [x1]
    cbz x3, .Lapo_miss
    ldr x4, [x3]
    str x4, [x1]
.Lapo_box:
    str x8, [x3]
    mov w4, #1
    str w4, [x3, #8]
    add x0, x3, #16
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Lapo_copy4:
    cmp x4, #4
    b.lt .Lapo_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Lapo_copy4
.Lapo_copy1:
    cbz x4, .Lapo_copy_done
.Lapo_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Lapo_copy1_loop
.Lapo_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
    add x1, x22, #3
    mov x9, #0x10000
    cmp x1, x9
    b.hs .Lapo_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L3
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L3:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapo_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapo_miss:
    add x1, x8, #3
    lsl x1, x1, #3
.Lapo_alloc:
    mov x0, x1
    bl __fern_alloc
    mov x3, x0
    b .Lapo_box
.Lapo_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapo_ret
    .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .text
__fern_alloc_bytes:
    tbz w0, #31, .Lfern_alloc_bytes_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_bytes_sized:
    cbz w0, .Lfern_alloc_bytes_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    sxtw x19, w0
    add x0, x19, #7
    lsr x0, x0, #3
    mov x20, x0
    bl __fern_arr_box
    str x19, [x0]
    add x2, x0, #8
.Lfern_alloc_bytes_zero:
    cbz x20, .Lfern_alloc_bytes_done
    str xzr, [x2], #8
    sub x20, x20, #1
    b .Lfern_alloc_bytes_zero
.Lfern_alloc_bytes_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_bytes_empty:
    adrp x0, .Lfern_empty_bytes
    add x0, x0, :lo12:.Lfern_empty_bytes
    ret
__fn___fern_random_i32:
    .cfi_startproc
__fn___fern_random_i32.k:
__fn___fern_random_i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa___fern_random_i32_0:
    mov x9, #4
    adrp x19, __fern_scratch
    add x19, x19, :lo12:__fern_scratch
    mov x9, #278
    mov x10, #4
    mov x11, #0
    str x9, [sp, #-16]!
    str x19, [sp, #-16]!
    str x10, [sp, #-16]!
    str x11, [sp, #-16]!
    ldr x2, [sp], #16
    ldr x1, [sp], #16
    ldr x0, [sp], #16
    ldr x8, [sp], #16
    svc #0
    ldrsw x0, [x19]
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.globl __fern_map_hash_seed
.type __fern_map_hash_seed, %function
__fern_map_hash_seed:
    adrp x1, __fern_map_seed
    add x1, x1, :lo12:__fern_map_seed
    ldr w0, [x1]
    cbnz w0, .Lmapseed_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_random_i32
    orr w0, w0, #1
    adrp x1, __fern_map_seed
    add x1, x1, :lo12:__fern_map_seed
    str w0, [x1]
    ldp x29, x30, [sp], #16
.Lmapseed_ret:
    ret
.size __fern_map_hash_seed, .-__fern_map_hash_seed
    .section .data
    .align 8
.Lfern_relanchor:
    .quad .Lfern_relanchor
    .align 8
.Lfern_sbox_begin:
    .section .data
.Lfern_sbox_end:
    .section .data
    .align 8
    .quad 2
    .quad -1
.K6:
    .quad 1
    .quad 0
    .quad 0
    .quad -1
.K7:
    .quad 0
    .align 8
.Lfern_cagg_begin:
    .section .data
    .align 8
    .section .data
.Lfern_cagg_end:
    .align 8
.Lfern_cfn_begin:
    .section .data
    .align 8
    .quad 2
    .quad -1
.K0:
    .quad 1
    .quad __fn___map_hash_scalar$wrap.k
    .quad 2
    .quad -1
.K1:
    .quad 1
    .quad __fn___map_eq_scalar$wrap.k
    .quad 2
    .quad -1
.K2:
    .quad 1
    .quad __fn___map_hash_wide$wrap.k
    .quad 2
    .quad -1
.K3:
    .quad 1
    .quad __fn___map_eq_wide$wrap.k
    .quad 2
    .quad -1
.K4:
    .quad 1
    .quad __fn___map_hash_str$wrap.k
    .quad 2
    .quad -1
.K5:
    .quad 1
    .quad __fn___map_eq_str$wrap.k
    .section .data
.Lfern_cfn_end:
    .align 8
.Lfern_cref_begin:
.Lfern_cref_end:
    .text
