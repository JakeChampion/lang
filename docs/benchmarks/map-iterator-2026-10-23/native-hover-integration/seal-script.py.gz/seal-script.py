from pathlib import Path
import subprocess,json,hashlib,gzip,collections,io,tarfile,sys
family,root_arg,measured,previous_boot_arg,base=sys.argv[1:]
root=Path(root_arg);scope=Path('/workspace/scratch')/family/'native-hover-integration';oldboot=Path(previous_boot_arg)
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
current=git('rev-parse','HEAD').decode().strip();boot=json.loads((scope/'bootstrap/bootstrap.json').read_text());before=json.loads(oldboot.read_text());assert boot['fixedpoint']
assert [x['sha256']for x in boot['stages']]==[x['sha256']for x in before['stages']]
files=[];digest=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();digest.update(n.encode()+b'\0'+data+b'\0');files.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert digest.hexdigest()==boot['source_sha256']
changed=git('diff','--name-only',measured,'HEAD','--','compiler','internal/stdlib').decode().splitlines()
assert changed==['internal/stdlib/std/i32.fern'],changed
n=changed[0];old=git('show',measured+':'+n);now=(root/n).read_bytes();line=b'// The decimal text of `n`, with a leading `-` when it is negative.\n';assert now.count(line)==1 and now.replace(line,b'')==old
assert not git('diff',measured,'HEAD','--','conformance','internal/testing')
go=[]
for n in git('diff','--name-only',measured,'HEAD','--','*.go').decode().splitlines():
 old=git('show',measured+':'+n);now=(root/n).read_bytes();formatted=subprocess.check_output(['/home/agent/.local/share/mise/installs/go/1.27.3/bin/gofmt'],input=old);assert formatted==now,n;go.append(n)
assert go==([] if family!='lang-map-iterator' else ['internal/check/checker/checker.go','internal/oracle/treeshake/treeshake.go']),go
stamp={'lang-defer-capture-cells':'capture-after-last-write-2026-10-24','lang-validate-os-text':'os-text-2026-10-23','lang-map-iterator':'map-iterator-2026-10-23'}[family]
dest=root/'docs/benchmarks'/stamp/'native-hover-integration';dest.mkdir();rows=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);rows.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def take(n,folder=scope):save(n.replace('/','-')+'.gz',gzip.compress((folder/n).read_bytes(),mtime=0))
bridge={'packaged_source':current,'bootstrap_source':boot['source_git'],'measured_source':measured,'previous_bootstrap_source':before['source_git'],'source_sha256':digest.hexdigest(),'source_files':len(files),'native_images_sha256':[s['sha256']for s in boot['stages']],'all_three_compiler_images_identical':True,'only_library_change':'Restore the i32.to_string doc comment; all other compiler and library bytes are unchanged.','go_changes_equal_standard_gofmt':go,'all_test_and_conformance_files_unchanged':True,'dependency_base':base}
save('source-identity.json',json.dumps(bridge,indent=2).encode()+b'\n');save('source-files.json',json.dumps(files,indent=2).encode()+b'\n')
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log']:take(n)
save('seal-script.py.gz',gzip.compress(Path(__file__).read_bytes(),mtime=0))
patch=git('diff','--binary',base,'HEAD');subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
if family=='lang-map-iterator':
 out=scope.parent/'comment-data-integration'
 for name,count,skips,pkgs in [('targeted-tests',98,0,2),('go-regressions',2563,3,5)]:
  es=[json.loads(s)for s in(out/(name+'.jsonl')).read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);assert c['run']==count and c['skip']==skips and not c['fail'];assert len([e for e in es if e['Action']=='pass'and'Test'not in e])==pkgs
 matrix=json.loads((out/'matrix-helper.json').read_text());assert matrix['complete']and len(matrix['runs'])==88 and matrix['source_commit']==measured
 cs=[r['census']for r in matrix['runs']if'census'in r];assert len(cs)==24 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
 profile=json.loads((out/'loop-profile/report.json').read_text());assert profile['complete']and len(profile['runs'])==18;cs=[r['census']for r in profile['runs']if'census'in r];assert len(cs)==9 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi']:
  for variant,want in [('baseline',[60000]),('candidate',[60000]),('protocol',[60000,420000])]:assert next(r for r in profile['runs']if r['name']==variant+'-run-'+target)['allocations']==want
 assert matrix['producer_sha256']==profile['compilers']['candidate']==boot['stages'][2]['sha256']
 assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text();assert not(out/'vet.log').read_bytes();assert not(out/'format.log').read_bytes();assert not(out/'gofmt-final.log').read_bytes()
 assert 'vcs.revision='+measured in(out/'oracle-version.txt').read_text()and'vcs.modified=false'in(out/'oracle-version.txt').read_text()
 for n in ['targeted-tests.jsonl','go-regressions.jsonl','matrix-helper.json','matrix-helper.py','matrix.log','loop-profile.py','loop-profile/report.json','loop-profile.log','driver-builds.json','driver-sizes.txt','driver-gate.log','check-sizes.py','vet.log','oracle-version.txt','format.log','format.json','gofmt-final.log']:take(n,out)
 stream=io.BytesIO();logs=[]
 with tarfile.open(fileobj=stream,mode='w:gz')as t:
  for folder in ['matrix-helper','loop-profile']:
   for p in sorted((out/folder).iterdir()):
    if p.suffix not in ['.stdout','.stderr','.fern']:continue
    data=p.read_bytes();info=tarfile.TarInfo(folder+'/'+p.name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data));logs.append(p)
 assert len(logs)==214;save('execution-logs.tar.gz',stream.getvalue())
 save('measurements.json',json.dumps({'source_commit':measured,'focused_cases':98,'focused_skips':0,'go_cases':2563,'go_skips':3,'go_packages':5,'matrix_commands':88,'matrix_balanced_executions':24,'profile_commands':18,'profile_balanced_executions':9,'strict_size_gates':11},indent=2).encode()+b'\n')
(dest/'artifacts.json').write_text(json.dumps({'source_identity':bridge,'artifacts':rows},indent=2)+'\n')
(dest/'README.md').write_text('''# Integration of the native hover repair

The source identity record gives the measured and final source commits.
The only library change restores the `i32.to_string` doc comment.
All other compiler and library bytes remain unchanged.
Test and conformance files remain unchanged.
The record change passed all 18 native playground and 18 browser shim cases.

A fresh bootstrap from the released stage0 pin reproduces all three compiler images.
Stages 2 and 3 match byte for byte.
The archive retains each bootstrap log and all compiler hashes.
Earlier test and benchmark results retain their original source scopes.
'''+('''
The two Go source changes equal the output of the standard Go formatter.
All 98 focused cases pass without failures or skips.
All 2560 applicable Go cases pass across five packages. Three synthetic-AST cases skip.
The matrix passes 88 commands with 24 balanced runtime allocation checks.
All 18 profile commands pass with nine balanced runtime allocation checks.

Direct loops retain 60000 allocations for 10000 loops on each execution target.
The public snapshot protocol uses 420000 allocations for those loops.
All 11 strict driver size gates pass without baseline changes.
The archive retains all 214 execution output logs and inputs.
'''if family=='lang-map-iterator'else''))
print('Sealed',family,current,len(rows),'artifacts')
