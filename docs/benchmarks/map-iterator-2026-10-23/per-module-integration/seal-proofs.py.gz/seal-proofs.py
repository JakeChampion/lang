from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile,io,collections
root=Path('/workspace/lang-map-iterator-publish');out=Path('/workspace/scratch/lang-map-iterator/per-module-integration');core='44e75d1104c7dd416e9e30667fc21f4012117d7e';base='efb97bf382454c88255d26c40e95cbf6d822b981';oracle_scope='85018cd7080613844ba1acabcca8ae9ff7f7f129';dest=root/'docs/benchmarks/map-iterator-2026-10-23/per-module-integration'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==core and boot['fixedpoint']and len({r['sha256']for r in boot['stages']})==1;native=boot['stages'][-1]['sha256'];assert hashlib.sha256((out/'bootstrap/stage3').read_bytes()).hexdigest()==native
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256'];es=[json.loads(l)for l in(out/'integration-tests.jsonl').read_text().splitlines()if l.startswith('{')];c=collections.Counter(e['Action']for e in es);ps=[e for e in es if'Test'not in e and e['Action']in ['pass','fail']];assert c['run']==431 and not c['skip']and not c['fail']and len(ps)==2 and all(e['Action']=='pass'for e in ps)
assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text()
for n in ['format.log','gofmt.log','vet.log']:assert not(out/n).read_bytes()
m=json.loads((out/'matrix-helper.json').read_text());b=json.loads((out/'byte-matrix.json').read_text());p=json.loads((out/'loop-profile/report.json').read_text());assert m['complete']and len(m['runs'])==88 and m['source_commit']==core and m['compiler_source_commit']==core and m['producer_sha256']==native;assert b['complete']and len(b['runs'])==38 and b['source_commit']==core and b['compiler_sha256']==native;assert p['complete']and len(p['runs'])==18 and p['candidate_compiler_source_commit']==core and p['compilers']['candidate']==native and p['baseline_compiler_source_commit']=='14395d0eeb43d7df0894a594c3b3b534725a48ac'
for rows,want in [(m['runs'],24),(b['runs'],9),(p['runs'],9)]:
 cs=[r['census']for r in rows if'census'in r];assert len(cs)==want and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
for r in p['runs']:
 if'allocations'in r:assert r['allocations']==([60000,420000]if r['name'].startswith('protocol')else[60000])
# The Go oracle and the earlier Go suite retain their recorded source scope.
old=Path('/workspace/scratch/lang-map-iterator/os-byte-integration');assert m['oracle_sha256']==b['oracle_sha256']==hashlib.sha256((old/'oracle').read_bytes()).hexdigest();assert 'vcs.revision='+oracle_scope in(old/'oracle-version.txt').read_text()
changes=git('diff','--name-only',oracle_scope,core,'--','*.go').decode().splitlines();assert len(changes)==4 and all(n.startswith('internal/testing/e2ecompiler/')and n.endswith('_test.go')for n in changes);identity=dict(oracle_source=oracle_scope,current_source=core,production_go_unchanged=True,changed_go_files=changes);(out/'go-oracle-scope.json').write_text(json.dumps(identity,indent=2)+'\n')
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 pp=dest/n;pp.parent.mkdir(parents=True,exist_ok=True);pp.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks');subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','integration-tests.jsonl','test-command.json','driver-builds.json','driver-sizes.txt','driver-gate.log','sizes.log','check-sizes.py','format.log','gofmt.log','vet.log','matrix-helper.json','matrix-helper.py','matrix.log','os-byte-matrix.py','os-byte-matrix.log','byte-matrix.json','loop-profile.py','loop-profile/report.json','loop-profile.log','go-oracle-scope.json','seal-proofs.py']:take(n)
stream=io.BytesIO();logs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['matrix-helper','byte-matrix','loop-profile']:
  for pp in sorted((out/folder).glob('*')):
   if pp.suffix not in ['.stdout','.stderr','.fern']:continue
   data=pp.read_bytes();name=folder+'/'+pp.name;item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(data));logs.append(name)
save('output-logs-and-inputs.tar.gz',stream.getvalue());manifest=dict(source_commit=core,dependency_base=base,native_sha256=native,source_sha256=h.hexdigest(),go_oracle_source=oracle_scope,prior_go_suite=dict(source=oracle_scope,cases_passed=2561,synthetic_ast_skips=3,packages=5),integration_cases_passed=431,integration_skips=0,map_commands=88,os_commands=38,profile_commands=18,balanced_censuses=42,source_files=len(files),logs_and_inputs=len(logs),patch_excludes=['docs/benchmarks'],artifacts=artifacts);(dest/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(dict(artifacts=len(artifacts),source_files=len(files),logs=len(logs),native=native)))
