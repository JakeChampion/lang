from pathlib import Path
import collections, gzip, hashlib, io, json, subprocess, tarfile

root = Path('/workspace/lang-map-iterator-publish')
out = Path('/workspace/scratch/lang-map-iterator/path-helper-integration')
core = 'fc81935c68d878b7577f2479c627b1b72548c793'
base = '8b923f809c901f95d7a8ddbdc0b85b204c86156b'
dest = root / 'docs/benchmarks/map-iterator-2026-10-23/path-helper-integration'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == core
boot = json.loads((out / 'bootstrap/bootstrap.json').read_text())
assert boot['fixedpoint'] and boot['source_git'] == '19551ede188ee36a55578b4c59eddf1778c39a69'
assert boot['stages'][1]['sha256'] == boot['stages'][2]['sha256']
tests = []
for name, count in [('targeted-tests', 98)]:
    events = [json.loads(s) for s in (out / (name + '.jsonl')).read_text().splitlines() if s.startswith('{')]
    c = collections.Counter(e['Action'] for e in events)
    assert c['run'] == count and not c['fail'] and not c['skip'] and events[-1]['Action'] == 'pass', c
    tests.append({'suite': name, 'cases': count})
matrix = json.loads((out / 'matrix-helper.json').read_text())
assert matrix['complete'] and len(matrix['runs']) == 88
assert matrix['producer_sha256'] == boot['stages'][2]['sha256']
censuses = [r['census'] for r in matrix['runs'] if 'census' in r]
assert len(censuses) == 24 and all(c['allocs'] == c['frees'] and c['live_bytes'] == 0 for c in censuses)
profile = json.loads((out / 'loop-profile/report.json').read_text())
assert profile['complete'] and len(profile['runs']) == 18
assert profile['compilers']['candidate'] == boot['stages'][2]['sha256']
assert all(r['exit'] == r['expected_exit'] for r in matrix['runs'])
pcs = [r['census'] for r in profile['runs'] if 'census' in r]
assert len(pcs) == 9 and all(c['allocs'] == c['frees'] and c['live_bytes'] == 0 for c in pcs)
for target in ['x86-64-linux', 'arm64-linux', 'wasm32-wasi']:
    before = next(r for r in profile['runs'] if r['name'] == 'baseline-run-' + target)
    after = next(r for r in profile['runs'] if r['name'] == 'candidate-run-' + target)
    protocol = next(r for r in profile['runs'] if r['name'] == 'protocol-run-' + target)
    assert before['allocations'] == after['allocations'] == [60000]
    assert protocol['allocations'] == [60000, 420000]
assert 'Every driver measured here is within 5%' in (out / 'driver-gate.log').read_text()
assert not (out / 'format.log').read_bytes() and not (out / 'gofmt.log').read_bytes()
files = []
digest = hashlib.sha256()
for name in sorted(subprocess.check_output(['git', 'ls-files', 'compiler', 'internal/stdlib'], cwd=root, text=True).splitlines()):
    data = (root / name).read_bytes()
    digest.update(name.encode() + b'\0' + data + b'\0')
    files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert digest.hexdigest() == boot['source_sha256']
dest.mkdir(parents=True, exist_ok=False)
artifacts = []
def save(name, data):
    p = dest / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    artifacts.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
def take(name):
    save(name + '.gz', gzip.compress((out / name).read_bytes(), mtime=0))
save('source-files.json', json.dumps(files, indent=2).encode() + b'\n')
patch = subprocess.check_output(['git', 'diff', '--binary', base, core], cwd=root)
subprocess.run(['git', 'apply', '--reverse', '--check', '-'], input=patch, cwd=root, check=True)
save('change.patch.gz', gzip.compress(patch, mtime=0))
for name in ['bootstrap/bootstrap.json', 'bootstrap/stage1.log', 'bootstrap/stage2.log', 'bootstrap/stage3.log', 'targeted-tests.jsonl', 'driver-builds.json', 'driver-sizes.txt', 'driver-gate.log', 'check-sizes.py', 'matrix-helper.json', 'matrix-helper.py', 'matrix.log', 'loop-profile.py', 'loop-profile/report.json', 'loop-profile.log', 'os-proof-merge.json', 'format.log', 'gofmt.log', 'vet.log', 'record-proofs.py']:
    take(name)

stream = io.BytesIO()
logs = []
with tarfile.open(fileobj=stream, mode='w:gz') as archive:
    for folder in ['matrix-helper', 'loop-profile']:
        for p in sorted((out / folder).glob('*')):
            if p.suffix not in ['.stdout', '.stderr', '.fern']:
                continue
            data = p.read_bytes()
            info = tarfile.TarInfo(folder + '/' + p.name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
            logs.append(str(p))
assert len(logs) == 214
save('execution-logs.tar.gz', stream.getvalue())
(dest / 'artifacts.json').write_text(json.dumps({'source_commit': core, 'dependency_base': base, 'native_sha256': boot['stages'][2]['sha256'], 'tests': tests, 'source_sha256': digest.hexdigest(), 'oracle_sha256': matrix['oracle_sha256'], 'artifacts': artifacts}, indent=2) + '\n')
print('Verified', len(files), 'source files and', len(artifacts), 'artifacts')
