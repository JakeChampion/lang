from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-map-iterator-publish');scratch=Path('/workspace/scratch/lang-map-iterator/path-helper-integration');out=scratch/'matrix-helper';out.mkdir(exist_ok=True);compiler=scratch/'bootstrap/stage3';oracle=Path('/workspace/scratch/lang-map-iterator/current-integration/oracle-helper');stdlib=root/'internal/stdlib';rows=[]
names=['map_iter_struct_value','map_iter_unannotated','map_str_iter','map_struct_value_field','rc_corpus_map_iter_escape_churn_free','rc_corpus_map_iter_string_kv_retain_churn_free','map_iterator_protocol','iterator_nested_tuple_adapter']
meta={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'compiler_source_commit':'19551ede188ee36a55578b4c59eddf1778c39a69','producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows,'fixtures':[]}
def save():(scratch/'matrix-helper.json').write_text(json.dumps(meta,indent=2)+'\n')
def run(name,args,expected=0,extra={}):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(os.environ,**extra),capture_output=True,timeout=180);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);row={'name':name,'args':list(map(str,args)),'exit':r.returncode,'expected_exit':expected,'seconds':time.monotonic()-start};rows.append(row);save();print(row,flush=True);assert r.returncode==expected,(name,r.stdout,r.stderr);assert b'fern-sanitizer:'not in r.stderr;return r,row
for name in names:
 path=root/'conformance/cases'/name/'main.fern';e=path.parent/'expected.exit';expected=int(e.read_text())if e.exists()else 0;meta['fixtures'].append({'name':name,'expected_exit':expected,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 for engine,tool in [('go',oracle),('self',compiler)]:
  for mode in ['-check','-interp']:run(name+'-'+engine+mode,[tool,mode,path]+([stdlib]if engine=='self'else[]),expected if mode=='-interp'else 0)
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=out/(name+'-'+target);args=[compiler,'-target',target,'-o',dest]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[path,stdlib];run(name+'-build-'+target,args,extra={'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest]if target=='x86-64-linux'else['qemu-aarch64',dest]if target=='arm64-linux'else['wasmtime','run',dest];r,row=run(name+'-run-'+target,args,expected);m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,(name,target,r.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
meta['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
