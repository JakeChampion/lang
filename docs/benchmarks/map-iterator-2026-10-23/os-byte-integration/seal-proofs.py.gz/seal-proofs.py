from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile,io,collections
root=Path('/workspace/lang-map-iterator-publish');out=Path('/workspace/scratch/lang-map-iterator/os-byte-integration');measured='85018cd7080613844ba1acabcca8ae9ff7f7f129';core='aedd40abf595377c7de1c3054b0ea260ee5a3e62';base='77602f33f56372f4eabbfc7229bd13fce2eb928d';dest=root/'docs/benchmarks/map-iterator-2026-10-23/os-byte-integration';assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==core
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==measured and boot['fixedpoint'];assert len({r['sha256']for r in boot['stages']})==1;files=[];digest=hashlib.sha256()
for n in sorted(subprocess.check_output(['git','ls-files','compiler','internal/stdlib'],cwd=root,text=True).splitlines()):
 data=(root/n).read_bytes();digest.update(n.encode()+b'\0'+data+b'\0');files.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
assert digest.hexdigest()==boot['source_sha256'];assert 'Every driver measured here is within 5%'in(out/'driver-gate.log').read_text();assert all((out/n).stat().st_size==0 for n in ['format.log','gofmt.log','vet.log'])
tests={}
for name,count,skips,pkgs in [('targeted-tests.jsonl',98,0,2),('go-regressions.jsonl',2564,3,5)]:
 ds=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];counts=collections.Counter(d['Action']for d in ds);assert counts['run']==count and counts['skip']==skips and counts['fail']==0;terminal=[d for d in ds if'Test'not in d and d['Action']in('pass','fail')];assert len(terminal)==pkgs and all(d['Action']=='pass'for d in terminal);tests[name]={'actions':dict(counts),'packages':[d['Package']for d in terminal]}
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+measured in version and 'vcs.modified=false'in version
m=json.loads((out/'matrix-helper.json').read_text());assert m['complete']and m['source_commit']==measured and m['compiler_source_commit']==measured and len(m['runs'])==88;assert m['producer_sha256']==boot['stages'][-1]['sha256'];assert m['oracle_sha256']==hashlib.sha256((out/'oracle').read_bytes()).hexdigest();assert all(r['exit']==r['expected_exit']for r in m['runs'])
b=json.loads((out/'byte-matrix.json').read_text());assert b['source_commit']==measured and b['complete']and len(b['runs'])==38 and all(r['code']==0 for r in b['runs'])
profile=json.loads((out/'loop-profile/report.json').read_text());assert profile['source_commit']==measured and profile['complete']and len(profile['runs'])==18;assert profile['baseline_compiler_source_commit']=='3048da4e51442f2baa9e8b045f5003329d72d214';assert profile['candidate_compiler_source_commit']==measured;assert profile['compilers']['candidate']==boot['stages'][-1]['sha256']
for rows,want in [(m['runs'],24),(b['runs'],9),(profile['runs'],9)]:
 cs=[r['census']for r in rows if'census'in r];assert len(cs)==want and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
for r in profile['runs']:
 if'allocations'in r:assert r['allocations']==([60000,420000]if r['name'].startswith('protocol')else[60000])
identity=json.loads((out/'main-repair-merge-identity.json').read_text());assert identity['measured_source']==measured and identity['integrated_source']==core and identity['compiler_stdlib_and_pin_unchanged']
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def take(n):
 data=(out/n).read_bytes();pack=len(data)>1000 or n.endswith('.py');save(n+'.gz'if pack else n,gzip.compress(data,mtime=0)if pack else data)
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=subprocess.check_output(['git','diff','--binary',base,core,'--','.',':(exclude)docs/benchmarks'],cwd=root);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','targeted-tests.jsonl','compiler-parents.txt','focused-command.json','go-regressions.jsonl','oracle-version.txt','driver-builds.json','driver-sizes.txt','driver-gate.log','sizes.log','check-sizes.py','format.log','gofmt.log','vet.log','matrix-helper.json','matrix-helper.py','matrix.log','loop-profile.py','loop-profile/report.json','loop-profile.log','os-byte-matrix.py','os-byte-matrix.log','byte-matrix.json','main-repair-merge-identity.json','seal-proofs.py']:take(n)
stream=io.BytesIO();logs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['matrix-helper','loop-profile','byte-matrix']:
  for p in sorted((out/folder).glob('*')):
   if p.suffix not in['.stdout','.stderr','.fern']:continue
   data=p.read_bytes();name=folder+'/'+p.name;item=tarfile.TarInfo(name);item.size=len(data);item.mode=0o644;item.mtime=0;t.addfile(item,io.BytesIO(data));logs.append(name)
save('output-logs-and-inputs.tar.gz',stream.getvalue());manifest={'measured_source':measured,'integrated_source':core,'dependency_base':base,'source_sha256':digest.hexdigest(),'source_files':len(files),'native_sha256':boot['stages'][-1]['sha256'],'oracle_sha256':m['oracle_sha256'],'tests':tests,'map_matrix_commands':88,'map_balanced_censuses':24,'os_matrix_commands':38,'os_balanced_censuses':9,'profile_commands':18,'profile_balanced_censuses':9,'output_logs_and_inputs':len(logs),'artifacts':artifacts};(dest/'artifacts.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'artifacts':len(artifacts),'source_files':len(files),'logs_and_inputs':len(logs),'native':manifest['native_sha256']}))
