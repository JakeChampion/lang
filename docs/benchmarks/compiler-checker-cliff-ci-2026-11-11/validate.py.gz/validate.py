from pathlib import Path
import subprocess,json,hashlib,re,os,datetime,traceback
root=Path('/workspace/lang-spec-index-pins-20261111-0230');out=Path(__file__).resolve().parent
source='2ca148c6757a95ba419a67751dd3598726f07c56';oldpub='7ed25d7e1c1c94d73cae445d61852197c4c4e6aa';oldsrc='29b1234d0699d6b42d7d85bbcd82dbfb92c6dce2'
oldarchive='docs/benchmarks/compiler-method-result-ci-2026-11-11'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s={'source':source,'scope':'One exact corrective cliff-count row from current main CI. Projected-row replay and explicit full-baseline missing-row controls. No compiler benchmark or negative-suite rerun.','runs':[]}
def save():(out/'validation.json').write_text(json.dumps(s,indent=2)+'\n')
def blob(rev,name):return subprocess.check_output(['git','show',rev+':'+name],cwd=root)
def table(b):
 return {a[0]:(int(a[1]),a[2:])for line in b.decode().splitlines()if line.strip()and not line.lstrip().startswith('#') for a in [line.split()]}
def run(label,baseline,expected):
 env=dict(os.environ)
 for key in ['FERN_CI_PERF_GATE_MAX_DRIFT','FERN_PERF_TOLERANCE_PERCENT']:env.pop(key,None)
 env['FERN_CI_PERF_GATE_STRICT']='1'
 args=[str(root/'scripts/ci-check-perf'),str(baseline),str(out/'ci-corrective.report')]
 r={'label':label,'args':args,'expected_exit':expected,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};s['runs'].append(r);save()
 with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:p=subprocess.run(args,cwd=root,stdout=so,stderr=se,env=env,timeout=180)
 r['exit_code']=p.returncode;r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();assert p.returncode==expected,(label,p.returncode)
save()
try:
 text=(out/'ci/job-130273056431.log').read_text()
 found=re.findall(r'(x86_64/checker\.cliff_count) measured (\d+) against a baseline of (\d+) — over its ([0-9.]+)% tolerance',text)
 assert found==[('x86_64/checker.cliff_count','378075','373694','1')],found
 before=(out/'before-cliff-baseline.txt').read_bytes();after=(root/'.github/cliff-baseline.txt').read_bytes();assert before==blob(source,'.github/cliff-baseline.txt')
 a,b=table(before),table(after);assert a.keys()==b.keys()
 changed=[k for k in a if a[k]!=b[k]];assert changed==['x86_64/checker.cliff_count'],changed
 for k in a:assert a[k][1]==b[k][1]
 assert a[changed[0]][0]==373694 and b[changed[0]][0]==378075
 assert all(line in after.decode().splitlines()for line in before.decode().splitlines()if line.startswith('#'))
 (out/'after-cliff-baseline.txt').write_bytes(after)
 (out/'ci-corrective.report').write_text('x86_64/checker.cliff_count\t378075\n')
 (out/'projected-old-baseline.txt').write_text('x86_64/checker.cliff_count\t373694\n')
 (out/'projected-new-baseline.txt').write_text('x86_64/checker.cliff_count\t378075\n')
 run('projected-old-gate',out/'projected-old-baseline.txt',1)
 run('projected-new-gate',out/'projected-new-baseline.txt',0)
 run('full-old-partial-report',out/'before-cliff-baseline.txt',1)
 run('full-new-partial-report',root/'.github/cliff-baseline.txt',1)
 for label in ['full-old-partial-report','full-new-partial-report']:
  assert 'MISSING: x86_64/checker.cliff_bytes' in(out/(label+'.stderr')).read_text()+(out/(label+'.stdout')).read_text()
 oldmanifest_bytes=blob(oldpub,oldarchive+'/manifest.json');oldmanifest=json.loads(oldmanifest_bytes)
 for n,h in oldmanifest['data_sha256'].items():assert hashlib.sha256(blob(oldpub,oldarchive+'/'+n)).hexdigest()==h,n
 previous=json.loads(blob(oldpub,oldarchive+'/validation.json'));assert previous['exit_code']==0 and previous['captured_comparator_children']==22
 protocol={}
 for name in ['scripts/ci-check-perf','scripts/flag-lib','scripts/perf-gate-selftest.mjs','scripts/cliff-bench','.github/workflows/perf.yml','bootstrap/stage0.lock']:
  raw=blob(source,name);assert (root/name).read_bytes()==raw,name
  assert raw==blob(oldsrc,name),name
  protocol[name]={'git_blob':subprocess.check_output(['git','rev-parse',source+':'+name],cwd=root,text=True).strip(),'sha256':hashlib.sha256(raw).hexdigest()}
 (out/'source-identities.json').write_text(json.dumps({'source':source,'product_trees':{p:subprocess.check_output(['git','rev-parse',source+':'+p],cwd=root,text=True).strip()for p in ['compiler','internal/stdlib','internal/check']},'protocol_files':protocol,'measured_compiler_executable_sha256':None,'protocol_note':'The original cliff script disables ownership certification for its lowering counters. These counters do not establish normal certified timing or leak freedom.'},indent=2)+'\n')
 (out/'negative-controls-reuse.json').write_text(json.dumps({'commit':oldpub,'archive':oldarchive,'verified_data_hashes':len(oldmanifest['data_sha256']),'manifest_sha256':hashlib.sha256(oldmanifest_bytes).hexdigest(),'canonical_control_results':22,'canonical_control_commands_executed':0,'comparator_flag_helper_and_selftest_sources_unchanged':True,'reason':'Reuse the unchanged canonical comparator controls by exact source and archive identity. The four replay commands above separately check this new measured row and preserve missing-row refusal.'},indent=2)+'\n')
 (out/'row-move.json').write_text(json.dumps({'source':source,'run':42942829694,'job':130273056431,'measurement_date':'2026-11-11','bank_date':'2026-11-11','key':'x86_64/checker.cliff_count','before':373694,'after':378075,'default_tolerance_percent':1,'unchanged_all_other_rows_and_tolerances':True,'report_scope':'Only the exact corrective count from the complete decoded CI log. No exact values inferred from rounded in-band displays. The report is a parsed view, not a downloaded full artifact report.','qualification_limit':'One-row projections pass after the update. Both full baselines reject this partial report. Complete exact-head CI must qualify the actual full report.'},indent=2)+'\n')
 s.update(exit_code=0,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except Exception as e:s.update(exit_code=1,error=repr(e),traceback=traceback.format_exc());save();raise
