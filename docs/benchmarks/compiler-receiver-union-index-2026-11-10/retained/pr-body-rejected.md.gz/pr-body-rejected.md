The union-index trial is rejected because cold checker compilation regresses in the fixed matched sweep.
Keep this pull request in draft.
Published head `67b21637` still contains the rejected trial and must not merge.
Local removal `7f9ea39b` deletes only the helper and its two call sites.
Local merge `c02d2b4c` preserves actual main `e4494347` and awaits retained-source validation.

The proposed final compiler and standard library sources exactly match main `e4494347`.
The retained changes cover receiver-query contracts and repair the kernel scheduler fixture.
All earlier experiment records remain intact.
No compiler optimization or speedup remains in the proposed final source.

The new receiver regression checks exact raw membership and method selection on x86-64, QEMU ARM64, and WASI.
It covers first-duplicate behavior, empty and missing names, qualified variants, direct/generic receivers, and import state.
The test also checks a table with 300 unions.
The recursive array-based membership API and the existing union index remain unchanged.

The measured trial compares main `b442b6b9` with candidate `67b21637`.
Eight fixed balanced pairs per workload and proof-cache mode produce 64 timed commands.
Separate cache primes and probes add eight normal commands.
Twelve separate counter commands retain allocation and free counts.
All 84 commands succeed, and emitted native programs match within each workload.
No sample extension or favorable retry occurs.

Cold checker CPU medians increase from 11.8509315 to 13.118910 seconds, or 10.7%.
Seven of eight candidate pairs are slower.
The other three workload and cache combinations retain lower CPU medians.
Allocation counts and median peak RSS remain equal in all four combinations.
The other gains do not justify the unresolved cold checker cost.
The physical timing cause remains unknown.

The instruction matrix stops after this rejection.
Its first candidate run receives SIGTERM, and all partial traces and logs remain intact.
There is no completed instruction comparison for this source pair.
The older `0e715dff` / `99fda7a6` instruction reduction remains a separate historical result for the rejected trial.
No external rank or normal full-run leak claim is made.

The earlier CI failure concerns `TestSelfHostKernelTwoCoreSchedulerOnQemu`.
All workers exit zero and frames return, but the test does not observe each worker on both cores.
I claimed only this failure on #15118, comment 6773460833.
The fixture now requires each process to visit both cores before either core resumes it repeatedly.
The compiler, standard library, timer, worker, assertions, and budgets remain unchanged by this repair.

Six ordinary main `515ddee8` repetitions pass locally, so no natural local reproduction is claimed.
One private slower-timer control fails the original migration and concurrency assertions.
The corrected fixture passes 12 standard scheduler runs, Go vet, and every original assertion under that private control.
This control does not establish a unique cause for the CI timing difference.
The `ci-full` label retains every failure in the next complete round.

The rejected source passes 147 test and subtest results across 17 suites, with zero skips.
Both normal compilers check their own source and retain all five E098 refusals with identical diagnostics.
Its full normal interpreter control passes the complete Opus corpus with the expected reference TAP output.
These results remain source-specific.
Fresh main and retained builds, source checks, targeted tests, and full correctness controls are in progress.
The retained source also includes every upstream parser, mismatch-kernel, and Android repair from current main.

The validated removal will follow on this same branch with an expected-head guard.
All raw measurements, failures, exact source identities, and the rejection decision will follow in a separate evidence archive.
Keep this PR in draft until the retained source passes complete exact-head relevant CI.

Part of #11534.
