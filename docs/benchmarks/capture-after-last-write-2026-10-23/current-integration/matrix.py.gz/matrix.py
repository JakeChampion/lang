from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-capture-after-last-write-publish');scratch=Path('/workspace/scratch/lang-defer-capture-cells/current-range-integration');out=scratch/'matrix-checked';out.mkdir(exist_ok=True)
compiler=scratch/'bootstrap/stage3';oracle=scratch/'oracle';stdlib=root/'internal/stdlib';rows=[]
metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'compiler_source_commit':'76f95b0edb8b0de0881b2f7f10f9ca8c63a78b8f','producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows}
def save():(scratch/'matrix.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(name,args,expected=0,extra={}):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(os.environ,**extra),capture_output=True,timeout=240)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 row={'name':name,'args':list(map(str,args)),'exit':r.returncode,'expected_exit':expected,'seconds':time.monotonic()-start};rows.append(row);save();print(row,flush=True);assert r.returncode==expected,(name,r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace'));return r,row
fixtures=[]
for name,file,var in [('capture-timing','self_host_capture_timing_test.go','captureTimingProgram'),('builtin-shadow','self_host_builtin_shadow_call_test.go','builtinShadowProgram')]:
 s=(root/'internal/testing/e2ecompiler'/file).read_text();src=re.search(r'const '+var+r' = `([\s\S]*?)`',s).group(1);path=out/(name+'.fern');path.write_text(src+'\n');fixtures.append((name,path,0,b'ok\n'))
path=out/'reader-before-writer.fern';src=Path('/workspace/scratch/lang-defer-capture-cells/reader-before-writer-public/capture.fern').read_text();assert 'return first * 10 + read();' in src;path.write_text(src.replace('return first * 10 + read();','if (first * 10 + read() != 77) { return 1; } return 0;'));fixtures.append(('reader-before-writer',path,0,b''))
metadata['fixtures']=[{'name':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'expected_exit':expected,'expected_stdout':stdout.decode()}for name,p,expected,stdout in fixtures]
for name,path,expected,stdout in fixtures:
 for engine,tool in [('go',oracle),('self',compiler)]:
  for mode in ['-check','-interp']:
   r,_=run(name+'-'+engine+mode,[tool,mode,path]+([stdlib]if engine=='self'else[]),expected if mode=='-interp'else 0)
   if mode=='-interp':assert r.stdout==stdout,(name,engine,r.stdout)
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=out/(name+'-'+target)
  run(name+'-build-'+target,[compiler,'-target',target,'-o',dest,path,stdlib],extra={'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest]if target=='x86-64-linux'else['qemu-aarch64',dest]if target=='arm64-linux'else['wasmtime','run','--dir=.',dest]
  r,row=run(name+'-run-'+target,args,expected);assert r.stdout==stdout,(name,target,r.stdout)
  m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,(name,target,r.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
metadata['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
