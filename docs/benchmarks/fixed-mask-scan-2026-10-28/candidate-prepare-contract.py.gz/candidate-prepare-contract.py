from pathlib import Path
import json
p=Path(__file__).parent;repo=Path('/workspace/lang-perf-4412');c=p/'contract';c.mkdir();(c/'ssafixed.fern').write_bytes((p/'compiler/ssafixed.fern').read_bytes());(c/'ssafixed_original.fern').write_bytes((repo/'compiler/ssafixed.fern').read_bytes())
s='''import "./ssafixed";
import "./ssafixed_original";
function same(a: i32[], b: i32[]): boolean {
  if (a.len() != b.len()) { return false; }
  let i: i32 = 0;
  while (i < a.len()) { if (a[i] != b[i]) { return false; } i = i + 1; }
  return true;
}
function rows(a: i32[][], b: i32[][]): boolean {
  if (a.len() != b.len()) { return false; }
  let i: i32 = 0;
  while (i < a.len()) { if (!same(a[i], b[i])) { return false; } i = i + 1; }
  return true;
}
function table_same(a: ssafixed.Table, b: ssafixed_original.Table): boolean {
  return a.first == b.first && a.clobber_first == b.clobber_first && rows(a.before, b.before) && rows(a.clobbers, b.clobbers);
}
function check(first: i32, count: i32, masks: i32[]): boolean {
  let a = ssafixed.table(first, count, masks);
  let b = ssafixed_original.table(first, count, masks);
  if (!table_same(a, b)) { return false; }
  a = ssafixed.with_clobbers(a, first + 1, count, masks);
  b = ssafixed_original.with_clobbers(b, first + 1, count, masks);
  if (!table_same(a, b)) { return false; }
  ssafixed.validate(a, first + count + 1, masks.len());
  ssafixed_original.validate(b, first + count + 1, masks.len());
  let reg: i32 = 0;
  while (reg <= first + count + 1) {
    let lo: i32 = 0;
    while (lo < masks.len()) {
      if (ssafixed.allows(a, reg, lo, lo) != ssafixed_original.allows(b, reg, lo, lo)) { return false; }
      if (ssafixed.allows(a, reg, lo, masks.len() - 1) != ssafixed_original.allows(b, reg, lo, masks.len() - 1)) { return false; }
      lo = lo + 1;
    }
    reg = reg + 1;
  }
  return ssafixed.empty(a) == ssafixed_original.empty(b);
}
function refused(mode: string, original: boolean): i32 {
  let first: i32 = 0;
  let count: i32 = 2;
  let masks: i32[] = [0, 1];
  if (mode == "first") { first = -1; }
  if (mode == "zero") { count = 0; }
  if (mode == "negative") { count = -1; }
  if (mode == "wide") { count = 32; }
  if (mode == "negative-mask") { masks = [0, -1]; }
  if (mode == "late-mask") { masks = [0, 1, 4]; }
  if (mode == "high-mask") { count = 30; masks = [1073741824]; }
  if (mode == "range-before-mask") { first = -1; masks = [-1]; }
  if (original) {
    let t = ssafixed_original.table(first, count, masks);
    if (mode == "positions") { ssafixed_original.validate(t, 2, 9); }
    if (mode == "caller-range") { ssafixed_original.validate(t, 1, masks.len()); }
  } else {
    let t = ssafixed.table(first, count, masks);
    if (mode == "positions") { ssafixed.validate(t, 2, 9); }
    if (mode == "caller-range") { ssafixed.validate(t, 1, masks.len()); }
  }
  return 9;
}
function main(): i32 {
  let av = args();
  if (av.len() > 2) { return refused(av[1], av[2] == "original"); }
  let cases: i32 = 0;
  let count: i32 = 1;
  while (count <= 31) {
    for first in [0, 1, 5] {
      for n in [0, 1, 2, 7, 8, 9, 31, 33] {
        for pattern in [0, 1, 2, 3] {
          let limit: i32 = 2147483647 >> (31 - count);
          let masks: i32[] = [];
          let i: i32 = 0;
          while (i < n) {
            let mask: i32 = 0;
            if (pattern == 1) { mask = limit; }
            if (pattern == 2) { mask = i & limit; }
            if (pattern == 3) { mask = (i * 31 + 17) & limit; }
            masks = masks.append(mask);
            i = i + 1;
          }
          if (!check(first, count, masks)) { print("table mismatch"); return 1; }
          cases = cases + 1;
        }
      }
    }
    count = count + 1;
  }
  if (!table_same(ssafixed.none(), ssafixed_original.none())) { return 2; }
  print(cases);
  return 0;
}
'''
(c/'fixed_contract.fern').write_text(s);(p/'contract-provenance.json').write_text(json.dumps(dict(valid_cases=2976,refusal_modes=['first','zero','negative','wide','negative-mask','late-mask','high-mask','range-before-mask','positions','caller-range'],targets=3,proof='Compare full prefix matrices, ranges, empty status and interval decisions; compare exit3 and full diagnostic bytes for refusals.',limits='Helper-level table corpus. Actual register allocation and emitter suites required before production adoption.'),indent=2)+'\n');print('contract prepared, no duplicate compiler build started')
