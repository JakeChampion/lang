from pathlib import Path
import hashlib,json,os,re,subprocess,time
p=Path(__file__).parent;prov=json.loads((p/'provenance.json').read_text());producer=prov['common_producer'];stdlib=prov['fixed_stdlib'];env=dict(os.environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_RC_CERTIFY_MEMO=str(p/'memo-contract'));records=[]
modes=json.loads((p/'contract-provenance.json').read_text())['refusal_modes']
for target in ['x86-64-linux','arm64-linux','wasm32-wasi']:
 name='contract-'+target;binary=p/name;cmd=[producer,'-O','-sanitize','-target',target,'-o',str(binary),str(p/'contract/fixed_contract.fern'),stdlib];start=time.perf_counter()
 with (p/(name+'-build.log')).open('wb') as out:r=subprocess.run(cmd,env=env,stdout=out,stderr=subprocess.STDOUT)
 rec=dict(target=target,build_command=cmd,build_exit=r.returncode,build_seconds=time.perf_counter()-start);records.append(rec);(p/'differential.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,target
 base=[str(binary)] if target=='x86-64-linux' else ['qemu-aarch64','-cpu','max',str(binary)] if target=='arm64-linux' else ['wasmtime','run','--env','FERN_SANITIZE=1',str(binary)]
 command=base if target!='wasm32-wasi' else base[:2]+['--env','FERN_LEAKCHECK=1']+base[2:];start=time.perf_counter();r=subprocess.run(command,env=env,capture_output=True);(p/(name+'.stdout')).write_bytes(r.stdout);(p/(name+'.stderr')).write_bytes(r.stderr);m=re.fullmatch(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)\s*',r.stderr);rec.update(command=command,exit=r.returncode,seconds=time.perf_counter()-start,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stdout_bytes=len(r.stdout),census=list(map(int,m.groups())) if m else None);(p/'differential.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0 and r.stdout==b'2976\n' and m,target;allocs,frees,live=rec['census'];assert allocs>0 and allocs==frees and live==0,target
 refusals=[];refenv=dict(env);refenv.pop('FERN_LEAKCHECK',None);refenv.pop('FERN_SANITIZE',None)
 plain=p/('plain-'+target);plaincmd=[producer,'-O','-target',target,'-o',str(plain),str(p/'contract/fixed_contract.fern'),stdlib]
 with (p/('plain-'+target+'-build.log')).open('wb') as out:plainresult=subprocess.run(plaincmd,env=refenv,stdout=out,stderr=subprocess.STDOUT)
 rec.update(refusal_build_command=plaincmd,refusal_build_exit=plainresult.returncode);(p/'differential.json').write_text(json.dumps(records,indent=2)+'\n');assert plainresult.returncode==0
 refusalbase=[str(plain)] if target=='x86-64-linux' else ['qemu-aarch64','-cpu','max',str(plain)] if target=='arm64-linux' else ['wasmtime','run',str(plain)]
 for mode in modes:
  expected=b'SSA fixed-register table: '+(b'invalid register range' if mode in ['first','zero','negative','wide','range-before-mask'] else b'incorrect position count' if mode=='positions' else b'range outside caller registers' if mode=='caller-range' else b'mask outside register range')+b'\n';pair=[]
  for variant in ['original','candidate']:
   command=refusalbase+[mode,variant];r=subprocess.run(command,env=refenv,capture_output=True);stem=name+'-'+mode+'-'+variant;(p/(stem+'.stdout')).write_bytes(r.stdout);(p/(stem+'.stderr')).write_bytes(r.stderr);entry=dict(mode=mode,variant=variant,command=command,exit=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),diagnostic=r.stderr.decode());refusals.append(entry);(p/('refusals-'+target+'.json')).write_text(json.dumps(refusals,indent=2)+'\n');assert r.returncode==3 and r.stdout==b'' and r.stderr==expected,(target,mode,variant,r.stderr);pair.append((r.returncode,r.stdout,r.stderr))
  assert pair[0]==pair[1]
 rec.update(refusal_runs=len(refusals),refusals_identical=True);(p/'differential.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(rec),flush=True)
