from pathlib import Path
import os,json,subprocess,hashlib
p=Path(__file__).parent;env=dict(os.environ);env.pop('FERN_LEAKCHECK',None);env.pop('FERN_SANITIZE',None);records=[]
for mode in json.loads((p/'contract-provenance.json').read_text())['refusal_modes']:
 expected=b'SSA fixed-register table: '+(b'invalid register range' if mode in ['first','zero','negative','wide','range-before-mask'] else b'incorrect position count' if mode=='positions' else b'range outside caller registers' if mode=='caller-range' else b'mask outside register range')+b'\n';pair=[]
 for variant in ['original','candidate']:
  cmd=['wasmtime','run',str(p/'plain-wasm32-wasi'),mode,variant];r=subprocess.run(cmd,env=env,capture_output=True);stem='contract-wasm32-wasi-'+mode+'-'+variant;(p/(stem+'.stdout')).write_bytes(r.stdout);(p/(stem+'.stderr')).write_bytes(r.stderr);records.append(dict(mode=mode,variant=variant,command=cmd,exit=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),diagnostic=r.stderr.decode()));(p/'refusals-wasm32-wasi.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==1 and r.stdout==b'' and r.stderr==expected;pair.append((r.returncode,r.stdout,r.stderr))
 assert pair[0]==pair[1]
f=p/'differential.json';j=json.loads(f.read_text());j[-1].update(refusal_runs=20,refusals_identical=True,refusal_resume='finish-refusals.py',expected_component_exit_status=1);assert all(x['exit']==0 and x['refusals_identical'] for x in j);f.write_text(json.dumps(j,indent=2)+'\n');print('All2976 validcases/target, all60refusalruns pass. Native/ARM exit3; Wasmcomponent exit1; exact stdout/stderr preserved.')
