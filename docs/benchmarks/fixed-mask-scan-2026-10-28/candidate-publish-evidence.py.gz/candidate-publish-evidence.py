from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).parent;repo=Path('/workspace/lang-perf-4412');out=repo/'docs/benchmarks/fixed-mask-scan-2026-10-28';out.mkdir(exist_ok=True);prov=json.loads((p/'provenance.json').read_text());base=Path(prov['baseline_directory']);rows=[]
assert json.loads((p/'post-state.json').read_text())['complete']
def save(name,raw,mode=0o644):
 z=out/(name+'.gz');packed=gzip.compress(raw,mtime=0);z.write_bytes(packed);assert gzip.decompress(z.read_bytes())==raw;rows.append(dict(archive=z.name,raw_name=name,raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),archive_sha256=hashlib.sha256(packed).hexdigest(),restore_mode=mode))
def file(prefix,f):
 raw=f.read_bytes();name=prefix+f.name
 if f.suffix=='.gz':raw=gzip.decompress(raw);name=name[:-3]
 save(name,raw,f.stat().st_mode&0o777)
for f in sorted(p.iterdir()):
 if f.is_file() and f.name not in ['fern-oracle','fern-oracle.gz']:file('candidate-',f)
for f in sorted(base.iterdir()):
 if f.is_file():file('baseline-',f)
for folder in ['initial-refusal-harness','wasm-status-harness']:
 for f in sorted((p/folder).rglob('*')):
  if f.is_file():file(folder+'-',f)
def tree(name,root):
 b=io.BytesIO()
 with tarfile.open(fileobj=b,mode='w') as t:
  for f in sorted(root.rglob('*')):
   if f.is_file():t.add(f,arcname=str(f.relative_to(root)),recursive=False)
 save(name+'.tar',b.getvalue())
tree('candidate-source',p/'compiler');tree('contract-source',p/'contract');tree('conformance-source',p/'emit-source/conformance')
for name,old in [('baseline-source.tar','source-before.tar.gz'),('fixed-subject-tree.tar','source-after.tar.gz')]:
 f=repo/'docs/benchmarks/liveness-offset-rejected-2026-10-28'/old;save(name,gzip.decompress(f.read_bytes()))
producer=Path(prov['common_producer']);save('common-stage1',producer.read_bytes(),0o755)
for name in ['current-cli-info.json','current-producer.json']:file('producer-',p.parent/'main-b024-merge'/name)
(out/'manifest.json').write_text(json.dumps(rows,indent=2)+'\n');print('Verified',len(rows),'raw archives;',sum((out/x['archive']).stat().st_size for x in rows),'compressed bytes')
