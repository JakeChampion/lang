from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
p=Path(__file__).parent;repo=Path('/workspace/lang-perf-4412');prov=json.loads((p/'provenance.json').read_text());producer=prov['common_producer'];stdlib=prov['fixed_stdlib'];baseline=Path(prov['baseline_directory']).parent/'source-before/compiler';env=dict(os.environ);env.pop('STAGE0',None);env.pop('FERN_SELFHOST',None);steps=[];state=p/'post-state.json';assert not state.exists()
def save():state.write_text(json.dumps(dict(steps=steps,complete=False,runner_pid=os.getpid()),indent=2)+'\n')
def run(name,cmd,command_env=env):
 rec=dict(name=name,command=cmd,started_at=datetime.datetime.now(datetime.timezone.utc).isoformat());steps.append(rec);started=time.perf_counter()
 with (p/(name+'.log')).open('wb') as out:
  proc=subprocess.Popen(cmd,cwd=repo,env=command_env,stdout=out,stderr=subprocess.STDOUT);rec['pid']=proc.pid;save();code=proc.wait()
 rec.update(exit=code,seconds=time.perf_counter()-started);save();(p/(name+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True);assert code==0,name;return rec
sizes=[]
for target in ['x86-64-linux','arm64-linux','wasm32-wasi']:
 for version,root in [('before',baseline),('after',p/'compiler')]:
  name='small-driver-'+version+'-'+target;binary=p/name;run(name+'-build',[producer,'-O','-target',target,'-o',str(binary),str(root/'drivers/ssa_cold_calls_run.fern'),stdlib]);cmd=[str(binary)] if target=='x86-64-linux' else ['qemu-aarch64','-cpu','max',str(binary)] if target=='arm64-linux' else ['wasmtime','run',str(binary)];rec=run(name+'-run',cmd);output=(p/(name+'-run.log')).read_bytes();assert output==b'failures=0\n';sizes.append(dict(target=target,version=version,bytes=binary.stat().st_size,sha256=hashlib.sha256(binary.read_bytes()).hexdigest()));(p/'small-driver-sizes.json').write_text(json.dumps(sizes,indent=2)+'\n')
for target in ['x86-64-linux','arm64-linux','wasm32-wasi']:
 a,b=[x['bytes'] for x in sizes if x['target']==target];assert b<=a*1.05,(target,a,b)
run('public-cli-build',['go','build','-o',str(p/'fern-oracle'),'./cmd/fern']);(p/'format-current.py').write_bytes((p.parent/'main-b024-merge/format-current.py').read_bytes());run('format-current',['python3',str(p/'format-current.py')])
for version,binary in [('before',Path(prov['baseline_directory'])/'stage2'),('after',p/'stage2')]:
 run('emit-hashes-'+version,[str(p/'emit-source/scripts/selfhost-emit-hashes'),str(binary),str(p/('emit-hashes-'+version+'.txt'))])
a=(p/'emit-hashes-before.txt').read_bytes();b=(p/'emit-hashes-after.txt').read_bytes();assert a==b,'conformance matrix differs';lines=a.splitlines();refused=sum(x.startswith(b'FAILED') for x in lines);assert len(lines)==1414*3 and refused<len(lines);record=dict(rows=len(lines),emitted=len(lines)-refused,refused=refused,byte_identical=True,sha256=hashlib.sha256(a).hexdigest());(p/'emit-comparison.json').write_text(json.dumps(record,indent=2)+'\n');frozen=p/'emit-source';hashes=json.loads((p/'emit-source-hashes.json').read_text());assert hashes=={str(f.relative_to(frozen)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (frozen/'conformance').rglob('*') if f.is_file()};j=json.loads(state.read_text());j['complete']=True;state.write_text(json.dumps(j,indent=2)+'\n');print(json.dumps(record),flush=True)
