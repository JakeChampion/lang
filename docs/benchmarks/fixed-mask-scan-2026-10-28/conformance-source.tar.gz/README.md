# The Fern conformance corpus

Status: normative. This directory defines observable Fern behaviour by
example. A change to a case's expected output is a change to the
language, and should be reviewed as one.

`cases/` holds one self-contained program per directory, each with the
program plus a few declarative sidecar files describing what running it
must produce. Every Fern implementation is measured against it: the
oracle, `internal/oracle/interp` (`bin/fern-oracle -interp`), and the
compiler users run, `fern`, through its interpreter, its front end and its
three targets (x86-64, arm64, wasm).

## Why this lives outside `internal/`

It used to be `internal/testing/e2e/testdata/cases` — inside one implementation,
which made it look like that implementation's test suite rather than the
language's definition.

New surface lands in `compiler/` first, and the Go oracle learns it so the
differentials can check it (`docs/NATIVE-RETIREMENT.md`). This corpus is
what carries the definition between them, so it is positioned as a peer of
the implementations rather than as a component of one.

See `docs/SPECIFICATION-RESEARCH.md` for the wider argument and for the
staged shape this is the first slice of.

## What is NOT here

**Per-implementation expectation files stay with their implementation.**
The `selfhost-*-known-divergences.txt` files remain in
`internal/testing/e2e/testdata/` deliberately: a divergence list records where
one implementation currently falls short of the corpus, which is a fact
about that implementation, not about the language. This follows test262,
where the suite is shared and each engine keeps its own expectations.

## Case format

A case is a directory `cases/<name>/`. Contents:

| File | Required | Meaning |
| --- | --- | --- |
| `main.fern` | yes | Entry point, defining `main(): i32`. May import sibling `.fern` files (`import "./helper";`) and stdlib modules. |
| `*.fern` | no | Sibling modules imported by `main.fern`. |
| `expected.stdout` | no | Expected stdout. Byte-for-byte in the default `exact` mode; a list of required substrings, one per line, in `contains` mode. Defaults to empty. |
| `expected.exit` | no | Expected process exit code, `0`–`255`. Defaults to `0`. |
| `stdin` | no | Bytes fed to the program's stdin. |
| `match` | no | `exact` (default) or `contains`. |
| `backends` | no | Whitespace-separated subset of `interp x86_64 arm64 wasm`; `#` starts a comment. Defaults to all four. |
| `expected.error` | no | Marks a **compile-error case** — the front end must reject it. See below. |
| `expected.lowering-error` | no | Marks a **lowering-error case** — the front end must ACCEPT it and lowering must reject it. See below. |
| `meta` | no | Justifies a case that asserts less than the maximum — see below. Required exactly when the case does. |
| `reclaim-observable` | no | Marks a case whose output deliberately DIFFERS with reclamation off, so the free-off gates invert for it rather than requiring a match. Contents are prose explaining why; only the file's presence is read. |

No other filenames are permitted, and case directories have no
subdirectories. Both are enforced (`TestConformanceCorpusFormat`),
because an unrecognised sidecar is otherwise read as an absent one: a
`expected.exitcode` typo silently asserts exit `0` rather than failing.

A `backends` file that names all four backends is rejected: that is
already what omitting the file means, so the list says nothing and only
its comment carries information — and a comment belongs in `main.fern`
with the rest of the case's rationale. The rule keeps "has a `backends`
file" readable as "is restricted".

### Compile-error cases

A case containing `expected.error` is **not run**. It must fail the
front-end — parse, module load, or type check. This gives declarative
coverage of the rejection paths behind the `E0NN` codes.

`expected.error` holds **one line per expected diagnostic**, and the
case asserts both directions: every line must appear in the reported
errors, and every error CODE reported must be named by some line.
Repeats of the same code are the case doing its job — one diagnostic
per offending element is normal — so the second half is over distinct
codes, not over the number of diagnostics.

The second half is why the file is a list. A case usually carries
functions showing what IS allowed beside the one that is rejected, and
under a plain substring match those were never checked to compile: a
second diagnostic was reported, matched past, and never seen.
`diag_e053` documented an in-place array write as the allocation-free
`fip` shape for months that way, with the `E056` saying it does not
compile sitting in the output the whole time (#9601). When a second
code IS legitimate — a cascade the rejected construct causes — add a
line for it, which records the cascade rather than hiding it.

Such a case must carry none of `expected.stdout`, `expected.exit`,
`stdin`, `match` or `backends`; those are ignored on this path, and a
case that sets one is asserting something that is not being checked.
It must not carry a `meta` waiver either: a waiver justifies asserting
less than byte-exact output on all four backends, and a rejection case
asserts no output at all.

### Lowering-error cases

Not every rejection is a front-end rejection. `E068` — a `fbip`
function that allocates without a donor to reuse — is reported by
`compiler/irfipverify.fern` during lowering, after the checker has
already accepted the program, so an `expected.error` case can never
reach it: that path stops at the type check.

A case carrying `expected.lowering-error` asserts **both** halves. The
front end must accept the program, and `fern -target` must then reject
it with an error containing the file's trimmed contents. Asserting only
the second half would let a program the checker already rejects
masquerade as a lowering rule, which is the confusion the separate
sidecar exists to prevent — the runner reports that case by name and
says to move it to `expected.error`.

It runs at **both pointer widths**. A lowering rejection that fires on
one target and not the other is a portability defect in its own right,
so a case that holds at only one width fails rather than passing
quietly.

The same exclusivity rules apply as for `expected.error`: no run
sidecars, and a case cannot carry both files — which stage rejects a
program is precisely what these cases pin, and it cannot be two.

### A program that aborts cannot opt into wasm

An abort on wasm is a trap, and the wasm leg fails any case that traps,
since a trap is also how a miscompile shows there. The abort family
(`oob_index_read` and its siblings) therefore restricts `backends` to the
interpreter, x86-64 and arm64 and carries a `harness-limit` waiver. This is a property of how
the leg reads a run, not of the wasm target, which traps exactly as
intended.

### The wasm exit-code convention

Every target propagates `main`'s return value to the process exit code,
but WASI refuses an exit status outside `0..125`: wasmtime reports 1
instead. On the wasm leg a case whose `expected.exit` is 126 or more
therefore keeps its trap and rejection checks and loses its value check.

## Justifying a weaker assertion

The strongest thing a case can say is "this exact stdout, on all four
backends". There are two ways to say less — `match: contains`, and a
`backends` subset — and both are claims about the language, so a case
that uses either **must** carry a `meta` file saying why. A case that
uses neither must **not** carry one. Both directions are enforced.

`meta` is `key: value` lines; `#` starts a comment, and a line indented
relative to its key continues that key's value.

| Key | Meaning |
| --- | --- |
| `waiver` | Why the case asserts less. One of the four kinds below. Required. |
| `reason` | Prose. Required — a waiver with no stated reason is indistinguishable from an oversight. |
| `issue` | Bare issue number, no `#`. Required for `implementation-gap`, rejected for the others. |

The four kinds exist because they call for completely different
follow-up, and collapsing them is how a gap goes missing:

| `waiver` | Means | Follow-up |
| --- | --- | --- |
| `implementation-gap` | A backend has not implemented this yet. | Tracked by `issue`. The case should widen when it lands. |
| `harness-limit` | The runner cannot *observe* the behaviour on that backend. | None — not a language or backend defect. |
| `unspecified` | The language deliberately grants the freedom, as `docs/FLOAT-SEMANTICS.md` does for NaN bit-patterns. | None; cite the doc in `reason`. |
| `harness-self-test` | The case exercises the runner, not the language. | None. |

```
waiver: implementation-gap
issue: 1234
reason: the wasm backend has no <builtin> yet (it needs <the missing
  runtime piece>). <what does work there>.
```

That shape is illustrative rather than quoted: the waiver it was taken
from — `audit_monotonic_sleep`, opted out of wasm for a missing
`sleep_ms` — was deleted when #7947 landed the lowering, which is the
rule below working.

The rule matters in both directions. An unjustified weakening hides a
gap behind what looks like a passing case. A *stale* waiver is worse: it
is how an obsolete exclusion survives for years. `f64_sqrt` sat opted
out of arm64 and x86-64 with "sqrt needs libm; the `-nostdlib` native
backends can't link it" long after `sqrt` began lowering to a hardware
instruction with nothing to link — two backends of real coverage,
silently absent. It also matched on a substring "to stay robust to
trailing fractional digits" that the output does not have. Requiring the
waiver to be deleted the moment the case stops weakening is what turns
that from archaeology into a test failure.

## Adding a case

Drop in a directory. No Go code is required, and nothing needs
registering — the runners discover directories.

Prefer the strongest assertion the behaviour supports: byte-exact stdout
on all four backends, no `meta`. Reach for a waiver when that is
genuinely not available, not when it is inconvenient — the gap between
what a case asserts and what the language guarantees is exactly the kind
of unspecified behaviour this corpus exists to pin down.

## Runners

| Runner | What it does |
| --- | --- |
| `TestFernFixtures` (`internal/testing/e2e`) | Every case through the oracle: the run cases on the interpreter, and the compile-error cases through its checker; the lowering-error cases go through the self-host compiler (`fern -target`) at both pointer widths. |
| `TestFernFixturesSelfHost{Wasm,X86_64,Arm64,Interp,Check}` (`internal/testing/e2e`) | The same cases through `fern`, on each target, its interpreter and its checker, against per-leg divergence lists. Env-gated by `FERN_SELFHOST_FIXTURES=1`. |
| `TestConformanceCorpusFormat` (`internal/testing/e2e`) | Validates this document's format rules. Fast; no compilation. |
| `scripts/selfhost-emit-hashes` | Hashes self-host emit output per case, for byte-identity comparison. |

The corpus root is a single constant, `e2eharness.ConformanceCases`.
