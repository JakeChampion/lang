from pathlib import Path
import collections,hashlib,json,os,re,subprocess
root=Path('/tmp/lang-stdlib-cohesion-integration');out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/final-validation');work=Path('/tmp/lang-cohesion-alias-matrix');work.mkdir(exist_ok=True);native=out/'bootstrap/stage3';oracle=out/'oracle';stdlib=root/'internal/stdlib';env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};rows=[]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binaries={str(p):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in [native,oracle]},commands=rows)
def run(name,args,want='',flags=None):
 args=list(map(str,args));p=subprocess.run(args,cwd=root,env=dict(env,**(flags or{})),capture_output=True,text=True,timeout=180);row=dict(name=name,args=args,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=p.returncode==0 and(want is None or p.stdout==want));rows.append(row);(out/'receiver-alias-matrix.json').write_text(json.dumps(report,indent=2)+'\n');assert row['pass_'],row;return p
cases=[];data=(root/'conformance/cases/derive_from_json_import_alias/main.fern').read_text()
for alias in ['json','js','v','s','__fj_r','__fj_tag','__fj_Pair_0','__fj_v_value','__fja_r','__from_json_value','__from_json_text']:
 s=data.replace('js.',alias+'.').replace(' as js;',';'if alias=='json'else' as '+alias+';');cases.append(('json-alias-'+alias,s,''))
for name in ['generic_receiver_array_drop','generic_option_static_trait_helper']:cases.append((name,(root/'conformance/cases'/name/'main.fern').read_text(),'ok\n'))
for name,src,want in cases:
 d=work/name;d.mkdir(exist_ok=True);source=d/'main.fern';source.write_text(src);formats=[]
 for label,cli in [('Go',oracle),('self',native)]:
  run(name+'-'+label+'-check',[cli,'-check',source,stdlib]);run(name+'-'+label+'-interp',[cli,'-interp',source,stdlib],want)
  p=run(name+'-'+label+'-fmt',[cli,'-fmt',source,],None);formats.append(p.stdout);formatted=d/(label+'.fern');formatted.write_text(p.stdout);run(name+'-'+label+'-fmt-again',[cli,'-fmt',formatted],p.stdout);run(name+'-'+label+'-formatted-check',[cli,'-check',formatted,stdlib]);run(name+'-'+label+'-formatted-interp',[cli,'-interp',formatted,stdlib],want)
 assert formats[0]==formats[1],name
 for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
  binary=d/target;flags=dict(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_RC_TRACE='1');args=[native,'-target',target,'-o',binary]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[source,stdlib];run(name+'-build-'+target,args,flags=flags);p=run(name+'-run-'+target,runner+[binary],want);m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);assert m and m[1]==m[2]and m[3]=='0';live={};events=0
  for line in p.stderr.splitlines():
   m=re.fullmatch(r'rctrace ([af]) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16})',line)
   if not m:continue
   op,addr,size,_,_=m.groups();events+=1
   if op=='a':assert addr not in live;live[addr]=size
   else:assert live.pop(addr)==size
  assert not live and(events>0 or target!='x86-64-linux');rows[-1].update(trace_events=events,unpaired=0,balanced_census=True)
 for label,cli in [('Go',oracle),('self',native)]:run(name+'-'+label+'-Darwin',[cli,'-target','arm64-darwin','-o',d/('Darwin-'+label),source,stdlib])
 (out/'receiver-alias-matrix.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',name,flush=True)
assert len(rows)==260 and all(r['pass_']for r in rows);print('PASS',len(rows),'commands',flush=True)
