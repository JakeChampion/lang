from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path('/tmp/lang-stdlib-cohesion-integration');out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/final-validation');exe=Path('/tmp/lang-cohesion-97f-embedded-fern');work=Path('/tmp/lang-cohesion-97f-embedded-checks');work.mkdir(exist_ok=True);env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};rows=[]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binary=str(exe),binary_sha256=hashlib.sha256(exe.read_bytes()).hexdigest(),cwd='/tmp',commands=rows)
def run(name,args,want='',flags=None):
 args=list(map(str,args));p=subprocess.run(args,cwd='/tmp',env=dict(env,**(flags or{})),capture_output=True,text=True,timeout=180);row=dict(name=name,args=args,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=p.returncode==0 and(want is None or p.stdout==want));rows.append(row);(out/'embedded-results.json').write_text(json.dumps(report,indent=2)+'\n');assert row['pass_'],row;return p
for name in ['primitive_protocols_and_unsigned_num','primitive_display_without_imports','text_api_owners','unicode_linear_transforms','number_parsing','derive_from_json_import_alias','generic_receiver_array_drop','generic_option_static_trait_helper','nested_payloadless_constructor','generic_fn_value_array_methods','lanes_map_fusion']:
 case=root/'conformance/cases'/name;d=work/name;d.mkdir(exist_ok=True)
 for p in case.glob('*.fern'):shutil.copy2(p,d/p.name)
 source=d/'main.fern';want=(case/'expected.stdout').read_text()if(case/'expected.stdout').exists()else''
 run(name+'-check',[exe,'-check',source]);run(name+'-interp',[exe,'-interp',source],want)
 for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
  binary=d/target;args=[exe,'-target',target,'-o',binary]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[source];run(name+'-build-'+target,args,flags=dict(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_RC_TRACE='1'));p=run(name+'-run-'+target,runner+[binary],want);m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);assert m and m[1]==m[2]and m[3]=='0';allocations=int(m[1]);live={};events=0
  for line in p.stderr.splitlines():
   m=re.fullmatch(r'rctrace ([af]) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16})',line)
   if not m:continue
   op,addr,size,_,_=m.groups();events+=1
   if op=='a':assert addr not in live;live[addr]=size
   else:assert live.pop(addr)==size
  assert not live and(events>0 or target!='x86-64-linux' or allocations==0);rows[-1].update(trace_events=events,unpaired=0,balanced_census=True)
 run(name+'-Darwin-build',[exe,'-target','arm64-darwin','-o',d/'Darwin',source]);assert(d/'Darwin').read_bytes()[:4]==b'\xcf\xfa\xed\xfe'
run('version',[exe,'-version'],None);(out/'embedded-results.json').write_text(json.dumps(report,indent=2)+'\n');assert len(rows)==100;print('PASS',len(rows),'embedded commands')
