from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/tmp/lang-stdlib-cohesion-integration');out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/final-validation');pin=Path(os.environ['STAGE0']);digest=hashlib.sha256(pin.read_bytes()).hexdigest();env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};boot=json.loads((Path('/workspace/scratch/lang-stdlib-cohesion-integration/final-validation/bootstrap/bootstrap.json')).read_text());rows=['fern.fern/stage2\t'+str(boot['stages'][1]['bytes'])];report=[]
names=['fern.fern','drivers/asm_load_run.fern','drivers/asm_modload_run.fern','drivers/asm_ir_run.fern','drivers/asm_run.fern','drivers/wasm_ir_run.fern','drivers/wasm_run.fern','drivers/wasm_runio_run.fern','drivers/asm_pathprobe_run.fern','drivers/checker_modload_run.fern']
for name in names:
 binary=Path('/tmp/lang-cohesion-measured-driver');args=[str(pin),'-target','x86-64-linux','-o',str(binary),str(root/'compiler'/name),str(root/'internal/stdlib')];start=time.monotonic()
 with (out/(Path(name).stem+'-final-build.log')).open('w')as log:subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 row={'source':name,'arguments':args,'producer_sha256':digest,'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'seconds':time.monotonic()-start};report.append(row);rows.append(name+'\t'+str(row['bytes']));(out/'final-driver-sizes.txt').write_text('\n'.join(rows)+'\n');(out/'final-driver-builds.json').write_text(json.dumps(report,indent=2)+'\n');binary.unlink();print(name,row['bytes'],flush=True)
with(out/'final-driver-gate.log').open('w')as log:subprocess.run([str(root/'scripts/ci-check-driver-sizes'),str(root/'.github/selfhost-driver-sizes.txt'),str(out/'final-driver-sizes.txt')],cwd=root,env=dict(env,FERN_CI_SIZE_GATE_STRICT='1',FERN_SIZE_REPORT_COMPLETE='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
print('PASS all 11 strict sizes',flush=True)
