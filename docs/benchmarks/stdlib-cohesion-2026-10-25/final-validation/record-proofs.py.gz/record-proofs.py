from pathlib import Path
import ast,collections,gzip,hashlib,json,re,subprocess
root=Path('/tmp/lang-stdlib-cohesion-integration');out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/final-validation');source='97f686adeee9baa851df24b6b3d7ee2621fcc910';base='9344a74be12163ec9d95cf56a882e835a8a774fd';dest=root/'docs/benchmarks/stdlib-cohesion-2026-10-25/final-validation'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
for name in ['go-regressions.jsonl','targeted-regressions.jsonl','nested-pattern-regressions.jsonl']:
 p=out/name
 if not p.exists():p.write_bytes((out.parent/name).read_bytes())
def suite(name,count,packages):
 rows=[json.loads(s)for s in(out/name).read_text().splitlines()if s.startswith('{')];c=collections.Counter(r['Action']for r in rows if r.get('Test'));term=[r for r in rows if not r.get('Test')and r['Action']in ['pass','fail','skip']];assert c['run']==c['pass']==count and not c['skip']and not c['fail']and len(term)==packages and all(r['Action']=='pass'for r in term)and rows[-1]['Action']=='pass',(name,c);return dict(file=name,cases=count,passed=count,skipped=0,packages=packages)
tests=[suite('go-regressions.jsonl',2820,7),suite('native-regressions.jsonl',11021,1),suite('gnu-9.12-regressions.jsonl',5786,1),suite('targeted-regressions.jsonl',30,1),suite('nested-pattern-regressions.jsonl',7,1)]
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());native=out/'bootstrap/stage3';oracle=out/'oracle';assert boot['fixedpoint']and boot['source_git']==source and boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f';assert sha(native)==sha(out/'bootstrap/stage2')==boot['stages'][2]['sha256']=='628c9e6fb1eb4a0bd1923cd82f176199cf8269f5fdd069f56ddde1ec24dc0a68';assert native.stat().st_size==14545088
assert 'vcs.revision='+source in(out/'oracle-version.txt').read_text()and'vcs.modified=false'in(out/'oracle-version.txt').read_text()
matrices=[];total=balanced=events=0
spec=[('contracts-matrix-results.json',144,24),('verified-negative.json',6,0),('text-matrix-results.json',40,6),('package-compatibility/committed-matrix-final-results.json',90,15),('package-compatibility/package-project-matrix-final-results.json',19,3),('package-compatibility/reexport-matrix-final-results.json',86,12),('all-coreutils-checks.json',212,0),('numeric-matrix-results.json',80,9),('receiver-alias-matrix.json',260,39),('matrix-results.json',24,3),('io-result-matrix.json',80,12)]
for name,count,censuses in spec:
 d=json.loads((out/name).read_text());assert d.get('source_commit',d.get('core_commit'))==source;assert len(d['commands'])==count and all(r['pass_']for r in d['commands']),name
 if'binaries'in d:assert d['binaries'][str(native)]['sha256']==sha(native)and d['binaries'][str(oracle)]['sha256']==sha(oracle)
 else:assert d['compiler_sha256']==sha(native)and d['oracle_sha256']==sha(oracle)
 cs=[tuple(map(int,m.groups()))for r in d['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==censuses and all(a==b and n==0 for a,b,n in cs);n=sum(len(re.findall(r'(?m)^rctrace [af] ',r['stderr']))for r in d['commands']);total+=count;balanced+=len(cs);events+=n;matrices.append(dict(file=name,commands=count,balanced_censuses=censuses,raw_trace_events=n))
assert(total,balanced,events)==(1041,123,10026)
raw=json.loads((out/'final-matrix/results.json').read_text());wrapped=json.loads((out/'text-matrix-results.json').read_text());assert raw==[{k:v for k,v in r.items()if k!='pass_'}for r in wrapped['commands']]
embedded=json.loads((out/'embedded-results.json').read_text());assert embedded['source_commit']==source and len(embedded['commands'])==100 and all(r['pass_']for r in embedded['commands'])and sha(Path(embedded['binary']))==embedded['binary_sha256'];assert sum(r.get('trace_events',0)for r in embedded['commands'])==7698;cs=[tuple(map(int,m.groups()))for r in embedded['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==33 and all(a==b and n==0 for a,b,n in cs)
darwin=json.loads((out/'darwin-extra-builds.json').read_text());assert darwin['source_commit']==source and len(darwin['commands'])==10 and all(r['pass_']for r in darwin['commands'])
assert json.loads((out/'format-final.json').read_text())==dict(source_commit=source,files=1222,exit=0,selection='Makefile FERN_SRCS')
assert len((out/'final-driver-sizes.txt').read_text().splitlines())==11 and'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text()
for name in ['format-check.log','gofmt.log','vet.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert'Result: 0 errors, 0 warnings.'in(out/name).read_text()
perf=json.loads((out/'profiles/results.json').read_text());assert len(perf)==8
for name in ['integer','float-fast','float-exact','group-format']:
 a,b=[r for r in perf if r['case']==name];assert a['variant']=='before'and b['variant']=='after'and a['checksum']==b['checksum']and b['source_commit']==source and b['compiler_sha256']==sha(native)
cert=json.loads((out/'publication-source-certificate.json').read_text());assert cert['recorded_source']==source and not git('diff','--name-only',source,'HEAD','--',*cert['paths'])
assets=Path('/tmp/lang-cohesion-97f-embedded-stage');inventory=[dict(path=str(p.relative_to(assets)),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(assets.rglob('*'))if p.is_file()];(out/'embedded-asset-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
patch_paths=['.',':(exclude)docs/benchmarks'];patch=git('diff','--binary',base,source,'--',*patch_paths);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
files=['README.md','pr-body.md','readme-ste.log','pr-body-ste.log','record-proofs.py','publication-source-certificate.json','go-regressions.jsonl','native-regressions.jsonl','gnu-9.12-regressions.jsonl','targeted-regressions.jsonl','nested-pattern-regressions.jsonl','native-selection.json','gnu-selection.json','bootstrap.log','bootstrap/bootstrap.json','bootstrap/completed-intermediates.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','oracle-version.txt','contracts-matrix.py','contracts-matrix-results.json','contracts-matrix.log','verified-negative.py','verified-negative.json','verified-negative.log','check-text-matrix.py','check-text-matrix.log','text-matrix-results.json','final-matrix/results.json','check-all-coreutils.py','all-coreutils-checks.json','all-coreutils-checks.log','numeric-matrix.py','numeric-matrix-results.json','numeric-matrix.log','receiver-alias-matrix.py','receiver-alias-matrix.json','receiver-alias-matrix.log','nested-matrix.py','matrix-results.json','nested-matrix.log','documented-section.md','io-result-matrix.py','io-result-matrix.json','io-result-matrix.log','check-embedded.py','embedded-results.json','embedded-results.log','embedded-build.log','embed-stage.log','embedded-asset-inventory.json','check-sizes.py','check-sizes.log','final-driver-builds.json','final-driver-sizes.txt','final-driver-gate.log','format-final.json','format-check.log','gofmt.log','vet.log','darwin-extra-builds.json','profile-kernels.py','profile-kernels.log','profiles/results.json']
for name in ['f32-midpoints.fern','float-probe.fern']:(out/name).write_bytes((out.parent/name).read_bytes());files.append(name)
for stem in ['committed-matrix-final','package-project-matrix-final','reexport-matrix-final']:files.extend('package-compatibility/'+stem+s for s in ['.py','-results.json','.log'])
for case in ['integer','float-fast','float-exact','group-format']:
 for variant in ['before','after']:files.extend('profiles/'+case+'-'+variant+s for s in ['.fern','.callgrind','.compile.log','.profile.log'])
dest.mkdir(parents=True);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
for name in files:save(name.replace('/','__')+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
issues=[12704,13081,13082,13083,13084,13085,12718,13086,12713,13087,13089,13093,13164,13102,12844,13161]
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,base_commit=base,source_patch_paths=patch_paths,issues=issues,tests=tests,matrices=matrices,matrix_commands=1041,balanced_matrix_censuses=123,raw_matrix_trace_events=10026,embedded_commands=100,balanced_embedded_censuses=33,embedded_trace_events=7698,darwin_builds=63,compiler=dict(path=str(native),bytes=native.stat().st_size,sha256=sha(native)),oracle=dict(path=str(oracle),sha256=sha(oracle)),bootstrap=boot,performance=perf,artifacts=artifacts),indent=2)+'\n');print('PASS',len(artifacts),'artifacts; 19627 primary regression cases; 1041 matrix commands; 100 embedded commands')
