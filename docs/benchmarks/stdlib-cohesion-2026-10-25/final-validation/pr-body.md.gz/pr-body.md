Complete the dependent library and compiler fixes in one integration branch.

- Primitive scalars provide default text output without imports. Explicit methods retain precedence. Both frontends preserve char and usize receiver types.
- Text operations have canonical module owners. Unicode transforms avoid repeated copies of the accumulated prefix.
- Numeric modules provide typed parsers and consistent integer formats. Validators share parser behavior. Parsers preserve negative zero and correct f32 values.
- JSON derives preserve import aliases and generated-name hygiene. Generic static calls retain receiver bindings and their helper calls.
- Reader, Writer, and Dir results pass directly through the interpreter. The current stage0 pin permits removal of the I/O compatibility module.
- Nested constructors preserve pattern coverage. Missing qualified functions report E087 before the loader changes their names.

Validation:

- All 2,820 selected Go checks pass across seven packages without skips.
- All 11,021 selected native checks pass without skips. The feature census and complexity gates pass.
- All 5,786 selected GNU 9.12 parity checks pass without skips.
- All 1,041 matrix and caller commands pass. All 123 runtime allocation counts balance.
- The embedded compiler passes 100 commands. All 33 runtime allocation counts balance, with 7,698 balanced x86 trace events.
- A fresh official bootstrap reaches a fixed point at 14,545,088 bytes. All 11 strict driver size gates pass.
- All 1,222 source format checks pass. Go format and vet checks pass.
- The matrices build 63 Darwin images. Darwin execution requires CI on Apple Silicon.

Plain string views can enter inlined functions when their results contain no views.
The regression checks owned temporaries, borrowed slices, shared callers, and returned views across the supported executable targets.

The numeric comparison retains equal checksums and zero fast-path allocations.
The integer parser uses 946,106 instructions against the reference's 695,221.
The fast float parser uses 1,907,573 against 1,875,829.
The grouped integer formatter decreases from 9,606,033 instructions to 4,694,929.
The capsule retains these costs and makes no general speed claim.

The proof is `docs/benchmarks/stdlib-cohesion-2026-10-25/final-validation`.
Earlier capsules retain their recorded source scopes.
Full CI must pass before merge.

Closes #12704.
Closes #13081.
Closes #13082.
Closes #13083.

Closes #13084.
Closes #13085.
Closes #12718.
Closes #13086.

Closes #12713.
Closes #13087.
Closes #13089.
Closes #13093.

Closes #13164.
Closes #13102.
Closes #12844.
Closes #13161.
