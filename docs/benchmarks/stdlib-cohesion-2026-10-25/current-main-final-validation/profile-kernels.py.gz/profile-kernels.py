from pathlib import Path
import hashlib,json,os,re,subprocess
out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation/profiles');out.mkdir(exist_ok=True)
compilers=dict(before=Path('/workspace/scratch/lang-text-api-cohesion/module-driver-integration/bootstrap/stage3'),after=Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation/bootstrap/stage3'))
roots=dict(before=Path('/tmp/lang-text-api-cohesion-publish'),after=Path('/tmp/lang-stdlib-cohesion-integration'))
env={k:v for k,v in os.environ.items() if not k.startswith('FERN_')}
rows=[]
cases={
 'integer':(4096,['42','-2147483648','2147483647','123456789'], 'i32', 'sum = sum + value as i64;'),
 'float-fast':(4096,['1.25','3.141592653589793','6.022e23','1.5e-300'], 'f64', 'sum = sum + (f64_bits(value) & 65535);'),
 'float-exact':(8,['1.00000000000000011102230246251565404236316680908203125','7.4109846876186981626485318930233205854758970392148714663837852375101326090531312779794975454245398856969484704316857659638998506553390969459816219401617281718945106978546710679176872575177347315553308e-324'], 'f64', 'sum = sum + (f64_bits(value) & 65535);'),
 'group-format':(4096,[],None,'sum = sum + (123456789).to_string_with_sep("·").len() as i64;'),
}
for name,(count,texts,kind,body) in cases.items():
 for variant,root in roots.items():
  compiler=compilers[variant]
  source='import "std/string";\nimport "std/i32";\n'
  if kind=='f64':source+='import "std/f64";\n'
  source+='function main(): i32 {\n'
  if texts:source+='let texts: string[] = '+json.dumps(texts)+';\n'
  source+='let sum: i64 = 0i64;\nlet before: i64 = __heap_alloc_count();\nlet i: i32 = 0;\nwhile (i < '+str(count)+') {\n'
  if kind:
   parse='texts[i % '+str(len(texts))+'].parse_'+('int' if kind=='i32' else 'float')+'()'
   if variant=='after':parse=kind+'.parse_'+kind+'(texts[i % '+str(len(texts))+'])'
   source+='match ('+parse+') {\n'+('Some' if variant=='before' else 'Ok')+'(value) => { '+body+' },\n'+('None' if variant=='before' else 'Err(_)')+' => { return 1; }\n}\n'
  else:source+=body+'\n'
  source+='i = i + 1;\n}\nlet allocations: i64 = __heap_alloc_count() - before;\nprint(sum); print(allocations);\nreturn 0;\n}\n'
  path=out/(name+'-'+variant+'.fern');path.write_text(source);binary=path.with_suffix('')
  with path.with_suffix('.compile.log').open('w') as log:
   subprocess.run([str(compiler),'-target','x86-64-linux','-o',str(binary),str(path),str(root/'internal/stdlib')],cwd=root,env=dict(env,FERN_STRICT_IR='1'),stdout=log,stderr=subprocess.STDOUT,check=True)
  with path.with_suffix('.profile.log').open('w') as log:
   r=subprocess.run(['valgrind','--tool=callgrind','--callgrind-out-file='+str(path.with_suffix('.callgrind')),str(binary)],env=env,cwd=root,stdout=subprocess.PIPE,stderr=log,text=True,check=True)
  profile=path.with_suffix('.callgrind').read_text()
  ir=int(re.search(r'(?m)^summary: (\d+)',profile)[1])
  lines=r.stdout.strip().splitlines();row=dict(case=name,variant=variant,iterations=count,checksum=lines[0],allocations=int(lines[1]),instructions=ir,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),build_args=[str(compiler),'-target','x86-64-linux','-o',str(binary),str(path),str(root/'internal/stdlib')],source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size)
  rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
 for a,b in [(rows[-2],rows[-1])]:assert a['checksum']==b['checksum'],(a,b)
