from pathlib import Path
import hashlib,json,os,re,subprocess

root=Path('/tmp/lang-stdlib-cohesion-integration')
out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation')
work=Path('/tmp/lang-cohesion-numeric-matrix')
work.mkdir(exist_ok=True)
native=out/'bootstrap/stage3'
oracle=out/'oracle'
stdlib=root/'internal/stdlib'
env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')}
rows=[]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binaries={str(p):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in [native,oracle]},commands=rows)

def run(name,args,want='',code=None,census=False,flags=None):
    args=list(map(str,args))
    p=subprocess.run(args,cwd=root,env=dict(env,**(flags or{})),capture_output=True,text=True,timeout=180)
    good=p.returncode==0 and (want is None or p.stdout==want)
    if code:good=p.returncode==1 and set(re.findall(r'error\[(E\d+)\]',p.stderr))=={code}
    events=0;live={}
    if census:
        m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr)
        good=good and bool(m and m[1]==m[2]and m[3]=='0')
        for line in p.stderr.splitlines():
            if not line.startswith('rctrace '):continue
            _,op,address,size,*_=line.split();events+=1
            if op=='a':assert address not in live;live[address]=size
            elif op=='f':assert live.pop(address)==size
            else:raise AssertionError(line)
        good=good and not live
    row=dict(name=name,args=args,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=good)
    if census:row.update(trace_events=events,unpaired=len(live))
    rows.append(row)
    (out/'numeric-matrix-results.json').write_text(json.dumps(report,indent=2)+'\n')
    assert good,row
    return p.stdout

sources=[('number_parsing',root/'conformance/cases/number_parsing/main.fern'),('f32-midpoints',out.parent/'f32-midpoints.fern'),('float-probe',out.parent/'float-probe.fern')]
for name,source in sources:
    formats=[]
    for tag,cli in [('Go',oracle),('self',native)]:
        run(name+'-'+tag+'-check',[cli,'-check',source,stdlib])
        run(name+'-'+tag+'-interp',[cli,'-interp',source,stdlib])
        text=run(name+'-'+tag+'-fmt',[cli,'-fmt',source],want=None)
        formats.append(text)
        path=work/(name+'-'+tag+'.fern');path.write_text(text)
        run(name+'-'+tag+'-fmt-again',[cli,'-fmt',path],want=text)
        run(name+'-'+tag+'-formatted-check',[cli,'-check',path,stdlib])
        run(name+'-'+tag+'-formatted-interp',[cli,'-interp',path,stdlib])
        binary=work/(name+'-'+tag+'-arm64-darwin')
        run(name+'-'+tag+'-darwin-build',[cli,'-target','arm64-darwin','-o',binary,source,stdlib])
    assert formats[0]==formats[1],name
    for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
        binary=work/(name+'-'+target)
        args=[native,'-target',target,'-o',binary]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[source,stdlib]
        flags=dict(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1')
        if name=='number_parsing'and target=='x86-64-linux':flags['FERN_RC_TRACE']='1'
        run(name+'-'+target+'-build',args,flags=flags)
        run(name+'-'+target+'-run',runner+[binary],census=True)
    print('PASS',name,flush=True)

negative=[
    ('removed-string-int','import "std/string"; function main(): i32 { return "1".parse_int().unwrap_or(0); }','E043'),
    ('removed-string-float','import "std/string"; function main(): i32 { let n = "1".parse_float(); return 0; }','E043'),
    ('removed-core-parser','import "core/int"; function main(): i32 { return int.parse_int_radix("1", 10).unwrap_or(0); }','E087'),
    ('missing-qualified-parser','import "std/i64"; function main(): i32 { let n = i64.parse_i66("1"); return 0; }','E087'),
    ('removed-decimal-module','import "std/parse"; function main(): i32 { return 0; }','E086'),
]
for name,text,code in negative:
    path=work/(name+'.fern');path.write_text(text+'\n')
    for tag,cli in [('Go',oracle),('self',native)]:
        for mode in ['-check','-interp']:run(name+'-'+tag+mode,[cli,mode,path,stdlib],code=code)
assert len(rows)==80 and all(r['pass_']for r in rows)
print('PASS 80 commands; nine balanced censuses; six Darwin builds',flush=True)
