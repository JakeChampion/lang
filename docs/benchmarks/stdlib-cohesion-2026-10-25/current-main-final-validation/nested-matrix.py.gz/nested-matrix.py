from pathlib import Path
import hashlib, json, os, re, subprocess

root = Path('/tmp/lang-stdlib-cohesion-integration')
out = Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation')
work = Path('/tmp/lang-cohesion-nested-matrix')
work.mkdir(exist_ok=True)
native = out/'bootstrap/stage3'
oracle = out/'oracle'
stdlib = root/'internal/stdlib'
env = {k:v for k,v in os.environ.items() if not k.startswith('FERN_')}
rows = []
report = dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(), binaries={str(p):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in [native,oracle]}, commands=rows)

def run(name,args,expected='',error=None,census=False,variables=None):
    args = list(map(str,args))
    p = subprocess.run(args,cwd=root,env=dict(env,**(variables or {})),capture_output=True,text=True,timeout=180)
    good = p.returncode == 0 and (expected is None or p.stdout == expected)
    if error: good = p.returncode == 1 and error in p.stdout+p.stderr
    if census:
        m = re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr)
        good = good and bool(m and m[1]==m[2] and m[3]=='0')
    row = dict(name=name,args=args,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=good)
    rows.append(row)
    (out/'matrix-results.json').write_text(json.dumps(report,indent=2)+'\n')
    assert good,row
    return p.stdout

source = root/'conformance/cases/nested_payloadless_constructor/main.fern'
negative = root/'conformance/cases/nested_payload_binding_unreachable/main.fern'
formats = []
for name,cli in [('Go',oracle),('self',native)]:
    run(name+'-check',[cli,'-check',source,stdlib])
    run(name+'-interp',[cli,'-interp',source,stdlib])
    text = run(name+'-fmt',[cli,'-fmt',source],expected=None)
    formats.append(text)
    formatted = work/(name+'.fern')
    formatted.write_text(text)
    run(name+'-fmt-again',[cli,'-fmt',formatted],expected=text)
    run(name+'-formatted-check',[cli,'-check',formatted,stdlib])
    run(name+'-formatted-interp',[cli,'-interp',formatted,stdlib])
    for mode in ['-check','-interp']:
        run(name+'-negative'+mode,[cli,mode,negative,stdlib],error='E028')
    run(name+'-darwin-build',[cli,'-target','arm64-darwin','-o',work/(name+'-arm64-darwin'),source,stdlib])
assert formats[0] == formats[1]
for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
    binary = work/target
    args = [native,'-target',target,'-o',binary]
    if target == 'wasm32-wasi': args += ['-emit','command-module']
    run(target+'-build',args+[source,stdlib],variables=dict(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_RC_TRACE='1'))
    run(target+'-run',runner+[binary],census=True)
text = (root/'site/src/content/docs/reference/language-features.md').read_text().split('## Constructors inside payload patterns',1)[1].split('\n## ',1)[0]
example = re.search(r'```fern\n(.*?)```',text,re.S).group(1)
assert example == source.read_text()
(out/'documented-section.md').write_text('## Constructors inside payload patterns'+text)
assert len(rows)==24 and all(r['pass_'] for r in rows)
print('PASS',len(rows),'commands; three balanced censuses; two Darwin builds; documentation equals fixture')
