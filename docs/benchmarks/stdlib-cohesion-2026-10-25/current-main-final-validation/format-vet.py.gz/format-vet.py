from pathlib import Path
import subprocess,json
root=Path('/tmp/lang-stdlib-cohesion-integration');out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation');files=[f for f in subprocess.check_output(['git','ls-files','*.fern','*.fern.md'],cwd=root,text=True).splitlines()if not f.startswith('conformance/')and'/testdata/'not in f];p=subprocess.run([str(out/'oracle'),'-fmt','-d',*files],cwd=root,capture_output=True,text=True);(out/'format-check.log').write_text(p.stdout+p.stderr);(out/'format-final.json').write_text(json.dumps(dict(count=len(files),exit=p.returncode,selection='Makefile FERN_SRCS'),indent=2)+'\n');assert p.returncode==0
files=subprocess.check_output(['git','ls-files','*.go'],cwd=root,text=True).splitlines();p=subprocess.run(['gofmt','-l',*files],cwd=root,capture_output=True,text=True);(out/'gofmt.log').write_text(p.stdout+p.stderr);assert p.returncode==0 and not p.stdout
with(out/'vet.log').open('w')as log:subprocess.run(['go','vet','./...'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('PASS format',len(files),'Go files and Go vet')
