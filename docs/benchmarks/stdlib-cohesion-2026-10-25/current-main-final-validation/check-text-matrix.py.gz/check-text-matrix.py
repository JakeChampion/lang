from pathlib import Path
import hashlib, json, os, re, subprocess

root = Path('/tmp/lang-stdlib-cohesion-integration')
out = Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation/final-matrix')
out.mkdir(exist_ok=True)
compiler = Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation/bootstrap/stage3')
oracle = out.parent / 'oracle'
stdlib = root / 'internal/stdlib'
env = {k:v for k,v in os.environ.items() if not k.startswith('FERN_')}
rows = []

def run(name, args, variables=None, bad=None, census=False):
    r = subprocess.run(list(map(str,args)), cwd=root, env=dict(env, **(variables or {})), capture_output=True)
    row = dict(name=name, args=list(map(str,args)), exit=r.returncode, stdout=r.stdout.decode(), stderr=r.stderr.decode())
    rows.append(row)
    (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
    text = row['stdout']+row['stderr']
    if bad:
        assert r.returncode == 1 and 'error[' in text and bad in text, row
    else:
        assert r.returncode == 0 and not row['stdout'], row
        assert 'fern-sanitizer:' not in text, row
        if census:
            m = re.search(r'(?m)^leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)$', row['stderr'])
            assert m and m[1]==m[2] and m[3]=='0', row
    return row

for name in ['text_api_owners','unicode_linear_transforms']:
    source = root/'conformance/cases'/name/'main.fern'
    for engine, args in [('Go-check',[oracle,'-check',source]),('Go-interp',[oracle,'-interp',source]),('self-check',[compiler,'-check',source,stdlib]),('self-interp',[compiler,'-interp',source,stdlib])]:
        run(name+'-'+engine,args)
    for target in ['x86-64-linux','arm64-linux','wasm32-wasi']:
        binary = out/(name+'-'+target)
        flags = dict(FERN_STRICT_IR='1', FERN_SANITIZE='1', FERN_LEAKCHECK='1', FERN_RC_TRACE='1')
        args = [compiler,'-target',target,'-o',binary]
        if target == 'wasm32-wasi': args += ['-emit','command-module']
        run(name+'-compile-'+target,args+[source,stdlib],variables=flags)
        runner = [] if target=='x86-64-linux' else ['qemu-aarch64'] if target=='arm64-linux' else ['wasmtime','run']
        run(name+'-run-'+target,runner+[binary],census=True)

cases = {
    'string-does-not-own-Unicode': ('import "std/string";\nfunction main(): i32 { let s = "a".to_upper(); return 0; }', 'to_upper'),
    'string-does-not-own-decoding': ('import "std/string";\nfunction main(): i32 { return "a".codepoint_count(); }', 'codepoint_count'),
    'removed-count-alias': ('import "std/string";\nfunction main(): i32 { return "a".count_matches("a"); }', 'count_matches'),
    'removed-replacement-alias': ('import "std/string";\nfunction main(): i32 { let s = "a".replacen("a", "b", 1); return 0; }', 'replacen'),
    'removed-encode-alias': ('import "std/utf8";\nfunction main(): i32 { let s = utf8.utf8_encode(65 as char); return 0; }', 'utf8_encode'),
    'removed-scalar-alias': ('import "std/string";\nfunction main(): i32 { let s = string.string_from_codepoint(65 as char); return 0; }', 'string_from_codepoint'),
    'removed-bulk-alias': ('import "std/string";\nfunction main(): i32 { let s = string.string_from_codepoints([65 as char]); return 0; }', 'string_from_codepoints'),
    'removed-decode-alias': ('import "std/utf8";\nfunction main(): i32 { let s = utf8.codepoints("a"); return 0; }', 'codepoints'),
    'removed-free-case-alias': ('import "std/unicode";\nfunction main(): i32 { let s = unicode.to_upper("a"); return 0; }', 'to_upper'),
    'removed-byte-letter-alias': ('import "std/i32";\nfunction main(): i32 { if ((65 as u8).is_ascii_alpha()) { return 1; } return 0; }', 'is_ascii_alpha'),
}
negative = out/'negative'
negative.mkdir(exist_ok=True)
for name,(text,bad) in cases.items():
    source = negative/(name+'.fern')
    source.write_text(text+'\n')
    for engine,args in [('Go',[oracle,'-check',source]),('self',[compiler,'-check',source,stdlib])]:
        run(name+'-'+engine,args,bad=bad)

h=hashlib.sha256()
for name in sorted(subprocess.check_output(['git','ls-files','compiler','internal/stdlib'],cwd=root,text=True).splitlines()):
    h.update(name.encode()+b'\0'+(root/name).read_bytes()+b'\0')
(out/'identity.json').write_text(json.dumps(dict(source_sha256=h.hexdigest(), compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),oracle_sha256=hashlib.sha256(oracle.read_bytes()).hexdigest(),commands=len(rows)),indent=2)+'\n')
print('All',len(rows),'matrix commands pass')
