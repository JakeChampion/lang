Primitive protocols now cover char, usize, unsigned integers, and implicit scalar display. Scalar calls report ordinary arity errors. Text APIs have distinct owners, and Unicode transforms build their output with one output buffer.

Numeric modules provide typed integer and float parsers. Decimal parsers preserve negative zero, and JSON f32 reads use their destination width. Missing qualified module functions report E087.

The semantic pass retains generic receiver bindings and generic helpers used by enum static calls. I/O handles return Result directly, and the obsolete io_outcome bridge is removed. The pattern documentation includes nested payloadless constructors.

Constant initializers are evaluated before acceptance. Failed division, modulo, or other constant operations report E093. Literal range errors keep E047, and valid integer arithmetic wraps at its declared width.

Validation:

- All 2,823 Go checks pass across seven packages. All 1,387 targeted native checks pass without skips, with 185 constant checks and the complete verifier corpus.
- All 1,041 matrix commands pass. All 123 runtime allocation counts balance. The matrices cover both frontends, three executable targets, eleven JSON aliases, I/O close results, and all 106 coreutils programs.
- The compiler passes 100 commands with its embedded library. All 33 runtime allocation counts balance. The checks retain 17,724 balanced allocation trace events.
- A fresh official bootstrap produces identical stages 2 and 3 at 14,566,352 bytes. All 11 strict driver size gates pass.
- All 1,223 source format checks pass. Go format, Go vet, feature census, and the unchanged complexity gate pass. The matrices build 63 Darwin images. Darwin execution requires CI on Apple Silicon.

The latest proof is `docs/benchmarks/stdlib-cohesion-2026-10-25/current-main-final-validation`. Earlier capsules retain their recorded source scopes. They include 11,021 native checks and 5,786 GNU 9.12 parity checks without skips.

The numeric measurements retain equal checksums and report the costs directly. The integer parser uses about 36% more instructions in this kernel. The fast float parser uses about 1.7% more. The group separator formatter reduces instructions and allocations. Full CI must pass before merge.

Closes #12704.

Closes #13081.

Closes #13082.

Closes #13083.

Closes #13084.

Closes #13085.

Closes #12718.

Closes #13086.

Closes #12713.

Closes #13087.

Closes #13089.

Closes #13093.

Closes #13164.

Closes #13102.

Closes #12844.

Closes #13161.

Closes #13174.
