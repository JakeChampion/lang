from pathlib import Path
import hashlib,json,os,re,subprocess
root=Path('/tmp/lang-stdlib-cohesion-integration');out=Path('/workspace/scratch/lang-stdlib-cohesion-integration/current-main-final-validation');work=Path('/tmp/lang-cohesion-io-result-matrix');work.mkdir(exist_ok=True);native=out/'bootstrap/stage3';oracle=out/'oracle';stdlib=root/'internal/stdlib';env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};rows=[]
source=(root/'internal/testing/e2eharness/buffered_writer_bytes.go').read_text();writer=re.search(r'const BufferedWriterBytesProgram = `([^`]*)`',source,re.S)[1]
want='directé'.encode()+bytes(range(256))+bytes([195,255,97,0,128,255,97])+b'tail'+bytes([255,0,128,254,193,255,0,254,255,0,128,254])+bytes([255,193,128,254,255,128,254,0,128,255,255])+bytes([255,0,128,0,255,0,128,255,128,255,128])*64
read_all='''import "std/io";
function main(): i32 {
  let Ok(bytes) = io.read_all_stdin_bytes() else { return 1; };
  if (bytes.len() != 256) { return 2; }
  for i in 0..256 { if (bytes[i] != i as u8) { return 3; } }
  return 0;
}
'''
reader_close='''function main(): i32 {
  let reader: Reader = stdin();
  if let Err(_) = reader.close() { return 1; }
  if let Ok(_) = reader.close() { return 2; }
  return 0;
}
'''
writer_close=reader_close.replace('reader: Reader = stdin()','writer: Writer = stdout()').replace('reader.close()', 'writer.close()')
cases=[('stdin-bytes',read_all,bytes(range(256)),b''),('buffered-bytes',writer,b'',want),('reader-close',reader_close,b'',b''),('writer-close',writer_close,b'',b'')]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binaries={str(p):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in [native,oracle]},commands=rows)
def run(name,args,want=b'',stdin=b'',flags=None):
 args=list(map(str,args));p=subprocess.run(args,cwd=root,env=dict(env,**(flags or{})),input=stdin,capture_output=True,timeout=180);row=dict(name=name,args=args,exit=p.returncode,stdin_hex=stdin.hex(),stdout_hex=p.stdout.hex(),stderr=p.stderr.decode('utf8','replace'),pass_=p.returncode==0 and(want is None or p.stdout==want));rows.append(row);(out/'io-result-matrix.json').write_text(json.dumps(report,indent=2)+'\n');assert row['pass_'],row;return p
for name,source,input_bytes,expected in cases:
 d=work/name;d.mkdir(exist_ok=True);path=d/'main.fern';path.write_text(source);formats=[]
 for label,cli in [('Go',oracle),('self',native)]:
  run(name+'-'+label+'-check',[cli,'-check',path,stdlib]);run(name+'-'+label+'-interp',[cli,'-interp',path,stdlib],expected,input_bytes);p=run(name+'-'+label+'-fmt',[cli,'-fmt',path],None);formats.append(p.stdout);formatted=d/(label+'.fern');formatted.write_bytes(p.stdout);run(name+'-'+label+'-fmt-again',[cli,'-fmt',formatted],p.stdout);run(name+'-'+label+'-formatted-check',[cli,'-check',formatted,stdlib]);run(name+'-'+label+'-formatted-interp',[cli,'-interp',formatted,stdlib],expected,input_bytes)
 assert formats[0]==formats[1],name
 for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]:
  binary=d/target;args=[native,'-target',target,'-o',binary]+(['-emit','command-module']if target=='wasm32-wasi'else[])+[path,stdlib];run(name+'-build-'+target,args,flags=dict(FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_RC_TRACE='1'));p=run(name+'-run-'+target,runner+[binary],expected,input_bytes);stderr=p.stderr.decode();m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',stderr);assert m and m[1]==m[2]and m[3]=='0';live={};events=0
  for line in stderr.splitlines():
   m=re.fullmatch(r'rctrace ([af]) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16}) ([0-9a-f]{16})',line)
   if not m:continue
   op,addr,size,_,_=m.groups();events+=1
   if op=='a':assert addr not in live;live[addr]=size
   else:assert live.pop(addr)==size
  assert not live;rows[-1].update(trace_events=events,unpaired=0,balanced_census=True)
 for label,cli in [('Go',oracle),('self',native)]:run(name+'-'+label+'-Darwin',[cli,'-target','arm64-darwin','-o',d/('Darwin-'+label),path,stdlib])
 (out/'io-result-matrix.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',name,flush=True)
assert len(rows)==80;print('PASS',len(rows),'commands',flush=True)
