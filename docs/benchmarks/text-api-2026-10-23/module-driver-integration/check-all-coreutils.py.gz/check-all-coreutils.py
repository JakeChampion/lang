from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/lang-text-api-cohesion-publish')
out=Path('/workspace/scratch/lang-text-api-cohesion/module-driver-integration')
oracle=out/'oracle'
native=out/'bootstrap/stage3'
rows=[]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binaries={str(p):dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size)for p in [oracle,native]},commands=rows)
for source in sorted((root/'coreutils').glob('*.fern')):
    for name,cli in [('Go',oracle),('self',native)]:
        args=[str(cli),'-check',str(source),str(root/'internal/stdlib')]
        p=subprocess.run(args,cwd=root,capture_output=True,text=True,timeout=90)
        row=dict(source=str(source),frontend=name,args=args,exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=p.returncode==0)
        rows.append(row)
        (out/'all-coreutils-checks.json').write_text(json.dumps(report,indent=2)+'\n')
        if not row['pass_']:print('FAIL',name,source.name,p.stderr,flush=True)
    print('DONE',source.name,flush=True)
assert all(r['pass_']for r in rows)
print('PASS',len(rows),'commands',flush=True)
