Move text operations to their library owners and remove duplicate aliases.
UTF-8 owns scalar encode and decode functions.
Unicode owns case conversion and grapheme reversal.

String owns byte operations, replacement, and match counts.
Grapheme reversal copies each byte once and preserves malformed input bytes.

All 2,495 Go checks and 4,593 native checks pass without skips.
All 385 matrix commands pass, with 60 balanced runtime allocation counts.
Both frontends also check all 106 coreutils programs.

The official bootstrap reaches equal stage two and stage three images.
All 11 strict size gates and 1,222 source format checks pass.
The installed compiler passes 33 embedded library checks.

Two Darwin images build but are not executed locally.

The encode and replace probe reduces allocations from 4,115 to four.
Its instruction count increases by 1.65 percent.
The case conversion and reverse probes reduce allocations and instruction counts.

The proof capsule retains raw logs, source commits, and binary hashes.
See `docs/benchmarks/text-api-2026-10-23/module-driver-integration`.

Closes #12718.
Closes #13086.
