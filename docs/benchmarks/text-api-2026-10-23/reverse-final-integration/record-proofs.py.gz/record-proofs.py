from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess
root=Path('/tmp/lang-text-api-cohesion-publish');out=Path('/workspace/scratch/lang-text-api-cohesion/reverse-final-integration');source='c2f3af1b24b65d908f895f8f2ac8598bd02ed932';base='0e9d56bda5dfbe2fda224f7e6c5b68599d34f531';dest=root/'docs/benchmarks/text-api-2026-10-23/reverse-final-integration'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
def suite(name,count,packages):
 rows=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];c=collections.Counter(r['Action']for r in rows if r.get('Test'));terminal=[r for r in rows if not r.get('Test')and r['Action']in['pass','fail','skip']]
 assert c['run']==c['pass']==count and not c['fail']and not c['skip'],(name,c)
 assert len(terminal)==packages and all(r['Action']=='pass'for r in terminal)and rows[-1]['Action']=='pass'
 return dict(file=name,cases=count,packages=packages,skipped=0)
tests=[suite('generator-tests.jsonl',16,1),suite('go-regressions-final.jsonl',2495,6),suite('library-regressions.jsonl',67,1),suite('native-final-regressions.jsonl',4586,1)]
native=out/'bootstrap/stage3';oracle=out/'oracle';boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==source and boot['fixedpoint']and boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f';assert sha(native)==sha(out/'bootstrap/stage2')==boot['stages'][2]['sha256']=='8d174fa691d49128a4b2f2b2a9442f94787fa0f0164e025a8bc5945e98d8d5a5'
assert len((out/'final-driver-sizes.txt').read_text().splitlines())==11 and 'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text();version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+source in version and 'vcs.modified=false'in version
matrix=json.loads((out/'final-matrix/results.json').read_text());assert len(matrix)==40;cs=[tuple(map(int,m.groups()))for r in matrix if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==6 and all(a==b and n==0 for a,b,n in cs);identity=json.loads((out/'final-matrix/identity.json').read_text());assert identity['compiler_sha256']==sha(native)and identity['oracle_sha256']==sha(oracle)
matrices=[dict(file='final-matrix/results.json',commands=40,balanced_censuses=6)]
for name,count,census in [('contracts-matrix-results.json',144,24),('verified-negative.json',6,0),('package-compatibility/committed-matrix-final-results.json',90,15),('package-compatibility/package-project-matrix-final-results.json',19,3),('package-compatibility/reexport-matrix-final-results.json',86,12)]:
 d=json.loads((out/name).read_text());assert d.get('core_commit',d.get('source_commit'))==source and len(d['commands'])==count and all(r['pass_']for r in d['commands'])
 if 'binaries'in d:assert d['binaries'][str(native)]['sha256']==sha(native)and d['binaries'][str(oracle)]['sha256']==sha(oracle)
 else:assert d['compiler_sha256']==sha(native)and d['oracle_sha256']==sha(oracle)
 cs=[tuple(map(int,m.groups()))for r in d['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==census and all(a==b and n==0 for a,b,n in cs);matrices.append(dict(file=name,commands=count,balanced_censuses=census))
embed=json.loads((out/'embedded-results.json').read_text());assert embed['source_commit']==source and len(embed['commands'])==33 and all(r['pass_']for r in embed['commands'])and sha(Path(embed['binary']))==embed['binary_sha256'];assert sum(r.get('trace_events',0)for r in embed['commands'])==792
darwin=json.loads((out/'reverse-darwin-builds.json').read_text());assert darwin['source_commit']==source and len(darwin['commands'])==2
for r in darwin['commands']:assert r['exit']==0 and not r['executed']and sha(Path(r['args'][4]))==r['binary_sha256']
assert json.loads((out/'format-final.json').read_text())==dict(source_commit=source,files=1222,exit=0,selection='Makefile FERN_SRCS')
for name in ['vet.log','gofmt.log','format-check.log']:assert not(out/name).read_bytes()
assert 'Result: 0 errors, 0 warnings.'in(out/'readme-ste.log').read_text()
profiles=json.loads((out/'kernel-profile-results.json').read_text());assert profiles['source_commit']==source and len(profiles['rows'])==6
for i in range(0,6,2):
 a,b=profiles['rows'][i:i+2];assert a['version']=='before'and b['version']=='after'and a['source_sha256']==b['source_sha256'];old=a['stdout'].splitlines();new=b['stdout'].splitlines()
 for r in [a,b]:assert sha(Path(r['build_args'][4]))==r['binary_sha256']and sha(Path(r['build_args'][5]))==r['source_sha256']
 if a['probe']=='reverse-clusters':
  for k in [0,3,6]:assert old[k:k+2]==new[k:k+2]and int(new[k+2])<int(old[k+2])
 else:assert old[:-1]==new[:-1]and int(new[-1])<int(old[-1])
 if a['probe']!='phase1-probe':assert b['instructions']<a['instructions']
patch=git('diff','--binary',base,source);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True);dest.mkdir(parents=True,exist_ok=False);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
files=['bootstrap/bootstrap.json','bootstrap/completed-intermediates.json','bootstrap/cross-scope-identical-images.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','oracle-version.txt','generator-tests.jsonl','go-regressions-final.jsonl','library-regressions.jsonl','native-final-regressions.jsonl','go-regressions.jsonl','check-matrix.py','final-matrix/results.json','final-matrix/identity.json','contracts-matrix.py','contracts-matrix-results.json','verified-negative.py','verified-negative.json','embedded-results.json','embedded-results-final.log','reverse-darwin-builds.json','final-driver-builds.json','final-driver-sizes.txt','final-driver-gate.log','check-sizes.py','format-final.json','format-check.log','vet.log','gofmt.log','readme-ste.log','profile-kernels.py','kernel-profile-results.json','record-proofs.py']
for stem in ['committed-matrix-final','package-project-matrix-final','reexport-matrix-final']:files.extend(['package-compatibility/'+stem+suffix for suffix in ['.py','-results.json','.log']])
for probe in ['phase1-probe','unicode-loop-baseline','reverse-clusters']:
 files.append('profiles/'+probe+'.fern')
 for tag in ['before','after']:
  files.extend(['profiles/'+probe+'-'+tag+suffix for suffix in ['.callgrind','.log','.stdout','-build.log']])
for name in files:save(name.replace('/','__')+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
save('check-embedded.py.gz',gzip.compress(Path('/workspace/scratch/lang-check-active-embedded.py').read_bytes(),mtime=0))
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,baseline_commit=base,issues=[12718,13086],tests=tests,matrices=matrices,embedded_commands=33,balanced_trace_events=792,darwin_builds=2,darwin_local_execution=False,profiles=profiles,compiler=dict(path=str(native),sha256=sha(native),bytes=native.stat().st_size),oracle=dict(path=str(oracle),sha256=sha(oracle)),artifacts=artifacts),indent=2)+'\n');print('PASS',len(artifacts),'artifacts; 7148 primary checks; 385 matrix commands')
