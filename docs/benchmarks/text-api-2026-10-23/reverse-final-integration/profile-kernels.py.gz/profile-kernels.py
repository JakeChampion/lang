from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
root=Path('/tmp/lang-text-api-cohesion-publish');out=Path('/workspace/scratch/lang-text-api-cohesion/reverse-final-integration');work=out/'profiles';work.mkdir(exist_ok=True)
before_root=Path('/tmp/lang-text-profile-baseline');before=Path('/workspace/scratch/lang-primitive-protocols/latest-package-integration/bootstrap/stage3');after=out/'bootstrap/stage3';oracle=out/'oracle'
env={k:v for k,v in os.environ.items()if not k.startswith('FERN_')};rows=[]
for name in ['phase1-probe','unicode-loop-baseline','reverse-clusters']:
    source=work/(name+'.fern');original=Path('/workspace/scratch/lang-text-api-cohesion/utf8-dependency-followup')/(name+'.fern')if name=='reverse-clusters'else Path('/workspace/scratch/lang-text-api-cohesion')/(name+'.fern');shutil.copy2(original,source)
    subprocess.run([str(oracle),'-fmt','-w',str(source)],cwd=root,env=env,check=True,capture_output=True)
    source_hash=hashlib.sha256(source.read_bytes()).hexdigest();pair=[]
    for tag,compiler,lib,tree in [('before',before,before_root/'internal/stdlib',before_root),('after',after,root/'internal/stdlib',root)]:
        binary=work/(name+'-'+tag);args=list(map(str,[compiler,'-target','x86-64-linux','-o',binary,source,lib]));built=subprocess.run(args,cwd=tree,env=env,capture_output=True,text=True,timeout=180);(work/(name+'-'+tag+'-build.log')).write_text(built.stdout+built.stderr);assert built.returncode==0,built.stderr
        normal=subprocess.run([str(binary)],env=env,capture_output=True,text=True,timeout=180);assert normal.returncode==0,(name,tag,normal)
        raw=work/(name+'-'+tag+'.callgrind');command=['valgrind','--tool=callgrind','--callgrind-out-file='+str(raw),str(binary)];profile=subprocess.run(command,env=env,capture_output=True,text=True,timeout=300);assert profile.returncode==0 and profile.stdout==normal.stdout,(name,tag,profile.stderr);(work/(name+'-'+tag+'.log')).write_text(profile.stderr);(work/(name+'-'+tag+'.stdout')).write_text(profile.stdout);instructions=int(re.search(r'Collected\s*:\s*(\d+)',profile.stderr)[1])
        row=dict(probe=name,version=tag,source_sha256=source_hash,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size,build_args=args,profile_args=command,instructions=instructions,stdout=profile.stdout);rows.append(row);pair.append(row)
    a,b=pair;old=a['stdout'].splitlines();new=b['stdout'].splitlines()
    if name=='reverse-clusters':
        assert len(old)==len(new)==9
        for i in [0,3,6]:assert old[i:i+2]==new[i:i+2]and int(new[i+2])<int(old[i+2])
    else:assert old[:-1]==new[:-1]and int(new[-1])<int(old[-1])
    if name=='unicode-loop-baseline':assert b['instructions']<a['instructions'],(name,a['instructions'],b['instructions'])
    b['instruction_ratio']=b['instructions']/a['instructions']
    report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),rows=rows);(out/'kernel-profile-results.json').write_text(json.dumps(report,indent=2)+'\n');print(name,a['instructions'],'->',b['instructions'],flush=True)
