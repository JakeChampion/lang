from pathlib import Path
import subprocess,re,json,hashlib,time
root=Path('/workspace/lang-csv-convert-errors-publish');out=Path('/workspace/scratch/lang-csv-convert-errors-publish/value-namespace-validation');logs=out/'matrix';logs.mkdir(exist_ok=True);oracle=out/'oracle';prior=out.parent/'main-codec-system-integration';s=(root/'internal/testing/e2ecompiler/self_host_generic_supertraits_test.go').read_text();constants=dict(re.findall(r'const (\w+) = `([^`]*)`',s));cases=re.findall(r'\{"([^"]+)", (?:(\w+) \+ )?`([^`]*)`, "([^"]*)"\}',s);assert len(cases)==25,len(cases)
rows=[];core=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();report={'source_commit':core,'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'native_evidence_source':'618ad7990f972c4b7f285cd28ad1a6183a49154d','runs':rows};fingerprint=hashlib.sha256()
for name in sorted(subprocess.check_output(['git','ls-files','compiler','internal/stdlib'],cwd=root,text=True).splitlines()):fingerprint.update(name.encode()+b'\0'+(root/name).read_bytes()+b'\0')
assert fingerprint.hexdigest()==json.loads((prior/'bootstrap/bootstrap.json').read_text())['source_sha256'];report['unchanged_native_source_sha256']=fingerprint.hexdigest()
def save():(out/'go-matrix.json').write_text(json.dumps(report,indent=2)+'\n')
def run(name,args,code=''):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,capture_output=True,timeout=180);(logs/(name+'.stdout')).write_bytes(r.stdout);(logs/(name+'.stderr')).write_bytes(r.stderr);rows.append({'name':name,'args':list(map(str,args)),'exit':r.returncode,'expected_diagnostic':code,'seconds':time.monotonic()-start});save();print(name,r.returncode,flush=True)
 assert (r.returncode!=0 and ('['+code+']').encode()in r.stdout+r.stderr)if code else r.returncode==0,(name,r.stdout,r.stderr)
for name,prefix,source,code in cases:
 d=logs/name;d.mkdir(exist_ok=True);p=d/'main.fern';p.write_text(constants.get(prefix,'')+source)
 for n in ['api','values']:(d/(n+'.fern')).write_text(constants[n])
 run(name+'-check',[oracle,'-check',p],code)
 if not code:run(name+'-interp',[oracle,'-interp',p])
for matrix in ['final-matrix.json','json-compatibility/matrix.json']:
 m=json.loads((prior/matrix).read_text())
 for row in m['runs']:
  if Path(row['args'][0]).name!='oracle':continue
  args=[str(oracle)]+row['args'][1:]
  run('compat-'+row['name'],args)
assert len(rows)==54,len(rows);report['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
