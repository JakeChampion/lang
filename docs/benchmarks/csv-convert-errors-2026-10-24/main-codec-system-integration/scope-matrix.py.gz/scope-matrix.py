from pathlib import Path
import re,subprocess,json,os,time,hashlib
root=Path('/workspace/lang-csv-convert-errors-publish'); out=Path('/workspace/scratch/lang-csv-convert-errors-publish/main-codec-system-integration/scope-matrix');out.mkdir(exist_ok=True)
s=(root/'internal/testing/e2ecompiler/self_host_generic_supertraits_test.go').read_text()
api=re.search(r'const api = `([^`]*)`',s)[1]
constants=dict(re.findall(r'const (\w+) = `([^`]*)`',s))
cases=re.findall(r'\{"([^"]+)", (?:(\w+) \+ )?`([^`]*)`, "([^"]*)"\}',s)
selfbin=Path('/workspace/scratch/lang-csv-convert-errors-publish/main-codec-system-integration/bootstrap/stage3'); oracle=Path('/workspace/scratch/lang-csv-convert-errors-publish/main-codec-system-integration/oracle'); stdlib=root/'internal/stdlib'
rows=[]; report={'diagnostic_prototype':False,'source_commit':'618ad7990f972c4b7f285cd28ad1a6183a49154d','producer_sha256':hashlib.sha256(selfbin.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows,'source_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff'],cwd=root)).hexdigest()}
def run(name,args,code=''):
 start=time.monotonic(); p=subprocess.run(list(map(str,args)),capture_output=True,timeout=180,cwd=root,env=dict(os.environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1'))
 (out/(name+'.stdout')).write_bytes(p.stdout);(out/(name+'.stderr')).write_bytes(p.stderr)
 row={'name':name,'argv':list(map(str,args)),'exit':p.returncode,'seconds':time.monotonic()-start};rows.append(row);save();print(name,p.returncode,flush=True)
 assert (p.returncode!=0 and ('['+code+']').encode() in p.stderr+p.stdout) if code else p.returncode==0,(name,p.stdout,p.stderr)
 return p,row
def save():(out/'matrix.json').write_text(json.dumps(report,indent=2)+'\n')
for name,prefix,src,code in cases:
 d=out/name;d.mkdir(exist_ok=True);path=d/'main.fern';path.write_text(constants.get(prefix,'')+src);(d/'api.fern').write_text(api)
 for engine,bin in [('go',oracle),('self',selfbin)]:
  run(name+'-'+engine+'-check',[bin,'-check',path]+([stdlib]if engine=='self'else[]),code)
  if not code:run(name+'-'+engine+'-interp',[bin,'-interp',path]+([stdlib]if engine=='self'else[]))
 if code:continue
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=d/target;run(name+'-build-'+target,[selfbin,'-target',target,'-o',dest,path,stdlib])
  if target=='arm64-darwin':continue
  args=[dest] if target=='x86-64-linux' else ['qemu-aarch64',dest] if target=='arm64-linux' else ['wasmtime','run',dest]
  p,row=run(name+'-run-'+target,args);m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);assert m,(name,target,p.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
report['complete']=True;save();print('PASS',len(cases),'cases',len(rows),'commands',flush=True)
