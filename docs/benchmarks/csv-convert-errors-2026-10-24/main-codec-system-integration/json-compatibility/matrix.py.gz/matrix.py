from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-csv-convert-errors-publish');out=Path('/workspace/scratch/lang-csv-convert-errors-publish/main-codec-system-integration/json-compatibility');logs=out/'matrix';logs.mkdir(exist_ok=True);stdlib=root/'internal/stdlib';oracle=out.parent/'oracle';producers={'current':Path('/workspace/scratch/lang-csv-convert-errors-publish/main-codec-system-integration/bootstrap/stage3')};fixtures={'json-object':(root/'tests/stdlib/json_object_test.fern',9),'collection-vocabulary':(root/'tests/stdlib/collection_vocabulary_test.fern',5)};rows=[]
metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'producers':{n:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for n,p in producers.items()},'fixtures':{n:{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tap_tests':t}for n,(p,t)in fixtures.items()},'runs':rows}
def save():(out/'matrix.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(name,args,extra={}):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(os.environ,**extra),capture_output=True,timeout=240)
 (logs/(name+'.stdout')).write_bytes(r.stdout);(logs/(name+'.stderr')).write_bytes(r.stderr);row={'name':name,'args':list(map(str,args)),'exit':r.returncode,'seconds':time.monotonic()-start};rows.append(row);save();print(row,flush=True);assert r.returncode==0,(name,r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace'));return r,row
for name,(source,tap)in fixtures.items():
 golden=None
 for mode in ['-check','-interp']:
  r,_=run(name+'-go'+mode,[oracle,mode,source])
  if mode=='-interp':
   assert ('# pass '+str(tap)).encode()in r.stdout and b'# fail 0'in r.stdout and ('1..'+str(tap)).encode()in r.stdout,r.stdout;golden=r.stdout
 for producer,compiler in producers.items():
  prefix=name+'-'+producer
  for mode in ['-check','-interp']:
   r,_=run(prefix+mode,[compiler,mode,source,stdlib])
   if mode=='-interp':assert r.stdout==golden,(prefix,'interpreter output')
  for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
   dest=logs/(prefix+'-'+target);run(prefix+'-build-'+target,[compiler,'-target',target,'-o',dest,source,stdlib],{'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
   if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
   args=[dest]if target=='x86-64-linux'else['qemu-aarch64',dest]if target=='arm64-linux'else['wasmtime','run',dest]
   r,row=run(prefix+'-run-'+target,args);assert r.stdout==golden,(prefix,target,'runtime output');m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,r.stderr;a,f,l=map(int,m.groups());assert a==f and l==0,(prefix,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
metadata['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
