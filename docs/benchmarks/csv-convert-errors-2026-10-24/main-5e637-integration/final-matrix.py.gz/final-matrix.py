from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-csv-convert-errors-publish');scratch=Path('/workspace/scratch/lang-csv-convert-errors-publish');out=scratch/'final-matrix';out.mkdir(exist_ok=True)
oracle=scratch/'final-oracle';compiler=scratch/'final-validation/bootstrap/stage3';stdlib=root/'internal/stdlib'
convert=re.search(r'const tryConvertSrc = `([\s\S]*?)`',(root/'internal/testing/e2e/try_convert_test.go').read_text())[1];(scratch/'conversion-final.fern').write_text(convert)
fixtures={'csv':(root/'tests/stdlib/csv_test.fern',0),'csv_fields':(root/'conformance/cases/csv_fields/main.fern',5),'audit_std_textfmt':(root/'conformance/cases/audit_std_textfmt/main.fern',0),'conversion':(scratch/'conversion-final.fern',149),'generic_supertraits':(Path('/workspace/scratch/lang-generic-supertraits/inherited.fern'),0)}
# The component CLI maps every nonzero guest main result to process exit 1.
# Assert exact fixture values inside wrappers and expose them in stdout.
fixture_sources=[]
for name,(path,want) in list(fixtures.items()):
 original=path;source=path.read_text()
 if want:
  source='import "std/i32";\n'+source.replace('function main(): i32', 'function __fixture_main(): i32',1)
  source+='\nfunction main(): i32 { let value: i32 = __fixture_main(); print(value.to_string()); if (value != '+str(want)+') { return 1; } return 0; }\n'
  path=scratch/(name+'-wrapped.fern');path.write_text(source);fixtures[name]=(path,0)
 fixture_sources.append({'name':name,'original_path':str(original),'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'original_expected_main_result':want,'matrix_path':str(path),'matrix_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(scratch/'final-fixture-sources.json').write_text(json.dumps(fixture_sources,indent=2)+'\n')
rows=[];goldens={};env=dict(os.environ)
metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows}
def save():(scratch/'final-matrix.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(name,args,want=0,extra=None):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(env,**(extra or {})),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 row={'name':name,'args':list(map(str,args)),'seconds':time.monotonic()-start,'exit':r.returncode,'expected_exit':want,'stdout_bytes':len(r.stdout),'stderr_bytes':len(r.stderr)};rows.append(row);save();print(row,flush=True);assert r.returncode==want,(name,r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace'));return r,row
for name,(path,want) in fixtures.items():
 for engine,tool in [('go',oracle),('self',compiler)]:
  for mode in ['-check','-interp']:
   r,_=run(name+'-'+engine+mode,[tool,mode,path]+([stdlib]if engine=='self'else[]),want if mode=='-interp'else 0)
   if mode=='-interp':
    if name=='csv':assert b'# pass 23' in r.stdout and b'# fail 0' in r.stdout and b'1..23' in r.stdout,r.stdout
    if name in goldens:assert r.stdout==goldens[name],(name,engine,'interpreter output mismatch')
    goldens[name]=r.stdout
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=out/(name+'-'+target)
  run(name+'-build-'+target,[compiler,'-target',target,'-o',dest,path,stdlib],extra={'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest] if target=='x86-64-linux' else ['qemu-aarch64',dest] if target=='arm64-linux' else ['wasmtime','run',dest]
  r,row=run(name+'-run-'+target,args,want)
  m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,(name,target,r.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
  assert r.stdout==goldens[name],(name,target,'execution output mismatch')
metadata['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
