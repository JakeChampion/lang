from pathlib import Path
import subprocess,json,hashlib,re,os,datetime
root=Path('/workspace/lang-indirect-method-result-20261110-2255');out=Path("/workspace/lang-checker-union-index-20261110-1540/build/baseline-bank-20261111-0010")
source='29b1234d0699d6b42d7d85bbcd82dbfb92c6dce2';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
state={'source':source,'head':'8440203b0ce52b7d1fbe07a9e23a1c9eb0307b03','runs':[],'scope':'Replay exact CI corrective rows against old and updated baselines. Negative controls retain the unchanged canonical comparator assertions. No compiler benchmark rerun or performance claim.'}
def save():(out/'validation.json').write_text(json.dumps(state,indent=2)+'\n')
def run(label,args,expected=0,env=None):
 row={'label':label,'args':args,'expected_exit':expected,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};state['runs'].append(row);save()
 with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:r=subprocess.run(args,cwd=root,stdout=so,stderr=se,env=env,timeout=180)
 row.update(exit_code=r.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save();assert r.returncode==expected,(label,r.returncode,expected)
save()
try:
 log=(out/'130211808249/tool-decoded.raw').read_text(encoding='utf-8')
 pattern=r'(x86_64/checker\.(?:cliff_bytes|cliff_count|allocs|frees)) measured (\d+) against a baseline of (\d+) — over its ([0-9.]+)% tolerance'
 rows={}
 for key,new,old,tol in re.findall(pattern,log):
  value={'key':key,'old':int(old),'new':int(new),'tolerance_percent':float(tol)}
  assert key not in rows or rows[key]==value
  rows[key]=value
 expected={'x86_64/checker.allocs':(39556378,40440085),'x86_64/checker.frees':(39556378,40440085),'x86_64/checker.cliff_bytes':(38416000,39116232),'x86_64/checker.cliff_count':(369099,373694)}
 assert set(rows)==set(expected)
 for key,value in rows.items():assert (value['old'],value['new'])==expected[key] and value['tolerance_percent']==1
 changes=[]
 for file,kind in [('alloc-baseline.txt','alloc'),('cliff-baseline.txt','cliff')]:
  old=(out/('before-'+file)).read_text();new=(root/'.github'/file).read_text()
  def table(text):return {r.split()[0]:(int(r.split()[1]),r.split()[2:]) for r in text.splitlines() if r.strip() and not r.lstrip().startswith('#')}
  a,b=table(old),table(new);assert a.keys()==b.keys()
  report=[]
  for key in a:
   assert a[key][1]==b[key][1]
   if a[key]!=b[key]:
    assert key in rows and a[key][0]==rows[key]['old'] and b[key][0]==rows[key]['new']
    changes.append(key)
   report.append(key+'\t'+str(rows[key]['new'])+'\n')
  (out/(kind+'-ci-values.report')).write_text(''.join(report))
 assert set(changes)==set(expected)
 (out/'row-moves.json').write_text(json.dumps({'source':source,'run':42916398671,'job':130211808249,'measurement_date':'2026-11-10','bank_date':'2026-11-11','rows':list(rows.values()),'default_tolerance_percent':1,'unchanged_all_other_rows_and_tolerances':True,'report_scope':'The .report files derive the exact corrective lines from the complete decoded CI log. They are not downloaded artifact reports.','protocol':'Original CI cliff and allocation scripts set FERN_RC_CERTIFY=0 for the lowering counters. Their source and flags remain unchanged. Allocation counts are balanced; live-byte and normal-compiler timing claims are outside this record.'},indent=2)+'\n')
 sources={}
 for name in ['scripts/ci-check-perf','scripts/perf-gate-selftest.mjs','scripts/cliff-bench','scripts/selfhost-alloc-bench','.github/workflows/perf.yml','bootstrap/stage0.lock']:
  f=root/name;blob=subprocess.check_output(['git','rev-parse',source+':'+name],cwd=root,text=True).strip();assert f.read_bytes()==subprocess.check_output(['git','cat-file','blob',blob],cwd=root)
  sources[name]={'git_blob':blob,'sha256':sha(f)}
 (out/'source-identities.json').write_text(json.dumps({'source':source,'files':sources},indent=2)+'\n')
 env=dict(os.environ)
 for k in ['FERN_CI_PERF_GATE_STRICT','FERN_CI_PERF_GATE_MAX_DRIFT','FERN_PERF_TOLERANCE_PERCENT']:env.pop(k,None)
 env['FERN_CI_PERF_GATE_STRICT']='1'
 for file,kind in [('alloc-baseline.txt','alloc'),('cliff-baseline.txt','cliff')]:
  run(kind+'-old-gate',[str(root/'scripts/ci-check-perf'),str(out/('before-'+file)),str(out/(kind+'-ci-values.report'))],1,env)
  run(kind+'-new-gate',[str(root/'scripts/ci-check-perf'),str(root/'.github'/file),str(out/(kind+'-ci-values.report'))],0,env)
 tmp=out/'negative-control-scratch';tmp.mkdir()
 env=dict(os.environ,TMPDIR=str(tmp))
 run('canonical-negative-controls',['/workspace/scratch/lang-node22-20261110-2320/node-v22.23.4-linux-x64/bin/node','--import',str(out/'preserve-controls.mjs'),str(root/'scripts/perf-gate-selftest.mjs')],0,env)
 cases=sorted((out/'negative-controls').glob('case-*'))
 assert len(cases)>0 and any(json.loads((c/'result.json').read_text())['status']==1 for c in cases)
 state['captured_comparator_children']=len(cases)
 run('whitespace',['git','diff','--check'])
 state.update(exit_code=0,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except Exception as e:state.update(exit_code=1,error=repr(e),finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save();raise

