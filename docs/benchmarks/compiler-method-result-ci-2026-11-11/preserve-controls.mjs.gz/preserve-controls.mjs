import fs from "node:fs";
import cp from "node:child_process";
import path from "node:path";
import { syncBuiltinESMExports } from "node:module";
const out = "/workspace/lang-checker-union-index-20261110-1540/build/baseline-bank-20261111-0010/negative-controls";
const root = "/workspace/lang-indirect-method-result-20261110-2255";
fs.mkdirSync(out, { recursive: true });
const saved = new Set();
const makeTemp = fs.mkdtempSync.bind(fs);
const remove = fs.rmSync.bind(fs);
const spawn = cp.spawnSync.bind(cp);
let sequence = 0;
fs.mkdtempSync = (prefix, options) => {
  const result = makeTemp(prefix, options);
  if (path.basename(String(prefix)) === "perf-gate-") saved.add(result);
  return result;
};
fs.rmSync = (target, options) => {
  if (saved.has(String(target))) {
    fs.writeFileSync(path.join(out, "preserved-scratch.json"), JSON.stringify([...saved], null, 2) + "\n");
    return;
  }
  return remove(target, options);
};
cp.spawnSync = (command, args, options) => {
  const result = spawn(command, args, options);
  if (command === path.join(root, "scripts/ci-check-perf")) {
    const record = path.join(out, "case-" + String(++sequence).padStart(3, "0"));
    fs.mkdirSync(record);
    const inputs = [];
    for (const [i, name] of ["baseline.txt", "report.txt"].entries()) {
      const exists = fs.existsSync(args[i]);
      inputs.push({ path: args[i], present: exists });
      if (exists) fs.copyFileSync(args[i], path.join(record, name));
    }
    fs.writeFileSync(path.join(record, "stdout"), result.stdout ?? "");
    fs.writeFileSync(path.join(record, "stderr"), result.stderr ?? "");
    const names = ["FERN_CI_PERF_GATE_STRICT", "FERN_CI_PERF_GATE_MAX_DRIFT", "FERN_PERF_TOLERANCE_PERCENT"];
    const environment = Object.fromEntries(names.filter(k => options.env[k] !== undefined).map(k => [k, options.env[k]]));
    fs.writeFileSync(path.join(record, "result.json"), JSON.stringify({ command, args, inputs, environment, status: result.status, signal: result.signal, error: result.error?.message ?? null }, null, 2) + "\n");
  }
  return result;
};
syncBuiltinESMExports();

