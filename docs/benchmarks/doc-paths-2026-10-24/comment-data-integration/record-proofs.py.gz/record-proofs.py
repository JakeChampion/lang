from pathlib import Path
import subprocess,hashlib,json,gzip,collections
root=Path('/workspace/lang-doc-paths-publish');out=Path('/workspace/scratch/lang-doc-paths/comment-data-integration');core='814e894c1bc25c71fa22255560fbffa8c1cc1952';base='7b9bcc9a3e9aba8ffbd25020e13a0f27795aa45b'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core
es=[json.loads(s)for s in(out/'tests.jsonl').read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);assert c['run']==238 and not c['skip']and not c['fail'];assert len([e for e in es if e['Action']=='pass'and'Test'not in e])==2
assert not git('diff',base,core,'--','compiler','internal/stdlib')
changed_go=[n for n in git('diff','--name-only',base,core,'--','*.go').decode().splitlines()];assert changed_go==['internal/testing/sourcelint/doc_paths_test.go'],changed_go
workflow='.github/workflows/macos.yml'
strip=lambda b:b'\n'.join(x for x in b.splitlines()if x.strip()and not x.lstrip().startswith(b'#'))
assert strip(git('show',base+':'+workflow))==strip((root/workflow).read_bytes())
archive='docs/records/stdlib-implementation-strategy-2026-10-23.md';raw=(root/archive).read_bytes();quote=b''.join(x[2:]if x.startswith(b'> ')else x[1:]for x in raw.splitlines(keepends=True)if x.startswith(b'>'));assert len(quote)==6687;assert hashlib.sha256(quote).hexdigest()=='163eb97a58a96c4c0a64516be40122974a627a2031d0501990a420f18a499ea7';assert quote in git('show','8547531b2a3464b0e086527d76668a47e468f948:docs/LANGUAGE-DIRECTION.md');assert raw==git('show','fc07e2e5257d7ab0f916ff492f086df59b5c4d3d:'+archive)
go=(out/'go-E044.txt').read_bytes();native=(out/'self-E044.txt').read_bytes();assert go==native
canonical=(root/'internal/syntax/diag/explanations/E044.md').read_bytes();body=canonical.split(b'\n',1)[1].lstrip(b'\n');assert go.split(b'\n',1)[1].strip()==body.strip()and b'compiler/lift.fern'in go
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+core in version and'vcs.modified=false'in version
boot=json.loads(Path('/workspace/scratch/lang-grammar/comment-data-integration/bootstrap/bootstrap.json').read_text());assert boot['fixedpoint']and boot['source_git']==base
hash_source=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):hash_source.update(n.encode()+b'\0'+(root/n).read_bytes()+b'\0')
assert hash_source.hexdigest()==boot['source_sha256']
rows=json.loads((out/'audit.json').read_text());assert not[r for r in rows if r['status']in['reference','policy','tracker']]
checks={'source_commit':core,'dependency_base':base,'compiler_stdlib_changed':False,'production_go_changed':False,'macos_workflow_only_comments_changed':True,'original_strategy_exact_quoted_bytes':len(quote),'quote_sha256':hashlib.sha256(quote).hexdigest(),'canonical_E044_sha256':hashlib.sha256(canonical).hexdigest(),'go_self_output_equal':True,'native_reads_current_library_explanations':True,'source_sha256':hash_source.hexdigest(),'native_sha256':boot['stages'][2]['sha256'],'go_oracle_sha256':hashlib.sha256((out/'oracle').read_bytes()).hexdigest(),'tests':238,'failures':0,'skips':0,'historical_or_proposed_paths':len(rows),'missing_living_paths':0}
(out/'source-and-explanation-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
dest=root/'docs/benchmarks/doc-paths-2026-10-24/comment-data-integration';dest.mkdir(parents=True);artifacts=[]
for n in ['record-proofs.py','tests.jsonl','audit.json','audit.py','audit.log','go-E044.txt','self-E044.txt','oracle-version.txt','source-and-explanation-checks.json']:
 data=gzip.compress((out/n).read_bytes(),mtime=0);(dest/(n+'.gz')).write_bytes(data);artifacts.append({'path':n+'.gz','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
patch=git('diff','--binary',base,core);subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);data=gzip.compress(patch,mtime=0);(dest/'change.patch.gz').write_bytes(data);artifacts.append({'path':'change.patch.gz','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(dest/'artifacts.json').write_text(json.dumps({'checks':checks,'artifacts':artifacts},indent=2)+'\n')
(dest/'README.md').write_text('''# Documentation path checks after the current main merge

The source commit is `814e894c1bc25c71fa22255560fbffa8c1cc1952`.
The compiler and library bytes match the grammar branch exactly.
Production Go code remains unchanged.
The macOS workflow change affects comments only.

All 238 source and diagnostic test cases pass across two packages.
No cases fail or skip.
The audit finds zero missing paths in living documents.
The 560 historical or proposed references retain their declared document status.

The archive preserves all 6687 quoted bytes of the earlier library strategy.
Those bytes occur exactly in the named original source commit.
The current strategy describes the Fern compiler and library modules.

A fresh clean Go oracle and the final native grammar compiler emit identical E044 help.
Both outputs use the canonical explanation body and point to `compiler/lift.fern`.
The native compiler reads the current library explanation files at runtime.
The manifest retains compiler hashes, source checks, test output and the exact source patch.
''')
print('Verified',len(artifacts),'artifacts, 238 tests, zero missing living paths')
