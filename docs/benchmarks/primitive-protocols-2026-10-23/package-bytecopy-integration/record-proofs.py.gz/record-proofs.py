from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess
root=Path('/tmp/lang-primitive-protocols-publish');out=Path('/workspace/scratch/lang-primitive-protocols/package-bytecopy-integration');source='90ada84f0329462cd1bd55c586c157a68a2dea22';base='9344a74be12163ec9d95cf56a882e835a8a774fd';dest=root/'docs/benchmarks/primitive-protocols-2026-10-23/package-bytecopy-integration'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
tests=[]
for name,count,packages in [('go-regressions.jsonl',2479,5),('native-regressions.jsonl',4593,1)]:
 rows=[json.loads(l)for l in(out/name).read_text().splitlines()if l.startswith('{')];c=collections.Counter(r['Action']for r in rows if r.get('Test'));terminal=[r for r in rows if not r.get('Test')and r['Action']in ['pass','fail','skip']];assert c['run']==c['pass']==count and not c['fail']and not c['skip'] and len(terminal)==packages and all(r['Action']=='pass'for r in terminal)and rows[-1]['Action']=='pass';tests.append(dict(file=name,cases=count,passed=count,skipped=0,packages=packages))
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());native=out/'bootstrap/stage3';oracle=out/'oracle';assert boot['fixedpoint']and boot['source_git']==source and boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f';assert sha(native)==sha(out/'bootstrap/stage2')==boot['stages'][2]['sha256']=='eb2d4f35eb59aee709ebcda447c4c9da54b071681d19e1630e2bab37172d5930'
assert 'vcs.revision='+source in(out/'oracle-version.txt').read_text()and'vcs.modified=false'in(out/'oracle-version.txt').read_text()
matrices=[]
for name,count,censuses in [('contracts-matrix-results.json',144,24),('verified-negative.json',6,0),('package-compatibility/committed-matrix-final-results.json',90,15),('package-compatibility/package-project-matrix-final-results.json',19,3),('package-compatibility/reexport-matrix-final-results.json',86,12),('all-coreutils-checks.json',212,0)]:
 d=json.loads((out/name).read_text());assert d.get('core_commit',d.get('source_commit'))==source and len(d['commands'])==count and all(r['pass_']for r in d['commands']);assert (d['binaries'][str(native)]['sha256']==sha(native)and d['binaries'][str(oracle)]['sha256']==sha(oracle))if'binaries'in d else(d['compiler_sha256']==sha(native)and d['oracle_sha256']==sha(oracle))
 cs=[tuple(map(int,m.groups()))for r in d['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==censuses and all(a==b and n==0 for a,b,n in cs);matrices.append(dict(file=name,commands=count,balanced_censuses=censuses))
for name,count in [('embedded-results.json',26),('darwin-builds.json',8)]:
 d=json.loads((out/name).read_text());assert d['source_commit']==source and len(d['commands'])==count and all(r['pass_']for r in d['commands'])
assert sha(Path('/tmp/lang-primitive-90ada-embedded-fern'))==json.loads((out/'embedded-results.json').read_text())['binary_sha256']
assert json.loads((out/'format-final.json').read_text())==dict(source_commit=source,files=1222,exit=0,selection='Makefile FERN_SRCS')
assert len((out/'final-driver-sizes.txt').read_text().splitlines())==11 and'Every driver measured here is within 5%'in(out/'final-driver-gate.log').read_text()
for name in ['vet.log','gofmt.log','format-check.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert 'Result: 0 errors, 0 warnings.'in(out/name).read_text()
perf=json.loads((out/'kernel-profile-results.json').read_text());assert perf['rows'][0]['stdout']==perf['rows'][1]['stdout']and perf['instruction_ratio']<=1;assert perf['rows'][1]['compiler_sha256']==sha(native)and perf['rows'][1]['source_commit']==source
cert=dict(recorded_source=source,current_source=source,paths=['compiler','internal','cmd','bootstrap/stage0.lock','.github/selfhost-driver-sizes.txt','go.mod','go.sum']);(out/'publication-source-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
patch=git('diff','--binary',base,source);subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
files=['README.md','pr-body.md','readme-ste.log','pr-body-ste.log','record-proofs.py','publication-source-certificate.json','go-regressions.jsonl','native-regressions.jsonl','bootstrap.log','bootstrap/bootstrap.json','bootstrap/completed-intermediates.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','oracle-version.txt','contracts-matrix.py','contracts-matrix-results.json','contracts-matrix.log','verified-negative.py','verified-negative.json','verified-negative.log','check-all-coreutils.py','all-coreutils-checks.json','all-coreutils-checks.log','check-embedded.py','embedded-results.json','embedded-results.log','embedded-build.log','embed-stage.log','check-sizes.py','check-sizes.log','final-driver-builds.json','final-driver-sizes.txt','final-driver-gate.log','format-final.json','format-check.log','gofmt.log','vet.log','darwin-builds.json','profile-kernels.py','profile-kernels.log','kernel-cost.fern','kernel-profile-results.json','kernel-before.callgrind','kernel-after.callgrind','kernel-before.log','kernel-after.log','kernel-before.stdout','kernel-after.stdout']
for stem in ['committed-matrix-final','package-project-matrix-final','reexport-matrix-final']:files.extend('package-compatibility/'+stem+s for s in ['.py','-results.json','.log'])
dest.mkdir(parents=True);artifacts=[]
def save(name,data):
 p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
for name in files:save(name.replace('/','__')+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,base_commit=base,tests=tests,matrices=matrices,embedded_commands=26,darwin_builds=8,bootstrap=boot,compiler=dict(path=str(native),bytes=native.stat().st_size,sha256=sha(native)),oracle=dict(path=str(oracle),sha256=sha(oracle)),performance=perf,artifacts=artifacts),indent=2)+'\n');print('PASS',len(artifacts),'artifacts;',2479+4593,'regression cases; 557 matrix and caller commands')
