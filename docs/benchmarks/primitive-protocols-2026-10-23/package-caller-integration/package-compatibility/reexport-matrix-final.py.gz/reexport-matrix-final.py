from pathlib import Path
import subprocess,json,os,hashlib,re,collections
root=Path('/workspace/lang-primitive-protocols-publish');out=Path('/workspace/scratch/lang-primitive-protocols/package-caller-integration/package-compatibility');work=out/'reexport-matrix-final';work.mkdir(exist_ok=True)
source=(root/'internal/testing/modulecases/reexports.go').read_text();cases=[]
choice=re.search(r'const choice = `([^`]*)`',source)[1]
for m in re.finditer(r'\{"([^"]+)", map\[string\]string\{(.*?)\n\s*\}, "([^"]*)"\}',source,re.S):
 files={}
 for row in m[2].splitlines():
  f=re.search(r'"([^"]+)":\s*(.*),',row)
  if f: files[f[1]]=''.join(re.findall(r'`([^`]*)`',f[2])) if not f[2].startswith('choice') else choice+''.join(re.findall(r'`([^`]*)`',f[2]))
 cases.append(dict(name=m[1],files=files,error=m[3]))
assert len(cases)==10 and sum(bool(c['error']) for c in cases)==6
selfcli=Path('/workspace/scratch/lang-primitive-protocols/latest-package-integration/bootstrap/stage3');oracle=out.parent/'oracle';env=dict(os.environ,FERN_SANITIZE='1',FERN_LEAKCHECK='1',FERN_STRICT_IR='1');rows=[]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),compiler_sha256=hashlib.sha256(selfcli.read_bytes()).hexdigest(),oracle_sha256=hashlib.sha256(oracle.read_bytes()).hexdigest(),cases=cases,commands=rows,environment={k:env[k]for k in ['FERN_SANITIZE','FERN_LEAKCHECK','FERN_STRICT_IR']})
def run(name,args,error='',census=False):
 p=subprocess.run(list(map(str,args)),cwd=root,env=env,text=True,capture_output=True,timeout=180)
 good=(p.returncode!=0 and 'E087'in p.stderr and error in p.stderr)if error else p.returncode==0
 row=dict(name=name,arguments=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr,pass_=good)
 if census:
  m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);row['census']=dict(allocs=int(m[1]),frees=int(m[2]),live_bytes=int(m[3]))if m else None;good=good and bool(m and m[1]==m[2] and m[3]=='0');row['pass_']=good
 rows.append(row);(out/'reexport-matrix-final-results.json').write_text(json.dumps(report,indent=2)+'\n');assert good,row
for c in cases:
 d=work/c['name'];d.mkdir(exist_ok=True)
 for n,s in c['files'].items():(d/n).write_text(s)
 src=d/'main.fern'
 for tag,cli in [('go',oracle),('self',selfcli)]:
  for mode in ['-check','-interp']:run(c['name']+'-'+tag+mode,[cli,mode,src,root/'internal/stdlib'],c['error'])
 for target,runner in [('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run'])]+([]if c['error']else[('arm64-darwin',None)]):
  binary=d/target;assert not binary.exists();args=[selfcli,'-target',target,'-o',binary]
  if target=='wasm32-wasi':args+=['-emit','command-module']
  run(c['name']+'-build-'+target,args+[src,root/'internal/stdlib'],c['error'])
  if c['error']:assert not binary.exists()
  elif runner is not None:run(c['name']+'-run-'+target,runner+[binary],census=True)
 print('DONE',c['name'],flush=True)
assert len(rows)==86;print('PASS',len(rows),'commands',flush=True)
