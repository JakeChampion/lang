from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess
root=Path('/workspace/lang-primitive-protocols-publish');out=Path('/workspace/scratch/lang-primitive-protocols/package-caller-integration');source='f674ab43d324f2c2f6a8f9668da4e19ebb52b0a0';dest=root/'docs/benchmarks/primitive-protocols-2026-10-23/package-caller-integration'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==source and not git('status','--porcelain')
cert=json.loads((out/'native-source-certificate.json').read_text());assert cert['current_source']==source and not git('diff','--name-only',cert['recorded_source'],source,'--',*cert['paths']);assert sha(Path(cert['compiler']))==cert['compiler_sha256']
rows=[json.loads(l)for l in(out/'go-regressions.jsonl').read_text().splitlines()if l.startswith('{')];c=collections.Counter(r['Action']for r in rows if r.get('Test'));ps=[r for r in rows if not r.get('Test')and r['Action']in ['pass','fail','skip']];assert c['run']==c['pass']==2479 and not c['fail']and not c['skip']and len(ps)==5 and all(r['Action']=='pass'for r in ps)
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+source in version and 'vcs.modified=false'in version
matrices=[]
for name,count,census in [('contracts-matrix-results.json',144,24),('verified-negative.json',6,0),('package-compatibility/committed-matrix-final-results.json',90,15),('package-compatibility/package-project-matrix-final-results.json',19,3),('package-compatibility/reexport-matrix-final-results.json',86,12),('all-coreutils-checks.json',212,0)]:
    d=json.loads((out/name).read_text());assert d.get('core_commit',d.get('source_commit'))==source and len(d['commands'])==count and all(r['pass_']for r in d['commands'])
    if 'binaries'in d:assert d['binaries'][cert['compiler']]['sha256']==cert['compiler_sha256']and d['binaries'][str(out/'oracle')]['sha256']==sha(out/'oracle')
    else:assert d['compiler_sha256']==cert['compiler_sha256']and d['oracle_sha256']==sha(out/'oracle')
    cs=[tuple(map(int,m.groups()))for r in d['commands']if(m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))];assert len(cs)==census and all(a==f and n==0 for a,f,n in cs);matrices.append(dict(file=name,commands=count,balanced_censuses=census))
for name in ['vet.log','gofmt.log']:assert not(out/name).read_bytes()
for name in ['readme-ste.log','pr-body-ste.log']:assert 'Result: 0 errors, 0 warnings.'in(out/name).read_text()
dest.mkdir(exist_ok=False);artifacts=[]
def save(name,data):
    p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
save('README.md',(out/'README.md').read_bytes())
files=['native-source-certificate.json','go-regressions.jsonl','oracle-version.txt','contracts-matrix.py','contracts-matrix-results.json','contracts-matrix.log','verified-negative.py','verified-negative.json','verified-negative.log','check-all-coreutils.py','all-coreutils-checks.json','all-coreutils-checks.log','vet.log','gofmt.log','readme-ste.log','pr-body-ste.log','pr-body.md','record-proofs.py']
for stem in ['committed-matrix-final','package-project-matrix-final','reexport-matrix-final']:files += ['package-compatibility/'+stem+suffix for suffix in ['.py','-results.json','.log']]
for name in files:save(name+'.gz',gzip.compress((out/name).read_bytes(),mtime=0))
(dest/'manifest.json').write_text(json.dumps(dict(source_commit=source,go_cases=2479,packages=5,skips=0,native_certificate=cert,matrices=matrices,prior_proof='package-corpus-integration',artifacts=artifacts),indent=2)+'\n');print(json.dumps(dict(artifacts=len(artifacts),go_cases=2479,matrix_commands=345,balanced_censuses=54,coreutils_checks=212)))
