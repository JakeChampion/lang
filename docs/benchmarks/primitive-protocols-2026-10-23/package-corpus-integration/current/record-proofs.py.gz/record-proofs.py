from pathlib import Path
import collections, gzip, hashlib, json, re, subprocess

root = Path('/workspace/lang-primitive-protocols-publish')
out = Path('/workspace/scratch/lang-primitive-protocols/corpus-worker-integration')
prior = out.parent / 'latest-package-integration'
source = '15a3881824c771fadd1227c831feaa22aa5beb64'
dependency = '26c0a362e397506c8bc4c65b104ffc7d3b346cb1'
native_source = '56690b99c644ee5ef39595beb472dc4c4fe7cf18'
test_source = '2d845222a5f06a8a21f1e27519cb5995b92b1d96'
dest = root / 'docs/benchmarks/primitive-protocols-2026-10-23/package-corpus-integration'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert git('rev-parse', 'HEAD').decode().strip() == source
assert not git('status', '--porcelain')
cert = json.loads((out / 'native-source-certificate.json').read_text())
assert cert['recorded_source'] == native_source and cert['current_source'] == source
assert not git('diff', '--name-only', native_source, source, '--', *cert['paths'])
assert sha(Path(cert['compiler'])) == cert['compiler_sha256']
# Native test harness changes remain outside the native-input certificate.
harness_paths = ['internal/testing/e2ecompiler', 'internal/testing/e2e', 'conformance', 'internal/testing/modulecases']
assert not git('diff', '--name-only', test_source, source, '--', *harness_paths)
cert['native_test_source'] = test_source
cert['native_test_paths'] = harness_paths
(out / 'native-source-certificate.json').write_text(json.dumps(cert, indent=2) + '\n')
def suite(path, cases, packages):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    c = collections.Counter(r['Action'] for r in rows if r.get('Test'))
    terminal = [r for r in rows if not r.get('Test') and r['Action'] in ['pass', 'skip', 'fail']]
    assert c['run'] == c['pass'] == cases and c['fail'] == c['skip'] == 0, (path, c)
    assert len(terminal) == packages and all(r['Action'] == 'pass' for r in terminal)
    return dict(file=str(path), cases=cases, skips=0, packages=terminal)
tests = [suite(out / 'go-regressions.jsonl', 2478, 5), suite(prior / 'native-regressions-final.jsonl', 4566, 1)]
assert 'vcs.revision=' + source in (out / 'oracle-version.txt').read_text()
assert 'vcs.modified=false' in (out / 'oracle-version.txt').read_text()
matrices = []
for name, count, census in [('contracts-matrix-results.json', 144, 24), ('verified-negative.json', 6, 0), ('package-compatibility/committed-matrix-final-results.json', 90, 15), ('package-compatibility/package-project-matrix-final-results.json', 19, 3), ('package-compatibility/reexport-matrix-final-results.json', 86, 12)]:
    d = json.loads((out / name).read_text())
    assert d.get('core_commit', d.get('source_commit')) == source
    assert len(d['commands']) == count and all(r['pass_'] for r in d['commands'])
    if 'binaries' in d:
        assert d['binaries'][cert['compiler']]['sha256'] == cert['compiler_sha256']
        assert d['binaries'][str(out / 'oracle')]['sha256'] == sha(out / 'oracle')
    else:
        assert d['compiler_sha256'] == cert['compiler_sha256'] and d['oracle_sha256'] == sha(out / 'oracle')
    cs = [tuple(map(int, m.groups())) for r in d['commands'] if (m := re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)', r['stderr']))]
    assert len(cs) == census and all(a == f and n == 0 for a, f, n in cs)
    matrices.append(dict(file=name, commands=count, balanced_censuses=census))
boot = json.loads((prior / 'bootstrap/bootstrap.json').read_text())
assert boot['source_git'] == native_source and boot['fixedpoint']
assert boot['stages'][0]['producer_sha256'] == 'a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f'
assert sha(prior / 'bootstrap/stage2') == sha(prior / 'bootstrap/stage3') == cert['compiler_sha256']
trace = json.loads((prior / 'verified-census-results.json').read_text())
assert trace['core_commit'] == native_source and trace['compiler_sha256'] == cert['compiler_sha256']
assert len(trace['rows']) == 8 and all(r['unpaired'] == 0 for r in trace['rows'])
assert sum(r['trace_events'] for r in trace['rows']) == 188
embedded = json.loads((prior / 'embedded-results.json').read_text())
assert embedded['source_commit'] == native_source and len(embedded['commands']) == 26 and all(r['pass_'] for r in embedded['commands'])
assert sha(prior / 'embedded-fern') == embedded['binary_sha256']
darwin = json.loads((prior / 'darwin-builds-results.json').read_text())
assert darwin['source_commit'] == test_source and len(darwin['commands']) == 8 and all(r['exit'] == 0 for r in darwin['commands'])
assert json.loads((prior / 'format-final.json').read_text()) == dict(files=1234, exit=0)
assert len((prior / 'final-driver-sizes.txt').read_text().splitlines()) == 11
assert 'Every driver measured here is within 5%' in (prior / 'final-driver-gate.log').read_text()
assert 'excess 16323' in (prior / 'complexity-after.txt').read_text()
for name in ['vet.log', 'gofmt.log']:
    assert (out / name).read_bytes() == b''
for name in ['readme-ste.log', 'pr-body-ste.log']:
    assert 'Result: 0 errors, 0 warnings.' in (out / name).read_text()
perf = json.loads((prior / 'kernel-profile-results.json').read_text())
assert sha(prior / 'kernel-cost.fern') == perf['source_sha256']
before, after = perf['rows']
assert before['instructions'] == 29937444 and after['instructions'] == 29667649
assert before['stdout'] == after['stdout'] == '321202\n142986\n'
assert after['compiler_sha256'] == cert['compiler_sha256'] and perf['instruction_ratio'] <= 1
for r in perf['rows']:
    assert sha(Path(r['profile_args'][-1])) == r['binary_sha256']
dest.mkdir(exist_ok=False)
artifacts = []
def save(name, data):
    p = dest / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    artifacts.append(dict(path=name, bytes=len(data), sha256=sha(p)))
save('README.md', (out / 'README.md').read_bytes())
patch = git('diff', '--binary', dependency, source)
subprocess.run(['git', 'apply', '--reverse', '--check', '-'], cwd=root, input=patch, check=True)
save('source.patch.gz', gzip.compress(patch, mtime=0))
fresh = ['native-source-certificate.json', 'go-regressions.jsonl', 'oracle-version.txt', 'contracts-matrix.py', 'contracts-matrix-results.json', 'contracts-matrix.log', 'verified-negative.py', 'verified-negative.json', 'verified-negative.log', 'vet.log', 'gofmt.log', 'readme-ste.log', 'pr-body-ste.log', 'record-proofs.py', 'pr-body.md']
fresh += ['package-compatibility/' + n for n in ['committed-matrix-final.py', 'committed-matrix-final-results.json', 'committed-matrix-final.log', 'package-project-matrix-final.py', 'package-project-matrix-final-results.json', 'package-project-matrix-final.log', 'reexport-matrix-final.py', 'reexport-matrix-final-results.json', 'reexport-matrix-final.log']]
previous = ['bootstrap/bootstrap.json', 'bootstrap/completed-intermediates.json', 'bootstrap/stage1.log', 'bootstrap/stage2.log', 'bootstrap/stage3.log', 'native-regressions-final.jsonl', 'run-native-regressions-final.sh', 'metadata-only-source-certificate.json', 'verified-census-results.json', 'verified-census.log', 'measure-verified-census.py', 'embedded-results.json', 'embedded-results.log', 'check-embedded.py', 'darwin-builds-results.json', 'format-final.json', 'format-final.log', 'final-driver-builds.json', 'final-driver-sizes.txt', 'final-driver-gate.log', 'check-sizes.py', 'complexity-after.txt', 'kernel-profile-results.json', 'kernel-cost.fern', 'kernel-before.callgrind', 'kernel-before.log', 'kernel-before.stdout', 'kernel-after.callgrind', 'kernel-after.log', 'kernel-after.stdout', 'profile-kernels.py', 'profile-kernels.log']
for folder, names, prefix in [(out, fresh, 'current'), (prior, previous, 'native-records')]:
    for name in names:
        save(prefix + '/' + name + '.gz', gzip.compress((folder / name).read_bytes(), mtime=0))
binaries = {str(p): dict(bytes=p.stat().st_size, sha256=sha(p)) for p in [out / 'oracle', prior / 'oracle', prior / 'oracle-current', prior / 'embedded-fern', prior / 'bootstrap/stage2', prior / 'bootstrap/stage3', prior / 'kernel-cost-before', prior / 'kernel-cost-after']}
manifest = dict(source_commit=source, package_dependency=dependency, native_source_commit=native_source, native_test_source_commit=test_source, issues=[12704,13081,13082,13083,13084,13085], tests=tests, matrices=matrices, native_certificate=cert, bootstrap=boot, trace_events=188, unpaired=0, embedded_commands=26, darwin_builds=8, darwin_local_execution=False, performance=perf, binaries=binaries, artifacts=artifacts)
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(artifacts=len(artifacts), cases=[2478,4566], matrix_commands=345, balanced_censuses=54)))
