Complete primitive protocol instances and preserve scalar receiver types through interpreter bindings, arrays, views, captures, and cells.
Primitive interpolation needs no import.
Declared methods retain precedence over builtin methods.
Associated function calls and contextual type arguments agree across both frontends.
Invalid builtin arguments receive normal diagnostics, and method hints name only available methods.

Validation passes all 2,478 current Go checks across five packages without skips.
All 345 fresh matrix commands pass, with 54 balanced runtime allocation counts.
The source certificate verifies unchanged native inputs for the earlier 4,566 native checks, bootstrap, installed compiler, and size gates.
All 11 driver sizes retain their limits.
Eight Darwin images build but are not executed locally.

The kernel benchmark produces the same output and allocation count before and after the change.
Instruction counts decrease from 29,937,444 to 29,667,649.
The proof capsule retains raw profiles, source commits, and binary hashes.

Closes #12704.
Closes #13081.
Closes #13082.
Closes #13083.
Closes #13084.
Closes #13085.
