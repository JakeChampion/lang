from pathlib import Path
import collections,gzip,hashlib,json,re,subprocess

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def git(root,*args): return subprocess.check_output(['git',*args],cwd=root)
def suite(path,count,packages):
    events=[json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
    counts=collections.Counter(e['Action'] for e in events if e.get('Test'))
    terminal=[e for e in events if not e.get('Test') and e['Action'] in ['pass','fail','skip']]
    assert counts['run']==counts['pass']==count and not counts['fail'] and not counts['skip'],(path,counts)
    assert len(terminal)==packages and all(e['Action']=='pass' for e in terminal) and events[-1]['Action']=='pass',terminal
    return dict(path=str(path),cases=count,packages=packages,skips=0)

for kind,current,recorded,go_count,packages,native_count,baseline,capsule,issues in [
    ('primitive-protocols','460129e95d676f30cef6a3e8ea94da58872f24ac','493562d18cd679d2ff4721b6dd9eeca48898c41b',2479,5,4593,'e4821e67108f3bca308dd18b897e313996a8c3b6','primitive-protocols-2026-10-23',[12704,13081,13082,13083,13084,13085]),
    ('text-api-cohesion','af9fe92362083d4df4d33743e41333be6b985a88','acb3ebb2e1503970f61d587af88c5c985c074b45',2495,6,4593,'460129e95d676f30cef6a3e8ea94da58872f24ac','text-api-2026-10-23',[12718,13086]),
    ('nested-pattern-docs','1772fdf1ef2e2a3eaa1afa31eac1313ea3479d06','1772fdf1ef2e2a3eaa1afa31eac1313ea3479d06',2704,4,5626,'e4821e67108f3bca308dd18b897e313996a8c3b6','nested-pattern-2026-10-25',[13161]),
]:
    nested=kind=='nested-pattern-docs'
    root=Path('/tmp/lang-void-lambda-publish' if nested else '/tmp/lang-'+kind+'-publish')
    out=Path('/workspace/scratch/lang-'+kind+('/range-final-validation' if nested else '/module-driver-integration'))
    oracle=out.parent/'shape-final-validation/oracle' if nested else out/'oracle'
    go_out=oracle.parent
    assert git(root,'rev-parse','HEAD').decode().strip()==current and not git(root,'status','--porcelain')
    tests=[suite(go_out/'go-regressions.jsonl',go_count,packages),suite(out/'native-regressions.jsonl',native_count,1)]
    boot=json.loads((out/'bootstrap/bootstrap.json').read_text());native=out/'bootstrap/stage3'
    assert boot['source_git']==recorded and boot['fixedpoint'] and boot['stages'][0]['producer_sha256']=='a4d655b3ce09712582951702c8fce5d0cba0dbe58736c7da95ef2a60a9b3674f'
    assert sha(native)==sha(out/'bootstrap/stage2')==boot['stages'][1]['sha256']==boot['stages'][2]['sha256']
    paths=['compiler','internal/stdlib','bootstrap/stage0.lock','.github/selfhost-driver-sizes.txt']
    assert not git(root,'diff','--name-only',recorded,current,'--',*paths)
    cert=dict(recorded_source=recorded,current_source=current,paths=paths,compiler=str(native),compiler_sha256=sha(native),oracle=str(oracle),oracle_sha256=sha(oracle))
    (out/'native-source-certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
    go_source='2b75b1135dada4574e858ce8f7d1fb2312571da0' if nested else recorded
    assert not git(root,'diff','--name-only',go_source,current,'--','cmd','internal','go.mod','go.sum')
    version=(go_out/'oracle-version.txt').read_text()
    assert 'vcs.revision='+go_source in version and 'vcs.modified=false' in version
    for name in ['vet.log','gofmt.log','format-check.log']: assert not (out/name).read_bytes(),name
    for name in ['readme-ste.log','pr-body-ste.log']: assert 'Result: 0 errors, 0 warnings.' in (out/name).read_text(),name
    fmt=json.loads((out/'format-final.json').read_text());assert fmt['exit']==0 and fmt['files']==(1218 if nested else 1222)
    assert len((out/'final-driver-sizes.txt').read_text().splitlines())==11 and 'Every driver measured here is within 5%' in (out/'final-driver-gate.log').read_text()
    matrices=[]
    files=[('matrix-results.json',24,3)] if nested else [('contracts-matrix-results.json',144,24),('verified-negative.json',6,0),('package-compatibility/committed-matrix-final-results.json',90,15),('package-compatibility/package-project-matrix-final-results.json',19,3),('package-compatibility/reexport-matrix-final-results.json',86,12),('all-coreutils-checks.json',212,0)]
    for name,count,census in files:
        d=json.loads((out/name).read_text());assert len(d['commands'])==count and all(r['pass_'] for r in d['commands'])
        if 'binaries' in d: assert d['binaries'][str(native)]['sha256']==sha(native) and d['binaries'][str(oracle)]['sha256']==sha(oracle)
        else: assert d['compiler_sha256']==sha(native) and d['oracle_sha256']==sha(oracle)
        cs=[tuple(map(int,m.groups())) for r in d['commands'] if (m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))]
        assert len(cs)==census and all(a==f and n==0 for a,f,n in cs),(name,cs)
        matrices.append(dict(file=name,commands=count,balanced_censuses=census))
    if kind=='text-api-cohesion':
        d=json.loads((out/'final-matrix/identity.json').read_text());assert d['compiler_sha256']==sha(native) and d['oracle_sha256']==sha(oracle)
        rows=json.loads((out/'final-matrix/results.json').read_text());assert len(rows)==40
        for row in rows:
            if row['name'].startswith(('text_api_owners','unicode_linear_transforms')): assert row['exit']==0
            else: assert row['exit']==1 and 'error[' in row['stderr']+row['stdout']
        cs=[tuple(map(int,m.groups())) for r in rows if (m:=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r['stderr']))]
        assert len(cs)==6 and all(a==f and n==0 for a,f,n in cs)
        matrices.append(dict(file='final-matrix/results.json',commands=40,balanced_censuses=6))
    if not nested:
        embed=json.loads((out/'embedded-results.json').read_text());assert len(embed['commands'])==(26 if kind=='primitive-protocols' else 33) and all(r['pass_'] for r in embed['commands'])
        darwin=json.loads((out/'darwin-builds.json').read_text());assert len(darwin['commands'])==(8 if kind=='primitive-protocols' else 2)
        for row in darwin['commands']: assert row['pass_'] and row['exit']==0 and sha(row['args'][4])==row['image_sha256']
        profile=json.loads((out/'kernel-profile-results.json').read_text());rows=profile['rows']
        assert len(rows)==(2 if kind=='primitive-protocols' else 6)
        for row in rows:
            assert sha(row['build_args'][4])==row['binary_sha256']
            if 'source_sha256' in row: assert sha(row['build_args'][5])==row['source_sha256']
        if kind=='primitive-protocols': assert rows[0]['stdout']==rows[1]['stdout'] and rows[1]['instructions']<rows[0]['instructions']
        else:
            for i in range(0,6,2):
                a,b=rows[i:i+2];assert a['source_sha256']==b['source_sha256'];old=a['stdout'].splitlines();new=b['stdout'].splitlines()
                if a['probe']=='reverse-clusters':
                    for k in [0,3,6]: assert old[k:k+2]==new[k:k+2] and int(new[k+2])<int(old[k+2])
                else: assert old[:-1]==new[:-1] and int(new[-1])<int(old[-1])
                if a['probe']!='phase1-probe': assert b['instructions']<a['instructions']
    patch=git(root,'diff','--binary',baseline,current,'--','.',':(exclude)docs/benchmarks')
    subprocess.run(['git','apply','--reverse','--check','-'],cwd=root,input=patch,check=True)
    dest=root/'docs/benchmarks'/capsule/out.name;assert not dest.exists();dest.mkdir(parents=True)
    artifacts=[]
    def save(name,data):
        p=dest/name;p.write_bytes(data);artifacts.append(dict(path=name,bytes=len(data),sha256=sha(p)))
    save('README.md',(out/'README.md').read_bytes());save('source.patch.gz',gzip.compress(patch,mtime=0))
    selected=[]
    for p in sorted(out.rglob('*')):
        if not p.is_file() or 'previous-native' in p.name: continue
        rel=p.relative_to(out)
        if len(rel.parts)>1 and rel.parts[0] not in ['bootstrap','profiles','package-compatibility','final-matrix']: continue
        if p.name=='README.md' or p.suffix not in ['.py','.json','.jsonl','.log','.txt','.md','.callgrind','.stdout','.fern']: continue
        selected.append(p)
    for p in selected: save(str(p.relative_to(out)).replace('/','__')+'.gz',gzip.compress(p.read_bytes(),mtime=0))
    if nested:
        for name in ['go-regressions.jsonl','oracle-version.txt']:save('go-source__'+name+'.gz',gzip.compress((go_out/name).read_bytes(),mtime=0))
    save('record-proofs.py.gz',gzip.compress(Path(__file__).read_bytes(),mtime=0))
    manifest=dict(source_commit=current,recorded_native_source=recorded,recorded_go_source=go_source,baseline_commit=baseline,issues=issues,tests=tests,matrices=matrices,compiler=cert,artifacts=artifacts)
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(kind,'PASS',len(artifacts),'artifacts;',sum(x['cases'] for x in tests),'test cases;',sum(x['commands'] for x in matrices),'matrix commands',flush=True)
