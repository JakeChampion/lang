from pathlib import Path
import collections, gzip, hashlib, io, json, subprocess, tarfile

root = Path('/workspace/lang-capture-after-last-write-publish')
out = Path('/workspace/scratch/lang-defer-capture-cells/csv-path-integration')
core = '050683019d3c8e18c48674c8e27e4adb51e7849e'
base = '40e27bc3e299925678760a9e2fb32c97fff7e41d'
dest = root / 'docs/benchmarks/capture-after-last-write-2026-10-24/csv-path-integration'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == core
boot = json.loads((out / 'bootstrap/bootstrap.json').read_text())
assert boot['fixedpoint'] and boot['source_git'] == core
assert boot['stages'][1]['sha256'] == boot['stages'][2]['sha256']
tests = []
for name, count in [('targeted-tests', 41)]:
    events = [json.loads(s) for s in (out / (name + '.jsonl')).read_text().splitlines() if s.startswith('{')]
    c = collections.Counter(e['Action'] for e in events)
    assert c['run'] == count and not c['fail'] and not c['skip'] and events[-1]['Action'] == 'pass', c
    tests.append({'suite': name, 'cases': count})
matrix = json.loads((out / 'matrix.json').read_text())
assert matrix['complete'] and len(matrix['runs']) == 33
assert matrix['producer_sha256'] == boot['stages'][2]['sha256']
censuses = [r['census'] for r in matrix['runs'] if 'census' in r]
assert len(censuses) == 9 and all(c['allocs'] == c['frees'] and c['live_bytes'] == 0 for c in censuses)
pair = json.loads((out / 'measure-final/report.json').read_text())
assert len(pair['map_runs']) == 6 and len(pair['compiler_runs']) == 2 and pair['compiler_sha256']['candidate'] == boot['stages'][2]['sha256']
for run in pair['map_runs']:
    assert run['allocations_during_build'] <= 32 if run['variant'] == 'candidate' else run['allocations_during_build'] > 2 * run['n']
assert 'Every driver measured here is within 5%' in (out / 'driver-gate.log').read_text()
assert not (out / 'format.log').read_bytes() and not (out / 'gofmt.log').read_bytes()
files = []
digest = hashlib.sha256()
for name in sorted(subprocess.check_output(['git', 'ls-files', 'compiler', 'internal/stdlib'], cwd=root, text=True).splitlines()):
    data = (root / name).read_bytes()
    digest.update(name.encode() + b'\0' + data + b'\0')
    files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert digest.hexdigest() == boot['source_sha256']
dest.mkdir(parents=True, exist_ok=False)
artifacts = []
def save(name, data):
    p = dest / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    artifacts.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
def take(name):
    save(name + '.gz', gzip.compress((out / name).read_bytes(), mtime=0))
save('source-files.json', json.dumps(files, indent=2).encode() + b'\n')
patch = subprocess.check_output(['git', 'diff', '--binary', base, core], cwd=root)
subprocess.run(['git', 'apply', '--reverse', '--check', '-'], input=patch, cwd=root, check=True)
save('change.patch.gz', gzip.compress(patch, mtime=0))
for name in ['bootstrap/bootstrap.json', 'bootstrap/stage1.log', 'bootstrap/stage2.log', 'bootstrap/stage3.log', 'targeted-tests.jsonl', 'driver-builds.json', 'driver-sizes.txt', 'driver-gate.log', 'check-sizes.py', 'matrix.json', 'matrix.py', 'matrix.log', 'measure-final.py', 'measure-final/report.json', 'measurements.log', 'format.log', 'gofmt.log', 'record-proofs.py', 'measure-final/baseline-build.log', 'measure-final/candidate-build.log', 'measure-final/compiler-0-baseline.log', 'measure-final/compiler-0-candidate.log']:
    take(name)
stream = io.BytesIO()
logs = []
with tarfile.open(fileobj=stream, mode='w:gz') as archive:
    for folder in ['matrix-checked', 'measure-final']:
        for p in sorted((out / folder).glob('*')):
            if p.suffix not in ['.stdout', '.stderr']:
                continue
            data = p.read_bytes()
            info = tarfile.TarInfo(folder + '/' + p.name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
            logs.append(str(p))
assert len(logs) == 66
save('execution-logs.tar.gz', stream.getvalue())
(dest / 'artifacts.json').write_text(json.dumps({'source_commit': core, 'dependency_base': base, 'native_sha256': boot['stages'][2]['sha256'], 'tests': tests, 'source_sha256': digest.hexdigest(), 'oracle_sha256': matrix['oracle_sha256'], 'artifacts': artifacts}, indent=2) + '\n')
print('Verified', len(files), 'source files and', len(artifacts), 'artifacts')
