from pathlib import Path
import subprocess,re,os,json,hashlib,time
root=Path('/workspace/lang-module-callback-followups');out=Path('/workspace/scratch/lang-module-callback-followups');work=out/'matrix';work.mkdir(exist_ok=False);native=out/'bootstrap/stage3';oracle=out/'oracle';env=dict(os.environ,FERN_STRICT_IR='1',FERN_SANITIZE='1',FERN_LEAKCHECK='1');rows=[]
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),binaries={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in[native,oracle]},commands=rows,fixtures=[],environment={k:env[k]for k in['FERN_STRICT_IR','FERN_SANITIZE','FERN_LEAKCHECK']})
def run(name,args,code=0,error=False,census=False):
 start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=root,env=env,capture_output=True,text=True,timeout=180);good=(p.returncode!=0 and 'E002'in p.stderr and 'void'in p.stderr and 'i32'in p.stderr)if error else p.returncode==code
 row=dict(name=name,arguments=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=time.monotonic()-start,pass_=good)
 if census:
  m=re.search(r'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',p.stderr);row['census']=dict(allocs=int(m[1]),frees=int(m[2]),live_bytes=int(m[3]))if m else None;good=good and bool(m and m[1]==m[2]and m[3]=='0');row['pass_']=good
 rows.append(row);(out/'matrix-results.json').write_text(json.dumps(report,indent=2)+'\n');assert good,row
static=(root/'internal/pkg/modload/struct_static_target_test.go').read_text().split('\n\t} {',1)[0];cases=[]
for name,lib in re.findall(r'"([^"]+)":\s*`([^`]*)`',static):
 d=work/name;d.mkdir();(d/'lib.fern').write_text(lib);(d/'main.fern').write_text('import "./lib"; function main(): i32 { return lib.run(); }');cases.append((name,d/'main.fern',42))
assert len(cases)==4
source=(root/'internal/testing/e2ecompiler/self_host_pattern_callback_test.go').read_text();d=work/'callbacks';d.mkdir();(d/'main.fern').write_text(re.search(r'const source = `([^`]*)`',source)[1]);cases.append(('callbacks',d/'main.fern',0))
for name,src,code in cases:
 report['fixtures'].append(dict(name=name,path=str(src),sha256=hashlib.sha256(src.read_bytes()).hexdigest()))
 for tag,cli in[('go',oracle),('native',native)]:
  run(name+'-'+tag+'-check',[cli,'-check',src,root/'internal/stdlib'])
  run(name+'-'+tag+'-interp',[cli,'-interp',src,root/'internal/stdlib'],code)
 for target,runner in[('x86-64-linux',[]),('arm64-linux',['qemu-aarch64']),('wasm32-wasi',['wasmtime','run']),('arm64-darwin',None)]:
  binary=src.parent/target;args=[native,'-target',target,'-o',binary]
  if target=='wasm32-wasi':args+=['-emit','command-module']
  run(name+'-build-'+target,args+[src,root/'internal/stdlib'])
  if runner is not None:run(name+'-run-'+target,runner+[binary],code,census=True)
 print('DONE',name,flush=True)
d=work/'invalid';d.mkdir();src=d/'main.fern';src.write_text(re.search(r'const invalid = `([^`]*)`',source)[1])
for tag,cli in[('go',oracle),('native',native)]:
 for mode in['-check','-interp']:run('invalid-'+tag+mode,[cli,mode,src,root/'internal/stdlib'],error=True)
for target in['x86-64-linux','arm64-linux','wasm32-wasi']:
 binary=d/target;run('invalid-build-'+target,[native,'-target',target,'-o',binary,src,root/'internal/stdlib'],error=True);assert not binary.exists()
assert len(rows)==62;report['complete']=True;(out/'matrix-results.json').write_text(json.dumps(report,indent=2)+'\n');print('PASS',len(rows),'commands')
