from pathlib import Path
import subprocess,json,hashlib,gzip,collections,tarfile,io
root=Path('/workspace/lang-module-callback-followups');out=Path('/workspace/scratch/lang-module-callback-followups');core='54d091064a377c379610bcf3d9968daca11e025f';base='191c0c1a05e15db00e465bf14cfd7eb09b05c29b';dest=root/'docs/benchmarks/module-callback-followups-2026-10-24'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==core and not git('status','--porcelain')
boot=json.loads((out/'bootstrap/bootstrap.json').read_text());assert boot['source_git']==core and boot['fixedpoint'];native=boot['stages'][-1]['sha256'];assert native==boot['stages'][1]['sha256']=='efd9f2ba6ed9eea4b28213afed61e87f182752ccc3c52ac60ab7e91e1bbcca13'
files=[];h=hashlib.sha256()
for n in sorted(git('ls-files','compiler','internal/stdlib').decode().splitlines()):
 data=(root/n).read_bytes();h.update(n.encode()+b'\0'+data+b'\0');files.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
assert h.hexdigest()==boot['source_sha256'];tests=[];native_runs=0;native_parents=[]
for n,count,pkgs in [('regressions.jsonl',17,2),('go-regressions.jsonl',2279,3),('native-regressions.jsonl',178,1),('typeparam-precedence.jsonl',34,1)]:
 es=[json.loads(s)for s in(out/n).read_text().splitlines()if s.startswith('{')];c=collections.Counter(e['Action']for e in es);ps=[e for e in es if'Test'not in e and e['Action']in['pass','fail']];assert c['run']==count and not c['fail']and not c['skip']and len(ps)==pkgs and all(e['Action']=='pass'for e in ps);tests.append(dict(file=n,runs=count,packages=pkgs,skips=0))
 for e in es:
  if e['Action']=='run'and e['Package'].endswith('/e2ecompiler'):
   native_runs+=1
   if '/'not in e['Test']:native_parents.append(e['Test'])
assert native_runs==224 and len(native_parents)==len(set(native_parents))
m=json.loads((out/'matrix-final-results.json').read_text());assert m['complete']and m['source_commit']==core and len(m['commands'])==53 and all(r['pass_']for r in m['commands']);cs=[r['census']for r in m['commands']if'census'in r];assert len(cs)==12 and all(c['allocs']==c['frees']and c['live_bytes']==0 for c in cs)
assert 'Every driver measured here is within 5%'in(out/'size-validation/final-driver-gate.log').read_text();assert len((out/'size-validation/final-driver-sizes.txt').read_text().splitlines())==11
for n in ['format-all.log','gofmt.log','vet.log']:assert not(out/n).read_bytes()
assert json.loads((out/'format-all.json').read_text())==dict(count=1204,exit=0)
version=(out/'oracle-version.txt').read_text();assert 'vcs.revision='+core in version and'vcs.modified=false'in version
before=[json.loads(s)for s in(out/'struct-static-before.jsonl').read_text().splitlines()if s.startswith('{')];failed=[e['Test']for e in before if e['Action']=='fail'and'/'in e.get('Test','')];assert len(failed)==2
cb=json.loads((out/'callback-before.json').read_text());assert cb[0]['exit']==0 and cb[1]['exit']!=0 and'expected void, got unknown'in cb[1]['stderr']
explore=json.loads((out/'matrix-results.json').read_text());bad=[r for r in explore['commands']if not r['pass_']];assert len(bad)==1 and bad[0]['name']=='type-parameter-shadow-native-check'
dest.mkdir(exist_ok=False);artifacts=[]
def save(n,data):
 p=dest/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);artifacts.append(dict(path=n,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
def take(n):save(n.replace('/','-')+'.gz',gzip.compress((out/n).read_bytes(),mtime=0))
save('source-files.json',json.dumps(files,indent=2).encode()+b'\n');patch=git('diff','--binary',base,core);subprocess.run(['git','apply','--reverse','--check','-'],input=patch,cwd=root,check=True);save('change.patch.gz',gzip.compress(patch,mtime=0))
for n in ['bootstrap/bootstrap.json','bootstrap/stage1.log','bootstrap/stage2.log','bootstrap/stage3.log','regressions.jsonl','go-regressions.jsonl','native-regressions.jsonl','typeparam-precedence.jsonl','struct-static-before.jsonl','struct-static-after.jsonl','callback-before.json','matrix-final.py','matrix-final-results.json','matrix-final.log','matrix.py','matrix-results.json','matrix.log','size-validation/final-driver-sizes.txt','size-validation/final-driver-builds.json','size-validation/final-driver-gate.log','size-validation/sizes.log','check-sizes-final.py','format-all.json','format-all.log','gofmt.log','vet.log','oracle-version.txt','ste.log','record-proofs.py']:take(n)
stream=io.BytesIO();inputs=[]
with tarfile.open(fileobj=stream,mode='w:gz')as t:
 for folder in ['baseline','matrix-final']:
  for p in sorted((out/folder).rglob('*.fern')):
   data=p.read_bytes();name=str(p.relative_to(out));ti=tarfile.TarInfo(name);ti.size=len(data);ti.mode=0o644;ti.mtime=0;t.addfile(ti,io.BytesIO(data));inputs.append(name)
save('inputs.tar.gz',stream.getvalue());binaries={str(p):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in[out/'oracle',*[out/'bootstrap'/n for n in['stage1','stage2','stage3']]]}
(dest/'artifacts.json').write_text(json.dumps(dict(source_commit=core,dependency_base=base,source_sha256=h.hexdigest(),native_sha256=native,tests=tests,native_runs=native_runs,native_parents=native_parents,matrix_commands=53,balanced_censuses=12,go_only_control=m['go_only_control'],exploratory_refusal=bad[0]['name'],inputs=len(inputs),binaries=binaries,artifacts=artifacts),indent=2)+'\n');(dest/'README.md').write_bytes((out/'README.md').read_bytes());print(json.dumps(dict(artifacts=len(artifacts),native_runs=native_runs,inputs=len(inputs))))
