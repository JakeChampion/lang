from pathlib import Path
import hashlib,json,os,re,subprocess,time
root=Path('/workspace/lang-codecs-errors-publish');scratch=Path('/workspace/scratch/lang-codecs-errors-publish');out=scratch/'byte-matrix';out.mkdir(exist_ok=True)
oracle=scratch/'final-oracle';compiler=scratch/'final-validation/bootstrap/stage3';stdlib=root/'internal/stdlib'
fixtures={name:root/'conformance/cases'/name/'main.fern'for name in ['byte_views_in_codecs','byte_views_in_binary_codecs','minimum_i32_crc_seed','pad_multibyte_fill']}
core=set(fixtures);rows=[];goldens={};env=dict(os.environ)
metadata={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'producer_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256(oracle.read_bytes()).hexdigest(),'runs':rows}
def save():(scratch/'byte-matrix.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(name,args,extra=None):
 start=time.monotonic();r=subprocess.run(list(map(str,args)),cwd=root,env=dict(env,**(extra or {})),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 row={'name':name,'args':list(map(str,args)),'seconds':time.monotonic()-start,'exit':r.returncode,'stdout_bytes':len(r.stdout),'stderr_bytes':len(r.stderr)};rows.append(row);save();print(row,flush=True);assert r.returncode==0,(name,r.stdout.decode(errors='replace'),r.stderr.decode(errors='replace'));return r,row
for name,path in fixtures.items():
 for engine,tool in [('go',oracle),('self',compiler)]:
  modes=['-check','-interp'] if name in core else ['-check']
  for mode in modes:
   r,_=run(name+'-'+engine+mode,[tool,mode,path]+([stdlib]if engine=='self'else[]))
   if mode=='-interp':
    if False:assert b'# fail 0' in r.stdout and re.search(rb'1\.\.[1-9][0-9]*',r.stdout),r.stdout
    if name in goldens:assert r.stdout==goldens[name],(name,engine,'interpreter output mismatch')
    assert r.stdout==(path.parent/'expected.stdout').read_bytes(),(name,'fixture output mismatch')
    goldens[name]=r.stdout
 for target in ['x86-64-linux','arm64-linux','wasm32-wasi','arm64-darwin']:
  dest=out/(name+'-'+target)
  run(name+'-build-'+target,[compiler,'-target',target,'-o',dest,path,stdlib],{'FERN_STRICT_IR':'1','FERN_SANITIZE':'1','FERN_LEAKCHECK':'1'})
  if target=='arm64-darwin':assert dest.read_bytes()[:4]==bytes.fromhex('cffaedfe');continue
  args=[dest] if target=='x86-64-linux' else ['qemu-aarch64',dest] if target=='arm64-linux' else ['wasmtime','run',dest]
  r,row=run(name+'-run-'+target,args)
  m=re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)',r.stderr);assert m,(name,target,r.stderr);a,f,l=map(int,m.groups());assert a==f and l==0,(name,target,a,f,l);row['census']={'allocs':a,'frees':f,'live_bytes':l};save()
  if False:assert b'# fail 0' in r.stdout and re.search(rb'1\.\.[1-9][0-9]*',r.stdout),r.stdout
  if name in goldens:assert r.stdout==goldens[name],(name,target,'execution output mismatch')
  goldens[name]=r.stdout
metadata['complete']=True;save();print('PASS',len(rows),'commands',flush=True)
