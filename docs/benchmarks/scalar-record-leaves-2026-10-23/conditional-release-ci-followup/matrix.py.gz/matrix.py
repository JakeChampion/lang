from pathlib import Path
import hashlib, json, os, re, subprocess

root = Path('/workspace/lang-record-ci-followup')
out = Path('/workspace/scratch/lang-record-field-leaves/conditional-release-ci-followup')
text = (root / 'internal/testing/e2ecompiler/self_host_conditional_value_release_test.go').read_text()
source = re.search(r'const condAliasStructSrc = `([^`]+)`', text).group(1)
path = out / 'alias-struct.fern'
path.write_text(source)
compiler = Path('/workspace/scratch/lang-record-field-leaves/csv-path-integration/bootstrap/stage3')
rows = []
for target in ['x86-64-linux', 'arm64-linux', 'wasm32-wasi']:
    dest = out / target
    args = [str(compiler), '-target', target, '-o', str(dest)]
    if target == 'wasm32-wasi':
        args += ['-emit', 'command-module']
    args += [str(path), str(root / 'internal/stdlib')]
    env = {k: v for k, v in os.environ.items() if not k.startswith('FERN_')}
    env.update(FERN_LEAKCHECK='1', FERN_SANITIZE='1', FERN_STRICT_IR='1')
    result = subprocess.run(args, cwd=root, env=env, capture_output=True)
    for channel, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (out / (target + '-build.' + channel)).write_bytes(data)
    assert result.returncode == 0, (target, result.stderr)
    run = [str(dest)] if target == 'x86-64-linux' else ['qemu-aarch64', str(dest)] if target == 'arm64-linux' else ['wasmtime', 'run', str(dest)]
    result = subprocess.run(run, cwd=root, capture_output=True)
    for channel, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        (out / (target + '.' + channel)).write_bytes(data)
    census = re.search(rb'leakcheck: allocs=(\d+) frees=(\d+) live_bytes=(\d+)', result.stderr)
    assert result.returncode == 65 and census, (target, result.returncode, result.stderr)
    allocs, frees, live = map(int, census.groups())
    assert allocs > 0 and allocs == frees and live == 0, (target, allocs, frees, live)
    rows.append({'target': target, 'build_arguments': args, 'run_arguments': run, 'exit': result.returncode, 'allocs': allocs, 'frees': frees, 'live_bytes': live})
    print(target, allocs, frees, live)
oracle = Path('/workspace/scratch/lang-record-field-leaves/current-integration/oracle')
result = subprocess.run([str(oracle), '-interp', str(path)], cwd=root, capture_output=True)
assert result.returncode == 65, result
(out / 'matrix.json').write_text(json.dumps({'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'compiler_sha256': hashlib.sha256(compiler.read_bytes()).hexdigest(), 'oracle_sha256': hashlib.sha256(oracle.read_bytes()).hexdigest(), 'oracle_exit': result.returncode, 'fixture_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'runs': rows, 'complete': True}, indent=2) + '\n')
