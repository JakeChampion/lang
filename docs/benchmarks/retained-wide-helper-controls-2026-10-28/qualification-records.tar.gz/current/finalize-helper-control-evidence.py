from pathlib import Path
import subprocess,json,hashlib,gzip,tarfile,io,time
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-call-summaries');folder=Path('/tmp/image-wide-call-summary-evidence-secondary');source=(folder/'source-sha.txt').read_text().strip();git=lambda *a:subprocess.check_output(['git',*a],cwd=root,text=True).strip();sha=lambda b:hashlib.sha256(b).hexdigest();assert git('rev-parse','HEAD')==source and not git('status','--porcelain')
gates=json.loads((folder/'final-gates.json').read_text());go=json.loads((folder/'final-Go.json').read_text());private=json.loads((folder/'private-view-controls.json').read_text());reuse=json.loads((folder/'production-tool-reuse.json').read_text())
for j in [gates,go]:assert j['source']==source and j['sources_unchanged']and j['binaries_unchanged']and j['worktree_still_clean']and all(c['exit']==c['FAIL']==c['SKIP']==0 for c in j['checks'])
assert next(c for c in gates['checks']if c['name']=='targets-complexity')['PASS']==7 and next(c for c in gates['checks']if c['name']=='source-audit')['PASS']==219 and gates['Fern_format_files']==2110
assert private['compile_exit']==0 and private['sources_unchanged']and private['compiler_unchanged']and private['binary_sha256_before_execution']==private['binary_sha256_after_execution']and len(private['controls'])==7
assert all(c['actual_exit']==c['expected_exit']for c in private['controls'])and private['controls'][0]['heap']==dict(allocs=216528,frees=216528,live_bytes=0)
assert reuse['production_closure_unchanged']and not reuse['new_compiler_build']and reuse['make_q_exit']==0
assert go['oracle_actual_build']=='7872a0970739ed6cfc100b48750f1bfb5716a4bb'and go['oracle_sha256']=='05b739cb256bbb2daf2766495a698b1f49e654602f0a8476d34a5b9a0d9e3d6b'
tools=json.loads((folder/'final-tools-before.json').read_text())
for name,item in tools['tools'].items():assert sha(Path(item['selected_path']).read_bytes())==item['sha256']
tools.update(observed_after_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),all_before_hashes_unchanged=True);(folder/'final-tools-after.json').write_text(json.dumps(tools,indent=2)+'\n')
protected=[':(glob)compiler/*.fern','internal/stdlib','internal/check','internal/oracle','internal/syntax','cmd','bootstrap','Makefile','.github','scripts'];assert not git('diff','--name-only','64896fed6fc9288db3618f44fae2bac7bfe03fbf','HEAD','--',*protected)
base=root/'docs/benchmarks/retained-wide-helper-controls-2026-10-28';rel=str(base.relative_to(root));assert not base.exists()and subprocess.run(['git','cat-file','-e','HEAD:'+rel],cwd=root,stderr=subprocess.DEVNULL).returncode!=0 and not git('ls-files','--',rel);base.mkdir(parents=True);manifest=[];omitted=[]
for name in ['final-gates','final-Go','private-view-controls']:
 p=folder/(name+'.json');raw=p.read_bytes();target=base/(name+'.json.gz');data=gzip.compress(raw,mtime=0);target.write_bytes(data);manifest.append(dict(original=str(p),published=target.name,original_sha256=sha(raw),published_sha256=sha(data),published_bytes=len(data)))
payload=io.BytesIO();count=0
with tarfile.open(fileobj=payload,mode='w')as tar:
 for p in sorted(folder.rglob('*')):
  if not p.is_file()or p.is_symlink()or p.name in ['finalize-evidence.log','finalization-record.json','final-gates.json','final-Go.json','private-view-controls.json']:continue
  relative=p.relative_to(folder)
  if any((folder/Path(*relative.parts[:i])).is_symlink()for i in range(1,len(relative.parts))):continue
  raw=p.read_bytes()
  if raw.startswith(b'\x7fELF')or p.suffix in ['.elf','.wasm','.wat']:
   omitted.append(dict(path=str(p),bytes=len(raw),sha256=sha(raw)));continue
  info=tarfile.TarInfo('current/'+str(relative));info.size=len(raw);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(raw));count+=1
archive=gzip.compress(payload.getvalue(),mtime=0);(base/'qualification-records.tar.gz').write_bytes(archive);manifest.append(dict(original='Frozen qualification logs, sources, view packets, failures, and corrections',published='qualification-records.tar.gz',published_sha256=sha(archive),published_bytes=len(archive),member_count=count))
(base/'omitted-executable-identities.json').write_text(json.dumps(omitted,indent=2)+'\n')
evidence=dict(PR=13754,native_issue=13753,source=source,source_commit_precedes_final_campaigns=True,changed_test_drivers_only=True,production_tool_reuse=reuse,source_hash_count=len(gates['source_hashes']),sourcegate_node_count_unclaimed=True,Go_oracle_actual_build=go['oracle_actual_build'],Go_oracle_loaded_source=go['oracle_loaded_source'],Go_oracle_postrun_sha256=go['oracle_sha256'],all_tools_sampled_before_and_after=True,checks=[{k:v for k,v in c.items()if k!='command'}for c in gates['checks']],private_view_controls=dict(binary=private['binary_sha256_before_execution'],baseline_nonzero_balanced_zero_live=True,intentional_failures=6,ordinary_pass_claim_for_intentional_failures=False,all_assertion_messages_and_exit_codes_exact=True),old_control_function_bodies_and_order_byte_exact=True,old_models_apis_domains_production_baselines_unchanged=True,full_retained_machine_qualification=False,caller_machine_integration=False,full_CI_recovery=False,M5_epic='OPEN',manifest=manifest)
(base/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
text=(root/'docs/rc-log/2026-10-28-retained-wide-helper-controls.md').read_text()+'''\n## Final qualification\n
The final checks use source `'''+source+'''`.
The focused driver passed on native, ARM64, and Wasm through the original strict harness.
All three executions satisfied the nonzero balanced zero-live census assertion.
The stock harness private CLI hash was not separately recorded.
No invented private CLI identity appears in this evidence.

The source gate passed five runtime sets, fixture checks, compiler modules, standard library modules, and all 85 standalone drivers.
The nonverbose source gate does not establish a separate test-node count.
The focused driver passed four TAP nodes, and unchanged complexity checks passed three nodes, with zero skips.
All 2110 format inputs, Go build, vet, workflow lint, test names, CI self-tests, and 219 source-audit nodes passed.
All 6221 source hashes and all compiler and tool hashes remained unchanged.

The Go oracle from qualified source 7872 passed check and interpreter commands on the current fixture source.
Its actual build and loaded source identities remain separate in the raw record.
The production compiler and Go implementation match that qualified source byte for byte.
The copied CLI and raw binaries retain their actual 7872 identities.
The successful make freshness check confirms that the source gate did not rebuild the compiler.
No duplicate production compiler build or separate image-corpus campaign was necessary for these test-driver changes.

One private binary compiled successfully and retained the same hash across all seven executions.
Its unmodified baseline passed with 216528 balanced allocations and zero live bytes.
The dependency controls rejected all three incorrect views with exit 166.
The instruction controls rejected those views with exit 180 and the exact limit, operand, or decode assertion message.
Those six intentional failures remain separate from ordinary passes.
Their early-exit censuses do not establish a persistent compiler leak.

The first private coordinator contained an incorrect Python conditional expression.
Python rejected it before compilation or runtime execution.
The corrected coordinator adds the missing whitespace without a source, policy, or criterion change.
The archive preserves the original script, error log, corrected script, input packets, stdout, stderr, and source identities.

The fresh unchanged whole retained-machine command failed with exit 166 before this scope.
Its source and compiler context remain explicit in the before record.
The current helper diagnostic completed successfully and captured 29 lines, exact wide operands, and 124818 balanced allocations.
The complete retained-machine command still requires later caller-proof work.
The new focused qualification does not establish a whole-group pass.

The raw records, manifests, and private-view evidence remain separate from earlier campaigns.
All gzip records preserve their exact original bytes.
All archive members match their original files byte for byte.
Executables remain at their original paths with explicit hashes.
Caller-machine integration, actual CI recovery, native milestones, M5, and epic acceptance remain open.
'''
(base/'README.md').write_text(text)
for item in manifest:
 data=(base/item['published']).read_bytes();assert sha(data)==item['published_sha256']
 if'original_sha256'in item:assert gzip.decompress(data)==Path(item['original']).read_bytes()
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(archive)),mode='r')as tar:
 assert len(tar.getmembers())==count
 for item in tar.getmembers():assert tar.extractfile(item).read()==(folder/Path(item.name).relative_to('current')).read_bytes()
(base/'publication-checks.json').write_text(json.dumps(dict(all_gzip_roundtrips_exact=True,all_archive_members_exact=True,archive_members=count),indent=2)+'\n')
(folder/'finalization-record.json').write_text(json.dumps(dict(source=source,destination=str(base),archive_members=count,published_bytes=sum(p.stat().st_size for p in base.iterdir())),indent=2)+'\n');print('Evidence prepared',base,count,'exact archive members')
