Parent: #13717.

Fresh main 64896fed6fc9288db3618f44fae2bac7bfe03fbf reproduces the unchanged retained-machine failure with exit 166.
The source remains clean, and all source hashes remain unchanged.
A separate current-source diagnostic captures the actual selected helper and both decoder views.
The helper contains 29 instructions and starts with MOVABS 17179869184 into RAX, followed by CMP RAX against RSI.
The old decoder records an unknown first instruction.
The accepted wide decoder records kind 41, the exact I64 immediate, and kind 28 with source zero and destination six.

This scope repairs test-driver expectations for that actual helper.
It does not integrate the caller-machine proofs or change their call summaries.

Predeclared constraints:

- Preserve all production emitter instructions, compiler and runtime behavior, standard library sources, numeric domains, APIs, baselines, and thresholds.
- Preserve the old decoder and every old sample, address, shift, literal, unsupported-instruction, isolation, namespace, and boundary assertion.
- Preserve the order of the original decoder control groups.
- Update only the actual-output assertions to use the accepted wide decoder.
- Require exactly 29 instructions with the complete expected kind sequence and one instruction per selected line.
- Require MOVABS with the exact I64 limit, width 64, and destination RAX.
- Require the following width-64 comparison with source RAX and destination RSI.
- Preserve exact branch-label identity, label targets, freelist symbol, indexed-load operands, scale eight, and block-store operands.
- Update the dependency-boundary fixture to require those exact first two lines for the large helper.
- Preserve the capacity-helper expectation and all boundary and namespace controls.
- Add a focused driver that emits the actual current helper and runs both original control groups.
- Qualify that driver on native, Wasm, and ARM64 with unchanged strict sanitizer and leak checks.
- Require private incorrect-limit, swapped-comparison, and unsupported-instruction views to fail for exact assertion reasons.
- Preserve original linked runtime behavior during those private view controls.
- Record intentional control exits separately from ordinary successful zero-live qualification.
- Add no broad opcode allowance, NOP treatment, instruction removal, guard change, count relaxation, or numeric waiver.

Acceptance:

- [ ] Preserve the fresh unchanged failure, actual helper, decoder observations, and source/tool identities.
- [ ] Pass all preserved old decoder and namespace controls plus the exact current-output assertions.
- [ ] Pass the focused driver on native, Wasm, and ARM64 with nonzero balanced zero-live censuses and zero skips.
- [ ] Reject all three private view controls for their exact declared reasons.
- [ ] Complete appropriate Go, source, runtime, format, build, vet, audit, and unchanged complexity checks.
- [ ] Preserve production sources, old decoder APIs, numeric domains, baselines, thresholds, and unrelated assertions.
- [ ] Merge one READY PR normally at the exact full head and publish bounded evidence.

The full retained-machine command can still fail at later caller proofs.
Such a failure does not qualify as a pass.
Retained-driver recovery, caller-machine integration, actual CI recovery, M5, and epic acceptance remain open.

