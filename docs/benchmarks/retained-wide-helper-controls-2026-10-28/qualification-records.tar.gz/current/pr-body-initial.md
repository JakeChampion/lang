Closes #13753.

The retained dependency controls expect the old immediate comparison and 28 decoded instructions.
The current helper uses MOVABS 17179869184, a register comparison, and exactly 29 instructions.
This change updates only the actual-output assertions and adds a focused driver for both original control groups.

All original sample, address, shift, literal, unsupported-instruction, isolation, namespace, and boundary control functions remain byte for byte unchanged.
Their call order remains unchanged.
The current assertions require exact guard operands, branch-label identities, freelist operands, and store operands.
Production compiler sources, runtime behavior, old decoder APIs, numeric domains, baselines, and gate thresholds remain unchanged.

Initial Go check and interpreter runs passed.
The focused driver passed on native, ARM64, and Wasm with nonzero balanced zero-live censuses.
One private binary rejected all three incorrect views in both control groups with exact messages and exit codes.
Its unmodified baseline passed with 216528 balanced allocations and zero live bytes.
Its binary hash remained unchanged across all seven runs.
Intentional control exits remain separate from ordinary successful qualification.

Source commit: cac925e341192154358ff3dfda3e8d11009f51f7.
Final immutable qualification is in progress.
The production implementation matches qualified source 7872a0970739ed6cfc100b48750f1bfb5716a4bb, whose compiler and Go oracle identities remain explicit.
No production compiler rebuild is necessary for these test-driver changes.

The complete retained-machine command remains unqualified at later caller proofs.
Caller-machine integration, actual CI recovery, M5, and epic acceptance remain open.

