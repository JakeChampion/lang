from pathlib import Path
root=Path('/tmp/image-engine-secondary-worktrees/lang-image-retained-wide-call-summaries');folder=Path('/tmp/image-wide-call-summary-evidence-secondary/private-views');assert not folder.exists();folder.mkdir();(folder/'compiler').symlink_to(root/'compiler',target_is_directory=True)
(folder/'main.fern').write_text('''import "./compiler/drivers/ssaretainedprogram" as retained;
import "./compiler/drivers/ssadecrementdependencies" as dependencies;
import "./compiler/drivers/ssalargepushisas" as instructions;
import "std/io";
import "std/string";

function view(output: string, mutation: i32): string {
  if (mutation == 0) { return output; }
  let outer = output.split("__fern_large_push:\\n");
  if (outer.len() != 2) { exit(2); }
  let middle = outer[1].split("__fern_capw:\\n");
  if (middle.len() != 2) { exit(2); }
  let from = if (mutation == 2) { "cmpq %rax, %rsi" } else { "movabs $17179869184, %rax" };
  let to = if (mutation == 1) { "movabs $17179869185, %rax" } else { if (mutation == 2) { "cmpq %rsi, %rax" } else { "unknown_instruction" } };
  let parts = middle[0].split(from);
  if (parts.len() != 2) { exit(2); }
  return outer[0] + "__fern_large_push:\\n" + parts.join(to) + "__fern_capw:\\n" + middle[1];
}

pub function main(): i32 {
  let input = match (io.read_all_stdin_bytes()) { Ok(value) => value, Err(_) => { return 2; } };
  if (input.len() != 2 || input[0] > 2 || input[1] > 3) { return 2; }
  let mod = retained.module();
  let g = retained.program(mod);
  let output = retained.emit(g, g.cache, g.physical, false, true, true, 0, -1).text;
  let inspected = view(output, input[1] as i32);
  if (input[0] == 0 || input[0] == 2) { dependencies.run(inspected); }
  if (input[0] == 1 || input[0] == 2) { instructions.run(inspected); }
  print("private view baseline passed");
  return 0;
}
''')
print('private view source prepared outside tracked worktree')
