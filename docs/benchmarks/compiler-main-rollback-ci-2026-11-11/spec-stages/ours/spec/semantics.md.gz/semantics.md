# Behavioural semantics

Status: normative index. The rules that say what an accepted Fern
program *does* live as prose in `docs/`, written down as policy notes
before this directory existed. This file is the index of the claims
those notes make and of which conformance case pins each one.

`spec/diagnostics.md` is the sibling for rejections: it says which
programs the front-end refuses. This one says what the accepted ones
are guaranteed to do.

## Why an index and not a rewrite

The policy docs are living documents — they carry implementation
notes, the reasoning behind a choice, and corrections when the choice
turned out to have been described wrongly. Copying their rules here
would produce two statements of the same thing and one of them would
go stale. So the docs stay where they are, and this file adds the one
thing prose cannot do for itself: a machine-checked link from each
claim to a program that demonstrates it.

## Why that link is worth having

`docs/CLOSURE-CAPTURE.md` is the argument. It stated for months that
closures capture scalars **by value** — a snapshot taken at closure
creation. Every compiled backend had captured by reference since
#2896, deliberately, to match the interpreter. The document was not
describing a bug; it was describing a language that no implementation
had implemented, and nothing could tell, because a prose claim with no
test attached is unfalsifiable. It was corrected in #5479 by editing
the doc.

A claim in this index cannot fail that way silently: the case named in
the last column has to exist, has to name the claim back, and has to
pass on every backend it opts into.

## How the link is checked

`TestSemanticsIndexIsAccurate` (`internal/testing/e2e`) enforces, in both
directions:

- every claim ID is unique, and its doc exists;
- every named case exists under `conformance/cases`;
- every named case carries a `// spec: <ID>` comment naming the claim
  back, so a case cannot be repurposed out from under a claim, and a
  claim cannot point at a case that is about something else;
- every `// spec:` marker in the corpus names a claim that exists here,
  so a marker cannot outlive the claim it was written for;
- every doc in `spec/README.md`'s normative-prose table appears here
  with at least one claim;
- the counts in the paragraph below match the table.

The cases themselves are run by `TestFernFixtures` like any other, so
"pinned" means the behaviour is checked on every backend the case opts
into, not merely that a file exists.

**148 of 151** claims are pinned by a conformance case. The remaining
**three are freedoms** — see below. There are no gaps left.

## Freedoms are not gaps

Three rows are marked `n/a — freedom` rather than `—`. These are
places where the language deliberately declines to guarantee anything:
`docs/FLOAT-SEMANTICS.md` under-specifies the NaN bit-pattern, denormal
handling, and whether `-0.0` survives arithmetic, on the argument that
cross-backend bit-equality at the IEEE edges costs canonicalisation on
every NaN-producing op and buys nothing for the programs Fern is for.

A freedom cannot be pinned by a conformance case, because a case
asserts an output and the whole content of the claim is that no
particular output is owed. The distinction is worth keeping visible:
a `—` is work someone should do, and a `n/a` is a decision someone
already made. Collapsing them would turn three deliberate choices into
three apparent oversights, which is what a bare `—` would have made
of them.

## Claims

| Claim | Doc | Rule | Pinned by |
| --- | --- | --- | --- |
| `AA-01` | `docs/ARRAY-ALGEBRA.md` | Positional pairing truncates to the shorter input: `zip`, `dot`, `distance_f64` and `add` drop the longer tail rather than aborting or answering an `Option` | `array_pair_truncates` |
| `AA-02` | `docs/ARRAY-ALGEBRA.md` | A float reduction evaluates in index order, so no implementation may reassociate `sum` over an `f64[]` | `float_reduce_in_index_order` |
| `AB-01` | `docs/ARRAY-BOUNDS.md` | Reading an array past its end aborts | `oob_index_read` |
| `AB-02` | `docs/ARRAY-BOUNDS.md` | A negative index aborts | `oob_index_negative` |
| `AB-03` | `docs/ARRAY-BOUNDS.md` | Writing past the end (`xs.with(i, v)`) aborts | `oob_index_write` |
| `AB-04` | `docs/ARRAY-BOUNDS.md` | Array slice construction outside `0 <= lo <= hi <= len` aborts (a string slice answers `None` — `ST-01`) | `oob_slice_range` |
| `AB-05` | `docs/ARRAY-BOUNDS.md` | `lo == hi == len` is a legal empty array slice | `slice_at_length` |
| `AB-06` | `docs/ARRAY-BOUNDS.md` | An index that wrapping arithmetic makes negative aborts; the check reads the value, not the expression | `oob_index_wrapped` |
| `AB-07` | `docs/ARRAY-BOUNDS.md` | A loop guard past the length does not elide the check; the first out-of-range index aborts | `oob_loop_guard_past_length` |
| `AB-08` | `docs/ARRAY-BOUNDS.md` | A view's bound is its own length, not its storage's | `oob_view_index_past_view` |
| `AB-09` | `docs/ARRAY-BOUNDS.md` | An array slice with a negative low bound aborts | `oob_slice_negative_start` |
| `AB-10` | `docs/ARRAY-BOUNDS.md` | A guard on a wrapping sum (`i + 1 < len`) proves nothing about `i`; the read at the largest `i32` aborts | `oob_index_wrapped_guard` |
| `AB-11` | `docs/ARRAY-BOUNDS.md` | A guard on `i` proves nothing about `i - 1`; the read at -1 aborts | `oob_index_below_guard` |
| `AB-12` | `docs/ARRAY-BOUNDS.md` | A slice end that wrapping arithmetic makes negative aborts | `oob_slice_wrapped_end` |
| `AB-13` | `docs/ARRAY-BOUNDS.md` | A write at the largest `i32` index aborts like a read | `oob_write_wrapped_index` |
| `AB-14` | `docs/ARRAY-BOUNDS.md` | A scaled index that wraps negative fails its own guard, so the read is skipped | `index_wrapped_product_rejected` |
| `IS-01` | `docs/INTEGER-SEMANTICS.md` | `+ - * <<` wrap at the operand's width | `int_wrap` |
| `IS-02` | `docs/INTEGER-SEMANTICS.md` | Shift counts are masked (`& 31` / `& 63`) | `int_shift_count_masked` |
| `IS-03` | `docs/INTEGER-SEMANTICS.md` | `>>` is arithmetic for signed operands, logical for unsigned | `int_shift_count_masked` |
| `IS-04` | `docs/INTEGER-SEMANTICS.md` | `x / 0 == 0` — division never traps | `int_div_rem_by_zero` |
| `IS-05` | `docs/INTEGER-SEMANTICS.md` | `x % 0 == x` | `int_div_rem_by_zero` |
| `IS-06` | `docs/INTEGER-SEMANTICS.md` | `MIN / -1 == MIN` — no overflow trap | `int_min_arithmetic` |
| `IS-07` | `docs/INTEGER-SEMANTICS.md` | `MIN % -1 == 0` | `int_min_arithmetic` |
| `IS-08` | `docs/INTEGER-SEMANTICS.md` | `+\| -\| *\| <<\|` clamp to the type's `[MIN, MAX]` | `int_saturating_ops` |
| `IS-09` | `docs/INTEGER-SEMANTICS.md` | `+? -? *? /? %? <<? >>?` yield `None` on overflow, zero divisor, or out-of-range count | `int_checked_ops` |
| `IS-10` | `docs/INTEGER-SEMANTICS.md` | A saturating operator on `usize` is rejected (`E009`) | `sat_usize_rejected` |
| `IS-11` | `docs/INTEGER-SEMANTICS.md` | A saturating operator is rejected inside a `const` initializer | `sat_const_rejected` |
| `IS-12` | `docs/INTEGER-SEMANTICS.md` | `a <<? n` is `None` when bits are shifted out or `n` is negative or `>= width`, so it is `Some` exactly when `a * 2^n` fits | `int_checked_shl` |
| `IS-13` | `docs/INTEGER-SEMANTICS.md` | `<<\|` clamps exactly where `<<?` is `None`, to `MIN` for a negative value and `MAX` otherwise; `0 <<\| n` is `0` | `int_saturating_shl` |
| `IS-14` | `docs/INTEGER-SEMANTICS.md` | A checked or saturating shift on `usize` is rejected (`E009`) | `shift_usize_rejected` |
| `IS-15` | `docs/INTEGER-SEMANTICS.md` | A `/` or `%` whose divisor evaluates to zero inside a `const` initializer is rejected (`E093`) | `const_div_by_zero_rejected` |
| `IS-16` | `docs/INTEGER-SEMANTICS.md` | A declared `const` evaluates at its declared width: `+ - * <<` wrap there and a shift count masks to it | `const_folds_at_declared_width` |
| `IS-17` | `docs/INTEGER-SEMANTICS.md` | Widening integer casts extend by the source signedness, then interpret the destination bits | `integer_conversion_boundaries` |
| `IS-18` | `docs/INTEGER-SEMANTICS.md` | Narrowing integer casts retain the low destination-width bits | `integer_conversion_boundaries` |
| `IS-19` | `docs/INTEGER-SEMANTICS.md` | Checked integer casts return `None` outside the destination range and `Some` at representable boundaries | `integer_conversion_boundaries` |
| `FS-01` | `docs/FLOAT-SEMANTICS.md` | Float-to-int conversion of `NaN` yields `0` | `float_to_int_saturating` |
| `FS-02` | `docs/FLOAT-SEMANTICS.md` | Out-of-range float-to-int saturates to the destination's min / max | `float_to_int_saturating` |
| `FS-03` | `docs/FLOAT-SEMANTICS.md` | In-range float-to-int truncates toward zero | `float_to_int_saturating` |
| `FS-04` | `docs/FLOAT-SEMANTICS.md` | The NaN bit-pattern is not specified | n/a — freedom |
| `FS-05` | `docs/FLOAT-SEMANTICS.md` | Denormal handling is not specified | n/a — freedom |
| `FS-06` | `docs/FLOAT-SEMANTICS.md` | Whether `-0.0` survives arithmetic is not specified | n/a — freedom |
| `FS-07` | `docs/FLOAT-SEMANTICS.md` | Ordinary `+ - * /` and comparisons are portable across backends | `float_pythagoras` |
| `FS-08` | `docs/FLOAT-SEMANTICS.md` | A float `/` by zero in a `const` initializer folds to the same ±Inf or NaN it gives as code | `const_float_div_by_zero_ieee` |
| `CC-01` | `docs/CLOSURE-CAPTURE.md` | A mutation of a captured scalar inside a closure is visible outside | `closure_capture_shared_cell` |
| `CC-02` | `docs/CLOSURE-CAPTURE.md` | A write to the outer variable is visible inside the closure | `closure_capture_shared_cell` |
| `CC-03` | `docs/CLOSURE-CAPTURE.md` | Assigning a reference-typed capture is rejected, inside the closure and from the enclosing scope when the stored value can reach a closure (`E049`) | `diag_e049` |
| `CE-01` | `docs/CELL-TYPE-PLAN.md` | A Cell snapshot retains native descriptor values and nested cycle-free data without duplicating the OS resource | `cell_native_descriptor_snapshots` |
| `DI-01` | `docs/INITIALIZATION.md` | Every local scalar declaration requires an initializer | `init_missing_scalar` |
| `DI-02` | `docs/INITIALIZATION.md` | A local binding is unavailable in its own initializer (`E001`) | `init_self_reference` |
| `DI-03` | `docs/INITIALIZATION.md` | A branch-local binding cannot escape its block (`E001`) | `init_branch_scope_escape` |
| `DI-04` | `docs/INITIALIZATION.md` | A struct literal must provide every required field (`E005`) | `err_missing_field` |
| `DI-05` | `docs/INITIALIZATION.md` | The name `null` is an ordinary unbound identifier without a declaration (`E001`) | `init_null_identifier` |
| `DI-06` | `docs/INITIALIZATION.md` | A field cannot be read directly from an `Option` value (`E043`) | `init_option_field_rejected` |
| `DI-07` | `docs/INITIALIZATION.md` | Assignments in either branch update an initialized outer binding | `init_branch_control` |
| `DI-08` | `docs/INITIALIZATION.md` | Matching `Some` and `None` permits a checked optional payload read | `init_option_control` |
| `DI-09` | `docs/INITIALIZATION.md` | Every local array declaration requires an initializer | `init_missing_array` |
| `DI-10` | `docs/INITIALIZATION.md` | A loop-local binding cannot escape its block (`E001`) | `init_loop_scope_escape` |
| `DI-11` | `docs/INITIALIZATION.md` | An enum constructor requires every payload argument (`E036`) | `init_variant_payload_missing` |
| `DI-12` | `docs/INITIALIZATION.md` | Both empty and payload enum variants produce initialized typed values | `init_variant_control` |
| `DI-13` | `docs/INITIALIZATION.md` | A struct update retains initialized fields from its base | `init_struct_update_control` |
| `DI-14` | `docs/INITIALIZATION.md` | A local callable or callback parameter shadows a builtin function name, including in a nested closure; calls use the resolved signature | `cell_constructor_shadowed_callbacks` |
| `ML-01` | `docs/MODE-LATTICE.md` | A borrowed value cannot be passed to an `own` parameter (`E051`) | `diag_e051` |
| `ML-02` | `docs/MODE-LATTICE.md` | A `fip` function may not allocate (`E053`) | `diag_e053` |
| `ML-03` | `docs/MODE-LATTICE.md` | A `[T]` view of function-local storage may not be returned (`E063`), on its own or inside a returned struct, tuple, array or enum | `diag_e063` |
| `ML-04` | `docs/MODE-LATTICE.md` | A `str` view of a function-local string, may not be returned (`E065`), on its own or inside a returned struct, tuple, array, map or enum. The front end refuses the direct return. The lowering refuses a view that a reassignment put in the returned value. Additional controls: `diag_e065_array_reassigned` and `diag_e065_map_reassigned`. | `diag_e065` |
| `ML-05` | `docs/MODE-LATTICE.md` | Using an owned parameter after it is consumed is rejected (`E050`) | `diag_e050` |
| `ML-06` | `docs/MODE-LATTICE.md` | A `fbip` function that allocates without a donor to reuse is rejected (`E068`) | `diag_e068` |
| `ML-07` | `docs/MODE-LATTICE.md` | A closure may not capture a value holding a borrowed view (`E082`) | `diag_e082` |
| `ML-08` | `docs/MODE-LATTICE.md` | An `if` or `match` expression whose arms build fresh arrays can be lent as a view, and the chosen arm's storage lives until the view's last use | `view_of_branch_value` |
| `ML-09` | `docs/MODE-LATTICE.md` | A local array view accepts a matching owned array, literal, or temporary and preserves its contents across owner updates | `local_array_views_keep_their_storage` |
| `EO-01` | `docs/EVALUATION-ORDER.md` | A call evaluates its callee or receiver before arguments, then evaluates positional arguments from left to right | `evaluation_order_effects` |
| `EO-02` | `docs/EVALUATION-ORDER.md` | Named arguments evaluate in parameter declaration order, and omitted arguments use constant defaults | `evaluation_order_effects` |
| `EO-03` | `docs/EVALUATION-ORDER.md` | Operands, indices, slices, and aggregate contents follow the specified evaluation order | `evaluation_order_effects` |
| `EO-04` | `docs/EVALUATION-ORDER.md` | Boolean operators short-circuit, and conditional expressions evaluate only the selected arm | `evaluation_order_effects` |
| `CL-01` | `internal/stdlib/core/cmp.fern.md` | Float Eq, Ord, and Hash satisfy equivalence, total order, and equal-hash laws | `comparison_float_laws` |
| `CL-02` | `internal/stdlib/core/cmp.fern.md` | Float collection traits equate signed zeros and all NaNs, and order NaNs after numbers | `comparison_float_laws` |
| `SS-01` | `internal/stdlib/std/string.fern.md` | String chunks preserve scalar boundaries and return one nonempty chunk at nonpositive sizes, while array chunks return none | `collection_edge_policies` |
| `SI-01` | `internal/stdlib/std/i32.fern.md` | Signed abs_diff returns a wrapping result at its result width, including a negative result when the mathematical distance exceeds MAX | `collection_edge_policies` |
| `MC-01` | `docs/MUST-CONSUME.md` | A `@must_consume` value unconsumed on some path is rejected (`E067`) | `diag_e067` |
| `MC-02` | `docs/MUST-CONSUME.md` | An `own` parameter is the declared sink, exempt from `E067` | `must_consume_own_sink` |
| `MC-03` | `docs/MUST-CONSUME.md` | A consuming call inside a `match` scrutinee is a consuming use | `must_consume_in_match_tag` |
| `MC-04` | `docs/MUST-CONSUME.md` | A method call passes its receiver, so it is a consuming use of a `@must_consume` receiver | `must_consume_method_receiver` |
| `MC-05` | `docs/MUST-CONSUME.md` | A consuming call inside an `if` condition, or in the scrutinee of a match on literals, is a consuming use | `must_consume_in_if_condition` |
| `WK-01` | `docs/WORKERS.md` | A `send` parameter admits only a send-safe argument; a closure written at the call crosses with send-safe captures and result, and a function value does not (`E100`) | `diag_e100` |
| `WK-02` | `docs/WORKERS.md` | `worker.spawn` runs its closure once and `join` returns the result, with the same contents on every engine | `worker_spawn_join` |
| `WK-03` | `docs/WORKERS.md` | A `Worker` is `@must_consume`, so a spawned worker that is not joined is rejected (`E067`) | `diag_e067_worker_unjoined` |
| `WK-04` | `docs/WORKERS.md` | `__send_copy` returns a fresh deep copy with the same contents, for a string, an array, a tuple, a record, an enum in either layout and a map | `send_copy_deep` |
| `WK-05` | `docs/WORKERS.md` | On native Linux a worker runs as another process, and its result crosses back through the shared region | `worker_runs_in_its_own_process` |
| `WK-06` | `docs/WORKERS.md` | A simulation is a worker scheduler: a worker spawned on it parks on the virtual clock, its result crosses back at the join, and the joins move the clock to the deadlines | `worker_runs_on_the_simulation` |
| `WK-07` | `docs/WORKERS.md` | A type parameter bounded by `worker.Send` crosses the worker boundary, the bound holds only for a send-safe type argument (`E021`), and no impl declares `Send` (`E021`) | `worker_send_bound` |
| `AL-01` | `docs/ALLOCATION-OBSERVABLE.md` | A loop that reclaims what it allocates does not grow the fresh-allocation high-water mark with the round count | `alloc_flat_under_reclaim` |
| `AL-02` | `docs/ALLOCATION-OBSERVABLE.md` | A loop that retains what it allocates does grow it with the round count | `alloc_grows_when_retained` |
| `AL-03` | `docs/ALLOCATION-OBSERVABLE.md` | A loop that allocates a closure environment per round reclaims it too | `alloc_flat_closure_env` |
| `AL-04` | `docs/ALLOCATION-OBSERVABLE.md` | A loop that only READS a container — a map lookup, hit or miss — reclaims what the read allocated | `alloc_flat_map_get` |
| `AL-05` | `docs/ALLOCATION-OBSERVABLE.md` | A loop that recycles a block still calls the allocator every round: the allocation COUNT scales with the round count where the fresh-byte mark stays flat | `alloc_count_sees_recycling` |
| `AL-06` | `docs/ALLOCATION-OBSERVABLE.md` | An aggregate literal buys its box after evaluating its operands, so an operand that reads the allocation count does not see the literal's own box | `eval_order_aggregate_literal` |
| `SH-01` | `docs/security/UNSAFE-INVENTORY.md` | The owned result of share_unchecked survives local aliases and helper returns. An unsafe block alone grants no ownership | `share_owner_result_survives_aliases` |
| `VT-01` | `docs/VALUE-TYPES.md` | A checked value cleanup preserves retained COW holders | `value_cleanup_keeps_cow_aliases` |
| `VT-02` | `docs/VALUE-TYPES.md` | Value fields cannot retain resource handles | `diag_e051_value_descriptor` |
| `VT-03` | `docs/VALUE-TYPES.md` | Value fields cannot retain mutable cells or callbacks | `diag_e051_value_cell` |
| `VT-04` | `docs/VALUE-TYPES.md` | Value fields cannot retain borrowed views or unconstrained types | `diag_e051_value_view` |
| `VT-05` | `docs/VALUE-TYPES.md` | Value fields cannot retain consumption obligations | `diag_e051_value_obligation` |
| `ST-01` | `docs/STRINGS-SOTA.md` | `s[a:b]` on a string yields `None` when an endpoint is out of range, rather than aborting | `string_slice_option` |
| `ST-02` | `docs/STRINGS-SOTA.md` | `s[a:b]` on a string yields `None` when an endpoint splits a UTF-8 code point | `string_slice_option` |
| `ST-03` | `docs/STRINGS-SOTA.md` | `slice_unchecked(s, a, b)` indexes bytes and checks no code-point boundary | `slice_unchecked_bytes` |
| `ST-04` | `docs/STRINGS-SOTA.md` | `slice_unchecked(s, a, b)` aborts when its bounds are out of range | `slice_unchecked_oob` |
| `SC-01` | `docs/SAFETY-CONTRACT.md` | A call to an unsafe function is accepted only inside an `unsafe` block, through a direct call, a method, a trait object, a bound type parameter, an import, or a closure that holds its own block (`E095` otherwise) | `unsafe_block_accepts_obligations` |
| `SC-02` | `docs/SAFETY-CONTRACT.md` | A call to a raw builtin (the raw allocation, load, store, copy, fill and release builtins, the box count helpers, `__arr_set_len`, the heap checkpoints, the `__c_call` forms, the task hooks and the syscall floor) is accepted only inside an `unsafe` block, in a function body or in a closure (`E095` otherwise) | `unsafe_block_accepts_raw_builtins` |
| `RH-01` | `docs/security/HANDLE-AUDIT.md` | A handle whose `close` consumes its receiver cannot be closed twice; the first close is not the local's last use (`E051`) | `diag_e051_handle_closed_twice` |
| `RH-02` | `docs/security/HANDLE-AUDIT.md` | A handle is not read after a consuming close (`E051`) | `diag_e051_handle_read_after_close` |
| `RH-03` | `docs/security/HANDLE-AUDIT.md` | A handle passed to an `own` parameter is not used after the transfer (`E051`) | `diag_e051_handle_used_after_transfer` |
| `RH-04` | `docs/security/HANDLE-AUDIT.md` | A handle with a consuming close is closed exactly once at a local's last use, through an `own` parameter, and on each branch that closes or stores it | `handle_transfer_closes_once` |
| `RH-05` | `docs/security/HANDLE-AUDIT.md` | The built-in close consumes its handle, so a second close of a built-in `Reader` is refused (`E050`) | `diag_e050_builtin_reader_closed_twice` |
| `RH-06` | `docs/security/HANDLE-AUDIT.md` | A deferred consuming close runs at the function's exit and is the handle's last use; the handle stays readable after the `defer` statement | `handle_defer_closes_at_exit` |
| `RH-07` | `docs/security/HANDLE-AUDIT.md` | A field of a fresh local or of an `own` parameter moves out to a consuming call at the path's last use; a sibling field stays owned | `handle_field_closes_from_local` |
| `RH-08` | `docs/security/HANDLE-AUDIT.md` | A close after a deferred close of the same handle is a second consumption (`E051`) | `diag_e051_handle_closed_after_defer` |
| `RH-09` | `docs/security/HANDLE-AUDIT.md` | A field closed twice makes the first close a borrow (`E051`) | `diag_e051_handle_field_closed_twice` |
| `RH-10` | `docs/security/HANDLE-AUDIT.md` | A transfer of the whole after one of its fields moved out makes the field close a borrow (`E051`) | `diag_e051_handle_whole_used_after_field_close` |
| `RH-11` | `docs/security/HANDLE-AUDIT.md` | A deferred consuming close inside a loop of a handle declared outside it is refused (`E051`) | `diag_e051_handle_deferred_close_in_loop` |
| `RH-12` | `docs/security/HANDLE-AUDIT.md` | An `own` parameter a deferred call consumes is consumed nowhere else (`E050`) | `diag_e050_owned_handle_consumed_after_defer` |
| `RH-13` | `docs/security/HANDLE-AUDIT.md` | A handle a closure captures cannot be closed by a deferred consuming call (`E051`) | `diag_e051_handle_captured_then_deferred` |
| `RH-14` | `docs/security/HANDLE-AUDIT.md` | A consuming close inside a loop is the handle's last use when every path from the close leaves the loop by a return, a break or a labelled break; a local the loop body declares closes once per round | `handle_closes_on_loop_exit` |
| `RH-15` | `docs/security/HANDLE-AUDIT.md` | A close before a `continue` is not the handle's last use (`E051`) | `diag_e051_handle_closed_before_continue` |
| `RH-16` | `docs/security/HANDLE-AUDIT.md` | A close of a handle declared outside the loop on a path that reaches the end of the loop body is refused (`E051`) | `diag_e051_handle_closed_each_round` |
| `RH-17` | `docs/security/HANDLE-AUDIT.md` | A consuming close in a loop's head is refused (`E051`) | `diag_e051_handle_closed_in_loop_head` |
| `RH-18` | `docs/security/HANDLE-AUDIT.md` | A match on a local at its last use, or on a field path of a local at the path's last use, moves the payload into the arm | `handle_payload_closes_from_local_match` |
| `RH-19` | `docs/security/HANDLE-AUDIT.md` | A pattern binding of an owned scrutinee owns its payload, so a field of the payload moves out at the path's last use | `handle_payload_field_closes` |
| `RH-20` | `docs/security/HANDLE-AUDIT.md` | A for-each over an owned array, a fresh local at its last use or an `own` parameter, binds each element owned | `handle_elements_close_in_for_each` |
| `RH-21` | `docs/security/HANDLE-AUDIT.md` | A match that is not the local's last use lends its payload (`E051`) | `diag_e051_handle_matched_after_payload_closed` |
| `RH-22` | `docs/security/HANDLE-AUDIT.md` | A pattern binding of a borrowed scrutinee lends its payload, so a field of it cannot move out (`E051`) | `diag_e051_handle_payload_field_of_borrowed` |
| `RH-23` | `docs/security/HANDLE-AUDIT.md` | A for-each over a borrowed array lends each element (`E051`) | `diag_e051_handle_elements_closed_from_borrowed_array` |
| `RH-24` | `docs/security/HANDLE-AUDIT.md` | A payload a match takes from a local at its last use is a fresh local: it is stored and read again in the same arm | `match_taken_payload_is_a_fresh_local` |
| `RH-25` | `docs/security/HANDLE-AUDIT.md` | A write to a built-in `Writer` after its close is refused (`E051`) | `diag_e051_builtin_writer_written_after_close` |
| `RH-26` | `docs/security/HANDLE-AUDIT.md` | A variant constructor carries its payload, so a result that wraps a borrowed value cannot pass to an `own` parameter (`E051`) | `diag_e051_variant_result_borrows_its_payload` |
| `RH-27` | `docs/security/HANDLE-AUDIT.md` | A local initialised from a call whose result can hold a handle and borrows its argument is not a fresh value (`E051`). Generic parameters, elements, and callback results retain this borrow | `diag_e051_local_from_borrowing_call` |
| `RH-28` | `docs/security/HANDLE-AUDIT.md` | A call to a function that never returns ends the path, so an own parameter it consumes in a loop is not used again | `handle_consumed_before_a_call_that_never_returns` |
| `RH-29` | `docs/security/HANDLE-AUDIT.md` | A name a match arm binds is declared afresh each round, so a payload taken in a loop closes once each round | `handle_payload_closes_in_loop_from_unpack` |
| `RH-30` | `docs/security/HANDLE-AUDIT.md` | A field moves to a consuming call while the same call reads other fields of its owner | `handle_field_closes_beside_other_field_reads` |
| `RH-31` | `docs/security/HANDLE-AUDIT.md` | A call that moves a field cannot read the same field in another argument (`E051`) | `diag_e051_handle_field_moved_beside_same_field` |
| `RH-32` | `docs/security/HANDLE-AUDIT.md` | An own parameter consumed in a loop body is refused at the consume (`E050`) | `diag_e050_owned_handle_consumed_inside_loop` |
| `RH-33` | `docs/security/HANDLE-AUDIT.md` | A local initialised from a call whose result cannot hold a handle is a fresh value | `local_from_handle_free_call_is_fresh` |
| `RH-34` | `docs/security/HANDLE-AUDIT.md` | A local read out of a borrowed structure passes to an `own` parameter at its last use, in a `let`, an assignment or a `return`, when its type cannot hold a handle | `local_read_from_borrowed_struct_moves_at_last_use` |
| `RH-35` | `docs/security/HANDLE-AUDIT.md` | A handle read out of a borrowed structure cannot pass to an `own` parameter, not even at its last use (`E051`) | `diag_e051_handle_local_read_from_borrowed_struct` |
| `RH-36` | `docs/security/HANDLE-AUDIT.md` | A payload a match takes from a fresh value or an `own` parameter is an owned name that moves once when its type can hold a handle, and a fresh local when it cannot | `payload_binding_is_a_local` |
| `RH-37` | `docs/security/HANDLE-AUDIT.md` | A fresh local that an assignment gives a borrowed handle, and an alias of a borrowed parameter, cannot pass to an `own` parameter or to a consuming method (`E051`) | `diag_e051_fresh_local_reassigned_from_a_borrow` |
| `RH-38` | `docs/security/HANDLE-AUDIT.md` | A local holder and a global callee with the same name keep separate identities in the ownership analysis | `field_holder_shadows_callee` |
| `RH-40` | `docs/security/HANDLE-AUDIT.md` | An empty None is fresh, so a match that consumes an owned source can retain its owned result as a field of an owned literal | `owned_match_results_rebuild_literal` |

| `OR-01` | `docs/OWNED-RESULTS.md` | A checked owned result remains available through a generic callback and a function-valued field | `checked_owned_results` |
| `OR-02` | `docs/OWNED-RESULTS.md` | An owned generic result cannot transfer a borrowed parameter without a copy contract (`E051`) | `diag_e051_checked_result_borrows` |
| `OR-03` | `docs/OWNED-RESULTS.md` | An ordinary-result function cannot satisfy an owned-result function type (`E003`) | `diag_e003_checked_result_strengthening` |
| `OR-04` | `docs/OWNED-RESULTS.md` | Ordinary call results containing only immutable copyable data can transfer their own reference while COW preserves borrowed sources | `copied_call_results` |

## Every gap this index opened with is now closed

`IS-10`, `IS-11`, `ML-05`, `MC-01` and `MC-02` were all *rejections*
exercised only by a Go test under `internal/check/checker`. That is coverage
of the Go oracle, and the self-host compiler is the only compiler
(`docs/NATIVE-RETIREMENT.md`), so a Go test measures the wrong
implementation. `E050`
and `E067` were also two of the three codes `spec/diagnostics.md`
listed as unpinned, so those rows closed in both indexes at once.

`ML-06` was the interesting one, because it was not unpinned for want
of writing a case. `E068` is reported by `compiler/irfipverify.fern`
during *lowering*, after the checker has already accepted the program,
and a case with an `expected.error` file stops at the type check — so
the format itself could not express the claim. Rather than move the
`fbip` check forward into the checker to suit the test format, the
format grew an `expected.lowering-error` sidecar that asserts both
halves: the front end must accept the program and lowering must reject
it. A program the checker already rejects is reported by name and told
to move to `expected.error`, because which stage rejects a program is
exactly what these cases pin.

The lesson is worth keeping: an unpinnable claim is sometimes a fact
about the harness rather than about the language, and writing down
which of the two it is — rather than a bare `—` — is what made the
next step obvious.

## The store, and the first thing said about it

`AL-01` / `AL-02` are the first claims here that are about the **store**
rather than about values. Allocation was not unmeasured before them —
`TestX86_64AllocScaling` bounds asymptotics and
`TestSelfHostAllocDifferentialX86_64` compares the two compilers — but
both are Go tests on one backend, so neither survives the freeze and
neither can see a backend that allocates unlike the others. The
*corpus* pinned allocation behaviour nowhere at all, and every leak
investigation under #6127 had to build a bespoke differential harness
before it could measure anything.

They are deliberately weak: they say only that a reclaiming loop's
fresh-allocation high-water mark does not grow with the round count and
a retaining one's does. That is far short of a store semantics, and
`docs/ALLOCATION-OBSERVABLE.md` says which questions it leaves open. But
it is the difference between a property that can be pinned and one that
cannot, and the first thing it found was a real leak: the wasm backend
never reclaims a short-lived string, consuming exactly 32 fresh bytes
per iteration where x86-64 and arm64 are flat (#6423).

## What is still not here

The claims above are the ones the policy docs happen to state. They are
not a semantics: there is no typing rule, no memory model, and — beyond
the allocation-shape claims — no statement of when a value is freed.
`docs/EVALUATION-ORDER.md` defines expression evaluation order.
The `EO-*` cases check observable effects separately from allocation timing.

Read this file as a list of the promises that have been written down,
not as the set of promises Fern makes.
