# Diagnostics

Status: normative index. Every rejection the front-end can report has a
stable code, and every warning a `W` code, with an explanation (`fern -explain E0NN`, sourced from
`internal/syntax/diag/explanations/`), and — where one exists — a conformance
case that pins it.

The codes are the closest thing Fern has to a written statement of its
static semantics. The *rules* they enforce live only in code: the
compiler's checker, `compiler/checker.fern`, and the Go oracle's,
`internal/check/checker`. This index says which rules exist and which are
pinned by something an independent implementation could be measured
against, not what each rule is.

## Rendering and editor data

The compiler retains the code, message, primary location, related locations
and any replacement edit as structured data. The terminal renderer and LSP
consume those fields directly. Related locations can belong to another
module; literate source locations map back to the document. A redeclared
local variable points to its previous declaration.

Normal terminal output includes source context, related notes and applicable
fixes. `-color auto|always|never`, `NO_COLOR` and `-ascii` control colour and
the gutter; automatic box drawing requires a UTF-8 locale. `-q` or
`FERN_DIAG_FORMAT=terse` selects one plain physical line per diagnostic,
without context, notes, fixes or colour. Carriage returns and newlines in a
diagnostic header are escaped in this mode, including those in filenames.
The choice of terminal format does not remove editor metadata.

The LSP publishes secondary locations as `relatedInformation` and exposes
replacement edits as quickfix code actions. Its ranges use UTF-16 positions,
including supplementary Unicode characters and the end of a file. A textual
hint is not necessarily an applicable edit: migration advice that requires
restructuring a statement must not offer a name-only replacement.

A failed initializer poisons the binding in its scope, suppressing errors
that depend on its missing type. Independent errors still appear, including
errors in a match arm whose scrutinee failed to check. A later declaration of
the same name still reports the collision and its previous location.

## Why conformance coverage, when the Go tests already pass

Almost every code here is exercised by a Go test under
`internal/check/checker` or `internal/syntax/parser`. That is coverage of
the Go oracle's front end, and **none of it reaches the compiler users
run.**

The self-host compiler is the only compiler (`docs/NATIVE-RETIREMENT.md`).
A Go test cannot measure it; a conformance case can, because the corpus is
source plus expected output and any implementation can be run against it
(`TestFernFixturesSelfHostCheck` runs the compile-error cases through
`fern -check`). So a diagnostic rule with only Go-side coverage is a rule
the compiler is never checked against.

**91 of 114** codes are pinned by a conformance case. The table
below is verified against reality by `TestDiagnosticsIndexIsAccurate`:
a code with no explanation, an explanation with no row, a claimed case
that does not exist or does not actually emit the code, and a `—` on a
code some case *does* emit are all failures. The count in this paragraph
is checked too, so improving or regressing coverage has to be a visible
edit.

## The dead entry this found

`E039` documented a bare `len(x)` builtin with its own arity and
argument-type errors. No `errfCode` site emits it, and `len` is a
method — `xs.len()` — so the example in its own explanation could not
compile, let alone produce E039. `docs/SELFHOST-CHECKER-PORT.md` had
already noticed the code was dead without anyone removing the
explanation, so `fern -explain E039` went on describing a construct the
language does not have. It is deleted.

## Codes

| Code | Rule | Pinned by |
| --- | --- | --- |
| `E001` | Undefined identifier | `err_undefined_ident` |
| `E002` | Type mismatch | `err_return_type` |
| `E003` | Cannot assign value to variable of different type | `err_assign_type` |
| `E004` | Wrong number of arguments to a call | `err_arity` |
| `E005` | Struct literal missing field | `err_missing_field` |
| `E006` | Top-level declaration redeclared | `diag_e006` |
| `E007` | Duplicate field | `err_duplicate_field` |
| `E008` | Non-boolean condition | `err_if_not_bool` |
| `E009` | Operator requires integer-compatible operands | `err_operator_type` |
| `E010` | Reserved built-in name | `diag_e010` |
| `E011` | `break` or `continue` outside a loop | `diag_e011` |
| `E012` | `return` without value in a non-void function | `diag_e012` |
| `E013` | Variable already declared in this scope | `err_redeclare` |
| `E014` | Variant not part of enum | `diag_e014` |
| `E015` | Variant payload count mismatch | `diag_e015` |
| `E016` | Union declaration error | `diag_e016` |
| `E017` | Duplicate enum variant | `diag_e017` |
| `E018` | Duplicate function parameter | `diag_e018` |
| `E019` | Generic type-parameter count mismatch | `diag_e019` |
| `E020` | Empty array literal needs a type annotation | `diag_e020` |
| `E021` | Invalid method receiver / trait conformance | `diag_e021` |
| `E022` | `let-else` / `if-let` source error | `let_else_rejects_else_must_diverge` |
| `E023` | Unknown enum | — |
| `E024` | Tuple or struct destructure error | `param_destructure_err_arity` |
| `E026` | Wildcard `_` arm must be last | — |
| `E027` | Match guard must be boolean | — |
| `E028` | Match arm variant already covered | `diag_e014_imported_enum_names` |
| `E029` | Variant pattern qualifier mismatch | `diag_e029` |
| `E030` | `match` is not exhaustive | `err_nonexhaustive_match` |
| `E031` | Match arms have incompatible types | `diag_e031` |
| `E032` | `use` clause inference error | — |
| `E033` | Unsupported cast | `diag_e033` |
| `E034` | Array / indexing error | `diag_e034` |
| `E035` | Literal pattern error in match | `tuple_match_err_arity` |
| `E036` | Variant constructor call error | `diag_e036` |
| `E037` | Slice error | `diag_e037` |
| `E038` | Call error | `err_arg_type` |
| `E040` | Generic type-parameter inference / arity error | `generic_call_unit_variant_binds_nothing` |
| `E041` | Operator error | `diag_e041` |
| `E042` | `?` operator error | `diag_e042` |
| `E043` | Struct literal field error | `err_unknown_field` |
| `E044` | Captured variable has unsupported type | — |
| `E045` | Map key / value type error | `err_map_key_no_hash` |
| `E046` | Tuple field access error | `diag_e046` |
| `E047` | Integer literal out of range | `diag_e047` |
| `E048` | Field is immutable after construction | `compound_field_assign` |
| `E049` | A captured reference is read-only, on both sides of the capture | `diag_e049` |
| `E050` | Use of an owned parameter after it was consumed | `diag_e050` |
| `E051` | Argument to an owned parameter must be an owned value | `diag_e051` |
| `E052` | missing return in a value-returning function | `diag_e052` |
| `E053` | `fip` / `fbip` function violates its shape rules | `diag_e053` |
| `E054` | an `@export` function cannot be generic | — |
| `E055` | the result of a collection operation is unused | `diag_e055` |
| `E056` | cannot assign to an array element | `diag_e056` |
| `E057` | `Cell[T]` element type is not allowed | `diag_e057` |
| `E058` | labelled `break` / `continue` names no enclosing loop | `diag_e058` |
| `E059` | `as?` requires a `dyn Trait` value or an integer | `diag_e059` |
| `E060` | invalid `as?` downcast target | `diag_e060` |
| `E061` | block-expression has no trailing value | `diag_e061` |
| `E062` | ambiguous method on a multi-trait object | — |
| `E063` | returning a `[T]` slice that views function-local storage | `diag_e063` |
| `E064` | unknown type | `diag_struct_field_positions` |
| `E065` | returning a `str` view of a function-local string. Additional controls: `diag_e065_array_reassigned` and `diag_e065_map_reassigned`. | `diag_e065` |
| `E066` | target does not provide a required capability | — |
| `E067` | a `@must_consume` value was not consumed on every path | `diag_e067` |
| `E068` | `fip` / `fbip` function fails IR allocation verification | `diag_e068` |
| `E069` | a 32-bit value was reinterpreted as a pointer-shaped type | — |
| `E070` | a dependency package reaches a capability it was not granted | — |
| `E071` | a literal outside the Unicode scalar range was cast to `char` | — |
| `E072` | ? | — |
| `E073` | an explicit call to a `core/mem.Drop` finalizer | `diag_e073` |
| `E074` | two visible implementations of one method name on one type | `diag_e074` |
| `E075` | `init` and the handler disagree about process-lifetime state | `diag_e075` |
| `E076` | a parameter's default value is not a constant expression | `diag_e076` |
| `E077` | invalid named argument | `diag_e077` |
| `E078` | an `@try` enum does not have the shape `?` requires | — |
| `E079` | `?` inside a `defer` / `errdefer` action | `diag_e079` |
| `E080` | a handler reaches a host effect around its `Platform` bag | `a_handler_cannot_block_on_the_machine` |
| `E081` | a named function or `const` declares no type | — |
| `E082` | a closure captures a borrowed view | `diag_e082` |
| `E083` | a `for` subject is not iterable | `diag_e083` |
| `E084` | `main` takes a parameter or returns a type that cannot be an exit status | `diag_e084` |
| `E085` | a lane value is held inside another value | `diag_e085` |
| `E086` | an import does not resolve to a module | `diag_e086` |
| `E087` | a module-qualified name the importing module cannot use | `diag_e087` |
| `E088` | a `fern.toml` the loader refuses | — |
| `E089` | a const argument is not an integer literal or a const parameter | `diag_e089` |
| `E090` | an argument has the wrong kind for its parameter | `diag_e090` |
| `E091` | an assignment to a const or a const parameter | `diag_e091` |
| `E092` | a literate document does not tangle | — |
| `E093` | a `const` initializer is not a constant expression | `const_initialiser_not_a_constant` |
| `E094` | an embedded asset the compiler cannot resolve | — |
| `E095` | an unsafe obligation escapes its boundary | `diag_e095` |
| `E096` | a `Vec[N, T]` that names no lane type | `diag_e096` |
| `E097` | a builtin reserved for the standard library | `diag_e097` |
| `E098` | a builtin named as a value | `diag_e098` |
| `E099` | a built-in handle built from a literal | `diag_e099` |
| `E100` | a value that cannot cross a worker boundary passed to a `send` parameter | `diag_e100` |
| `E101` | an incorrect capability provider | `diag_e101` |
| `E102` | a `@norc` function that can allocate or change a reference count | `diag_e102` |
| `E103` | an `@interrupt` handler of the wrong shape, or for a target without a vector table | — |
| `E104` | an `@early` hook of the wrong shape, a second hook, or a target without a reset entry | — |
| `E105` | a `@secondary` entry of the wrong shape, a second entry, or a target without a secondary entry | — |
| `P001` | Unexpected token (parse error) | `diag_p001` |
| `P002` | Numeric literal error | `diag_p002` |
| `P003` | Left-hand side of assignment is not assignable | `diag_p003` |
| `P004` | At most one `_` placeholder in a piped call | `diag_p004` |
| `P005` | Input nests deeper than the parser's recursion bound | `diag_p005` |
| `P006` | `function` in expression position | `diag_p006` |
| `P007` | a method declares a receiver type parameter again | `diag_p007` |
| `P008` | type parameters before a function name | `diag_p008` |
| `W001` | a `todo` stub remains | — |
| `W002` | an ungoverned dependency reaches a capability | — |
| `W003` | a literate chunk is defined but never used | — |

For array fusion, map storage and ndarray kernel decisions, run
`fern -array-report FILE.fern` or compile with `FERN_ARRAY_REPORT=1`. The report
names each stage and a closed reason tag, including guarded reuse and why R7
declined a map. See [`ARRAY-ALGEBRA.md`](../docs/ARRAY-ALGEBRA.md) for the
interface.

## The 20 unpinned codes

These have Go-side coverage but no conformance case. Most resisted the
mechanical derivation used for the rest — their catalogue examples are
fragments that need a surrounding program the example does not supply,
or they need a multi-module or capability-manifest setup a single
`main.fern` cannot express (`E066`, `E070`). `E080` is reported by the
drivers rather than the checker, so the self-host rejection gate, which
reads the checker alone, cannot pin it. A compile-error case cannot pin a
warning, which is reported only for a program that checks, `E092`, which
needs a literate document rather than a `main.fern`, or `E094`, which needs
`-embed DIR`. They are the remaining
work, not a decision.
