package e2ecompiler

import (
	"bytes"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"testing"

	"github.com/jakechampion/lang/internal/pkg/modload"
	"github.com/jakechampion/lang/internal/testing/e2eharness"
	"github.com/jakechampion/lang/internal/tools/gates"
)

func TestSelfHostIRVerifyStructure(t *testing.T) {
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("irverify_run driver runs natively; skipping under an exec runner")
	}
	dir := t.TempDir()
	copySelfHostDriver(t, dir, "drivers/irverify_run.fern")
	bin := buildSelfHostBin(t, gcc, dir, "drivers/irverify_run.fern", "irverify_run")

	cmd := exec.Command(bin)
	out, _ := cmd.Output()
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("irverify_run did not exit normally")
	}
	if code := cmd.ProcessState.ExitCode(); code != 0 {
		t.Fatalf("irverify_run exit code = %d, want 0 — that code is the failing assertion's id in irverify_run.fern", code)
	}
	if want := "irverify: all structural checks agree"; !strings.Contains(string(out), want) {
		t.Errorf("irverify_run stdout = %q, want it to contain %q", out, want)
	}
}

func TestSelfHostIRVerifyStack(t *testing.T) {
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("irverify_run driver runs natively; skipping under an exec runner")
	}
	dir := t.TempDir()
	copySelfHostDriver(t, dir, "drivers/irverify_run.fern")
	bin := buildSelfHostBin(t, gcc, dir, "drivers/irverify_run.fern", "irverify_run")

	cmd := exec.Command(bin)
	out, _ := cmd.Output()
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("irverify_run did not exit normally")
	}
	if code := cmd.ProcessState.ExitCode(); code != 0 {
		t.Fatalf("irverify_run exit code = %d, want 0 — that code is the failing assertion's id in irverify_run.fern", code)
	}
	if want := "irverifystack: all stack checks agree"; !strings.Contains(string(out), want) {
		t.Errorf("irverify_run stdout = %q, want it to contain %q", out, want)
	}
}

func TestSelfHostIRVerifyFip(t *testing.T) {
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("irverify_run driver runs natively; skipping under an exec runner")
	}
	dir := t.TempDir()
	copySelfHostDriver(t, dir, "drivers/irverify_run.fern")
	bin := buildSelfHostBin(t, gcc, dir, "drivers/irverify_run.fern", "irverify_run")

	cmd := exec.Command(bin)
	out, _ := cmd.Output()
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("irverify_run did not exit normally")
	}
	if code := cmd.ProcessState.ExitCode(); code != 0 {
		t.Fatalf("irverify_run exit code = %d, want 0 — that code is the failing assertion's id in irverify_run.fern", code)
	}
	if want := "irfipverify: all allocation-budget checks agree"; !strings.Contains(string(out), want) {
		t.Errorf("irverify_run stdout = %q, want it to contain %q", out, want)
	}
}

func TestSelfHostIRVerifyProvided(t *testing.T) {
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("irverify_run driver runs natively; skipping under an exec runner")
	}
	dir := t.TempDir()
	copySelfHostDriver(t, dir, "drivers/irverify_run.fern")
	bin := buildSelfHostBin(t, gcc, dir, "drivers/irverify_run.fern", "irverify_run")

	cmd := exec.Command(bin)
	out, _ := cmd.Output()
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("irverify_run did not exit normally")
	}
	if code := cmd.ProcessState.ExitCode(); code != 0 {
		t.Fatalf("irverify_run exit code = %d, want 0 — that code is the failing assertion's id in irverify_run.fern", code)
	}
	if want := "irverifyprovided: all callee-resolution checks agree"; !strings.Contains(string(out), want) {
		t.Errorf("irverify_run stdout = %q, want it to contain %q", out, want)
	}
}

func TestSelfHostIRVerifyProvidedAudit(t *testing.T) {
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("modload driver runs natively; skipping under an exec runner")
	}
	dir := writeSelfHostModloadProject(t)
	bin := buildSelfHostBin(t, gcc, dir, "drivers/asm_modload_run.fern", "provided_audit")

	cmd := exec.Command(bin, "-provided-audit")
	out, _ := cmd.Output()
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("driver did not exit normally")
	}
	if cmd.ProcessState.ExitCode() != 0 {
		t.Fatalf("provided-audit failed:\n%s", out)
	}
	if !strings.Contains(string(out), "inventory entries are emitted by the backend") {
		t.Errorf("provided-audit stdout = %q, want the agreement line", out)
	}

	path := filepath.Join(dir, "drivers", "irverifyprovided.fern")
	src, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	const anchor = `"__fern_oob_abort",`
	if bytes.Count(src, []byte(anchor)) != 1 {
		t.Fatal("expected exactly one inventory anchor")
	}
	for _, control := range []struct{ label, symbol string }{
		{"missing-symbol-refused", "__fern_missing_audit_control"},
		{"unemitted-symbol-refused", "__fern_profile_finish"},
	} {
		t.Run(control.label, func(t *testing.T) {
			changed := bytes.Replace(src, []byte(anchor), []byte(anchor+` "`+control.symbol+`",`), 1)
			if err := os.WriteFile(path, changed, 0o644); err != nil {
				t.Fatal(err)
			}
			badBin := buildSelfHostBin(t, gcc, dir, "drivers/asm_modload_run.fern", "provided_audit_missing")
			bad := exec.Command(badBin, "-provided-audit")
			out, err := bad.CombinedOutput()
			if bad.ProcessState == nil || !bad.ProcessState.Exited() {
				t.Fatalf("audit control did not exit normally: %v\n%s", err, out)
			}
			if bad.ProcessState.ExitCode() != 1 || !strings.Contains(string(out), "1 inventory entrie(s) no backend emits:") || !strings.Contains(string(out), control.symbol) {
				t.Fatalf("audit must reject the unemitted inventory entry: exit=%d output=%q", bad.ProcessState.ExitCode(), out)
			}
		})
	}
}

func TestSelfHostIRVerifyProvidedCompilerClean(t *testing.T) {
	if testing.Short() {
		t.Skip("whole-compiler sweep is slow; skipped under -short")
	}
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("modload driver runs natively; skipping under an exec runner")
	}
	dir := writeSelfHostModloadProjectTyped(t)
	bin := buildSelfHostBin(t, gcc, dir, "drivers/asm_modload_run.fern", "provided_compiler")

	cmd := exec.Command(bin, filepath.Join(dir, "drivers/asm_modload_run.fern"), "-verifyprovided")
	out, _ := cmd.Output()
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("driver did not exit normally")
	}
	if cmd.ProcessState.ExitCode() != 0 {
		t.Fatalf("resolution pass reported problems on the compiler's own sources:\n%s", out)
	}
	checked, calls := parseProvidedTally(string(out))
	if checked < 500 {
		t.Errorf("pass checked %d functions of the compiler, expected the full set — a shrunken sweep proves nothing (out: %s)", checked, out)
	}
	if calls < 5000 {
		t.Errorf("pass resolved %d direct calls across the compiler, expected far more — a sweep that resolved nothing proves nothing (out: %s)", calls, out)
	}
}

func parseProvidedTally(out string) (int, int) {
	i := strings.Index(out, "checked ")
	if i < 0 {
		return 0, 0
	}
	var checked, calls int
	if _, err := fmt.Sscanf(out[i:], "checked %d functions, %d direct calls", &checked, &calls); err != nil {
		return 0, 0
	}
	return checked, calls
}

func TestSelfHostIRVerifyProvidedCorpusClean(t *testing.T) {
	if testing.Short() {
		t.Skip("corpus sweep is slow; skipped under -short")
	}
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("modload driver runs natively; skipping under an exec runner")
	}
	dir := writeSelfHostModloadProject(t)
	bin := buildSelfHostBin(t, gcc, dir, "drivers/asm_modload_run.fern", "provided_corpus")
	testProvidedCorpus(t, bin)
}

func testProvidedCorpus(t *testing.T, bin string) {
	t.Helper()
	stdRoot := langSrcAbs(t, filepath.Join("internal", "stdlib"))
	all, err := filepath.Glob(filepath.Join(langSrcAbs(t, "conformance"), "cases", "*", "main.fern"))
	if err != nil {
		t.Fatalf("globbing conformance cases: %v", err)
	}
	var mains []string
	for _, main := range all {
		if _, err := os.Stat(filepath.Join(filepath.Dir(main), "expected.error")); err != nil {
			mains = append(mains, main)
		}
	}
	if len(mains) < 400 {
		t.Fatalf("found %d conformance cases, expected the full corpus: a silently shrunken sweep proves nothing", len(mains))
	}

	type result struct {
		ran                     bool
		refused                 bool
		calls, modelled, bodies int
	}
	results := make([]result, len(mains))
	t.Run("cases", func(t *testing.T) {
		for i, main := range mains {
			name := filepath.Base(filepath.Dir(main))
			t.Run(name, func(t *testing.T) {
				t.Parallel()
				results[i].ran = true
				stage := stageProvidedFixture(t, stdRoot, filepath.Dir(main))
				want, readErr := os.ReadFile(filepath.Join(filepath.Dir(main), "expected.lowering-error"))
				if readErr == nil {
					testProvidedLoweringRefusal(t, filepath.Join(stage, "main.fern"), string(want))
					results[i].refused = true
					return
				}
				if !os.IsNotExist(readErr) {
					t.Fatal(readErr)
				}
				cmd := exec.Command(bin, filepath.Join(stage, "main.fern"), "-verifyprovided")
				var stderr bytes.Buffer
				cmd.Stderr = &stderr
				var out []byte
				err := withBuildMemoryMB(5*1024, func() error {
					var err error
					out, err = cmd.Output()
					return err
				})
				if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
					t.Fatalf("resolution driver did not exit normally: %v\n%s", err, out)
				}
				results[i].calls, err = validateProvidedCorpusVerdict(cmd.ProcessState.ExitCode(), string(out))
				if err != nil {
					t.Errorf("invalid resolution verdict: %v\n%s\nstderr:\n%s", err, out, stderr.String())
				}
				results[i].modelled, results[i].bodies = parseStackCoverage(string(out))
			})
		}
	})
	swept, refused, calls, modelled, bodies := 0, 0, 0, 0, 0
	for _, result := range results {
		if result.ran {
			swept++
			if result.refused {
				refused++
			}
			calls += result.calls
			modelled += result.modelled
			bodies += result.bodies
		}
	}
	if modelled != bodies {
		t.Errorf("stack pass modelled %d of %d lowered bodies; a skip is an op the pass's table does not carry", modelled, bodies)
	}
	if swept == len(mains) && calls < 2000 {
		t.Errorf("pass resolved %d direct calls across the corpus, expected far more: a sweep that resolved nothing proves nothing", calls)
	}
	t.Logf("swept %d/%d fixtures, resolved %d direct calls, stack-modelled %d/%d bodies", swept, len(mains), calls, modelled, bodies)
	t.Logf("validated %d expected lowering refusals through the production compiler", refused)
}

func testProvidedLoweringRefusal(t *testing.T, main, want string) {
	t.Helper()
	prog, _, err := modload.Load(main)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := gates.Check(main, prog, "", nil); err != nil {
		t.Fatalf("lowering fixture failed the front end: %v", err)
	}
	out := filepath.Join(t.TempDir(), "prog")
	cmd := e2eharness.SelfHostCompileCmd(t, e2eharness.TargetX86_64Linux, main, out)
	cmd.Env = e2eharness.SelfHostChildEnv()
	var output []byte
	err = withBuildMemoryMB(5*1024, func() error {
		var err error
		output, err = cmd.CombinedOutput()
		return err
	})
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("lowering compiler did not exit normally: %v\n%s", err, output)
	}
	if err := validateProvidedLoweringRefusal(cmd.ProcessState.ExitCode(), string(output), want); err != nil {
		t.Fatalf("invalid lowering refusal: %v\n%s", err, output)
	}
	if _, err := os.Stat(out); !os.IsNotExist(err) {
		t.Fatalf("refused fixture left an output executable: %v", err)
	}
}

var providedLoweringDiagnostic = regexp.MustCompile(`(?m)^.*: error\[E[0-9]{3}\]: `)

func validateProvidedLoweringRefusal(exitCode int, output, want string) error {
	if exitCode != 1 {
		return fmt.Errorf("compiler exited %d, want diagnostic status 1", exitCode)
	}
	if !providedLoweringDiagnostic.MatchString(output) || strings.Contains(output, "error: internal:") {
		return fmt.Errorf("expected a compiler diagnostic")
	}
	if strings.TrimSpace(want) == "" {
		return fmt.Errorf("empty expected.lowering-error")
	}
	for _, line := range strings.Split(want, "\n") {
		line = strings.TrimSpace(line)
		if line != "" && !strings.Contains(output, line) {
			return fmt.Errorf("missing expected diagnostic %q", line)
		}
	}
	return nil
}

func TestProvidedLoweringRefusalVerdict(t *testing.T) {
	const diagnostic = "main.fern:4:3: error[E065]: expected refusal\n"
	for _, tc := range []struct {
		name         string
		exit         int
		output, want string
		ok           bool
	}{
		{"exact", 1, diagnostic, diagnostic, true},
		{"message", 1, diagnostic, "expected refusal\n", true},
		{"all_lines", 1, diagnostic + "second detail\n", "expected refusal\nsecond detail\n", true},
		{"clean", 0, diagnostic, diagnostic, false},
		{"internal_exit", 3, diagnostic, diagnostic, false},
		{"signal", -1, diagnostic, diagnostic, false},
		{"wrong_message", 1, diagnostic, "another refusal", false},
		{"missing_detail", 1, diagnostic, "expected refusal\nsecond detail", false},
		{"no_diagnostic", 1, "expected refusal", "expected refusal", false},
		{"internal_error", 1, diagnostic + "error: internal: missing body\n", diagnostic, false},
		{"empty_expectation", 1, diagnostic, "", false},
		{"blank_expectation", 1, diagnostic, " \n", false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			err := validateProvidedLoweringRefusal(tc.exit, tc.output, tc.want)
			if (err == nil) != tc.ok {
				t.Fatalf("verdict = %v, want accepted %v", err, tc.ok)
			}
		})
	}
}

func parseStackCoverage(out string) (int, int) {
	i := strings.Index(out, "irverifystack: modelled ")
	if i < 0 {
		return 0, 0
	}
	var m, f int
	if _, err := fmt.Sscanf(out[i:], "irverifystack: modelled %d/%d", &m, &f); err != nil {
		return 0, 0
	}
	return m, f
}

var providedCorpusVerdict = regexp.MustCompile(`^irverifyprovided: (clean|[1-9][0-9]* problem\(s\)) \(checked ([0-9]+) functions, ([0-9]+) direct calls\)$`)

func validateProvidedCorpusVerdict(exitCode int, out string) (int, error) {
	if exitCode != 0 && exitCode != 1 {
		return 0, fmt.Errorf("driver exited %d, want verifier status 0 or 1", exitCode)
	}
	header, _, _ := strings.Cut(out, "\n")
	match := providedCorpusVerdict.FindStringSubmatch(header)
	if match == nil {
		return 0, fmt.Errorf("missing or malformed verifier tally")
	}
	checked, checkedErr := strconv.Atoi(match[2])
	calls, callsErr := strconv.Atoi(match[3])
	if checkedErr != nil || callsErr != nil || checked < 0 || calls < 0 {
		return 0, fmt.Errorf("invalid verifier counts")
	}
	dirty := match[1] != "clean"
	if dirty != (exitCode == 1) {
		return 0, fmt.Errorf("verifier header disagrees with exit %d", exitCode)
	}
	if dirty {
		return 0, fmt.Errorf("the verifier reported unresolved callees")
	}
	return calls, nil
}

func stageProvidedFixture(t *testing.T, stdRoot, caseDir string) string {
	t.Helper()
	stage := t.TempDir()
	for _, lib := range []string{"std", "core"} {
		if err := os.Symlink(filepath.Join(stdRoot, lib), filepath.Join(stage, lib)); err != nil {
			t.Fatalf("linking stdlib %s: %v", lib, err)
		}
	}
	files, err := filepath.Glob(filepath.Join(caseDir, "*.fern"))
	if err != nil {
		t.Fatalf("globbing fixture modules: %v", err)
	}
	for _, file := range files {
		src, err := os.ReadFile(file)
		if err != nil {
			t.Fatalf("reading %s: %v", file, err)
		}
		if err := os.WriteFile(filepath.Join(stage, filepath.Base(file)), src, 0o644); err != nil {
			t.Fatalf("staging %s: %v", file, err)
		}
	}
	return stage
}

func TestSelfHostIRVerifyRc(t *testing.T) {
	gcc, runner := x86_64Tooling(t)
	if len(runner) != 0 {
		t.Skip("irverify_run driver runs natively; skipping under an exec runner")
	}
	dir := t.TempDir()
	copySelfHostDriver(t, dir, "drivers/irverify_run.fern")
	bin := buildSelfHostBin(t, gcc, dir, "drivers/irverify_run.fern", "irverify_run")

	cmd := exec.Command(bin)
	out, _ := cmd.Output()
	if cmd.ProcessState == nil || !cmd.ProcessState.Exited() {
		t.Fatalf("irverify_run did not exit normally")
	}
	if code := cmd.ProcessState.ExitCode(); code != 0 {
		t.Fatalf("irverify_run exit code = %d, want 0 — that code is the failing assertion's id in irverify_run.fern", code)
	}
	if want := "irverifyrc: all reuse-donor checks agree"; !strings.Contains(string(out), want) {
		t.Errorf("irverify_run stdout = %q, want it to contain %q", out, want)
	}
}
