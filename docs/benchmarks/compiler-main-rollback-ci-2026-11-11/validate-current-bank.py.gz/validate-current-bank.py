from pathlib import Path
import json,subprocess,hashlib,datetime,os,traceback,gzip
out=Path(__file__).parent;root=Path('/workspace/lang-spec-index-pins-20261111-0230');source='38399ecf5c363e3ef9a2981fa63cef01ff5401cb';measured='ca80bd07aba3edc5b60f971ceb76ac3925cdb292';oldpub='7ed25d7e1c1c94d73cae445d61852197c4c4e6aa';oldfolder='docs/benchmarks/compiler-method-result-ci-2026-11-11'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
def blob(rev,path):return git('show',rev+':'+path)
def nums(b):return {a[0]:(int(a[1]),a[2:])for l in b.decode().splitlines()if l.strip()and not l.lstrip().startswith('#')for a in[l.split()]}
s={'source':source,'measured_commit':measured,'run':42958185608,'job':130320191632,'artifact':13830651344,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[]}
def save():(out/'bank-validation.json').write_text(json.dumps(s,indent=2)+'\n')
save()
try:
 assert git('rev-parse',source+'^{tree}')==git('rev-parse',measured+'^{tree}')
 artifact=out/'perf-artifact';o=json.loads((artifact/'origin.json').read_text());assert sha((artifact/'artifact.zip').read_bytes())==o['zip_sha256']=='53f22f15015fd92b9217eae85e543ff298b66fc35ef5c235a652968f5f4e0e58'
 for r in o['files']:assert sha((artifact/r['name']).read_bytes())==r['sha256'],r['name']
 before=(out/'before/.github/cliff-baseline.txt').read_bytes();after=(root/'.github/cliff-baseline.txt').read_bytes();a,b=nums(before),nums(after)
 assert a.keys()==b.keys() and [k for k in a if a[k]!=b[k]]==['x86_64/checker.cliff_count']
 assert a['x86_64/checker.cliff_count']==(378075,[]) and b['x86_64/checker.cliff_count']==(373796,[])
 assert all(l in after.decode().splitlines()for l in before.decode().splitlines()if l.startswith('#'))
 (out/'after-cliff-baseline.txt').write_bytes(after)
 env=dict(os.environ);env['FERN_CI_PERF_GATE_STRICT']='1'
 for k in ['FERN_CI_PERF_GATE_MAX_DRIFT','FERN_PERF_TOLERANCE_PERCENT']:env.pop(k,None)
 for label,baseline,expected in [('full-old',out/'before/.github/cliff-baseline.txt',1),('full-new',out/'after-cliff-baseline.txt',0)]:
  args=[str(root/'scripts/ci-check-perf'),str(baseline),str(artifact/'cliff-report.txt')];r={'label':label,'args':args,'expected_exit':expected};s['runs'].append(r);save()
  with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:p=subprocess.run(args,cwd=root,env=env,stdout=so,stderr=se,timeout=180)
  r['exit_code']=p.returncode;save();assert p.returncode==expected
  text=(out/(label+'.stdout')).read_text()+(out/(label+'.stderr')).read_text();assert 'MISSING:'not in text
 manifest_raw=blob(oldpub,oldfolder+'/manifest.json');m=json.loads(manifest_raw)
 for name,h in m['data_sha256'].items():assert sha(blob(oldpub,oldfolder+'/'+name))==h,name
 v=json.loads(blob(oldpub,oldfolder+'/validation.json'));assert v['exit_code']==0 and v['captured_comparator_children']==22
 identities={}
 for name in ['scripts/ci-check-perf','scripts/flag-lib','scripts/perf-gate-selftest.mjs','scripts/cliff-bench','.github/workflows/perf.yml','bootstrap/stage0.lock']:
  raw=blob(source,name);assert raw==blob('2ca148c6757a95ba419a67751dd3598726f07c56',name)==blob('29b1234d0699d6b42d7d85bbcd82dbfb92c6dce2',name)==(root/name).read_bytes(),name
  identities[name]={'sha256':sha(raw),'blob':git('rev-parse',source+':'+name).decode().strip()}
 s.update(exit_code=0,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),row_before=378075,row_after=373796,all_other_rows_and_tolerances_unchanged=True,default_tolerance_percent=1,full_report_missing_metrics=False,qualified_controls={'publication':oldpub,'folder':oldfolder,'verified_data_hashes':len(m['data_sha256']),'manifest_sha256':sha(manifest_raw),'canonical_results':22,'commands_executed':0},protocol=identities,source_product_trees={n:git('rev-parse',source+':'+n).decode().strip()for n in ['compiler','internal/stdlib','internal/check','internal/syntax','conformance']},limit='Source-specific counters. Certification disabled by the unchanged protocol. No normal timing or leak claim. Executable hash absent from CI reports.');save()
except Exception as e:s.update(exit_code=1,error=repr(e),traceback=traceback.format_exc());save();raise
