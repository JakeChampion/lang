from pathlib import Path
import subprocess,json,datetime,traceback,hashlib,os
out=Path(__file__).parent;root=Path('/workspace/lang-spec-index-pins-20261111-0230');owner='38399ecf5c363e3ef9a2981fa63cef01ff5401cb'
s={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parent':'ae541bcfb04b763b00d1b526cc3c02c2dbe9d0fd','owner_commit':owner,'runs':[]}
def save():(out/'result.json').write_text(json.dumps(s,indent=2)+'\n')
save()
try:
 assert hashlib.sha256(Path(os.environ['STAGE0']).read_bytes()).hexdigest()=='a66fcf94f418bea5f969bfaf2b07e6fe56235d2565ca405c950e6e263187a751'
 for rel in ['compiler/semndarray.fern','internal/testing/e2ecompiler/self_host_ndarray_inner_plan_test.go','internal/testing/e2ecompiler/self_host_ndarray_product_test.go']:
  assert (root/rel).read_bytes()==subprocess.check_output(['git','show',owner+':'+rel],cwd=root)
 s['tree']=subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip();save()
 commands=[('source-check',[os.environ['STAGE0'],'-check','compiler/fern.fern','internal/stdlib']),('gofmt',['gofmt','-l','internal/testing/e2ecompiler/self_host_ndarray_inner_plan_test.go','internal/testing/e2ecompiler/self_host_ndarray_product_test.go']),('targeted',['go','test','./internal/testing/e2ecompiler','-run','^TestSelfHost(Ndarray.*|InnerMulAdd.*|OuterMul.*|ScaleReuse.*)$','-count=1','-timeout=25m','-json']),('refusal-controls',['go','test','./internal/testing/e2ecompiler','-run','^TestProvidedLoweringRefusalVerdict$','-count=1','-timeout=5m','-json']),('metadata',['go','test','./internal/testing/e2e','./internal/testing/sourcelint','-run','^(TestDiagnosticsIndexIsAccurate|TestSemanticsIndexIsAccurate|TestConformanceCensusHasARowPerFixture)$','-count=1','-timeout=12m','-json']),('vet',['go','vet','./internal/testing/e2ecompiler']),('ci-selftest',['make','ci-selftest']),('whitespace',['git','diff','--cached','--check'])]
 for label,args in commands:
  row={'label':label,'args':args,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};s['runs'].append(row);save()
  with(out/(label+'.stdout')).open('xb')as so,(out/(label+'.stderr')).open('xb')as se:p=subprocess.run(args,cwd=root,stdout=so,stderr=se,timeout=1560)
  row.update(exit_code=p.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save();assert p.returncode==0,(label,p.returncode)
  if label=='gofmt':assert not(out/(label+'.stdout')).read_bytes()
  if '-json' in args:
   rows=[json.loads(x)for x in(out/(label+'.stdout')).read_text().splitlines()if x.strip()]
   row.update(passes=sum(x.get('Action')=='pass'and bool(x.get('Test'))for x in rows),skips=sum(x.get('Action')=='skip'for x in rows),failures=[x.get('Test')or x.get('Package')for x in rows if x.get('Action')=='fail']);save()
   assert not row['skips']and not row['failures']
   names={x.get('Test')for x in rows if x.get('Action')=='pass'}
   if label=='targeted':
    for n in ['TestSelfHostNdarrayInnerPlan','TestSelfHostNdarrayProductReport','TestSelfHostScaleReuseDecisions','TestSelfHostOuterMulEmissionAndShadow','TestSelfHostInnerMulAddEmissionAndShadow']:assert n in names,n
 s.update(exit_code=0,finished=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
except Exception as e:s.update(exit_code=1,error=repr(e),traceback=traceback.format_exc());save();raise
