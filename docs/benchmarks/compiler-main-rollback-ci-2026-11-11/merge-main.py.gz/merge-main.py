from pathlib import Path
import subprocess,json,os,shutil,hashlib,datetime
root=Path('/workspace/lang-spec-index-pins-20261111-0230');out=Path(__file__).parent
head='ae541bcfb04b763b00d1b526cc3c02c2dbe9d0fd';main='38399ecf5c363e3ef9a2981fa63cef01ff5401cb';base='2ca148c6757a95ba419a67751dd3598726f07c56';owner='e3bd8452c16add0ac0be07a553761dea1ba10567'
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==head
assert not git('status','--porcelain=v1')
refs=subprocess.check_output(['git','-c','credential.helper=','ls-remote','--heads','https://github.com/JakeChampion/lang.git','main','fix/e065-spec-index-pins'],cwd=root,text=True);(out/'pre-merge-refs.txt').write_text(refs)
refs={name:sha for sha,name in(line.split()for line in refs.splitlines())};assert refs['refs/heads/main']==main,refs;assert refs['refs/heads/fix/e065-spec-index-pins']==head,refs
assert git('merge-base',head,main).decode().strip()==base
incoming=git('diff','--name-only',base,main).decode().splitlines();restore=['compiler/semndarray.fern','internal/testing/e2ecompiler/self_host_ndarray_inner_plan_test.go','internal/testing/e2ecompiler/self_host_ndarray_product_test.go'];extra=['internal/testing/e2e/testdata/conformance-leak-census.txt','.github/cliff-baseline.txt','docs/benchmarks/compiler-checker-cliff-ci-2026-11-11/README.md']
links=[]
for name in sorted(set(incoming+restore+extra)):
 p=root/name
 if p.is_file()and not p.is_symlink():
  b=p.read_bytes();q=out/'before'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);st=p.stat();tmp=p.with_name(p.name+'.private-0600');shutil.copy2(p,tmp);os.replace(tmp,p);assert p.read_bytes()==b and p.stat().st_ino!=st.st_ino
  links.append({'path':name,'before_inode':st.st_ino,'before_nlink':st.st_nlink,'after_inode':p.stat().st_ino,'after_nlink':p.stat().st_nlink,'sha256':hashlib.sha256(b).hexdigest()})
(out/'linkbreaks.json').write_text(json.dumps(links,indent=2)+'\n');(out/'incoming.patch').write_bytes(git('diff','--binary',base,main))
for name in ['spec/diagnostics.md','spec/semantics.md']:
 for label,rev in [('base',base),('ours',head),('theirs',main)]:
  q=out/'spec-stages'/label/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(git('show',rev+':'+name))
r=subprocess.run(['git','merge','--no-ff','--no-commit',main],cwd=root,capture_output=True);(out/'merge.stdout').write_bytes(r.stdout);(out/'merge.stderr').write_bytes(r.stderr);unmerged=git('ls-files','-u');(out/'unmerged.txt').write_bytes(unmerged)
assert r.returncode in [0,1],r.returncode
if r.returncode:assert unmerged
for line in unmerged.decode().splitlines():
 fields,name=line.split('\t');mode,sha,stage=fields.split();q=out/'actual-conflict-stages'/stage/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(git('cat-file','blob',sha))
for name in ['spec/diagnostics.md','spec/semantics.md']:
 p=root/name;p.write_bytes(git('show',main+':'+name));subprocess.run(['git','add',name],cwd=root,check=True)
assert not git('ls-files','-u')
reverse=git('diff','--binary',owner,owner+'^','--',*restore);(out/'owner-reverse.patch').write_bytes(reverse)
r=subprocess.run(['git','apply','--index','-'],input=reverse,cwd=root,capture_output=True);(out/'reverse.stdout').write_bytes(r.stdout);(out/'reverse.stderr').write_bytes(r.stderr);assert r.returncode==0
for name in restore:assert(root/name).read_bytes()==git('show',main+':'+name),name
p=root/extra[0];lines=p.read_text().splitlines(keepends=True);removed=[x for x in lines if x.split()and x.split()[0]=='a_function_named_like_a_raw_builtin_shadows_it'];assert len(removed)==1 and removed[0].split()[1]=='0'
p.write_text(''.join(x for x in lines if x not in removed)+'\n# 2026-11-11: Main 38399ecf removed the raw-builtin shadow fixture.\n# Its zero row and original measurement remain in commit 102403811dcc.\n')
def numbers(b):return {x.split()[0]:x.split()[1:]for x in b.decode().splitlines()if x.strip()and not x.lstrip().startswith('#')}
assert numbers(p.read_bytes())==numbers(git('show',main+':'+extra[0]))
p=root/extra[1];old=p.read_text();lines=old.splitlines(keepends=True);found=0
for i,line in enumerate(lines):
 if line.split()and line.split()[0]=='x86_64/checker.cliff_count':
  assert line.split()[1]=='378075';lines[i]=line.replace('378075','373796',1);found+=1
assert found==1
p.write_text(''.join(lines)+'\n# 2026-11-11: Bank checker.cliff_count 378075 -> 373796 after main reverts.\n# Exact CI 42958185608 / job 130320191632 measures source ca80bd07aba3.\n# That source tree equals main 38399ecf. The 1% tolerance stays unchanged.\n')
a,b=numbers(old.encode()),numbers(p.read_bytes());assert [k for k in a if a[k]!=b[k]]==['x86_64/checker.cliff_count']
subprocess.run(['git','add',*extra[:2]],cwd=root,check=True)
assert not git('diff',main,'--','compiler','internal/stdlib','internal/check','internal/syntax','conformance'), 'product differs from new main'
assert not git('diff','--','internal/testing/e2ecompiler/self_host_irverify_test.go')
(out/'resolution.json').write_text(json.dumps({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head_before':head,'incoming_main':main,'owner_patch_reversed':owner,'restore_paths':restore,'compiler_stdlib_checker_syntax_conformance_exact_main':True,'spec_files_exact_main':True,'obsolete_census_row_removed':removed,'historical_comments_retained':True,'cliff_count_before':378075,'cliff_count_after':373796,'counter_artifact':13830651344,'source_tree':'187b398684070660808d6d05db7d82b08d6e4e96','no_feature_reintroduced':True},indent=2)+'\n')
subprocess.run(['git','diff','--cached','--check'],cwd=root,check=True)
print('RESOLVED',len(links),'private copies; product exact MAIN; both conflict sides retained')
