    .globl _start
    .text
__fn_http____find_crlf:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____find_crlf.k:
__fn_http____find_crlf.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____find_crlf_0:
    mov x10, #13
    mov x2, x9
    mov x1, x10
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L0
    mov x2, #0
.L0:
    cmp x1, #255
    b.hi .L5
    cmp x2, x3
    b.ge .L5
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L2
.L1:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L7
    cmp x5, x8
    b.ls .L1
.L2:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L3
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L3
    sub x5, x5, #16
    b .L8
.L7:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L8
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L8:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L6
.L3:
    cmp x5, x6
    b.ge .L5
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L4
    add x5, x5, #1
    b .L3
.L4:
    sub x2, x5, x0
    b .L6
.L5:
    mov x2, #-1
.L6:
    mov x0, x2
.Lssa_http____find_crlf_3:
    mov x21, x0
.Lssa_http____find_crlf_4:
    cmp x21, #0
    b.lt .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_8:
    add x10, x21, #1
    sxtw x10, w10
    cmp x10, x20
    b.ge .Lssa_http____find_crlf_2
.Lssa_http____find_crlf_7:
    add w10, w21, #1
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http____find_crlf_1
.Lssa_http____find_crlf_5:
    add x9, x21, #1
    sxtw x9, w9
    mov x10, #13
    mov x2, x9
    mov x1, x10
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L9
    mov x2, #0
.L9:
    cmp x1, #255
    b.hi .L14
    cmp x2, x3
    b.ge .L14
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L11
.L10:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L16
    cmp x5, x8
    b.ls .L10
.L11:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L12
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L12
    sub x5, x5, #16
    b .L17
.L16:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L17
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L17:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L15
.L12:
    cmp x5, x6
    b.ge .L14
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L13
    add x5, x5, #1
    b .L12
.L13:
    sub x2, x5, x0
    b .L15
.L14:
    mov x2, #-1
.L15:
    mov x21, x2
    cmp x21, #0
    b.ge .Lssa_http____find_crlf_8
.Lssa_http____find_crlf_2:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____find_crlf_1:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____shared_string:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____shared_string.k:
__fn_http____shared_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
.Lssa_http____shared_string_0:
    ldr x9, [x22, #8]
    sub x10, x21, x20
    sxtw x10, w10
    cmp x9, x10
    b.ne .Lssa_http____shared_string_1
.Lssa_http____shared_string_4:
    ldr x9, [x22, #8]
    mov x10, #0
    mov x4, x9
    mov x3, x10
    mov x2, x22
    mov x1, x20
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L18_aop
    mov x1, #0
.L18_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L18_bop
    mov x3, #0
.L18_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L18_nok
    mov x4, #0
.L18_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L18_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L18_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L18_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L18_done
.L18_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L18_vec
.L18_short:
    cmp x10, #8
    b.lt .L18_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L18_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L18_eq
    add x8, x8, x14
.L18_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L18_done
.L18_w4:
    cmp x10, #4
    b.lt .L18_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L18_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L18_eq
    add x8, x8, x14
.L18_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L18_done
.L18_w2:
    cmp x10, #2
    b.lt .L18_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L18_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L18_eq
    add x8, x8, x14
.L18_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L18_done
.L18_tail:
    cmp x8, x13
    b.ge .L18_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L18_th
    add x8, x8, #1
    add x9, x9, #1
    b .L18_tail
.L18_th:
    sub x2, x8, x12
    b .L18_done
.L18_eq:
    mov x2, x4
.L18_done:
    mov x0, x2
    ldr x10, [x22, #8]
    cmp x0, x10
    b.ne .Lssa_http____shared_string_1
.Lssa_http____shared_string_3:
    tbnz x22, #0, .Lssa_http____shared_string_rcinc30
    cmp x22, #16, lsl #12
    b.lo .Lssa_http____shared_string_rcinc30
    ldur w5, [x22, #-8]
    tbnz w5, #31, .Lssa_http____shared_string_rcinc30
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http____shared_string_rcinc30:
    mov x0, x22
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____shared_string_1:
    str x21, [sp, #-16]!
    str x20, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____token_is:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____token_is.k:
__fn_http____token_is.r:
.Lssa_http____token_is_0:
    ldr x10, [x0, #8]
    mov x11, #0
    mov x4, x11
    mov x11, x9
    mov x9, x4
    b __fn_http____token_at.r
    .cfi_endproc
    .ltorg
__fn_http____token_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____token_at.k:
__fn_http____token_at.r:
.Lssa_http____token_at_0:
.Lssa_http____token_at_10:
.Lssa_http____token_at_11:
    cmp x9, x10
    b.ge .Lssa_http____token_at_34
.Lssa_http____token_at_18:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w12, [x6, x9]
.Lssa_http____token_at_17:
    cmp x12, #32
    b.eq .Lssa_http____token_at_12
.Lssa_http____token_at_15:
    cmp x12, #9
    b.ne .Lssa_http____token_at_34
.Lssa_http____token_at_12:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____token_at_18
.Lssa_http____token_at_8:
.Lssa_http____token_at_34:
    cmp x10, x9
    b.le .Lssa_http____token_at_7
.Lssa_http____token_at_41:
    sub x12, x10, #1
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w13, [x6, x12]
.Lssa_http____token_at_40:
    cmp x13, #32
    b.eq .Lssa_http____token_at_35
.Lssa_http____token_at_38:
    cmp x13, #9
    b.ne .Lssa_http____token_at_7
.Lssa_http____token_at_35:
    sub x10, x10, #1
    cmp x10, x9
    b.gt .Lssa_http____token_at_41
.Lssa_http____token_at_7:
    sub x10, x10, x9
    sxtw x10, w10
    ldr x13, [x11, #8]
    cmp x10, x13
    b.eq .Lssa_http____token_at_4
.Lssa_http____token_at_6:
    mov x0, #0
    ret
.Lssa_http____token_at_4:
.Lssa_http____token_at_3:
    ldr x10, [x11, #8]
    ldr x13, [x11, #0]
    mov x11, #0
.Lssa_http____token_at_61:
    cmp x11, x10
    b.ge .Lssa_http____token_at_2
.Lssa_http____token_at_74:
    add w12, w9, w11
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
.Lssa_http____token_at_73:
    cmp x14, #65
    b.lt .Lssa_http____token_at_69
.Lssa_http____token_at_72:
    cmp x14, #90
    b.gt .Lssa_http____token_at_69
.Lssa_http____token_at_71:
    add x12, x14, #32
    sxtw x12, w12
    mov x14, x12
.Lssa_http____token_at_70:
.Lssa_http____token_at_69:
    ldrb w12, [x13, x11]
.Lssa_http____token_at_68:
    cmp x12, #65
    b.lt .Lssa_http____token_at_64
.Lssa_http____token_at_67:
    cmp x12, #90
    b.gt .Lssa_http____token_at_64
.Lssa_http____token_at_66:
    add x15, x12, #32
    sxtw x15, w15
    mov x12, x15
.Lssa_http____token_at_65:
.Lssa_http____token_at_64:
    cmp x14, x12
    b.ne .Lssa_http____token_at_1
.Lssa_http____token_at_62:
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_http____token_at_74
.Lssa_http____token_at_2:
    mov x0, #1
    ret
.Lssa_http____token_at_1:
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn_http____leading_fields:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____leading_fields.k:
__fn_http____leading_fields.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x0
    mov x20, x9
.Lssa_http____leading_fields_0:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http____leading_fields_2:
    mov x21, x0
    mov x22, #0
.Lssa_http____leading_fields_3:
    cmp x22, x20
    b.lt .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_6:
    mov x0, x19
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http____leading_fields_1
.Lssa_http____leading_fields_4:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x22, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x19, #16]
    ldr x6, [x9]
    cmp x22, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    ldr x23, [x9, x5, lsl #3]
    tst x21, #1
    b.ne .Lssa_http____leading_fields_uq4
    cmp x21, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq4
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_http____leading_fields_uq4:
    b.ne .Lssa_http____leading_fields_10
.Lssa_http____leading_fields_9:
    mov x24, x21
    b .Lssa_http____leading_fields_11
.Lssa_http____leading_fields_10:
    mov x24, #0
.Lssa_http____leading_fields_11:
    ldr x25, [x21, #8]
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_14
.Lssa_http____leading_fields_12:
    tbnz x25, #0, .Lssa_http____leading_fields_rcinc55
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc55
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc55
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcinc55:
    mov x0, x25
.Lssa_http____leading_fields_14:
    tbnz x10, #0, .Lssa_http____leading_fields_rcinc56
    cmp x10, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc56
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc56
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_http____leading_fields_rcinc56:
    mov x0, x10
    tst x25, #1
    b.ne .Lssa_http____leading_fields_uq14
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq14
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_http____leading_fields_uq14:
    b.ne .Lssa_http____leading_fields_16
.Lssa_http____leading_fields_15:
    mov x0, x25
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush58s
.Lssa_http____leading_fields_apush58o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush58e
.Lssa_http____leading_fields_apush58s:
    str x10, [sp, #56]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
.Lssa_http____leading_fields_apush58e:
    mov x26, x0
    b .Lssa_http____leading_fields_17
.Lssa_http____leading_fields_16:
    mov x0, x25
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush59s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http____leading_fields_apush59o
    tbz w3, #31, .Lssa_http____leading_fields_apush59s
.Lssa_http____leading_fields_apush59o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush59e
.Lssa_http____leading_fields_apush59s:
    bl __fern_arr_push
.Lssa_http____leading_fields_apush59e:
    mov x26, x0
    mov x0, x25
    bl __fn___fern_arr_inc_elems.r
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcdeck61
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http____leading_fields_rcdecd61
    tbnz w5, #31, .Lssa_http____leading_fields_rcdeck61
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http____leading_fields_rcdece61
.Lssa_http____leading_fields_rcdecd61:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcdeck61:
    mov x0, x25
.Lssa_http____leading_fields_rcdece61:
.Lssa_http____leading_fields_17:
    ldr x25, [x21, #16]
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_20
.Lssa_http____leading_fields_18:
    tbnz x25, #0, .Lssa_http____leading_fields_rcinc66
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc66
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc66
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcinc66:
    mov x0, x25
.Lssa_http____leading_fields_20:
    tbnz x23, #0, .Lssa_http____leading_fields_rcinc67
    cmp x23, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc67
    ldur w5, [x23, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc67
    add w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_http____leading_fields_rcinc67:
    mov x0, x23
    tst x25, #1
    b.ne .Lssa_http____leading_fields_uq20
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq20
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_http____leading_fields_uq20:
    b.ne .Lssa_http____leading_fields_22
.Lssa_http____leading_fields_21:
    mov x0, x25
    mov x1, x23
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush69s
.Lssa_http____leading_fields_apush69o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush69e
.Lssa_http____leading_fields_apush69s:
    bl __fern_arr_push_owned
.Lssa_http____leading_fields_apush69e:
    mov x27, x0
    b .Lssa_http____leading_fields_23
.Lssa_http____leading_fields_22:
    mov x0, x25
    mov x1, x23
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush70s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http____leading_fields_apush70o
    tbz w3, #31, .Lssa_http____leading_fields_apush70s
.Lssa_http____leading_fields_apush70o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush70e
.Lssa_http____leading_fields_apush70s:
    bl __fern_arr_push
.Lssa_http____leading_fields_apush70e:
    mov x27, x0
    mov x0, x25
    bl __fn___fern_arr_inc_elems.r
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcdeck72
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http____leading_fields_rcdecd72
    tbnz w5, #31, .Lssa_http____leading_fields_rcdeck72
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http____leading_fields_rcdece72
.Lssa_http____leading_fields_rcdecd72:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcdeck72:
    mov x0, x25
.Lssa_http____leading_fields_rcdece72:
.Lssa_http____leading_fields_23:
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_25
.Lssa_http____leading_fields_24:
    mov x10, #3
    str x24, [sp, #-16]!
    str x10, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x10, .S0
    add x10, x10, :lo12:.S0
    str x10, [x0, #0]
    mov x25, x0
    b .Lssa_http____leading_fields_26
.Lssa_http____leading_fields_25:
    mov x25, x24
.Lssa_http____leading_fields_26:
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_29
.Lssa_http____leading_fields_28:
    mov x0, x21
    bl __fn___sem_release_HeaderMap.r
.Lssa_http____leading_fields_29:
    str x26, [x25, #8]
    str x27, [x25, #16]
    add x22, x22, #1
    mov x21, x25
    cmp x22, x20
    b.ge .Lssa_http____leading_fields_6
    b .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_1:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____crlf_terminated:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____crlf_terminated.k:
__fn_http____crlf_terminated.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____crlf_terminated_0:
.Lssa_http____crlf_terminated_7:
    mov x21, x9
.Lssa_http____crlf_terminated_8:
.Lssa_http____crlf_terminated_18:
    mov x9, #13
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L19
    mov x2, #0
.L19:
    cmp x1, #255
    b.hi .L24
    cmp x2, x3
    b.ge .L24
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L21
.L20:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L26
    cmp x5, x8
    b.ls .L20
.L21:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L22
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L22
    sub x5, x5, #16
    b .L27
.L26:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L27
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L27:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L25
.L22:
    cmp x5, x6
    b.ge .L24
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L23
    add x5, x5, #1
    b .L22
.L23:
    sub x2, x5, x0
    b .L25
.L24:
    mov x2, #-1
.L25:
    mov x22, x2
    mov x9, #10
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L28
    mov x2, #0
.L28:
    cmp x1, #255
    b.hi .L33
    cmp x2, x3
    b.ge .L33
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L30
.L29:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L35
    cmp x5, x8
    b.ls .L29
.L30:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L31
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L31
    sub x5, x5, #16
    b .L36
.L35:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L36
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L36:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L34
.L31:
    cmp x5, x6
    b.ge .L33
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L32
    add x5, x5, #1
    b .L31
.L32:
    sub x2, x5, x0
    b .L34
.L33:
    mov x2, #-1
.L34:
    mov x0, x2
    cmp x22, #0
    b.lt .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_17:
    cmp x22, x20
    b.ge .Lssa_http____crlf_terminated_6
.Lssa_http____crlf_terminated_15:
    cmp x0, #0
    b.lt .Lssa_http____crlf_terminated_12
.Lssa_http____crlf_terminated_14:
    cmp x0, x22
    b.lt .Lssa_http____crlf_terminated_2
.Lssa_http____crlf_terminated_12:
    add x9, x22, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http____crlf_terminated_9
.Lssa_http____crlf_terminated_11:
    add x9, x22, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.ne .Lssa_http____crlf_terminated_1
.Lssa_http____crlf_terminated_9:
    add x22, x22, #2
    sxtw x21, w22
    b .Lssa_http____crlf_terminated_18
.Lssa_http____crlf_terminated_6:
    mov x10, #1
    cmp x0, x20
    cset x20, ge
    cmp x0, #0
    csel x0, x10, x20, lt
.Lssa_http____crlf_terminated_3:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_2:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____crlf_terminated_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____field_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____field_at.k:
__fn_http____field_at.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____field_at_0:
.Lssa_http____field_at_3:
    mov x21, x10
.Lssa_http____field_at_4:
    ldr x10, [x19, #8]
    ldr x9, [x10, #0]
    cmp x21, x9
    b.ge .Lssa_http____field_at_2
.Lssa_http____field_at_8:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x10, #8]
    ldr x10, [x20, #8]
    cmp x9, x10
    b.ne .Lssa_http____field_at_5
.Lssa_http____field_at_7:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x9, x5, lsl #3]
    mov x9, x20
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http____field_at_1
.Lssa_http____field_at_5:
    add x21, x21, #1
    b .Lssa_http____field_at_4
.Lssa_http____field_at_2:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____field_at_1:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____kind_if:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____kind_if.k:
__fn_http____kind_if.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x10
.Lssa_http____kind_if_0:
    bl __fn_string__eq_ignore_ascii_case.r
    cbz x0, .Lssa_http____kind_if_1
.Lssa_http____kind_if_3:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____kind_if_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____absolute_form_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____absolute_form_path.k:
__fn_http____absolute_form_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_http____absolute_form_path_0:
    mov x9, #2
    and x9, x19, x9
    cbz x9, .Lssa_http____absolute_form_path_2
.Lssa_http____absolute_form_path_1:
    mov x9, #-2
    add x9, x19, x9
    ldr x10, [x9, #0]
    ldr x11, [x9, #8]
    mov x22, x10
    mov x23, x11
    b .Lssa_http____absolute_form_path_3
.Lssa_http____absolute_form_path_2:
    add x11, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____absolute_form_path_5
.Lssa_http____absolute_form_path_4:
    ldr x10, [x19, #0]
    b .Lssa_http____absolute_form_path_6
.Lssa_http____absolute_form_path_5:
    mov x10, #0
.Lssa_http____absolute_form_path_6:
    mov x22, x11
    mov x23, x10
.Lssa_http____absolute_form_path_3:
    mov x24, #-1
    adrp x11, .SB1
    add x11, x11, :lo12:.SB1
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_18
.Lssa_http____absolute_form_path_20:
    add x11, x20, #7
    sxtw x11, w11
    mov x24, x11
.Lssa_http____absolute_form_path_19:
.Lssa_http____absolute_form_path_18:
    adrp x11, .SB2
    add x11, x11, :lo12:.SB2
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_15
.Lssa_http____absolute_form_path_17:
    add x20, x20, #8
    sxtw x20, w20
    mov x24, x20
.Lssa_http____absolute_form_path_16:
.Lssa_http____absolute_form_path_15:
    cmp x24, #0
    b.ge .Lssa_http____absolute_form_path_12
.Lssa_http____absolute_form_path_14:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_12:
    mov x20, x24
.Lssa_http____absolute_form_path_35:
    cmp x20, x21
    b.ge .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_40:
    mov w11, w20
    cmp x11, x23
    b.lo .Lssa_http____absolute_form_path_47
.Lssa_http____absolute_form_path_45:
    bl __fern_oob_abort
    mov x10, x0
.Lssa_http____absolute_form_path_47:
    ldrb w0, [x22, x11]
    cmp x0, #47
    b.eq .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_39:
    cmp x0, #63
    b.eq .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_38:
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____absolute_form_path_9
.Lssa_http____absolute_form_path_36:
    add x20, x20, #1
    cmp x20, x21
    b.lt .Lssa_http____absolute_form_path_40
.Lssa_http____absolute_form_path_11:
    mov x11, #-1
    cmp x20, x24
    csel x0, x11, x20, eq
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_9:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____prefix_ci:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____prefix_ci.k:
__fn_http____prefix_ci.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____prefix_ci_0:
    mov x12, #2
    and x12, x0, x12
    cbz x12, .Lssa_http____prefix_ci_2
.Lssa_http____prefix_ci_1:
    mov x12, #-2
    add x12, x0, x12
    ldr x13, [x12, #0]
    ldr x14, [x12, #8]
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_2:
    add x14, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____prefix_ci_5
.Lssa_http____prefix_ci_4:
    ldr x13, [x0, #0]
    b .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_5:
    mov x13, #0
.Lssa_http____prefix_ci_6:
.Lssa_http____prefix_ci_3:
    sub x10, x10, x9
    sxtw x10, w10
    ldr x12, [x11, #8]
    cmp x10, x12
    b.ge .Lssa_http____prefix_ci_10
.Lssa_http____prefix_ci_12:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_10:
.Lssa_http____prefix_ci_9:
    ldr x10, [x11, #8]
    ldr x12, [x11, #0]
    mov x11, #0
.Lssa_http____prefix_ci_17:
    cmp x11, x10
    b.ge .Lssa_http____prefix_ci_8
.Lssa_http____prefix_ci_25:
    add w15, w9, w11
    cmp x15, x13
    b.lo .Lssa_http____prefix_ci_32
.Lssa_http____prefix_ci_30:
    bl __fern_oob_abort
    mov x1, x0
.Lssa_http____prefix_ci_32:
    ldrb w1, [x14, x15]
.Lssa_http____prefix_ci_24:
    cmp x1, #65
    b.lt .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_23:
    cmp x1, #90
    b.gt .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_22:
    add x15, x1, #32
    sxtw x15, w15
    mov x1, x15
.Lssa_http____prefix_ci_21:
.Lssa_http____prefix_ci_20:
    ldrb w15, [x12, x11]
    cmp x1, x15
    b.ne .Lssa_http____prefix_ci_7
.Lssa_http____prefix_ci_18:
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_http____prefix_ci_25
.Lssa_http____prefix_ci_8:
    mov x0, #1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_7:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____is_pchar:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____is_pchar.k:
__fn_http____is_pchar.r:
.Lssa_http____is_pchar_0:
.Lssa_http____is_pchar_46:
    cmp x0, #97
    b.lt .Lssa_http____is_pchar_41
.Lssa_http____is_pchar_45:
    cmp x0, #122
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_41:
    cmp x0, #65
    b.lt .Lssa_http____is_pchar_35
.Lssa_http____is_pchar_40:
    cmp x0, #90
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_35:
    cmp x0, #48
    b.lt .Lssa_http____is_pchar_29
.Lssa_http____is_pchar_34:
    cmp x0, #57
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_29:
    cmp x0, #45
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_26:
    cmp x0, #46
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_23:
    cmp x0, #95
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_20:
    cmp x0, #126
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_15:
    adrp x9, .SB3
    add x9, x9, :lo12:.SB3
.Lssa_http____is_pchar_14:
    ldr x10, [x9, #8]
    ldr x11, [x9, #0]
    mov x9, #0
.Lssa_http____is_pchar_97:
    cmp x9, x10
    b.ge .Lssa_http____is_pchar_8
.Lssa_http____is_pchar_100:
    ldrb w12, [x11, x9]
    cmp x12, x0
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_98:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____is_pchar_100
.Lssa_http____is_pchar_8:
    cmp x0, #58
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_5:
    cmp x0, #64
    b.ne .Lssa_http____is_pchar_2
.Lssa_http____is_pchar_3:
    mov x0, #1
    b .Lssa_http____is_pchar_1
.Lssa_http____is_pchar_2:
    cmp x0, #37
    cset x0, eq
.Lssa_http____is_pchar_1:
    ret
    .cfi_endproc
    .ltorg
__fn_http____query_ok:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____query_ok.k:
__fn_http____query_ok.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____query_ok_0:
    mov x10, #2
    and x10, x19, x10
    cbz x10, .Lssa_http____query_ok_2
.Lssa_http____query_ok_1:
    mov x10, #-2
    add x10, x19, x10
    ldr x11, [x10, #0]
    ldr x12, [x10, #8]
    mov x21, x11
    mov x22, x12
    b .Lssa_http____query_ok_10
.Lssa_http____query_ok_2:
    add x12, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____query_ok_5
.Lssa_http____query_ok_4:
    ldr x11, [x19, #0]
    b .Lssa_http____query_ok_6
.Lssa_http____query_ok_5:
    mov x11, #0
.Lssa_http____query_ok_6:
    mov x21, x12
    mov x22, x11
.Lssa_http____query_ok_3:
.Lssa_http____query_ok_10:
    mov x23, x9
.Lssa_http____query_ok_11:
    cmp x23, x20
    b.ge .Lssa_http____query_ok_9
.Lssa_http____query_ok_21:
    mov w9, w23
    cmp x9, x22
    b.lo .Lssa_http____query_ok_28
.Lssa_http____query_ok_26:
    bl __fern_oob_abort
    mov x11, x0
.Lssa_http____query_ok_28:
    ldrb w24, [x21, x9]
    cmp x24, #37
    b.ne .Lssa_http____query_ok_17
.Lssa_http____query_ok_20:
    mov x0, x19
    mov x9, x23
    mov x10, x20
    bl __fn_http____pct_byte.r
    cmp x0, #0
    b.lt .Lssa_http____query_ok_8
.Lssa_http____query_ok_18:
    add x9, x23, #3
    sxtw x9, w9
    mov x23, x9
    b .Lssa_http____query_ok_11
.Lssa_http____query_ok_17:
    mov x0, x24
    bl __fn_http____is_pchar.r
    cbnz x0, .Lssa_http____query_ok_13
.Lssa_http____query_ok_16:
    cmp x24, #47
    b.eq .Lssa_http____query_ok_13
.Lssa_http____query_ok_15:
    cmp x24, #63
    b.ne .Lssa_http____query_ok_7
.Lssa_http____query_ok_13:
    add x23, x23, #1
.Lssa_http____query_ok_12:
    cmp x23, x20
    b.lt .Lssa_http____query_ok_21
.Lssa_http____query_ok_9:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_8:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_7:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____pct_byte:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____pct_byte.k:
__fn_http____pct_byte.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____pct_byte_0:
    mov x11, #2
    and x11, x0, x11
    cbz x11, .Lssa_http____pct_byte_2
.Lssa_http____pct_byte_1:
    mov x11, #-2
    add x11, x0, x11
    ldr x12, [x11, #0]
    ldr x13, [x11, #8]
    mov x4, x12
    mov x12, x13
    mov x13, x4
    b .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____pct_byte_5
.Lssa_http____pct_byte_4:
    ldr x12, [x0, #0]
    b .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_5:
    mov x12, #0
.Lssa_http____pct_byte_6:
.Lssa_http____pct_byte_3:
    add x11, x9, #2
    sxtw x11, w11
    cmp x11, x10
    b.lt .Lssa_http____pct_byte_39
.Lssa_http____pct_byte_41:
    mov x0, #-1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_39:
    add w11, w9, #1
    cmp x11, x12
    b.lo .Lssa_http____pct_byte_48
.Lssa_http____pct_byte_46:
    bl __fern_oob_abort
    mov x10, x0
.Lssa_http____pct_byte_48:
    ldrb w10, [x13, x11]
.Lssa_http____pct_byte_38:
    cmp x10, #48
    b.lo .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_37:
    cmp x10, #57
    b.hi .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_36:
    sub x11, x10, #48
    sxtw x11, w11
    mov x10, x11
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_34:
    cmp x10, #97
    b.lo .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_33:
    cmp x10, #102
    b.hi .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_32:
    sub x11, x10, #87
    sxtw x11, w11
    mov x10, x11
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_30:
    cmp x10, #65
    b.lo .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_29:
    cmp x10, #70
    b.hi .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_28:
    sub x10, x10, #55
    sxtw x10, w10
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_26:
    mov x10, #-1
.Lssa_http____pct_byte_25:
    add w9, w9, #2
    cmp x9, x12
    b.lo .Lssa_http____pct_byte_78
.Lssa_http____pct_byte_76:
    bl __fern_oob_abort
    mov x12, x0
.Lssa_http____pct_byte_78:
    ldrb w12, [x13, x9]
.Lssa_http____pct_byte_24:
    cmp x12, #48
    b.lo .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_23:
    cmp x12, #57
    b.hi .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_22:
    sub x9, x12, #48
    sxtw x9, w9
    mov x12, x9
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_20:
    cmp x12, #97
    b.lo .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_19:
    cmp x12, #102
    b.hi .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_18:
    sub x9, x12, #87
    sxtw x9, w9
    mov x12, x9
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_16:
    cmp x12, #65
    b.lo .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_15:
    cmp x12, #70
    b.hi .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_14:
    sub x12, x12, #55
    sxtw x12, w12
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_12:
    mov x12, #-1
.Lssa_http____pct_byte_11:
    cmp x10, #0
    b.lt .Lssa_http____pct_byte_9
.Lssa_http____pct_byte_10:
    cmp x12, #0
    b.ge .Lssa_http____pct_byte_7
.Lssa_http____pct_byte_9:
    mov x0, #-1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_7:
    lsl x10, x10, #4
    add x10, x10, x12
    sxtw x0, w10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http__parse_request:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http__parse_request.k:
__fn_http__parse_request.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #144
.Lssa_http__parse_request_0:
    str x0, [sp, #-16]!
    bl __fn___fern_str_bytes_u8
    add sp, sp, #16
    mov x19, x0
.Lssa_http__parse_request_413:
.Lssa_http__parse_request_412:
    mov x20, #8192
    mov x4, #32768
    str x4, [sp, #136]
    movz x4, #16, lsl #16
    str x4, [sp, #128]
    adrp x4, .SB4
    add x4, x4, :lo12:.SB4
    str x4, [sp, #120]
    adrp x4, .SB4
    add x4, x4, :lo12:.SB4
    str x4, [sp, #112]
    adrp x25, .K1
    add x25, x25, :lo12:.K1
.Lssa_http__parse_request_410:
    ldr x9, [x19, #0]
    cmp x9, #1
    b.le .Lssa_http__parse_request_406
.Lssa_http__parse_request_409:
    ldrb w9, [x19, #8]
    cmp x9, #13
    b.ne .Lssa_http__parse_request_406
.Lssa_http__parse_request_408:
    ldr x6, [x19, #0]
    cmp x6, #1
    b.hi 1f
    b __fern_oob_abort
1:
    ldrb w9, [x19, #9]
    cmp x9, #10
    b.ne .Lssa_http__parse_request_406
.Lssa_http__parse_request_407:
    mov x5, #2
    str x5, [sp, #104]
    b .Lssa_http__parse_request_405
.Lssa_http__parse_request_406:
    str xzr, [sp, #104]
.Lssa_http__parse_request_405:
    ldr x4, [x19, #0]
    str x4, [sp, #96]
    ldr x4, [sp, #104]
    ldr x5, [sp, #96]
    cmp x4, x5
    b.lt .Lssa_http__parse_request_401
.Lssa_http__parse_request_427:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck2506
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd2506
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck2506
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece2506
.Lssa_http__parse_request_rcdecd2506:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck2506:
    mov x0, x19
.Lssa_http__parse_request_rcdece2506:
.Lssa_http__parse_request_404:
    mov x11, #1
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_401:
    ldr x4, [sp, #104]
    add x20, x4, x20
    add x20, x20, #2
    sxtw x20, w20
    ldr x5, [sp, #136]
    add x9, x4, x5
    add x9, x9, #4
    sxtw x4, w9
    str x4, [sp, #88]
    ldr x5, [sp, #96]
    cmp x4, x5
    ldr x6, [sp, #96]
    csel x23, x4, x6, lt
.Lssa_http__parse_request_398:
    mov x21, #-1
    mov x4, #-1
    str x4, [sp, #80]
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    mov x2, x9
    ldr x1, [sp, #104]
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L37
    mov x1, #0
.L37:
    adrp x9, .S5
    add x9, x9, :lo12:.S5
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L40
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L38:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L39
    add x5, x5, #16
    cmp x5, x8
    b.ls .L38
    sub x1, x5, x0
    b .L40
.L39:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L41
.L40:
    add x10, x9, #96
.L44:
    cmp x1, x3
    b.ge .L42
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L41
    add x1, x1, #1
    b .L44
.L41:
    str x1, [sp, #-16]!
    b .L43
.L42:
    str x3, [sp, #-16]!
.L43:
    ldr x0, [sp], #16
.Lssa_http__parse_request_397:
    cmp x0, x23
    b.lt .Lssa_http__parse_request_394
.Lssa_http__parse_request_396:
    mov x10, #2
    b .Lssa_http__parse_request_384
.Lssa_http__parse_request_394:
    ldr x6, [x19]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x0
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_391
.Lssa_http__parse_request_393:
    add x9, x0, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http__parse_request_389
.Lssa_http__parse_request_392:
    add x9, x0, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http__parse_request_389
.Lssa_http__parse_request_391:
    mov x10, #1
    b .Lssa_http__parse_request_384
.Lssa_http__parse_request_389:
    add x10, x0, #1
    ldr x9, [x19, #0]
    cmp x10, x9
    b.lt .Lssa_http__parse_request_386
.Lssa_http__parse_request_388:
    mov x10, #2
    b .Lssa_http__parse_request_384
.Lssa_http__parse_request_386:
    mov x10, #0
.Lssa_http__parse_request_385:
.Lssa_http__parse_request_384:
    ldr x26, [sp, #104]
    mov x27, x0
    mov x11, x10
    ldr x10, [sp, #104]
    mov x24, #0
    mov x9, #0
.Lssa_http__parse_request_460:
    cmp x11, #2
    b.ne .Lssa_http__parse_request_487
.Lssa_http__parse_request_489:
    ldr x27, [sp, #80]
    b .Lssa_http__parse_request_378
.Lssa_http__parse_request_487:
    cmp x11, #1
    b.ne .Lssa_http__parse_request_485
.Lssa_http__parse_request_486:
    add x11, x27, #1
    sxtw x11, w11
    mov x28, x11
    mov x26, x11
    mov x24, #1
    mov x22, #0
    b .Lssa_http__parse_request_474
.Lssa_http__parse_request_485:
    mov x11, #-1
    cmp x21, x11
    b.ne .Lssa_http__parse_request_478
.Lssa_http__parse_request_484:
    add x11, x27, #1
    sxtw x11, w11
.Lssa_http__parse_request_483:
    mov x12, #-2
    cmp x11, x20
    csel x12, x12, x27, ge
    b .Lssa_http__parse_request_479
.Lssa_http__parse_request_481:
    b .Lssa_http__parse_request_478
.Lssa_http__parse_request_479:
    mov x21, x12
.Lssa_http__parse_request_478:
    cmp x27, x10
    b.ne .Lssa_http__parse_request_475
.Lssa_http__parse_request_477:
    cbnz x9, .Lssa_http__parse_request_383
.Lssa_http__parse_request_475:
    add x10, x27, #2
    sxtw x10, w10
    mov x28, x10
    mov x26, x10
    mov x22, #1
.Lssa_http__parse_request_474:
    adrp x10, .K2
    add x10, x10, :lo12:.K2
    mov x2, x10
    mov x1, x26
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L45
    mov x1, #0
.L45:
    adrp x9, .S5
    add x9, x9, :lo12:.S5
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L48
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L46:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L47
    add x5, x5, #16
    cmp x5, x8
    b.ls .L46
    sub x1, x5, x0
    b .L48
.L47:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L49
.L48:
    add x10, x9, #96
.L52:
    cmp x1, x3
    b.ge .L50
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L49
    add x1, x1, #1
    b .L52
.L49:
    str x1, [sp, #-16]!
    b .L51
.L50:
    str x3, [sp, #-16]!
.L51:
    ldr x0, [sp], #16
    mov x27, x0
.Lssa_http__parse_request_473:
    cmp x27, x23
    b.lt .Lssa_http__parse_request_470
.Lssa_http__parse_request_472:
    mov x11, #2
    b .Lssa_http__parse_request_461
.Lssa_http__parse_request_470:
    ldr x6, [x19]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x27
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http__parse_request_467
.Lssa_http__parse_request_469:
    add x10, x27, #1
    ldr x9, [x19, #0]
    cmp x10, x9
    b.ge .Lssa_http__parse_request_465
.Lssa_http__parse_request_468:
    add x10, x27, #1
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_465
.Lssa_http__parse_request_467:
    mov x11, #1
    b .Lssa_http__parse_request_461
.Lssa_http__parse_request_465:
    add x9, x27, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.lt .Lssa_http__parse_request_462
.Lssa_http__parse_request_464:
    mov x11, #2
    b .Lssa_http__parse_request_461
.Lssa_http__parse_request_462:
    mov x11, #0
.Lssa_http__parse_request_461:
    mov x10, x28
    mov x9, x22
    cmp x11, #2
    b.eq .Lssa_http__parse_request_489
    b .Lssa_http__parse_request_487
.Lssa_http__parse_request_383:
    sub x11, x27, #2
    sxtw x11, w11
    add x27, x27, #1
    sxtw x27, w27
.Lssa_http__parse_request_382:
    mov x9, #-2
    ldr x5, [sp, #88]
    cmp x27, x5
    csel x9, x9, x11, ge
.Lssa_http__parse_request_379:
    mov x27, x9
.Lssa_http__parse_request_378:
    mov x9, #-1
    cmp x21, x9
    b.ne .Lssa_http__parse_request_372
.Lssa_http__parse_request_376:
    ldr x22, [x19, #0]
    cmp x20, x23
    b.le .Lssa_http__parse_request_365
.Lssa_http__parse_request_375:
    cmp x23, x22
    b.ge .Lssa_http__parse_request_365
.Lssa_http__parse_request_374:
    cmp x20, x22
    csel x10, x20, x22, lt
    b .Lssa_http__parse_request_370
.Lssa_http__parse_request_372:
    str x21, [sp, #80]
    b .Lssa_http__parse_request_360
.Lssa_http__parse_request_370:
    mov x0, x19
    mov x9, x26
    bl __fn_http____find_crlf.r
    cmp x0, #0
    b.lt .Lssa_http__parse_request_365
.Lssa_http__parse_request_369:
    mov x10, x0
    b .Lssa_http__parse_request_361
.Lssa_http__parse_request_365:
    cmp x22, x20
    b.lt .Lssa_http__parse_request_362
.Lssa_http__parse_request_364:
    mov x10, #-2
    b .Lssa_http__parse_request_361
.Lssa_http__parse_request_362:
    mov x10, #-1
.Lssa_http__parse_request_361:
    str x10, [sp, #80]
.Lssa_http__parse_request_360:
    mov x10, #-1
    cmp x27, x10
    b.ne .Lssa_http__parse_request_354
.Lssa_http__parse_request_359:
    ldr x4, [sp, #96]
    ldr x5, [sp, #88]
    cmp x4, x5
    b.lt .Lssa_http__parse_request_354
.Lssa_http__parse_request_358:
    mov x10, #-2
    mov x27, x10
.Lssa_http__parse_request_357:
.Lssa_http__parse_request_356:
.Lssa_http__parse_request_354:
    mov x10, #-2
    ldr x4, [sp, #80]
    cmp x4, x10
    b.ne .Lssa_http__parse_request_351
.Lssa_http__parse_request_353:
    mov x24, #414
    b .Lssa_http__parse_request_344
.Lssa_http__parse_request_351:
    mov x10, #-2
    cmp x27, x10
    b.ne .Lssa_http__parse_request_348
.Lssa_http__parse_request_350:
    mov x24, #431
    b .Lssa_http__parse_request_344
.Lssa_http__parse_request_348:
    cbz x24, .Lssa_http__parse_request_345
.Lssa_http__parse_request_347:
    mov x24, #400
    b .Lssa_http__parse_request_344
.Lssa_http__parse_request_345:
    mov x24, #0
.Lssa_http__parse_request_344:
    cmp x24, #0
    b.eq .Lssa_http__parse_request_341
.Lssa_http__parse_request_598:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck2696
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd2696
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck2696
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece2696
.Lssa_http__parse_request_rcdecd2696:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck2696:
    mov x0, x19
.Lssa_http__parse_request_rcdece2696:
.Lssa_http__parse_request_343:
    mov x11, x24
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_341:
    mov x24, #-1
    mov x20, #-1
    adrp x26, .SB4
    add x26, x26, :lo12:.SB4
    ldr x4, [sp, #80]
    cmp x4, #0
    b.lt .Lssa_http__parse_request_335
.Lssa_http__parse_request_339:
    adrp x10, .K3
    add x10, x10, :lo12:.K3
    mov x2, x10
    ldr x1, [sp, #104]
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L53
    mov x1, #0
.L53:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L56
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L54:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L55
    add x5, x5, #16
    cmp x5, x8
    b.ls .L54
    sub x1, x5, x0
    b .L56
.L55:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L57
.L56:
    add x10, x9, #96
.L60:
    cmp x1, x3
    b.ge .L58
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L57
    add x1, x1, #1
    b .L60
.L57:
    str x1, [sp, #-16]!
    b .L59
.L58:
    str x3, [sp, #-16]!
.L59:
    ldr x0, [sp], #16
    ldr x5, [sp, #80]
    cmp x0, x5
    ldr x5, [sp, #80]
    csel x4, x5, x0, gt
    str x4, [sp, #96]
.Lssa_http__parse_request_607:
    ldr x4, [sp, #96]
    ldr x5, [sp, #104]
    cmp x4, x5
    b.eq .Lssa_http__parse_request_336
.Lssa_http__parse_request_338:
    ldr x4, [sp, #96]
    ldr x5, [sp, #80]
    cmp x4, x5
    b.ge .Lssa_http__parse_request_336
.Lssa_http__parse_request_337:
    ldr x5, [sp, #96]
    ldr x6, [x19]
    cmp x5, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x5
    ldrb w10, [x5, #8]
    cmp x10, #32
    b.eq .Lssa_http__parse_request_333
.Lssa_http__parse_request_336:
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    mov x9, #-1
    mov x11, #-1
    mov x24, x9
    mov x26, x11
    mov x21, x10
    mov x22, #400
    b .Lssa_http__parse_request_214
.Lssa_http__parse_request_335:
    str x24, [sp, #112]
    str x26, [sp, #96]
    mov x26, x20
    b .Lssa_http__parse_request_211
.Lssa_http__parse_request_333:
    ldr x4, [sp, #96]
    add x11, x4, #1
.Lssa_http__parse_request_332:
    mov x9, #32
    mov x2, x11
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L61
    mov x2, #0
.L61:
    cmp x1, #255
    b.hi .L66
    cmp x2, x3
    b.ge .L66
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L63
.L62:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L68
    cmp x5, x8
    b.ls .L62
.L63:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L64
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L64
    sub x5, x5, #16
    b .L69
.L68:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L69
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L69:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L67
.L64:
    cmp x5, x6
    b.ge .L66
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L65
    add x5, x5, #1
    b .L64
.L65:
    sub x2, x5, x0
    b .L67
.L66:
    mov x2, #-1
.L67:
    mov x0, x2
    mov x9, #-1
    ldr x5, [sp, #80]
    cmp x0, x5
    csel x26, x0, x9, lt
.Lssa_http__parse_request_328:
    cmp x26, #0
    b.lt .Lssa_http__parse_request_326
.Lssa_http__parse_request_327:
    ldr x4, [sp, #96]
    add x11, x4, #1
    cmp x26, x11
    b.ne .Lssa_http__parse_request_324
.Lssa_http__parse_request_326:
    adrp x11, .SB4
    add x11, x11, :lo12:.SB4
    mov x10, #-1
    mov x9, #-1
    mov x24, x10
    mov x26, x9
    mov x21, x11
    mov x22, #400
    b .Lssa_http__parse_request_214
.Lssa_http__parse_request_324:
    add x9, x26, #1
    sxtw x20, w9
.Lssa_http__parse_request_323:
    ldr x4, [sp, #80]
    sub x9, x4, x20
    sxtw x9, w9
    cmp x9, #8
    b.ne .Lssa_http__parse_request_321
.Lssa_http__parse_request_322:
    adrp x9, .K4
    add x9, x9, :lo12:.K4
    mov x10, #0
    mov x11, #5
    mov x4, x11
    mov x3, x10
    mov x2, x9
    mov x1, x20
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2]
    add x2, x2, #8
    cmp x1, #0
    b.ge .L70_aop
    mov x1, #0
.L70_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L70_bop
    mov x3, #0
.L70_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L70_nok
    mov x4, #0
.L70_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L70_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L70_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L70_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L70_done
.L70_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L70_vec
.L70_short:
    cmp x10, #8
    b.lt .L70_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L70_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L70_eq
    add x8, x8, x14
.L70_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L70_done
.L70_w4:
    cmp x10, #4
    b.lt .L70_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L70_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L70_eq
    add x8, x8, x14
.L70_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L70_done
.L70_w2:
    cmp x10, #2
    b.lt .L70_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L70_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L70_eq
    add x8, x8, x14
.L70_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L70_done
.L70_tail:
    cmp x8, x13
    b.ge .L70_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L70_th
    add x8, x8, #1
    add x9, x9, #1
    b .L70_tail
.L70_th:
    sub x2, x8, x12
    b .L70_done
.L70_eq:
    mov x2, x4
.L70_done:
    mov x0, x2
    cmp x0, #5
    b.eq .Lssa_http__parse_request_319
.Lssa_http__parse_request_321:
    mov x10, #400
    b .Lssa_http__parse_request_300
.Lssa_http__parse_request_319:
    add w11, w20, #5
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_318:
    cmp x10, #48
    b.lo .Lssa_http__parse_request_303
.Lssa_http__parse_request_317:
    cmp x10, #57
    b.hi .Lssa_http__parse_request_303
.Lssa_http__parse_request_313:
    add w10, w20, #6
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w11, [x5, #8]
    cmp x11, #46
    b.ne .Lssa_http__parse_request_303
.Lssa_http__parse_request_312:
    add w11, w20, #7
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_311:
    cmp x10, #48
    b.lo .Lssa_http__parse_request_303
.Lssa_http__parse_request_310:
    cmp x10, #57
    b.hi .Lssa_http__parse_request_303
.Lssa_http__parse_request_305:
    add w20, w20, #5
    ldr x6, [x19]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x20
    ldrb w10, [x5, #8]
    cmp x10, #49
    b.eq .Lssa_http__parse_request_301
.Lssa_http__parse_request_304:
    mov x10, #505
    b .Lssa_http__parse_request_300
.Lssa_http__parse_request_303:
    mov x10, #400
    b .Lssa_http__parse_request_300
.Lssa_http__parse_request_301:
    mov x10, #0
.Lssa_http__parse_request_300:
    cmp x10, #0
    b.eq .Lssa_http__parse_request_297
.Lssa_http__parse_request_299:
    adrp x11, .SB4
    add x11, x11, :lo12:.SB4
    mov x9, #-1
    mov x12, #-1
    mov x22, x10
    mov x24, x9
    mov x26, x12
    mov x21, x11
    b .Lssa_http__parse_request_214
.Lssa_http__parse_request_297:
    b .Lssa_http__parse_request_pool_404
    .ltorg
.Lssa_http__parse_request_pool_404:
    ldr x4, [sp, #96]
    add x20, x4, #1
    ldr x5, [sp, #104]
    sub x12, x4, x5
    sxtw x12, w12
    cmp x12, #7
    b.ne .Lssa_http__parse_request_295
.Lssa_http__parse_request_296:
    adrp x24, .SB7
    add x24, x24, :lo12:.SB7
    ldr x12, [x24, #8]
    mov x9, #0
    mov x4, x12
    mov x3, x9
    mov x2, x24
    ldr x1, [sp, #104]
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L71_aop
    mov x1, #0
.L71_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L71_bop
    mov x3, #0
.L71_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L71_nok
    mov x4, #0
.L71_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L71_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L71_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L71_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L71_vec
.L71_short:
    cmp x10, #8
    b.lt .L71_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L71_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L71_eq
    add x8, x8, x14
.L71_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_w4:
    cmp x10, #4
    b.lt .L71_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L71_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L71_eq
    add x8, x8, x14
.L71_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_w2:
    cmp x10, #2
    b.lt .L71_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L71_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L71_eq
    add x8, x8, x14
.L71_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_tail:
    cmp x8, x13
    b.ge .L71_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L71_th
    add x8, x8, #1
    add x9, x9, #1
    b .L71_tail
.L71_th:
    sub x2, x8, x12
    b .L71_done
.L71_eq:
    mov x2, x4
.L71_done:
    mov x0, x2
    ldr x9, [x24, #8]
    cmp x0, x9
    cset x0, eq
    b .Lssa_http__parse_request_292
.Lssa_http__parse_request_295:
    mov x0, #0
.Lssa_http__parse_request_294:
.Lssa_http__parse_request_292:
    add x9, x20, #1
    sxtw x9, w9
    cmp x26, x9
    b.ne .Lssa_http__parse_request_285
.Lssa_http__parse_request_291:
    ldr x6, [x19]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x20
    ldrb w9, [x5, #8]
    cmp x9, #42
    b.ne .Lssa_http__parse_request_285
.Lssa_http__parse_request_290:
    cbz x0, .Lssa_http__parse_request_287
.Lssa_http__parse_request_289:
    mov x9, #-1
    mov x20, x9
    b .Lssa_http__parse_request_278
.Lssa_http__parse_request_287:
    mov x9, #-2
    mov x20, x9
    b .Lssa_http__parse_request_278
.Lssa_http__parse_request_285:
    cmp x26, x20
    b.le .Lssa_http__parse_request_281
.Lssa_http__parse_request_284:
    ldr x6, [x19]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x20
    ldrb w9, [x5, #8]
    cmp x9, #47
    b.ne .Lssa_http__parse_request_281
.Lssa_http__parse_request_283:
    b .Lssa_http__parse_request_278
.Lssa_http__parse_request_281:
    mov x0, x19
    mov x9, x20
    mov x10, x26
    bl __fn_http____absolute_form_path.r
    mov x9, x0
    cmp x9, #0
    b.ge .Lssa_http__parse_request_279
.Lssa_http__parse_request_280:
    mov x12, #-2
    mov x20, x12
    b .Lssa_http__parse_request_278
.Lssa_http__parse_request_279:
    mov x20, x9
.Lssa_http__parse_request_278:
    mov x12, #-2
    cmp x20, x12
    b.ne .Lssa_http__parse_request_275
.Lssa_http__parse_request_277:
    mov x24, #0
    mov x22, #400
    mov x9, #0
    b .Lssa_http__parse_request_218
.Lssa_http__parse_request_275:
    mov x12, #-1
    cmp x20, x12
    b.ne .Lssa_http__parse_request_271
.Lssa_http__parse_request_274:
    adrp x12, .SB8
    add x12, x12, :lo12:.SB8
    mov x24, x12
    mov x22, #0
    mov x9, #1
    b .Lssa_http__parse_request_218
.Lssa_http__parse_request_271:
    mov x12, #2
    and x12, x19, x12
    cbz x12, .Lssa_http__parse_request_731
.Lssa_http__parse_request_730:
    mov x12, #-2
    add x12, x19, x12
    ldr x9, [x12, #0]
    ldr x11, [x12, #8]
    mov x4, x9
    mov x9, x11
    mov x11, x4
    b .Lssa_http__parse_request_270
.Lssa_http__parse_request_731:
    add x11, x19, #8
    cmp x19, #0
    b.eq .Lssa_http__parse_request_734
.Lssa_http__parse_request_733:
    ldr x9, [x19, #0]
    b .Lssa_http__parse_request_270
.Lssa_http__parse_request_734:
    mov x9, #0
.Lssa_http__parse_request_735:
.Lssa_http__parse_request_732:
.Lssa_http__parse_request_270:
    mov x10, x20
.Lssa_http__parse_request_736:
    cmp x10, x26
    b.ge .Lssa_http__parse_request_269
.Lssa_http__parse_request_739:
    mov w12, w10
    cmp x12, x9
    b.lo .Lssa_http__parse_request_746
.Lssa_http__parse_request_744:
    bl __fern_oob_abort
    mov x13, x0
.Lssa_http__parse_request_746:
    ldrb w13, [x11, x12]
    cmp x13, #63
    b.eq .Lssa_http__parse_request_268
.Lssa_http__parse_request_737:
    add x10, x10, #1
    cmp x10, x26
    b.lt .Lssa_http__parse_request_739
.Lssa_http__parse_request_269:
    mov x9, #-1
    mov x24, x9
    b .Lssa_http__parse_request_267
.Lssa_http__parse_request_268:
    mov x24, x10
.Lssa_http__parse_request_267:
    cmp x24, #0
    b.ge .Lssa_http__parse_request_264
.Lssa_http__parse_request_266:
    mov x24, x26
    b .Lssa_http__parse_request_261
.Lssa_http__parse_request_264:
    add x9, x24, #1
    sxtw x9, w9
    mov x0, x19
    mov x10, x26
    bl __fn_http____query_ok.r
    cbz x0, .Lssa_http__parse_request_262
.Lssa_http__parse_request_263:
    b .Lssa_http__parse_request_261
.Lssa_http__parse_request_262:
    mov x10, #-1
    mov x24, x10
.Lssa_http__parse_request_261:
    cmp x24, #0
    b.ge .Lssa_http__parse_request_258
.Lssa_http__parse_request_260:
    mov x24, #0
    mov x22, #400
    mov x9, #0
    b .Lssa_http__parse_request_218
.Lssa_http__parse_request_258:
    cmp x20, x24
    b.ge .Lssa_http__parse_request_240
.Lssa_http__parse_request_256:
    add x10, x20, #1
.Lssa_http__parse_request_255:
    mov x23, x10
    mov x28, x20
.Lssa_http__parse_request_773:
    cmp x28, x24
    b.ge .Lssa_http__parse_request_253
.Lssa_http__parse_request_789:
    ldr x6, [x19]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x28
    ldrb w0, [x5, #8]
    cmp x0, #47
    b.ne .Lssa_http__parse_request_781
.Lssa_http__parse_request_788:
    cmp x28, x20
    b.le .Lssa_http__parse_request_775
.Lssa_http__parse_request_786:
    sub x10, x28, x23
    sxtw x10, w10
    cmp x10, #1
    b.lt .Lssa_http__parse_request_782
.Lssa_http__parse_request_785:
    cmp x10, #2
    b.gt .Lssa_http__parse_request_782
.Lssa_http__parse_request_784:
    ldr x6, [x19]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x23
    ldrb w9, [x5, #8]
    cmp x9, #46
    b.ne .Lssa_http__parse_request_782
.Lssa_http__parse_request_783:
    sub x9, x28, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w11, [x5, #8]
    cmp x11, #46
    b.eq .Lssa_http__parse_request_777
.Lssa_http__parse_request_782:
    mov x10, #0
    b .Lssa_http__parse_request_777
.Lssa_http__parse_request_781:
    cmp x0, #37
    b.eq .Lssa_http__parse_request_240
.Lssa_http__parse_request_780:
    str x10, [sp, #56]
    bl __fn_http____is_pchar.r
    ldr x10, [sp, #56]
    cbz x0, .Lssa_http__parse_request_240
.Lssa_http__parse_request_779:
    b .Lssa_http__parse_request_774
.Lssa_http__parse_request_778:
.Lssa_http__parse_request_777:
    cmp x10, #0
    b.gt .Lssa_http__parse_request_240
.Lssa_http__parse_request_775:
    add x10, x28, #1
    mov x23, x10
.Lssa_http__parse_request_774:
    add x28, x28, #1
    cmp x28, x24
    b.lt .Lssa_http__parse_request_789
.Lssa_http__parse_request_253:
    sub x10, x24, x23
    sxtw x10, w10
    cmp x10, #1
    b.lt .Lssa_http__parse_request_249
.Lssa_http__parse_request_252:
    cmp x10, #2
    b.gt .Lssa_http__parse_request_249
.Lssa_http__parse_request_251:
    ldr x6, [x19]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x23
    ldrb w11, [x5, #8]
    cmp x11, #46
    b.ne .Lssa_http__parse_request_249
.Lssa_http__parse_request_250:
    sub x11, x24, #1
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w9, [x5, #8]
    cmp x9, #46
    b.eq .Lssa_http__parse_request_245
.Lssa_http__parse_request_249:
    mov x10, #0
.Lssa_http__parse_request_246:
.Lssa_http__parse_request_245:
    cmp x10, #0
    b.ne .Lssa_http__parse_request_240
.Lssa_http__parse_request_243:
    mov x0, x19
    mov x9, x20
    mov x10, x26
    ldr x11, [sp, #112]
    bl __fn_http____shared_string.r
    mov x24, x0
    mov x22, #0
    mov x9, #1
    b .Lssa_http__parse_request_218
.Lssa_http__parse_request_240:
    adrp x10, .K5
    add x10, x10, :lo12:.K5
    add x20, x20, #1
    sxtw x9, w20
.Lssa_http__parse_request_239:
    mov x20, x10
    mov x23, #0
    mov x28, #0
    mov x21, #0
.Lssa_http__parse_request_858:
    cmp x9, x24
    b.gt .Lssa_http__parse_request_237
.Lssa_http__parse_request_890:
    mov x10, #47
.Lssa_http__parse_request_889:
    ldr x11, [x20, #0]
    cmp x23, x11
    b.ge .Lssa_http__parse_request_886
.Lssa_http__parse_request_888:
    tst x20, #1
    b.ne .Lssa_http__parse_request_uq888
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq888
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq888:
    b.ne .Lssa_http__parse_request_900
.Lssa_http__parse_request_899:
    b .Lssa_http__parse_request_901
.Lssa_http__parse_request_900:
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3023
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3023
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3023
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x20
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_rcdece3023
.Lssa_http__parse_request_rcdecd3023:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3023:
    mov x0, x20
.Lssa_http__parse_request_rcdece3023:
    mov x11, #0
    ldr x13, [x20, #0]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x13, [sp, #-16]!
    str x11, [sp, #-16]!
    str x20, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    mov x20, x0
.Lssa_http__parse_request_901:
    mov x13, #47
    ldr x7, [x20]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, x23
    strb w13, [x5, #8]
    mov x11, x20
    b .Lssa_http__parse_request_885
.Lssa_http__parse_request_886:
    tst x20, #1
    b.ne .Lssa_http__parse_request_uq886
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq886
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq886:
    b.ne .Lssa_http__parse_request_904
.Lssa_http__parse_request_903:
    mov x0, x20
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3031s
.Lssa_http__parse_request_apush3031o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3031e
.Lssa_http__parse_request_apush3031s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    bl __fern_arr_push_owned_u8
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
.Lssa_http__parse_request_apush3031e:
    mov x11, x0
    b .Lssa_http__parse_request_885
.Lssa_http__parse_request_904:
    mov x0, x20
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3032s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3032o
    tbz w3, #31, .Lssa_http__parse_request_apush3032s
.Lssa_http__parse_request_apush3032o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3032e
.Lssa_http__parse_request_apush3032s:
    str x9, [sp, #56]
    bl __fern_arr_push_u8
    ldr x9, [sp, #56]
.Lssa_http__parse_request_apush3032e:
    mov x11, x0
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3033
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3033
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3033
    str x9, [sp, #56]
    str x11, [sp, #48]
    mov x0, x20
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x11, [sp, #48]
    b .Lssa_http__parse_request_rcdece3033
.Lssa_http__parse_request_rcdecd3033:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3033:
    mov x0, x20
.Lssa_http__parse_request_rcdece3033:
.Lssa_http__parse_request_905:
.Lssa_http__parse_request_885:
    add x10, x23, #1
    sxtw x10, w10
.Lssa_http__parse_request_884:
    mov x20, x11
    mov x11, x9
.Lssa_http__parse_request_906:
    cmp x11, x24
    b.ge .Lssa_http__parse_request_883
.Lssa_http__parse_request_933:
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w9, [x5, #8]
    cmp x9, #47
    b.eq .Lssa_http__parse_request_883
.Lssa_http__parse_request_931:
    cmp x9, #37
    b.ne .Lssa_http__parse_request_925
.Lssa_http__parse_request_930:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    mov x0, x19
    mov x9, x11
    mov x10, x24
    bl __fn_http____pct_byte.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    cmp x0, #0
    b.le .Lssa_http__parse_request_928
.Lssa_http__parse_request_929:
    cmp x0, #47
    b.ne .Lssa_http__parse_request_927
.Lssa_http__parse_request_928:
    mov x13, #-1
    b .Lssa_http__parse_request_922
.Lssa_http__parse_request_927:
    mov x13, x0
    b .Lssa_http__parse_request_922
.Lssa_http__parse_request_925:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    mov x0, x9
    bl __fn_http____is_pchar.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    cbz x0, .Lssa_http__parse_request_923
.Lssa_http__parse_request_924:
    mov x13, x9
    b .Lssa_http__parse_request_922
.Lssa_http__parse_request_923:
    mov x13, #-1
.Lssa_http__parse_request_922:
    cmp x13, #0
    b.ge .Lssa_http__parse_request_920
.Lssa_http__parse_request_961:
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3075
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3075
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3075
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x13, [sp, #32]
    mov x0, x20
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x13, [sp, #32]
    b .Lssa_http__parse_request_rcdece3075
.Lssa_http__parse_request_rcdecd3075:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3075:
    mov x0, x20
.Lssa_http__parse_request_rcdece3075:
    b .Lssa_http__parse_request_232
.Lssa_http__parse_request_920:
    mov x12, #1
    cmp x13, #128
    cset x14, ge
    cmp x21, #0
    csel x21, x12, x14, ne
.Lssa_http__parse_request_917:
    and x14, x13, #255
.Lssa_http__parse_request_916:
    ldr x13, [x20, #0]
    cmp x10, x13
    b.ge .Lssa_http__parse_request_913
.Lssa_http__parse_request_915:
    tst x20, #1
    b.ne .Lssa_http__parse_request_uq915
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq915
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq915:
    b.ne .Lssa_http__parse_request_975
.Lssa_http__parse_request_974:
    b .Lssa_http__parse_request_976
.Lssa_http__parse_request_975:
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3084
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3084
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3084
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x14, [sp, #32]
    mov x0, x20
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x14, [sp, #32]
    b .Lssa_http__parse_request_rcdece3084
.Lssa_http__parse_request_rcdecd3084:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3084:
    mov x0, x20
.Lssa_http__parse_request_rcdece3084:
    mov x13, #0
    ldr x12, [x20, #0]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x14, [sp, #32]
    str x12, [sp, #-16]!
    str x13, [sp, #-16]!
    str x20, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x14, [sp, #32]
    mov x20, x0
.Lssa_http__parse_request_976:
    ldr x7, [x20]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, x10
    strb w14, [x5, #8]
    b .Lssa_http__parse_request_912
.Lssa_http__parse_request_913:
    tst x20, #1
    b.ne .Lssa_http__parse_request_uq913
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq913
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq913:
    b.ne .Lssa_http__parse_request_979
.Lssa_http__parse_request_978:
    mov x0, x20
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3091s
.Lssa_http__parse_request_apush3091o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3091e
.Lssa_http__parse_request_apush3091s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x14, [sp, #32]
    bl __fern_arr_push_owned_u8
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x14, [sp, #32]
.Lssa_http__parse_request_apush3091e:
    mov x12, x0
    b .Lssa_http__parse_request_980
.Lssa_http__parse_request_979:
    mov x0, x20
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3092s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3092o
    tbz w3, #31, .Lssa_http__parse_request_apush3092s
.Lssa_http__parse_request_apush3092o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3092e
.Lssa_http__parse_request_apush3092s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    bl __fern_arr_push_u8
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
.Lssa_http__parse_request_apush3092e:
    mov x12, x0
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3093
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3093
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3093
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    mov x0, x20
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    b .Lssa_http__parse_request_rcdece3093
.Lssa_http__parse_request_rcdecd3093:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3093:
    mov x0, x20
.Lssa_http__parse_request_rcdece3093:
.Lssa_http__parse_request_980:
    mov x20, x12
.Lssa_http__parse_request_912:
    add x12, x10, #1
    sxtw x10, w12
.Lssa_http__parse_request_911:
    mov x12, #3
    mov x14, #1
    cmp x9, #37
    csel x12, x12, x14, eq
.Lssa_http__parse_request_907:
    add x12, x11, x12
    sxtw x11, w12
    cmp x11, x24
    b.lt .Lssa_http__parse_request_933
.Lssa_http__parse_request_883:
    cmp x11, x24
    cset x12, eq
    add x9, x23, #1
    sxtw x9, w9
.Lssa_http__parse_request_882:
    sub x14, x10, x9
    sxtw x14, w14
    cmp x14, #1
    b.lt .Lssa_http__parse_request_878
.Lssa_http__parse_request_881:
    cmp x14, #2
    b.gt .Lssa_http__parse_request_878
.Lssa_http__parse_request_880:
    ldr x6, [x20]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, x9
    ldrb w13, [x5, #8]
    cmp x13, #46
    b.ne .Lssa_http__parse_request_878
.Lssa_http__parse_request_879:
    sub w13, w10, #1
    ldr x6, [x20]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, x13
    ldrb w9, [x5, #8]
    cmp x9, #46
    b.eq .Lssa_http__parse_request_876
.Lssa_http__parse_request_878:
    mov x14, #0
.Lssa_http__parse_request_877:
.Lssa_http__parse_request_876:
    cmp x14, #0
    b.ne .Lssa_http__parse_request_873
.Lssa_http__parse_request_875:
    mov x23, x10
    mov x28, #0
    b .Lssa_http__parse_request_859
.Lssa_http__parse_request_873:
    cmp x14, #1
    b.ne .Lssa_http__parse_request_870
.Lssa_http__parse_request_872:
    b .Lssa_http__parse_request_861
.Lssa_http__parse_request_870:
    cmp x23, #0
    b.ne .Lssa_http__parse_request_867
.Lssa_http__parse_request_869:
    mov x14, #-1
    mov x23, x14
    b .Lssa_http__parse_request_861
.Lssa_http__parse_request_867:
    sub x14, x23, #1
    sxtw x14, w14
.Lssa_http__parse_request_866:
.Lssa_http__parse_request_1020:
    ldr x6, [x20]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, x14
    ldrb w9, [x5, #8]
    cmp x9, #47
    b.eq .Lssa_http__parse_request_865
.Lssa_http__parse_request_1021:
    sub x9, x14, #1
    sxtw x14, w9
    b .Lssa_http__parse_request_1020
.Lssa_http__parse_request_865:
    cbz x21, .Lssa_http__parse_request_863
.Lssa_http__parse_request_864:
    str x11, [sp, #56]
    str x12, [sp, #48]
    str x14, [sp, #40]
    str x23, [sp, #-16]!
    str x14, [sp, #-16]!
    str x20, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x9, x0
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    ldr x14, [sp, #40]
.Lssa_http__parse_request_1032:
    str x9, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x9
    bl __fn_utf8__is_valid.r
    mov x10, x0
    ldr x9, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    tbnz x9, #0, .Lssa_http__parse_request_rcdeck3151
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3151
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3151
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3151
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x9
    bl __fn___fern_str_free.u
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    b .Lssa_http__parse_request_rcdece3151
.Lssa_http__parse_request_rcdecd3151:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_rcdeck3151:
    mov x0, x9
.Lssa_http__parse_request_rcdece3151:
    cbz x10, .Lssa_http__parse_request_862
.Lssa_http__parse_request_863:
    mov x23, x14
    b .Lssa_http__parse_request_861
.Lssa_http__parse_request_862:
    mov x10, #-1
    mov x23, x10
.Lssa_http__parse_request_861:
    cmp x23, #0
    b.ge .Lssa_http__parse_request_860
.Lssa_http__parse_request_1039:
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3169
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3169
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3169
    str x11, [sp, #56]
    str x12, [sp, #48]
    mov x0, x20
    bl __fn___fern_arr_dec.u
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    b .Lssa_http__parse_request_rcdece3169
.Lssa_http__parse_request_rcdecd3169:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3169:
    mov x0, x20
.Lssa_http__parse_request_rcdece3169:
    b .Lssa_http__parse_request_231
.Lssa_http__parse_request_860:
    mov x28, x12
.Lssa_http__parse_request_859:
    add x11, x11, #1
    sxtw x9, w11
    cmp x9, x24
    b.le .Lssa_http__parse_request_890
.Lssa_http__parse_request_237:
    cmp x23, #0
    b.eq .Lssa_http__parse_request_235
.Lssa_http__parse_request_236:
    cbz x28, .Lssa_http__parse_request_230
.Lssa_http__parse_request_235:
    mov x28, #47
.Lssa_http__parse_request_234:
    ldr x9, [x20, #0]
    cmp x23, x9
    b.ge .Lssa_http__parse_request_228
.Lssa_http__parse_request_233:
    tst x20, #1
    b.ne .Lssa_http__parse_request_uq233
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq233
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq233:
    b.ne .Lssa_http__parse_request_1058
.Lssa_http__parse_request_1057:
    b .Lssa_http__parse_request_1059
.Lssa_http__parse_request_1058:
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3189
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3189
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3189
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3189
.Lssa_http__parse_request_rcdecd3189:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3189:
    mov x0, x20
.Lssa_http__parse_request_rcdece3189:
    mov x9, #0
    ldr x11, [x20, #0]
    str x11, [sp, #-16]!
    str x9, [sp, #-16]!
    str x20, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    mov x20, x0
.Lssa_http__parse_request_1059:
    mov x11, #47
    ldr x7, [x20]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, x23
    strb w11, [x5, #8]
    mov x22, x20
    b .Lssa_http__parse_request_227
.Lssa_http__parse_request_232:
    mov x24, #0
    mov x11, #400
    mov x9, #0
    b .Lssa_http__parse_request_219
.Lssa_http__parse_request_231:
    mov x24, #0
    mov x11, #400
    mov x9, #0
    b .Lssa_http__parse_request_219
.Lssa_http__parse_request_230:
    mov x22, x20
    b .Lssa_http__parse_request_1067
.Lssa_http__parse_request_228:
    tst x20, #1
    b.ne .Lssa_http__parse_request_uq228
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq228
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq228:
    b.ne .Lssa_http__parse_request_1065
.Lssa_http__parse_request_1064:
    mov x0, x20
    mov x1, x28
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3199s
.Lssa_http__parse_request_apush3199o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3199e
.Lssa_http__parse_request_apush3199s:
    bl __fern_arr_push_owned_u8
.Lssa_http__parse_request_apush3199e:
    mov x22, x0
    b .Lssa_http__parse_request_227
.Lssa_http__parse_request_1065:
    mov x0, x20
    mov x1, x28
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3200s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3200o
    tbz w3, #31, .Lssa_http__parse_request_apush3200s
.Lssa_http__parse_request_apush3200o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3200e
.Lssa_http__parse_request_apush3200s:
    bl __fern_arr_push_u8
.Lssa_http__parse_request_apush3200e:
    mov x22, x0
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3201
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3201
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3201
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3201
.Lssa_http__parse_request_rcdecd3201:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcdeck3201:
    mov x0, x20
.Lssa_http__parse_request_rcdece3201:
.Lssa_http__parse_request_1066:
.Lssa_http__parse_request_227:
    add x23, x23, #1
    sxtw x23, w23
.Lssa_http__parse_request_226:
.Lssa_http__parse_request_225:
.Lssa_http__parse_request_1067:
    cmp x24, x26
    b.ge .Lssa_http__parse_request_224
.Lssa_http__parse_request_1073:
    ldr x6, [x19]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x24
    ldrb w20, [x5, #8]
.Lssa_http__parse_request_1072:
    ldr x9, [x22, #0]
    cmp x23, x9
    b.ge .Lssa_http__parse_request_1069
.Lssa_http__parse_request_1071:
    tst x22, #1
    b.ne .Lssa_http__parse_request_uq1071
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1071
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1071:
    b.ne .Lssa_http__parse_request_1083
.Lssa_http__parse_request_1082:
    b .Lssa_http__parse_request_1084
.Lssa_http__parse_request_1083:
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3227
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3227
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3227
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3227
.Lssa_http__parse_request_rcdecd3227:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_rcdeck3227:
    mov x0, x22
.Lssa_http__parse_request_rcdece3227:
    mov x9, #0
    ldr x11, [x22, #0]
    str x11, [sp, #-16]!
    str x9, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    mov x22, x0
.Lssa_http__parse_request_1084:
    ldr x7, [x22]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x23
    strb w20, [x5, #8]
    b .Lssa_http__parse_request_1068
.Lssa_http__parse_request_1069:
    tst x22, #1
    b.ne .Lssa_http__parse_request_uq1069
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1069
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1069:
    b.ne .Lssa_http__parse_request_1087
.Lssa_http__parse_request_1086:
    mov x0, x22
    mov x1, x20
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3234s
.Lssa_http__parse_request_apush3234o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3234e
.Lssa_http__parse_request_apush3234s:
    bl __fern_arr_push_owned_u8
.Lssa_http__parse_request_apush3234e:
    mov x28, x0
    b .Lssa_http__parse_request_1088
.Lssa_http__parse_request_1087:
    mov x0, x22
    mov x1, x20
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3235s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3235o
    tbz w3, #31, .Lssa_http__parse_request_apush3235s
.Lssa_http__parse_request_apush3235o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_apush3235e
.Lssa_http__parse_request_apush3235s:
    bl __fern_arr_push_u8
.Lssa_http__parse_request_apush3235e:
    mov x28, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3236
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3236
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3236
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3236
.Lssa_http__parse_request_rcdecd3236:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_rcdeck3236:
    mov x0, x22
.Lssa_http__parse_request_rcdece3236:
.Lssa_http__parse_request_1088:
    mov x22, x28
.Lssa_http__parse_request_1068:
    add x11, x23, #1
    b .Lssa_http__parse_request_pool_882
    .ltorg
.Lssa_http__parse_request_pool_882:
    sxtw x23, w11
    add x24, x24, #1
    cmp x24, x26
    b.lt .Lssa_http__parse_request_1073
.Lssa_http__parse_request_224:
    mov x11, #0
    str x23, [sp, #-16]!
    str x11, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x24, x0
.Lssa_http__parse_request_1091:
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3248
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3248
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3248
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3248
.Lssa_http__parse_request_rcdecd3248:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_rcdeck3248:
    mov x0, x22
.Lssa_http__parse_request_rcdece3248:
    cbz x21, .Lssa_http__parse_request_222
.Lssa_http__parse_request_223:
    mov x0, x24
    bl __fn_utf8__is_valid.r
    cbnz x0, .Lssa_http__parse_request_222
.Lssa_http__parse_request_1098:
    tbnz x24, #0, .Lssa_http__parse_request_rcdeck3250
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3250
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3250
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3250
    mov x0, x24
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3250
.Lssa_http__parse_request_rcdecd3250:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_rcdeck3250:
    mov x0, x24
.Lssa_http__parse_request_rcdece3250:
    b .Lssa_http__parse_request_221
.Lssa_http__parse_request_222:
    mov x11, #0
    mov x9, #1
    b .Lssa_http__parse_request_219
.Lssa_http__parse_request_221:
    mov x24, #0
    mov x11, #400
    mov x9, #0
.Lssa_http__parse_request_220:
.Lssa_http__parse_request_219:
    mov x22, x11
.Lssa_http__parse_request_218:
    cbnz x9, .Lssa_http__parse_request_217
.Lssa_http__parse_request_1103:
    tbnz x24, #0, .Lssa_http__parse_request_rcdeck3269
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3269
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3269
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3269
    mov x0, x24
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3269
.Lssa_http__parse_request_rcdecd3269:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_rcdeck3269:
    mov x0, x24
.Lssa_http__parse_request_rcdece3269:
    b .Lssa_http__parse_request_215
.Lssa_http__parse_request_217:
    mov x21, x24
    ldr x24, [sp, #96]
    mov x22, #0
    b .Lssa_http__parse_request_214
.Lssa_http__parse_request_215:
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    mov x10, #-1
    mov x11, #-1
    mov x24, x10
    mov x26, x11
    mov x21, x9
.Lssa_http__parse_request_214:
    cmp x22, #0
    b.eq .Lssa_http__parse_request_212
.Lssa_http__parse_request_1107:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3283
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3283
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3283
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3283
.Lssa_http__parse_request_rcdecd3283:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3283:
    mov x0, x19
.Lssa_http__parse_request_rcdece3283:
    tbnz x21, #0, .Lssa_http__parse_request_rcdeck3284
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3284
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3284
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3284
    mov x0, x21
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3284
.Lssa_http__parse_request_rcdecd3284:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_rcdeck3284:
    mov x0, x21
.Lssa_http__parse_request_rcdece3284:
.Lssa_http__parse_request_213:
    mov x11, x22
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_212:
    str x24, [sp, #112]
    str x21, [sp, #96]
.Lssa_http__parse_request_211:
    ldr x4, [sp, #80]
    cmp x4, #0
    b.ge .Lssa_http__parse_request_210
.Lssa_http__parse_request_1112:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3294
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3294
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3294
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3294
.Lssa_http__parse_request_rcdecd3294:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3294:
    mov x0, x19
.Lssa_http__parse_request_rcdece3294:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3295
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3295
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3295
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3295
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3295
.Lssa_http__parse_request_rcdecd3295:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3295:
    mov x0, x4
.Lssa_http__parse_request_rcdece3295:
    b .Lssa_http__parse_request_209
.Lssa_http__parse_request_210:
    cmp x27, #0
    b.ge .Lssa_http__parse_request_207
.Lssa_http__parse_request_1116:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3298
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3298
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3298
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3298
.Lssa_http__parse_request_rcdecd3298:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3298:
    mov x0, x19
.Lssa_http__parse_request_rcdece3298:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3299
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3299
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3299
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3299
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3299
.Lssa_http__parse_request_rcdecd3299:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3299:
    mov x0, x4
.Lssa_http__parse_request_rcdece3299:
.Lssa_http__parse_request_209:
    mov x11, #1
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_207:
    add x11, x27, #4
    ldr x5, [sp, #104]
    sub x4, x11, x5
    str x4, [sp, #88]
    ldr x4, [sp, #80]
    add x11, x4, #2
    sxtw x11, w11
    cmp x11, x27
    csel x9, x27, x11, gt
.Lssa_http__parse_request_204:
.Lssa_http__parse_request_203:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http__parse_request_202:
    mov x23, x0
    mov x24, x9
    mov x28, #1
    mov x20, #0
.Lssa_http__parse_request_1126:
    cmp x24, x27
    b.ge .Lssa_http__parse_request_201
.Lssa_http__parse_request_1181:
    adrp x9, .K3
    add x9, x9, :lo12:.K3
    mov x2, x9
    mov x1, x24
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L72
    mov x1, #0
.L72:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L75
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L73:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L74
    add x5, x5, #16
    cmp x5, x8
    b.ls .L73
    sub x1, x5, x0
    b .L75
.L74:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L76
.L75:
    add x10, x9, #96
.L79:
    cmp x1, x3
    b.ge .L77
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L76
    add x1, x1, #1
    b .L79
.L76:
    str x1, [sp, #-16]!
    b .L78
.L77:
    str x3, [sp, #-16]!
.L78:
    ldr x0, [sp], #16
    cmp x0, x27
    csel x10, x27, x0, gt
.Lssa_http__parse_request_1187:
    cmp x10, x24
    b.eq .Lssa_http__parse_request_1178
.Lssa_http__parse_request_1180:
    cmp x10, x27
    b.ge .Lssa_http__parse_request_1178
.Lssa_http__parse_request_1179:
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #58
    b.eq .Lssa_http__parse_request_1176
.Lssa_http__parse_request_1178:
    mov x9, #-1
    mov x10, x27
    b .Lssa_http__parse_request_1164
.Lssa_http__parse_request_1176:
    add x9, x10, #1
.Lssa_http__parse_request_1175:
    mov x11, #13
    str x10, [sp, #56]
    mov x2, x9
    mov x1, x11
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L80
    mov x2, #0
.L80:
    cmp x1, #255
    b.hi .L85
    cmp x2, x3
    b.ge .L85
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L82
.L81:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L87
    cmp x5, x8
    b.ls .L81
.L82:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L83
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L83
    sub x5, x5, #16
    b .L88
.L87:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L88
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L88:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L86
.L83:
    cmp x5, x6
    b.ge .L85
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L84
    add x5, x5, #1
    b .L83
.L84:
    sub x2, x5, x0
    b .L86
.L85:
    mov x2, #-1
.L86:
    mov x0, x2
    ldr x10, [sp, #56]
    cmp x0, #0
    b.lt .Lssa_http__parse_request_1173
.Lssa_http__parse_request_1174:
    cmp x0, x27
    b.lt .Lssa_http__parse_request_1171
.Lssa_http__parse_request_1173:
    mov x0, x27
    b .Lssa_http__parse_request_1167
.Lssa_http__parse_request_1171:
    add x11, x0, #1
    cmp x11, x27
    b.ge .Lssa_http__parse_request_1169
.Lssa_http__parse_request_1170:
    add x11, x0, #1
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_1167
.Lssa_http__parse_request_1169:
    mov x9, #-1
    mov x0, x9
.Lssa_http__parse_request_1168:
.Lssa_http__parse_request_1167:
    cmp x0, #0
    b.ge .Lssa_http__parse_request_1165
.Lssa_http__parse_request_1166:
    mov x9, #-1
    mov x10, x27
    b .Lssa_http__parse_request_1164
.Lssa_http__parse_request_1165:
    mov x9, x10
    mov x10, x0
.Lssa_http__parse_request_1164:
    cmp x9, #0
    b.ge .Lssa_http__parse_request_1162
.Lssa_http__parse_request_1233:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3437
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3437
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3437
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x19
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_rcdece3437
.Lssa_http__parse_request_rcdecd3437:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3437:
    mov x0, x19
.Lssa_http__parse_request_rcdece3437:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3438
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3438
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3438
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3438
    str x9, [sp, #56]
    str x10, [sp, #48]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_rcdece3438
.Lssa_http__parse_request_rcdecd3438:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3438:
    mov x0, x4
.Lssa_http__parse_request_rcdece3438:
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_198
.Lssa_http__parse_request_1162:
    add x11, x20, #1
    sxtw x20, w11
    cmp x20, #100
    b.le .Lssa_http__parse_request_1160
.Lssa_http__parse_request_1237:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3444
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3444
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3444
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x19
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_rcdece3444
.Lssa_http__parse_request_rcdecd3444:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3444:
    mov x0, x19
.Lssa_http__parse_request_rcdece3444:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3445
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3445
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3445
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3445
    str x9, [sp, #56]
    str x10, [sp, #48]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_rcdece3445
.Lssa_http__parse_request_rcdecd3445:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3445:
    mov x0, x4
.Lssa_http__parse_request_rcdece3445:
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_197
.Lssa_http__parse_request_1160:
    sub x11, x20, #1
    sxtw x12, w11
    cbz x28, .Lssa_http__parse_request_1153
.Lssa_http__parse_request_1159:
    ldr x11, [x25, #8]
    ldr x14, [x11, #0]
    cmp x12, x14
    b.lt .Lssa_http__parse_request_1153
.Lssa_http__parse_request_1158:
    cmp x12, #0
    b.le .Lssa_http__parse_request_1155
.Lssa_http__parse_request_1249:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
.Lssa_http__parse_request_1157:
    tbnz x25, #0, .Lssa_http__parse_request_rcinc3456
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc3456
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc3456
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_rcinc3456:
    mov x0, x25
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    mov x0, x25
    mov x9, x12
    bl __fn_http____leading_fields.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    mov x23, x0
.Lssa_http__parse_request_1156:
.Lssa_http__parse_request_1155:
    mov x28, #0
.Lssa_http__parse_request_1154:
.Lssa_http__parse_request_1153:
    mov x14, #-1
    cmp x28, #0
    csel x14, x12, x14, ne
.Lssa_http__parse_request_1150:
    add x11, x9, #1
    sxtw x11, w11
.Lssa_http__parse_request_1149:
.Lssa_http__parse_request_1260:
    cmp x11, x10
    b.ge .Lssa_http__parse_request_1147
.Lssa_http__parse_request_1267:
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w13, [x5, #8]
.Lssa_http__parse_request_1266:
    cmp x13, #32
    b.eq .Lssa_http__parse_request_1261
.Lssa_http__parse_request_1264:
    cmp x13, #9
    b.ne .Lssa_http__parse_request_1147
.Lssa_http__parse_request_1261:
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_http__parse_request_1267
.Lssa_http__parse_request_1147:
    mov x13, x10
.Lssa_http__parse_request_1283:
    cmp x13, x11
    b.le .Lssa_http__parse_request_1146
.Lssa_http__parse_request_1290:
    sub x15, x13, #1
    ldr x6, [x19]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x15
    ldrb w1, [x5, #8]
.Lssa_http__parse_request_1289:
    cmp x1, #32
    b.eq .Lssa_http__parse_request_1284
.Lssa_http__parse_request_1287:
    cmp x1, #9
    b.ne .Lssa_http__parse_request_1146
.Lssa_http__parse_request_1284:
    sub x13, x13, #1
    cmp x13, x11
    b.gt .Lssa_http__parse_request_1290
.Lssa_http__parse_request_1146:
    cmp x14, #0
    b.lt .Lssa_http__parse_request_1141
.Lssa_http__parse_request_1145:
    ldr x1, [x25, #16]
    ldr x6, [x1]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x15, [x1, x5, lsl #3]
    ldr x1, [x15, #8]
    sub x15, x13, x11
    sxtw x15, w15
    cmp x1, x15
    b.ne .Lssa_http__parse_request_1141
.Lssa_http__parse_request_1144:
    ldr x15, [x25, #16]
    ldr x6, [x15]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x8, [x15, x5, lsl #3]
    ldr x1, [x8, #8]
    mov x2, #0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    mov x4, x1
    mov x3, x2
    mov x2, x8
    mov x1, x11
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L89_aop
    mov x1, #0
.L89_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L89_bop
    mov x3, #0
.L89_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L89_nok
    mov x4, #0
.L89_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L89_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L89_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L89_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L89_done
.L89_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L89_vec
.L89_short:
    cmp x10, #8
    b.lt .L89_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L89_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L89_eq
    add x8, x8, x14
.L89_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L89_done
.L89_w4:
    cmp x10, #4
    b.lt .L89_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L89_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L89_eq
    add x8, x8, x14
.L89_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L89_done
.L89_w2:
    cmp x10, #2
    b.lt .L89_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L89_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L89_eq
    add x8, x8, x14
.L89_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L89_done
.L89_tail:
    cmp x8, x13
    b.ge .L89_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L89_th
    add x8, x8, #1
    add x9, x9, #1
    b .L89_tail
.L89_th:
    sub x2, x8, x12
    b .L89_done
.L89_eq:
    mov x2, x4
.L89_done:
    mov x0, x2
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
    ldr x2, [x8, #8]
    cmp x0, x2
    b.ne .Lssa_http__parse_request_1141
.Lssa_http__parse_request_1143:
    ldr x6, [x15]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x2, [x15, x5, lsl #3]
    tbnz x2, #0, .Lssa_http__parse_request_rcinc3523
    cmp x2, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc3523
    ldur w5, [x2, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc3523
    add w5, w5, #1
    stur w5, [x2, #-8]
.Lssa_http__parse_request_rcinc3523:
    mov x0, x2
    mov x15, x2
    b .Lssa_http__parse_request_1137
.Lssa_http__parse_request_1141:
    adrp x2, .K6
    add x2, x2, :lo12:.K6
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    mov x1, x11
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L90
    mov x1, #0
.L90:
    adrp x9, .S9
    add x9, x9, :lo12:.S9
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L93
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L91:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L92
    add x5, x5, #16
    cmp x5, x8
    b.ls .L91
    sub x1, x5, x0
    b .L93
.L92:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L94
.L93:
    add x10, x9, #96
.L97:
    cmp x1, x3
    b.ge .L95
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L94
    add x1, x1, #1
    b .L97
.L94:
    str x1, [sp, #-16]!
    b .L96
.L95:
    str x3, [sp, #-16]!
.L96:
    ldr x0, [sp], #16
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    cmp x0, x13
    b.ge .Lssa_http__parse_request_1139
.Lssa_http__parse_request_1319:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3534
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3534
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3534
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    mov x0, x19
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    b .Lssa_http__parse_request_rcdece3534
.Lssa_http__parse_request_rcdecd3534:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3534:
    mov x0, x19
.Lssa_http__parse_request_rcdece3534:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3535
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3535
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3535
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3535
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    b .Lssa_http__parse_request_rcdece3535
.Lssa_http__parse_request_rcdecd3535:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3535:
    mov x0, x4
.Lssa_http__parse_request_rcdece3535:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    b .Lssa_http__parse_request_54
.Lssa_http__parse_request_1139:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #-16]!
    str x11, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x15, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
.Lssa_http__parse_request_1323:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x15
    bl __fn_utf8__is_valid.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    cbnz x0, .Lssa_http__parse_request_1137
.Lssa_http__parse_request_1326:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3539
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3539
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3539
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x19
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    b .Lssa_http__parse_request_rcdece3539
.Lssa_http__parse_request_rcdecd3539:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3539:
    mov x0, x19
.Lssa_http__parse_request_rcdece3539:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3540
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3540
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3540
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3540
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    b .Lssa_http__parse_request_rcdece3540
.Lssa_http__parse_request_rcdecd3540:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3540:
    mov x0, x4
.Lssa_http__parse_request_rcdece3540:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    tbnz x15, #0, .Lssa_http__parse_request_rcdeck3542
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3542
    ldur w5, [x15, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3542
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3542
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x15
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    b .Lssa_http__parse_request_rcdece3542
.Lssa_http__parse_request_rcdecd3542:
    sub w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_rcdeck3542:
    mov x0, x15
.Lssa_http__parse_request_rcdece3542:
    b .Lssa_http__parse_request_54
.Lssa_http__parse_request_1138:
.Lssa_http__parse_request_1137:
    cbz x28, .Lssa_http__parse_request_1129
.Lssa_http__parse_request_1136:
    ldr x13, [x25, #8]
    ldr x6, [x13]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x11, [x13, x5, lsl #3]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x15, [sp, #24]
    mov x0, x19
    mov x10, x9
    mov x9, x24
    bl __fn_http____shared_string.r
    mov x13, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x15, [sp, #24]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    ldr x6, [x13, #8]
    ldr x7, [x11, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn3561
    mov x0, x13
    mov x9, x11
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd3561
.Lssa_http__parse_request_streqn3561:
    mov x0, #0
.Lssa_http__parse_request_streqd3561:
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    cbz x0, .Lssa_http__parse_request_1134
.Lssa_http__parse_request_1135:
    ldr x11, [x25, #16]
    ldr x6, [x11]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x2, [x11, x5, lsl #3]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    ldr x6, [x15, #8]
    ldr x7, [x2, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn3564
    mov x0, x15
    mov x9, x2
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd3564
.Lssa_http__parse_request_streqn3564:
    mov x0, #0
.Lssa_http__parse_request_streqd3564:
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    mov x11, x0
    b .Lssa_http__parse_request_1133
.Lssa_http__parse_request_1134:
    mov x11, #0
.Lssa_http__parse_request_1133:
    cbz x11, .Lssa_http__parse_request_1339
.Lssa_http__parse_request_1338:
    tbnz x13, #0, .Lssa_http__parse_request_rcdeck3568
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3568
    ldur w5, [x13, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3568
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3568
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    mov x0, x13
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_rcdece3568
.Lssa_http__parse_request_rcdecd3568:
    sub w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_rcdeck3568:
    mov x0, x13
.Lssa_http__parse_request_rcdece3568:
    tbnz x15, #0, .Lssa_http__parse_request_rcdeck3569
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3569
    ldur w5, [x15, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3569
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3569
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    mov x0, x15
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_rcdece3569
.Lssa_http__parse_request_rcdecd3569:
    sub w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_rcdeck3569:
    mov x0, x15
.Lssa_http__parse_request_rcdece3569:
    b .Lssa_http__parse_request_1130
.Lssa_http__parse_request_1339:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_1131
.Lssa_http__parse_request_1132:
    b .Lssa_http__parse_request_1130
.Lssa_http__parse_request_1131:
    tbnz x25, #0, .Lssa_http__parse_request_rcinc3571
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc3571
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc3571
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_rcinc3571:
    mov x0, x25
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    mov x0, x25
    mov x9, x12
    bl __fn_http____leading_fields.r
    mov x14, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    tst x14, #1
    b.ne .Lssa_http__parse_request_uq1131
    cmp x14, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1131
    ldur w5, [x14, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1131:
    b.ne .Lssa_http__parse_request_1344
.Lssa_http__parse_request_1343:
    mov x12, x14
    b .Lssa_http__parse_request_1345
.Lssa_http__parse_request_1344:
    mov x12, #0
.Lssa_http__parse_request_1345:
    ldr x8, [x14, #8]
    cmp x12, #0
    b.ne .Lssa_http__parse_request_1348
.Lssa_http__parse_request_1346:
    tbnz x8, #0, .Lssa_http__parse_request_rcinc3579
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc3579
    ldur w5, [x8, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc3579
    add w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_rcinc3579:
    mov x0, x8
.Lssa_http__parse_request_1348:
    tst x8, #1
    b.ne .Lssa_http__parse_request_uq1348
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1348
    ldur w5, [x8, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1348:
    b.ne .Lssa_http__parse_request_1350
.Lssa_http__parse_request_1349:
    mov x0, x8
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3581s
.Lssa_http__parse_request_apush3581o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3581e
.Lssa_http__parse_request_apush3581s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
.Lssa_http__parse_request_apush3581e:
    mov x22, x0
    b .Lssa_http__parse_request_1351
.Lssa_http__parse_request_1350:
    mov x0, x8
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3582s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3582o
    tbz w3, #31, .Lssa_http__parse_request_apush3582s
.Lssa_http__parse_request_apush3582o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3582e
.Lssa_http__parse_request_apush3582s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_apush3582e:
    mov x22, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x0, x8
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3584
    ldur w5, [x8, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3584
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3584
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    mov x0, x8
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_rcdece3584
.Lssa_http__parse_request_rcdecd3584:
    sub w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_rcdeck3584:
    mov x0, x8
.Lssa_http__parse_request_rcdece3584:
.Lssa_http__parse_request_1351:
    ldr x8, [x14, #16]
    cmp x12, #0
    b.ne .Lssa_http__parse_request_1354
.Lssa_http__parse_request_1352:
    tbnz x8, #0, .Lssa_http__parse_request_rcinc3589
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc3589
    ldur w5, [x8, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc3589
    add w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_rcinc3589:
    mov x0, x8
.Lssa_http__parse_request_1354:
    tst x8, #1
    b.ne .Lssa_http__parse_request_uq1354
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1354
    ldur w5, [x8, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1354:
    b.ne .Lssa_http__parse_request_1356
.Lssa_http__parse_request_1355:
    mov x0, x8
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3591s
.Lssa_http__parse_request_apush3591o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3591e
.Lssa_http__parse_request_apush3591s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_apush3591e:
    mov x13, x0
    b .Lssa_http__parse_request_1357
.Lssa_http__parse_request_1356:
    mov x0, x8
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3592s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3592o
    tbz w3, #31, .Lssa_http__parse_request_apush3592s
.Lssa_http__parse_request_apush3592o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3592e
.Lssa_http__parse_request_apush3592s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_apush3592e:
    mov x13, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    mov x0, x8
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3594
    ldur w5, [x8, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3594
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3594
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    mov x0, x8
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    b .Lssa_http__parse_request_rcdece3594
.Lssa_http__parse_request_rcdecd3594:
    sub w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_rcdeck3594:
    mov x0, x8
.Lssa_http__parse_request_rcdece3594:
.Lssa_http__parse_request_1357:
    cmp x12, #0
    b.ne .Lssa_http__parse_request_1359
.Lssa_http__parse_request_1358:
    mov x8, #3
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x12, [sp, #-16]!
    str x8, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    adrp x8, .S0
    add x8, x8, :lo12:.S0
    str x8, [x0, #0]
    mov x8, x0
    b .Lssa_http__parse_request_1360
.Lssa_http__parse_request_1359:
    mov x8, x12
.Lssa_http__parse_request_1360:
    cmp x12, #0
    b.ne .Lssa_http__parse_request_1363
.Lssa_http__parse_request_1362:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x14
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
.Lssa_http__parse_request_1363:
    str x22, [x8, #8]
    str x13, [x8, #16]
    mov x23, x8
.Lssa_http__parse_request_1130:
    mov x28, x11
    b .Lssa_http__parse_request_1127
.Lssa_http__parse_request_1129:
    str x10, [sp, #56]
    str x15, [sp, #48]
    str x9, [sp, #-16]!
    str x24, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x11, x0
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_http__parse_request_1365:
    tst x23, #1
    b.ne .Lssa_http__parse_request_uq1365
    cmp x23, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1365
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1365:
    b.ne .Lssa_http__parse_request_1368
.Lssa_http__parse_request_1367:
    mov x24, x23
    b .Lssa_http__parse_request_1369
.Lssa_http__parse_request_1368:
    mov x24, #0
.Lssa_http__parse_request_1369:
    ldr x22, [x23, #8]
    cmp x24, #0
    b.ne .Lssa_http__parse_request_1372
.Lssa_http__parse_request_1370:
    tbnz x22, #0, .Lssa_http__parse_request_rcinc3625
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc3625
    ldur w5, [x22, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc3625
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_rcinc3625:
    mov x0, x22
.Lssa_http__parse_request_1372:
    tst x22, #1
    b.ne .Lssa_http__parse_request_uq1372
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1372
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1372:
    b.ne .Lssa_http__parse_request_1374
.Lssa_http__parse_request_1373:
    mov x0, x22
    mov x1, x11
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3627s
.Lssa_http__parse_request_apush3627o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3627e
.Lssa_http__parse_request_apush3627s:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_apush3627e:
    mov x22, x0
    b .Lssa_http__parse_request_1375
.Lssa_http__parse_request_1374:
    mov x0, x22
    mov x1, x11
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3628s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3628o
    tbz w3, #31, .Lssa_http__parse_request_apush3628s
.Lssa_http__parse_request_apush3628o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3628e
.Lssa_http__parse_request_apush3628s:
    str x10, [sp, #56]
    str x15, [sp, #48]
    bl __fern_arr_push
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_http__parse_request_apush3628e:
    mov x9, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x15, [sp, #40]
    mov x0, x22
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x15, [sp, #40]
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3630
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3630
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3630
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x15, [sp, #40]
    mov x0, x22
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x15, [sp, #40]
    b .Lssa_http__parse_request_rcdece3630
.Lssa_http__parse_request_rcdecd3630:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_rcdeck3630:
    mov x0, x22
.Lssa_http__parse_request_rcdece3630:
    mov x22, x9
.Lssa_http__parse_request_1375:
    ldr x9, [x23, #16]
    cmp x24, #0
    b.ne .Lssa_http__parse_request_1378
.Lssa_http__parse_request_1376:
    tbnz x9, #0, .Lssa_http__parse_request_rcinc3635
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc3635
    ldur w5, [x9, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc3635
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_rcinc3635:
    mov x0, x9
.Lssa_http__parse_request_1378:
    tst x9, #1
    b.ne .Lssa_http__parse_request_uq1378
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1378
    ldur w5, [x9, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1378:
    b.ne .Lssa_http__parse_request_1380
.Lssa_http__parse_request_1379:
    mov x0, x9
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3637s
.Lssa_http__parse_request_apush3637o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3637e
.Lssa_http__parse_request_apush3637s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x15, [sp, #40]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_apush3637e:
    mov x11, x0
    b .Lssa_http__parse_request_1381
.Lssa_http__parse_request_1380:
    mov x0, x9
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush3638s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush3638o
    tbz w3, #31, .Lssa_http__parse_request_apush3638s
.Lssa_http__parse_request_apush3638o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush3638e
.Lssa_http__parse_request_apush3638s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
.Lssa_http__parse_request_apush3638e:
    mov x11, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    mov x0, x9
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3640
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3640
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3640
    str x10, [sp, #56]
    str x11, [sp, #48]
    mov x0, x9
    bl __fn___fern_arr_dec.u
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    b .Lssa_http__parse_request_rcdece3640
.Lssa_http__parse_request_rcdecd3640:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_rcdeck3640:
    mov x0, x9
.Lssa_http__parse_request_rcdece3640:
.Lssa_http__parse_request_1381:
    cmp x24, #0
    b.ne .Lssa_http__parse_request_1383
.Lssa_http__parse_request_1382:
    mov x9, #3
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x24, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    adrp x9, .S0
    add x9, x9, :lo12:.S0
    str x9, [x0, #0]
    mov x15, x0
    b .Lssa_http__parse_request_1384
.Lssa_http__parse_request_1383:
    mov x15, x24
.Lssa_http__parse_request_1384:
    cmp x24, #0
    b.ne .Lssa_http__parse_request_1387
.Lssa_http__parse_request_1386:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_1387:
    str x22, [x15, #8]
    str x11, [x15, #16]
    mov x23, x15
.Lssa_http__parse_request_1128:
.Lssa_http__parse_request_1127:
    add x10, x10, #2
    sxtw x24, w10
    cmp x24, x27
    b.lt .Lssa_http__parse_request_1181
.Lssa_http__parse_request_201:
    cbz x28, .Lssa_http__parse_request_195
.Lssa_http__parse_request_200:
    ldr x10, [x25, #8]
    ldr x9, [x10, #0]
    cmp x20, x9
    b.ne .Lssa_http__parse_request_195
.Lssa_http__parse_request_1394:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_199:
    mov x23, x25
    b .Lssa_http__parse_request_191
.Lssa_http__parse_request_198:
    mov x11, #400
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_197:
    mov x11, #431
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_195:
    cbz x28, .Lssa_http__parse_request_191
.Lssa_http__parse_request_1401:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_194:
    mov x0, x25
    mov x9, x20
    bl __fn_http____leading_fields.r
    mov x23, x0
.Lssa_http__parse_request_193:
.Lssa_http__parse_request_192:
.Lssa_http__parse_request_191:
    add x26, x26, #1
.Lssa_http__parse_request_190:
    add w26, w26, #7
    ldr x6, [x19]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x26
    ldrb w9, [x5, #8]
    cmp x9, #48
    b.ne .Lssa_http__parse_request_187
.Lssa_http__parse_request_189:
    adrp x9, .SB10
    add x9, x9, :lo12:.SB10
    str x9, [sp, #80]
    b .Lssa_http__parse_request_185
.Lssa_http__parse_request_187:
    adrp x9, .SB11
    add x9, x9, :lo12:.SB11
    str x9, [sp, #80]
.Lssa_http__parse_request_186:
.Lssa_http__parse_request_185:
    mov x9, #-1
    mov x10, #-1
    mov x15, #-1
    mov x11, #-1
    mov x14, #-1
.Lssa_http__parse_request_184:
    mov x20, x9
    mov x25, x10
    mov x28, x15
    mov x24, x11
    mov x27, x14
    mov x22, #0
.Lssa_http__parse_request_1411:
    ldr x14, [x23, #8]
    ldr x11, [x14, #0]
    b .Lssa_http__parse_request_pool_1327
    .ltorg
.Lssa_http__parse_request_pool_1327:
    cmp x22, x11
    b.ge .Lssa_http__parse_request_181
.Lssa_http__parse_request_1461:
    ldr x11, [x23, #8]
    add x5, x22, #1
    ldr x14, [x11, x5, lsl #3]
.Lssa_http__parse_request_1460:
    ldr x11, [x14, #8]
    cmp x11, #4
    b.ne .Lssa_http__parse_request_1457
.Lssa_http__parse_request_1459:
    adrp x9, .SB12
    add x9, x9, :lo12:.SB12
    mov x10, #3
    str x11, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x11, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_1444
.Lssa_http__parse_request_1457:
    cmp x11, #6
    b.ne .Lssa_http__parse_request_1454
.Lssa_http__parse_request_1456:
    adrp x9, .SB13
    add x9, x9, :lo12:.SB13
    mov x10, #4
    str x11, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x11, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_1444
.Lssa_http__parse_request_1454:
    cmp x11, #10
    b.ne .Lssa_http__parse_request_1451
.Lssa_http__parse_request_1453:
    adrp x9, .SB14
    add x9, x9, :lo12:.SB14
    mov x10, #5
    str x11, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x11, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_1444
.Lssa_http__parse_request_1451:
    cmp x11, #14
    b.ne .Lssa_http__parse_request_1448
.Lssa_http__parse_request_1450:
    adrp x9, .SB15
    add x9, x9, :lo12:.SB15
    mov x10, #1
    str x11, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x11, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_1444
.Lssa_http__parse_request_1448:
    cmp x11, #17
    b.ne .Lssa_http__parse_request_1445
.Lssa_http__parse_request_1447:
    adrp x9, .SB16
    add x9, x9, :lo12:.SB16
    mov x10, #2
    mov x0, x14
    bl __fn_http____kind_if.r
    b .Lssa_http__parse_request_1444
.Lssa_http__parse_request_1445:
    mov x0, #0
.Lssa_http__parse_request_1444:
    cmp x0, #1
    b.ne .Lssa_http__parse_request_1436
.Lssa_http__parse_request_1442:
    mov x10, #-1
    mov x9, #-2
    cmp x20, x10
    csel x9, x22, x9, eq
    b .Lssa_http__parse_request_1437
.Lssa_http__parse_request_1440:
    b .Lssa_http__parse_request_1436
.Lssa_http__parse_request_1437:
    mov x20, x9
.Lssa_http__parse_request_1436:
    cmp x0, #2
    b.ne .Lssa_http__parse_request_1428
.Lssa_http__parse_request_1434:
    mov x9, #-1
    mov x10, #-2
    cmp x25, x9
    csel x10, x22, x10, eq
    b .Lssa_http__parse_request_1429
.Lssa_http__parse_request_1432:
    b .Lssa_http__parse_request_1428
.Lssa_http__parse_request_1429:
    mov x25, x10
.Lssa_http__parse_request_1428:
    cmp x0, #3
    b.ne .Lssa_http__parse_request_1420
.Lssa_http__parse_request_1426:
    mov x10, #-1
    mov x9, #-2
    cmp x28, x10
    csel x9, x22, x9, eq
    b .Lssa_http__parse_request_1421
.Lssa_http__parse_request_1424:
    b .Lssa_http__parse_request_1420
.Lssa_http__parse_request_1421:
    mov x28, x9
.Lssa_http__parse_request_1420:
    cmp x0, #4
    b.ne .Lssa_http__parse_request_1416
.Lssa_http__parse_request_1419:
    cmp x24, #0
    b.ge .Lssa_http__parse_request_1416
.Lssa_http__parse_request_1418:
    mov x24, x22
.Lssa_http__parse_request_1417:
.Lssa_http__parse_request_1416:
    cmp x0, #5
    b.ne .Lssa_http__parse_request_1412
.Lssa_http__parse_request_1415:
    cmp x27, #0
    b.ge .Lssa_http__parse_request_1412
.Lssa_http__parse_request_1414:
    mov x27, x22
.Lssa_http__parse_request_1413:
.Lssa_http__parse_request_1412:
    add x22, x22, #1
    b .Lssa_http__parse_request_1411
.Lssa_http__parse_request_181:
    cmp x24, #0
    b.ge .Lssa_http__parse_request_1546
.Lssa_http__parse_request_180:
    str xzr, [sp, #72]
    b .Lssa_http__parse_request_173
.Lssa_http__parse_request_178:
.Lssa_http__parse_request_1546:
    cmp x24, #0
    b.lt .Lssa_http__parse_request_177
.Lssa_http__parse_request_1549:
    ldr x9, [x23, #16]
    ldr x6, [x9]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    ldr x0, [x9, x5, lsl #3]
    adrp x9, .SB17
    add x9, x9, :lo12:.SB17
    bl __fn_http____token_is.r
    cbz x0, .Lssa_http__parse_request_176
.Lssa_http__parse_request_1547:
    adrp x9, .SB13
    add x9, x9, :lo12:.SB13
    add x24, x24, #1
    sxtw x10, w24
    mov x0, x23
    bl __fn_http____field_at.r
    mov x24, x0
    cmp x24, #0
    b.ge .Lssa_http__parse_request_1549
.Lssa_http__parse_request_177:
    mov x5, #1
    str x5, [sp, #72]
    b .Lssa_http__parse_request_173
.Lssa_http__parse_request_176:
    mov x5, #417
    str x5, [sp, #72]
.Lssa_http__parse_request_175:
.Lssa_http__parse_request_173:
    mov x10, #-1
    cmp x28, x10
    b.ne .Lssa_http__parse_request_170
.Lssa_http__parse_request_172:
    adrp x10, .SB11
    add x10, x10, :lo12:.SB11
    ldr x4, [sp, #80]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_http__parse_request_1566
.Lssa_http__parse_request_1565:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn3839
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_streqn3839
    ldr x0, [sp, #80]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd3839
.Lssa_http__parse_request_streqn3839:
    mov x0, #0
.Lssa_http__parse_request_streqd3839:
    b .Lssa_http__parse_request_1567
.Lssa_http__parse_request_1566:
    mov x0, #0
.Lssa_http__parse_request_1567:
    cbnz x0, .Lssa_http__parse_request_159
    b .Lssa_http__parse_request_161
.Lssa_http__parse_request_170:
    mov x10, #-2
    cmp x28, x10
    b.eq .Lssa_http__parse_request_159
.Lssa_http__parse_request_167:
    ldr x10, [x23, #16]
    ldr x6, [x10]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x9, [x10, x5, lsl #3]
.Lssa_http__parse_request_166:
    ldr x10, [x9, #8]
    ldr x14, [x9, #0]
    mov x9, #0
.Lssa_http__parse_request_1574:
    cmp x9, x10
    b.ge .Lssa_http__parse_request_161
.Lssa_http__parse_request_1578:
    ldrb w11, [x14, x9]
    cmp x11, #33
    b.lt .Lssa_http__parse_request_159
.Lssa_http__parse_request_1577:
    cmp x11, #126
    b.gt .Lssa_http__parse_request_159
.Lssa_http__parse_request_1575:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http__parse_request_1578
.Lssa_http__parse_request_161:
    ldr x4, [sp, #72]
    cmp x4, #417
    b.ne .Lssa_http__parse_request_157
.Lssa_http__parse_request_160:
    mov x28, #417
    b .Lssa_http__parse_request_156
.Lssa_http__parse_request_159:
    mov x28, #400
    b .Lssa_http__parse_request_156
.Lssa_http__parse_request_157:
    mov x28, #0
.Lssa_http__parse_request_156:
    cmp x28, #0
    b.le .Lssa_http__parse_request_152
.Lssa_http__parse_request_1604:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3874
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3874
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3874
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3874
.Lssa_http__parse_request_rcdecd3874:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3874:
    mov x0, x19
.Lssa_http__parse_request_rcdece3874:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3875
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3875
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3875
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3875
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3875
.Lssa_http__parse_request_rcdecd3875:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3875:
    mov x0, x4
.Lssa_http__parse_request_rcdece3875:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_155:
    mov x11, x28
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_152:
    mov x9, #-1
    cmp x25, x9
    b.ne .Lssa_http__parse_request_147
.Lssa_http__parse_request_150:
    mov x9, #-1
    cmp x20, x9
    b.ne .Lssa_http__parse_request_133
.Lssa_http__parse_request_149:
    mov x22, #0
    b .Lssa_http__parse_request_124
.Lssa_http__parse_request_147:
    mov x9, #-1
    cmp x20, x9
    b.eq .Lssa_http__parse_request_146
.Lssa_http__parse_request_1618:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3884
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3884
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3884
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3884
.Lssa_http__parse_request_rcdecd3884:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3884:
    mov x0, x19
.Lssa_http__parse_request_rcdece3884:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3885
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3885
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3885
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3885
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3885
.Lssa_http__parse_request_rcdecd3885:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3885:
    mov x0, x4
.Lssa_http__parse_request_rcdece3885:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_145
.Lssa_http__parse_request_146:
    mov x9, #-2
    cmp x25, x9
    b.ne .Lssa_http__parse_request_143
.Lssa_http__parse_request_1622:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3889
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3889
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3889
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3889
.Lssa_http__parse_request_rcdecd3889:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3889:
    mov x0, x19
.Lssa_http__parse_request_rcdece3889:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3890
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3890
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3890
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3890
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3890
.Lssa_http__parse_request_rcdecd3890:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3890:
    mov x0, x4
.Lssa_http__parse_request_rcdece3890:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_145:
    mov x10, #400
    b .Lssa_http__parse_request_104
.Lssa_http__parse_request_143:
    ldr x9, [x23, #16]
    ldr x6, [x9]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x14, [x9, x5, lsl #3]
    adrp x9, .SB18
    add x9, x9, :lo12:.SB18
    mov x1, x9
    mov x0, x14
    str x1, [sp, #-16]!
    str x0, [sp, #-16]!
    bl __fn___fern_str_split
    add sp, sp, #32
    mov x25, x0
    ldr x9, [x25, #0]
    sub w9, w9, #1
    ldr x6, [x25]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x0, [x25, x5, lsl #3]
    adrp x9, .SB19
    add x9, x9, :lo12:.SB19
    bl __fn_http____token_is.r
    cbnz x0, .Lssa_http__parse_request_141
.Lssa_http__parse_request_1628:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3904
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3904
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3904
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3904
.Lssa_http__parse_request_rcdecd3904:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3904:
    mov x0, x19
.Lssa_http__parse_request_rcdece3904:
    tst x25, #1
    b.ne .Lssa_http__parse_request_uq1628
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1628
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1628:
    b.ne .Lssa_http__parse_request_1632
.Lssa_http__parse_request_1630:
    mov x28, #0
.Lssa_http__parse_request_1634:
    ldr x9, [x25, #0]
    cmp x28, x9
    b.ge .Lssa_http__parse_request_1632
.Lssa_http__parse_request_1635:
    add x5, x28, #1
    ldr x9, [x25, x5, lsl #3]
    tbnz x9, #0, .Lssa_http__parse_request_rcdeck3911
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3911
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3911
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3911
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3911
.Lssa_http__parse_request_rcdecd3911:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_rcdeck3911:
    mov x0, x9
.Lssa_http__parse_request_rcdece3911:
    add x28, x28, #1
    b .Lssa_http__parse_request_1634
.Lssa_http__parse_request_1632:
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3915
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3915
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3915
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3915
.Lssa_http__parse_request_rcdecd3915:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_rcdeck3915:
    mov x0, x25
.Lssa_http__parse_request_rcdece3915:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3916
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3916
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3916
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3916
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3916
.Lssa_http__parse_request_rcdecd3916:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3916:
    mov x0, x4
.Lssa_http__parse_request_rcdece3916:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_137
.Lssa_http__parse_request_141:
.Lssa_http__parse_request_140:
    mov x28, #0
.Lssa_http__parse_request_1639:
    add x9, x28, #1
    sxtw x9, w9
    ldr x22, [x25, #0]
    cmp x9, x22
    b.ge .Lssa_http__parse_request_139
.Lssa_http__parse_request_1642:
    ldr x6, [x25]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x0, [x25, x5, lsl #3]
    adrp x9, .SB19
    add x9, x9, :lo12:.SB19
    bl __fn_http____token_is.r
    cbz x0, .Lssa_http__parse_request_1640
.Lssa_http__parse_request_1647:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3933
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3933
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3933
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3933
.Lssa_http__parse_request_rcdecd3933:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3933:
    mov x0, x19
.Lssa_http__parse_request_rcdece3933:
    tst x25, #1
    b.ne .Lssa_http__parse_request_uq1647
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq1647
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq1647:
    b.ne .Lssa_http__parse_request_1652
.Lssa_http__parse_request_1650:
    mov x24, #0
.Lssa_http__parse_request_1654:
    ldr x9, [x25, #0]
    cmp x24, x9
    b.ge .Lssa_http__parse_request_1652
.Lssa_http__parse_request_1655:
    add x5, x24, #1
    ldr x9, [x25, x5, lsl #3]
    tbnz x9, #0, .Lssa_http__parse_request_rcdeck3940
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3940
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3940
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3940
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3940
.Lssa_http__parse_request_rcdecd3940:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_rcdeck3940:
    mov x0, x9
.Lssa_http__parse_request_rcdece3940:
    add x24, x24, #1
    b .Lssa_http__parse_request_1654
.Lssa_http__parse_request_1652:
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3944
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3944
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3944
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3944
.Lssa_http__parse_request_rcdecd3944:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_rcdeck3944:
    mov x0, x25
.Lssa_http__parse_request_rcdece3944:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3945
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3945
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3945
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3945
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3945
.Lssa_http__parse_request_rcdecd3945:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3945:
    mov x0, x4
.Lssa_http__parse_request_rcdece3945:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_136
.Lssa_http__parse_request_1640:
    add x28, x28, #1
    sxtw x28, w28
    b .Lssa_http__parse_request_1639
.Lssa_http__parse_request_139:
    tst x25, #1
    b.ne .Lssa_http__parse_request_uq139
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq139
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq139:
    b.ne .Lssa_http__parse_request_1663
.Lssa_http__parse_request_1661:
    mov x28, #0
.Lssa_http__parse_request_1665:
    ldr x9, [x25, #0]
    cmp x28, x9
    b.ge .Lssa_http__parse_request_1663
.Lssa_http__parse_request_1666:
    add x5, x28, #1
    ldr x9, [x25, x5, lsl #3]
    tbnz x9, #0, .Lssa_http__parse_request_rcdeck3957
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3957
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3957
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3957
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3957
.Lssa_http__parse_request_rcdecd3957:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_rcdeck3957:
    mov x0, x9
.Lssa_http__parse_request_rcdece3957:
    add x28, x28, #1
    b .Lssa_http__parse_request_1665
.Lssa_http__parse_request_1663:
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3961
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3961
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3961
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3961
.Lssa_http__parse_request_rcdecd3961:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_rcdeck3961:
    mov x0, x25
.Lssa_http__parse_request_rcdece3961:
    cmp x22, #1
    b.le .Lssa_http__parse_request_135
.Lssa_http__parse_request_1669:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3964
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3964
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3964
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3964
.Lssa_http__parse_request_rcdecd3964:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3964:
    mov x0, x19
.Lssa_http__parse_request_rcdece3964:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3965
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3965
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3965
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3965
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3965
.Lssa_http__parse_request_rcdecd3965:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3965:
    mov x0, x4
.Lssa_http__parse_request_rcdece3965:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_138:
    mov x10, #501
    b .Lssa_http__parse_request_104
.Lssa_http__parse_request_137:
    mov x10, #400
    b .Lssa_http__parse_request_104
.Lssa_http__parse_request_136:
    mov x10, #400
    b .Lssa_http__parse_request_104
.Lssa_http__parse_request_135:
    mov x22, #0
    mov x28, #0
    b .Lssa_http__parse_request_122
.Lssa_http__parse_request_133:
    mov x9, #-2
    cmp x20, x9
    b.ne .Lssa_http__parse_request_130
.Lssa_http__parse_request_1677:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3972
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3972
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3972
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3972
.Lssa_http__parse_request_rcdecd3972:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3972:
    mov x0, x19
.Lssa_http__parse_request_rcdece3972:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3973
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3973
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3973
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3973
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3973
.Lssa_http__parse_request_rcdecd3973:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3973:
    mov x0, x4
.Lssa_http__parse_request_rcdece3973:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_105
.Lssa_http__parse_request_130:
    ldr x9, [x23, #16]
    ldr x6, [x9]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x20, #1
    ldr x22, [x9, x5, lsl #3]
    ldr x9, [x22, #8]
    cmp x9, #0
    b.ne .Lssa_http__parse_request_127
.Lssa_http__parse_request_1682:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3980
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3980
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3980
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3980
.Lssa_http__parse_request_rcdecd3980:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3980:
    mov x0, x19
.Lssa_http__parse_request_rcdece3980:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3981
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3981
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3981
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3981
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3981
.Lssa_http__parse_request_rcdecd3981:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3981:
    mov x0, x4
.Lssa_http__parse_request_rcdece3981:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_105
.Lssa_http__parse_request_127:
.Lssa_http__parse_request_126:
    ldr x20, [x22, #8]
    ldr x25, [x22, #0]
    mov x22, #0
    mov x28, #0
.Lssa_http__parse_request_1687:
    cmp x28, x20
    b.ge .Lssa_http__parse_request_124
.Lssa_http__parse_request_1695:
    ldrb w24, [x25, x28]
    cmp x24, #48
    b.ge .Lssa_http__parse_request_1694
.Lssa_http__parse_request_1700:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3998
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3998
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3998
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece3998
.Lssa_http__parse_request_rcdecd3998:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck3998:
    mov x0, x19
.Lssa_http__parse_request_rcdece3998:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck3999
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck3999
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd3999
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck3999
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece3999
.Lssa_http__parse_request_rcdecd3999:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck3999:
    mov x0, x4
.Lssa_http__parse_request_rcdece3999:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_105
.Lssa_http__parse_request_1694:
    cmp x24, #57
    b.le .Lssa_http__parse_request_1692
.Lssa_http__parse_request_1704:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4003
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4003
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4003
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece4003
.Lssa_http__parse_request_rcdecd4003:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck4003:
    mov x0, x19
.Lssa_http__parse_request_rcdece4003:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck4004
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4004
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4004
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4004
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece4004
.Lssa_http__parse_request_rcdecd4004:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck4004:
    mov x0, x4
.Lssa_http__parse_request_rcdece4004:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_105
.Lssa_http__parse_request_1692:
    sub x24, x24, #48
    sxtw x24, w24
    ldr x9, =214748364
    cmp x22, x9
    b.le .Lssa_http__parse_request_1691
.Lssa_http__parse_request_1708:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4011
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4011
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4011
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece4011
.Lssa_http__parse_request_rcdecd4011:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck4011:
    mov x0, x19
.Lssa_http__parse_request_rcdece4011:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck4012
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4012
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4012
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4012
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece4012
.Lssa_http__parse_request_rcdecd4012:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck4012:
    mov x0, x4
.Lssa_http__parse_request_rcdece4012:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_105
.Lssa_http__parse_request_1691:
    ldr x9, =214748364
    cmp x22, x9
    b.ne .Lssa_http__parse_request_1688
.Lssa_http__parse_request_1690:
    cmp x24, #7
    b.le .Lssa_http__parse_request_1688
.Lssa_http__parse_request_1716:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4018
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4018
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4018
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece4018
.Lssa_http__parse_request_rcdecd4018:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck4018:
    mov x0, x19
.Lssa_http__parse_request_rcdece4018:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck4019
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4019
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4019
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4019
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece4019
.Lssa_http__parse_request_rcdecd4019:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck4019:
    mov x0, x4
.Lssa_http__parse_request_rcdece4019:
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_105
.Lssa_http__parse_request_1688:
    mov x9, #10
    mul x9, x22, x9
    add x9, x9, x24
    sxtw x22, w9
    add x28, x28, #1
    cmp x28, x20
    b.lt .Lssa_http__parse_request_1695
.Lssa_http__parse_request_125:
.Lssa_http__parse_request_124:
    mov x28, x22
    mov x22, #1
.Lssa_http__parse_request_123:
.Lssa_http__parse_request_122:
    mov x0, x19
    ldr x9, [sp, #104]
    ldr x10, [sp, #112]
    ldr x11, [sp, #120]
    bl __fn_http____shared_string.r
    str x0, [sp, #64]
    ldr x4, [sp, #104]
    ldr x5, [sp, #88]
    add x9, x4, x5
    sxtw x20, w9
.Lssa_http__parse_request_121:
.Lssa_http__parse_request_120:
    mov x24, #0
.Lssa_http__parse_request_1722:
    cmp x27, #0
    b.lt .Lssa_http__parse_request_119
.Lssa_http__parse_request_1729:
    ldr x25, [x23, #16]
    ldr x6, [x25]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, #1
    ldr x0, [x25, x5, lsl #3]
    adrp x9, .SB20
    add x9, x9, :lo12:.SB20
    bl __fn_http____lists_token.r
    cbz x0, .Lssa_http__parse_request_1726
.Lssa_http__parse_request_1728:
    mov x24, #1
.Lssa_http__parse_request_1727:
.Lssa_http__parse_request_1726:
    ldr x6, [x25]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, #1
    ldr x0, [x25, x5, lsl #3]
    adrp x9, .SB21
    add x9, x9, :lo12:.SB21
    bl __fn_http____lists_token.r
.Lssa_http__parse_request_1723:
    adrp x9, .SB14
    add x9, x9, :lo12:.SB14
    add x27, x27, #1
    sxtw x10, w27
    mov x0, x23
    bl __fn_http____field_at.r
    mov x27, x0
    cmp x27, #0
    b.ge .Lssa_http__parse_request_1729
.Lssa_http__parse_request_119:
    cbnz x24, .Lssa_http__parse_request_111
.Lssa_http__parse_request_116:
    adrp x10, .SB10
    add x10, x10, :lo12:.SB10
    ldr x4, [sp, #80]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_http__parse_request_111
.Lssa_http__parse_request_1751:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn4072
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_streqn4072
    ldr x0, [sp, #80]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd4072
.Lssa_http__parse_request_streqn4072:
    mov x0, #0
.Lssa_http__parse_request_streqd4072:
.Lssa_http__parse_request_111:
    adrp x4, .K5
    add x4, x4, :lo12:.K5
    str x4, [sp, #120]
    adrp x4, .K1
    add x4, x4, :lo12:.K1
    str x4, [sp, #112]
    cbz x22, .Lssa_http__parse_request_97
.Lssa_http__parse_request_110:
    ldr x5, [sp, #128]
    cmp x28, x5
    b.le .Lssa_http__parse_request_102
.Lssa_http__parse_request_1763:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4080
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4080
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4080
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece4080
.Lssa_http__parse_request_rcdecd4080:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck4080:
    mov x0, x19
.Lssa_http__parse_request_rcdece4080:
.Lssa_http__parse_request_109:
    ldr x25, [sp, #120]
    ldr x5, [sp, #112]
    str x5, [sp, #136]
    mov x22, #413
    b .Lssa_http__parse_request_22
.Lssa_http__parse_request_105:
    mov x10, #400
.Lssa_http__parse_request_104:
    mov x11, x10
    b .Lssa_http__parse_request_50
.Lssa_http__parse_request_102:
    add x10, x20, x28
    sxtw x10, w10
    ldr x9, [x19, #0]
    cmp x10, x9
    b.le .Lssa_http__parse_request_99
.Lssa_http__parse_request_1770:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4089
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4089
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4089
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece4089
.Lssa_http__parse_request_rcdecd4089:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck4089:
    mov x0, x19
.Lssa_http__parse_request_rcdece4089:
.Lssa_http__parse_request_101:
    ldr x25, [sp, #120]
    ldr x5, [sp, #112]
    str x5, [sp, #136]
    mov x22, #1
    b .Lssa_http__parse_request_22
.Lssa_http__parse_request_99:
    add x28, x20, x28
    sxtw x28, w28
    str x19, [sp, #-16]!
    str x20, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_bytes_range
    add sp, sp, #48
    mov x22, x0
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4094
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4094
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4094
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece4094
.Lssa_http__parse_request_rcdecd4094:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck4094:
    mov x0, x19
.Lssa_http__parse_request_rcdece4094:
    mov x25, x22
    ldr x5, [sp, #112]
    str x5, [sp, #136]
    mov x22, #2
    b .Lssa_http__parse_request_22
.Lssa_http__parse_request_97:
    adrp x10, .SB11
    add x10, x10, :lo12:.SB11
    b .Lssa_http__parse_request_pool_1769
    .ltorg
.Lssa_http__parse_request_pool_1769:
    ldr x4, [sp, #80]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_http__parse_request_1777
.Lssa_http__parse_request_1776:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn4103
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_streqn4103
    ldr x0, [sp, #80]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd4103
.Lssa_http__parse_request_streqn4103:
    mov x0, #0
.Lssa_http__parse_request_streqd4103:
    b .Lssa_http__parse_request_1778
.Lssa_http__parse_request_1777:
    mov x0, #0
.Lssa_http__parse_request_1778:
    cbnz x0, .Lssa_http__parse_request_93
.Lssa_http__parse_request_1779:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4106
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4106
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4106
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece4106
.Lssa_http__parse_request_rcdecd4106:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck4106:
    mov x0, x19
.Lssa_http__parse_request_rcdece4106:
.Lssa_http__parse_request_96:
    ldr x25, [sp, #120]
    ldr x5, [sp, #112]
    str x5, [sp, #136]
    mov x22, #400
    b .Lssa_http__parse_request_22
.Lssa_http__parse_request_93:
    adrp x10, .K0
    add x10, x10, :lo12:.K0
    adrp x4, .K1
    add x4, x4, :lo12:.K1
    str x4, [sp, #104]
.Lssa_http__parse_request_92:
    ldr x28, [sp, #136]
    ldr x25, [sp, #128]
    mov x27, x10
.Lssa_http__parse_request_1784:
.Lssa_http__parse_request_1843:
    ldr x24, [x19, #0]
    add x10, x20, x28
    sxtw x10, w10
    cmp x10, x24
    csel x26, x24, x10, gt
.Lssa_http__parse_request_1840:
    mov x0, x19
    mov x9, x20
    mov x10, x26
    bl __fn_http____find_crlf.r
    mov x22, x0
    cmp x22, #0
    csel x10, x22, x26, ge
.Lssa_http__parse_request_1837:
    mov x0, x19
    mov x9, x20
    bl __fn_http____crlf_terminated.r
    cbz x0, .Lssa_http__parse_request_1832
.Lssa_http__parse_request_1835:
    cmp x22, #0
    b.ge .Lssa_http__parse_request_1827
.Lssa_http__parse_request_1834:
    add x10, x20, x28
    sxtw x10, w10
    cmp x24, x10
    b.lt .Lssa_http__parse_request_1830
.Lssa_http__parse_request_1833:
    mov x11, #431
    mov x22, #0
    mov x24, #0
    b .Lssa_http__parse_request_1808
.Lssa_http__parse_request_1832:
    mov x11, #400
    mov x22, #0
    mov x24, #0
    b .Lssa_http__parse_request_1808
.Lssa_http__parse_request_1830:
    mov x11, #1
    mov x22, #0
    mov x24, #0
    b .Lssa_http__parse_request_1808
.Lssa_http__parse_request_1827:
.Lssa_http__parse_request_1826:
    mov x9, x20
    mov x10, #0
.Lssa_http__parse_request_1870:
    cmp x9, x22
    b.ge .Lssa_http__parse_request_1825
.Lssa_http__parse_request_1902:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w14, [x5, #8]
.Lssa_http__parse_request_1901:
    cmp x14, #48
    b.lo .Lssa_http__parse_request_1897
.Lssa_http__parse_request_1900:
    cmp x14, #57
    b.hi .Lssa_http__parse_request_1897
.Lssa_http__parse_request_1899:
    sub x11, x14, #48
    sxtw x11, w11
    b .Lssa_http__parse_request_1888
.Lssa_http__parse_request_1897:
    cmp x14, #97
    b.lo .Lssa_http__parse_request_1893
.Lssa_http__parse_request_1896:
    cmp x14, #102
    b.hi .Lssa_http__parse_request_1893
.Lssa_http__parse_request_1895:
    sub x11, x14, #87
    sxtw x11, w11
    b .Lssa_http__parse_request_1888
.Lssa_http__parse_request_1893:
    cmp x14, #65
    b.lo .Lssa_http__parse_request_1889
.Lssa_http__parse_request_1892:
    cmp x14, #70
    b.hi .Lssa_http__parse_request_1889
.Lssa_http__parse_request_1891:
    sub x11, x14, #55
    sxtw x11, w11
    b .Lssa_http__parse_request_1888
.Lssa_http__parse_request_1889:
    mov x11, #-1
.Lssa_http__parse_request_1888:
    cmp x11, #0
    b.lt .Lssa_http__parse_request_1825
.Lssa_http__parse_request_1886:
    cmp x14, #48
    b.lo .Lssa_http__parse_request_1882
.Lssa_http__parse_request_1885:
    cmp x14, #57
    b.hi .Lssa_http__parse_request_1882
.Lssa_http__parse_request_1884:
    sub x11, x14, #48
    mov x14, x11
    b .Lssa_http__parse_request_1873
.Lssa_http__parse_request_1882:
    cmp x14, #97
    b.lo .Lssa_http__parse_request_1878
.Lssa_http__parse_request_1881:
    cmp x14, #102
    b.hi .Lssa_http__parse_request_1878
.Lssa_http__parse_request_1880:
    sub x11, x14, #87
    mov x14, x11
    b .Lssa_http__parse_request_1873
.Lssa_http__parse_request_1878:
    cmp x14, #65
    b.lo .Lssa_http__parse_request_1874
.Lssa_http__parse_request_1877:
    cmp x14, #70
    b.hi .Lssa_http__parse_request_1874
.Lssa_http__parse_request_1876:
    sub x14, x14, #55
    b .Lssa_http__parse_request_1873
.Lssa_http__parse_request_1874:
    mov x14, #-1
.Lssa_http__parse_request_1873:
    lsl x11, x10, #4
    add x11, x11, x14
    sxtw x11, w11
    cmp x11, x25
    b.gt .Lssa_http__parse_request_1823
.Lssa_http__parse_request_1871:
    lsl x11, x10, #4
    add x11, x11, x14
    sxtw x10, w11
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_http__parse_request_1902
.Lssa_http__parse_request_1825:
    cmp x9, x20
    b.ne .Lssa_http__parse_request_1821
.Lssa_http__parse_request_1824:
    mov x11, #400
    mov x24, #0
    b .Lssa_http__parse_request_1820
.Lssa_http__parse_request_1823:
    mov x11, #413
    mov x24, #0
    b .Lssa_http__parse_request_1820
.Lssa_http__parse_request_1821:
    mov x24, x10
    mov x11, #0
.Lssa_http__parse_request_1820:
    cmp x11, #0
    b.eq .Lssa_http__parse_request_1982
.Lssa_http__parse_request_1819:
    mov x22, #0
    mov x24, #0
    b .Lssa_http__parse_request_1808
.Lssa_http__parse_request_1817:
.Lssa_http__parse_request_1982:
    cmp x9, x22
    b.ge .Lssa_http__parse_request_1810
.Lssa_http__parse_request_2017:
.Lssa_http__parse_request_2023:
    cmp x9, x22
    b.ge .Lssa_http__parse_request_2015
.Lssa_http__parse_request_2030:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_2029:
    cmp x10, #32
    b.eq .Lssa_http__parse_request_2024
.Lssa_http__parse_request_2027:
    cmp x10, #9
    b.ne .Lssa_http__parse_request_2015
.Lssa_http__parse_request_2024:
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_http__parse_request_2030
.Lssa_http__parse_request_2015:
    cmp x9, x22
    b.ge .Lssa_http__parse_request_1809
.Lssa_http__parse_request_2014:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #59
    b.ne .Lssa_http__parse_request_1809
.Lssa_http__parse_request_2012:
    add x9, x9, #1
.Lssa_http__parse_request_2011:
    mov x26, x9
.Lssa_http__parse_request_2054:
    cmp x26, x22
    b.ge .Lssa_http__parse_request_2009
.Lssa_http__parse_request_2061:
    ldr x6, [x19]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x26
    ldrb w9, [x5, #8]
.Lssa_http__parse_request_2060:
    cmp x9, #32
    b.eq .Lssa_http__parse_request_2055
.Lssa_http__parse_request_2058:
    cmp x9, #9
    b.ne .Lssa_http__parse_request_2009
.Lssa_http__parse_request_2055:
    add x26, x26, #1
    cmp x26, x22
    b.lt .Lssa_http__parse_request_2061
.Lssa_http__parse_request_2009:
    adrp x9, .K3
    add x9, x9, :lo12:.K3
    mov x2, x9
    mov x1, x26
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L98
    mov x1, #0
.L98:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L101
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L99:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L100
    add x5, x5, #16
    cmp x5, x8
    b.ls .L99
    sub x1, x5, x0
    b .L101
.L100:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L102
.L101:
    add x10, x9, #96
.L105:
    cmp x1, x3
    b.ge .L103
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L102
    add x1, x1, #1
    b .L105
.L102:
    str x1, [sp, #-16]!
    b .L104
.L103:
    str x3, [sp, #-16]!
.L104:
    ldr x0, [sp], #16
    cmp x0, x22
    csel x0, x22, x0, gt
.Lssa_http__parse_request_2077:
    cmp x0, x26
    b.eq .Lssa_http__parse_request_1809
.Lssa_http__parse_request_2007:
    mov x9, x0
.Lssa_http__parse_request_2091:
    cmp x9, x22
    b.ge .Lssa_http__parse_request_2005
.Lssa_http__parse_request_2098:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_2097:
    cmp x10, #32
    b.eq .Lssa_http__parse_request_2092
.Lssa_http__parse_request_2095:
    cmp x10, #9
    b.ne .Lssa_http__parse_request_2005
.Lssa_http__parse_request_2092:
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_http__parse_request_2098
.Lssa_http__parse_request_2005:
    cmp x9, x22
    b.ge .Lssa_http__parse_request_1997
.Lssa_http__parse_request_2004:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #61
    b.ne .Lssa_http__parse_request_1997
.Lssa_http__parse_request_2003:
    add x9, x9, #1
.Lssa_http__parse_request_2002:
    mov x26, x9
.Lssa_http__parse_request_2122:
    cmp x26, x22
    b.ge .Lssa_http__parse_request_1999
.Lssa_http__parse_request_2129:
    ldr x6, [x19]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x26
    ldrb w9, [x5, #8]
.Lssa_http__parse_request_2128:
    cmp x9, #32
    b.eq .Lssa_http__parse_request_2123
.Lssa_http__parse_request_2126:
    cmp x9, #9
    b.ne .Lssa_http__parse_request_1999
.Lssa_http__parse_request_2123:
    add x26, x26, #1
    cmp x26, x22
    b.lt .Lssa_http__parse_request_2129
.Lssa_http__parse_request_1999:
    cmp x26, x22
    b.lt .Lssa_http__parse_request_1995
.Lssa_http__parse_request_1998:
    mov x9, #-1
    mov x10, x9
    b .Lssa_http__parse_request_1985
.Lssa_http__parse_request_1997:
    mov x9, x0
    b .Lssa_http__parse_request_1982
.Lssa_http__parse_request_1995:
    ldr x6, [x19]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x26
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_http__parse_request_1990
.Lssa_http__parse_request_1994:
    adrp x9, .K3
    add x9, x9, :lo12:.K3
    mov x2, x9
    mov x1, x26
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L106
    mov x1, #0
.L106:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L109
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L107:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L108
    add x5, x5, #16
    cmp x5, x8
    b.ls .L107
    sub x1, x5, x0
    b .L109
.L108:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L110
.L109:
    add x10, x9, #96
.L113:
    cmp x1, x3
    b.ge .L111
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L110
    add x1, x1, #1
    b .L113
.L110:
    str x1, [sp, #-16]!
    b .L112
.L111:
    str x3, [sp, #-16]!
.L112:
    ldr x0, [sp], #16
    cmp x0, x22
    csel x0, x22, x0, gt
.Lssa_http__parse_request_2155:
    cmp x0, x26
    b.ne .Lssa_http__parse_request_1992
.Lssa_http__parse_request_1993:
    mov x9, #-1
    mov x10, x9
    b .Lssa_http__parse_request_1985
.Lssa_http__parse_request_1992:
    mov x10, x0
    b .Lssa_http__parse_request_1985
.Lssa_http__parse_request_1990:
    add x26, x26, #1
.Lssa_http__parse_request_1989:
.Lssa_http__parse_request_2171:
    cmp x26, x22
    b.ge .Lssa_http__parse_request_1988
.Lssa_http__parse_request_2188:
    ldr x6, [x19]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x26
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_http__parse_request_1987
.Lssa_http__parse_request_2186:
    add x10, x26, #1
    cmp x9, #92
    csel x10, x10, x26, eq
.Lssa_http__parse_request_2183:
    cmp x10, x22
    b.ge .Lssa_http__parse_request_1986
.Lssa_http__parse_request_2182:
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
.Lssa_http__parse_request_2181:
    cmp x9, #9
    b.eq .Lssa_http__parse_request_2172
.Lssa_http__parse_request_2179:
    cmp x9, #32
    b.lo .Lssa_http__parse_request_1986
.Lssa_http__parse_request_2178:
    cmp x9, #127
    b.eq .Lssa_http__parse_request_1986
.Lssa_http__parse_request_2172:
    add x26, x10, #1
    cmp x26, x22
    b.lt .Lssa_http__parse_request_2188
.Lssa_http__parse_request_1988:
    mov x10, #-1
    b .Lssa_http__parse_request_1985
.Lssa_http__parse_request_1987:
    add x26, x26, #1
    mov x10, x26
    b .Lssa_http__parse_request_1985
.Lssa_http__parse_request_1986:
    mov x10, #-1
.Lssa_http__parse_request_1985:
    cmp x10, #0
    b.lt .Lssa_http__parse_request_1809
.Lssa_http__parse_request_1984:
    mov x9, x10
.Lssa_http__parse_request_1983:
    cmp x9, x22
    b.lt .Lssa_http__parse_request_2023
.Lssa_http__parse_request_1810:
    mov x11, #2
    b .Lssa_http__parse_request_1808
.Lssa_http__parse_request_1809:
    mov x11, #400
    mov x22, #0
    mov x24, #0
.Lssa_http__parse_request_1808:
    cmp x11, #2
    b.ne .Lssa_http__parse_request_91
.Lssa_http__parse_request_1806:
    add x22, x22, #2
    sxtw x22, w22
    sub x20, x22, x20
    sub x28, x28, x20
    sub x28, x28, #2
    sxtw x28, w28
    cmp x28, #0
    b.lt .Lssa_http__parse_request_90
.Lssa_http__parse_request_1804:
    cmp x24, #0
    b.eq .Lssa_http__parse_request_89
.Lssa_http__parse_request_1802:
    add x9, x22, x24
    sxtw x9, w9
.Lssa_http__parse_request_1801:
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http__parse_request_1797
.Lssa_http__parse_request_1800:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w14, [x5, #8]
    cmp x14, #13
    b.eq .Lssa_http__parse_request_1797
.Lssa_http__parse_request_1799:
    mov x9, #0
    b .Lssa_http__parse_request_1789
.Lssa_http__parse_request_1797:
    add x14, x9, #1
    sxtw x14, w14
    cmp x14, x10
    b.ge .Lssa_http__parse_request_1793
.Lssa_http__parse_request_1796:
    add w14, w9, #1
    ldr x6, [x19]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x14
    ldrb w15, [x5, #8]
    cmp x15, #10
    b.eq .Lssa_http__parse_request_1793
.Lssa_http__parse_request_1795:
    mov x9, #0
    b .Lssa_http__parse_request_1789
.Lssa_http__parse_request_1793:
    add x9, x9, #2
    sxtw x9, w9
    cmp x9, x10
    b.le .Lssa_http__parse_request_1790
.Lssa_http__parse_request_1792:
    mov x9, #1
    b .Lssa_http__parse_request_1789
.Lssa_http__parse_request_1790:
    mov x9, #2
.Lssa_http__parse_request_1789:
    cmp x9, #0
    b.eq .Lssa_http__parse_request_86
.Lssa_http__parse_request_1787:
    cmp x9, #1
    b.eq .Lssa_http__parse_request_85
.Lssa_http__parse_request_1785:
    mov x0, x27
    mov x1, x22
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush4643s
.Lssa_http__parse_request_apush4643o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush4643e
.Lssa_http__parse_request_apush4643s:
    str x11, [sp, #56]
    bl __fern_arr_push_owned
    ldr x11, [sp, #56]
.Lssa_http__parse_request_apush4643e:
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush4644s
.Lssa_http__parse_request_apush4644o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush4644e
.Lssa_http__parse_request_apush4644s:
    str x11, [sp, #56]
    bl __fern_arr_push_owned
    ldr x11, [sp, #56]
.Lssa_http__parse_request_apush4644e:
    mov x27, x0
    sub x25, x25, x24
    sxtw x25, w25
    add x24, x22, x24
    add x24, x24, #2
    sxtw x20, w24
    b .Lssa_http__parse_request_1843
.Lssa_http__parse_request_91:
    mov x22, x11
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    b .Lssa_http__parse_request_31
.Lssa_http__parse_request_90:
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x22, #431
    b .Lssa_http__parse_request_31
.Lssa_http__parse_request_89:
    add x28, x28, #2
.Lssa_http__parse_request_88:
    ldr x20, [x19, #0]
    adrp x4, .K1
    add x4, x4, :lo12:.K1
    str x4, [sp, #136]
    add x11, x22, x28
    sxtw x11, w11
    cmp x11, x20
    csel x25, x20, x11, gt
    b .Lssa_http__parse_request_83
.Lssa_http__parse_request_86:
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x22, #400
    b .Lssa_http__parse_request_31
.Lssa_http__parse_request_85:
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x22, #1
    b .Lssa_http__parse_request_31
.Lssa_http__parse_request_83:
    sub x9, x22, #2
    sxtw x9, w9
.Lssa_http__parse_request_82:
    mov x11, #13
    mov x2, x9
    mov x1, x11
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L114
    mov x2, #0
.L114:
    cmp x1, #255
    b.hi .L119
    cmp x2, x3
    b.ge .L119
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L116
.L115:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L121
    cmp x5, x8
    b.ls .L115
.L116:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L117
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L117
    sub x5, x5, #16
    b .L122
.L121:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L122
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L122:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L120
.L117:
    cmp x5, x6
    b.ge .L119
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L118
    add x5, x5, #1
    b .L117
.L118:
    sub x2, x5, x0
    b .L120
.L119:
    mov x2, #-1
.L120:
    mov x0, x2
.Lssa_http__parse_request_81:
    mov x26, x0
.Lssa_http__parse_request_2292:
    cmp x26, #0
    b.lt .Lssa_http__parse_request_80
.Lssa_http__parse_request_2298:
    add x11, x26, #3
    sxtw x11, w11
    cmp x11, x25
    b.ge .Lssa_http__parse_request_80
.Lssa_http__parse_request_2297:
    add w11, w26, #1
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.ne .Lssa_http__parse_request_2293
.Lssa_http__parse_request_2296:
    add w9, w26, #2
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w11, [x5, #8]
    cmp x11, #13
    b.ne .Lssa_http__parse_request_2293
.Lssa_http__parse_request_2295:
    add w11, w26, #3
    ldr x6, [x19]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x11
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_78
.Lssa_http__parse_request_2293:
    add x9, x26, #1
    sxtw x9, w9
    mov x11, #13
    mov x2, x9
    mov x1, x11
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L123
    mov x2, #0
.L123:
    cmp x1, #255
    b.hi .L128
    cmp x2, x3
    b.ge .L128
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L125
.L124:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L130
    cmp x5, x8
    b.ls .L124
.L125:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L126
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L126
    sub x5, x5, #16
    b .L131
.L130:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L131
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L131:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L129
.L126:
    cmp x5, x6
    b.ge .L128
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L127
    add x5, x5, #1
    b .L126
.L127:
    sub x2, x5, x0
    b .L129
.L128:
    mov x2, #-1
.L129:
    mov x26, x2
    cmp x26, #0
    b.ge .Lssa_http__parse_request_2298
.Lssa_http__parse_request_80:
    mov x11, #-1
    mov x26, x11
.Lssa_http__parse_request_79:
.Lssa_http__parse_request_78:
    cmp x26, #0
    csel x10, x26, x25, ge
.Lssa_http__parse_request_75:
    cmp x10, x22
    b.le .Lssa_http__parse_request_72
.Lssa_http__parse_request_74:
    mov x0, x19
    mov x9, x22
    bl __fn_http____crlf_terminated.r
    cbz x0, .Lssa_http__parse_request_69
.Lssa_http__parse_request_72:
    b .Lssa_http__parse_request_pool_2237
    .ltorg
.Lssa_http__parse_request_pool_2237:
    cmp x26, #0
    b.ge .Lssa_http__parse_request_65
.Lssa_http__parse_request_71:
    add x28, x22, x28
    sxtw x28, w28
    cmp x20, x28
    b.lt .Lssa_http__parse_request_67
.Lssa_http__parse_request_70:
    mov x9, #431
    b .Lssa_http__parse_request_32
.Lssa_http__parse_request_69:
    mov x9, #400
    b .Lssa_http__parse_request_32
.Lssa_http__parse_request_67:
    mov x9, #1
    b .Lssa_http__parse_request_32
.Lssa_http__parse_request_65:
    cmp x26, x22
    b.le .Lssa_http__parse_request_39
.Lssa_http__parse_request_64:
    adrp x20, .K1
    add x20, x20, :lo12:.K1
.Lssa_http__parse_request_63:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http__parse_request_62:
    mov x24, x22
    mov x22, x0
    mov x28, #1
    mov x25, #0
.Lssa_http__parse_request_2350:
    cmp x24, x26
    b.ge .Lssa_http__parse_request_61
.Lssa_http__parse_request_2405:
    adrp x10, .K3
    add x10, x10, :lo12:.K3
    mov x2, x10
    mov x1, x24
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L132
    mov x1, #0
.L132:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L135
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L133:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L134
    add x5, x5, #16
    cmp x5, x8
    b.ls .L133
    sub x1, x5, x0
    b .L135
.L134:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L136
.L135:
    add x10, x9, #96
.L139:
    cmp x1, x3
    b.ge .L137
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L136
    add x1, x1, #1
    b .L139
.L136:
    str x1, [sp, #-16]!
    b .L138
.L137:
    str x3, [sp, #-16]!
.L138:
    ldr x0, [sp], #16
    cmp x0, x26
    csel x10, x26, x0, gt
.Lssa_http__parse_request_2411:
    cmp x10, x24
    b.eq .Lssa_http__parse_request_2402
.Lssa_http__parse_request_2404:
    cmp x10, x26
    b.ge .Lssa_http__parse_request_2402
.Lssa_http__parse_request_2403:
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w11, [x5, #8]
    cmp x11, #58
    b.eq .Lssa_http__parse_request_2400
.Lssa_http__parse_request_2402:
    mov x11, #-1
    mov x10, x26
    b .Lssa_http__parse_request_2388
.Lssa_http__parse_request_2400:
    add x11, x10, #1
.Lssa_http__parse_request_2399:
    mov x9, #13
    str x10, [sp, #56]
    mov x2, x11
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L140
    mov x2, #0
.L140:
    cmp x1, #255
    b.hi .L145
    cmp x2, x3
    b.ge .L145
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L142
.L141:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L147
    cmp x5, x8
    b.ls .L141
.L142:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L143
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L143
    sub x5, x5, #16
    b .L148
.L147:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L148
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L148:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L146
.L143:
    cmp x5, x6
    b.ge .L145
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L144
    add x5, x5, #1
    b .L143
.L144:
    sub x2, x5, x0
    b .L146
.L145:
    mov x2, #-1
.L146:
    mov x0, x2
    ldr x10, [sp, #56]
    cmp x0, #0
    b.lt .Lssa_http__parse_request_2397
.Lssa_http__parse_request_2398:
    cmp x0, x26
    b.lt .Lssa_http__parse_request_2395
.Lssa_http__parse_request_2397:
    mov x0, x26
    b .Lssa_http__parse_request_2391
.Lssa_http__parse_request_2395:
    add x9, x0, #1
    cmp x9, x26
    b.ge .Lssa_http__parse_request_2393
.Lssa_http__parse_request_2394:
    add x9, x0, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w11, [x5, #8]
    cmp x11, #10
    b.eq .Lssa_http__parse_request_2391
.Lssa_http__parse_request_2393:
    mov x11, #-1
    mov x0, x11
.Lssa_http__parse_request_2392:
.Lssa_http__parse_request_2391:
    cmp x0, #0
    b.ge .Lssa_http__parse_request_2389
.Lssa_http__parse_request_2390:
    mov x11, #-1
    mov x10, x26
    b .Lssa_http__parse_request_2388
.Lssa_http__parse_request_2389:
    mov x11, x10
    mov x10, x0
.Lssa_http__parse_request_2388:
    cmp x11, #0
    b.ge .Lssa_http__parse_request_2386
.Lssa_http__parse_request_2457:
    str x10, [sp, #56]
    str x11, [sp, #48]
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    b .Lssa_http__parse_request_46
.Lssa_http__parse_request_2386:
    add x9, x25, #1
    sxtw x25, w9
    cmp x25, #100
    b.le .Lssa_http__parse_request_2384
.Lssa_http__parse_request_2461:
    str x10, [sp, #56]
    str x11, [sp, #48]
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    b .Lssa_http__parse_request_45
.Lssa_http__parse_request_2384:
    sub x9, x25, #1
    sxtw x15, w9
    cbz x28, .Lssa_http__parse_request_2377
.Lssa_http__parse_request_2383:
    ldr x9, [x20, #8]
    ldr x14, [x9, #0]
    cmp x15, x14
    b.lt .Lssa_http__parse_request_2377
.Lssa_http__parse_request_2382:
    cmp x15, #0
    b.le .Lssa_http__parse_request_2379
.Lssa_http__parse_request_2473:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_2381:
    tbnz x20, #0, .Lssa_http__parse_request_rcinc4865
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc4865
    ldur w5, [x20, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc4865
    add w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcinc4865:
    mov x0, x20
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    mov x0, x20
    mov x9, x15
    bl __fn_http____leading_fields.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
    mov x22, x0
.Lssa_http__parse_request_2380:
.Lssa_http__parse_request_2379:
    mov x28, #0
.Lssa_http__parse_request_2378:
.Lssa_http__parse_request_2377:
    mov x14, #-1
    cmp x28, #0
    csel x14, x15, x14, ne
.Lssa_http__parse_request_2374:
    add x9, x11, #1
    sxtw x9, w9
.Lssa_http__parse_request_2373:
.Lssa_http__parse_request_2484:
    cmp x9, x10
    b.ge .Lssa_http__parse_request_2371
.Lssa_http__parse_request_2491:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w8, [x5, #8]
.Lssa_http__parse_request_2490:
    cmp x8, #32
    b.eq .Lssa_http__parse_request_2485
.Lssa_http__parse_request_2488:
    cmp x8, #9
    b.ne .Lssa_http__parse_request_2371
.Lssa_http__parse_request_2485:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http__parse_request_2491
.Lssa_http__parse_request_2371:
    mov x8, x10
.Lssa_http__parse_request_2507:
    cmp x8, x9
    b.le .Lssa_http__parse_request_2370
.Lssa_http__parse_request_2514:
    sub x13, x8, #1
    ldr x6, [x19]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x13
    ldrb w12, [x5, #8]
.Lssa_http__parse_request_2513:
    cmp x12, #32
    b.eq .Lssa_http__parse_request_2508
.Lssa_http__parse_request_2511:
    cmp x12, #9
    b.ne .Lssa_http__parse_request_2370
.Lssa_http__parse_request_2508:
    sub x8, x8, #1
    cmp x8, x9
    b.gt .Lssa_http__parse_request_2514
.Lssa_http__parse_request_2370:
    cmp x14, #0
    b.lt .Lssa_http__parse_request_2365
.Lssa_http__parse_request_2369:
    ldr x12, [x20, #16]
    ldr x6, [x12]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x13, [x12, x5, lsl #3]
    ldr x12, [x13, #8]
    sub x13, x8, x9
    sxtw x13, w13
    cmp x12, x13
    b.ne .Lssa_http__parse_request_2365
.Lssa_http__parse_request_2368:
    ldr x12, [x20, #16]
    ldr x6, [x12]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x13, [x12, x5, lsl #3]
    ldr x2, [x13, #8]
    mov x1, #0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    mov x4, x2
    mov x3, x1
    mov x2, x13
    mov x1, x9
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L149_aop
    mov x1, #0
.L149_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L149_bop
    mov x3, #0
.L149_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L149_nok
    mov x4, #0
.L149_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L149_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L149_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L149_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L149_done
.L149_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L149_vec
.L149_short:
    cmp x10, #8
    b.lt .L149_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L149_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L149_eq
    add x8, x8, x14
.L149_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L149_done
.L149_w4:
    cmp x10, #4
    b.lt .L149_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L149_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L149_eq
    add x8, x8, x14
.L149_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L149_done
.L149_w2:
    cmp x10, #2
    b.lt .L149_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L149_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L149_eq
    add x8, x8, x14
.L149_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L149_done
.L149_tail:
    cmp x8, x13
    b.ge .L149_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L149_th
    add x8, x8, #1
    add x9, x9, #1
    b .L149_tail
.L149_th:
    sub x2, x8, x12
    b .L149_done
.L149_eq:
    mov x2, x4
.L149_done:
    mov x0, x2
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
    ldr x1, [x13, #8]
    cmp x0, x1
    b.ne .Lssa_http__parse_request_2365
.Lssa_http__parse_request_2367:
    ldr x6, [x12]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x1, [x12, x5, lsl #3]
    tbnz x1, #0, .Lssa_http__parse_request_rcinc4932
    cmp x1, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc4932
    ldur w5, [x1, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc4932
    add w5, w5, #1
    stur w5, [x1, #-8]
.Lssa_http__parse_request_rcinc4932:
    mov x0, x1
    mov x12, x1
    b .Lssa_http__parse_request_2361
.Lssa_http__parse_request_2365:
    adrp x1, .K6
    add x1, x1, :lo12:.K6
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x15, [sp, #32]
    str x8, [sp, #24]
    mov x2, x1
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L150
    mov x1, #0
.L150:
    adrp x9, .S9
    add x9, x9, :lo12:.S9
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L153
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L151:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L152
    add x5, x5, #16
    cmp x5, x8
    b.ls .L151
    sub x1, x5, x0
    b .L153
.L152:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L154
.L153:
    add x10, x9, #96
.L157:
    cmp x1, x3
    b.ge .L155
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L154
    add x1, x1, #1
    b .L157
.L154:
    str x1, [sp, #-16]!
    b .L156
.L155:
    str x3, [sp, #-16]!
.L156:
    ldr x0, [sp], #16
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x15, [sp, #32]
    ldr x8, [sp, #24]
    cmp x0, x8
    b.ge .Lssa_http__parse_request_2363
.Lssa_http__parse_request_2543:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x15, [sp, #32]
    str x8, [sp, #24]
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x15, [sp, #32]
    ldr x8, [sp, #24]
    b .Lssa_http__parse_request_35
.Lssa_http__parse_request_2363:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x15, [sp, #40]
    str x8, [sp, #-16]!
    str x9, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x12, x0
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_2547:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x12
    bl __fn_utf8__is_valid.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    cbnz x0, .Lssa_http__parse_request_2361
.Lssa_http__parse_request_2550:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    tbnz x12, #0, .Lssa_http__parse_request_rcdeck4947
    cmp x12, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4947
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4947
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4947
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    mov x0, x12
    bl __fn___fern_str_free.u
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    b .Lssa_http__parse_request_rcdece4947
.Lssa_http__parse_request_rcdecd4947:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_http__parse_request_rcdeck4947:
    mov x0, x12
.Lssa_http__parse_request_rcdece4947:
    b .Lssa_http__parse_request_35
.Lssa_http__parse_request_2362:
.Lssa_http__parse_request_2361:
    cbz x28, .Lssa_http__parse_request_2353
.Lssa_http__parse_request_2360:
    ldr x8, [x20, #8]
    ldr x6, [x8]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x15, #1
    ldr x9, [x8, x5, lsl #3]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x15, [sp, #24]
    mov x0, x19
    mov x10, x11
    mov x11, x9
    mov x9, x24
    bl __fn_http____shared_string.r
    mov x8, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x15, [sp, #24]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    str x8, [sp, #24]
    ldr x6, [x8, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn4966
    mov x0, x8
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd4966
.Lssa_http__parse_request_streqn4966:
    mov x0, #0
.Lssa_http__parse_request_streqd4966:
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    ldr x8, [sp, #24]
    cbz x0, .Lssa_http__parse_request_2358
.Lssa_http__parse_request_2359:
    ldr x9, [x20, #16]
    ldr x6, [x9]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x15, #1
    ldr x1, [x9, x5, lsl #3]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x15, [sp, #32]
    str x8, [sp, #24]
    ldr x6, [x12, #8]
    ldr x7, [x1, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn4969
    mov x0, x12
    mov x9, x1
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd4969
.Lssa_http__parse_request_streqn4969:
    mov x0, #0
.Lssa_http__parse_request_streqd4969:
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x15, [sp, #32]
    ldr x8, [sp, #24]
    mov x9, x0
    b .Lssa_http__parse_request_2357
.Lssa_http__parse_request_2358:
    mov x9, #0
.Lssa_http__parse_request_2357:
    cbz x9, .Lssa_http__parse_request_2563
.Lssa_http__parse_request_2562:
    tbnz x8, #0, .Lssa_http__parse_request_rcdeck4973
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4973
    ldur w5, [x8, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4973
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4973
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x8
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    b .Lssa_http__parse_request_rcdece4973
.Lssa_http__parse_request_rcdecd4973:
    sub w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_rcdeck4973:
    mov x0, x8
.Lssa_http__parse_request_rcdece4973:
    tbnz x12, #0, .Lssa_http__parse_request_rcdeck4974
    cmp x12, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4974
    ldur w5, [x12, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4974
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4974
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x12
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    b .Lssa_http__parse_request_rcdece4974
.Lssa_http__parse_request_rcdecd4974:
    sub w5, w5, #1
    stur w5, [x12, #-8]
.Lssa_http__parse_request_rcdeck4974:
    mov x0, x12
.Lssa_http__parse_request_rcdece4974:
    b .Lssa_http__parse_request_2354
.Lssa_http__parse_request_2563:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
    b .Lssa_http__parse_request_2355
.Lssa_http__parse_request_2356:
    b .Lssa_http__parse_request_2354
.Lssa_http__parse_request_2355:
    tbnz x20, #0, .Lssa_http__parse_request_rcinc4976
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc4976
    ldur w5, [x20, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc4976
    add w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_http__parse_request_rcinc4976:
    mov x0, x20
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x8, [sp, #24]
    mov x0, x20
    mov x9, x15
    bl __fn_http____leading_fields.r
    mov x14, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x8, [sp, #24]
    tst x14, #1
    b.ne .Lssa_http__parse_request_uq2355
    cmp x14, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq2355
    ldur w5, [x14, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq2355:
    b.ne .Lssa_http__parse_request_2568
.Lssa_http__parse_request_2567:
    mov x15, x14
    b .Lssa_http__parse_request_2569
.Lssa_http__parse_request_2568:
    mov x15, #0
.Lssa_http__parse_request_2569:
    ldr x13, [x14, #8]
    cmp x15, #0
    b.ne .Lssa_http__parse_request_2572
.Lssa_http__parse_request_2570:
    tbnz x13, #0, .Lssa_http__parse_request_rcinc4984
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc4984
    ldur w5, [x13, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc4984
    add w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_rcinc4984:
    mov x0, x13
.Lssa_http__parse_request_2572:
    tst x13, #1
    b.ne .Lssa_http__parse_request_uq2572
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq2572
    ldur w5, [x13, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq2572:
    b.ne .Lssa_http__parse_request_2574
.Lssa_http__parse_request_2573:
    mov x0, x13
    mov x1, x8
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush4986s
.Lssa_http__parse_request_apush4986o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush4986e
.Lssa_http__parse_request_apush4986s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
.Lssa_http__parse_request_apush4986e:
    mov x21, x0
    b .Lssa_http__parse_request_2575
.Lssa_http__parse_request_2574:
    mov x0, x13
    mov x1, x8
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush4987s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush4987o
    tbz w3, #31, .Lssa_http__parse_request_apush4987s
.Lssa_http__parse_request_apush4987o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush4987e
.Lssa_http__parse_request_apush4987s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
.Lssa_http__parse_request_apush4987e:
    mov x21, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    mov x0, x13
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4989
    ldur w5, [x13, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4989
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4989
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    mov x0, x13
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_rcdece4989
.Lssa_http__parse_request_rcdecd4989:
    sub w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_rcdeck4989:
    mov x0, x13
.Lssa_http__parse_request_rcdece4989:
.Lssa_http__parse_request_2575:
    ldr x13, [x14, #16]
    cmp x15, #0
    b.ne .Lssa_http__parse_request_2578
.Lssa_http__parse_request_2576:
    tbnz x13, #0, .Lssa_http__parse_request_rcinc4994
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc4994
    ldur w5, [x13, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc4994
    add w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_rcinc4994:
    mov x0, x13
.Lssa_http__parse_request_2578:
    tst x13, #1
    b.ne .Lssa_http__parse_request_uq2578
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq2578
    ldur w5, [x13, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq2578:
    b.ne .Lssa_http__parse_request_2580
.Lssa_http__parse_request_2579:
    mov x0, x13
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush4996s
.Lssa_http__parse_request_apush4996o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush4996e
.Lssa_http__parse_request_apush4996s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
.Lssa_http__parse_request_apush4996e:
    mov x8, x0
    b .Lssa_http__parse_request_2581
.Lssa_http__parse_request_2580:
    mov x0, x13
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush4997s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush4997o
    tbz w3, #31, .Lssa_http__parse_request_apush4997s
.Lssa_http__parse_request_apush4997o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush4997e
.Lssa_http__parse_request_apush4997s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
.Lssa_http__parse_request_apush4997e:
    mov x8, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    mov x0, x13
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck4999
    ldur w5, [x13, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd4999
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck4999
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x0, x13
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    b .Lssa_http__parse_request_rcdece4999
.Lssa_http__parse_request_rcdecd4999:
    sub w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_rcdeck4999:
    mov x0, x13
.Lssa_http__parse_request_rcdece4999:
.Lssa_http__parse_request_2581:
    cmp x15, #0
    b.ne .Lssa_http__parse_request_2583
.Lssa_http__parse_request_2582:
    mov x13, #3
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    str x15, [sp, #-16]!
    str x13, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    adrp x13, .S0
    add x13, x13, :lo12:.S0
    str x13, [x0, #0]
    mov x13, x0
    b .Lssa_http__parse_request_2584
.Lssa_http__parse_request_2583:
    mov x13, x15
.Lssa_http__parse_request_2584:
    cmp x15, #0
    b.ne .Lssa_http__parse_request_2587
.Lssa_http__parse_request_2586:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x8, [sp, #16]
    mov x0, x14
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x8, [sp, #16]
.Lssa_http__parse_request_2587:
    str x21, [x13, #8]
    str x8, [x13, #16]
    mov x22, x13
.Lssa_http__parse_request_2354:
    mov x28, x9
    b .Lssa_http__parse_request_2351
.Lssa_http__parse_request_2353:
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x11, [sp, #-16]!
    str x24, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x9, x0
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
.Lssa_http__parse_request_2589:
    tst x22, #1
    b.ne .Lssa_http__parse_request_uq2589
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq2589
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq2589:
    b.ne .Lssa_http__parse_request_2592
.Lssa_http__parse_request_2591:
    mov x24, x22
    b .Lssa_http__parse_request_2593
.Lssa_http__parse_request_2592:
    mov x24, #0
.Lssa_http__parse_request_2593:
    ldr x21, [x22, #8]
    cmp x24, #0
    b.ne .Lssa_http__parse_request_2596
.Lssa_http__parse_request_2594:
    tbnz x21, #0, .Lssa_http__parse_request_rcinc5030
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc5030
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc5030
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_rcinc5030:
    mov x0, x21
.Lssa_http__parse_request_2596:
    tst x21, #1
    b.ne .Lssa_http__parse_request_uq2596
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq2596
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq2596:
    b.ne .Lssa_http__parse_request_2598
.Lssa_http__parse_request_2597:
    mov x0, x21
    mov x1, x9
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush5032s
.Lssa_http__parse_request_apush5032o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush5032e
.Lssa_http__parse_request_apush5032s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
.Lssa_http__parse_request_apush5032e:
    mov x21, x0
    b .Lssa_http__parse_request_2599
.Lssa_http__parse_request_2598:
    mov x0, x21
    mov x1, x9
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush5033s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush5033o
    tbz w3, #31, .Lssa_http__parse_request_apush5033s
.Lssa_http__parse_request_apush5033o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush5033e
.Lssa_http__parse_request_apush5033s:
    str x10, [sp, #56]
    str x12, [sp, #48]
    bl __fern_arr_push
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
.Lssa_http__parse_request_apush5033e:
    mov x11, x0
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    mov x0, x21
    bl __fn___fern_arr_inc_elems.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5035
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5035
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5035
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    mov x0, x21
    bl __fn___fern_arr_dec.u
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    b .Lssa_http__parse_request_rcdece5035
.Lssa_http__parse_request_rcdecd5035:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_rcdeck5035:
    mov x0, x21
.Lssa_http__parse_request_rcdece5035:
    mov x21, x11
.Lssa_http__parse_request_2599:
    ldr x11, [x22, #16]
    cmp x24, #0
    b.ne .Lssa_http__parse_request_2602
.Lssa_http__parse_request_2600:
    tbnz x11, #0, .Lssa_http__parse_request_rcinc5040
    cmp x11, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcinc5040
    ldur w5, [x11, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_rcinc5040
    add w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_http__parse_request_rcinc5040:
    mov x0, x11
.Lssa_http__parse_request_2602:
    tst x11, #1
    b.ne .Lssa_http__parse_request_uq2602
    cmp x11, #16, lsl #12
    b.lo .Lssa_http__parse_request_uq2602
    ldur w5, [x11, #-8]
    cmp w5, #1
.Lssa_http__parse_request_uq2602:
    b.ne .Lssa_http__parse_request_2604
.Lssa_http__parse_request_2603:
    mov x0, x11
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush5042s
.Lssa_http__parse_request_apush5042o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush5042e
.Lssa_http__parse_request_apush5042s:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
.Lssa_http__parse_request_apush5042e:
    mov x9, x0
    b .Lssa_http__parse_request_2605
.Lssa_http__parse_request_2604:
    mov x0, x11
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_apush5043s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_apush5043o
    tbz w3, #31, .Lssa_http__parse_request_apush5043s
.Lssa_http__parse_request_apush5043o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_apush5043e
.Lssa_http__parse_request_apush5043s:
    str x10, [sp, #56]
    str x11, [sp, #48]
    bl __fern_arr_push
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
.Lssa_http__parse_request_apush5043e:
    mov x9, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    mov x0, x11
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    cmp x11, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5045
    ldur w5, [x11, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5045
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5045
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x11
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_rcdece5045
.Lssa_http__parse_request_rcdecd5045:
    sub w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_http__parse_request_rcdeck5045:
    mov x0, x11
.Lssa_http__parse_request_rcdece5045:
.Lssa_http__parse_request_2605:
    cmp x24, #0
    b.ne .Lssa_http__parse_request_2607
.Lssa_http__parse_request_2606:
    mov x11, #3
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x24, [sp, #-16]!
    str x11, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    adrp x11, .S0
    add x11, x11, :lo12:.S0
    str x11, [x0, #0]
    mov x12, x0
    b .Lssa_http__parse_request_2608
.Lssa_http__parse_request_2607:
    mov x12, x24
.Lssa_http__parse_request_2608:
    cmp x24, #0
    b.ne .Lssa_http__parse_request_2611
.Lssa_http__parse_request_2610:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
.Lssa_http__parse_request_2611:
    str x21, [x12, #8]
    str x9, [x12, #16]
    mov x22, x12
.Lssa_http__parse_request_2352:
.Lssa_http__parse_request_2351:
    add x10, x10, #2
    sxtw x24, w10
    cmp x24, x26
    b.lt .Lssa_http__parse_request_2405
.Lssa_http__parse_request_61:
    cbz x28, .Lssa_http__parse_request_43
.Lssa_http__parse_request_60:
    ldr x10, [x20, #8]
    ldr x11, [x10, #0]
    cmp x25, x11
    b.ne .Lssa_http__parse_request_43
.Lssa_http__parse_request_2618:
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_59:
    mov x22, x20
    b .Lssa_http__parse_request_40
.Lssa_http__parse_request_58:
    b .Lssa_http__parse_request_39
.Lssa_http__parse_request_54:
    mov x11, #400
.Lssa_http__parse_request_53:
.Lssa_http__parse_request_52:
.Lssa_http__parse_request_50:
    cmp x11, #1
    b.ne .Lssa_http__parse_request_48
.Lssa_http__parse_request_49:
    mov x10, #1
    mov x11, #0
    mov x12, #0
    mov x9, #0
    mov x0, #0
    b .Lssa_http__parse_request_47
.Lssa_http__parse_request_48:
    mov x12, x11
    mov x10, #0
    mov x11, #0
    mov x9, #0
    mov x0, #0
.Lssa_http__parse_request_47:
    mov x22, x10
    mov x23, x11
    mov x27, x12
    mov x11, x9
    mov x20, x0
    b .Lssa_http__parse_request_10
.Lssa_http__parse_request_46:
    mov x9, #400
    b .Lssa_http__parse_request_32
.Lssa_http__parse_request_45:
    mov x9, #431
    b .Lssa_http__parse_request_32
.Lssa_http__parse_request_43:
    cbz x28, .Lssa_http__parse_request_40
.Lssa_http__parse_request_2633:
    mov x0, x22
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_42:
    mov x0, x20
    mov x9, x25
    bl __fn_http____leading_fields.r
    mov x22, x0
.Lssa_http__parse_request_41:
.Lssa_http__parse_request_40:
    str x22, [sp, #136]
.Lssa_http__parse_request_39:
    mov x9, #2
    b .Lssa_http__parse_request_32
.Lssa_http__parse_request_35:
    mov x9, #400
.Lssa_http__parse_request_34:
.Lssa_http__parse_request_33:
.Lssa_http__parse_request_32:
    mov x22, x9
.Lssa_http__parse_request_31:
    cmp x22, #2
    b.eq .Lssa_http__parse_request_28
.Lssa_http__parse_request_2640:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5134
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5134
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5134
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece5134
.Lssa_http__parse_request_rcdecd5134:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck5134:
    mov x0, x19
.Lssa_http__parse_request_rcdece5134:
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5135
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5135
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5135
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece5135
.Lssa_http__parse_request_rcdecd5135:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_rcdeck5135:
    mov x0, x27
.Lssa_http__parse_request_rcdece5135:
    ldr x0, [sp, #136]
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_30:
    ldr x25, [sp, #120]
    ldr x5, [sp, #112]
    str x5, [sp, #136]
    b .Lssa_http__parse_request_22
.Lssa_http__parse_request_28:
.Lssa_http__parse_request_27:
.Lssa_http__parse_request_26:
    mov x9, #0
    mov x12, #1
.Lssa_http__parse_request_2645:
    ldr x11, [x27, #0]
    cmp x12, x11
    b.ge .Lssa_http__parse_request_25
.Lssa_http__parse_request_2646:
    add x5, x12, #1
    ldr x11, [x27, x5, lsl #3]
    add x11, x9, x11
    sxtw x9, w11
    add x12, x12, #2
    sxtw x12, w12
    b .Lssa_http__parse_request_2645
.Lssa_http__parse_request_25:
    mov x0, x9
    bl __fern_alloc_bytes
.Lssa_http__parse_request_24:
    mov x25, x0
    mov x22, #0
    mov x20, #0
.Lssa_http__parse_request_2653:
    add x9, x22, #1
    sxtw x9, w9
    ldr x12, [x27, #0]
    cmp x9, x12
    b.lt .Lssa_http__parse_request_2654
.Lssa_http__parse_request_2656:
    cmp x19, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5178
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5178
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5178
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece5178
.Lssa_http__parse_request_rcdecd5178:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_http__parse_request_rcdeck5178:
    mov x0, x19
.Lssa_http__parse_request_rcdece5178:
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5179
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5179
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5179
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece5179
.Lssa_http__parse_request_rcdecd5179:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_rcdeck5179:
    mov x0, x27
.Lssa_http__parse_request_rcdece5179:
    b .Lssa_http__parse_request_23
.Lssa_http__parse_request_2654:
    add x9, x22, #1
    sxtw x28, w9
    asr x9, x22, #31
    orr x9, x28, x9
    ldr x6, [x27]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    ldr x12, [x27, x5, lsl #3]
    add x5, x28, #1
    ldr x9, [x27, x5, lsl #3]
    str x25, [sp, #-16]!
    str x20, [sp, #-16]!
    str x19, [sp, #-16]!
    str x12, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_bytes_into
    add sp, sp, #80
    mov x25, x0
    ldr x6, [x27]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x9, [x27, x5, lsl #3]
    add x20, x20, x9
    sxtw x20, w20
    add x22, x22, #2
    sxtw x22, w22
    b .Lssa_http__parse_request_2653
.Lssa_http__parse_request_23:
    mov x22, #2
.Lssa_http__parse_request_22:
    cmp x22, #2
    b.eq .Lssa_http__parse_request_17
.Lssa_http__parse_request_2661:
    ldr x4, [sp, #64]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck5211
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5211
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5211
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5211
    ldr x0, [sp, #64]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece5211
.Lssa_http__parse_request_rcdecd5211:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck5211:
    mov x0, x4
.Lssa_http__parse_request_rcdece5211:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_rcdeck5212
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5212
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5212
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5212
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_rcdece5212
.Lssa_http__parse_request_rcdecd5212:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_rcdeck5212:
    mov x0, x4
.Lssa_http__parse_request_rcdece5212:
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_rcdeck5213
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_rcdecd5213
    tbnz w5, #31, .Lssa_http__parse_request_rcdeck5213
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_rcdece5213
.Lssa_http__parse_request_rcdecd5213:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_rcdeck5213:
    mov x0, x25
.Lssa_http__parse_request_rcdece5213:
    ldr x0, [sp, #136]
    bl __fn___sem_release_HeaderMap.r
    mov x0, x23
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_20:
    cmp x22, #400
    b.lt .Lssa_http__parse_request_15
.Lssa_http__parse_request_19:
    mov x9, #0
    mov x12, #0
    mov x11, #0
    mov x0, #0
    b .Lssa_http__parse_request_11
.Lssa_http__parse_request_17:
    adrp x22, .K7
    add x22, x22, :lo12:.K7
    mov x20, #0
    mov x0, #4
    bl __fern_arr_box
    mov x27, x0
    b .Lssa_http__parse_request_pool_2694
    .ltorg
.Lssa_http__parse_request_pool_2694:
    adrp x9, .S22
    add x9, x9, :lo12:.S22
    str x9, [x27, #0]
    str x25, [x27, #8]
    str x20, [x27, #16]
    str x22, [x27, #24]
    mov x0, #6
    bl __fern_arr_box
    adrp x12, .S23
    add x12, x12, :lo12:.S23
    str x12, [x0, #0]
    ldr x5, [sp, #64]
    str x5, [x0, #8]
    ldr x5, [sp, #96]
    str x5, [x0, #16]
    str x27, [x0, #24]
    str x23, [x0, #32]
    ldr x5, [sp, #136]
    str x5, [x0, #40]
    mov x20, x0
    mov x22, #0
    mov x23, #0
    mov x27, #0
    mov x11, #1
    b .Lssa_http__parse_request_10
.Lssa_http__parse_request_15:
    adrp x9, .SB10
    add x9, x9, :lo12:.SB10
    ldr x4, [sp, #80]
    ldr x12, [x4, #8]
    cmp x12, #8
    b.ne .Lssa_http__parse_request_2672
.Lssa_http__parse_request_2671:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_streqn5239
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_streqn5239
    ldr x0, [sp, #80]
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_streqd5239
.Lssa_http__parse_request_streqn5239:
    mov x0, #0
.Lssa_http__parse_request_streqd5239:
    b .Lssa_http__parse_request_2673
.Lssa_http__parse_request_2672:
    mov x0, #0
.Lssa_http__parse_request_2673:
    cbnz x0, .Lssa_http__parse_request_12
.Lssa_http__parse_request_14:
    ldr x4, [sp, #72]
    cmp x4, #1
    b.ne .Lssa_http__parse_request_12
.Lssa_http__parse_request_13:
    mov x9, #0
    mov x12, #1
    mov x22, #0
    mov x11, #0
    mov x0, #0
    b .Lssa_http__parse_request_11
.Lssa_http__parse_request_12:
    mov x9, #1
    mov x12, #0
    mov x22, #0
    mov x11, #0
    mov x0, #0
.Lssa_http__parse_request_11:
    mov x23, x12
    mov x27, x22
    mov x20, x0
    mov x22, x9
.Lssa_http__parse_request_10:
    cbnz x11, .Lssa_http__parse_request_8
.Lssa_http__parse_request_2684:
    mov x0, x20
    bl __fn___sem_release_HttpRequest.r
    b .Lssa_http__parse_request_7
.Lssa_http__parse_request_8:
    mov x1, x20
    mov x0, x1
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_7:
    cbz x22, .Lssa_http__parse_request_5
.Lssa_http__parse_request_6:
    adrp x11, .K8
    add x11, x11, :lo12:.K8
    mov x0, x11
    b .Lssa_http__parse_request_1
.Lssa_http__parse_request_5:
    cbz x23, .Lssa_http__parse_request_2
.Lssa_http__parse_request_4:
    adrp x11, .K9
    add x11, x11, :lo12:.K9
    mov x0, x11
    b .Lssa_http__parse_request_1
.Lssa_http__parse_request_2:
    mov x0, #2
    bl __fern_arr_box
    adrp x11, .S26
    add x11, x11, :lo12:.S26
    str x11, [x0, #0]
    str x27, [x0, #8]
.Lssa_http__parse_request_1:
    mov x1, x0
    mov x12, x1
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____lists_token:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____lists_token.k:
__fn_http____lists_token.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____lists_token_0:
    ldr x21, [x19, #8]
.Lssa_http____lists_token_3:
    mov x9, #0
.Lssa_http____lists_token_4:
    cmp x9, x21
    b.gt .Lssa_http____lists_token_2
.Lssa_http____lists_token_8:
    mov x22, x9
.Lssa_http____lists_token_14:
    cmp x22, x21
    b.ge .Lssa_http____lists_token_7
.Lssa_http____lists_token_16:
    ldr x6, [x19, #8]
    cmp x22, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x22]
    cmp x10, #44
    b.eq .Lssa_http____lists_token_7
.Lssa_http____lists_token_15:
    add x22, x22, #1
    cmp x22, x21
    b.lt .Lssa_http____lists_token_16
.Lssa_http____lists_token_7:
    mov x0, x19
    mov x10, x22
    mov x11, x20
    bl __fn_http____token_at.r
    cbnz x0, .Lssa_http____lists_token_1
.Lssa_http____lists_token_5:
    add x22, x22, #1
    sxtw x9, w22
    cmp x9, x21
    b.le .Lssa_http____lists_token_8
.Lssa_http____lists_token_2:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____lists_token_1:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_fnv_str_seeded:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_fnv_str_seeded.k:
__fn___map_fnv_str_seeded.r:
.Lssa___map_fnv_str_seeded_0:
    ldr x10, =2166136261
    mov w9, w9
    eor x10, x10, x9
    ldr x9, =16777619
    ldr x11, [x0, #8]
.Lssa___map_fnv_str_seeded_4:
    mov x12, #0
.Lssa___map_fnv_str_seeded_5:
    add x13, x12, #4
    sxtw x13, w13
    cmp x13, x11
    b.gt .Lssa___map_fnv_str_seeded_13
.Lssa___map_fnv_str_seeded_6:
    add x13, x12, #3
    sxtw x13, w13
    asr x14, x12, #31
    orr x13, x13, x14
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x14, [x0, #0]
    add x14, x14, x12
    ldrsw x14, [x14]
    eor x14, x10, x14
    ldr x13, =16777619
    mul w10, w14, w13
    add x14, x12, #4
    sxtw x12, w14
    b .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmp x12, x11
    b.ge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
    eor x14, x10, x14
    mul w10, w14, w9
    add x12, x12, #1
    cmp x12, x11
    b.lt .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    lsr x12, x10, #16
    eor x10, x10, x12
    ldr x12, =2246822507
    mul w10, w10, w12
    lsr x12, x10, #13
    eor x10, x10, x12
    ldr x12, =3266489909
    mul w10, w10, w12
    lsr x12, x10, #16
    eor x10, x10, x12
    sxtw x0, w10
    ret
    .cfi_endproc
    .ltorg
__fn_string____str_maxsuf:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_maxsuf.k:
__fn_string____str_maxsuf.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_string____str_maxsuf_0:
    mov x13, #-1
.Lssa_string____str_maxsuf_2:
    mov x19, x13
    mov x13, #0
    mov x14, #1
    mov x15, #1
.Lssa_string____str_maxsuf_3:
    add x1, x13, x14
    sxtw x1, w1
    cmp x1, x9
    b.ge .Lssa_string____str_maxsuf_1
.Lssa_string____str_maxsuf_16:
    add x1, x13, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w2, [x6, x1]
    add x1, x19, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w3, [x6, x1]
    cmp x10, #0
    csel x1, x3, x2, ne
    cmp x10, #0
    csel x2, x2, x3, ne
.Lssa_string____str_maxsuf_13:
    cmp x1, x2
    b.ge .Lssa_string____str_maxsuf_11
.Lssa_string____str_maxsuf_12:
    add x3, x13, x14
    sxtw x3, w3
    sub x8, x3, x19
    sxtw x8, w8
    mov x13, x3
    mov x15, x8
    mov x14, #1
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_11:
    cmp x1, x2
    b.ne .Lssa_string____str_maxsuf_6
.Lssa_string____str_maxsuf_10:
    cmp x14, x15
    b.ne .Lssa_string____str_maxsuf_8
.Lssa_string____str_maxsuf_9:
    add x1, x13, x15
    sxtw x1, w1
    mov x13, x1
    mov x14, #1
    b .Lssa_string____str_maxsuf_7
.Lssa_string____str_maxsuf_8:
    add x14, x14, #1
    sxtw x14, w14
.Lssa_string____str_maxsuf_7:
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_string____str_maxsuf_5
.Lssa_string____str_maxsuf_6:
    add x14, x13, #1
    sxtw x14, w14
    mov x19, x13
    mov x13, #1
    mov x15, #1
.Lssa_string____str_maxsuf_5:
    mov x4, x14
    mov x14, x13
    mov x13, x4
.Lssa_string____str_maxsuf_4:
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_1:
    mov x1, x15
    mov x0, x1
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string____str_find_from:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_find_from.k:
__fn_string____str_find_from.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
.Lssa_string____str_find_from_0:
    mov x9, #0
    cmp x12, #0
    csel x23, x9, x12, lt
.Lssa_string____str_find_from_47:
    cmp x22, #0
    b.ne .Lssa_string____str_find_from_41
.Lssa_string____str_find_from_46:
    cmp x23, x20
    csel x0, x20, x23, gt
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_41:
    sub x10, x20, x23
    sxtw x10, w10
    cmp x22, x10
    b.le .Lssa_string____str_find_from_38
.Lssa_string____str_find_from_40:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_38:
    cmp x22, #1
    b.ne .Lssa_string____str_find_from_35
.Lssa_string____str_find_from_37:
    ldr x6, [x21, #8]
    cmp x6, #0
    b.hi 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w10, [x6, #0]
    mov x2, x23
    mov x1, x10
    mov x0, x19
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L158
    mov x2, #0
.L158:
    cmp x1, #255
    b.hi .L163
    cmp x2, x3
    b.ge .L163
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L160
.L159:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L165
    cmp x5, x8
    b.ls .L159
.L160:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L161
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L161
    sub x5, x5, #16
    b .L166
.L165:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L166
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L166:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L164
.L161:
    cmp x5, x6
    b.ge .L163
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L162
    add x5, x5, #1
    b .L161
.L162:
    sub x2, x5, x0
    b .L164
.L163:
    mov x2, #-1
.L164:
    mov x0, x2
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_35:
    cmp x22, #4
    b.gt .Lssa_string____str_find_from_30
.Lssa_string____str_find_from_33:
    sub x10, x20, x22
    sxtw x10, w10
.Lssa_string____str_find_from_75:
    cmp x23, x10
    b.gt .Lssa_string____str_find_from_32
.Lssa_string____str_find_from_80:
.Lssa_string____str_find_from_79:
    mov x9, #0
.Lssa_string____str_find_from_85:
    cmp x9, x22
    b.ge .Lssa_string____str_find_from_78
.Lssa_string____str_find_from_87:
    add w12, w23, w9
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w11, [x6, x12]
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w12, [x6, x9]
    cmp x11, x12
    b.ne .Lssa_string____str_find_from_78
.Lssa_string____str_find_from_86:
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_string____str_find_from_87
.Lssa_string____str_find_from_78:
    cmp x9, x22
    b.eq .Lssa_string____str_find_from_26
.Lssa_string____str_find_from_76:
    add x9, x23, #1
    sxtw x23, w9
    cmp x23, x10
    b.le .Lssa_string____str_find_from_80
.Lssa_string____str_find_from_32:
    mov x0, #-1
    b .Lssa_string____str_find_from_25
.Lssa_string____str_find_from_30:
    mov x24, #0
    mov x25, #1
.Lssa_string____str_find_from_28:
    cmp x22, #3
    b.ge .Lssa_string____str_find_from_23
.Lssa_string____str_find_from_27:
    sub x9, x22, #1
    mov x28, x9
    mov x0, #1
    b .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_26:
    mov x0, x23
.Lssa_string____str_find_from_25:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_23:
    mov x10, #0
    mov x0, x21
    mov x9, x22
    mov x11, x24
    mov x12, x25
    bl __fn_string____str_maxsuf.r
    mov x26, x0
    mov x27, x1
    mov x10, #1
    mov x0, x21
    mov x9, x22
    mov x11, x24
    mov x12, x25
    bl __fn_string____str_maxsuf.r
    mov x28, x0
    mov x0, x1
    cmp x28, x26
    b.ge .Lssa_string____str_find_from_20
.Lssa_string____str_find_from_22:
    add x26, x26, #1
    sxtw x26, w26
    mov x28, x26
    mov x0, x27
    b .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_20:
    add x28, x28, #1
    sxtw x28, w28
.Lssa_string____str_find_from_19:
    sub x20, x20, x22
    sxtw x20, w20
.Lssa_string____str_find_from_18:
.Lssa_string____str_find_from_17:
    mov x10, #0
.Lssa_string____str_find_from_115:
    cmp x10, x28
    b.ge .Lssa_string____str_find_from_13
.Lssa_string____str_find_from_118:
    add w9, w0, w10
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w11, [x6, x9]
    mov w9, w10
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w12, [x6, x9]
    cmp x11, x12
    b.ne .Lssa_string____str_find_from_8
.Lssa_string____str_find_from_116:
    add x10, x10, #1
    cmp x10, x28
    b.lt .Lssa_string____str_find_from_118
.Lssa_string____str_find_from_13:
.Lssa_string____str_find_from_12:
    sub x10, x22, x0
    sxtw x10, w10
    mov x11, #0
.Lssa_string____str_find_from_134:
    cmp x23, x20
    b.gt .Lssa_string____str_find_from_11
.Lssa_string____str_find_from_147:
    cmp x11, x28
    csel x9, x11, x28, gt
.Lssa_string____str_find_from_144:
.Lssa_string____str_find_from_143:
.Lssa_string____str_find_from_157:
    cmp x9, x22
    b.ge .Lssa_string____str_find_from_142
.Lssa_string____str_find_from_159:
    mov w12, w9
    ldr x6, [x21, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w13, [x6, x12]
    add w12, w9, w23
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w14, [x6, x12]
    cmp x13, x14
    b.ne .Lssa_string____str_find_from_142
.Lssa_string____str_find_from_158:
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_string____str_find_from_159
.Lssa_string____str_find_from_142:
    cmp x9, x22
    b.lt .Lssa_string____str_find_from_136
.Lssa_string____str_find_from_141:
    sub x13, x28, #1
    sxtw x13, w13
.Lssa_string____str_find_from_140:
.Lssa_string____str_find_from_174:
    cmp x13, x11
    b.lt .Lssa_string____str_find_from_139
.Lssa_string____str_find_from_176:
    ldr x6, [x21, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w14, [x6, x13]
    add w12, w13, w23
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x12]
    cmp x14, x15
    b.ne .Lssa_string____str_find_from_139
.Lssa_string____str_find_from_175:
    sub x14, x13, #1
    sxtw x13, w14
    cmp x13, x11
    b.ge .Lssa_string____str_find_from_176
.Lssa_string____str_find_from_139:
    cmp x13, x11
    b.lt .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_137:
    add x13, x23, x0
    sxtw x13, w13
    mov x23, x13
    mov x11, x10
    b .Lssa_string____str_find_from_134
.Lssa_string____str_find_from_136:
    sub x9, x9, x28
    add x9, x23, x9
    add x9, x9, #1
    sxtw x9, w9
    mov x23, x9
    mov x11, #0
.Lssa_string____str_find_from_135:
    cmp x23, x20
    b.le .Lssa_string____str_find_from_147
.Lssa_string____str_find_from_11:
    mov x0, #-1
    mov x23, x0
.Lssa_string____str_find_from_10:
    b .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_8:
    sub x11, x22, x28
    sxtw x11, w11
    sub x10, x22, x28
    cmp x11, x28
    csel x10, x10, x28, gt
.Lssa_string____str_find_from_5:
    add x10, x10, #1
.Lssa_string____str_find_from_4:
.Lssa_string____str_find_from_201:
    cmp x23, x20
    b.gt .Lssa_string____str_find_from_3
.Lssa_string____str_find_from_210:
    mov x11, x28
.Lssa_string____str_find_from_216:
    cmp x11, x22
    b.ge .Lssa_string____str_find_from_209
.Lssa_string____str_find_from_218:
    mov w9, w11
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w13, [x6, x9]
    add w9, w11, w23
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w14, [x6, x9]
    cmp x13, x14
    b.ne .Lssa_string____str_find_from_209
.Lssa_string____str_find_from_217:
    add x11, x11, #1
    cmp x11, x22
    b.lt .Lssa_string____str_find_from_218
.Lssa_string____str_find_from_209:
    cmp x11, x22
    b.lt .Lssa_string____str_find_from_203
.Lssa_string____str_find_from_208:
    sub x13, x28, #1
    sxtw x13, w13
.Lssa_string____str_find_from_207:
.Lssa_string____str_find_from_233:
    cmp x13, #0
    b.lt .Lssa_string____str_find_from_206
.Lssa_string____str_find_from_235:
    ldr x6, [x21, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w14, [x6, x13]
    add w9, w13, w23
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x9]
    cmp x14, x15
    b.ne .Lssa_string____str_find_from_206
.Lssa_string____str_find_from_234:
    sub x14, x13, #1
    sxtw x13, w14
    cmp x13, #0
    b.ge .Lssa_string____str_find_from_235
.Lssa_string____str_find_from_206:
    cmp x13, #0
    b.lt .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_204:
    add x13, x23, x10
    sxtw x13, w13
    mov x23, x13
    b .Lssa_string____str_find_from_201
.Lssa_string____str_find_from_203:
    sub x11, x11, x28
    add x11, x23, x11
    add x11, x11, #1
    sxtw x11, w11
    mov x23, x11
.Lssa_string____str_find_from_202:
    cmp x23, x20
    b.le .Lssa_string____str_find_from_210
.Lssa_string____str_find_from_3:
    mov x0, #-1
    mov x23, x0
.Lssa_string____str_find_from_2:
.Lssa_string____str_find_from_1:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__split.k:
__fn_string__split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #80
    mov x19, x0
    mov x20, x9
.Lssa_string__split_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    adrp x23, .K0
    add x23, x23, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa_string__split_3
.Lssa_string__split_8:
    ldr x24, [x19, #8]
    adrp x0, .K0
    add x0, x0, :lo12:.K0
.Lssa_string__split_7:
    mov x25, x0
    mov x26, #0
.Lssa_string__split_14:
    cmp x26, x24
    b.ge .Lssa_string__split_5
.Lssa_string__split_15:
    mov x0, x19
    mov x9, x26
    mov x10, x24
    bl __fn_utf8_scalar__step.r
    add x0, x26, x0
    sxtw x27, w0
    mov x0, x19
    mov x1, x26
    mov x2, x27
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x28, x0
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    str x9, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x26, x0
    str x28, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x25
    mov x1, x26
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush73s
.Lssa_string__split_apush73o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush73e
.Lssa_string__split_apush73s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush73e:
    mov x25, x0
    mov x26, x27
    cmp x26, x24
    b.lt .Lssa_string__split_15
.Lssa_string__split_5:
    mov x0, x25
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string__split_3:
    mov x12, #0
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    bl __fn_string____str_find_from.r
.Lssa_string__split_2:
    mov x26, x0
    mov x25, #0
.Lssa_string__split_22:
    cmp x26, #0
    b.lt .Lssa_string__split_1
.Lssa_string__split_23:
    mov x0, x19
    mov x1, x25
    mov x2, x26
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x27, x0
    adrp x12, .SB4
    add x12, x12, :lo12:.SB4
    str x12, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x24, x0
    str x27, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush94s
.Lssa_string__split_apush94o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush94e
.Lssa_string__split_apush94s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush94e:
    mov x23, x0
    add x26, x26, x22
    sxtw x25, w26
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    mov x12, x25
    bl __fn_string____str_find_from.r
    mov x26, x0
    cmp x26, #0
    b.ge .Lssa_string__split_23
.Lssa_string__split_1:
    mov x0, x19
    mov x1, x25
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x12, .SB4
    add x12, x12, :lo12:.SB4
    str x12, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x25, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x25
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush102s
.Lssa_string__split_apush102o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush102e
.Lssa_string__split_apush102s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush102e:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__eq_ignore_ascii_case:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__eq_ignore_ascii_case.k:
__fn_string__eq_ignore_ascii_case.r:
.Lssa_string__eq_ignore_ascii_case_0:
    ldr x10, [x0, #8]
    ldr x11, [x9, #8]
    cmp x10, x11
    b.eq .Lssa_string__eq_ignore_ascii_case_5
.Lssa_string__eq_ignore_ascii_case_7:
    mov x0, #0
    ret
.Lssa_string__eq_ignore_ascii_case_5:
    mov x11, #-1
.Lssa_string__eq_ignore_ascii_case_4:
.Lssa_string__eq_ignore_ascii_case_12:
.Lssa_string__eq_ignore_ascii_case_19:
    add x11, x11, #1
    sxtw x11, w11
    cmp x11, x10
    b.ge .Lssa_string__eq_ignore_ascii_case_2
.Lssa_string__eq_ignore_ascii_case_17:
    ldr x12, [x0, #0]
    ldrb w13, [x12, x11]
    ldr x6, [x9, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x9]
    ldrb w12, [x6, x11]
    eor x12, x13, x12
    cmp x12, #0
    b.eq .Lssa_string__eq_ignore_ascii_case_19
.Lssa_string__eq_ignore_ascii_case_16:
    cmp x12, #32
    b.ne .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_15:
    mov x12, #32
    orr x12, x13, x12
    cmp x12, #97
    b.lt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_14:
    mov x12, #32
    orr x13, x13, x12
    cmp x13, #122
    b.gt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_13:
    b .Lssa_string__eq_ignore_ascii_case_19
.Lssa_string__eq_ignore_ascii_case_2:
    mov x0, #1
    ret
.Lssa_string__eq_ignore_ascii_case_1:
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn_io_buffered__BufBlock__drop:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_io_buffered__BufBlock__drop.k:
__fn_io_buffered__BufBlock__drop.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_io_buffered__BufBlock__drop_0:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fern_buf_free
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_json__JsonError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_json__JsonError__eq.k:
__fn_json__JsonError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_json__JsonError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_json__JsonError__eq_streqn22
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_json__JsonError__eq_streqd22
.Lssa_json__JsonError__eq_streqn22:
    mov x0, #0
.Lssa_json__JsonError__eq_streqd22:
    cbz x0, .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_9:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_6:
    ldr x10, [x19, #24]
    ldr x9, [x20, #24]
    cmp x10, x9
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_3:
    ldr x10, [x19, #32]
    ldr x9, [x20, #32]
    cmp x10, x9
    cset x0, eq
    b .Lssa_json__JsonError__eq_1
.Lssa_json__JsonError__eq_2:
    mov x0, #0
.Lssa_json__JsonError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8__is_valid:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_utf8__is_valid.k:
__fn_utf8__is_valid.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa_utf8__is_valid_0:
.Lssa_utf8__is_valid_21:
    ldr x20, [x19, #8]
.Lssa_utf8__is_valid_20:
    mov x21, #0
.Lssa_utf8__is_valid_22:
    cmp x21, x20
    b.ge .Lssa_utf8__is_valid_19
.Lssa_utf8__is_valid_71:
    ldr x6, [x19, #8]
    cmp x21, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w22, [x6, x21]
    cmp x22, #128
    b.ge .Lssa_utf8__is_valid_66
.Lssa_utf8__is_valid_70:
    mov x2, x21
    mov x0, x19
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L167
    mov x2, #0
.L167:
    cmp x2, x3
    b.ge .L172
    add x5, x0, x2
    add x6, x0, x3
.L168:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L170
    ld1 {v0.16b}, [x5]
    cmlt v0.16b, v0.16b, #0
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L169
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L173
.L169:
    add x5, x5, #16
    b .L168
.L170:
    cmp x5, x6
    b.ge .L172
    ldrb w4, [x5]
    tbnz w4, #7, .L171
    add x5, x5, #1
    b .L170
.L171:
    sub x2, x5, x0
    b .L173
.L172:
    mov x2, x3
.L173:
    mov x0, x2
    cmp x0, x20
    b.ge .Lssa_utf8__is_valid_18
.Lssa_utf8__is_valid_68:
    ldr x6, [x19, #8]
    cmp x0, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w9, [x6, x0]
    mov x21, x0
    mov x22, x9
.Lssa_utf8__is_valid_67:
.Lssa_utf8__is_valid_66:
    cmp x22, #192
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_65:
    cmp x22, #224
    b.ge .Lssa_utf8__is_valid_56
.Lssa_utf8__is_valid_64:
    add x9, x21, #1
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_62:
    add w9, w21, #1
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_61:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_59:
    sub x9, x22, #192
    lsl x9, x9, #6
    sxtw x9, w9
    sub x10, x10, #128
    sxtw x10, w10
    orr x9, x9, x10
    cmp x9, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_57:
    add x9, x21, #2
    sxtw x9, w9
    mov x21, x9
    b .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_56:
    cmp x22, #240
    b.ge .Lssa_utf8__is_valid_41
.Lssa_utf8__is_valid_55:
    add x9, x21, #2
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_53:
    add x9, x21, #1
    sxtw x9, w9
    add x10, x9, #1
    sxtw x10, w10
    asr x11, x9, #31
    orr x10, x10, x11
    ldr x6, [x19, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x11, [x19, #0]
    ldrb w10, [x11, x9]
    add x9, x21, #2
    sxtw x9, w9
    ldrb w12, [x11, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_52:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_50:
    cmp x12, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_49:
    cmp x12, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_47:
    sub x9, x22, #224
    lsl x9, x9, #12
    sxtw x9, w9
    sub x10, x10, #128
    lsl x10, x10, #6
    sxtw x10, w10
    orr x9, x9, x10
    sub x12, x12, #128
    sxtw x12, w12
    orr x9, x9, x12
    cmp x9, #2048
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_45:
    mov x12, #55296
    cmp x9, x12
    b.lt .Lssa_utf8__is_valid_42
.Lssa_utf8__is_valid_44:
    mov x12, #57343
    cmp x9, x12
    b.le .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_42:
    add x9, x21, #3
    sxtw x9, w9
    mov x13, x9
    b .Lssa_utf8__is_valid_24
.Lssa_utf8__is_valid_41:
    cmp x22, #248
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_40:
    add x9, x21, #3
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_38:
    add x9, x21, #1
    sxtw x9, w9
    add x12, x9, #2
    sxtw x12, w12
    asr x10, x9, #31
    orr x12, x12, x10
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x10, [x19, #0]
    ldrb w12, [x10, x9]
    add x9, x21, #2
    sxtw x9, w9
    ldrb w11, [x10, x9]
    add x9, x21, #3
    sxtw x9, w9
    ldrb w13, [x10, x9]
    cmp x12, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_37:
    cmp x12, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_35:
    cmp x11, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_34:
    cmp x11, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_32:
    cmp x13, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_31:
    cmp x13, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_29:
    sub x22, x22, #240
    lsl x22, x22, #18
    sxtw x22, w22
    sub x12, x12, #128
    lsl x12, x12, #12
    sxtw x12, w12
    orr x22, x22, x12
    sub x11, x11, #128
    lsl x11, x11, #6
    sxtw x11, w11
    orr x22, x22, x11
    sub x13, x13, #128
    sxtw x13, w13
    orr x22, x22, x13
    movz x13, #1, lsl #16
    cmp x22, x13
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_27:
    movn w13, #65519, lsl #16
    cmp x22, x13
    b.gt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_25:
    add x13, x21, #4
    sxtw x13, w13
.Lssa_utf8__is_valid_24:
    mov x21, x13
.Lssa_utf8__is_valid_23:
    cmp x21, x20
    b.lt .Lssa_utf8__is_valid_71
.Lssa_utf8__is_valid_19:
    mov x21, x20
    b .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_18:
    mov x21, x20
.Lssa_utf8__is_valid_17:
.Lssa_utf8__is_valid_16:
.Lssa_utf8__is_valid_15:
.Lssa_utf8__is_valid_14:
.Lssa_utf8__is_valid_13:
.Lssa_utf8__is_valid_12:
.Lssa_utf8__is_valid_11:
.Lssa_utf8__is_valid_10:
.Lssa_utf8__is_valid_9:
.Lssa_utf8__is_valid_8:
.Lssa_utf8__is_valid_7:
.Lssa_utf8__is_valid_6:
.Lssa_utf8__is_valid_5:
.Lssa_utf8__is_valid_4:
.Lssa_utf8__is_valid_3:
.Lssa_utf8__is_valid_2:
.Lssa_utf8__is_valid_1:
    ldr x13, [x19, #8]
    cmp x21, x13
    cset x0, eq
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___primitive_i32_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_i32_to_string.k:
__fn___primitive_i32_to_string.r:
.Lssa___primitive_i32_to_string_0:
    b __fn_int__int_to_string.r
    .cfi_endproc
    .ltorg
__fn_int__int_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_int__int_to_string.k:
__fn_int__int_to_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
.Lssa_int__int_to_string_0:
    cmp x0, #0
    b.lt .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_47:
    cmp x0, #100
    b.ge .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_46:
    adrp x9, .K10
    add x9, x9, :lo12:.K10
    ldr x6, [x9]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x0, #1
    ldr x10, [x9, x5, lsl #3]
    tbnz x10, #0, .Lssa_int__int_to_string_rcinc221
    cmp x10, #16, lsl #12
    b.lo .Lssa_int__int_to_string_rcinc221
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_int__int_to_string_rcinc221
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_int__int_to_string_rcinc221:
    mov x9, x10
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_int__int_to_string_44:
    mov x9, #0
    mov x10, #0
    sub x10, x10, x0
    mov x11, #1
    cmp x0, #0
    csel x10, x10, x0, lt
    csel x19, x11, x9, lt
.Lssa_int__int_to_string_41:
    mov w20, w10
.Lssa_int__int_to_string_40:
    cmp x20, #10
    b.hs .Lssa_int__int_to_string_37
.Lssa_int__int_to_string_39:
    mov x10, #1
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_37:
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_34
.Lssa_int__int_to_string_36:
    mov x10, #2
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_34:
    cmp x20, #1000
    b.hs .Lssa_int__int_to_string_31
.Lssa_int__int_to_string_33:
    mov x10, #3
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_31:
    mov x10, #10000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_28
.Lssa_int__int_to_string_30:
    mov x10, #4
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_28:
    ldr x10, =100000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_25
.Lssa_int__int_to_string_27:
    mov x10, #5
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_25:
    ldr x10, =1000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_22
.Lssa_int__int_to_string_24:
    mov x10, #6
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_22:
    ldr x10, =10000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_19
.Lssa_int__int_to_string_21:
    mov x10, #7
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_19:
    ldr x10, =100000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_16
.Lssa_int__int_to_string_18:
    mov x10, #8
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_16:
    ldr x10, =1000000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_13
.Lssa_int__int_to_string_15:
    mov x10, #9
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_13:
    mov x10, #10
.Lssa_int__int_to_string_12:
    add x12, x10, #1
    sxtw x12, w12
    cmp x19, #0
    csel x21, x12, x10, ne
.Lssa_int__int_to_string_9:
    mov x0, x21
    bl __fern_alloc_bytes
    mov x22, x0
    adrp x12, .SB127
    add x12, x12, :lo12:.SB127
.Lssa_int__int_to_string_8:
.Lssa_int__int_to_string_111:
    cmp x20, #100
    b.lo .Lssa_int__int_to_string_7
.Lssa_int__int_to_string_112:
    mov x4, x20
    ldr x5, =184467440737095517
    umulh x5, x4, x5
    mov x4, x5
    mov x10, x4
    mov x11, #100
    mul x11, x10, x11
    sub x11, x20, x11
    sub x9, x21, #2
    sxtw x21, w9
    lsl x11, x11, #1
    sxtw x11, w11
    ldr x6, [x12, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w9, [x6, x11]
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w9, [x5, #8]
    add w13, w21, #1
    add w11, w11, #1
    ldr x6, [x12, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w9, [x6, x11]
    ldr x7, [x22]
    cmp x13, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    strb w9, [x5, #8]
    mov x20, x10
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_112
.Lssa_int__int_to_string_7:
    cmp x20, #10
    b.lo .Lssa_int__int_to_string_5
.Lssa_int__int_to_string_6:
    sub x11, x21, #2
    sxtw x11, w11
    lsl x9, x20, #1
    sxtw x9, w9
    ldr x6, [x12, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w13, [x6, x9]
    ldr x7, [x22]
    cmp x11, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    strb w13, [x5, #8]
    add w11, w11, #1
    add w9, w9, #1
    ldr x6, [x12, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w10, [x6, x9]
    ldr x7, [x22]
    cmp x11, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    strb w10, [x5, #8]
    b .Lssa_int__int_to_string_4
.Lssa_int__int_to_string_5:
    sub w21, w21, #1
    add x20, x20, #48
    and x20, x20, #255
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w20, [x5, #8]
.Lssa_int__int_to_string_4:
    cbz x19, .Lssa_int__int_to_string_1
.Lssa_int__int_to_string_3:
    tst x22, #1
    b.ne .Lssa_int__int_to_string_uq3
    cmp x22, #16, lsl #12
    b.lo .Lssa_int__int_to_string_uq3
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_int__int_to_string_uq3:
    b.ne .Lssa_int__int_to_string_129
.Lssa_int__int_to_string_128:
    b .Lssa_int__int_to_string_130
.Lssa_int__int_to_string_129:
    cmp x22, #16, lsl #12
    b.lo .Lssa_int__int_to_string_rcdeck346
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_int__int_to_string_rcdecd346
    tbnz w5, #31, .Lssa_int__int_to_string_rcdeck346
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_int__int_to_string_rcdece346
.Lssa_int__int_to_string_rcdecd346:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_int__int_to_string_rcdeck346:
    mov x0, x22
.Lssa_int__int_to_string_rcdece346:
    mov x9, #0
    ldr x10, [x22, #0]
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    mov x22, x0
.Lssa_int__int_to_string_130:
    mov x10, #45
    ldr x6, [x22, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    strb w10, [x22, #8]
.Lssa_int__int_to_string_2:
.Lssa_int__int_to_string_1:
    str x22, [sp, #-16]!
    bl __fn___fern_string_from_bytes_u8
    add sp, sp, #16
    mov x20, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa_int__int_to_string_rcdeck356
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_int__int_to_string_rcdecd356
    tbnz w5, #31, .Lssa_int__int_to_string_rcdeck356
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_int__int_to_string_rcdece356
.Lssa_int__int_to_string_rcdecd356:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_int__int_to_string_rcdeck356:
    mov x0, x22
.Lssa_int__int_to_string_rcdece356:
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8_scalar__step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_utf8_scalar__step.k:
__fn_utf8_scalar__step.r:
.Lssa_utf8_scalar__step_0:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x9]
.Lssa_utf8_scalar__step_47:
    cmp x11, #128
    b.ge .Lssa_utf8_scalar__step_44
.Lssa_utf8_scalar__step_46:
    mov x12, #1
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_44:
    cmp x11, #194
    b.ge .Lssa_utf8_scalar__step_41
.Lssa_utf8_scalar__step_43:
    mov x12, #0
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_41:
    cmp x11, #224
    b.ge .Lssa_utf8_scalar__step_38
.Lssa_utf8_scalar__step_40:
    mov x12, #2
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_38:
    cmp x11, #240
    b.ge .Lssa_utf8_scalar__step_35
.Lssa_utf8_scalar__step_37:
    mov x12, #3
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_35:
    cmp x11, #245
    b.ge .Lssa_utf8_scalar__step_32
.Lssa_utf8_scalar__step_34:
    mov x12, #4
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_32:
    mov x12, #0
.Lssa_utf8_scalar__step_31:
    cmp x12, #1
    b.gt .Lssa_utf8_scalar__step_28
.Lssa_utf8_scalar__step_30:
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_28:
    add x13, x9, #1
    sxtw x13, w13
    cmp x13, x10
    b.lt .Lssa_utf8_scalar__step_25
.Lssa_utf8_scalar__step_27:
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_25:
    add w13, w9, #1
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x13]
.Lssa_utf8_scalar__step_24:
    cmp x11, #224
    b.ne .Lssa_utf8_scalar__step_21
.Lssa_utf8_scalar__step_23:
    mov x13, #160
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_21:
    cmp x11, #240
    b.ne .Lssa_utf8_scalar__step_18
.Lssa_utf8_scalar__step_20:
    mov x13, #144
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_18:
    mov x13, #128
.Lssa_utf8_scalar__step_17:
    cmp x14, x13
    b.lt .Lssa_utf8_scalar__step_7
.Lssa_utf8_scalar__step_15:
    cmp x11, #237
    b.ne .Lssa_utf8_scalar__step_12
.Lssa_utf8_scalar__step_14:
    mov x11, #159
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_12:
    cmp x11, #244
    b.ne .Lssa_utf8_scalar__step_9
.Lssa_utf8_scalar__step_11:
    mov x11, #143
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_9:
    mov x11, #191
.Lssa_utf8_scalar__step_8:
    cmp x14, x11
    b.le .Lssa_utf8_scalar__step_5
.Lssa_utf8_scalar__step_7:
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_5:
.Lssa_utf8_scalar__step_4:
    mov x14, #2
.Lssa_utf8_scalar__step_109:
    cmp x14, x12
    b.ge .Lssa_utf8_scalar__step_3
.Lssa_utf8_scalar__step_119:
    add x11, x9, x14
    sxtw x11, w11
    cmp x11, x10
    b.ge .Lssa_utf8_scalar__step_2
.Lssa_utf8_scalar__step_117:
    add w11, w9, w14
    ldr x6, [x0, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w13, [x6, x11]
.Lssa_utf8_scalar__step_116:
    cmp x13, #128
    b.lt .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_115:
    cmp x13, #192
    b.ge .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_110:
    add x14, x14, #1
    cmp x14, x12
    b.lt .Lssa_utf8_scalar__step_119
.Lssa_utf8_scalar__step_3:
    mov x0, x12
    ret
.Lssa_utf8_scalar__step_2:
    mov x0, x14
    ret
.Lssa_utf8_scalar__step_1:
    mov x0, x14
    ret
    .cfi_endproc
    .ltorg
__fn_deflate____ReadPhase__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_deflate____ReadPhase__eq.k:
__fn_deflate____ReadPhase__eq.r:
.Lssa_deflate____ReadPhase__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S128
    add x11, x11, :lo12:.S128
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_20
.Lssa_deflate____ReadPhase__eq_24:
    ldr x11, [x9, #0]
    adrp x12, .S128
    add x12, x12, :lo12:.S128
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_20:
    adrp x11, .S129
    add x11, x11, :lo12:.S129
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_15
.Lssa_deflate____ReadPhase__eq_19:
    ldr x11, [x9, #0]
    adrp x14, .S129
    add x14, x14, :lo12:.S129
    mov x13, #1
    mov x12, #0
    cmp x11, x14
    csel x0, x13, x12, eq
    ret
.Lssa_deflate____ReadPhase__eq_15:
    adrp x11, .S130
    add x11, x11, :lo12:.S130
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_10
.Lssa_deflate____ReadPhase__eq_14:
    ldr x11, [x9, #0]
    adrp x12, .S130
    add x12, x12, :lo12:.S130
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_10:
    adrp x11, .S131
    add x11, x11, :lo12:.S131
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_4
.Lssa_deflate____ReadPhase__eq_9:
    ldr x10, [x9, #0]
    adrp x11, .S131
    add x11, x11, :lo12:.S131
    mov x14, #1
    mov x13, #0
    cmp x10, x11
    csel x0, x14, x13, eq
    ret
.Lssa_deflate____ReadPhase__eq_4:
    ldr x10, [x9, #0]
    adrp x9, .S132
    add x9, x9, :lo12:.S132
    mov x13, #1
    mov x14, #0
    cmp x10, x9
    csel x0, x13, x14, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeErrorKind__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeErrorKind__eq.k:
__fn_codec__DecodeErrorKind__eq.r:
.Lssa_codec__DecodeErrorKind__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S133
    add x11, x11, :lo12:.S133
    cmp x10, x11
    b.ne .Lssa_codec__DecodeErrorKind__eq_15
.Lssa_codec__DecodeErrorKind__eq_19:
    ldr x11, [x0, #8]
    ldr x12, [x9, #0]
    adrp x13, .S133
    add x13, x13, :lo12:.S133
    cmp x12, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_16
.Lssa_codec__DecodeErrorKind__eq_18:
    ldr x12, [x9, #8]
    cmp x11, x12
    cset x0, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_16:
    mov x0, #0
    ret
.Lssa_codec__DecodeErrorKind__eq_15:
    adrp x12, .S134
    add x12, x12, :lo12:.S134
    cmp x10, x12
    b.ne .Lssa_codec__DecodeErrorKind__eq_10
.Lssa_codec__DecodeErrorKind__eq_14:
    ldr x12, [x9, #0]
    adrp x11, .S134
    add x11, x11, :lo12:.S134
    mov x13, #1
    mov x14, #0
    cmp x12, x11
    csel x0, x13, x14, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_10:
    adrp x12, .S135
    add x12, x12, :lo12:.S135
    cmp x10, x12
    b.ne .Lssa_codec__DecodeErrorKind__eq_4
.Lssa_codec__DecodeErrorKind__eq_9:
    ldr x10, [x9, #0]
    adrp x12, .S135
    add x12, x12, :lo12:.S135
    mov x14, #1
    mov x13, #0
    cmp x10, x12
    csel x0, x14, x13, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_4:
    ldr x10, [x9, #0]
    adrp x9, .S136
    add x9, x9, :lo12:.S136
    mov x13, #1
    mov x14, #0
    cmp x10, x9
    csel x0, x13, x14, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeError__eq.k:
__fn_codec__DecodeError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_codec__DecodeError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_codec__DecodeError__eq_streqn36
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_codec__DecodeError__eq_streqd36
.Lssa_codec__DecodeError__eq_streqn36:
    mov x0, #0
.Lssa_codec__DecodeError__eq_streqd36:
    cbz x0, .Lssa_codec__DecodeError__eq_20
.Lssa_codec__DecodeError__eq_27:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_codec__DecodeError__eq_20
.Lssa_codec__DecodeError__eq_24:
    ldr x10, [x19, #24]
    ldr x9, [x20, #24]
.Lssa_codec__DecodeError__eq_23:
    ldr x11, [x10, #0]
    adrp x12, .S133
    add x12, x12, :lo12:.S133
    cmp x11, x12
    b.ne .Lssa_codec__DecodeError__eq_17
.Lssa_codec__DecodeError__eq_22:
    ldr x12, [x10, #8]
    ldr x10, [x9, #0]
    adrp x13, .S133
    add x13, x13, :lo12:.S133
    cmp x10, x13
    b.ne .Lssa_codec__DecodeError__eq_18
.Lssa_codec__DecodeError__eq_21:
    ldr x10, [x9, #8]
    cmp x12, x10
    cset x0, eq
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_20:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_18:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_17:
    adrp x10, .S134
    add x10, x10, :lo12:.S134
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_12
.Lssa_codec__DecodeError__eq_16:
    ldr x10, [x9, #0]
    adrp x12, .S134
    add x12, x12, :lo12:.S134
    cmp x10, x12
    b.ne .Lssa_codec__DecodeError__eq_13
.Lssa_codec__DecodeError__eq_15:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_13:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_12:
    adrp x10, .S135
    add x10, x10, :lo12:.S135
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_6
.Lssa_codec__DecodeError__eq_11:
    ldr x11, [x9, #0]
    adrp x10, .S135
    add x10, x10, :lo12:.S135
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_8
.Lssa_codec__DecodeError__eq_10:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_8:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_6:
    ldr x11, [x9, #0]
    adrp x9, .S136
    add x9, x9, :lo12:.S136
    cmp x11, x9
    b.ne .Lssa_codec__DecodeError__eq_3
.Lssa_codec__DecodeError__eq_5:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_3:
    mov x0, #0
.Lssa_codec__DecodeError__eq_2:
.Lssa_codec__DecodeError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_main:
    .cfi_startproc
__fn_main.k:
__fn_main.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #32
.Lssa_main_0:
    adrp x4, .SB137
    add x4, x4, :lo12:.SB137
    str x4, [sp, #24]
.Lssa_main_6:
    mov x21, #0
    str xzr, [sp, #16]
.Lssa_main_7:
    cmp x21, #4000
    b.ge .Lssa_main_5
.Lssa_main_59:
    ldr x0, [sp, #24]
    bl __fn_http__parse_request.r
    mov x22, x0
    mov x23, x1
    cmp x22, #0
    b.ne .Lssa_main_4
.Lssa_main_57:
    adrp x9, .SB138
    add x9, x9, :lo12:.SB138
    ldr x10, [x23, #16]
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x22, x0
    adrp x24, .K0
    add x24, x24, :lo12:.K0
    adrp x25, .K0
    add x25, x25, :lo12:.K0
.Lssa_main_55:
    adrp x26, .SB139
    add x26, x26, :lo12:.SB139
.Lssa_main_50:
    mov x4, #0
    str x4, [sp, #8]
.Lssa_main_44:
    adrp x28, .SB140
    add x28, x28, :lo12:.SB140
    ldr x0, [x22, #8]
    bl __fn_int__int_to_string.r
    mov x19, x0
    str x19, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x20, x0
    tbnz x19, #0, .Lssa_main_rcdeck401
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck401
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd401
    tbnz w5, #31, .Lssa_main_rcdeck401
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece401
.Lssa_main_rcdecd401:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck401:
    mov x0, x19
.Lssa_main_rcdece401:
    adrp x19, .SB141
    add x19, x19, :lo12:.SB141
    str x20, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_69
.Lssa_main_68:
    mov x28, x20
    b .Lssa_main_43
.Lssa_main_69:
    str x20, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x28, x0
    tbnz x20, #0, .Lssa_main_rcdeck405
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_rcdeck405
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd405
    tbnz w5, #31, .Lssa_main_rcdeck405
    mov x0, x20
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece405
.Lssa_main_rcdecd405:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_main_rcdeck405:
    mov x0, x20
.Lssa_main_rcdece405:
.Lssa_main_70:
.Lssa_main_43:
    mov x10, #256
    mov x0, x10
    bl __fern_buf_new
    mov x20, x0
.Lssa_main_41:
    adrp x10, .SB142
    add x10, x10, :lo12:.SB142
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push
    mov x10, #200
.Lssa_main_37:
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push_decimal
.Lssa_main_36:
    adrp x10, .SB143
    add x10, x10, :lo12:.SB143
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push
.Lssa_main_34:
    adrp x10, .K11
    add x10, x10, :lo12:.K11
    adrp x9, .K12
    add x9, x9, :lo12:.K12
.Lssa_main_33:
    mov x11, #0
.Lssa_main_74:
    ldr x12, [x10, #0]
    cmp x11, x12
    b.ge .Lssa_main_32
.Lssa_main_77:
    add x5, x11, #1
    ldr x12, [x10, x5, lsl #3]
    cmp x12, #200
    b.eq .Lssa_main_31
.Lssa_main_75:
    add x11, x11, #1
    b .Lssa_main_74
.Lssa_main_32:
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    mov x19, x10
    b .Lssa_main_30
.Lssa_main_31:
    ldr x6, [x9]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x10, [x9, x5, lsl #3]
    tbnz x10, #0, .Lssa_main_rcinc434
    cmp x10, #16, lsl #12
    b.lo .Lssa_main_rcinc434
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_main_rcinc434
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_main_rcinc434:
    mov x0, x10
    mov x19, x10
.Lssa_main_30:
    ldr x10, [x19, #8]
    cmp x10, #0
    b.ne .Lssa_main_27
.Lssa_main_89:
    tbnz x19, #0, .Lssa_main_rcdeck440
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck440
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd440
    tbnz w5, #31, .Lssa_main_rcdeck440
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece440
.Lssa_main_rcdecd440:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck440:
    mov x0, x19
.Lssa_main_rcdece440:
.Lssa_main_29:
    adrp x10, .SB193
    add x10, x10, :lo12:.SB193
    mov x19, x10
.Lssa_main_28:
.Lssa_main_27:
    mov x0, x20
    mov x1, x19
    bl __fern_buf_push
    tbnz x19, #0, .Lssa_main_rcdeck444
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck444
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd444
    tbnz w5, #31, .Lssa_main_rcdeck444
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece444
.Lssa_main_rcdecd444:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck444:
    mov x0, x19
.Lssa_main_rcdece444:
    adrp x10, .SB141
    add x10, x10, :lo12:.SB141
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push
.Lssa_main_26:
    mov x19, #0
.Lssa_main_94:
    ldr x10, [x24, #0]
    cmp x19, x10
    b.ge .Lssa_main_24
.Lssa_main_100:
    add x5, x19, #1
    ldr x27, [x24, x5, lsl #3]
    adrp x9, .SB15
    add x9, x9, :lo12:.SB15
    mov x0, x27
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_95
.Lssa_main_99:
    adrp x9, .SB14
    add x9, x9, :lo12:.SB14
    mov x0, x27
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_95
.Lssa_main_98:
    adrp x9, .SB16
    add x9, x9, :lo12:.SB16
    mov x0, x27
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_95
.Lssa_main_96:
    mov x0, x20
    mov x1, x27
    bl __fern_buf_push
    adrp x9, .SB194
    add x9, x9, :lo12:.SB194
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
    ldr x6, [x25]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x9, [x25, x5, lsl #3]
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
    adrp x9, .SB141
    add x9, x9, :lo12:.SB141
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_95:
    add x19, x19, #1
    b .Lssa_main_94
.Lssa_main_24:
    mov x0, x20
    mov x1, x28
    bl __fern_buf_push
    tbnz x28, #0, .Lssa_main_rcdeck484
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck484
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd484
    tbnz w5, #31, .Lssa_main_rcdeck484
    mov x0, x28
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece484
.Lssa_main_rcdecd484:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck484:
    mov x0, x28
.Lssa_main_rcdece484:
.Lssa_main_19:
    adrp x9, .SB195
    add x9, x9, :lo12:.SB195
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_16:
    mov x0, x20
    bl __fern_buf_take
    mov x28, x0
    mov x0, x20
    bl __fern_buf_free
    ldr x4, [sp, #8]
    cbz x4, .Lssa_main_15
.Lssa_main_120:
    tbnz x22, #0, .Lssa_main_rcdeck489
    cmp x22, #16, lsl #12
    b.lo .Lssa_main_rcdeck489
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd489
    tbnz w5, #31, .Lssa_main_rcdeck489
    mov x0, x22
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece489
.Lssa_main_rcdecd489:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_main_rcdeck489:
    mov x0, x22
.Lssa_main_rcdece489:
    tbnz x28, #0, .Lssa_main_rcdeck490
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck490
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd490
    tbnz w5, #31, .Lssa_main_rcdeck490
    mov x0, x28
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece490
.Lssa_main_rcdecd490:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck490:
    mov x0, x28
.Lssa_main_rcdece490:
    mov x0, x23
    bl __fn___sem_release_HttpRequest.r
    b .Lssa_main_1
.Lssa_main_15:
    adrp x9, .SB196
    add x9, x9, :lo12:.SB196
    ldr x10, [x26, #8]
    cmp x10, #4
    b.ne .Lssa_main_12
.Lssa_main_124:
    ldr x6, [x26, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn497
    ldr x6, [x26]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn497
    mov x0, x26
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd497
.Lssa_main_streqn497:
    mov x0, #0
.Lssa_main_streqd497:
    cbz x0, .Lssa_main_12
.Lssa_main_127:
    tbnz x22, #0, .Lssa_main_rcdeck499
    cmp x22, #16, lsl #12
    b.lo .Lssa_main_rcdeck499
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd499
    tbnz w5, #31, .Lssa_main_rcdeck499
    mov x0, x22
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece499
.Lssa_main_rcdecd499:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_main_rcdeck499:
    mov x0, x22
.Lssa_main_rcdece499:
.Lssa_main_14:
    mov x26, x28
    b .Lssa_main_9
.Lssa_main_12:
    str x28, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_133
.Lssa_main_132:
    mov x26, x28
    b .Lssa_main_134
.Lssa_main_133:
    str x28, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x26, x0
    tbnz x28, #0, .Lssa_main_rcdeck502
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck502
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd502
    tbnz w5, #31, .Lssa_main_rcdeck502
    mov x0, x28
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece502
.Lssa_main_rcdecd502:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck502:
    mov x0, x28
.Lssa_main_rcdece502:
.Lssa_main_134:
    tbnz x22, #0, .Lssa_main_rcdeck504
    cmp x22, #16, lsl #12
    b.lo .Lssa_main_rcdeck504
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd504
    tbnz w5, #31, .Lssa_main_rcdeck504
    mov x0, x22
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece504
.Lssa_main_rcdecd504:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_main_rcdeck504:
    mov x0, x22
.Lssa_main_rcdece504:
.Lssa_main_11:
.Lssa_main_9:
    ldr x22, [x26, #8]
    tbnz x26, #0, .Lssa_main_rcdeck509
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck509
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd509
    tbnz w5, #31, .Lssa_main_rcdeck509
    mov x0, x26
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece509
.Lssa_main_rcdecd509:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck509:
    mov x0, x26
.Lssa_main_rcdece509:
    tst x23, #1
    b.ne .Lssa_main_uq9
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_uq9
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_main_uq9:
    b.ne .Lssa_main_136
.Lssa_main_135:
    mov x9, x23
    b .Lssa_main_137
.Lssa_main_136:
    mov x9, #0
.Lssa_main_137:
    ldr x26, [x23, #32]
    cmp x9, #0
    b.ne .Lssa_main_140
.Lssa_main_138:
    tbnz x26, #0, .Lssa_main_rcinc516
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcinc516
    ldur w5, [x26, #-8]
    tbnz w5, #31, .Lssa_main_rcinc516
    add w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcinc516:
    mov x0, x26
.Lssa_main_140:
    cmp x9, #0
    b.eq .Lssa_main_142
.Lssa_main_141:
    mov x9, #0
    str x9, [x23, #32]
    mov x0, x23
    bl __fn___sem_drop_HttpRequest.r
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_main_143
.Lssa_main_142:
    mov x0, x23
    bl __fn___sem_release_HttpRequest.r
.Lssa_main_143:
    tst x26, #1
    b.ne .Lssa_main_uq143
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_uq143
    ldur w5, [x26, #-8]
    cmp w5, #1
.Lssa_main_uq143:
    b.ne .Lssa_main_145
.Lssa_main_144:
    mov x10, x26
    b .Lssa_main_146
.Lssa_main_145:
    mov x10, #0
.Lssa_main_146:
    ldr x28, [x26, #8]
    cmp x10, #0
    b.ne .Lssa_main_149
.Lssa_main_147:
    tbnz x28, #0, .Lssa_main_rcinc530
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcinc530
    ldur w5, [x28, #-8]
    tbnz w5, #31, .Lssa_main_rcinc530
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcinc530:
    mov x0, x28
.Lssa_main_149:
    cmp x10, #0
    b.eq .Lssa_main_151
.Lssa_main_150:
    ldr x20, [x26, #16]
    tst x20, #1
    b.ne .Lssa_main_uq150
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_uq150
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_main_uq150:
    b.ne .Lssa_main_155
.Lssa_main_153:
    mov x19, #0
.Lssa_main_157:
    ldr x10, [x20, #0]
    cmp x19, x10
    b.ge .Lssa_main_155
.Lssa_main_158:
    add x5, x19, #1
    ldr x10, [x20, x5, lsl #3]
    tbnz x10, #0, .Lssa_main_rcdeck540
    cmp x10, #16, lsl #12
    b.lo .Lssa_main_rcdeck540
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd540
    tbnz w5, #31, .Lssa_main_rcdeck540
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece540
.Lssa_main_rcdecd540:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_main_rcdeck540:
    mov x0, x10
.Lssa_main_rcdece540:
    add x19, x19, #1
    b .Lssa_main_157
.Lssa_main_155:
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_rcdeck544
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd544
    tbnz w5, #31, .Lssa_main_rcdeck544
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece544
.Lssa_main_rcdecd544:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_main_rcdeck544:
    mov x0, x20
.Lssa_main_rcdece544:
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_152
.Lssa_main_151:
    mov x0, x26
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_152:
    ldr x26, [x28, #0]
    tst x28, #1
    b.ne .Lssa_main_uq152
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_uq152
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_main_uq152:
    b.ne .Lssa_main_163
.Lssa_main_161:
    mov x20, #0
.Lssa_main_165:
    ldr x10, [x28, #0]
    cmp x20, x10
    b.ge .Lssa_main_163
.Lssa_main_166:
    add x5, x20, #1
    ldr x10, [x28, x5, lsl #3]
    tbnz x10, #0, .Lssa_main_rcdeck557
    cmp x10, #16, lsl #12
    b.lo .Lssa_main_rcdeck557
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd557
    tbnz w5, #31, .Lssa_main_rcdeck557
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece557
.Lssa_main_rcdecd557:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_main_rcdeck557:
    mov x0, x10
.Lssa_main_rcdece557:
    add x20, x20, #1
    b .Lssa_main_165
.Lssa_main_163:
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck562
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd562
    tbnz w5, #31, .Lssa_main_rcdeck562
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece562
.Lssa_main_rcdecd562:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck562:
    mov x0, x28
.Lssa_main_rcdece562:
    add x22, x22, x26
    sxtw x22, w22
    ldr x4, [sp, #16]
    add x4, x4, x22
    str x4, [sp, #16]
.Lssa_main_8:
    add x21, x21, #1
    cmp x21, #4000
    b.lt .Lssa_main_59
.Lssa_main_5:
    ldr x4, [sp, #16]
    ldr x5, =-6275696437447579415
    smulh x5, x4, x5
    add x5, x5, x4
    asr x5, x5, #6
    add x5, x5, x5, lsr #63
    mov x6, #97
    msub x4, x5, x6, x4
    mov x10, x4
    sxtw x0, w10
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_4:
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_rcdeck573
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd573
    tbnz w5, #31, .Lssa_main_rcdeck573
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece573
.Lssa_main_rcdecd573:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_main_rcdeck573:
    mov x0, x23
.Lssa_main_rcdece573:
.Lssa_main_2:
    mov x0, #100
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_1:
    mov x10, #134
    mov x0, x10
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HeaderMap
.weak __fn___sem_drop_HeaderMap.k
__fn___sem_drop_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HeaderMap.k:
__fn___sem_drop_HeaderMap.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HeaderMap_0:
    ldr x20, [x19, #8]
    tst x20, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq0
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq0:
    b.ne .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_1:
    mov x21, #0
.Lssa___sem_drop_HeaderMap_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_6:
    add x5, x21, #1
    ldr x9, [x20, x5, lsl #3]
    tbnz x9, #0, .Lssa___sem_drop_HeaderMap_rcdeck11
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck11
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd11
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck11
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HeaderMap_rcdece11
.Lssa___sem_drop_HeaderMap_rcdecd11:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck11:
    mov x0, x9
.Lssa___sem_drop_HeaderMap_rcdece11:
    add x21, x21, #1
    b .Lssa___sem_drop_HeaderMap_5
.Lssa___sem_drop_HeaderMap_3:
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck15
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd15
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck15
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_HeaderMap_rcdece15
.Lssa___sem_drop_HeaderMap_rcdecd15:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck15:
    mov x0, x20
.Lssa___sem_drop_HeaderMap_rcdece15:
    ldr x20, [x19, #16]
    tst x20, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq3
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq3
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq3:
    b.ne .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_9:
    mov x19, #0
.Lssa___sem_drop_HeaderMap_13:
    ldr x9, [x20, #0]
    cmp x19, x9
    b.ge .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_14:
    add x5, x19, #1
    ldr x9, [x20, x5, lsl #3]
    tbnz x9, #0, .Lssa___sem_drop_HeaderMap_rcdeck23
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck23
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd23
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck23
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HeaderMap_rcdece23
.Lssa___sem_drop_HeaderMap_rcdecd23:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck23:
    mov x0, x9
.Lssa___sem_drop_HeaderMap_rcdece23:
    add x19, x19, #1
    b .Lssa___sem_drop_HeaderMap_13
.Lssa___sem_drop_HeaderMap_11:
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck27
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd27
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck27
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_HeaderMap_rcdece27
.Lssa___sem_drop_HeaderMap_rcdecd27:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck27:
    mov x0, x20
.Lssa___sem_drop_HeaderMap_rcdece27:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HeaderMap
.weak __fn___sem_release_HeaderMap.k
__fn___sem_release_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HeaderMap.k:
__fn___sem_release_HeaderMap.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HeaderMap_release_dec
    tbz w5, #31, .Lssa___sem_release_HeaderMap_release_slow
.Lssa___sem_release_HeaderMap_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_HeaderMap_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_HeaderMap_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HeaderMap_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HeaderMap_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_HeaderMap_uq0:
    b.ne .Lssa___sem_release_HeaderMap_3
.Lssa___sem_release_HeaderMap_1:
    mov x0, x19
    bl __fn___sem_drop_HeaderMap.r
.Lssa___sem_release_HeaderMap_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HeaderMap_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_HeaderMap_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_HeaderMap_rcdece3
.Lssa___sem_release_HeaderMap_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_HeaderMap_rcdeck3:
    mov x0, x19
.Lssa___sem_release_HeaderMap_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ByteStream
.weak __fn___sem_drop_ByteStream.k
__fn___sem_drop_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ByteStream.k:
__fn___sem_drop_ByteStream.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_ByteStream_0:
    ldr x9, [x19, #8]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ByteStream_rcdeck3
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ByteStream_rcdecd3
    tbnz w5, #31, .Lssa___sem_drop_ByteStream_rcdeck3
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ByteStream_rcdece3
.Lssa___sem_drop_ByteStream_rcdecd3:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ByteStream_rcdeck3:
    mov x0, x9
.Lssa___sem_drop_ByteStream_rcdece3:
    ldr x0, [x19, #24]
    bl __fn___sem_release_Option$BodySource.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ByteStream
.weak __fn___sem_release_ByteStream.k
__fn___sem_release_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ByteStream.k:
__fn___sem_release_ByteStream.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ByteStream_release_dec
    tbz w5, #31, .Lssa___sem_release_ByteStream_release_slow
.Lssa___sem_release_ByteStream_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_ByteStream_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_ByteStream_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ByteStream_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ByteStream_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_ByteStream_uq0:
    b.ne .Lssa___sem_release_ByteStream_3
.Lssa___sem_release_ByteStream_1:
    mov x0, x19
    bl __fn___sem_drop_ByteStream.r
.Lssa___sem_release_ByteStream_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ByteStream_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_ByteStream_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_ByteStream_rcdece3
.Lssa___sem_release_ByteStream_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_ByteStream_rcdeck3:
    mov x0, x19
.Lssa___sem_release_ByteStream_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_BodySource
.weak __fn___sem_drop_BodySource.k
__fn___sem_drop_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_BodySource.k:
__fn___sem_drop_BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_BodySource_0:
    ldr x9, [x19, #8]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_rcdeck5
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_BodySource_rcdecd5
    tbnz w5, #31, .Lssa___sem_drop_BodySource_rcdeck5
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_BodySource_rcdece5
.Lssa___sem_drop_BodySource_rcdecd5:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_BodySource_rcdeck5:
    mov x0, x9
.Lssa___sem_drop_BodySource_rcdece5:
    ldr x20, [x19, #16]
    tst x20, #1
    b.ne .Lssa___sem_drop_BodySource_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_uq0
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_BodySource_uq0:
    b.ne .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_1:
    mov x21, #0
.Lssa___sem_drop_BodySource_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_6:
    add x5, x21, #1
    ldr x0, [x20, x5, lsl #3]
    bl __fn___sem_release_Option$StreamFault.r
    add x21, x21, #1
    b .Lssa___sem_drop_BodySource_5
.Lssa___sem_drop_BodySource_3:
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_rcdeck17
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_BodySource_rcdecd17
    tbnz w5, #31, .Lssa___sem_drop_BodySource_rcdeck17
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_BodySource_rcdece17
.Lssa___sem_drop_BodySource_rcdecd17:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___sem_drop_BodySource_rcdeck17:
    mov x0, x20
.Lssa___sem_drop_BodySource_rcdece17:
    ldr x9, [x19, #24]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_rcdeck19
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_BodySource_rcdecd19
    tbnz w5, #31, .Lssa___sem_drop_BodySource_rcdeck19
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_BodySource_rcdece19
.Lssa___sem_drop_BodySource_rcdecd19:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_BodySource_rcdeck19:
    mov x0, x9
.Lssa___sem_drop_BodySource_rcdece19:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_BodySource
.weak __fn___sem_release_BodySource.k
__fn___sem_release_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_BodySource.k:
__fn___sem_release_BodySource.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_BodySource_release_dec
    tbz w5, #31, .Lssa___sem_release_BodySource_release_slow
.Lssa___sem_release_BodySource_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_BodySource_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_BodySource_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_BodySource_uq0:
    b.ne .Lssa___sem_release_BodySource_3
.Lssa___sem_release_BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_BodySource.r
.Lssa___sem_release_BodySource_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_BodySource_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_BodySource_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_BodySource_rcdece3
.Lssa___sem_release_BodySource_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_BodySource_rcdeck3:
    mov x0, x19
.Lssa___sem_release_BodySource_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HttpRequest
.weak __fn___sem_drop_HttpRequest.k
__fn___sem_drop_HttpRequest:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HttpRequest.k:
__fn___sem_drop_HttpRequest.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HttpRequest_0:
    ldr x9, [x19, #8]
    tbnz x9, #0, .Lssa___sem_drop_HttpRequest_rcdeck3
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HttpRequest_rcdeck3
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HttpRequest_rcdecd3
    tbnz w5, #31, .Lssa___sem_drop_HttpRequest_rcdeck3
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HttpRequest_rcdece3
.Lssa___sem_drop_HttpRequest_rcdecd3:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HttpRequest_rcdeck3:
    mov x0, x9
.Lssa___sem_drop_HttpRequest_rcdece3:
    ldr x9, [x19, #16]
    tbnz x9, #0, .Lssa___sem_drop_HttpRequest_rcdeck5
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HttpRequest_rcdeck5
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HttpRequest_rcdecd5
    tbnz w5, #31, .Lssa___sem_drop_HttpRequest_rcdeck5
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HttpRequest_rcdece5
.Lssa___sem_drop_HttpRequest_rcdecd5:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HttpRequest_rcdeck5:
    mov x0, x9
.Lssa___sem_drop_HttpRequest_rcdece5:
    ldr x0, [x19, #24]
    bl __fn___sem_release_ByteStream.r
    ldr x0, [x19, #32]
    bl __fn___sem_release_HeaderMap.r
    ldr x0, [x19, #40]
    bl __fn___sem_release_HeaderMap.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HttpRequest
.weak __fn___sem_release_HttpRequest.k
__fn___sem_release_HttpRequest:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HttpRequest.k:
__fn___sem_release_HttpRequest.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_HttpRequest_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HttpRequest_release_dec
    tbz w5, #31, .Lssa___sem_release_HttpRequest_release_slow
.Lssa___sem_release_HttpRequest_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_HttpRequest_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_HttpRequest_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HttpRequest_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HttpRequest_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HttpRequest_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_HttpRequest_uq0:
    b.ne .Lssa___sem_release_HttpRequest_3
.Lssa___sem_release_HttpRequest_1:
    mov x0, x19
    bl __fn___sem_drop_HttpRequest.r
.Lssa___sem_release_HttpRequest_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HttpRequest_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HttpRequest_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_HttpRequest_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_HttpRequest_rcdece3
.Lssa___sem_release_HttpRequest_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_HttpRequest_rcdeck3:
    mov x0, x19
.Lssa___sem_release_HttpRequest_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$BodySource
.weak __fn___sem_drop_Option$BodySource.k
__fn___sem_drop_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$BodySource.k:
__fn___sem_drop_Option$BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$BodySource_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$BodySource_3
.Lssa___sem_drop_Option$BodySource_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___sem_release_BodySource.r
.Lssa___sem_drop_Option$BodySource_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$BodySource
.weak __fn___sem_release_Option$BodySource.k
__fn___sem_release_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$BodySource.k:
__fn___sem_release_Option$BodySource.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$BodySource_release_dec
    tbz w5, #31, .Lssa___sem_release_Option$BodySource_release_slow
.Lssa___sem_release_Option$BodySource_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Option$BodySource_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Option$BodySource_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Option$BodySource_uq0:
    b.ne .Lssa___sem_release_Option$BodySource_3
.Lssa___sem_release_Option$BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_Option$BodySource.r
.Lssa___sem_release_Option$BodySource_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$BodySource_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_Option$BodySource_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_Option$BodySource_rcdece3
.Lssa___sem_release_Option$BodySource_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_Option$BodySource_rcdeck3:
    mov x0, x19
.Lssa___sem_release_Option$BodySource_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$StreamFault
.weak __fn___sem_drop_Option$StreamFault.k
__fn___sem_drop_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$StreamFault.k:
__fn___sem_drop_Option$StreamFault.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$StreamFault_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$StreamFault_3
.Lssa___sem_drop_Option$StreamFault_1:
    ldr x9, [x0, #8]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_Option$StreamFault_rcdeck6
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_Option$StreamFault_rcdecd6
    tbnz w5, #31, .Lssa___sem_drop_Option$StreamFault_rcdeck6
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_Option$StreamFault_rcdece6
.Lssa___sem_drop_Option$StreamFault_rcdecd6:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_Option$StreamFault_rcdeck6:
    mov x0, x9
.Lssa___sem_drop_Option$StreamFault_rcdece6:
.Lssa___sem_drop_Option$StreamFault_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$StreamFault
.weak __fn___sem_release_Option$StreamFault.k
__fn___sem_release_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$StreamFault.k:
__fn___sem_release_Option$StreamFault.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$StreamFault_release_dec
    tbz w5, #31, .Lssa___sem_release_Option$StreamFault_release_slow
.Lssa___sem_release_Option$StreamFault_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Option$StreamFault_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Option$StreamFault_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$StreamFault_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$StreamFault_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Option$StreamFault_uq0:
    b.ne .Lssa___sem_release_Option$StreamFault_3
.Lssa___sem_release_Option$StreamFault_1:
    mov x0, x19
    bl __fn___sem_drop_Option$StreamFault.r
.Lssa___sem_release_Option$StreamFault_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$StreamFault_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_Option$StreamFault_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_Option$StreamFault_rcdece3
.Lssa___sem_release_Option$StreamFault_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_Option$StreamFault_rcdeck3:
    mov x0, x19
.Lssa___sem_release_Option$StreamFault_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_len
.weak __fn___sem_view_len.k
__fn___sem_view_len:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_len.k:
__fn___sem_view_len.r:
.Lssa___sem_view_len_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_len_3
.Lssa___sem_view_len_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #8]
    mov x0, x10
    ret
.Lssa___sem_view_len_3:
    ldr x10, [x0, #0]
    mov x0, x10
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_data
.weak __fn___sem_view_data.k
__fn___sem_view_data:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_data.k:
__fn___sem_view_data.r:
.Lssa___sem_view_data_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_data_3
.Lssa___sem_view_data_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #0]
    mov x0, x10
    ret
.Lssa___sem_view_data_3:
    add x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_slice
.weak __fn___sem_byte_view_slice.k
__fn___sem_byte_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_byte_view_slice.k:
__fn___sem_byte_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_byte_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_byte_view_slice_3
.Lssa___sem_byte_view_slice_1:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_byte_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_byte_view_slice_6
.Lssa___sem_byte_view_slice_4:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_byte_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_byte_view_slice_9
.Lssa___sem_byte_view_slice_7:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_byte_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    add x0, x0, x20
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice
.weak __fn___sem_view_slice.k
__fn___sem_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice.k:
__fn___sem_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_3
.Lssa___sem_view_slice_1:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_6
.Lssa___sem_view_slice_4:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_9
.Lssa___sem_view_slice_7:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice_wide
.weak __fn___sem_view_slice_wide.k
__fn___sem_view_slice_wide:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice_wide.k:
__fn___sem_view_slice_wide.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_wide_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_wide_3
.Lssa___sem_view_slice_wide_1:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_wide_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_wide_6
.Lssa___sem_view_slice_wide_4:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_wide_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_wide_9
.Lssa___sem_view_slice_wide_7:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_wide_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_release
.weak __fn___sem_view_release.k
__fn___sem_view_release:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_release.k:
__fn___sem_view_release.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_view_release_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_release_3
.Lssa___sem_view_release_1:
    mov x9, #-2
    add x9, x0, x9
    str x9, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_view_release_3:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_view_release_rcdeck6
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_view_release_rcdecd6
    tbnz w5, #31, .Lssa___sem_view_release_rcdeck6
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_view_release_rcdece6
.Lssa___sem_view_release_rcdecd6:
    sub w5, w5, #1
    stur w5, [x0, #-8]
.Lssa___sem_view_release_rcdeck6:
.Lssa___sem_view_release_rcdece6:
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_string
.weak __fn___sem_byte_view_string.k
__fn___sem_byte_view_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_byte_view_string.k:
__fn___sem_byte_view_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_string_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_byte_view_string_3
.Lssa___sem_byte_view_string_1:
    mov x9, #-2
    add x9, x0, x9
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_string_3:
    str x0, [sp, #-16]!
    bl __fn___fern_string_from_bytes_u8
    add sp, sp, #16
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_mismatch
.weak __fn___sem_byte_view_mismatch.k
__fn___sem_byte_view_mismatch:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___sem_byte_view_mismatch.k:
__fn___sem_byte_view_mismatch.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_mismatch_0:
    mov x13, #2
    and x13, x0, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_3
.Lssa___sem_byte_view_mismatch_1:
    mov x13, #2
    and x13, x10, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_6
.Lssa___sem_byte_view_mismatch_4:
    mov x13, #-2
    add x13, x0, x13
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    mov x0, x13
    ldr x5, [x0, #8]
    ldr x0, [x0]
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L174_aop
    mov x1, #0
.L174_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L174_bop
    mov x3, #0
.L174_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L174_nok
    mov x4, #0
.L174_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L174_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L174_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L174_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L174_vec
.L174_short:
    cmp x10, #8
    b.lt .L174_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L174_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L174_eq
    add x8, x8, x14
.L174_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_w4:
    cmp x10, #4
    b.lt .L174_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L174_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L174_eq
    add x8, x8, x14
.L174_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_w2:
    cmp x10, #2
    b.lt .L174_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L174_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L174_eq
    add x8, x8, x14
.L174_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L174_done
.L174_tail:
    cmp x8, x13
    b.ge .L174_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L174_th
    add x8, x8, #1
    add x9, x9, #1
    b .L174_tail
.L174_th:
    sub x2, x8, x12
    b .L174_done
.L174_eq:
    mov x2, x4
.L174_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_6:
    mov x15, #-2
    add x15, x0, x15
    mov x4, x12
    mov x3, x9
    mov x2, x15
    mov x1, x11
    mov x0, x10
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L175_aop
    mov x1, #0
.L175_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L175_bop
    mov x3, #0
.L175_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L175_nok
    mov x4, #0
.L175_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L175_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L175_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L175_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L175_vec
.L175_short:
    cmp x10, #8
    b.lt .L175_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L175_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L175_eq
    add x8, x8, x14
.L175_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_w4:
    cmp x10, #4
    b.lt .L175_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L175_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L175_eq
    add x8, x8, x14
.L175_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_w2:
    cmp x10, #2
    b.lt .L175_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L175_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L175_eq
    add x8, x8, x14
.L175_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L175_done
.L175_tail:
    cmp x8, x13
    b.ge .L175_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L175_th
    add x8, x8, #1
    add x9, x9, #1
    b .L175_tail
.L175_th:
    sub x2, x8, x12
    b .L175_done
.L175_eq:
    mov x2, x4
.L175_done:
    mov x14, x2
    mov x0, x14
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_3:
    mov x14, #2
    and x14, x10, x14
    cbz x14, .Lssa___sem_byte_view_mismatch_9
.Lssa___sem_byte_view_mismatch_7:
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L176_aop
    mov x1, #0
.L176_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L176_bop
    mov x3, #0
.L176_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L176_nok
    mov x4, #0
.L176_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L176_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L176_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L176_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L176_done
.L176_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L176_vec
.L176_short:
    cmp x10, #8
    b.lt .L176_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L176_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L176_eq
    add x8, x8, x14
.L176_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L176_done
.L176_w4:
    cmp x10, #4
    b.lt .L176_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L176_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L176_eq
    add x8, x8, x14
.L176_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L176_done
.L176_w2:
    cmp x10, #2
    b.lt .L176_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L176_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L176_eq
    add x8, x8, x14
.L176_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L176_done
.L176_tail:
    cmp x8, x13
    b.ge .L176_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L176_th
    add x8, x8, #1
    add x9, x9, #1
    b .L176_tail
.L176_th:
    sub x2, x8, x12
    b .L176_done
.L176_eq:
    mov x2, x4
.L176_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_9:
    mov x4, x12
    mov x3, x11
    mov x2, x10
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2]
    add x2, x2, #8
    cmp x1, #0
    b.ge .L177_aop
    mov x1, #0
.L177_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L177_bop
    mov x3, #0
.L177_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L177_nok
    mov x4, #0
.L177_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L177_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L177_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L177_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L177_done
.L177_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L177_vec
.L177_short:
    cmp x10, #8
    b.lt .L177_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L177_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L177_eq
    add x8, x8, x14
.L177_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L177_done
.L177_w4:
    cmp x10, #4
    b.lt .L177_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L177_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L177_eq
    add x8, x8, x14
.L177_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L177_done
.L177_w2:
    cmp x10, #2
    b.lt .L177_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L177_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L177_eq
    add x8, x8, x14
.L177_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L177_done
.L177_tail:
    cmp x8, x13
    b.ge .L177_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L177_th
    add x8, x8, #1
    add x9, x9, #1
    b .L177_tail
.L177_th:
    sub x2, x8, x12
    b .L177_done
.L177_eq:
    mov x2, x4
.L177_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
_start:
    adrp x9, .Lfern_relanchor
    add x9, x9, :lo12:.Lfern_relanchor
    ldr x10, [x9]
    sub x9, x9, x10
    cbz x9, .Lfern_reloc_done
    adrp x11, .Lfern_sbox_begin
    add x11, x11, :lo12:.Lfern_sbox_begin
    adrp x12, .Lfern_sbox_end
    add x12, x12, :lo12:.Lfern_sbox_end
.Lfern_sbox_loop:
    cmp x11, x12
    b.hs .Lfern_sbox_done
    ldr x13, [x11, #8]
    add x13, x13, x9
    str x13, [x11, #8]
    add x11, x11, #24
    b .Lfern_sbox_loop
.Lfern_sbox_done:
    adrp x11, .Lfern_cagg_begin
    add x11, x11, :lo12:.Lfern_cagg_begin
    adrp x12, .Lfern_cagg_end
    add x12, x12, :lo12:.Lfern_cagg_end
.Lfern_cagg_loop:
    cmp x11, x12
    b.hs .Lfern_cagg_done
    ldr x13, [x11, #16]
    add x13, x13, x9
    str x13, [x11, #16]
    ldr x14, [x11]
    add x11, x11, #16
    add x11, x11, x14, lsl #3
    b .Lfern_cagg_loop
.Lfern_cagg_done:
    adrp x11, .Lfern_cfn_begin
    add x11, x11, :lo12:.Lfern_cfn_begin
    adrp x12, .Lfern_cfn_end
    add x12, x12, :lo12:.Lfern_cfn_end
.Lfern_cfn_loop:
    cmp x11, x12
    b.hs .Lfern_cfn_done
    ldr x13, [x11, #24]
    add x13, x13, x9
    str x13, [x11, #24]
    add x11, x11, #32
    b .Lfern_cfn_loop
.Lfern_cfn_done:
    adrp x11, .Lfern_cref_begin
    add x11, x11, :lo12:.Lfern_cref_begin
    adrp x12, .Lfern_cref_end
    add x12, x12, :lo12:.Lfern_cref_end
.Lfern_cref_loop:
    cmp x11, x12
    b.hs .Lfern_reloc_done
    ldr x13, [x11]
    add x13, x13, x9
    ldr x14, [x13]
    add x14, x14, x9
    str x14, [x13]
    add x11, x11, #8
    b .Lfern_cref_loop
.Lfern_reloc_done:
    ldr x0, [sp]
    lsl x0, x0, #3
    add x0, x0, #16
    add x0, sp, x0
    adrp x1, __fern_envp
    add x1, x1, :lo12:__fern_envp
    str x0, [x1]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #30
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_stack_kept
    mov x19, x0
    mov x1, #1
    lsl x1, x1, #20
    mov x2, #0
    mov x8, #226
    svc #0
    cbnz x0, .Lfern_stack_guard_failed
    mov x9, #1
    lsl x9, x9, #30
    add x9, x19, x9
    sub sp, x9, #16
    mov x10, sp
    adrp x11, __fern_stack_top
    add x11, x11, :lo12:__fern_stack_top
    str x10, [x11]
.Lfern_stack_kept:
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #16
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_signal_stack_map_failed
    mov x9, #1
    lsl x9, x9, #16
    sub sp, sp, #32
    stp x0, xzr, [sp]
    str x9, [sp, #16]
    mov x0, sp
    mov x1, #0
    mov x8, #132
    svc #0
    cbnz x0, .Lfern_signal_stack_failed
    adrp x9, __fern_segv
    add x9, x9, :lo12:__fern_segv
    mov x10, #4
    movk x10, #0x800, lsl #16
    mov x11, #0
    stp x9, x10, [sp]
    stp x11, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_handler_failed
    add sp, sp, #32
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    bl __fn_main
    mov x8, #94
    svc #0
__fn___fern_str_concat:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_concat.k:
__fn___fern_str_concat.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_concat_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    add x9, x21, x22
    sxtw x23, w9
    mov x0, x23
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    ldr x9, [x19, #0]
    mov x2, x21
    mov x1, x9
    mov x0, x24
    cbz x2, .Lssa___fern_str_concat_mcd18
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb18
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc18:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct18
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc18
.Lssa___fern_str_concat_mct18:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd18
.Lssa___fern_str_concat_mcb18:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb18
.Lssa___fern_str_concat_mcd18:
    mov x0, #0
    sxtw x21, w21
    add x21, x24, x21
    ldr x9, [x20, #0]
    mov x2, x22
    mov x1, x9
    mov x0, x21
    cbz x2, .Lssa___fern_str_concat_mcd34
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb34
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc34:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct34
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc34
.Lssa___fern_str_concat_mct34:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd34
.Lssa___fern_str_concat_mcb34:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb34
.Lssa___fern_str_concat_mcd34:
    mov x0, #0
    mov x0, x24
    mov x1, x23
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_eq:
    ldr x0, [sp]
    ldr x9, [sp, #16]
__fn___fern_str_eq.r:
    cmp x0, x9
    b.eq .Lseq_yes
    ldr x4, [x0, #8]
    ldr x5, [x9, #8]
    cmp x4, x5
    b.ne .Lseq_no
    ldr x2, [x0]
    ldr x3, [x9]
    cmp x2, x3
    b.eq .Lseq_yes
    add x6, x2, x4
    add x7, x3, x4
    cmp x4, #8
    b.lo .Lseq_short
    sub x6, x6, #8
    sub x7, x7, #8
.Lseq_word:
    ldr x0, [x2]
    ldr x1, [x3]
    cmp x0, x1
    b.ne .Lseq_no
    add x2, x2, #8
    add x3, x3, #8
    cmp x2, x6
    b.lo .Lseq_word
    ldr x0, [x6]
    ldr x1, [x7]
    cmp x0, x1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_short:
    cbz x4, .Lseq_yes
    cmp x4, #4
    b.lo .Lseq_byte
    ldr w0, [x2]
    ldr w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #4
    sub x7, x7, #4
    ldr w0, [x6]
    ldr w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_byte:
    ldrb w0, [x2]
    ldrb w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #1
    sub x7, x7, #1
    ldrb w0, [x6]
    ldrb w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    cmp x4, #3
    b.lo .Lseq_yes
    ldrb w0, [x2, #1]
    ldrb w1, [x3, #1]
    cmp w0, w1
    b.ne .Lseq_no
.Lseq_yes:
    mov x0, #1
    ret
.Lseq_no:
    mov x0, #0
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .bss
    .align 3
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 3
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 3
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 3
__fern_rc_underflow: .quad 0
    .align 3
__fern_map_seed: .quad 0
    .align 3
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 3
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 3
__fern_freelist_shadow: .skip 524288
    .align 3
__fern_large_freelist_shadow: .skip 20480
    .text
.globl __fern_capw
__fern_capw:
    stp x9, x10, [sp, #-32]!
    str x11, [sp, #16]
    ldr x9, [sp, #32]
    cmp x9, #256
    b.ls .Lcapw_ret
    clz x10, x9
    mov x11, #61
    sub x10, x11, x10
    mov x11, #1
    lsl x11, x11, x10
    add x9, x9, x11
    sub x9, x9, #1
    neg x11, x11
    and x9, x9, x11
    mov x10, #0x10000
    cmp x9, x10
    b.lo .Lcapw_store
    mov x9, #65535
.Lcapw_store:
    str x9, [sp, #32]
.Lcapw_ret:
    ldr x11, [sp, #16]
    ldp x9, x10, [sp], #32
    ret
.globl __fern_alloc
.type __fern_alloc, %function
__fern_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    add x0, x0, #7
    lsr x3, x0, #3
    lsl x0, x3, #3
    mov x2, #0x10000
    cmp x3, x2
    b.hs .Lalloc_large
    cmp x3, #256
    b.ls .L178
    str x3, [sp, #-16]!
    bl __fern_capw
    ldr x3, [sp], #16
.L178:
    lsl x0, x3, #3
    adrp x1, __fern_freelist
    add x1, x1, :lo12:__fern_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_large:
    mov x1, #1
    lsl x1, x1, #34
    cmp x0, x1
    b.hi .Lalloc_nofl
    mov x1, #1
    lsl x1, x1, #19
    cmp x0, x1
    csel x0, x1, x0, lo
    clz x1, x0
    mov x3, #61
    sub x3, x3, x1
    mov x1, #1
    lsl x1, x1, x3
    sub x1, x1, #1
    add x0, x0, x1
    bic x0, x0, x1
    clz x1, x0
    mov x3, #61
    sub x1, x3, x1
    lsr x3, x0, x1
    add x3, x3, x1, lsl #2
    sub x3, x3, #72
    adrp x1, __fern_large_freelist
    add x1, x1, :lo12:__fern_large_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_nofl:
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    ldr x2, [x1]
    cbnz x2, .Lalloc_inited
    stp x4, x5, [sp, #-16]!
    stp x8, x9, [sp, #-16]!
    mov x9, x0
    mov x0, #1
    lsl x0, x0, #28
    movz x1, #0
    movk x1, #4, lsl #32
    mov x2, #3
    mov x3, #0x4022
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    cmn x0, #0
    b.mi .Lalloc_map_fail
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    str x0, [x1]
    adrp x1, __fern_heap_base
    add x1, x1, :lo12:__fern_heap_base
    str x0, [x1]
    movz x2, #0
    movk x2, #4, lsl #32
    add x2, x0, x2
    adrp x3, __fern_heap_end
    add x3, x3, :lo12:__fern_heap_end
    str x2, [x3]
    mov x0, x9
    ldp x8, x9, [sp], #16
    ldp x4, x5, [sp], #16
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
.Lalloc_inited:
    ldr x2, [x1]
    adds x3, x2, x0
    b.cs __fern_alloc_size_abort
    str x4, [sp, #-16]!
    adrp x4, __fern_heap_end
    add x4, x4, :lo12:__fern_heap_end
    ldr x4, [x4]
    cmp x3, x4
    ldr x4, [sp], #16
    b.hi .Lalloc_oom
    str x3, [x1]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .text
.Lalloc_oom:
    adrp x1, .Lmsg_oom
    add x1, x1, :lo12:.Lmsg_oom
    mov x2, #43
    mov x0, #125
    b __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .text
.Lalloc_map_fail:
    neg x9, x0
    sub sp, sp, #96
    add x10, sp, #96
    mov x12, #10
    sub x10, x10, #1
    strb w12, [x10]
    mov x11, #41
    sub x10, x10, #1
    strb w11, [x10]
.Lmap_fail_digit:
    udiv x13, x9, x12
    msub x14, x13, x12, x9
    add x14, x14, #48
    sub x10, x10, #1
    strb w14, [x10]
    mov x9, x13
    cbnz x9, .Lmap_fail_digit
    adrp x15, .Lmsg_map_fail
    add x15, x15, :lo12:.Lmsg_map_fail
    add x15, x15, #42
    mov x11, #42
.Lmap_fail_copy:
    sub x15, x15, #1
    ldrb w14, [x15]
    sub x10, x10, #1
    strb w14, [x10]
    subs x11, x11, #1
    b.ne .Lmap_fail_copy
    mov x1, x10
    add x2, sp, #96
    sub x2, x2, x10
    mov x0, #123
    b __fern_report
.size __fern_alloc, .-__fern_alloc
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .text
__fern_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_oob_abort
.type __fern_oob_abort, %function
__fern_oob_abort:
    adrp x1, .Lmsg_arr_oob
    add x1, x1, :lo12:.Lmsg_arr_oob
    mov x2, #31
    b __fern_abort_134
.size __fern_oob_abort, .-__fern_oob_abort
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .text
__fern_str_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_str_oob_abort
.type __fern_str_oob_abort, %function
__fern_str_oob_abort:
    adrp x1, .Lmsg_str_oob
    add x1, x1, :lo12:.Lmsg_str_oob
    mov x2, #32
    b __fern_abort_134
.size __fern_str_oob_abort, .-__fern_str_oob_abort
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .text
__fern_slice_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_slice_abort
.type __fern_slice_abort, %function
__fern_slice_abort:
    adrp x1, .Lmsg_slice
    add x1, x1, :lo12:.Lmsg_slice
    mov x2, #32
    b __fern_abort_134
.size __fern_slice_abort, .-__fern_slice_abort
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .text
__fern_alloc_size_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_alloc_size_abort
.type __fern_alloc_size_abort, %function
__fern_alloc_size_abort:
    adrp x1, .Lmsg_alloc_size
    add x1, x1, :lo12:.Lmsg_alloc_size
    mov x2, #35
    b __fern_abort_134
.size __fern_alloc_size_abort, .-__fern_alloc_size_abort
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .text
.globl __fern_free_range_abort
.type __fern_free_range_abort, %function
__fern_free_range_abort:
    adrp x1, .Lmsg_free_range
    add x1, x1, :lo12:.Lmsg_free_range
    mov x2, #41
    b __fern_abort_134
.size __fern_free_range_abort, .-__fern_free_range_abort
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .text
__fern_double_free_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_double_free_abort
.type __fern_double_free_abort, %function
__fern_double_free_abort:
    adrp x1, .Lmsg_double_free
    add x1, x1, :lo12:.Lmsg_double_free
    mov x2, #45
    b __fern_abort_134
.size __fern_double_free_abort, .-__fern_double_free_abort
__fern_arr_box:
    movz x1, #65535
    movk x1, #4095, lsl #16
    cmp x0, x1
    b.ls .Larrbox_sized
    b __fern_alloc_size_abort_leaf
.Larrbox_sized:
    add x1, x0, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Larrbox_alloc
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    add x1, x2, x1
    ldr x2, [x1]
    cbz x2, .Larrbox_miss
    ldr x3, [x2]
    str x3, [x1]
    str x0, [x2]
    mov w3, #1
    str w3, [x2, #8]
    str x0, [x2, #16]
    add x0, x2, #16
    ret
.Larrbox_miss:
    add x1, x0, #3
    lsl x1, x1, #3
.Larrbox_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    mov x0, x1
    bl __fern_alloc
    ldr x1, [sp]
    str x1, [x0]
    mov w2, #1
    str w2, [x0, #8]
    str x1, [x0, #16]
    add x0, x0, #16
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
__fern_str_box:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x0, #24
    bl __fern_alloc
    mov x2, #1
    str x2, [x0]
    ldp x2, x3, [sp], #16
    str x2, [x0, #8]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fern_str_box_hdr:
    sub x2, x0, #24
    mov w3, #1
    str w3, [x2]
    mov w4, #32781
    movk w4, #29519, lsl #16
    stur w4, [x2, #4]
    str x0, [x2, #8]
    str x1, [x2, #16]
    add x0, x2, #8
    ret
.globl __fern_buf_new
.type __fern_buf_new, %function
__fern_buf_new:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cmp x19, #16
    b.hs .Lbufnew_cap
    mov x19, #16
.Lbufnew_cap:
    mov x0, #32
    bl __fern_alloc
    mov x20, x0
    mov x0, x19
    bl __fern_alloc
    str x0, [x20]
    str xzr, [x20, #8]
    str x19, [x20, #16]
    str x19, [x20, #24]
    mov x0, x20
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_new, .-__fern_buf_new
.globl __fern_buf_reserve
.type __fern_buf_reserve, %function
__fern_buf_reserve:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19, #16]
    cbnz x21, .Lbufres_dbl
    ldr x21, [x19, #24]
    cbnz x21, .Lbufres_dbl
    mov x21, #64
.Lbufres_dbl:
    cmp x21, x20
    b.hs .Lbufres_alloc
    lsl x21, x21, #1
    b .Lbufres_dbl
.Lbufres_alloc:
    mov x0, x21
    bl __fern_alloc
    mov x22, x0
    ldr x2, [x19, #8]
    cbz x2, .Lbufres_nocopy
    ldr x1, [x19]
    mov x3, x22
    cbz x2, .Lbufres_copy_d
    cmp x2, #8
    b.lo .Lbufres_copy_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x3, x2
    sub x11, x11, #8
.Lbufres_copy_w:
    cmp x3, x11
    b.hs .Lbufres_copy_t
    ldr x9, [x1], #8
    str x9, [x3], #8
    b .Lbufres_copy_w
.Lbufres_copy_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufres_copy_d
.Lbufres_copy_b:
    ldrb w9, [x1], #1
    strb w9, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufres_copy_b
.Lbufres_copy_d:
.Lbufres_nocopy:
    ldr x5, [x19]
    cbz x5, .Lbufres_store
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbufres_old_large
    cmp x6, #256
    b.ls .L179
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L179:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbufres_old_done
.Lbufres_old_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbufres_old_done:
.Lbufres_store:
    str x22, [x19]
    str x21, [x19, #16]
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_reserve, .-__fern_buf_reserve
.globl __fern_buf_push
.type __fern_buf_push, %function
__fern_buf_push:
    ldrsw x3, [x1, #8]
    cbz x3, .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufpush_grow
    str x5, [x0, #8]
    ldr x1, [x1]
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
    b .Lbufrange_tail
.Lbufpush_grow:
    mov x2, #0
    b .Lbufrange_grow
.size __fern_buf_push, .-__fern_buf_push
.globl __fern_buf_push_range
.type __fern_buf_push_range, %function
__fern_buf_push_range:
    sxtw x2, w2
    sxtw x3, w3
    tbz x2, #63, .Lbufrange_lo
    b __fern_slice_abort_leaf
.Lbufrange_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lbufrange_hi
    b __fern_slice_abort_leaf
.Lbufrange_hi:
    subs x3, x3, x2
    b.ge .Lbufrange_range
    b __fern_slice_abort_leaf
.Lbufrange_range:
    b.eq .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufrange_grow
.Lbufrange_copy:
    str x5, [x0, #8]
    ldr x1, [x1]
    add x1, x1, x2
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
.Lbufrange_tail:
    cbz x2, .Lbufrange_done
    cmp x2, #8
    b.lo .Lbufrange_loop_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x6, x2
    sub x11, x11, #8
.Lbufrange_loop_w:
    cmp x6, x11
    b.hs .Lbufrange_loop_t
    ldr x9, [x1], #8
    str x9, [x6], #8
    b .Lbufrange_loop_w
.Lbufrange_loop_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufrange_done
.Lbufrange_loop_b:
    ldrb w9, [x1], #1
    strb w9, [x6], #1
    sub x2, x2, #1
    cbnz x2, .Lbufrange_loop_b
.Lbufrange_done:
    ret
.Lbufrange_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    stp x2, x3, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x2, x3, [sp], #16
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, x3
    b .Lbufrange_copy
.size __fern_buf_push_range, .-__fern_buf_push_range
.globl __fern_buf_push_mapped
.type __fern_buf_push_mapped, %function
__fern_buf_push_mapped:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    mov x21, x2
    ldr x22, [x20, #8]
    cbz x22, .Lbufmap_done
    ldr x0, [x19, #8]
    add x0, x0, x22
    ldr x1, [x19, #16]
    cmp x0, x1
    b.ls .Lbufmap_fits
    mov x1, x0
    mov x0, x19
    bl __fern_buf_reserve
.Lbufmap_fits:
    ldr x1, [x20]
    ldr x3, [x19]
    ldr x4, [x19, #8]
    add x3, x3, x4
    ldr x4, [x21]
    mov x2, x22
    cmp x4, #256
    b.lo .Lbufmap_short
.Lbufmap_full:
    ldrb w5, [x1], #1
    add x6, x21, x5, lsl #3
    ldrb w5, [x6, #8]
    strb w5, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufmap_full
    b .Lbufmap_len
.Lbufmap_short:
    ldrb w5, [x1], #1
    cmp x5, x4
    b.hs .Lbufmap_keep
    add x6, x21, x5, lsl #3
    ldrb w5, [x6, #8]
.Lbufmap_keep:
    strb w5, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufmap_short
.Lbufmap_len:
    ldr x0, [x19, #8]
    add x0, x0, x22
    str x0, [x19, #8]
.Lbufmap_done:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_push_mapped, .-__fern_buf_push_mapped
.globl __fern_buf_push_filtered
.type __fern_buf_push_filtered, %function
__fern_buf_push_filtered:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    mov x21, x2
    ldr x22, [x20, #8]
    cbz x22, .Lbuffilt_done
    ldr x0, [x19, #8]
    add x0, x0, x22
    ldr x1, [x19, #16]
    cmp x0, x1
    b.ls .Lbuffilt_fits
    mov x1, x0
    mov x0, x19
    bl __fern_buf_reserve
.Lbuffilt_fits:
    ldr x1, [x20]
    ldr x3, [x19]
    ldr x4, [x19, #8]
    add x3, x3, x4
    ldr x4, [x21]
    mov x2, x22
    mov x7, #0
    cmp x4, #256
    b.lo .Lbuffilt_loop
.Lbuffilt_full:
    ldrb w5, [x1], #1
    add x6, x21, x5, lsl #3
    ldrb w6, [x6, #8]
    strb w5, [x3, x7]
    cmp w6, #0
    cinc x7, x7, eq
    sub x2, x2, #1
    cbnz x2, .Lbuffilt_full
    b .Lbuffilt_len
.Lbuffilt_loop:
    ldrb w5, [x1], #1
    cmp x5, x4
    b.hs .Lbuffilt_keep
    add x6, x21, x5, lsl #3
    ldrb w6, [x6, #8]
    cbnz w6, .Lbuffilt_next
.Lbuffilt_keep:
    strb w5, [x3], #1
    add x7, x7, #1
.Lbuffilt_next:
    sub x2, x2, #1
    cbnz x2, .Lbuffilt_loop
.Lbuffilt_len:
    ldr x0, [x19, #8]
    add x0, x0, x7
    str x0, [x19, #8]
.Lbuffilt_done:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_push_filtered, .-__fern_buf_push_filtered
.globl __fern_buf_push_expanded
.type __fern_buf_push_expanded, %function
__fern_buf_push_expanded:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    mov x21, x2
    ldr x22, [x20, #8]
    cbz x22, .Lbufexp_done
    lsl x0, x22, #3
    add x0, x0, #8
    ldr x1, [x19, #8]
    add x0, x0, x1
    ldr x1, [x19, #16]
    cmp x0, x1
    b.ls .Lbufexp_fits
    mov x1, x0
    mov x0, x19
    bl __fern_buf_reserve
.Lbufexp_fits:
    ldr x1, [x20]
    ldr x3, [x19]
    ldr x4, [x19, #8]
    add x3, x3, x4
    ldr x4, [x21]
    lsr x4, x4, #3
    mov x2, x22
    cmp x4, #256
    b.lo .Lbufexp_loop
    cmp x2, #256
    b.lo .Lbufexp_loop
    sub sp, sp, #2048
    add x6, x21, #8
    mov x7, #0
.Lbufexp_pack:
    ldr x8, [x6, x7, lsl #3]
    strb w8, [sp, x7]
    add x7, x7, #1
    cmp x7, #2048
    b.lo .Lbufexp_pack
    mov x9, #7
.Lbufexp_fast:
    ldrb w5, [x1], #1
    ldr x8, [sp, x5, lsl #3]
    and x7, x8, #255
    cmp x7, x9
    csel x7, x7, x9, ls
    lsr x8, x8, #8
    str x8, [x3]
    add x3, x3, x7
    subs x2, x2, #1
    b.ne .Lbufexp_fast
    add sp, sp, #2048
    b .Lbufexp_len
.Lbufexp_loop:
    cbz x2, .Lbufexp_len
    ldrb w5, [x1], #1
    cmp x5, x4
    b.hs .Lbufexp_keep
    add x6, x21, x5, lsl #6
    ldr x7, [x6, #8]
    cmp x7, #7
    b.ls .Lbufexp_room
    mov x7, #7
.Lbufexp_room:
    add x6, x6, #16
.Lbufexp_byte:
    cbz x7, .Lbufexp_next
    ldr x8, [x6], #8
    strb w8, [x3], #1
    sub x7, x7, #1
    b .Lbufexp_byte
.Lbufexp_keep:
    strb w5, [x3], #1
.Lbufexp_next:
    sub x2, x2, #1
    b .Lbufexp_loop
.Lbufexp_len:
    ldr x0, [x19]
    sub x3, x3, x0
    str x3, [x19, #8]
.Lbufexp_done:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_push_expanded, .-__fern_buf_push_expanded
.globl __fern_buf_push_byte
.type __fern_buf_push_byte, %function
__fern_buf_push_byte:
    ldr x4, [x0, #8]
    add x5, x4, #1
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufbyte_grow
.Lbufbyte_fits:
    ldr x6, [x0]
    strb w1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufbyte_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #1
    b .Lbufbyte_fits
.size __fern_buf_push_byte, .-__fern_buf_push_byte
.globl __fern_buf_push_u64
.type __fern_buf_push_u64, %function
__fern_buf_push_u64:
    ldr x4, [x0, #8]
    add x5, x4, #8
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufu64_grow
.Lbufu64_fits:
    ldr x6, [x0]
    str x1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufu64_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #8
    b .Lbufu64_fits
.size __fern_buf_push_u64, .-__fern_buf_push_u64
.globl __fern_buf_push_decimal
.type __fern_buf_push_decimal, %function
__fern_buf_push_decimal:
    stp x29, x30, [sp, #-64]!
    mov x29, sp
    add x8, sp, #40
    adrp x11, .Ldecimal_pairs
    add x11, x11, :lo12:.Ldecimal_pairs
    mov x9, #0xf5c3
    movk x9, #0x5c28, lsl #16
    movk x9, #0xc28f, lsl #32
    movk x9, #0x28f5, lsl #48
    mov x12, #100
.Ldecimal_loop:
    cmp x1, #100
    b.lo .Ldecimal_tail
    lsr x10, x1, #2
    umulh x10, x10, x9
    lsr x10, x10, #2
    msub x13, x10, x12, x1
    ldrh w13, [x11, x13, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    mov x1, x10
    b .Ldecimal_loop
.Ldecimal_tail:
    cmp x1, #10
    b.lo .Ldecimal_one
    ldrh w13, [x11, x1, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    b .Ldecimal_copy
.Ldecimal_one:
    add w13, w1, #48
    sub x8, x8, #1
    strb w13, [x8]
.Ldecimal_copy:
    add x2, sp, #40
    sub x2, x2, x8
    ldr x3, [x0, #8]
    add x4, x3, x2
    ldr x5, [x0, #16]
    cmp x4, x5
    b.hi .Ldecimal_grow
.Ldecimal_fits:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x3
.Ldecimal_byte:
    ldrb w6, [x8], #1
    strb w6, [x5], #1
    subs x2, x2, #1
    b.ne .Ldecimal_byte
    ldp x29, x30, [sp], #64
    ret
.Ldecimal_grow:
    str x0, [sp, #40]
    stp x2, x8, [sp, #48]
    mov x1, x4
    bl __fern_buf_reserve
    ldr x0, [sp, #40]
    ldp x2, x8, [sp, #48]
    ldr x3, [x0, #8]
    add x4, x3, x2
    b .Ldecimal_fits
.size __fern_buf_push_decimal, .-__fern_buf_push_decimal
    .section .rodata
.Ldecimal_pairs:
    .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
    .text
.globl __fern_buf_len
.type __fern_buf_len, %function
__fern_buf_len:
    ldr x0, [x0, #8]
    ret
.size __fern_buf_len, .-__fern_buf_len
.globl __fern_buf_clear
.type __fern_buf_clear, %function
__fern_buf_clear:
    str xzr, [x0, #8]
    mov x0, #0
    ret
.size __fern_buf_clear, .-__fern_buf_clear
.globl __fern_buf_take
.type __fern_buf_take, %function
__fern_buf_take:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    bl __fn___fern_buf_take_text
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_take, .-__fern_buf_take
__fn___fern_buf_text_part:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_buf_text_part.k:
__fn___fern_buf_text_part.r:
.Lssa___fern_buf_text_part_0:
    ldrb w11, [x0, x9]
    cmp x11, #128
    b.ge .Lssa___fern_buf_text_part_20
.Lssa___fern_buf_text_part_22:
    mov x0, #1
    ret
.Lssa___fern_buf_text_part_20:
    cmp x11, #194
    b.lt .Lssa___fern_buf_text_part_17
.Lssa___fern_buf_text_part_19:
    cmp x11, #223
    b.gt .Lssa___fern_buf_text_part_17
.Lssa___fern_buf_text_part_18:
    mov x12, #2
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_17:
    cmp x11, #224
    b.lt .Lssa___fern_buf_text_part_14
.Lssa___fern_buf_text_part_16:
    cmp x11, #239
    b.gt .Lssa___fern_buf_text_part_14
.Lssa___fern_buf_text_part_15:
    mov x12, #3
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_14:
    cmp x11, #240
    b.lt .Lssa___fern_buf_text_part_11
.Lssa___fern_buf_text_part_13:
    cmp x11, #244
    b.gt .Lssa___fern_buf_text_part_11
.Lssa___fern_buf_text_part_12:
    mov x12, #4
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_11:
    mov x12, #0
.Lssa___fern_buf_text_part_10:
.Lssa___fern_buf_text_part_9:
.Lssa___fern_buf_text_part_8:
.Lssa___fern_buf_text_part_7:
    sub x10, x10, x9
    sxtw x10, w10
    mov x13, #1
.Lssa___fern_buf_text_part_54:
    cmp x13, x12
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_69:
    cmp x13, x10
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_68:
    add x14, x9, x13
    sxtw x14, w14
    ldrb w15, [x0, x14]
    cmp x15, #128
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_67:
    cmp x15, #191
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_65:
    cmp x13, #1
    b.ne .Lssa___fern_buf_text_part_55
.Lssa___fern_buf_text_part_64:
    cmp x11, #224
    b.ne .Lssa___fern_buf_text_part_62
.Lssa___fern_buf_text_part_63:
    cmp x15, #160
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_62:
    cmp x11, #237
    b.ne .Lssa___fern_buf_text_part_60
.Lssa___fern_buf_text_part_61:
    cmp x15, #159
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_60:
    cmp x11, #240
    b.ne .Lssa___fern_buf_text_part_58
.Lssa___fern_buf_text_part_59:
    cmp x15, #144
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_58:
    cmp x11, #244
    b.ne .Lssa___fern_buf_text_part_55
.Lssa___fern_buf_text_part_57:
    cmp x15, #143
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_55:
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___fern_buf_text_part_69
.Lssa___fern_buf_text_part_4:
    mov x10, #0
    sub x10, x10, x13
    sxtw x10, w10
    cmp x13, x12
    csel x0, x13, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn___fern_buf_take_text:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_buf_take_text.k:
__fn___fern_buf_take_text.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x0
.Lssa___fern_buf_take_text_0:
    ldr x20, [x19, #8]
    cmp x20, #0
    b.lt .Lssa___fern_buf_take_text_16
.Lssa___fern_buf_take_text_17:
    movn w9, #32768, lsl #16
    cmp x20, x9
    b.le .Lssa___fern_buf_take_text_14
.Lssa___fern_buf_take_text_16:
    mov x9, #-1
    mov x0, x9
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x9, #0
    mov x1, x9
    bl __fern_str_box_hdr
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_14:
    sxtw x21, w20
    cmp x21, #0
    b.ne .Lssa___fern_buf_take_text_11
.Lssa___fern_buf_take_text_13:
    adrp x0, .SB4
    add x0, x0, :lo12:.SB4
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_11:
    ldr x22, [x19, #0]
    ldr x23, =9259542123273814144
.Lssa___fern_buf_take_text_10:
    mov x24, #0
    mov x25, #0
.Lssa___fern_buf_take_text_30:
    cmp x24, x21
    b.ge .Lssa___fern_buf_take_text_9
.Lssa___fern_buf_take_text_40:
    sub x10, x21, x24
    sxtw x10, w10
    cmp x10, #8
    b.lt .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_39:
    add x10, x22, x24
    ldr x9, [x10, #0]
    and x9, x9, x23
    cmp x9, #0
    b.ne .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_38:
    add x9, x24, #8
    sxtw x24, w9
    cmp x24, x21
    b.ge .Lssa___fern_buf_take_text_9
    b .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_34:
    mov x0, x22
    mov x9, x24
    mov x10, x21
    bl __fn___fern_buf_text_part.r
    cmp x0, #0
    b.ge .Lssa___fern_buf_take_text_32
.Lssa___fern_buf_take_text_33:
    add x9, x0, #3
    sxtw x9, w9
    add x9, x20, x9
    sub x10, x24, x0
    sxtw x10, w10
    mov x20, x9
    mov x24, x10
    mov x25, #1
    b .Lssa___fern_buf_take_text_30
.Lssa___fern_buf_take_text_32:
    add x24, x24, x0
    sxtw x24, w24
.Lssa___fern_buf_take_text_31:
    cmp x24, x21
    b.lt .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_9:
    movn w10, #32768, lsl #16
    cmp x20, x10
    b.le .Lssa___fern_buf_take_text_6
.Lssa___fern_buf_take_text_8:
    mov x10, #-1
    mov x0, x10
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x10, #0
    mov x1, x10
    bl __fern_str_box_hdr
    mov x9, x0
    mov x0, x9
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_6:
    sxtw x20, w20
    mov x0, x20
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    cbz x25, .Lssa___fern_buf_take_text_2
.Lssa___fern_buf_take_text_5:
.Lssa___fern_buf_take_text_4:
    mov x25, #0
    mov x26, #0
    mov x27, #0
.Lssa___fern_buf_take_text_70:
    cmp x25, x21
    b.ge .Lssa___fern_buf_take_text_3
.Lssa___fern_buf_take_text_80:
    sub x9, x21, x25
    sxtw x9, w9
    cmp x9, #8
    b.lt .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_79:
    add x9, x22, x25
    ldr x10, [x9, #0]
    and x10, x10, x23
    cmp x10, #0
    b.ne .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_78:
    add x10, x25, #8
    sxtw x25, w10
    cmp x25, x21
    b.ge .Lssa___fern_buf_take_text_3
    b .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_74:
    mov x0, x22
    mov x9, x25
    mov x10, x21
    bl __fn___fern_buf_text_part.r
    mov x28, x0
    cmp x28, #0
    b.ge .Lssa___fern_buf_take_text_72
.Lssa___fern_buf_take_text_73:
    sxtw x10, w27
    add x10, x24, x10
    add x9, x22, x26
    sub x11, x25, x26
    sxtw x11, w11
    str x11, [sp, #56]
    mov x2, x11
    mov x1, x9
    mov x0, x10
    cbz x2, .Lssa___fern_buf_take_text_mcd338
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb338
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc338:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct338
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc338
.Lssa___fern_buf_take_text_mct338:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd338
.Lssa___fern_buf_take_text_mcb338:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb338
.Lssa___fern_buf_take_text_mcd338:
    mov x0, #0
    ldr x11, [sp, #56]
    add x11, x27, x11
    sxtw x11, w11
    mov x9, #239
    strb w9, [x24, x11]
    add x10, x11, #1
    sxtw x10, w10
    mov x9, #191
    strb w9, [x24, x10]
    add x12, x11, #2
    sxtw x12, w12
    mov x9, #189
    strb w9, [x24, x12]
    add x11, x11, #3
    sub x10, x25, x28
    sxtw x10, w10
    mov x25, x10
    mov x26, x10
    mov x27, x11
    b .Lssa___fern_buf_take_text_70
.Lssa___fern_buf_take_text_72:
    add x25, x25, x28
    sxtw x25, w25
.Lssa___fern_buf_take_text_71:
    cmp x25, x21
    b.lt .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_3:
    sxtw x27, w27
    add x27, x24, x27
    add x10, x22, x26
    sub x26, x21, x26
    sxtw x26, w26
    mov x2, x26
    mov x1, x10
    mov x0, x27
    cbz x2, .Lssa___fern_buf_take_text_mcd435
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb435
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc435:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct435
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc435
.Lssa___fern_buf_take_text_mct435:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd435
.Lssa___fern_buf_take_text_mcb435:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb435
.Lssa___fern_buf_take_text_mcd435:
    mov x0, #0
    b .Lssa___fern_buf_take_text_1
.Lssa___fern_buf_take_text_2:
    mov x2, x21
    mov x1, x22
    mov x0, x24
    cbz x2, .Lssa___fern_buf_take_text_mcd442
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb442
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc442:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct442
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc442
.Lssa___fern_buf_take_text_mct442:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd442
.Lssa___fern_buf_take_text_mcb442:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb442
.Lssa___fern_buf_take_text_mcd442:
    mov x0, #0
.Lssa___fern_buf_take_text_1:
    mov x10, #0
    str x10, [x19, #8]
    mov x0, x24
    mov x1, x20
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.globl __fern_buf_free
.type __fern_buf_free, %function
__fern_buf_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cbz x19, .Lbuffree_ret
    ldr x5, [x19]
    cbz x5, .Lbuffree_ctl
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_data_large
    cmp x6, #256
    b.ls .L180
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L180:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbuffree_data_done
.Lbuffree_data_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbuffree_data_done:
.Lbuffree_ctl:
    mov x5, x19
    mov x6, #4
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_ctlblk_large
    cmp x6, #256
    b.ls .L181
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L181:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbuffree_ctlblk_done
.Lbuffree_ctlblk_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbuffree_ctlblk_done:
.Lbuffree_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_free, .-__fern_buf_free
__fn___alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    bl __fern_alloc
    ldp x29, x30, [sp], #16
    ret
__fn___free:
    ret
__fn___memset:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    ldr x2, [x29, #48]
    cbz x2, .Lfnmemset_done
.Lfnmemset_loop:
    strb w1, [x0], #1
    subs x2, x2, #1
    bne .Lfnmemset_loop
.Lfnmemset_done:
    ldp x29, x30, [sp], #16
    ret
__fn___load_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldrsw x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str w1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_i64:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str x1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___ptr_width:
    mov x0, #8
    ret
__fn___fern_rc_inc:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcinc_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcinc_ret
    and x0, x0, #0xfffffffffffffffd
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcinc_ret
    add w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcinc_ret:
    ldr x0, [sp]
    ret
__fn___fern_rc_dec:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcdec_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcdec_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcdec_ret
    cmp w1, #0
    bgt .Lshrcdec_dec
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w11, [x10]
    add w11, w11, #1
    str w11, [x10]
.Lshrcdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcdec_ret:
    ret
__fn___fern_rc_is_unique:
    ldr x2, [sp]
    mov x0, #0
    tbnz x2, #0, .Lshuniq_ret
    mov x9, #0x10000
    cmp x2, x9
    blo .Lshuniq_ret
    and x2, x2, #0xfffffffffffffffd
    ldur w3, [x2, #-8]
    tbnz w3, #31, .Lshuniq_ret
    cmp w3, #1
    bne .Lshuniq_ret
    mov x0, #1
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    ldr x0, [sp]
__fn___fern_arr_inc_elems.r:
    mov x9, #0x10000
    cmp x0, x9
    blo .Laie_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Laie_ret
    stp x19, x30, [sp, #-16]!
    stp x20, x21, [sp, #-16]!
    mov x19, x0
    ldr x20, [x19]
    mov x21, #0
.Laie_loop:
    cmp x21, x20
    bge .Laie_done
    add x9, x21, #1
    ldr x0, [x19, x9, lsl #3]
    str x0, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    add x21, x21, #1
    b .Laie_loop
.Laie_done:
    mov x0, x19
    ldp x20, x21, [sp], #16
    ldp x19, x30, [sp], #16
.Laie_ret:
    ret
__fn___fern_str_grow:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsg_body
__fn___fern_str_grow_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbnz x2, #63, .Lsg_no
    ldr x4, [x1, #8]
    cmp x3, x4
    b.gt .Lsg_no
    subs x3, x3, x2
    b.lt .Lsg_no
    ldr x1, [x1]
    add x1, x1, x2
.Lsg_body:
    tbnz x0, #0, .Lsg_no
    mov x9, #0x10000
    cmp x0, x9
    blo .Lsg_no
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.ne .Lsg_no
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbnz x9, .Lsg_no
    ldur w5, [x0, #-4]
    mov w6, #0x4F57
    movk w6, #0x4752, lsl #16
    cmp w5, w6
    b.ne .Lsg_fused
    add x6, x4, #39
    lsr x6, x6, #3
    ldur x7, [x0, #-16]
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_copy
.Lsg_fused:
    mov w6, #32781
    movk w6, #29519, lsl #16
    cmp w5, w6
    b.ne .Lsg_no
    add x5, x2, #31
    lsr x5, x5, #3
    add x6, x4, #31
    lsr x6, x6, #3
    cmp x6, x5
    b.eq .Lsg_copy
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lsg_large
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x7, x30, [sp], #16
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_fits
.Lsg_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsg_no
    lsl x7, x5, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x7, x7, #3
    cmp x6, x7
    b.hi .Lsg_no
.Lsg_fits:
.Lsg_copy:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsg_d
    cmp x3, #8
    b.lo .Lsg_b
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsg_w:
    cmp x5, x10
    b.hs .Lsg_t
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsg_w
.Lsg_t:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsg_d
.Lsg_b:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsg_b
.Lsg_d:
    mov x0, #1
    ret
.Lsg_no:
    mov x0, #0
    ret
__fn___fern_str_grow_fresh:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsgf_body
__fn___fern_str_grow_fresh_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbz x2, #63, .Lsgf_lo
    b __fern_slice_abort_leaf
.Lsgf_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lsgf_hi
    b __fern_slice_abort_leaf
.Lsgf_hi:
    subs x3, x3, x2
    b.ge .Lsgf_range
    b __fern_slice_abort_leaf
.Lsgf_range:
    ldr x1, [x1]
    add x1, x1, x2
.Lsgf_body:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbz x9, .Lsgf_sized
    b __fern_alloc_size_abort
.Lsgf_sized:
    add x5, x4, #39
    lsr x5, x5, #3
    add x6, x2, #31
    lsr x6, x6, #3
    lsl x6, x6, #1
    cmp x6, x5
    csel x6, x5, x6, lo
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lsgf_large
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
    b .Lsgf_alloc
.Lsgf_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsgf_alloc
    lsl x7, x6, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x6, x7, #3
.Lsgf_alloc:
    stp x0, x1, [sp, #-48]!
    stp x2, x3, [sp, #16]
    str x6, [sp, #32]
    lsl x0, x6, #3
    bl __fern_alloc
    ldr x6, [sp, #32]
    ldp x2, x3, [sp, #16]
    ldp x4, x1, [sp], #48
    str x6, [x0]
    mov w5, #1
    str w5, [x0, #8]
    mov w5, #0x4F57
    movk w5, #0x4752, lsl #16
    str w5, [x0, #12]
    add x5, x0, #32
    str x5, [x0, #16]
    add x6, x2, x3
    str x6, [x0, #24]
    ldr x6, [x4]
    cbz x2, .Lsgf_ad
    cmp x2, #8
    b.lo .Lsgf_ab
    add x9, x6, x2
    sub x9, x9, #8
    add x10, x5, x2
    sub x10, x10, #8
.Lsgf_aw:
    cmp x5, x10
    b.hs .Lsgf_at
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_aw
.Lsgf_at:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_ad
.Lsgf_ab:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x2, x2, #1
    cbnz x2, .Lsgf_ab
.Lsgf_ad:
    add x5, x0, #32
    ldr x2, [x0, #24]
    sub x2, x2, x3
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsgf_bd
    cmp x3, #8
    b.lo .Lsgf_bb
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsgf_bw:
    cmp x5, x10
    b.hs .Lsgf_bt
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_bw
.Lsgf_bt:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_bd
.Lsgf_bb:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsgf_bb
.Lsgf_bd:
    add x0, x0, #16
    ldp x29, x30, [sp], #16
    ret
__fn___fern_str_borrow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    mov x0, #24
    bl __fern_alloc
    mov w2, #1
    str w2, [x0]
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    stur w3, [x0, #4]
    ldr x2, [sp, #32]
    str x2, [x0, #8]
    ldr x3, [sp, #16]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fn___fern_alloc_reuse:
    ldr x0, [sp, #16]
    cbz x0, .Lsarelo_fresh
    ldr x1, [sp]
    ldur x2, [x0, #-16]
    cmp x2, x1
    beq .Lsarelo_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_arr_dec.r
    ldp x29, x30, [sp], #16
.Lsarelo_fresh:
    ldr x0, [sp]
    b __fern_arr_box
.Lsarelo_ret:
    ret
__fn___fern_rc_underflow_count:
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w0, [x10]
    ret
__fern_large_push:
    mov x3, #1
    lsl x3, x3, #34
    cmp x2, x3
    b.hi .Llpush_ret
    mov x3, #1
    lsl x3, x3, #19
    cmp x2, x3
    csel x2, x3, x2, lo
    clz x3, x2
    mov x4, #61
    sub x4, x4, x3
    mov x3, #1
    lsl x3, x3, x4
    sub x3, x3, #1
    add x2, x2, x3
    bic x2, x2, x3
    clz x3, x2
    mov x4, #61
    sub x3, x4, x3
    lsr x4, x2, x3
    add x4, x4, x3, lsl #2
    sub x4, x4, #72
    mov x2, x4
    adrp x3, __fern_large_freelist
    add x3, x3, :lo12:__fern_large_freelist
    ldr x4, [x3, x2, lsl #3]
    cmp x4, x1
    b.eq __fern_double_free_abort_leaf
    str x4, [x1]
    str x1, [x3, x2, lsl #3]
.Llpush_ret:
    ret
__fern_raw_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    cbz x0, .Lrawfree_done
    adrp x9, __fern_heap_base
    add x9, x9, :lo12:__fern_heap_base
    ldr x9, [x9]
    cmp x0, x9
    b.lo .Lrawfree_bad
    adrp x9, __fern_heap_end
    add x9, x9, :lo12:__fern_heap_end
    ldr x9, [x9]
    cmp x0, x9
    b.hs .Lrawfree_bad
    add x1, x1, #7
    lsr x5, x1, #3
    cbz x5, .Lrawfree_done
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lrawfree_b_large
    cmp x5, #256
    b.ls .L182
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x5, x30, [sp], #16
.L182:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x5, lsl #3]
    cmp x10, x0
    b.eq __fern_double_free_abort
    str x10, [x0]
    str x0, [x3, x5, lsl #3]
    b .Lrawfree_b_done
.Lrawfree_b_large:
    mov x1, x0
    lsl x2, x5, #3
    bl __fern_large_push
.Lrawfree_b_done:
.Lrawfree_done:
    ldp x29, x30, [sp], #16
    ret
.Lrawfree_bad:
    b __fern_free_range_abort
__fn___fern_arr_dec:
    ldr x0, [sp]
__fn___fern_arr_dec.r:
    cmp x0, #16, lsl #12
    blo .Larrdec_ret
__fn___fern_arr_dec.u:
    ldur w1, [x0, #-8]
    cmp w1, #1
    bne .Larrdec_shared
    stur wzr, [x0, #-8]
    ldur x1, [x0, #-16]
    add x1, x1, #3
    sub x2, x0, #16
    cmp x1, #256
    b.hi .Larrdec_big
.Larrdec_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Larrdec_ret:
    ret
.Larrdec_shared:
    tbnz w1, #31, .Larrdec_ret
    bgt .Larrdec_dec
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    ret
.Larrdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
    ret
.Larrdec_big:
    mov x9, #0x10000
    cmp x1, x9
    bhs .Larrdec_large
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
    b .Larrdec_push
.Larrdec_large:
    lsl x2, x1, #3
    sub x1, x0, #16
    b __fern_large_push
__fn___fern_str_free:
    ldr x0, [sp]
__fn___fern_str_free.r:
    tbnz x0, #0, .Lstrfree_ret
    cmp x0, #16, lsl #12
    blo .Lstrfree_ret
__fn___fern_str_free.u:
    mov x9, #0x10000
    ldur w4, [x0, #-8]
    cmp w4, #1
    bne .Lstrfree_shared
    ldur w2, [x0, #-4]
    mov w3, #32781
    movk w3, #29519, lsl #16
    cmp w2, w3
    beq .Lstrfree_fused
    mov w3, #0x4F57
    movk w3, #0x4752, lsl #16
    cmp w2, w3
    beq .Lstrfree_grown
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    cmp w2, w3
    beq .Lstrfree_box
    ldr x1, [x0]
    ldr x2, [x0, #8]
    cmp x1, x9
    blo .Lstrfree_box
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrfree_box
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrfree_box
    cmp x2, #0
    ble .Lstrfree_box
    add x2, x2, #7
    lsr x2, x2, #3
    cmp x2, x9
    bhs .Lstrfree_box
    cmp x2, #256
    b.ls .L183
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
.L183:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
.Lstrfree_box:
    stur wzr, [x0, #-8]
    sub x1, x0, #8
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
    b .Lstrfree_ret
.Lstrfree_grown:
    ldur x2, [x0, #-16]
    stur wzr, [x0, #-8]
    sub x1, x0, #16
    b .Lstrfree_block
.Lstrfree_fused:
    ldr x2, [x0, #8]
    add x2, x2, #7
    lsr x2, x2, #3
    add x2, x2, #3
    stur wzr, [x0, #-8]
    sub x1, x0, #8
.Lstrfree_block:
    cmp x2, #256
    b.hi .Lstrfree_fused_big
.Lstrfree_fused_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
    b .Lstrfree_ret
.Lstrfree_fused_big:
    cmp x2, x9
    bhs .Lstrfree_fused_large
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
    b .Lstrfree_fused_push
.Lstrfree_fused_large:
    lsl x2, x2, #3
    b __fern_large_push
.Lstrfree_shared:
    tbnz w4, #31, .Lstrfree_ret
    blt .Lstrfree_uf
    sub w4, w4, #1
    stur w4, [x0, #-8]
    ret
.Lstrfree_uf:
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    ldr x0, [sp]
    tbnz x0, #0, .Lstrvfree_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lstrvfree_ret
    ldur w4, [x0, #-8]
    tbnz w4, #31, .Lstrvfree_view
    b __fn___fern_str_free
.Lstrvfree_view:
    sub x1, x0, #8
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrvfree_ret
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrvfree_ret
    stur wzr, [x0, #-8]
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_arr_free.k:
__fn___fern_str_arr_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_arr_free_0:
    movz x9, #1, lsl #16
    cmp x19, x9
    b.lo .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    ldrsw x20, [x19]
.Lssa___fern_str_arr_free_4:
    mov x9, #0
.Lssa___fern_str_arr_free_15:
    cmp x9, x20
    b.ge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    add x21, x9, #1
    ldr x9, [x19, x21, lsl #3]
    tbnz x9, #0, .Lssa___fern_str_arr_free_rcdeck36
    cmp x9, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck36
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd36
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck36
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___fern_str_arr_free_rcdece36
.Lssa___fern_str_arr_free_rcdecd36:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___fern_str_arr_free_rcdeck36:
    mov x0, x9
.Lssa___fern_str_arr_free_rcdece36:
    mov x9, x21
    cmp x9, x20
    b.lt .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    cmp x19, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck40
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd40
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck40
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___fern_str_arr_free_rcdece40
.Lssa___fern_str_arr_free_rcdecd40:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___fern_str_arr_free_rcdeck40:
    mov x0, x19
.Lssa___fern_str_arr_free_rcdece40:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_drop_arr_ptr:
    ret
    .section .bss
    .align 8
__fern_envp: .quad 0
    .section .text
    .section .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_u8:
    .quad 0
    .text
.globl __fern_alloc_u8
.type __fern_alloc_u8, %function
__fern_alloc_u8:
    tbz w0, #31, .Lfern_alloc_u8_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_u8_sized:
    cbz w0, .Lfern_alloc_u8_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x0, x19
    bl __fern_arr_box
    add x2, x0, #8
    mov w1, w19
.Lfern_alloc_u8_zero:
    cbz x1, .Lfern_alloc_u8_done
    str xzr, [x2], #8
    sub x1, x1, #1
    b .Lfern_alloc_u8_zero
.Lfern_alloc_u8_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_u8_empty:
    adrp x0, .Lfern_empty_u8
    add x0, x0, :lo12:.Lfern_empty_u8
    ret
.size __fern_alloc_u8, .-__fern_alloc_u8
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
    .text
__fern_segv:
    ldr x9, [x1, #16]
    adrp x14, __fern_stack_top
    add x14, x14, :lo12:__fern_stack_top
    ldr x14, [x14]
    cbz x14, .Lfern_segv_near_sp
    mov x15, #1
    lsl x15, x15, #30
    sub x14, x14, x15
    add x14, x14, #16
    sub x15, x9, x14
    mov x16, #1
    lsl x16, x16, #20
    cmp x15, x16
    b.lo .Lfern_segv_overflow
    b .Lfern_segv_other
.Lfern_segv_near_sp:
    ldr x10, [x2, #432]
    sub x9, x9, x10
    mov x10, #1
    lsl x10, x10, #20
    add x9, x9, x10
    lsl x10, x10, #1
    cmp x9, x10
    b.hs .Lfern_segv_other
.Lfern_segv_overflow:
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_stack_overflow
    add x1, x1, :lo12:.Lmsg_stack_overflow
    mov x2, #21
    mov x0, #134
    b __fern_report
.Lfern_segv_other:
    stp x29, x30, [sp, #-16]!
    sub sp, sp, #32
    stp xzr, xzr, [sp]
    stp xzr, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    add sp, sp, #32
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    adrp x1, .Lfern_stack_guard_failed_msg
    add x1, x1, :lo12:.Lfern_stack_guard_failed_msg
    mov x2, #40
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    adrp x1, .Lfern_signal_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_map_failed_msg
    mov x2, #37
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    adrp x1, .Lfern_signal_stack_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_failed_msg
    mov x2, #41
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    adrp x1, .Lfern_fault_handler_failed_msg
    add x1, x1, :lo12:.Lfern_fault_handler_failed_msg
    mov x2, #42
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=arm64-linux profile= harden=0 pie=0 sanitize=0 backtrace=1 size=0 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .bss
    .align 3
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .align 3
__fern_bt_floor: .quad 0
    .text
.globl __fern_report
.type __fern_report, %function
__fern_abort_134:
    mov x0, #134
__fern_report:
    mov x19, x0
    mov x0, #2
    mov x8, #64
    svc #0
    b __fern_bt_exit
.size __fern_report, .-__fern_report
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .text
    .globl __fern_bt_exit
__fern_bt_exit:
    adrp x1, .Lmsg_bt
    add x1, x1, :lo12:.Lmsg_bt
    mov x2, #11
    mov x0, #2
    mov x8, #64
    svc #0
    mov x20, x29
    mov x21, #64
    mov x22, sp
.Lbt_loop:
    cmp x20, x22
    b.lo .Lbt_done
    and x23, x20, #7
    cbnz x23, .Lbt_done
    ldr x1, [x20, #8]
    cmp x1, #16, lsl #12
    b.lo .Lbt_done
    bl .Lbt_hex
    adrp x24, __fern_bt_floor
    add x24, x24, :lo12:__fern_bt_floor
    ldr x22, [x24]
    str xzr, [x24]
    cmp x22, #0
    csel x22, x20, x22, eq
    ldr x20, [x20]
    adrp x24, __fern_stack_top
    add x24, x24, :lo12:__fern_stack_top
    ldr x24, [x24]
    cbz x24, .Lbt_next
    cmp x20, x24
    b.hs .Lbt_done
.Lbt_next:
    subs x21, x21, #1
    b.ne .Lbt_loop
.Lbt_done:
    mov x0, x19
    mov x8, #94
    svc #0
.Lbt_hex:
    sub sp, sp, #32
    mov w2, #0x2020
    movk w2, #0x7830, lsl #16
    str w2, [sp]
    mov w2, #10
    strb w2, [sp, #20]
    mov x3, #16
    add x4, sp, #3
.Lbt_hloop:
    and x2, x1, #15
    cmp x2, #10
    add x5, x2, #87
    add x2, x2, #48
    csel x2, x5, x2, hs
    strb w2, [x4, x3]
    lsr x1, x1, #4
    subs x3, x3, #1
    b.ne .Lbt_hloop
    mov x0, #2
    mov x1, sp
    mov x2, #21
    mov x8, #64
    svc #0
    add sp, sp, #32
    ret
__fern_arr_push:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Larr_push_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_slow_ok
    tbz w3, #31, .Larr_push_slow
.Larr_push_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Larr_push_slow:
    ldr x2, [x0]
    cbnz x2, .Larr_push_frame
    ldur x2, [x0, #-16]
    cbnz x2, .Larr_push_frame
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    ldr x3, [x2, #56]
    cbz x3, .Larr_push_fresh
    ldr x4, [x3]
    str x4, [x2, #56]
    mov x2, #4
    str x2, [x3]
    mov w2, #1
    str w2, [x3, #8]
    mov x2, #1
    str x2, [x3, #16]
    str x1, [x3, #24]
    add x0, x3, #16
    ret
.Larr_push_fresh:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x1, [sp, #-16]!
    mov x0, #4
    bl __fern_arr_box
    ldr x1, [sp], #16
    mov x2, #1
    str x2, [x0]
    str x1, [x0, #8]
    ldp x29, x30, [sp], #16
    ret
.Larr_push_frame:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_rc_ok
    tbnz w2, #31, .Larr_push_rc_ok
    b .Larr_push_grow
.Larr_push_rc_ok:
    cmp x21, x22
    b.ge .Larr_push_grow
    add x1, x21, #1
    str x20, [x19, x1, lsl #3]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_ret
.Larr_push_grow:
    mov x2, x22
    cmp x21, x22
    b.lt .Larr_push_shared_cliff
    cmp x22, #0
    b.ne .Larr_push_dbl
    mov x2, #4
    b .Larr_push_cap
.Larr_push_shared_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21, lsl #3
    str x4, [x3]
    b .Larr_push_cap
.Larr_push_dbl:
    lsl x2, x22, #1
.Larr_push_cap:
    add x9, x21, #1
    cmp x2, x9
    csel x2, x2, x9, hs
    mov x22, x2
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Larr_push_copy4:
    cmp x4, #4
    b.lt .Larr_push_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Larr_push_copy4
.Larr_push_copy1:
    cbz x4, .Larr_push_copy_done
.Larr_push_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Larr_push_copy1_loop
.Larr_push_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
.Larr_push_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lapo_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapo_slow_ok
    tbz w3, #31, .Lapo_slow
.Lapo_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Lapo_slow:
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.eq .Lapo_own
    b .Larr_push_slow
.Lapo_own:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    lsl x8, x22, #1
    cbnz x8, .Lapo_cap
    mov x8, #4
.Lapo_cap:
    add x9, x21, #1
    cmp x8, x9
    csel x8, x8, x9, hs
    movz x9, #65535
    movk x9, #4095, lsl #16
    cmp x8, x9
    b.ls .Lapo_sized
    b __fern_alloc_size_abort
.Lapo_sized:
    add x1, x8, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Lapo_alloc
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    add x1, x3, x1
    ldr x3, [x1]
    cbz x3, .Lapo_miss
    ldr x4, [x3]
    str x4, [x1]
.Lapo_box:
    str x8, [x3]
    mov w4, #1
    str w4, [x3, #8]
    add x0, x3, #16
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Lapo_copy4:
    cmp x4, #4
    b.lt .Lapo_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Lapo_copy4
.Lapo_copy1:
    cbz x4, .Lapo_copy_done
.Lapo_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Lapo_copy1_loop
.Lapo_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
    add x1, x22, #3
    mov x9, #0x10000
    cmp x1, x9
    b.hs .Lapo_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L184
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L184:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapo_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapo_miss:
    add x1, x8, #3
    lsl x1, x1, #3
.Lapo_alloc:
    mov x0, x1
    bl __fern_alloc
    mov x3, x0
    b .Lapo_box
.Lapo_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapo_ret
__fern_arr_push_u8:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Larr_push_u8_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_u8_slow_ok
    tbz w3, #31, .Larr_push_u8_slow
.Larr_push_u8_slow_ok:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    ret
.Larr_push_u8_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_u8_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_u8_rc_ok
    tbnz w2, #31, .Larr_push_u8_rc_ok
    b .Larr_push_u8_grow
.Larr_push_u8_rc_ok:
    lsl x2, x22, #3
    cmp x21, x2
    b.ge .Larr_push_u8_grow
    add x2, x19, x21
    strb w20, [x2, #8]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_u8_ret
.Larr_push_u8_grow:
    mov x2, x22
    lsl x3, x22, #3
    cmp x21, x3
    b.lt .Larr_push_u8_cliff
    cbnz x22, .Larr_push_u8_dbl
    mov x2, #4
    b .Larr_push_u8_cap
.Larr_push_u8_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21
    str x4, [x3]
    b .Larr_push_u8_cap
.Larr_push_u8_dbl:
    lsl x2, x22, #1
.Larr_push_u8_cap:
    add x3, x21, #8
    lsr x3, x3, #3
    cmp x2, x3
    csel x2, x2, x3, hs
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    add x4, x21, #7
    lsr x4, x4, #3
.Larr_push_u8_copy:
    cbz x4, .Larr_push_u8_copied
    ldr x5, [x2], #8
    str x5, [x3], #8
    sub x4, x4, #1
    b .Larr_push_u8_copy
.Larr_push_u8_copied:
    add x2, x0, x21
    strb w20, [x2, #8]
.Larr_push_u8_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned_u8:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lapou_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapou_slow_ok
    tbz w3, #31, .Lapou_slow
.Lapou_slow_ok:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    ret
.Lapou_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    bl .Larr_push_u8_slow
    cmp x0, x19
    beq .Lapou_ret
    mov x9, #0x10000
    cmp x19, x9
    blo .Lapou_ret
    ldur w1, [x19, #-8]
    tbnz w1, #31, .Lapou_ret
    cmp w1, #1
    bne .Lapou_ret
    ldur x1, [x19, #-16]
    add x1, x1, #3
    mov x9, #0x10000
    cmp x1, x9
    bhs .Lapou_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L185
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L185:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapou_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapou_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapou_ret
    .section .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .text
__fern_alloc_bytes:
    tbz w0, #31, .Lfern_alloc_bytes_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_bytes_sized:
    cbz w0, .Lfern_alloc_bytes_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    sxtw x19, w0
    add x0, x19, #7
    lsr x0, x0, #3
    mov x20, x0
    bl __fern_arr_box
    str x19, [x0]
    add x2, x0, #8
.Lfern_alloc_bytes_zero:
    cbz x20, .Lfern_alloc_bytes_done
    str xzr, [x2], #8
    sub x20, x20, #1
    b .Lfern_alloc_bytes_zero
.Lfern_alloc_bytes_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_bytes_empty:
    adrp x0, .Lfern_empty_bytes
    add x0, x0, :lo12:.Lfern_empty_bytes
    ret
__fn___fern_bytes_range:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_bytes_range.k:
__fn___fern_bytes_range.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
.Lssa___fern_bytes_range_0:
    sxtw x9, w10
    mov x11, #2
    and x9, x9, x11
    cmp x9, #0
    b.eq .Lssa___fern_bytes_range_10
.Lssa___fern_bytes_range_11:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x20, x12
    mov x12, x11
    b .Lssa___fern_bytes_range_9
.Lssa___fern_bytes_range_10:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x20, x10
.Lssa___fern_bytes_range_9:
    cmp x19, #0
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_8:
    cmp x0, x19
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_7:
    cmp x0, x12
    b.le .Lssa___fern_bytes_range_4
.Lssa___fern_bytes_range_6:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_bytes_range_4:
    sub x0, x0, x19
    sxtw x21, w0
    cmp x21, #0
    b.ne .Lssa___fern_bytes_range_1
.Lssa___fern_bytes_range_3:
    adrp x0, .K0
    add x0, x0, :lo12:.K0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_range_1:
    add x12, x21, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    sxtw x19, w19
    add x20, x20, x19
    mov x2, x21
    mov x1, x20
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_range_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_bytes_range_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_range_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_range_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_range_mc136
.Lssa___fern_bytes_range_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_range_mcd136
.Lssa___fern_bytes_range_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_range_mcb136
.Lssa___fern_bytes_range_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_bytes_into:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___fern_bytes_into.k:
__fn___fern_bytes_into.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    str x25, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x11
    mov x22, x12
.Lssa___fern_bytes_into_0:
    sxtw x9, w10
    mov x11, #2
    and x9, x9, x11
    cmp x9, #0
    b.eq .Lssa___fern_bytes_into_15
.Lssa___fern_bytes_into_16:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x23, x12
    mov x12, x11
    b .Lssa___fern_bytes_into_14
.Lssa___fern_bytes_into_15:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x23, x10
.Lssa___fern_bytes_into_14:
    ldrsw x24, [x22]
    cmp x19, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_13:
    cmp x21, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_12:
    cmp x20, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_11:
    sub x10, x24, x19
    sxtw x10, w10
    cmp x21, x10
    b.gt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_10:
    sub x12, x12, x19
    sxtw x12, w12
    cmp x20, x12
    b.le .Lssa___fern_bytes_into_7
.Lssa___fern_bytes_into_9:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_bytes_into_7:
    cmp x19, #0
    b.ne .Lssa___fern_bytes_into_4
.Lssa___fern_bytes_into_6:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_into_4:
    mov x6, #0
    tbnz x22, #0, .Lssa___fern_bytes_into_rcuniq100
    cmp x22, #16, lsl #12
    b.lo .Lssa___fern_bytes_into_rcuniq100
    and x7, x22, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    cmp w5, #1
    b.ne .Lssa___fern_bytes_into_rcuniq100
    mov x6, #1
.Lssa___fern_bytes_into_rcuniq100:
    mov x0, x6
    cmp x0, #0
    b.ne .Lssa___fern_bytes_into_1
.Lssa___fern_bytes_into_3:
    add x12, x24, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x25, x0
    str x24, [x25, #0]
    add x10, x25, #8
    add x12, x22, #8
    mov x2, x24
    mov x1, x12
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_into_mcd172
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb172
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc172:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct172
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc172
.Lssa___fern_bytes_into_mct172:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd172
.Lssa___fern_bytes_into_mcb172:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb172
.Lssa___fern_bytes_into_mcd172:
    mov x0, #0
    cmp x22, #16, lsl #12
    b.lo .Lssa___fern_bytes_into_rcdeck117
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_bytes_into_rcdecd117
    tbnz w5, #31, .Lssa___fern_bytes_into_rcdeck117
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa___fern_bytes_into_rcdece117
.Lssa___fern_bytes_into_rcdecd117:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa___fern_bytes_into_rcdeck117:
    mov x0, x22
.Lssa___fern_bytes_into_rcdece117:
    mov x22, x25
.Lssa___fern_bytes_into_2:
.Lssa___fern_bytes_into_1:
    add x12, x22, #8
    sxtw x21, w21
    add x12, x12, x21
    sxtw x20, w20
    add x23, x23, x20
    mov x2, x19
    mov x1, x23
    mov x0, x12
    cbz x2, .Lssa___fern_bytes_into_mcd207
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb207
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc207:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct207
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc207
.Lssa___fern_bytes_into_mct207:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd207
.Lssa___fern_bytes_into_mcb207:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb207
.Lssa___fern_bytes_into_mcd207:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_utf8_step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_utf8_step.k:
__fn___fern_utf8_step.r:
.Lssa___fern_utf8_step_0:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x9]
    mov x12, #0
    mov x13, #1
    cmp x11, #128
    csel x13, x13, x12, lt
.Lssa___fern_utf8_step_42:
    cmp x11, #194
    b.lt .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_41:
    cmp x11, #224
    b.ge .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_40:
    mov x13, #2
.Lssa___fern_utf8_step_39:
.Lssa___fern_utf8_step_38:
    cmp x11, #224
    b.lt .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_37:
    cmp x11, #240
    b.ge .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_36:
    mov x13, #3
.Lssa___fern_utf8_step_35:
.Lssa___fern_utf8_step_34:
    cmp x11, #240
    b.lt .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_33:
    cmp x11, #245
    b.ge .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_32:
    mov x13, #4
.Lssa___fern_utf8_step_31:
.Lssa___fern_utf8_step_30:
    cmp x13, #1
    b.gt .Lssa___fern_utf8_step_27
.Lssa___fern_utf8_step_29:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_27:
    add x14, x9, #1
    sxtw x14, w14
    cmp x14, x10
    b.lt .Lssa___fern_utf8_step_24
.Lssa___fern_utf8_step_26:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_24:
    mov x14, #128
    mov x12, #160
    cmp x11, #224
    csel x12, x12, x14, eq
.Lssa___fern_utf8_step_21:
    mov x15, #144
    cmp x11, #240
    csel x15, x15, x12, eq
.Lssa___fern_utf8_step_18:
    mov x14, #191
    mov x12, #159
    cmp x11, #237
    csel x12, x12, x14, eq
.Lssa___fern_utf8_step_15:
    mov x1, #143
    cmp x11, #244
    csel x1, x1, x12, eq
.Lssa___fern_utf8_step_12:
    add w11, w9, #1
    ldr x6, [x0, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w12, [x6, x11]
    cmp x12, x15
    b.ge .Lssa___fern_utf8_step_9
.Lssa___fern_utf8_step_11:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_9:
    cmp x12, x1
    b.le .Lssa___fern_utf8_step_6
.Lssa___fern_utf8_step_8:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_6:
.Lssa___fern_utf8_step_5:
    mov x12, #2
.Lssa___fern_utf8_step_113:
    cmp x12, x13
    b.ge .Lssa___fern_utf8_step_4
.Lssa___fern_utf8_step_120:
    add x1, x9, x12
    sxtw x1, w1
    cmp x1, x10
    b.ge .Lssa___fern_utf8_step_3
.Lssa___fern_utf8_step_118:
    add w1, w9, w12
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w15, [x6, x1]
    cmp x15, #128
    b.lt .Lssa___fern_utf8_step_2
.Lssa___fern_utf8_step_116:
    cmp x15, #191
    b.gt .Lssa___fern_utf8_step_1
.Lssa___fern_utf8_step_114:
    add x12, x12, #1
    cmp x12, x13
    b.lt .Lssa___fern_utf8_step_120
.Lssa___fern_utf8_step_4:
    mov x0, x13
    ret
.Lssa___fern_utf8_step_3:
    mov x0, x12
    ret
.Lssa___fern_utf8_step_2:
    mov x0, x12
    ret
.Lssa___fern_utf8_step_1:
    mov x0, x12
    ret
    .cfi_endproc
    .ltorg
__fn___fern_str_split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_split.k:
__fn___fern_str_split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    sub sp, sp, #80
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_split_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    adrp x23, .K0
    add x23, x23, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa___fern_str_split_3
.Lssa___fern_str_split_7:
.Lssa___fern_str_split_6:
    mov x24, #0
.Lssa___fern_str_split_12:
    cmp x24, x21
    b.ge .Lssa___fern_str_split_5
.Lssa___fern_str_split_13:
    mov x0, x19
    mov x9, x24
    mov x10, x21
    bl __fn___fern_utf8_step.r
    add x0, x24, x0
    sxtw x25, w0
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    str x9, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x24, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush87s
.Lssa___fern_str_split_apush87o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush87e
.Lssa___fern_str_split_apush87s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush87e:
    mov x23, x0
    mov x24, x25
    cmp x24, x21
    b.lt .Lssa___fern_str_split_13
.Lssa___fern_str_split_5:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_str_split_3:
.Lssa___fern_str_split_2:
    mov x24, #0
    mov x25, #0
.Lssa___fern_str_split_20:
    add x9, x25, x22
    sxtw x9, w9
    cmp x9, x21
    b.gt .Lssa___fern_str_split_1
.Lssa___fern_str_split_26:
.Lssa___fern_str_split_25:
    mov x9, #0
    mov x10, #1
.Lssa___fern_str_split_31:
    cmp x9, x22
    b.ge .Lssa___fern_str_split_24
.Lssa___fern_str_split_35:
    add w11, w25, w9
    ldr x6, [x19, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w12, [x6, x11]
    ldr x11, [x20, #0]
    ldrb w13, [x11, x9]
    mov x11, #0
    add x9, x9, #1
    cmp x12, x13
    csel x9, x22, x9, ne
    csel x10, x11, x10, ne
.Lssa___fern_str_split_32:
    cmp x9, x22
    b.lt .Lssa___fern_str_split_35
.Lssa___fern_str_split_24:
    cmp x10, #1
    b.ne .Lssa___fern_str_split_22
.Lssa___fern_str_split_23:
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    str x10, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x27, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x27
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush142s
.Lssa___fern_str_split_apush142o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush142e
.Lssa___fern_str_split_apush142s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush142e:
    add x10, x25, x22
    sxtw x10, w10
    mov x23, x0
    mov x24, x10
    mov x25, x10
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_22:
    add x25, x25, #1
    sxtw x25, w25
.Lssa___fern_str_split_21:
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_1:
    mov x0, x19
    mov x1, x24
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x25, x0
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    str x10, [sp, #-16]!
    str x25, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x24, x0
    str x25, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush161s
.Lssa___fern_str_split_apush161o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush161e
.Lssa___fern_str_split_apush161s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush161e:
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_bytes_u8.k:
__fn___fern_str_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_bytes_u8_0:
    ldr x20, [x19, #8]
    sxtw x21, w20
    add x9, x21, #7
    mov x4, x9
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    sxtw x10, w10
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    ldr x9, [x19, #0]
    mov x2, x20
    mov x1, x9
    mov x0, x10
    cbz x2, .Lssa___fern_str_bytes_u8_mcd36
    cmp x2, #8
    b.lo .Lssa___fern_str_bytes_u8_mcb36
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_bytes_u8_mc36:
    cmp x0, x10
    b.hs .Lssa___fern_str_bytes_u8_mct36
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_bytes_u8_mc36
.Lssa___fern_str_bytes_u8_mct36:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_bytes_u8_mcd36
.Lssa___fern_str_bytes_u8_mcb36:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_bytes_u8_mcb36
.Lssa___fern_str_bytes_u8_mcd36:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_string_from_bytes_u8.k:
__fn___fern_string_from_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_string_from_bytes_u8_0:
    ldr x20, [x19, #0]
    mov x0, x20
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x21, x0
    add x19, x19, #8
    mov x2, x20
    mov x1, x19
    mov x0, x21
    cbz x2, .Lssa___fern_string_from_bytes_u8_mcd14
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_u8_mcb14
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_u8_mc14:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_u8_mct14
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_u8_mc14
.Lssa___fern_string_from_bytes_u8_mct14:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_u8_mcd14
.Lssa___fern_string_from_bytes_u8_mcb14:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_u8_mcb14
.Lssa___fern_string_from_bytes_u8_mcd14:
    mov x0, #0
    mov x0, x21
    mov x1, x20
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_range_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_string_from_bytes_range_u8.k:
__fn___fern_string_from_bytes_range_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_string_from_bytes_range_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
.Lssa___fern_string_from_bytes_range_u8_13:
    mov x13, #1
    cmp x10, x9
    csel x13, x13, x12, gt
.Lssa___fern_string_from_bytes_range_u8_10:
    mov x9, #1
    cmp x20, #0
    csel x9, x9, x13, lt
.Lssa___fern_string_from_bytes_range_u8_7:
    mov x12, #1
    cmp x20, x10
    csel x12, x12, x9, gt
.Lssa___fern_string_from_bytes_range_u8_4:
    cmp x12, #1
    b.ne .Lssa___fern_string_from_bytes_range_u8_1
.Lssa___fern_string_from_bytes_range_u8_3:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_string_from_bytes_range_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    mov x0, x21
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x22, x0
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x22
    cbz x2, .Lssa___fern_string_from_bytes_range_u8_mcd117
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_range_u8_mcb117
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_range_u8_mc117:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_range_u8_mct117
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_range_u8_mc117
.Lssa___fern_string_from_bytes_range_u8_mct117:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_range_u8_mcd117
.Lssa___fern_string_from_bytes_range_u8_mcb117:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_range_u8_mcb117
.Lssa___fern_string_from_bytes_range_u8_mcd117:
    mov x0, #0
    mov x0, x22
    mov x1, x21
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_arr_slice_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_arr_slice_u8.k:
__fn___fern_arr_slice_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_arr_slice_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
.Lssa___fern_arr_slice_u8_13:
    mov x13, #1
    cmp x10, x9
    csel x13, x13, x12, gt
.Lssa___fern_arr_slice_u8_10:
    mov x9, #1
    cmp x20, #0
    csel x9, x9, x13, lt
.Lssa___fern_arr_slice_u8_7:
    mov x12, #1
    cmp x20, x10
    csel x12, x12, x9, gt
.Lssa___fern_arr_slice_u8_4:
    cmp x12, #1
    b.ne .Lssa___fern_arr_slice_u8_1
.Lssa___fern_arr_slice_u8_3:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_arr_slice_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    add x10, x21, #7
    sxtw x10, w10
    mov x4, x10
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x12, x4
    mov x0, x12
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x12, x22, #8
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x12
    cbz x2, .Lssa___fern_arr_slice_u8_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_arr_slice_u8_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_arr_slice_u8_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_arr_slice_u8_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_arr_slice_u8_mc136
.Lssa___fern_arr_slice_u8_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_arr_slice_u8_mcd136
.Lssa___fern_arr_slice_u8_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_arr_slice_u8_mcb136
.Lssa___fern_arr_slice_u8_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
    .section .rodata
.S0: .ascii "HeaderMap"
.S1: .ascii "http://"
.S2: .ascii "https://"
.S3: .ascii "!$&'()*+,;="
.S4: .ascii ""
.S5: .ascii "\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\r"
.S6: .ascii "\027\003\007\003\003\003\003\003\007\007\013\253/\253\013\217\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\001\000\000\000\000\000\001\001\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001"
.S7: .ascii "OPTIONS"
.S8: .ascii "*"
.S9: .ascii "\003\003\003\003\003\003\003\003\003\002\003\003\003\003\003\203\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
.S10: .ascii "HTTP/1.0"
.S11: .ascii "HTTP/1.1"
.S12: .ascii "host"
.S13: .ascii "expect"
.S14: .ascii "connection"
.S15: .ascii "content-length"
.S16: .ascii "transfer-encoding"
.S17: .ascii "100-continue"
.S18: .ascii ","
.S19: .ascii "chunked"
.S20: .ascii "close"
.S21: .ascii "keep-alive"
.S22: .ascii "ByteStream"
.S23: .ascii "HttpRequest"
.S24: .ascii "http__RequestParseError$http__Incomplete"
.S25: .ascii "http__RequestParseError$http__NeedsContinue"
.S26: .ascii "http__RequestParseError$http__Malformed"
.S27: .ascii "0"
.S28: .ascii "1"
.S29: .ascii "2"
.S30: .ascii "3"
.S31: .ascii "4"
.S32: .ascii "5"
.S33: .ascii "6"
.S34: .ascii "7"
.S35: .ascii "8"
.S36: .ascii "9"
.S37: .ascii "10"
.S38: .ascii "11"
.S39: .ascii "12"
.S40: .ascii "13"
.S41: .ascii "14"
.S42: .ascii "15"
.S43: .ascii "16"
.S44: .ascii "17"
.S45: .ascii "18"
.S46: .ascii "19"
.S47: .ascii "20"
.S48: .ascii "21"
.S49: .ascii "22"
.S50: .ascii "23"
.S51: .ascii "24"
.S52: .ascii "25"
.S53: .ascii "26"
.S54: .ascii "27"
.S55: .ascii "28"
.S56: .ascii "29"
.S57: .ascii "30"
.S58: .ascii "31"
.S59: .ascii "32"
.S60: .ascii "33"
.S61: .ascii "34"
.S62: .ascii "35"
.S63: .ascii "36"
.S64: .ascii "37"
.S65: .ascii "38"
.S66: .ascii "39"
.S67: .ascii "40"
.S68: .ascii "41"
.S69: .ascii "42"
.S70: .ascii "43"
.S71: .ascii "44"
.S72: .ascii "45"
.S73: .ascii "46"
.S74: .ascii "47"
.S75: .ascii "48"
.S76: .ascii "49"
.S77: .ascii "50"
.S78: .ascii "51"
.S79: .ascii "52"
.S80: .ascii "53"
.S81: .ascii "54"
.S82: .ascii "55"
.S83: .ascii "56"
.S84: .ascii "57"
.S85: .ascii "58"
.S86: .ascii "59"
.S87: .ascii "60"
.S88: .ascii "61"
.S89: .ascii "62"
.S90: .ascii "63"
.S91: .ascii "64"
.S92: .ascii "65"
.S93: .ascii "66"
.S94: .ascii "67"
.S95: .ascii "68"
.S96: .ascii "69"
.S97: .ascii "70"
.S98: .ascii "71"
.S99: .ascii "72"
.S100: .ascii "73"
.S101: .ascii "74"
.S102: .ascii "75"
.S103: .ascii "76"
.S104: .ascii "77"
.S105: .ascii "78"
.S106: .ascii "79"
.S107: .ascii "80"
.S108: .ascii "81"
.S109: .ascii "82"
.S110: .ascii "83"
.S111: .ascii "84"
.S112: .ascii "85"
.S113: .ascii "86"
.S114: .ascii "87"
.S115: .ascii "88"
.S116: .ascii "89"
.S117: .ascii "90"
.S118: .ascii "91"
.S119: .ascii "92"
.S120: .ascii "93"
.S121: .ascii "94"
.S122: .ascii "95"
.S123: .ascii "96"
.S124: .ascii "97"
.S125: .ascii "98"
.S126: .ascii "99"
.S127: .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
.S128: .ascii "deflate____ReadPhase$deflate__ReadHeader"
.S129: .ascii "deflate____ReadPhase$deflate__ReadStored"
.S130: .ascii "deflate____ReadPhase$deflate__ReadCodes"
.S131: .ascii "deflate____ReadPhase$deflate__ReadCopy"
.S132: .ascii "deflate____ReadPhase$deflate__ReadEnd"
.S133: .ascii "codec__DecodeErrorKind$codec__InvalidByte"
.S134: .ascii "codec__DecodeErrorKind$codec__InvalidLength"
.S135: .ascii "codec__DecodeErrorKind$codec__InvalidPadding"
.S136: .ascii "codec__DecodeErrorKind$codec__NonZeroTrailingBits"
.S137: .ascii "GET /hello HTTP/1.1\r\nHost: bench\r\nUser-Agent: perf-bench\r\nAccept: */*\r\n\r\n"
.S138: .ascii "hello "
.S139: .ascii "GET"
.S140: .ascii "Content-Length: "
.S141: .ascii "\r\n"
.S142: .ascii "HTTP/1.1 "
.S143: .ascii " "
.S144: .ascii "Continue"
.S145: .ascii "Switching Protocols"
.S146: .ascii "OK"
.S147: .ascii "Created"
.S148: .ascii "Accepted"
.S149: .ascii "Non-Authoritative Information"
.S150: .ascii "No Content"
.S151: .ascii "Reset Content"
.S152: .ascii "Partial Content"
.S153: .ascii "Multiple Choices"
.S154: .ascii "Moved Permanently"
.S155: .ascii "Found"
.S156: .ascii "See Other"
.S157: .ascii "Not Modified"
.S158: .ascii "Use Proxy"
.S159: .ascii "Temporary Redirect"
.S160: .ascii "Permanent Redirect"
.S161: .ascii "Bad Request"
.S162: .ascii "Unauthorized"
.S163: .ascii "Payment Required"
.S164: .ascii "Forbidden"
.S165: .ascii "Not Found"
.S166: .ascii "Method Not Allowed"
.S167: .ascii "Not Acceptable"
.S168: .ascii "Proxy Authentication Required"
.S169: .ascii "Request Timeout"
.S170: .ascii "Conflict"
.S171: .ascii "Gone"
.S172: .ascii "Length Required"
.S173: .ascii "Precondition Failed"
.S174: .ascii "Payload Too Large"
.S175: .ascii "URI Too Long"
.S176: .ascii "Unsupported Media Type"
.S177: .ascii "Range Not Satisfiable"
.S178: .ascii "Expectation Failed"
.S179: .ascii "I'm a teapot"
.S180: .ascii "Misdirected Request"
.S181: .ascii "Unprocessable Entity"
.S182: .ascii "Upgrade Required"
.S183: .ascii "Precondition Required"
.S184: .ascii "Too Many Requests"
.S185: .ascii "Request Header Fields Too Large"
.S186: .ascii "Internal Server Error"
.S187: .ascii "Not Implemented"
.S188: .ascii "Bad Gateway"
.S189: .ascii "Service Unavailable"
.S190: .ascii "Gateway Timeout"
.S191: .ascii "HTTP Version Not Supported"
.S192: .ascii "Network Authentication Required"
.S193: .ascii "Status"
.S194: .ascii ": "
.S195: .ascii "Connection: close\r\n\r\n"
.S196: .ascii "HEAD"
    .section .data
    .align 8
.Lfern_relanchor:
    .quad .Lfern_relanchor
    .section .data.rel.ro
    .align 8
.Lfern_sbox_begin:
    .section .data.rel.ro
    .align 8
    .quad -1
.SB0:
    .quad .S0
    .quad 9
    .quad -1
.SB1:
    .quad .S1
    .quad 7
    .quad -1
.SB2:
    .quad .S2
    .quad 8
    .quad -1
.SB3:
    .quad .S3
    .quad 11
    .quad -1
.SB4:
    .quad .S4
    .quad 0
    .quad -1
.SB5:
    .quad .S5
    .quad 354
    .quad -1
.SB6:
    .quad .S6
    .quad 352
    .quad -1
.SB7:
    .quad .S7
    .quad 7
    .quad -1
.SB8:
    .quad .S8
    .quad 1
    .quad -1
.SB9:
    .quad .S9
    .quad 352
    .quad -1
.SB10:
    .quad .S10
    .quad 8
    .quad -1
.SB11:
    .quad .S11
    .quad 8
    .quad -1
.SB12:
    .quad .S12
    .quad 4
    .quad -1
.SB13:
    .quad .S13
    .quad 6
    .quad -1
.SB14:
    .quad .S14
    .quad 10
    .quad -1
.SB15:
    .quad .S15
    .quad 14
    .quad -1
.SB16:
    .quad .S16
    .quad 17
    .quad -1
.SB17:
    .quad .S17
    .quad 12
    .quad -1
.SB18:
    .quad .S18
    .quad 1
    .quad -1
.SB19:
    .quad .S19
    .quad 7
    .quad -1
.SB20:
    .quad .S20
    .quad 5
    .quad -1
.SB21:
    .quad .S21
    .quad 10
    .quad -1
.SB22:
    .quad .S22
    .quad 10
    .quad -1
.SB23:
    .quad .S23
    .quad 11
    .quad -1
.SB24:
    .quad .S24
    .quad 40
    .quad -1
.SB25:
    .quad .S25
    .quad 43
    .quad -1
.SB26:
    .quad .S26
    .quad 39
    .quad -1
.SB27:
    .quad .S27
    .quad 1
    .quad -1
.SB28:
    .quad .S28
    .quad 1
    .quad -1
.SB29:
    .quad .S29
    .quad 1
    .quad -1
.SB30:
    .quad .S30
    .quad 1
    .quad -1
.SB31:
    .quad .S31
    .quad 1
    .quad -1
.SB32:
    .quad .S32
    .quad 1
    .quad -1
.SB33:
    .quad .S33
    .quad 1
    .quad -1
.SB34:
    .quad .S34
    .quad 1
    .quad -1
.SB35:
    .quad .S35
    .quad 1
    .quad -1
.SB36:
    .quad .S36
    .quad 1
    .quad -1
.SB37:
    .quad .S37
    .quad 2
    .quad -1
.SB38:
    .quad .S38
    .quad 2
    .quad -1
.SB39:
    .quad .S39
    .quad 2
    .quad -1
.SB40:
    .quad .S40
    .quad 2
    .quad -1
.SB41:
    .quad .S41
    .quad 2
    .quad -1
.SB42:
    .quad .S42
    .quad 2
    .quad -1
.SB43:
    .quad .S43
    .quad 2
    .quad -1
.SB44:
    .quad .S44
    .quad 2
    .quad -1
.SB45:
    .quad .S45
    .quad 2
    .quad -1
.SB46:
    .quad .S46
    .quad 2
    .quad -1
.SB47:
    .quad .S47
    .quad 2
    .quad -1
.SB48:
    .quad .S48
    .quad 2
    .quad -1
.SB49:
    .quad .S49
    .quad 2
    .quad -1
.SB50:
    .quad .S50
    .quad 2
    .quad -1
.SB51:
    .quad .S51
    .quad 2
    .quad -1
.SB52:
    .quad .S52
    .quad 2
    .quad -1
.SB53:
    .quad .S53
    .quad 2
    .quad -1
.SB54:
    .quad .S54
    .quad 2
    .quad -1
.SB55:
    .quad .S55
    .quad 2
    .quad -1
.SB56:
    .quad .S56
    .quad 2
    .quad -1
.SB57:
    .quad .S57
    .quad 2
    .quad -1
.SB58:
    .quad .S58
    .quad 2
    .quad -1
.SB59:
    .quad .S59
    .quad 2
    .quad -1
.SB60:
    .quad .S60
    .quad 2
    .quad -1
.SB61:
    .quad .S61
    .quad 2
    .quad -1
.SB62:
    .quad .S62
    .quad 2
    .quad -1
.SB63:
    .quad .S63
    .quad 2
    .quad -1
.SB64:
    .quad .S64
    .quad 2
    .quad -1
.SB65:
    .quad .S65
    .quad 2
    .quad -1
.SB66:
    .quad .S66
    .quad 2
    .quad -1
.SB67:
    .quad .S67
    .quad 2
    .quad -1
.SB68:
    .quad .S68
    .quad 2
    .quad -1
.SB69:
    .quad .S69
    .quad 2
    .quad -1
.SB70:
    .quad .S70
    .quad 2
    .quad -1
.SB71:
    .quad .S71
    .quad 2
    .quad -1
.SB72:
    .quad .S72
    .quad 2
    .quad -1
.SB73:
    .quad .S73
    .quad 2
    .quad -1
.SB74:
    .quad .S74
    .quad 2
    .quad -1
.SB75:
    .quad .S75
    .quad 2
    .quad -1
.SB76:
    .quad .S76
    .quad 2
    .quad -1
.SB77:
    .quad .S77
    .quad 2
    .quad -1
.SB78:
    .quad .S78
    .quad 2
    .quad -1
.SB79:
    .quad .S79
    .quad 2
    .quad -1
.SB80:
    .quad .S80
    .quad 2
    .quad -1
.SB81:
    .quad .S81
    .quad 2
    .quad -1
.SB82:
    .quad .S82
    .quad 2
    .quad -1
.SB83:
    .quad .S83
    .quad 2
    .quad -1
.SB84:
    .quad .S84
    .quad 2
    .quad -1
.SB85:
    .quad .S85
    .quad 2
    .quad -1
.SB86:
    .quad .S86
    .quad 2
    .quad -1
.SB87:
    .quad .S87
    .quad 2
    .quad -1
.SB88:
    .quad .S88
    .quad 2
    .quad -1
.SB89:
    .quad .S89
    .quad 2
    .quad -1
.SB90:
    .quad .S90
    .quad 2
    .quad -1
.SB91:
    .quad .S91
    .quad 2
    .quad -1
.SB92:
    .quad .S92
    .quad 2
    .quad -1
.SB93:
    .quad .S93
    .quad 2
    .quad -1
.SB94:
    .quad .S94
    .quad 2
    .quad -1
.SB95:
    .quad .S95
    .quad 2
    .quad -1
.SB96:
    .quad .S96
    .quad 2
    .quad -1
.SB97:
    .quad .S97
    .quad 2
    .quad -1
.SB98:
    .quad .S98
    .quad 2
    .quad -1
.SB99:
    .quad .S99
    .quad 2
    .quad -1
.SB100:
    .quad .S100
    .quad 2
    .quad -1
.SB101:
    .quad .S101
    .quad 2
    .quad -1
.SB102:
    .quad .S102
    .quad 2
    .quad -1
.SB103:
    .quad .S103
    .quad 2
    .quad -1
.SB104:
    .quad .S104
    .quad 2
    .quad -1
.SB105:
    .quad .S105
    .quad 2
    .quad -1
.SB106:
    .quad .S106
    .quad 2
    .quad -1
.SB107:
    .quad .S107
    .quad 2
    .quad -1
.SB108:
    .quad .S108
    .quad 2
    .quad -1
.SB109:
    .quad .S109
    .quad 2
    .quad -1
.SB110:
    .quad .S110
    .quad 2
    .quad -1
.SB111:
    .quad .S111
    .quad 2
    .quad -1
.SB112:
    .quad .S112
    .quad 2
    .quad -1
.SB113:
    .quad .S113
    .quad 2
    .quad -1
.SB114:
    .quad .S114
    .quad 2
    .quad -1
.SB115:
    .quad .S115
    .quad 2
    .quad -1
.SB116:
    .quad .S116
    .quad 2
    .quad -1
.SB117:
    .quad .S117
    .quad 2
    .quad -1
.SB118:
    .quad .S118
    .quad 2
    .quad -1
.SB119:
    .quad .S119
    .quad 2
    .quad -1
.SB120:
    .quad .S120
    .quad 2
    .quad -1
.SB121:
    .quad .S121
    .quad 2
    .quad -1
.SB122:
    .quad .S122
    .quad 2
    .quad -1
.SB123:
    .quad .S123
    .quad 2
    .quad -1
.SB124:
    .quad .S124
    .quad 2
    .quad -1
.SB125:
    .quad .S125
    .quad 2
    .quad -1
.SB126:
    .quad .S126
    .quad 2
    .quad -1
.SB127:
    .quad .S127
    .quad 200
    .quad -1
.SB128:
    .quad .S128
    .quad 40
    .quad -1
.SB129:
    .quad .S129
    .quad 40
    .quad -1
.SB130:
    .quad .S130
    .quad 39
    .quad -1
.SB131:
    .quad .S131
    .quad 38
    .quad -1
.SB132:
    .quad .S132
    .quad 37
    .quad -1
.SB133:
    .quad .S133
    .quad 41
    .quad -1
.SB134:
    .quad .S134
    .quad 43
    .quad -1
.SB135:
    .quad .S135
    .quad 44
    .quad -1
.SB136:
    .quad .S136
    .quad 49
    .quad -1
.SB137:
    .quad .S137
    .quad 73
    .quad -1
.SB138:
    .quad .S138
    .quad 6
    .quad -1
.SB139:
    .quad .S139
    .quad 3
    .quad -1
.SB140:
    .quad .S140
    .quad 16
    .quad -1
.SB141:
    .quad .S141
    .quad 2
    .quad -1
.SB142:
    .quad .S142
    .quad 9
    .quad -1
.SB143:
    .quad .S143
    .quad 1
    .quad -1
.SB144:
    .quad .S144
    .quad 8
    .quad -1
.SB145:
    .quad .S145
    .quad 19
    .quad -1
.SB146:
    .quad .S146
    .quad 2
    .quad -1
.SB147:
    .quad .S147
    .quad 7
    .quad -1
.SB148:
    .quad .S148
    .quad 8
    .quad -1
.SB149:
    .quad .S149
    .quad 29
    .quad -1
.SB150:
    .quad .S150
    .quad 10
    .quad -1
.SB151:
    .quad .S151
    .quad 13
    .quad -1
.SB152:
    .quad .S152
    .quad 15
    .quad -1
.SB153:
    .quad .S153
    .quad 16
    .quad -1
.SB154:
    .quad .S154
    .quad 17
    .quad -1
.SB155:
    .quad .S155
    .quad 5
    .quad -1
.SB156:
    .quad .S156
    .quad 9
    .quad -1
.SB157:
    .quad .S157
    .quad 12
    .quad -1
.SB158:
    .quad .S158
    .quad 9
    .quad -1
.SB159:
    .quad .S159
    .quad 18
    .quad -1
.SB160:
    .quad .S160
    .quad 18
    .quad -1
.SB161:
    .quad .S161
    .quad 11
    .quad -1
.SB162:
    .quad .S162
    .quad 12
    .quad -1
.SB163:
    .quad .S163
    .quad 16
    .quad -1
.SB164:
    .quad .S164
    .quad 9
    .quad -1
.SB165:
    .quad .S165
    .quad 9
    .quad -1
.SB166:
    .quad .S166
    .quad 18
    .quad -1
.SB167:
    .quad .S167
    .quad 14
    .quad -1
.SB168:
    .quad .S168
    .quad 29
    .quad -1
.SB169:
    .quad .S169
    .quad 15
    .quad -1
.SB170:
    .quad .S170
    .quad 8
    .quad -1
.SB171:
    .quad .S171
    .quad 4
    .quad -1
.SB172:
    .quad .S172
    .quad 15
    .quad -1
.SB173:
    .quad .S173
    .quad 19
    .quad -1
.SB174:
    .quad .S174
    .quad 17
    .quad -1
.SB175:
    .quad .S175
    .quad 12
    .quad -1
.SB176:
    .quad .S176
    .quad 22
    .quad -1
.SB177:
    .quad .S177
    .quad 21
    .quad -1
.SB178:
    .quad .S178
    .quad 18
    .quad -1
.SB179:
    .quad .S179
    .quad 12
    .quad -1
.SB180:
    .quad .S180
    .quad 19
    .quad -1
.SB181:
    .quad .S181
    .quad 20
    .quad -1
.SB182:
    .quad .S182
    .quad 16
    .quad -1
.SB183:
    .quad .S183
    .quad 21
    .quad -1
.SB184:
    .quad .S184
    .quad 17
    .quad -1
.SB185:
    .quad .S185
    .quad 31
    .quad -1
.SB186:
    .quad .S186
    .quad 21
    .quad -1
.SB187:
    .quad .S187
    .quad 15
    .quad -1
.SB188:
    .quad .S188
    .quad 11
    .quad -1
.SB189:
    .quad .S189
    .quad 19
    .quad -1
.SB190:
    .quad .S190
    .quad 15
    .quad -1
.SB191:
    .quad .S191
    .quad 26
    .quad -1
.SB192:
    .quad .S192
    .quad 31
    .quad -1
.SB193:
    .quad .S193
    .quad 6
    .quad -1
.SB194:
    .quad .S194
    .quad 2
    .quad -1
.SB195:
    .quad .S195
    .quad 21
    .quad -1
.SB196:
    .quad .S196
    .quad 4
.Lfern_sbox_end:
    .section .data
    .align 8
    .quad 0
    .quad -1
.K0:
    .quad 0
    .quad 0
    .quad -1
.K2:
    .quad 14
    .byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K3:
    .quad 256
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    .balign 8
    .quad 0
    .quad -1
.K4:
    .quad 5
    .byte 72, 84, 84, 80, 47
    .balign 8
    .quad 0
    .quad -1
.K5:
    .quad 0
    .balign 8
    .quad 0
    .quad -1
.K6:
    .quad 128
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
    .balign 8
    .quad 2
    .quad -1
.K7:
    .quad 1
    .quad 0
    .quad 100
    .quad -1
.K10:
    .quad 100
.K10_0:
    .quad .SB27
.K10_1:
    .quad .SB28
.K10_2:
    .quad .SB29
.K10_3:
    .quad .SB30
.K10_4:
    .quad .SB31
.K10_5:
    .quad .SB32
.K10_6:
    .quad .SB33
.K10_7:
    .quad .SB34
.K10_8:
    .quad .SB35
.K10_9:
    .quad .SB36
.K10_10:
    .quad .SB37
.K10_11:
    .quad .SB38
.K10_12:
    .quad .SB39
.K10_13:
    .quad .SB40
.K10_14:
    .quad .SB41
.K10_15:
    .quad .SB42
.K10_16:
    .quad .SB43
.K10_17:
    .quad .SB44
.K10_18:
    .quad .SB45
.K10_19:
    .quad .SB46
.K10_20:
    .quad .SB47
.K10_21:
    .quad .SB48
.K10_22:
    .quad .SB49
.K10_23:
    .quad .SB50
.K10_24:
    .quad .SB51
.K10_25:
    .quad .SB52
.K10_26:
    .quad .SB53
.K10_27:
    .quad .SB54
.K10_28:
    .quad .SB55
.K10_29:
    .quad .SB56
.K10_30:
    .quad .SB57
.K10_31:
    .quad .SB58
.K10_32:
    .quad .SB59
.K10_33:
    .quad .SB60
.K10_34:
    .quad .SB61
.K10_35:
    .quad .SB62
.K10_36:
    .quad .SB63
.K10_37:
    .quad .SB64
.K10_38:
    .quad .SB65
.K10_39:
    .quad .SB66
.K10_40:
    .quad .SB67
.K10_41:
    .quad .SB68
.K10_42:
    .quad .SB69
.K10_43:
    .quad .SB70
.K10_44:
    .quad .SB71
.K10_45:
    .quad .SB72
.K10_46:
    .quad .SB73
.K10_47:
    .quad .SB74
.K10_48:
    .quad .SB75
.K10_49:
    .quad .SB76
.K10_50:
    .quad .SB77
.K10_51:
    .quad .SB78
.K10_52:
    .quad .SB79
.K10_53:
    .quad .SB80
.K10_54:
    .quad .SB81
.K10_55:
    .quad .SB82
.K10_56:
    .quad .SB83
.K10_57:
    .quad .SB84
.K10_58:
    .quad .SB85
.K10_59:
    .quad .SB86
.K10_60:
    .quad .SB87
.K10_61:
    .quad .SB88
.K10_62:
    .quad .SB89
.K10_63:
    .quad .SB90
.K10_64:
    .quad .SB91
.K10_65:
    .quad .SB92
.K10_66:
    .quad .SB93
.K10_67:
    .quad .SB94
.K10_68:
    .quad .SB95
.K10_69:
    .quad .SB96
.K10_70:
    .quad .SB97
.K10_71:
    .quad .SB98
.K10_72:
    .quad .SB99
.K10_73:
    .quad .SB100
.K10_74:
    .quad .SB101
.K10_75:
    .quad .SB102
.K10_76:
    .quad .SB103
.K10_77:
    .quad .SB104
.K10_78:
    .quad .SB105
.K10_79:
    .quad .SB106
.K10_80:
    .quad .SB107
.K10_81:
    .quad .SB108
.K10_82:
    .quad .SB109
.K10_83:
    .quad .SB110
.K10_84:
    .quad .SB111
.K10_85:
    .quad .SB112
.K10_86:
    .quad .SB113
.K10_87:
    .quad .SB114
.K10_88:
    .quad .SB115
.K10_89:
    .quad .SB116
.K10_90:
    .quad .SB117
.K10_91:
    .quad .SB118
.K10_92:
    .quad .SB119
.K10_93:
    .quad .SB120
.K10_94:
    .quad .SB121
.K10_95:
    .quad .SB122
.K10_96:
    .quad .SB123
.K10_97:
    .quad .SB124
.K10_98:
    .quad .SB125
.K10_99:
    .quad .SB126
    .quad 49
    .quad -1
.K11:
    .quad 49
    .quad 100
    .quad 101
    .quad 200
    .quad 201
    .quad 202
    .quad 203
    .quad 204
    .quad 205
    .quad 206
    .quad 300
    .quad 301
    .quad 302
    .quad 303
    .quad 304
    .quad 305
    .quad 307
    .quad 308
    .quad 400
    .quad 401
    .quad 402
    .quad 403
    .quad 404
    .quad 405
    .quad 406
    .quad 407
    .quad 408
    .quad 409
    .quad 410
    .quad 411
    .quad 412
    .quad 413
    .quad 414
    .quad 415
    .quad 416
    .quad 417
    .quad 418
    .quad 421
    .quad 422
    .quad 426
    .quad 428
    .quad 429
    .quad 431
    .quad 500
    .quad 501
    .quad 502
    .quad 503
    .quad 504
    .quad 505
    .quad 511
    .quad 49
    .quad -1
.K12:
    .quad 49
.K12_0:
    .quad .SB144
.K12_1:
    .quad .SB145
.K12_2:
    .quad .SB146
.K12_3:
    .quad .SB147
.K12_4:
    .quad .SB148
.K12_5:
    .quad .SB149
.K12_6:
    .quad .SB150
.K12_7:
    .quad .SB151
.K12_8:
    .quad .SB152
.K12_9:
    .quad .SB153
.K12_10:
    .quad .SB154
.K12_11:
    .quad .SB155
.K12_12:
    .quad .SB156
.K12_13:
    .quad .SB157
.K12_14:
    .quad .SB158
.K12_15:
    .quad .SB159
.K12_16:
    .quad .SB160
.K12_17:
    .quad .SB161
.K12_18:
    .quad .SB162
.K12_19:
    .quad .SB163
.K12_20:
    .quad .SB164
.K12_21:
    .quad .SB165
.K12_22:
    .quad .SB166
.K12_23:
    .quad .SB167
.K12_24:
    .quad .SB168
.K12_25:
    .quad .SB169
.K12_26:
    .quad .SB170
.K12_27:
    .quad .SB171
.K12_28:
    .quad .SB172
.K12_29:
    .quad .SB173
.K12_30:
    .quad .SB174
.K12_31:
    .quad .SB175
.K12_32:
    .quad .SB176
.K12_33:
    .quad .SB177
.K12_34:
    .quad .SB178
.K12_35:
    .quad .SB179
.K12_36:
    .quad .SB180
.K12_37:
    .quad .SB181
.K12_38:
    .quad .SB182
.K12_39:
    .quad .SB183
.K12_40:
    .quad .SB184
.K12_41:
    .quad .SB185
.K12_42:
    .quad .SB186
.K12_43:
    .quad .SB187
.K12_44:
    .quad .SB188
.K12_45:
    .quad .SB189
.K12_46:
    .quad .SB190
.K12_47:
    .quad .SB191
.K12_48:
    .quad .SB192
    .section .data.rel.ro
    .align 8
.Lfern_cagg_begin:
    .section .data.rel.ro
    .align 8
    .quad 3
    .quad -1
.K1:
    .quad .S0
.K1_0:
    .quad .K0
.K1_1:
    .quad .K0
    .quad 1
    .quad -1
.K8:
    .quad .S24
    .quad 1
    .quad -1
.K9:
    .quad .S25
.Lfern_cagg_end:
    .align 8
.Lfern_cfn_begin:
.Lfern_cfn_end:
    .align 8
.Lfern_cref_begin:
    .quad .K1_0
    .quad .K1_1
    .quad .K10_0
    .quad .K10_1
    .quad .K10_2
    .quad .K10_3
    .quad .K10_4
    .quad .K10_5
    .quad .K10_6
    .quad .K10_7
    .quad .K10_8
    .quad .K10_9
    .quad .K10_10
    .quad .K10_11
    .quad .K10_12
    .quad .K10_13
    .quad .K10_14
    .quad .K10_15
    .quad .K10_16
    .quad .K10_17
    .quad .K10_18
    .quad .K10_19
    .quad .K10_20
    .quad .K10_21
    .quad .K10_22
    .quad .K10_23
    .quad .K10_24
    .quad .K10_25
    .quad .K10_26
    .quad .K10_27
    .quad .K10_28
    .quad .K10_29
    .quad .K10_30
    .quad .K10_31
    .quad .K10_32
    .quad .K10_33
    .quad .K10_34
    .quad .K10_35
    .quad .K10_36
    .quad .K10_37
    .quad .K10_38
    .quad .K10_39
    .quad .K10_40
    .quad .K10_41
    .quad .K10_42
    .quad .K10_43
    .quad .K10_44
    .quad .K10_45
    .quad .K10_46
    .quad .K10_47
    .quad .K10_48
    .quad .K10_49
    .quad .K10_50
    .quad .K10_51
    .quad .K10_52
    .quad .K10_53
    .quad .K10_54
    .quad .K10_55
    .quad .K10_56
    .quad .K10_57
    .quad .K10_58
    .quad .K10_59
    .quad .K10_60
    .quad .K10_61
    .quad .K10_62
    .quad .K10_63
    .quad .K10_64
    .quad .K10_65
    .quad .K10_66
    .quad .K10_67
    .quad .K10_68
    .quad .K10_69
    .quad .K10_70
    .quad .K10_71
    .quad .K10_72
    .quad .K10_73
    .quad .K10_74
    .quad .K10_75
    .quad .K10_76
    .quad .K10_77
    .quad .K10_78
    .quad .K10_79
    .quad .K10_80
    .quad .K10_81
    .quad .K10_82
    .quad .K10_83
    .quad .K10_84
    .quad .K10_85
    .quad .K10_86
    .quad .K10_87
    .quad .K10_88
    .quad .K10_89
    .quad .K10_90
    .quad .K10_91
    .quad .K10_92
    .quad .K10_93
    .quad .K10_94
    .quad .K10_95
    .quad .K10_96
    .quad .K10_97
    .quad .K10_98
    .quad .K10_99
    .quad .K12_0
    .quad .K12_1
    .quad .K12_2
    .quad .K12_3
    .quad .K12_4
    .quad .K12_5
    .quad .K12_6
    .quad .K12_7
    .quad .K12_8
    .quad .K12_9
    .quad .K12_10
    .quad .K12_11
    .quad .K12_12
    .quad .K12_13
    .quad .K12_14
    .quad .K12_15
    .quad .K12_16
    .quad .K12_17
    .quad .K12_18
    .quad .K12_19
    .quad .K12_20
    .quad .K12_21
    .quad .K12_22
    .quad .K12_23
    .quad .K12_24
    .quad .K12_25
    .quad .K12_26
    .quad .K12_27
    .quad .K12_28
    .quad .K12_29
    .quad .K12_30
    .quad .K12_31
    .quad .K12_32
    .quad .K12_33
    .quad .K12_34
    .quad .K12_35
    .quad .K12_36
    .quad .K12_37
    .quad .K12_38
    .quad .K12_39
    .quad .K12_40
    .quad .K12_41
    .quad .K12_42
    .quad .K12_43
    .quad .K12_44
    .quad .K12_45
    .quad .K12_46
    .quad .K12_47
    .quad .K12_48
.Lfern_cref_end:
    .text
