    .globl _start
    .text
__fn_http____shared_string:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____shared_string.k:
__fn_http____shared_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
.Lssa_http____shared_string_0:
    ldr x9, [x22, #8]
    sub x10, x21, x20
    sxtw x10, w10
    cmp x9, x10
    b.ne .Lssa_http____shared_string_1
.Lssa_http____shared_string_4:
    ldr x9, [x22, #8]
    mov x10, #0
    mov x4, x9
    mov x3, x10
    mov x2, x22
    mov x1, x20
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L0_aop
    mov x1, #0
.L0_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L0_bop
    mov x3, #0
.L0_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L0_nok
    mov x4, #0
.L0_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L0_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L0_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L0_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L0_done
.L0_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L0_vec
.L0_short:
    cmp x10, #8
    b.lt .L0_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L0_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L0_eq
    add x8, x8, x14
.L0_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L0_done
.L0_w4:
    cmp x10, #4
    b.lt .L0_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L0_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L0_eq
    add x8, x8, x14
.L0_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L0_done
.L0_w2:
    cmp x10, #2
    b.lt .L0_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L0_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L0_eq
    add x8, x8, x14
.L0_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L0_done
.L0_tail:
    cmp x8, x13
    b.ge .L0_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L0_th
    add x8, x8, #1
    add x9, x9, #1
    b .L0_tail
.L0_th:
    sub x2, x8, x12
    b .L0_done
.L0_eq:
    mov x2, x4
.L0_done:
    mov x0, x2
    ldr x10, [x22, #8]
    cmp x0, x10
    b.ne .Lssa_http____shared_string_1
.Lssa_http____shared_string_3:
    tbnz x22, #0, .Lssa_http____shared_string_rcinc30
    cmp x22, #16, lsl #12
    b.lo .Lssa_http____shared_string_rcinc30
    ldur w5, [x22, #-8]
    tbnz w5, #31, .Lssa_http____shared_string_rcinc30
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http____shared_string_rcinc30:
    mov x0, x22
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____shared_string_1:
    str x21, [sp, #-16]!
    str x20, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____token_is:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____token_is.k:
__fn_http____token_is.r:
.Lssa_http____token_is_0:
    ldr x10, [x0, #8]
    mov x11, #0
    mov x4, x11
    mov x11, x9
    mov x9, x4
    b __fn_http____token_at.r
    .cfi_endproc
    .ltorg
__fn_http____token_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____token_at.k:
__fn_http____token_at.r:
.Lssa_http____token_at_0:
.Lssa_http____token_at_10:
.Lssa_http____token_at_11:
    cmp x9, x10
    b.ge .Lssa_http____token_at_34
.Lssa_http____token_at_18:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w12, [x6, x9]
.Lssa_http____token_at_17:
    cmp x12, #32
    b.eq .Lssa_http____token_at_12
.Lssa_http____token_at_15:
    cmp x12, #9
    b.ne .Lssa_http____token_at_34
.Lssa_http____token_at_12:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____token_at_18
.Lssa_http____token_at_8:
.Lssa_http____token_at_34:
    cmp x10, x9
    b.le .Lssa_http____token_at_7
.Lssa_http____token_at_41:
    sub x12, x10, #1
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w13, [x6, x12]
.Lssa_http____token_at_40:
    cmp x13, #32
    b.eq .Lssa_http____token_at_35
.Lssa_http____token_at_38:
    cmp x13, #9
    b.ne .Lssa_http____token_at_7
.Lssa_http____token_at_35:
    sub x10, x10, #1
    cmp x10, x9
    b.gt .Lssa_http____token_at_41
.Lssa_http____token_at_7:
    sub x10, x10, x9
    sxtw x10, w10
    ldr x13, [x11, #8]
    cmp x10, x13
    b.eq .Lssa_http____token_at_4
.Lssa_http____token_at_6:
    mov x0, #0
    ret
.Lssa_http____token_at_4:
.Lssa_http____token_at_3:
    ldr x10, [x11, #8]
    ldr x13, [x11, #0]
    mov x11, #0
.Lssa_http____token_at_61:
    cmp x11, x10
    b.ge .Lssa_http____token_at_2
.Lssa_http____token_at_74:
    add w12, w9, w11
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
.Lssa_http____token_at_73:
    cmp x14, #65
    b.lt .Lssa_http____token_at_69
.Lssa_http____token_at_72:
    cmp x14, #90
    b.gt .Lssa_http____token_at_69
.Lssa_http____token_at_71:
    add x12, x14, #32
    sxtw x12, w12
    mov x14, x12
.Lssa_http____token_at_70:
.Lssa_http____token_at_69:
    ldrb w12, [x13, x11]
.Lssa_http____token_at_68:
    cmp x12, #65
    b.lt .Lssa_http____token_at_64
.Lssa_http____token_at_67:
    cmp x12, #90
    b.gt .Lssa_http____token_at_64
.Lssa_http____token_at_66:
    add x15, x12, #32
    sxtw x15, w15
    mov x12, x15
.Lssa_http____token_at_65:
.Lssa_http____token_at_64:
    cmp x14, x12
    b.ne .Lssa_http____token_at_1
.Lssa_http____token_at_62:
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_http____token_at_74
.Lssa_http____token_at_2:
    mov x0, #1
    ret
.Lssa_http____token_at_1:
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn_http____leading_fields:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____leading_fields.k:
__fn_http____leading_fields.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x0
    mov x20, x9
.Lssa_http____leading_fields_0:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http____leading_fields_2:
    mov x21, x0
    mov x22, #0
.Lssa_http____leading_fields_3:
    cmp x22, x20
    b.lt .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_6:
    mov x0, x19
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http____leading_fields_1
.Lssa_http____leading_fields_4:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x22, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x19, #16]
    ldr x6, [x9]
    cmp x22, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    ldr x23, [x9, x5, lsl #3]
    tst x21, #1
    b.ne .Lssa_http____leading_fields_uq4
    cmp x21, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq4
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_http____leading_fields_uq4:
    b.ne .Lssa_http____leading_fields_10
.Lssa_http____leading_fields_9:
    mov x24, x21
    b .Lssa_http____leading_fields_11
.Lssa_http____leading_fields_10:
    mov x24, #0
.Lssa_http____leading_fields_11:
    ldr x25, [x21, #8]
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_14
.Lssa_http____leading_fields_12:
    tbnz x25, #0, .Lssa_http____leading_fields_rcinc55
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc55
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc55
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcinc55:
    mov x0, x25
.Lssa_http____leading_fields_14:
    tbnz x10, #0, .Lssa_http____leading_fields_rcinc56
    cmp x10, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc56
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc56
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_http____leading_fields_rcinc56:
    mov x0, x10
    tst x25, #1
    b.ne .Lssa_http____leading_fields_uq14
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq14
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_http____leading_fields_uq14:
    b.ne .Lssa_http____leading_fields_16
.Lssa_http____leading_fields_15:
    mov x0, x25
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush58s
.Lssa_http____leading_fields_apush58o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush58e
.Lssa_http____leading_fields_apush58s:
    str x10, [sp, #56]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
.Lssa_http____leading_fields_apush58e:
    mov x26, x0
    b .Lssa_http____leading_fields_17
.Lssa_http____leading_fields_16:
    mov x0, x25
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush59s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http____leading_fields_apush59o
    tbz w3, #31, .Lssa_http____leading_fields_apush59s
.Lssa_http____leading_fields_apush59o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush59e
.Lssa_http____leading_fields_apush59s:
    bl __fern_arr_push
.Lssa_http____leading_fields_apush59e:
    mov x26, x0
    mov x0, x25
    bl __fn___fern_arr_inc_elems.r
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcdeck61
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http____leading_fields_rcdecd61
    tbnz w5, #31, .Lssa_http____leading_fields_rcdeck61
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http____leading_fields_rcdece61
.Lssa_http____leading_fields_rcdecd61:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcdeck61:
    mov x0, x25
.Lssa_http____leading_fields_rcdece61:
.Lssa_http____leading_fields_17:
    ldr x25, [x21, #16]
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_20
.Lssa_http____leading_fields_18:
    tbnz x25, #0, .Lssa_http____leading_fields_rcinc66
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc66
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc66
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcinc66:
    mov x0, x25
.Lssa_http____leading_fields_20:
    tbnz x23, #0, .Lssa_http____leading_fields_rcinc67
    cmp x23, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcinc67
    ldur w5, [x23, #-8]
    tbnz w5, #31, .Lssa_http____leading_fields_rcinc67
    add w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_http____leading_fields_rcinc67:
    mov x0, x23
    tst x25, #1
    b.ne .Lssa_http____leading_fields_uq20
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_uq20
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_http____leading_fields_uq20:
    b.ne .Lssa_http____leading_fields_22
.Lssa_http____leading_fields_21:
    mov x0, x25
    mov x1, x23
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush69s
.Lssa_http____leading_fields_apush69o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush69e
.Lssa_http____leading_fields_apush69s:
    bl __fern_arr_push_owned
.Lssa_http____leading_fields_apush69e:
    mov x27, x0
    b .Lssa_http____leading_fields_23
.Lssa_http____leading_fields_22:
    mov x0, x25
    mov x1, x23
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http____leading_fields_apush70s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http____leading_fields_apush70o
    tbz w3, #31, .Lssa_http____leading_fields_apush70s
.Lssa_http____leading_fields_apush70o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http____leading_fields_apush70e
.Lssa_http____leading_fields_apush70s:
    bl __fern_arr_push
.Lssa_http____leading_fields_apush70e:
    mov x27, x0
    mov x0, x25
    bl __fn___fern_arr_inc_elems.r
    cmp x25, #16, lsl #12
    b.lo .Lssa_http____leading_fields_rcdeck72
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_http____leading_fields_rcdecd72
    tbnz w5, #31, .Lssa_http____leading_fields_rcdeck72
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_http____leading_fields_rcdece72
.Lssa_http____leading_fields_rcdecd72:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http____leading_fields_rcdeck72:
    mov x0, x25
.Lssa_http____leading_fields_rcdece72:
.Lssa_http____leading_fields_23:
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_25
.Lssa_http____leading_fields_24:
    mov x10, #3
    str x24, [sp, #-16]!
    str x10, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x10, .S0
    add x10, x10, :lo12:.S0
    str x10, [x0, #0]
    mov x25, x0
    b .Lssa_http____leading_fields_26
.Lssa_http____leading_fields_25:
    mov x25, x24
.Lssa_http____leading_fields_26:
    cmp x24, #0
    b.ne .Lssa_http____leading_fields_29
.Lssa_http____leading_fields_28:
    mov x0, x21
    bl __fn___sem_release_HeaderMap.r
.Lssa_http____leading_fields_29:
    str x26, [x25, #8]
    str x27, [x25, #16]
    add x22, x22, #1
    mov x21, x25
    cmp x22, x20
    b.ge .Lssa_http____leading_fields_6
    b .Lssa_http____leading_fields_4
.Lssa_http____leading_fields_1:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____field_at:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____field_at.k:
__fn_http____field_at.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____field_at_0:
.Lssa_http____field_at_3:
    mov x21, x10
.Lssa_http____field_at_4:
    ldr x10, [x19, #8]
    ldr x9, [x10, #0]
    cmp x21, x9
    b.ge .Lssa_http____field_at_2
.Lssa_http____field_at_8:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x10, [x9, x5, lsl #3]
    ldr x9, [x10, #8]
    ldr x10, [x20, #8]
    cmp x9, x10
    b.ne .Lssa_http____field_at_5
.Lssa_http____field_at_7:
    ldr x9, [x19, #8]
    ldr x6, [x9]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x0, [x9, x5, lsl #3]
    mov x9, x20
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_http____field_at_1
.Lssa_http____field_at_5:
    add x21, x21, #1
    b .Lssa_http____field_at_4
.Lssa_http____field_at_2:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____field_at_1:
    mov x0, x21
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____kind_if:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____kind_if.k:
__fn_http____kind_if.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x10
.Lssa_http____kind_if_0:
    bl __fn_string__eq_ignore_ascii_case.r
    cbz x0, .Lssa_http____kind_if_1
.Lssa_http____kind_if_3:
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____kind_if_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http__parse_request_bytes:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http__parse_request_bytes.k:
__fn_http__parse_request_bytes.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
.Lssa_http__parse_request_bytes_0:
    bl __fn_http__parse_request_framed.r
    mov x19, x0
    mov x20, x1
    cmp x19, #0
    b.ne .Lssa_http__parse_request_bytes_9
.Lssa_http__parse_request_bytes_10:
    tst x20, #1
    b.ne .Lssa_http__parse_request_bytes_uq10
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_bytes_uq10
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_bytes_uq10:
    b.ne .Lssa_http__parse_request_bytes_17
.Lssa_http__parse_request_bytes_16:
    mov x9, x20
    b .Lssa_http__parse_request_bytes_18
.Lssa_http__parse_request_bytes_17:
    mov x9, #0
.Lssa_http__parse_request_bytes_18:
    ldr x21, [x20, #8]
    cmp x9, #0
    b.ne .Lssa_http__parse_request_bytes_21
.Lssa_http__parse_request_bytes_19:
    tbnz x21, #0, .Lssa_http__parse_request_bytes_rcinc77
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_bytes_rcinc77
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_bytes_rcinc77
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_bytes_rcinc77:
    mov x0, x21
.Lssa_http__parse_request_bytes_21:
    cmp x9, #0
    b.eq .Lssa_http__parse_request_bytes_23
.Lssa_http__parse_request_bytes_22:
    ldr x9, [x20, #32]
    tbnz x9, #0, .Lssa_http__parse_request_bytes_rcdeck81
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_bytes_rcdeck81
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_bytes_rcdecd81
    tbnz w5, #31, .Lssa_http__parse_request_bytes_rcdeck81
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_bytes_rcdece81
.Lssa_http__parse_request_bytes_rcdecd81:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_bytes_rcdeck81:
    mov x0, x9
.Lssa_http__parse_request_bytes_rcdece81:
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_bytes_24
.Lssa_http__parse_request_bytes_23:
    mov x0, x20
    bl __fn___sem_release_http__HttpFramed.r
.Lssa_http__parse_request_bytes_24:
    mov x1, x21
    mov x0, x1
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_bytes_9:
    cmp x19, #1
    b.ne .Lssa_http__parse_request_bytes_6
.Lssa_http__parse_request_bytes_7:
    adrp x9, .K2
    add x9, x9, :lo12:.K2
    mov x1, x9
    mov x0, x1
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_bytes_6:
    cmp x19, #2
    b.ne .Lssa_http__parse_request_bytes_1
.Lssa_http__parse_request_bytes_4:
    adrp x9, .K3
    add x9, x9, :lo12:.K3
    mov x1, x9
    mov x0, x1
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_bytes_1:
    mov x0, #2
    bl __fern_arr_box
    adrp x9, .S3
    add x9, x9, :lo12:.S3
    str x9, [x0, #0]
    str x20, [x0, #8]
    mov x1, x0
    mov x10, x1
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http__parse_request_framed:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http__parse_request_framed.k:
__fn_http__parse_request_framed.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #144
    mov x19, x0
.Lssa_http__parse_request_framed_0:
    mov x9, #8192
    mov x4, #32768
    str x4, [sp, #136]
    movz x4, #16, lsl #16
    str x4, [sp, #128]
    adrp x4, .SB4
    add x4, x4, :lo12:.SB4
    str x4, [sp, #120]
    adrp x4, .SB4
    add x4, x4, :lo12:.SB4
    str x4, [sp, #112]
    adrp x24, .K1
    add x24, x24, :lo12:.K1
.Lssa_http__parse_request_framed_424:
    ldr x10, [x19, #0]
    cmp x10, #1
    b.le .Lssa_http__parse_request_framed_420
.Lssa_http__parse_request_framed_423:
    ldrb w10, [x19, #8]
    cmp x10, #13
    b.ne .Lssa_http__parse_request_framed_420
.Lssa_http__parse_request_framed_422:
    ldr x6, [x19, #0]
    cmp x6, #1
    b.hi 1f
    b __fern_oob_abort
1:
    ldrb w10, [x19, #9]
    cmp x10, #10
    b.ne .Lssa_http__parse_request_framed_420
.Lssa_http__parse_request_framed_421:
    mov x5, #2
    str x5, [sp, #104]
    b .Lssa_http__parse_request_framed_419
.Lssa_http__parse_request_framed_420:
    str xzr, [sp, #104]
.Lssa_http__parse_request_framed_419:
    ldr x4, [x19, #0]
    str x4, [sp, #96]
    ldr x4, [sp, #104]
    ldr x5, [sp, #96]
    cmp x4, x5
    b.lt .Lssa_http__parse_request_framed_415
.Lssa_http__parse_request_framed_418:
    mov x11, #1
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_415:
    ldr x4, [sp, #104]
    add x9, x4, x9
    add x9, x9, #2
    sxtw x27, w9
    ldr x5, [sp, #136]
    add x9, x4, x5
    add x9, x9, #4
    sxtw x4, w9
    str x4, [sp, #88]
    ldr x5, [sp, #96]
    cmp x4, x5
    ldr x6, [sp, #96]
    csel x22, x4, x6, lt
.Lssa_http__parse_request_framed_412:
    mov x20, #-1
    mov x4, #-1
    str x4, [sp, #80]
    adrp x9, .K4
    add x9, x9, :lo12:.K4
    mov x2, x9
    ldr x1, [sp, #104]
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L1
    mov x1, #0
.L1:
    adrp x9, .S5
    add x9, x9, :lo12:.S5
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L4
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L2:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L3
    add x5, x5, #16
    cmp x5, x8
    b.ls .L2
    sub x1, x5, x0
    b .L4
.L3:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L5
.L4:
    add x10, x9, #96
.L8:
    cmp x1, x3
    b.ge .L6
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L5
    add x1, x1, #1
    b .L8
.L5:
    str x1, [sp, #-16]!
    b .L7
.L6:
    str x3, [sp, #-16]!
.L7:
    ldr x0, [sp], #16
.Lssa_http__parse_request_framed_411:
    cmp x0, x22
    b.lt .Lssa_http__parse_request_framed_408
.Lssa_http__parse_request_framed_410:
    mov x10, #2
    b .Lssa_http__parse_request_framed_398
.Lssa_http__parse_request_framed_408:
    ldr x6, [x19]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x0
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_framed_405
.Lssa_http__parse_request_framed_407:
    add x9, x0, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http__parse_request_framed_403
.Lssa_http__parse_request_framed_406:
    add x9, x0, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http__parse_request_framed_403
.Lssa_http__parse_request_framed_405:
    mov x10, #1
    b .Lssa_http__parse_request_framed_398
.Lssa_http__parse_request_framed_403:
    add x10, x0, #1
    ldr x9, [x19, #0]
    cmp x10, x9
    b.lt .Lssa_http__parse_request_framed_400
.Lssa_http__parse_request_framed_402:
    mov x10, #2
    b .Lssa_http__parse_request_framed_398
.Lssa_http__parse_request_framed_400:
    mov x10, #0
.Lssa_http__parse_request_framed_399:
.Lssa_http__parse_request_framed_398:
    ldr x26, [sp, #104]
    mov x25, x0
    mov x11, x10
    ldr x10, [sp, #104]
    mov x23, #0
    mov x9, #0
.Lssa_http__parse_request_framed_472:
    cmp x11, #2
    b.ne .Lssa_http__parse_request_framed_499
.Lssa_http__parse_request_framed_501:
    ldr x25, [sp, #80]
    b .Lssa_http__parse_request_framed_392
.Lssa_http__parse_request_framed_499:
    cmp x11, #1
    b.ne .Lssa_http__parse_request_framed_497
.Lssa_http__parse_request_framed_498:
    add x11, x25, #1
    sxtw x11, w11
    mov x28, x11
    mov x26, x11
    mov x23, #1
    mov x21, #0
    b .Lssa_http__parse_request_framed_486
.Lssa_http__parse_request_framed_497:
    mov x11, #-1
    cmp x20, x11
    b.ne .Lssa_http__parse_request_framed_490
.Lssa_http__parse_request_framed_496:
    add x11, x25, #1
    sxtw x11, w11
.Lssa_http__parse_request_framed_495:
    mov x12, #-2
    cmp x11, x27
    csel x12, x12, x25, ge
    b .Lssa_http__parse_request_framed_491
.Lssa_http__parse_request_framed_493:
    b .Lssa_http__parse_request_framed_490
.Lssa_http__parse_request_framed_491:
    mov x20, x12
.Lssa_http__parse_request_framed_490:
    cmp x25, x10
    b.ne .Lssa_http__parse_request_framed_487
.Lssa_http__parse_request_framed_489:
    cbnz x9, .Lssa_http__parse_request_framed_397
.Lssa_http__parse_request_framed_487:
    add x10, x25, #2
    sxtw x10, w10
    mov x28, x10
    mov x26, x10
    mov x21, #1
.Lssa_http__parse_request_framed_486:
    adrp x10, .K4
    add x10, x10, :lo12:.K4
    mov x2, x10
    mov x1, x26
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L9
    mov x1, #0
.L9:
    adrp x9, .S5
    add x9, x9, :lo12:.S5
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L12
    add x10, x9, #352
    ld1r {v20.16b}, [x10]
    add x10, x9, #353
    ld1r {v21.16b}, [x10]
.L10:
    ldr q0, [x5]
    cmeq v1.16b, v0.16b, v20.16b
    cmeq v2.16b, v0.16b, v21.16b
    orr v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L11
    add x5, x5, #16
    cmp x5, x8
    b.ls .L10
    sub x1, x5, x0
    b .L12
.L11:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L13
.L12:
    add x10, x9, #96
.L16:
    cmp x1, x3
    b.ge .L14
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L13
    add x1, x1, #1
    b .L16
.L13:
    str x1, [sp, #-16]!
    b .L15
.L14:
    str x3, [sp, #-16]!
.L15:
    ldr x0, [sp], #16
    mov x25, x0
.Lssa_http__parse_request_framed_485:
    cmp x25, x22
    b.lt .Lssa_http__parse_request_framed_482
.Lssa_http__parse_request_framed_484:
    mov x11, #2
    b .Lssa_http__parse_request_framed_473
.Lssa_http__parse_request_framed_482:
    ldr x6, [x19]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x25
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http__parse_request_framed_479
.Lssa_http__parse_request_framed_481:
    add x10, x25, #1
    ldr x9, [x19, #0]
    cmp x10, x9
    b.ge .Lssa_http__parse_request_framed_477
.Lssa_http__parse_request_framed_480:
    add x10, x25, #1
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_framed_477
.Lssa_http__parse_request_framed_479:
    mov x11, #1
    b .Lssa_http__parse_request_framed_473
.Lssa_http__parse_request_framed_477:
    add x9, x25, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.lt .Lssa_http__parse_request_framed_474
.Lssa_http__parse_request_framed_476:
    mov x11, #2
    b .Lssa_http__parse_request_framed_473
.Lssa_http__parse_request_framed_474:
    mov x11, #0
.Lssa_http__parse_request_framed_473:
    mov x10, x28
    mov x9, x21
    cmp x11, #2
    b.eq .Lssa_http__parse_request_framed_501
    b .Lssa_http__parse_request_framed_499
.Lssa_http__parse_request_framed_397:
    sub x11, x25, #2
    sxtw x11, w11
    add x25, x25, #1
    sxtw x25, w25
.Lssa_http__parse_request_framed_396:
    mov x9, #-2
    ldr x5, [sp, #88]
    cmp x25, x5
    csel x9, x9, x11, ge
.Lssa_http__parse_request_framed_393:
    mov x25, x9
.Lssa_http__parse_request_framed_392:
    mov x9, #-1
    cmp x20, x9
    b.ne .Lssa_http__parse_request_framed_386
.Lssa_http__parse_request_framed_390:
    ldr x21, [x19, #0]
    cmp x27, x22
    b.le .Lssa_http__parse_request_framed_374
.Lssa_http__parse_request_framed_389:
    cmp x22, x21
    b.ge .Lssa_http__parse_request_framed_374
.Lssa_http__parse_request_framed_388:
    cmp x27, x21
    csel x22, x27, x21, lt
    b .Lssa_http__parse_request_framed_383
.Lssa_http__parse_request_framed_386:
    str x20, [sp, #80]
    b .Lssa_http__parse_request_framed_369
.Lssa_http__parse_request_framed_384:
.Lssa_http__parse_request_framed_383:
    mov x9, #13
    mov x2, x26
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L17
    mov x2, #0
.L17:
    cmp x1, #255
    b.hi .L22
    cmp x2, x3
    b.ge .L22
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L19
.L18:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L24
    cmp x5, x8
    b.ls .L18
.L19:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L20
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L20
    sub x5, x5, #16
    b .L25
.L24:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L25
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L25:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L23
.L20:
    cmp x5, x6
    b.ge .L22
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L21
    add x5, x5, #1
    b .L20
.L21:
    sub x2, x5, x0
    b .L23
.L22:
    mov x2, #-1
.L23:
    mov x0, x2
.Lssa_http__parse_request_framed_382:
    mov x26, x0
.Lssa_http__parse_request_framed_575:
    cmp x26, #0
    b.lt .Lssa_http__parse_request_framed_381
.Lssa_http__parse_request_framed_579:
    add x9, x26, #1
    sxtw x9, w9
    cmp x9, x22
    b.ge .Lssa_http__parse_request_framed_381
.Lssa_http__parse_request_framed_578:
    add w9, w26, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w11, [x5, #8]
    cmp x11, #10
    b.eq .Lssa_http__parse_request_framed_378
.Lssa_http__parse_request_framed_576:
    add x11, x26, #1
    sxtw x11, w11
    mov x9, #13
    mov x2, x11
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L26
    mov x2, #0
.L26:
    cmp x1, #255
    b.hi .L31
    cmp x2, x3
    b.ge .L31
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L28
.L27:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L33
    cmp x5, x8
    b.ls .L27
.L28:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L29
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L29
    sub x5, x5, #16
    b .L34
.L33:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L34
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L34:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L32
.L29:
    cmp x5, x6
    b.ge .L31
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L30
    add x5, x5, #1
    b .L29
.L30:
    sub x2, x5, x0
    b .L32
.L31:
    mov x2, #-1
.L32:
    mov x26, x2
    cmp x26, #0
    b.ge .Lssa_http__parse_request_framed_579
.Lssa_http__parse_request_framed_381:
    mov x9, #-1
    mov x26, x9
.Lssa_http__parse_request_framed_379:
.Lssa_http__parse_request_framed_378:
    cmp x26, #0
    b.lt .Lssa_http__parse_request_framed_374
.Lssa_http__parse_request_framed_377:
    mov x9, x26
    b .Lssa_http__parse_request_framed_370
.Lssa_http__parse_request_framed_374:
    cmp x21, x27
    b.lt .Lssa_http__parse_request_framed_371
.Lssa_http__parse_request_framed_373:
    mov x9, #-2
    b .Lssa_http__parse_request_framed_370
.Lssa_http__parse_request_framed_371:
    mov x9, #-1
.Lssa_http__parse_request_framed_370:
    str x9, [sp, #80]
.Lssa_http__parse_request_framed_369:
    mov x9, #-1
    cmp x25, x9
    b.ne .Lssa_http__parse_request_framed_363
.Lssa_http__parse_request_framed_368:
    ldr x4, [sp, #96]
    ldr x5, [sp, #88]
    cmp x4, x5
    b.lt .Lssa_http__parse_request_framed_363
.Lssa_http__parse_request_framed_367:
    mov x9, #-2
    mov x25, x9
.Lssa_http__parse_request_framed_366:
.Lssa_http__parse_request_framed_365:
.Lssa_http__parse_request_framed_363:
    mov x9, #-2
    ldr x4, [sp, #80]
    cmp x4, x9
    b.ne .Lssa_http__parse_request_framed_360
.Lssa_http__parse_request_framed_362:
    mov x9, #414
    b .Lssa_http__parse_request_framed_353
.Lssa_http__parse_request_framed_360:
    mov x9, #-2
    cmp x25, x9
    b.ne .Lssa_http__parse_request_framed_357
.Lssa_http__parse_request_framed_359:
    mov x9, #431
    b .Lssa_http__parse_request_framed_353
.Lssa_http__parse_request_framed_357:
    cbz x23, .Lssa_http__parse_request_framed_354
.Lssa_http__parse_request_framed_356:
    mov x9, #400
    b .Lssa_http__parse_request_framed_353
.Lssa_http__parse_request_framed_354:
    mov x9, #0
.Lssa_http__parse_request_framed_353:
    cmp x9, #0
    b.eq .Lssa_http__parse_request_framed_350
.Lssa_http__parse_request_framed_352:
    mov x11, x9
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_350:
    mov x23, #-1
    mov x27, #-1
    adrp x26, .SB4
    add x26, x26, :lo12:.SB4
    ldr x4, [sp, #80]
    cmp x4, #0
    b.lt .Lssa_http__parse_request_framed_344
.Lssa_http__parse_request_framed_348:
    adrp x11, .K5
    add x11, x11, :lo12:.K5
    mov x2, x11
    ldr x1, [sp, #104]
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L35
    mov x1, #0
.L35:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L38
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L36:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L37
    add x5, x5, #16
    cmp x5, x8
    b.ls .L36
    sub x1, x5, x0
    b .L38
.L37:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L39
.L38:
    add x10, x9, #96
.L42:
    cmp x1, x3
    b.ge .L40
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L39
    add x1, x1, #1
    b .L42
.L39:
    str x1, [sp, #-16]!
    b .L41
.L40:
    str x3, [sp, #-16]!
.L41:
    ldr x0, [sp], #16
    ldr x5, [sp, #80]
    cmp x0, x5
    ldr x5, [sp, #80]
    csel x4, x5, x0, gt
    str x4, [sp, #96]
.Lssa_http__parse_request_framed_639:
    ldr x4, [sp, #96]
    ldr x5, [sp, #104]
    cmp x4, x5
    b.eq .Lssa_http__parse_request_framed_345
.Lssa_http__parse_request_framed_347:
    ldr x4, [sp, #96]
    ldr x5, [sp, #80]
    cmp x4, x5
    b.ge .Lssa_http__parse_request_framed_345
.Lssa_http__parse_request_framed_346:
    ldr x5, [sp, #96]
    ldr x6, [x19]
    cmp x5, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x5
    ldrb w11, [x5, #8]
    cmp x11, #32
    b.eq .Lssa_http__parse_request_framed_342
.Lssa_http__parse_request_framed_345:
    adrp x11, .SB4
    add x11, x11, :lo12:.SB4
    mov x10, #-1
    mov x9, #-1
    mov x23, x10
    mov x26, x9
    mov x22, x11
    mov x21, #400
    b .Lssa_http__parse_request_framed_223
.Lssa_http__parse_request_framed_344:
    str x23, [sp, #112]
    str x26, [sp, #96]
    mov x26, x27
    b .Lssa_http__parse_request_framed_220
.Lssa_http__parse_request_framed_342:
    ldr x4, [sp, #96]
    add x9, x4, #1
.Lssa_http__parse_request_framed_341:
    mov x10, #32
    mov x2, x9
    mov x1, x10
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L43
    mov x2, #0
.L43:
    cmp x1, #255
    b.hi .L48
    cmp x2, x3
    b.ge .L48
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L45
.L44:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L50
    cmp x5, x8
    b.ls .L44
.L45:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L46
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L46
    sub x5, x5, #16
    b .L51
.L50:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L51
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L51:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L49
.L46:
    cmp x5, x6
    b.ge .L48
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L47
    add x5, x5, #1
    b .L46
.L47:
    sub x2, x5, x0
    b .L49
.L48:
    mov x2, #-1
.L49:
    mov x0, x2
    mov x10, #-1
    ldr x5, [sp, #80]
    cmp x0, x5
    csel x26, x0, x10, lt
.Lssa_http__parse_request_framed_337:
    cmp x26, #0
    b.lt .Lssa_http__parse_request_framed_335
.Lssa_http__parse_request_framed_336:
    ldr x4, [sp, #96]
    add x9, x4, #1
    cmp x26, x9
    b.ne .Lssa_http__parse_request_framed_333
.Lssa_http__parse_request_framed_335:
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    mov x10, #-1
    mov x11, #-1
    mov x23, x10
    mov x26, x11
    mov x22, x9
    mov x21, #400
    b .Lssa_http__parse_request_framed_223
.Lssa_http__parse_request_framed_333:
    add x11, x26, #1
    sxtw x27, w11
.Lssa_http__parse_request_framed_332:
    ldr x4, [sp, #80]
    sub x11, x4, x27
    sxtw x11, w11
    cmp x11, #8
    b.ne .Lssa_http__parse_request_framed_330
.Lssa_http__parse_request_framed_331:
    adrp x11, .K6
    add x11, x11, :lo12:.K6
    mov x10, #0
    mov x9, #5
    mov x4, x9
    mov x3, x10
    mov x2, x11
    mov x1, x27
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2]
    add x2, x2, #8
    cmp x1, #0
    b.ge .L52_aop
    mov x1, #0
.L52_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L52_bop
    mov x3, #0
.L52_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L52_nok
    mov x4, #0
.L52_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L52_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L52_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L52_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L52_done
.L52_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L52_vec
.L52_short:
    cmp x10, #8
    b.lt .L52_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L52_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L52_eq
    add x8, x8, x14
.L52_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L52_done
.L52_w4:
    cmp x10, #4
    b.lt .L52_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L52_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L52_eq
    add x8, x8, x14
.L52_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L52_done
.L52_w2:
    cmp x10, #2
    b.lt .L52_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L52_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L52_eq
    add x8, x8, x14
.L52_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L52_done
.L52_tail:
    cmp x8, x13
    b.ge .L52_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L52_th
    add x8, x8, #1
    add x9, x9, #1
    b .L52_tail
.L52_th:
    sub x2, x8, x12
    b .L52_done
.L52_eq:
    mov x2, x4
.L52_done:
    mov x0, x2
    cmp x0, #5
    b.eq .Lssa_http__parse_request_framed_328
.Lssa_http__parse_request_framed_330:
    mov x10, #400
    b .Lssa_http__parse_request_framed_309
.Lssa_http__parse_request_framed_328:
    add w9, w27, #5
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_framed_327:
    cmp x10, #48
    b.lo .Lssa_http__parse_request_framed_312
.Lssa_http__parse_request_framed_326:
    cmp x10, #57
    b.hi .Lssa_http__parse_request_framed_312
.Lssa_http__parse_request_framed_322:
    add w10, w27, #6
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #46
    b.ne .Lssa_http__parse_request_framed_312
.Lssa_http__parse_request_framed_321:
    add w9, w27, #7
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_framed_320:
    cmp x10, #48
    b.lo .Lssa_http__parse_request_framed_312
.Lssa_http__parse_request_framed_319:
    cmp x10, #57
    b.hi .Lssa_http__parse_request_framed_312
.Lssa_http__parse_request_framed_314:
    add w27, w27, #5
    ldr x6, [x19]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x27
    ldrb w10, [x5, #8]
    cmp x10, #49
    b.eq .Lssa_http__parse_request_framed_310
.Lssa_http__parse_request_framed_313:
    mov x10, #505
    b .Lssa_http__parse_request_framed_309
.Lssa_http__parse_request_framed_312:
    mov x10, #400
    b .Lssa_http__parse_request_framed_309
.Lssa_http__parse_request_framed_310:
    b .Lssa_http__parse_request_framed_pool_408
    .ltorg
.Lssa_http__parse_request_framed_pool_408:
    mov x10, #0
.Lssa_http__parse_request_framed_309:
    cmp x10, #0
    b.eq .Lssa_http__parse_request_framed_306
.Lssa_http__parse_request_framed_308:
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    mov x11, #-1
    mov x12, #-1
    mov x21, x10
    mov x23, x11
    mov x26, x12
    mov x22, x9
    b .Lssa_http__parse_request_framed_223
.Lssa_http__parse_request_framed_306:
    ldr x4, [sp, #96]
    add x27, x4, #1
    ldr x5, [sp, #104]
    sub x12, x4, x5
    sxtw x12, w12
    cmp x12, #7
    b.ne .Lssa_http__parse_request_framed_304
.Lssa_http__parse_request_framed_305:
    adrp x23, .SB7
    add x23, x23, :lo12:.SB7
    ldr x12, [x23, #8]
    mov x11, #0
    mov x4, x12
    mov x3, x11
    mov x2, x23
    ldr x1, [sp, #104]
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L53_aop
    mov x1, #0
.L53_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L53_bop
    mov x3, #0
.L53_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L53_nok
    mov x4, #0
.L53_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L53_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L53_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L53_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L53_done
.L53_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L53_vec
.L53_short:
    cmp x10, #8
    b.lt .L53_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L53_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L53_eq
    add x8, x8, x14
.L53_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L53_done
.L53_w4:
    cmp x10, #4
    b.lt .L53_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L53_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L53_eq
    add x8, x8, x14
.L53_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L53_done
.L53_w2:
    cmp x10, #2
    b.lt .L53_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L53_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L53_eq
    add x8, x8, x14
.L53_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L53_done
.L53_tail:
    cmp x8, x13
    b.ge .L53_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L53_th
    add x8, x8, #1
    add x9, x9, #1
    b .L53_tail
.L53_th:
    sub x2, x8, x12
    b .L53_done
.L53_eq:
    mov x2, x4
.L53_done:
    mov x0, x2
    ldr x11, [x23, #8]
    cmp x0, x11
    cset x0, eq
    b .Lssa_http__parse_request_framed_301
.Lssa_http__parse_request_framed_304:
    mov x0, #0
.Lssa_http__parse_request_framed_303:
.Lssa_http__parse_request_framed_301:
    add x11, x27, #1
    sxtw x11, w11
    cmp x26, x11
    b.ne .Lssa_http__parse_request_framed_294
.Lssa_http__parse_request_framed_300:
    ldr x6, [x19]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x27
    ldrb w11, [x5, #8]
    cmp x11, #42
    b.ne .Lssa_http__parse_request_framed_294
.Lssa_http__parse_request_framed_299:
    cbz x0, .Lssa_http__parse_request_framed_296
.Lssa_http__parse_request_framed_298:
    mov x9, #-1
    mov x27, x9
    b .Lssa_http__parse_request_framed_287
.Lssa_http__parse_request_framed_296:
    mov x9, #-2
    mov x27, x9
    b .Lssa_http__parse_request_framed_287
.Lssa_http__parse_request_framed_294:
    cmp x26, x27
    b.le .Lssa_http__parse_request_framed_290
.Lssa_http__parse_request_framed_293:
    ldr x6, [x19]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x27
    ldrb w9, [x5, #8]
    cmp x9, #47
    b.ne .Lssa_http__parse_request_framed_290
.Lssa_http__parse_request_framed_292:
    b .Lssa_http__parse_request_framed_287
.Lssa_http__parse_request_framed_290:
    mov x0, x19
    mov x9, x27
    mov x10, x26
    bl __fn_http____absolute_form_path.r
    mov x9, x0
    cmp x9, #0
    b.ge .Lssa_http__parse_request_framed_288
.Lssa_http__parse_request_framed_289:
    mov x11, #-2
    mov x27, x11
    b .Lssa_http__parse_request_framed_287
.Lssa_http__parse_request_framed_288:
    mov x27, x9
.Lssa_http__parse_request_framed_287:
    mov x11, #-2
    cmp x27, x11
    b.ne .Lssa_http__parse_request_framed_284
.Lssa_http__parse_request_framed_286:
    mov x23, #0
    mov x21, #400
    mov x9, #0
    b .Lssa_http__parse_request_framed_227
.Lssa_http__parse_request_framed_284:
    mov x11, #-1
    cmp x27, x11
    b.ne .Lssa_http__parse_request_framed_280
.Lssa_http__parse_request_framed_283:
    adrp x11, .SB8
    add x11, x11, :lo12:.SB8
    mov x23, x11
    mov x21, #0
    mov x9, #1
    b .Lssa_http__parse_request_framed_227
.Lssa_http__parse_request_framed_280:
    mov x11, #2
    and x11, x19, x11
    cbz x11, .Lssa_http__parse_request_framed_763
.Lssa_http__parse_request_framed_762:
    mov x11, #-2
    add x11, x19, x11
    ldr x9, [x11, #0]
    ldr x12, [x11, #8]
    mov x4, x9
    mov x9, x12
    mov x12, x4
    b .Lssa_http__parse_request_framed_279
.Lssa_http__parse_request_framed_763:
    add x12, x19, #8
    cmp x19, #0
    b.eq .Lssa_http__parse_request_framed_766
.Lssa_http__parse_request_framed_765:
    ldr x9, [x19, #0]
    b .Lssa_http__parse_request_framed_279
.Lssa_http__parse_request_framed_766:
    mov x9, #0
.Lssa_http__parse_request_framed_767:
.Lssa_http__parse_request_framed_764:
.Lssa_http__parse_request_framed_279:
    mov x10, x27
.Lssa_http__parse_request_framed_768:
    cmp x10, x26
    b.ge .Lssa_http__parse_request_framed_278
.Lssa_http__parse_request_framed_771:
    mov w11, w10
    cmp x11, x9
    b.lo .Lssa_http__parse_request_framed_778
.Lssa_http__parse_request_framed_776:
    bl __fern_oob_abort
    mov x13, x0
.Lssa_http__parse_request_framed_778:
    ldrb w13, [x12, x11]
    cmp x13, #63
    b.eq .Lssa_http__parse_request_framed_277
.Lssa_http__parse_request_framed_769:
    add x10, x10, #1
    cmp x10, x26
    b.lt .Lssa_http__parse_request_framed_771
.Lssa_http__parse_request_framed_278:
    mov x9, #-1
    mov x23, x9
    b .Lssa_http__parse_request_framed_276
.Lssa_http__parse_request_framed_277:
    mov x23, x10
.Lssa_http__parse_request_framed_276:
    cmp x23, #0
    b.ge .Lssa_http__parse_request_framed_273
.Lssa_http__parse_request_framed_275:
    mov x23, x26
    b .Lssa_http__parse_request_framed_270
.Lssa_http__parse_request_framed_273:
    add x9, x23, #1
    sxtw x9, w9
    mov x0, x19
    mov x10, x26
    bl __fn_http____query_ok.r
    cbz x0, .Lssa_http__parse_request_framed_271
.Lssa_http__parse_request_framed_272:
    b .Lssa_http__parse_request_framed_270
.Lssa_http__parse_request_framed_271:
    mov x10, #-1
    mov x23, x10
.Lssa_http__parse_request_framed_270:
    cmp x23, #0
    b.ge .Lssa_http__parse_request_framed_267
.Lssa_http__parse_request_framed_269:
    mov x23, #0
    mov x21, #400
    mov x9, #0
    b .Lssa_http__parse_request_framed_227
.Lssa_http__parse_request_framed_267:
    cmp x27, x23
    b.ge .Lssa_http__parse_request_framed_249
.Lssa_http__parse_request_framed_265:
    add x10, x27, #1
.Lssa_http__parse_request_framed_264:
    mov x20, x10
    mov x28, x27
.Lssa_http__parse_request_framed_805:
    cmp x28, x23
    b.ge .Lssa_http__parse_request_framed_262
.Lssa_http__parse_request_framed_821:
    ldr x6, [x19]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x28
    ldrb w0, [x5, #8]
    cmp x0, #47
    b.ne .Lssa_http__parse_request_framed_813
.Lssa_http__parse_request_framed_820:
    cmp x28, x27
    b.le .Lssa_http__parse_request_framed_807
.Lssa_http__parse_request_framed_818:
    sub x10, x28, x20
    sxtw x10, w10
    cmp x10, #1
    b.lt .Lssa_http__parse_request_framed_814
.Lssa_http__parse_request_framed_817:
    cmp x10, #2
    b.gt .Lssa_http__parse_request_framed_814
.Lssa_http__parse_request_framed_816:
    ldr x6, [x19]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x20
    ldrb w9, [x5, #8]
    cmp x9, #46
    b.ne .Lssa_http__parse_request_framed_814
.Lssa_http__parse_request_framed_815:
    sub x9, x28, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w12, [x5, #8]
    cmp x12, #46
    b.eq .Lssa_http__parse_request_framed_809
.Lssa_http__parse_request_framed_814:
    mov x10, #0
    b .Lssa_http__parse_request_framed_809
.Lssa_http__parse_request_framed_813:
    cmp x0, #37
    b.eq .Lssa_http__parse_request_framed_249
.Lssa_http__parse_request_framed_812:
    str x10, [sp, #56]
    bl __fn_http____is_pchar.r
    ldr x10, [sp, #56]
    cbz x0, .Lssa_http__parse_request_framed_249
.Lssa_http__parse_request_framed_811:
    b .Lssa_http__parse_request_framed_806
.Lssa_http__parse_request_framed_810:
.Lssa_http__parse_request_framed_809:
    cmp x10, #0
    b.gt .Lssa_http__parse_request_framed_249
.Lssa_http__parse_request_framed_807:
    add x10, x28, #1
    mov x20, x10
.Lssa_http__parse_request_framed_806:
    add x28, x28, #1
    cmp x28, x23
    b.lt .Lssa_http__parse_request_framed_821
.Lssa_http__parse_request_framed_262:
    sub x10, x23, x20
    sxtw x10, w10
    cmp x10, #1
    b.lt .Lssa_http__parse_request_framed_258
.Lssa_http__parse_request_framed_261:
    cmp x10, #2
    b.gt .Lssa_http__parse_request_framed_258
.Lssa_http__parse_request_framed_260:
    ldr x6, [x19]
    cmp x20, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x20
    ldrb w12, [x5, #8]
    cmp x12, #46
    b.ne .Lssa_http__parse_request_framed_258
.Lssa_http__parse_request_framed_259:
    sub x12, x23, #1
    ldr x6, [x19]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x12
    ldrb w9, [x5, #8]
    cmp x9, #46
    b.eq .Lssa_http__parse_request_framed_254
.Lssa_http__parse_request_framed_258:
    mov x10, #0
.Lssa_http__parse_request_framed_255:
.Lssa_http__parse_request_framed_254:
    cmp x10, #0
    b.ne .Lssa_http__parse_request_framed_249
.Lssa_http__parse_request_framed_252:
    mov x0, x19
    mov x9, x27
    mov x10, x26
    ldr x11, [sp, #112]
    bl __fn_http____shared_string.r
    mov x23, x0
    mov x21, #0
    mov x9, #1
    b .Lssa_http__parse_request_framed_227
.Lssa_http__parse_request_framed_249:
    adrp x10, .K7
    add x10, x10, :lo12:.K7
    add x27, x27, #1
    sxtw x9, w27
.Lssa_http__parse_request_framed_248:
    mov x27, x10
    mov x20, #0
    mov x28, #0
    mov x22, #0
.Lssa_http__parse_request_framed_890:
    cmp x9, x23
    b.gt .Lssa_http__parse_request_framed_246
.Lssa_http__parse_request_framed_922:
    mov x10, #47
.Lssa_http__parse_request_framed_921:
    ldr x12, [x27, #0]
    cmp x20, x12
    b.ge .Lssa_http__parse_request_framed_918
.Lssa_http__parse_request_framed_920:
    tst x27, #1
    b.ne .Lssa_http__parse_request_framed_uq920
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq920
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq920:
    b.ne .Lssa_http__parse_request_framed_932
.Lssa_http__parse_request_framed_931:
    b .Lssa_http__parse_request_framed_933
.Lssa_http__parse_request_framed_932:
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3116
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3116
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3116
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_framed_rcdece3116
.Lssa_http__parse_request_framed_rcdecd3116:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3116:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3116:
    mov x12, #0
    ldr x13, [x27, #0]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x13, [sp, #-16]!
    str x12, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    mov x27, x0
.Lssa_http__parse_request_framed_933:
    mov x13, #47
    ldr x7, [x27]
    cmp x20, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, x20
    strb w13, [x5, #8]
    mov x12, x27
    b .Lssa_http__parse_request_framed_917
.Lssa_http__parse_request_framed_918:
    tst x27, #1
    b.ne .Lssa_http__parse_request_framed_uq918
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq918
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq918:
    b.ne .Lssa_http__parse_request_framed_936
.Lssa_http__parse_request_framed_935:
    mov x0, x27
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3124s
.Lssa_http__parse_request_framed_apush3124o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3124e
.Lssa_http__parse_request_framed_apush3124s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    bl __fern_arr_push_owned_u8
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
.Lssa_http__parse_request_framed_apush3124e:
    mov x12, x0
    b .Lssa_http__parse_request_framed_917
.Lssa_http__parse_request_framed_936:
    mov x0, x27
    mov x1, x10
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3125s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3125o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3125s
.Lssa_http__parse_request_framed_apush3125o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3125e
.Lssa_http__parse_request_framed_apush3125s:
    str x9, [sp, #56]
    bl __fern_arr_push_u8
    ldr x9, [sp, #56]
.Lssa_http__parse_request_framed_apush3125e:
    mov x12, x0
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3126
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3126
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3126
    str x9, [sp, #56]
    str x12, [sp, #48]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x12, [sp, #48]
    b .Lssa_http__parse_request_framed_rcdece3126
.Lssa_http__parse_request_framed_rcdecd3126:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3126:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3126:
.Lssa_http__parse_request_framed_937:
.Lssa_http__parse_request_framed_917:
    add x10, x20, #1
    sxtw x10, w10
.Lssa_http__parse_request_framed_916:
    mov x27, x12
    mov x12, x9
.Lssa_http__parse_request_framed_938:
    cmp x12, x23
    b.ge .Lssa_http__parse_request_framed_915
.Lssa_http__parse_request_framed_965:
    ldr x6, [x19]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x12
    ldrb w9, [x5, #8]
    cmp x9, #47
    b.eq .Lssa_http__parse_request_framed_915
.Lssa_http__parse_request_framed_963:
    cmp x9, #37
    b.ne .Lssa_http__parse_request_framed_957
.Lssa_http__parse_request_framed_962:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    mov x0, x19
    mov x9, x12
    mov x10, x23
    bl __fn_http____pct_byte.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    cmp x0, #0
    b.le .Lssa_http__parse_request_framed_960
.Lssa_http__parse_request_framed_961:
    cmp x0, #47
    b.ne .Lssa_http__parse_request_framed_959
.Lssa_http__parse_request_framed_960:
    mov x13, #-1
    b .Lssa_http__parse_request_framed_954
.Lssa_http__parse_request_framed_959:
    mov x13, x0
    b .Lssa_http__parse_request_framed_954
.Lssa_http__parse_request_framed_957:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    mov x0, x9
    bl __fn_http____is_pchar.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    cbz x0, .Lssa_http__parse_request_framed_955
.Lssa_http__parse_request_framed_956:
    mov x13, x9
    b .Lssa_http__parse_request_framed_954
.Lssa_http__parse_request_framed_955:
    mov x13, #-1
.Lssa_http__parse_request_framed_954:
    cmp x13, #0
    b.ge .Lssa_http__parse_request_framed_952
.Lssa_http__parse_request_framed_993:
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3168
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3168
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3168
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    b .Lssa_http__parse_request_framed_rcdece3168
.Lssa_http__parse_request_framed_rcdecd3168:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3168:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3168:
    b .Lssa_http__parse_request_framed_241
.Lssa_http__parse_request_framed_952:
    mov x11, #1
    cmp x13, #128
    cset x14, ge
    cmp x22, #0
    csel x22, x11, x14, ne
.Lssa_http__parse_request_framed_949:
    and x14, x13, #255
.Lssa_http__parse_request_framed_948:
    ldr x13, [x27, #0]
    cmp x10, x13
    b.ge .Lssa_http__parse_request_framed_945
.Lssa_http__parse_request_framed_947:
    tst x27, #1
    b.ne .Lssa_http__parse_request_framed_uq947
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq947
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq947:
    b.ne .Lssa_http__parse_request_framed_1007
.Lssa_http__parse_request_framed_1006:
    b .Lssa_http__parse_request_framed_1008
.Lssa_http__parse_request_framed_1007:
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3177
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3177
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3177
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    b .Lssa_http__parse_request_framed_rcdece3177
.Lssa_http__parse_request_framed_rcdecd3177:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3177:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3177:
    mov x13, #0
    ldr x11, [x27, #0]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    str x11, [sp, #-16]!
    str x13, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    mov x27, x0
.Lssa_http__parse_request_framed_1008:
    ldr x7, [x27]
    cmp x10, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, x10
    strb w14, [x5, #8]
    b .Lssa_http__parse_request_framed_944
.Lssa_http__parse_request_framed_945:
    tst x27, #1
    b.ne .Lssa_http__parse_request_framed_uq945
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq945
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq945:
    b.ne .Lssa_http__parse_request_framed_1011
.Lssa_http__parse_request_framed_1010:
    mov x0, x27
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3184s
.Lssa_http__parse_request_framed_apush3184o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3184e
.Lssa_http__parse_request_framed_apush3184s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    bl __fern_arr_push_owned_u8
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
.Lssa_http__parse_request_framed_apush3184e:
    mov x11, x0
    b .Lssa_http__parse_request_framed_1012
.Lssa_http__parse_request_framed_1011:
    mov x0, x27
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3185s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3185o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3185s
.Lssa_http__parse_request_framed_apush3185o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3185e
.Lssa_http__parse_request_framed_apush3185s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    bl __fern_arr_push_u8
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
.Lssa_http__parse_request_framed_apush3185e:
    mov x11, x0
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3186
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3186
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3186
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    b .Lssa_http__parse_request_framed_rcdece3186
.Lssa_http__parse_request_framed_rcdecd3186:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3186:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3186:
.Lssa_http__parse_request_framed_1012:
    mov x27, x11
.Lssa_http__parse_request_framed_944:
    add x11, x10, #1
    sxtw x10, w11
.Lssa_http__parse_request_framed_943:
    mov x11, #3
    mov x14, #1
    cmp x9, #37
    csel x11, x11, x14, eq
.Lssa_http__parse_request_framed_939:
    add x11, x12, x11
    sxtw x12, w11
    cmp x12, x23
    b.lt .Lssa_http__parse_request_framed_965
.Lssa_http__parse_request_framed_915:
    cmp x12, x23
    cset x11, eq
    add x9, x20, #1
    sxtw x9, w9
.Lssa_http__parse_request_framed_914:
    sub x14, x10, x9
    sxtw x14, w14
    cmp x14, #1
    b.lt .Lssa_http__parse_request_framed_910
.Lssa_http__parse_request_framed_913:
    cmp x14, #2
    b.gt .Lssa_http__parse_request_framed_910
.Lssa_http__parse_request_framed_912:
    ldr x6, [x27]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, x9
    ldrb w13, [x5, #8]
    cmp x13, #46
    b.ne .Lssa_http__parse_request_framed_910
.Lssa_http__parse_request_framed_911:
    sub w13, w10, #1
    ldr x6, [x27]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, x13
    ldrb w9, [x5, #8]
    cmp x9, #46
    b.eq .Lssa_http__parse_request_framed_908
.Lssa_http__parse_request_framed_910:
    mov x14, #0
.Lssa_http__parse_request_framed_909:
.Lssa_http__parse_request_framed_908:
    cmp x14, #0
    b.ne .Lssa_http__parse_request_framed_905
.Lssa_http__parse_request_framed_907:
    mov x20, x10
    mov x28, #0
    b .Lssa_http__parse_request_framed_891
.Lssa_http__parse_request_framed_905:
    cmp x14, #1
    b.ne .Lssa_http__parse_request_framed_902
.Lssa_http__parse_request_framed_904:
    b .Lssa_http__parse_request_framed_893
.Lssa_http__parse_request_framed_902:
    cmp x20, #0
    b.ne .Lssa_http__parse_request_framed_899
.Lssa_http__parse_request_framed_901:
    mov x14, #-1
    mov x20, x14
    b .Lssa_http__parse_request_framed_893
.Lssa_http__parse_request_framed_899:
    sub x14, x20, #1
    sxtw x14, w14
.Lssa_http__parse_request_framed_898:
.Lssa_http__parse_request_framed_1052:
    ldr x6, [x27]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, x14
    ldrb w9, [x5, #8]
    cmp x9, #47
    b.eq .Lssa_http__parse_request_framed_897
.Lssa_http__parse_request_framed_1053:
    sub x9, x14, #1
    sxtw x14, w9
    b .Lssa_http__parse_request_framed_1052
.Lssa_http__parse_request_framed_897:
    cbz x22, .Lssa_http__parse_request_framed_895
.Lssa_http__parse_request_framed_896:
    str x11, [sp, #56]
    str x12, [sp, #48]
    str x14, [sp, #40]
    str x20, [sp, #-16]!
    str x14, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x9, x0
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    ldr x14, [sp, #40]
.Lssa_http__parse_request_framed_1064:
    str x9, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x9
    bl __fn_utf8__is_valid.r
    mov x10, x0
    ldr x9, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    tbnz x9, #0, .Lssa_http__parse_request_framed_rcdeck3244
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3244
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3244
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3244
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x9
    bl __fn___fern_str_free.u
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    b .Lssa_http__parse_request_framed_rcdece3244
.Lssa_http__parse_request_framed_rcdecd3244:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_framed_rcdeck3244:
    mov x0, x9
.Lssa_http__parse_request_framed_rcdece3244:
    cbz x10, .Lssa_http__parse_request_framed_894
.Lssa_http__parse_request_framed_895:
    mov x20, x14
    b .Lssa_http__parse_request_framed_893
.Lssa_http__parse_request_framed_894:
    mov x10, #-1
    mov x20, x10
.Lssa_http__parse_request_framed_893:
    cmp x20, #0
    b.ge .Lssa_http__parse_request_framed_892
.Lssa_http__parse_request_framed_1071:
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3262
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3262
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3262
    str x11, [sp, #56]
    str x12, [sp, #48]
    mov x0, x27
    bl __fn___fern_arr_dec.u
    ldr x11, [sp, #56]
    ldr x12, [sp, #48]
    b .Lssa_http__parse_request_framed_rcdece3262
.Lssa_http__parse_request_framed_rcdecd3262:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3262:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3262:
    b .Lssa_http__parse_request_framed_240
.Lssa_http__parse_request_framed_892:
    mov x28, x11
.Lssa_http__parse_request_framed_891:
    add x12, x12, #1
    sxtw x9, w12
    cmp x9, x23
    b.le .Lssa_http__parse_request_framed_922
.Lssa_http__parse_request_framed_246:
    cmp x20, #0
    b.eq .Lssa_http__parse_request_framed_244
.Lssa_http__parse_request_framed_245:
    cbz x28, .Lssa_http__parse_request_framed_239
.Lssa_http__parse_request_framed_244:
    mov x28, #47
.Lssa_http__parse_request_framed_243:
    ldr x9, [x27, #0]
    cmp x20, x9
    b.ge .Lssa_http__parse_request_framed_237
.Lssa_http__parse_request_framed_242:
    tst x27, #1
    b.ne .Lssa_http__parse_request_framed_uq242
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq242
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq242:
    b.ne .Lssa_http__parse_request_framed_1090
.Lssa_http__parse_request_framed_1089:
    b .Lssa_http__parse_request_framed_1091
.Lssa_http__parse_request_framed_1090:
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3282
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3282
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3282
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece3282
.Lssa_http__parse_request_framed_rcdecd3282:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3282:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3282:
    mov x9, #0
    ldr x12, [x27, #0]
    str x12, [sp, #-16]!
    str x9, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    mov x27, x0
.Lssa_http__parse_request_framed_1091:
    mov x12, #47
    ldr x7, [x27]
    cmp x20, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, x20
    strb w12, [x5, #8]
    mov x21, x27
    b .Lssa_http__parse_request_framed_236
.Lssa_http__parse_request_framed_241:
    mov x23, #0
    mov x12, #400
    mov x9, #0
    b .Lssa_http__parse_request_framed_228
.Lssa_http__parse_request_framed_240:
    mov x23, #0
    mov x12, #400
    mov x9, #0
    b .Lssa_http__parse_request_framed_228
.Lssa_http__parse_request_framed_239:
    mov x21, x27
    b .Lssa_http__parse_request_framed_1099
.Lssa_http__parse_request_framed_237:
    tst x27, #1
    b.ne .Lssa_http__parse_request_framed_uq237
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq237
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq237:
    b.ne .Lssa_http__parse_request_framed_1097
.Lssa_http__parse_request_framed_1096:
    mov x0, x27
    mov x1, x28
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3292s
.Lssa_http__parse_request_framed_apush3292o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3292e
.Lssa_http__parse_request_framed_apush3292s:
    bl __fern_arr_push_owned_u8
.Lssa_http__parse_request_framed_apush3292e:
    mov x21, x0
    b .Lssa_http__parse_request_framed_236
.Lssa_http__parse_request_framed_1097:
    mov x0, x27
    mov x1, x28
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3293s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3293o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3293s
.Lssa_http__parse_request_framed_apush3293o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3293e
.Lssa_http__parse_request_framed_apush3293s:
    bl __fern_arr_push_u8
.Lssa_http__parse_request_framed_apush3293e:
    mov x21, x0
    cmp x27, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3294
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3294
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3294
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece3294
.Lssa_http__parse_request_framed_rcdecd3294:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_http__parse_request_framed_rcdeck3294:
    mov x0, x27
.Lssa_http__parse_request_framed_rcdece3294:
.Lssa_http__parse_request_framed_1098:
.Lssa_http__parse_request_framed_236:
    add x20, x20, #1
    sxtw x20, w20
.Lssa_http__parse_request_framed_235:
.Lssa_http__parse_request_framed_234:
.Lssa_http__parse_request_framed_1099:
    cmp x23, x26
    b.ge .Lssa_http__parse_request_framed_233
.Lssa_http__parse_request_framed_1105:
    ldr x6, [x19]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x23
    ldrb w27, [x5, #8]
.Lssa_http__parse_request_framed_1104:
    ldr x9, [x21, #0]
    cmp x20, x9
    b.ge .Lssa_http__parse_request_framed_1101
.Lssa_http__parse_request_framed_1103:
    tst x21, #1
    b.ne .Lssa_http__parse_request_framed_uq1103
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1103
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1103:
    b.ne .Lssa_http__parse_request_framed_1115
.Lssa_http__parse_request_framed_1114:
    b .Lssa_http__parse_request_framed_1116
.Lssa_http__parse_request_framed_1115:
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3320
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3320
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3320
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece3320
.Lssa_http__parse_request_framed_rcdecd3320:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_framed_rcdeck3320:
    mov x0, x21
.Lssa_http__parse_request_framed_rcdece3320:
    mov x9, #0
    ldr x12, [x21, #0]
    str x12, [sp, #-16]!
    str x9, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    mov x21, x0
.Lssa_http__parse_request_framed_1116:
    ldr x7, [x21]
    cmp x20, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, x20
    strb w27, [x5, #8]
    b .Lssa_http__parse_request_framed_1100
.Lssa_http__parse_request_framed_1101:
    tst x21, #1
    b.ne .Lssa_http__parse_request_framed_uq1101
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1101
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1101:
    b.ne .Lssa_http__parse_request_framed_1119
.Lssa_http__parse_request_framed_1118:
    mov x0, x21
    mov x1, x27
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3327s
.Lssa_http__parse_request_framed_apush3327o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3327e
.Lssa_http__parse_request_framed_apush3327s:
    bl __fern_arr_push_owned_u8
.Lssa_http__parse_request_framed_apush3327e:
    b .Lssa_http__parse_request_framed_pool_887
    .ltorg
.Lssa_http__parse_request_framed_pool_887:
    mov x28, x0
    b .Lssa_http__parse_request_framed_1120
.Lssa_http__parse_request_framed_1119:
    mov x0, x21
    mov x1, x27
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3328s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3328o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3328s
.Lssa_http__parse_request_framed_apush3328o:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3328e
.Lssa_http__parse_request_framed_apush3328s:
    bl __fern_arr_push_u8
.Lssa_http__parse_request_framed_apush3328e:
    mov x28, x0
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3329
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3329
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3329
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece3329
.Lssa_http__parse_request_framed_rcdecd3329:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_framed_rcdeck3329:
    mov x0, x21
.Lssa_http__parse_request_framed_rcdece3329:
.Lssa_http__parse_request_framed_1120:
    mov x21, x28
.Lssa_http__parse_request_framed_1100:
    add x12, x20, #1
    sxtw x20, w12
    add x23, x23, #1
    cmp x23, x26
    b.lt .Lssa_http__parse_request_framed_1105
.Lssa_http__parse_request_framed_233:
    mov x12, #0
    str x20, [sp, #-16]!
    str x12, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x23, x0
.Lssa_http__parse_request_framed_1123:
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3341
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3341
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3341
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece3341
.Lssa_http__parse_request_framed_rcdecd3341:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_framed_rcdeck3341:
    mov x0, x21
.Lssa_http__parse_request_framed_rcdece3341:
    cbz x22, .Lssa_http__parse_request_framed_231
.Lssa_http__parse_request_framed_232:
    mov x0, x23
    bl __fn_utf8__is_valid.r
    cbnz x0, .Lssa_http__parse_request_framed_231
.Lssa_http__parse_request_framed_1130:
    tbnz x23, #0, .Lssa_http__parse_request_framed_rcdeck3343
    cmp x23, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3343
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3343
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3343
    mov x0, x23
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3343
.Lssa_http__parse_request_framed_rcdecd3343:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_http__parse_request_framed_rcdeck3343:
    mov x0, x23
.Lssa_http__parse_request_framed_rcdece3343:
    b .Lssa_http__parse_request_framed_230
.Lssa_http__parse_request_framed_231:
    mov x12, #0
    mov x9, #1
    b .Lssa_http__parse_request_framed_228
.Lssa_http__parse_request_framed_230:
    mov x23, #0
    mov x12, #400
    mov x9, #0
.Lssa_http__parse_request_framed_229:
.Lssa_http__parse_request_framed_228:
    mov x21, x12
.Lssa_http__parse_request_framed_227:
    cbnz x9, .Lssa_http__parse_request_framed_226
.Lssa_http__parse_request_framed_1135:
    tbnz x23, #0, .Lssa_http__parse_request_framed_rcdeck3362
    cmp x23, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3362
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3362
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3362
    mov x0, x23
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3362
.Lssa_http__parse_request_framed_rcdecd3362:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_http__parse_request_framed_rcdeck3362:
    mov x0, x23
.Lssa_http__parse_request_framed_rcdece3362:
    b .Lssa_http__parse_request_framed_224
.Lssa_http__parse_request_framed_226:
    mov x22, x23
    ldr x23, [sp, #96]
    mov x21, #0
    b .Lssa_http__parse_request_framed_223
.Lssa_http__parse_request_framed_224:
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    mov x10, #-1
    mov x12, #-1
    mov x23, x10
    mov x26, x12
    mov x22, x9
.Lssa_http__parse_request_framed_223:
    cmp x21, #0
    b.eq .Lssa_http__parse_request_framed_221
.Lssa_http__parse_request_framed_1139:
    tbnz x22, #0, .Lssa_http__parse_request_framed_rcdeck3376
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3376
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3376
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3376
    mov x0, x22
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3376
.Lssa_http__parse_request_framed_rcdecd3376:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_framed_rcdeck3376:
    mov x0, x22
.Lssa_http__parse_request_framed_rcdece3376:
.Lssa_http__parse_request_framed_222:
    mov x11, x21
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_221:
    str x23, [sp, #112]
    str x22, [sp, #96]
.Lssa_http__parse_request_framed_220:
    ldr x4, [sp, #80]
    cmp x4, #0
    b.ge .Lssa_http__parse_request_framed_219
.Lssa_http__parse_request_framed_1144:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3386
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3386
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3386
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3386
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3386
.Lssa_http__parse_request_framed_rcdecd3386:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3386:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3386:
    b .Lssa_http__parse_request_framed_218
.Lssa_http__parse_request_framed_219:
    cmp x25, #0
    b.ge .Lssa_http__parse_request_framed_216
.Lssa_http__parse_request_framed_1148:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3389
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3389
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3389
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3389
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3389
.Lssa_http__parse_request_framed_rcdecd3389:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3389:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3389:
.Lssa_http__parse_request_framed_218:
    mov x11, #1
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_216:
    add x12, x25, #4
    ldr x5, [sp, #104]
    sub x4, x12, x5
    str x4, [sp, #88]
    ldr x4, [sp, #80]
    add x12, x4, #2
    sxtw x12, w12
    cmp x12, x25
    csel x9, x25, x12, gt
.Lssa_http__parse_request_framed_213:
.Lssa_http__parse_request_framed_212:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http__parse_request_framed_211:
    mov x20, x0
    mov x23, x9
    mov x28, #1
    mov x27, #0
.Lssa_http__parse_request_framed_1158:
    cmp x23, x25
    b.ge .Lssa_http__parse_request_framed_210
.Lssa_http__parse_request_framed_1213:
    adrp x9, .K5
    add x9, x9, :lo12:.K5
    mov x2, x9
    mov x1, x23
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L54
    mov x1, #0
.L54:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L57
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L55:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L56
    add x5, x5, #16
    cmp x5, x8
    b.ls .L55
    sub x1, x5, x0
    b .L57
.L56:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L58
.L57:
    add x10, x9, #96
.L61:
    cmp x1, x3
    b.ge .L59
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L58
    add x1, x1, #1
    b .L61
.L58:
    str x1, [sp, #-16]!
    b .L60
.L59:
    str x3, [sp, #-16]!
.L60:
    ldr x0, [sp], #16
    cmp x0, x25
    csel x10, x25, x0, gt
.Lssa_http__parse_request_framed_1219:
    cmp x10, x23
    b.eq .Lssa_http__parse_request_framed_1210
.Lssa_http__parse_request_framed_1212:
    cmp x10, x25
    b.ge .Lssa_http__parse_request_framed_1210
.Lssa_http__parse_request_framed_1211:
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
    cmp x9, #58
    b.eq .Lssa_http__parse_request_framed_1208
.Lssa_http__parse_request_framed_1210:
    mov x9, #-1
    mov x10, x25
    b .Lssa_http__parse_request_framed_1196
.Lssa_http__parse_request_framed_1208:
    add x9, x10, #1
.Lssa_http__parse_request_framed_1207:
    mov x12, #13
    str x10, [sp, #56]
    mov x2, x9
    mov x1, x12
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L62
    mov x2, #0
.L62:
    cmp x1, #255
    b.hi .L67
    cmp x2, x3
    b.ge .L67
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L64
.L63:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L69
    cmp x5, x8
    b.ls .L63
.L64:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L65
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L65
    sub x5, x5, #16
    b .L70
.L69:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L70
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L70:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L68
.L65:
    cmp x5, x6
    b.ge .L67
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L66
    add x5, x5, #1
    b .L65
.L66:
    sub x2, x5, x0
    b .L68
.L67:
    mov x2, #-1
.L68:
    mov x0, x2
    ldr x10, [sp, #56]
    cmp x0, #0
    b.lt .Lssa_http__parse_request_framed_1205
.Lssa_http__parse_request_framed_1206:
    cmp x0, x25
    b.lt .Lssa_http__parse_request_framed_1203
.Lssa_http__parse_request_framed_1205:
    mov x0, x25
    b .Lssa_http__parse_request_framed_1199
.Lssa_http__parse_request_framed_1203:
    add x12, x0, #1
    cmp x12, x25
    b.ge .Lssa_http__parse_request_framed_1201
.Lssa_http__parse_request_framed_1202:
    add x12, x0, #1
    ldr x6, [x19]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x12
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_framed_1199
.Lssa_http__parse_request_framed_1201:
    mov x9, #-1
    mov x0, x9
.Lssa_http__parse_request_framed_1200:
.Lssa_http__parse_request_framed_1199:
    cmp x0, #0
    b.ge .Lssa_http__parse_request_framed_1197
.Lssa_http__parse_request_framed_1198:
    mov x9, #-1
    mov x10, x25
    b .Lssa_http__parse_request_framed_1196
.Lssa_http__parse_request_framed_1197:
    mov x9, x10
    mov x10, x0
.Lssa_http__parse_request_framed_1196:
    cmp x9, #0
    b.ge .Lssa_http__parse_request_framed_1194
.Lssa_http__parse_request_framed_1265:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3527
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3527
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3527
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3527
    str x9, [sp, #56]
    str x10, [sp, #48]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_framed_rcdece3527
.Lssa_http__parse_request_framed_rcdecd3527:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3527:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3527:
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_framed_207
.Lssa_http__parse_request_framed_1194:
    add x12, x27, #1
    sxtw x27, w12
    cmp x27, #100
    b.le .Lssa_http__parse_request_framed_1192
.Lssa_http__parse_request_framed_1269:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3533
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3533
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3533
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3533
    str x9, [sp, #56]
    str x10, [sp, #48]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_framed_rcdece3533
.Lssa_http__parse_request_framed_rcdecd3533:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3533:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3533:
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_framed_206
.Lssa_http__parse_request_framed_1192:
    sub x12, x27, #1
    sxtw x11, w12
    cbz x28, .Lssa_http__parse_request_framed_1185
.Lssa_http__parse_request_framed_1191:
    ldr x12, [x24, #8]
    ldr x14, [x12, #0]
    cmp x11, x14
    b.lt .Lssa_http__parse_request_framed_1185
.Lssa_http__parse_request_framed_1190:
    cmp x11, #0
    b.le .Lssa_http__parse_request_framed_1187
.Lssa_http__parse_request_framed_1281:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
.Lssa_http__parse_request_framed_1189:
    tbnz x24, #0, .Lssa_http__parse_request_framed_rcinc3544
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc3544
    ldur w5, [x24, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc3544
    add w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_framed_rcinc3544:
    mov x0, x24
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    mov x0, x24
    mov x9, x11
    bl __fn_http____leading_fields.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    mov x20, x0
.Lssa_http__parse_request_framed_1188:
.Lssa_http__parse_request_framed_1187:
    mov x28, #0
.Lssa_http__parse_request_framed_1186:
.Lssa_http__parse_request_framed_1185:
    mov x14, #-1
    cmp x28, #0
    csel x14, x11, x14, ne
.Lssa_http__parse_request_framed_1182:
    add x12, x9, #1
    sxtw x12, w12
.Lssa_http__parse_request_framed_1181:
.Lssa_http__parse_request_framed_1292:
    cmp x12, x10
    b.ge .Lssa_http__parse_request_framed_1179
.Lssa_http__parse_request_framed_1299:
    ldr x6, [x19]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x12
    ldrb w13, [x5, #8]
.Lssa_http__parse_request_framed_1298:
    cmp x13, #32
    b.eq .Lssa_http__parse_request_framed_1293
.Lssa_http__parse_request_framed_1296:
    cmp x13, #9
    b.ne .Lssa_http__parse_request_framed_1179
.Lssa_http__parse_request_framed_1293:
    add x12, x12, #1
    cmp x12, x10
    b.lt .Lssa_http__parse_request_framed_1299
.Lssa_http__parse_request_framed_1179:
    mov x13, x10
.Lssa_http__parse_request_framed_1315:
    cmp x13, x12
    b.le .Lssa_http__parse_request_framed_1178
.Lssa_http__parse_request_framed_1322:
    sub x15, x13, #1
    ldr x6, [x19]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x15
    ldrb w1, [x5, #8]
.Lssa_http__parse_request_framed_1321:
    cmp x1, #32
    b.eq .Lssa_http__parse_request_framed_1316
.Lssa_http__parse_request_framed_1319:
    cmp x1, #9
    b.ne .Lssa_http__parse_request_framed_1178
.Lssa_http__parse_request_framed_1316:
    sub x13, x13, #1
    cmp x13, x12
    b.gt .Lssa_http__parse_request_framed_1322
.Lssa_http__parse_request_framed_1178:
    cmp x14, #0
    b.lt .Lssa_http__parse_request_framed_1173
.Lssa_http__parse_request_framed_1177:
    ldr x1, [x24, #16]
    ldr x6, [x1]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x15, [x1, x5, lsl #3]
    ldr x1, [x15, #8]
    sub x15, x13, x12
    sxtw x15, w15
    cmp x1, x15
    b.ne .Lssa_http__parse_request_framed_1173
.Lssa_http__parse_request_framed_1176:
    ldr x15, [x24, #16]
    ldr x6, [x15]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x8, [x15, x5, lsl #3]
    ldr x1, [x8, #8]
    mov x2, #0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    mov x4, x1
    mov x3, x2
    mov x2, x8
    mov x1, x12
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L71_aop
    mov x1, #0
.L71_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L71_bop
    mov x3, #0
.L71_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L71_nok
    mov x4, #0
.L71_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L71_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L71_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L71_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L71_vec
.L71_short:
    cmp x10, #8
    b.lt .L71_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L71_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L71_eq
    add x8, x8, x14
.L71_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_w4:
    cmp x10, #4
    b.lt .L71_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L71_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L71_eq
    add x8, x8, x14
.L71_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_w2:
    cmp x10, #2
    b.lt .L71_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L71_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L71_eq
    add x8, x8, x14
.L71_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L71_done
.L71_tail:
    cmp x8, x13
    b.ge .L71_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L71_th
    add x8, x8, #1
    add x9, x9, #1
    b .L71_tail
.L71_th:
    sub x2, x8, x12
    b .L71_done
.L71_eq:
    mov x2, x4
.L71_done:
    mov x0, x2
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
    ldr x2, [x8, #8]
    cmp x0, x2
    b.ne .Lssa_http__parse_request_framed_1173
.Lssa_http__parse_request_framed_1175:
    ldr x6, [x15]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x2, [x15, x5, lsl #3]
    tbnz x2, #0, .Lssa_http__parse_request_framed_rcinc3611
    cmp x2, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc3611
    ldur w5, [x2, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc3611
    add w5, w5, #1
    stur w5, [x2, #-8]
.Lssa_http__parse_request_framed_rcinc3611:
    mov x0, x2
    mov x15, x2
    b .Lssa_http__parse_request_framed_1169
.Lssa_http__parse_request_framed_1173:
    adrp x2, .K8
    add x2, x2, :lo12:.K8
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    mov x1, x12
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L72
    mov x1, #0
.L72:
    adrp x9, .S9
    add x9, x9, :lo12:.S9
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L75
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L73:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L74
    add x5, x5, #16
    cmp x5, x8
    b.ls .L73
    sub x1, x5, x0
    b .L75
.L74:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L76
.L75:
    add x10, x9, #96
.L79:
    cmp x1, x3
    b.ge .L77
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L76
    add x1, x1, #1
    b .L79
.L76:
    str x1, [sp, #-16]!
    b .L78
.L77:
    str x3, [sp, #-16]!
.L78:
    ldr x0, [sp], #16
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    cmp x0, x13
    b.ge .Lssa_http__parse_request_framed_1171
.Lssa_http__parse_request_framed_1351:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3622
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3622
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3622
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3622
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    b .Lssa_http__parse_request_framed_rcdece3622
.Lssa_http__parse_request_framed_rcdecd3622:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3622:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3622:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    b .Lssa_http__parse_request_framed_54
.Lssa_http__parse_request_framed_1171:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x13, [sp, #-16]!
    str x12, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x15, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
.Lssa_http__parse_request_framed_1355:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x15, [sp, #32]
    mov x0, x15
    bl __fn_utf8__is_valid.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x15, [sp, #32]
    cbnz x0, .Lssa_http__parse_request_framed_1169
.Lssa_http__parse_request_framed_1358:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3626
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3626
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3626
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3626
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x15, [sp, #32]
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x15, [sp, #32]
    b .Lssa_http__parse_request_framed_rcdece3626
.Lssa_http__parse_request_framed_rcdecd3626:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3626:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3626:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x15, [sp, #32]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x15, [sp, #32]
    tbnz x15, #0, .Lssa_http__parse_request_framed_rcdeck3628
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3628
    ldur w5, [x15, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3628
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3628
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x15, [sp, #32]
    mov x0, x15
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x15, [sp, #32]
    b .Lssa_http__parse_request_framed_rcdece3628
.Lssa_http__parse_request_framed_rcdecd3628:
    sub w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_framed_rcdeck3628:
    mov x0, x15
.Lssa_http__parse_request_framed_rcdece3628:
    b .Lssa_http__parse_request_framed_54
.Lssa_http__parse_request_framed_1170:
.Lssa_http__parse_request_framed_1169:
    cbz x28, .Lssa_http__parse_request_framed_1161
.Lssa_http__parse_request_framed_1168:
    ldr x13, [x24, #8]
    ldr x6, [x13]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x12, [x13, x5, lsl #3]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x15, [sp, #24]
    mov x0, x19
    mov x10, x9
    mov x11, x12
    mov x9, x23
    bl __fn_http____shared_string.r
    mov x13, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x15, [sp, #24]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    ldr x6, [x13, #8]
    ldr x7, [x12, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn3647
    mov x0, x13
    mov x9, x12
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd3647
.Lssa_http__parse_request_framed_streqn3647:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd3647:
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    cbz x0, .Lssa_http__parse_request_framed_1166
.Lssa_http__parse_request_framed_1167:
    ldr x12, [x24, #16]
    ldr x6, [x12]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x2, [x12, x5, lsl #3]
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    ldr x6, [x15, #8]
    ldr x7, [x2, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn3650
    mov x0, x15
    mov x9, x2
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd3650
.Lssa_http__parse_request_framed_streqn3650:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd3650:
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    mov x12, x0
    b .Lssa_http__parse_request_framed_1165
.Lssa_http__parse_request_framed_1166:
    mov x12, #0
.Lssa_http__parse_request_framed_1165:
    cbz x12, .Lssa_http__parse_request_framed_1371
.Lssa_http__parse_request_framed_1370:
    tbnz x13, #0, .Lssa_http__parse_request_framed_rcdeck3654
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3654
    ldur w5, [x13, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3654
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3654
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    mov x0, x13
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_framed_rcdece3654
.Lssa_http__parse_request_framed_rcdecd3654:
    sub w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_framed_rcdeck3654:
    mov x0, x13
.Lssa_http__parse_request_framed_rcdece3654:
    tbnz x15, #0, .Lssa_http__parse_request_framed_rcdeck3655
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3655
    ldur w5, [x15, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3655
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3655
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    mov x0, x15
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_framed_rcdece3655
.Lssa_http__parse_request_framed_rcdecd3655:
    sub w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_framed_rcdeck3655:
    mov x0, x15
.Lssa_http__parse_request_framed_rcdece3655:
    b .Lssa_http__parse_request_framed_1162
.Lssa_http__parse_request_framed_1371:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_framed_1163
.Lssa_http__parse_request_framed_1164:
    b .Lssa_http__parse_request_framed_1162
.Lssa_http__parse_request_framed_1163:
    tbnz x24, #0, .Lssa_http__parse_request_framed_rcinc3657
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc3657
    ldur w5, [x24, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc3657
    add w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_framed_rcinc3657:
    mov x0, x24
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    mov x0, x24
    mov x9, x11
    bl __fn_http____leading_fields.r
    mov x14, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    tst x14, #1
    b.ne .Lssa_http__parse_request_framed_uq1163
    cmp x14, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1163
    ldur w5, [x14, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1163:
    b.ne .Lssa_http__parse_request_framed_1376
.Lssa_http__parse_request_framed_1375:
    mov x11, x14
    b .Lssa_http__parse_request_framed_1377
.Lssa_http__parse_request_framed_1376:
    mov x11, #0
.Lssa_http__parse_request_framed_1377:
    ldr x8, [x14, #8]
    cmp x11, #0
    b.ne .Lssa_http__parse_request_framed_1380
.Lssa_http__parse_request_framed_1378:
    tbnz x8, #0, .Lssa_http__parse_request_framed_rcinc3665
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc3665
    ldur w5, [x8, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc3665
    add w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_framed_rcinc3665:
    mov x0, x8
.Lssa_http__parse_request_framed_1380:
    tst x8, #1
    b.ne .Lssa_http__parse_request_framed_uq1380
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1380
    ldur w5, [x8, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1380:
    b.ne .Lssa_http__parse_request_framed_1382
.Lssa_http__parse_request_framed_1381:
    mov x0, x8
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3667s
.Lssa_http__parse_request_framed_apush3667o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3667e
.Lssa_http__parse_request_framed_apush3667s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
.Lssa_http__parse_request_framed_apush3667e:
    mov x21, x0
    b .Lssa_http__parse_request_framed_1383
.Lssa_http__parse_request_framed_1382:
    mov x0, x8
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3668s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3668o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3668s
.Lssa_http__parse_request_framed_apush3668o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3668e
.Lssa_http__parse_request_framed_apush3668s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_framed_apush3668e:
    mov x21, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x0, x8
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3670
    ldur w5, [x8, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3670
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3670
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    mov x0, x8
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    b .Lssa_http__parse_request_framed_rcdece3670
.Lssa_http__parse_request_framed_rcdecd3670:
    sub w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_framed_rcdeck3670:
    mov x0, x8
.Lssa_http__parse_request_framed_rcdece3670:
.Lssa_http__parse_request_framed_1383:
    ldr x8, [x14, #16]
    cmp x11, #0
    b.ne .Lssa_http__parse_request_framed_1386
.Lssa_http__parse_request_framed_1384:
    tbnz x8, #0, .Lssa_http__parse_request_framed_rcinc3675
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc3675
    ldur w5, [x8, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc3675
    add w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_framed_rcinc3675:
    mov x0, x8
.Lssa_http__parse_request_framed_1386:
    tst x8, #1
    b.ne .Lssa_http__parse_request_framed_uq1386
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1386
    ldur w5, [x8, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1386:
    b.ne .Lssa_http__parse_request_framed_1388
.Lssa_http__parse_request_framed_1387:
    mov x0, x8
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3677s
.Lssa_http__parse_request_framed_apush3677o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3677e
.Lssa_http__parse_request_framed_apush3677s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_framed_apush3677e:
    mov x13, x0
    b .Lssa_http__parse_request_framed_1389
.Lssa_http__parse_request_framed_1388:
    mov x0, x8
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3678s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3678o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3678s
.Lssa_http__parse_request_framed_apush3678o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3678e
.Lssa_http__parse_request_framed_apush3678s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_framed_apush3678e:
    mov x13, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    mov x0, x8
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
    cmp x8, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3680
    ldur w5, [x8, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3680
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3680
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    mov x0, x8
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    b .Lssa_http__parse_request_framed_rcdece3680
.Lssa_http__parse_request_framed_rcdecd3680:
    sub w5, w5, #1
    stur w5, [x8, #-8]
.Lssa_http__parse_request_framed_rcdeck3680:
    mov x0, x8
.Lssa_http__parse_request_framed_rcdece3680:
.Lssa_http__parse_request_framed_1389:
    cmp x11, #0
    b.ne .Lssa_http__parse_request_framed_1391
.Lssa_http__parse_request_framed_1390:
    mov x8, #3
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x11, [sp, #-16]!
    str x8, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    adrp x8, .S0
    add x8, x8, :lo12:.S0
    str x8, [x0, #0]
    mov x8, x0
    b .Lssa_http__parse_request_framed_1392
.Lssa_http__parse_request_framed_1391:
    mov x8, x11
.Lssa_http__parse_request_framed_1392:
    cmp x11, #0
    b.ne .Lssa_http__parse_request_framed_1395
.Lssa_http__parse_request_framed_1394:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x14
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
.Lssa_http__parse_request_framed_1395:
    str x21, [x8, #8]
    str x13, [x8, #16]
    mov x20, x8
.Lssa_http__parse_request_framed_1162:
    mov x28, x12
    b .Lssa_http__parse_request_framed_1159
.Lssa_http__parse_request_framed_1161:
    str x10, [sp, #56]
    str x15, [sp, #48]
    str x9, [sp, #-16]!
    str x23, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x12, x0
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_http__parse_request_framed_1397:
    tst x20, #1
    b.ne .Lssa_http__parse_request_framed_uq1397
    cmp x20, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1397
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1397:
    b.ne .Lssa_http__parse_request_framed_1400
.Lssa_http__parse_request_framed_1399:
    mov x23, x20
    b .Lssa_http__parse_request_framed_1401
.Lssa_http__parse_request_framed_1400:
    mov x23, #0
.Lssa_http__parse_request_framed_1401:
    ldr x21, [x20, #8]
    cmp x23, #0
    b.ne .Lssa_http__parse_request_framed_1404
.Lssa_http__parse_request_framed_1402:
    tbnz x21, #0, .Lssa_http__parse_request_framed_rcinc3711
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc3711
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc3711
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_framed_rcinc3711:
    mov x0, x21
.Lssa_http__parse_request_framed_1404:
    tst x21, #1
    b.ne .Lssa_http__parse_request_framed_uq1404
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1404
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1404:
    b.ne .Lssa_http__parse_request_framed_1406
.Lssa_http__parse_request_framed_1405:
    mov x0, x21
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3713s
.Lssa_http__parse_request_framed_apush3713o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3713e
.Lssa_http__parse_request_framed_apush3713s:
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x15, [sp, #40]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_framed_apush3713e:
    mov x21, x0
    b .Lssa_http__parse_request_framed_1407
.Lssa_http__parse_request_framed_1406:
    mov x0, x21
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3714s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3714o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3714s
.Lssa_http__parse_request_framed_apush3714o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3714e
.Lssa_http__parse_request_framed_apush3714s:
    str x10, [sp, #56]
    str x15, [sp, #48]
    bl __fern_arr_push
    ldr x10, [sp, #56]
    ldr x15, [sp, #48]
.Lssa_http__parse_request_framed_apush3714e:
    mov x9, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x15, [sp, #40]
    mov x0, x21
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x15, [sp, #40]
    cmp x21, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3716
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3716
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3716
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x15, [sp, #40]
    mov x0, x21
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x15, [sp, #40]
    b .Lssa_http__parse_request_framed_rcdece3716
.Lssa_http__parse_request_framed_rcdecd3716:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_http__parse_request_framed_rcdeck3716:
    mov x0, x21
.Lssa_http__parse_request_framed_rcdece3716:
    mov x21, x9
.Lssa_http__parse_request_framed_1407:
    ldr x9, [x20, #16]
    cmp x23, #0
    b.ne .Lssa_http__parse_request_framed_1410
.Lssa_http__parse_request_framed_1408:
    tbnz x9, #0, .Lssa_http__parse_request_framed_rcinc3721
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc3721
    ldur w5, [x9, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc3721
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_framed_rcinc3721:
    mov x0, x9
.Lssa_http__parse_request_framed_1410:
    tst x9, #1
    b.ne .Lssa_http__parse_request_framed_uq1410
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1410
    ldur w5, [x9, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1410:
    b.ne .Lssa_http__parse_request_framed_1412
.Lssa_http__parse_request_framed_1411:
    mov x0, x9
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3723s
.Lssa_http__parse_request_framed_apush3723o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3723e
.Lssa_http__parse_request_framed_apush3723s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x15, [sp, #40]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_framed_apush3723e:
    mov x12, x0
    b .Lssa_http__parse_request_framed_1413
.Lssa_http__parse_request_framed_1412:
    mov x0, x9
    mov x1, x15
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush3724s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush3724o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush3724s
.Lssa_http__parse_request_framed_apush3724o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush3724e
.Lssa_http__parse_request_framed_apush3724s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
.Lssa_http__parse_request_framed_apush3724e:
    mov x12, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    mov x0, x9
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3726
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3726
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3726
    str x10, [sp, #56]
    str x12, [sp, #48]
    mov x0, x9
    bl __fn___fern_arr_dec.u
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    b .Lssa_http__parse_request_framed_rcdece3726
.Lssa_http__parse_request_framed_rcdecd3726:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_framed_rcdeck3726:
    mov x0, x9
.Lssa_http__parse_request_framed_rcdece3726:
.Lssa_http__parse_request_framed_1413:
    cmp x23, #0
    b.ne .Lssa_http__parse_request_framed_1415
.Lssa_http__parse_request_framed_1414:
    mov x9, #3
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x23, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    adrp x9, .S0
    add x9, x9, :lo12:.S0
    str x9, [x0, #0]
    mov x15, x0
    b .Lssa_http__parse_request_framed_1416
.Lssa_http__parse_request_framed_1415:
    mov x15, x23
.Lssa_http__parse_request_framed_1416:
    cmp x23, #0
    b.ne .Lssa_http__parse_request_framed_1419
.Lssa_http__parse_request_framed_1418:
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x15, [sp, #40]
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x15, [sp, #40]
.Lssa_http__parse_request_framed_1419:
    str x21, [x15, #8]
    str x12, [x15, #16]
    mov x20, x15
.Lssa_http__parse_request_framed_1160:
.Lssa_http__parse_request_framed_1159:
    add x10, x10, #2
    sxtw x23, w10
    cmp x23, x25
    b.lt .Lssa_http__parse_request_framed_1213
.Lssa_http__parse_request_framed_210:
    cbz x28, .Lssa_http__parse_request_framed_204
.Lssa_http__parse_request_framed_209:
    ldr x10, [x24, #8]
    ldr x9, [x10, #0]
    cmp x27, x9
    b.ne .Lssa_http__parse_request_framed_204
.Lssa_http__parse_request_framed_1426:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_208:
    mov x20, x24
    b .Lssa_http__parse_request_framed_200
.Lssa_http__parse_request_framed_207:
    mov x11, #400
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_206:
    mov x11, #431
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_204:
    cbz x28, .Lssa_http__parse_request_framed_200
.Lssa_http__parse_request_framed_1433:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_203:
    mov x0, x24
    mov x9, x27
    bl __fn_http____leading_fields.r
    mov x20, x0
.Lssa_http__parse_request_framed_202:
.Lssa_http__parse_request_framed_201:
.Lssa_http__parse_request_framed_200:
    add x26, x26, #1
.Lssa_http__parse_request_framed_199:
    add w26, w26, #7
    ldr x6, [x19]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x26
    ldrb w9, [x5, #8]
    cmp x9, #48
    b.ne .Lssa_http__parse_request_framed_196
.Lssa_http__parse_request_framed_198:
    adrp x9, .SB10
    add x9, x9, :lo12:.SB10
    str x9, [sp, #80]
    b .Lssa_http__parse_request_framed_194
.Lssa_http__parse_request_framed_196:
    adrp x9, .SB11
    add x9, x9, :lo12:.SB11
    str x9, [sp, #80]
.Lssa_http__parse_request_framed_195:
.Lssa_http__parse_request_framed_194:
    mov x9, #-1
    mov x10, #-1
    mov x15, #-1
    mov x12, #-1
    mov x14, #-1
.Lssa_http__parse_request_framed_193:
    mov x27, x9
    mov x24, x10
    mov x28, x15
    mov x23, x12
    mov x25, x14
    mov x21, #0
.Lssa_http__parse_request_framed_1443:
    ldr x14, [x20, #8]
    ldr x12, [x14, #0]
    cmp x21, x12
    b.ge .Lssa_http__parse_request_framed_190
.Lssa_http__parse_request_framed_1493:
    ldr x12, [x20, #8]
    b .Lssa_http__parse_request_framed_pool_1337
    .ltorg
.Lssa_http__parse_request_framed_pool_1337:
    add x5, x21, #1
    ldr x14, [x12, x5, lsl #3]
.Lssa_http__parse_request_framed_1492:
    ldr x12, [x14, #8]
    cmp x12, #4
    b.ne .Lssa_http__parse_request_framed_1489
.Lssa_http__parse_request_framed_1491:
    adrp x9, .SB12
    add x9, x9, :lo12:.SB12
    mov x10, #3
    str x12, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x12, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_framed_1476
.Lssa_http__parse_request_framed_1489:
    cmp x12, #6
    b.ne .Lssa_http__parse_request_framed_1486
.Lssa_http__parse_request_framed_1488:
    adrp x9, .SB13
    add x9, x9, :lo12:.SB13
    mov x10, #4
    str x12, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x12, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_framed_1476
.Lssa_http__parse_request_framed_1486:
    cmp x12, #10
    b.ne .Lssa_http__parse_request_framed_1483
.Lssa_http__parse_request_framed_1485:
    adrp x9, .SB14
    add x9, x9, :lo12:.SB14
    mov x10, #5
    str x12, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x12, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_framed_1476
.Lssa_http__parse_request_framed_1483:
    cmp x12, #14
    b.ne .Lssa_http__parse_request_framed_1480
.Lssa_http__parse_request_framed_1482:
    adrp x9, .SB15
    add x9, x9, :lo12:.SB15
    mov x10, #1
    str x12, [sp, #56]
    str x14, [sp, #48]
    mov x0, x14
    bl __fn_http____kind_if.r
    ldr x12, [sp, #56]
    ldr x14, [sp, #48]
    b .Lssa_http__parse_request_framed_1476
.Lssa_http__parse_request_framed_1480:
    cmp x12, #17
    b.ne .Lssa_http__parse_request_framed_1477
.Lssa_http__parse_request_framed_1479:
    adrp x9, .SB16
    add x9, x9, :lo12:.SB16
    mov x10, #2
    mov x0, x14
    bl __fn_http____kind_if.r
    b .Lssa_http__parse_request_framed_1476
.Lssa_http__parse_request_framed_1477:
    mov x0, #0
.Lssa_http__parse_request_framed_1476:
    cmp x0, #1
    b.ne .Lssa_http__parse_request_framed_1468
.Lssa_http__parse_request_framed_1474:
    mov x10, #-1
    mov x9, #-2
    cmp x27, x10
    csel x9, x21, x9, eq
    b .Lssa_http__parse_request_framed_1469
.Lssa_http__parse_request_framed_1472:
    b .Lssa_http__parse_request_framed_1468
.Lssa_http__parse_request_framed_1469:
    mov x27, x9
.Lssa_http__parse_request_framed_1468:
    cmp x0, #2
    b.ne .Lssa_http__parse_request_framed_1460
.Lssa_http__parse_request_framed_1466:
    mov x9, #-1
    mov x10, #-2
    cmp x24, x9
    csel x10, x21, x10, eq
    b .Lssa_http__parse_request_framed_1461
.Lssa_http__parse_request_framed_1464:
    b .Lssa_http__parse_request_framed_1460
.Lssa_http__parse_request_framed_1461:
    mov x24, x10
.Lssa_http__parse_request_framed_1460:
    cmp x0, #3
    b.ne .Lssa_http__parse_request_framed_1452
.Lssa_http__parse_request_framed_1458:
    mov x10, #-1
    mov x9, #-2
    cmp x28, x10
    csel x9, x21, x9, eq
    b .Lssa_http__parse_request_framed_1453
.Lssa_http__parse_request_framed_1456:
    b .Lssa_http__parse_request_framed_1452
.Lssa_http__parse_request_framed_1453:
    mov x28, x9
.Lssa_http__parse_request_framed_1452:
    cmp x0, #4
    b.ne .Lssa_http__parse_request_framed_1448
.Lssa_http__parse_request_framed_1451:
    cmp x23, #0
    b.ge .Lssa_http__parse_request_framed_1448
.Lssa_http__parse_request_framed_1450:
    mov x23, x21
.Lssa_http__parse_request_framed_1449:
.Lssa_http__parse_request_framed_1448:
    cmp x0, #5
    b.ne .Lssa_http__parse_request_framed_1444
.Lssa_http__parse_request_framed_1447:
    cmp x25, #0
    b.ge .Lssa_http__parse_request_framed_1444
.Lssa_http__parse_request_framed_1446:
    mov x25, x21
.Lssa_http__parse_request_framed_1445:
.Lssa_http__parse_request_framed_1444:
    add x21, x21, #1
    b .Lssa_http__parse_request_framed_1443
.Lssa_http__parse_request_framed_190:
    cmp x23, #0
    b.ge .Lssa_http__parse_request_framed_1578
.Lssa_http__parse_request_framed_189:
    str xzr, [sp, #72]
    b .Lssa_http__parse_request_framed_182
.Lssa_http__parse_request_framed_187:
.Lssa_http__parse_request_framed_1578:
    cmp x23, #0
    b.lt .Lssa_http__parse_request_framed_186
.Lssa_http__parse_request_framed_1581:
    ldr x9, [x20, #16]
    ldr x6, [x9]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    ldr x0, [x9, x5, lsl #3]
    adrp x9, .SB17
    add x9, x9, :lo12:.SB17
    bl __fn_http____token_is.r
    cbz x0, .Lssa_http__parse_request_framed_185
.Lssa_http__parse_request_framed_1579:
    adrp x9, .SB13
    add x9, x9, :lo12:.SB13
    add x23, x23, #1
    sxtw x10, w23
    mov x0, x20
    bl __fn_http____field_at.r
    mov x23, x0
    cmp x23, #0
    b.ge .Lssa_http__parse_request_framed_1581
.Lssa_http__parse_request_framed_186:
    mov x5, #1
    str x5, [sp, #72]
    b .Lssa_http__parse_request_framed_182
.Lssa_http__parse_request_framed_185:
    mov x5, #417
    str x5, [sp, #72]
.Lssa_http__parse_request_framed_184:
.Lssa_http__parse_request_framed_182:
    mov x10, #-1
    cmp x28, x10
    b.ne .Lssa_http__parse_request_framed_179
.Lssa_http__parse_request_framed_181:
    adrp x10, .SB11
    add x10, x10, :lo12:.SB11
    ldr x4, [sp, #80]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_http__parse_request_framed_1598
.Lssa_http__parse_request_framed_1597:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn3925
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_framed_streqn3925
    ldr x0, [sp, #80]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd3925
.Lssa_http__parse_request_framed_streqn3925:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd3925:
    b .Lssa_http__parse_request_framed_1599
.Lssa_http__parse_request_framed_1598:
    mov x0, #0
.Lssa_http__parse_request_framed_1599:
    cbnz x0, .Lssa_http__parse_request_framed_168
    b .Lssa_http__parse_request_framed_170
.Lssa_http__parse_request_framed_179:
    mov x10, #-2
    cmp x28, x10
    b.eq .Lssa_http__parse_request_framed_168
.Lssa_http__parse_request_framed_176:
    ldr x10, [x20, #16]
    ldr x6, [x10]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x9, [x10, x5, lsl #3]
.Lssa_http__parse_request_framed_175:
    ldr x10, [x9, #8]
    ldr x14, [x9, #0]
    mov x9, #0
.Lssa_http__parse_request_framed_1606:
    cmp x9, x10
    b.ge .Lssa_http__parse_request_framed_170
.Lssa_http__parse_request_framed_1610:
    ldrb w12, [x14, x9]
    cmp x12, #33
    b.lt .Lssa_http__parse_request_framed_168
.Lssa_http__parse_request_framed_1609:
    cmp x12, #126
    b.gt .Lssa_http__parse_request_framed_168
.Lssa_http__parse_request_framed_1607:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http__parse_request_framed_1610
.Lssa_http__parse_request_framed_170:
    ldr x4, [sp, #72]
    cmp x4, #417
    b.ne .Lssa_http__parse_request_framed_166
.Lssa_http__parse_request_framed_169:
    mov x28, #417
    b .Lssa_http__parse_request_framed_165
.Lssa_http__parse_request_framed_168:
    mov x28, #400
    b .Lssa_http__parse_request_framed_165
.Lssa_http__parse_request_framed_166:
    mov x28, #0
.Lssa_http__parse_request_framed_165:
    cmp x28, #0
    b.le .Lssa_http__parse_request_framed_161
.Lssa_http__parse_request_framed_1636:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3960
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3960
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3960
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3960
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3960
.Lssa_http__parse_request_framed_rcdecd3960:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3960:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3960:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_164:
    mov x11, x28
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_161:
    mov x9, #-1
    cmp x24, x9
    b.ne .Lssa_http__parse_request_framed_156
.Lssa_http__parse_request_framed_159:
    mov x9, #-1
    cmp x27, x9
    b.ne .Lssa_http__parse_request_framed_142
.Lssa_http__parse_request_framed_158:
    mov x21, #0
    b .Lssa_http__parse_request_framed_133
.Lssa_http__parse_request_framed_156:
    mov x9, #-1
    cmp x27, x9
    b.eq .Lssa_http__parse_request_framed_155
.Lssa_http__parse_request_framed_1650:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3969
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3969
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3969
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3969
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3969
.Lssa_http__parse_request_framed_rcdecd3969:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3969:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3969:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_154
.Lssa_http__parse_request_framed_155:
    mov x9, #-2
    cmp x24, x9
    b.ne .Lssa_http__parse_request_framed_152
.Lssa_http__parse_request_framed_1654:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3973
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3973
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3973
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3973
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3973
.Lssa_http__parse_request_framed_rcdecd3973:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3973:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3973:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_154:
    mov x10, #400
    b .Lssa_http__parse_request_framed_112
.Lssa_http__parse_request_framed_152:
    ldr x9, [x20, #16]
    ldr x6, [x9]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    ldr x14, [x9, x5, lsl #3]
    adrp x9, .SB18
    add x9, x9, :lo12:.SB18
    mov x1, x9
    mov x0, x14
    str x1, [sp, #-16]!
    str x0, [sp, #-16]!
    bl __fn___fern_str_split
    add sp, sp, #32
    mov x24, x0
    ldr x9, [x24, #0]
    sub w9, w9, #1
    ldr x6, [x24]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x0, [x24, x5, lsl #3]
    adrp x9, .SB19
    add x9, x9, :lo12:.SB19
    bl __fn_http____token_is.r
    cbnz x0, .Lssa_http__parse_request_framed_150
.Lssa_http__parse_request_framed_1660:
    tst x24, #1
    b.ne .Lssa_http__parse_request_framed_uq1660
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1660
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1660:
    b.ne .Lssa_http__parse_request_framed_1664
.Lssa_http__parse_request_framed_1662:
    mov x28, #0
.Lssa_http__parse_request_framed_1666:
    ldr x9, [x24, #0]
    cmp x28, x9
    b.ge .Lssa_http__parse_request_framed_1664
.Lssa_http__parse_request_framed_1667:
    add x5, x28, #1
    ldr x9, [x24, x5, lsl #3]
    tbnz x9, #0, .Lssa_http__parse_request_framed_rcdeck3993
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3993
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3993
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3993
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3993
.Lssa_http__parse_request_framed_rcdecd3993:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_framed_rcdeck3993:
    mov x0, x9
.Lssa_http__parse_request_framed_rcdece3993:
    add x28, x28, #1
    b .Lssa_http__parse_request_framed_1666
.Lssa_http__parse_request_framed_1664:
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3997
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3997
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3997
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece3997
.Lssa_http__parse_request_framed_rcdecd3997:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_framed_rcdeck3997:
    mov x0, x24
.Lssa_http__parse_request_framed_rcdece3997:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck3998
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck3998
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd3998
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck3998
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece3998
.Lssa_http__parse_request_framed_rcdecd3998:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck3998:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece3998:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_146
.Lssa_http__parse_request_framed_150:
.Lssa_http__parse_request_framed_149:
    mov x28, #0
.Lssa_http__parse_request_framed_1671:
    add x9, x28, #1
    sxtw x9, w9
    ldr x21, [x24, #0]
    cmp x9, x21
    b.ge .Lssa_http__parse_request_framed_148
.Lssa_http__parse_request_framed_1674:
    ldr x6, [x24]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x0, [x24, x5, lsl #3]
    adrp x9, .SB19
    add x9, x9, :lo12:.SB19
    bl __fn_http____token_is.r
    cbz x0, .Lssa_http__parse_request_framed_1672
.Lssa_http__parse_request_framed_1679:
    tst x24, #1
    b.ne .Lssa_http__parse_request_framed_uq1679
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq1679
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq1679:
    b.ne .Lssa_http__parse_request_framed_1684
.Lssa_http__parse_request_framed_1682:
    mov x23, #0
.Lssa_http__parse_request_framed_1686:
    ldr x9, [x24, #0]
    cmp x23, x9
    b.ge .Lssa_http__parse_request_framed_1684
.Lssa_http__parse_request_framed_1687:
    add x5, x23, #1
    ldr x9, [x24, x5, lsl #3]
    tbnz x9, #0, .Lssa_http__parse_request_framed_rcdeck4021
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4021
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4021
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4021
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4021
.Lssa_http__parse_request_framed_rcdecd4021:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_framed_rcdeck4021:
    mov x0, x9
.Lssa_http__parse_request_framed_rcdece4021:
    add x23, x23, #1
    b .Lssa_http__parse_request_framed_1686
.Lssa_http__parse_request_framed_1684:
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4025
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4025
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4025
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece4025
.Lssa_http__parse_request_framed_rcdecd4025:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_framed_rcdeck4025:
    mov x0, x24
.Lssa_http__parse_request_framed_rcdece4025:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4026
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4026
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4026
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4026
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4026
.Lssa_http__parse_request_framed_rcdecd4026:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4026:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4026:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_145
.Lssa_http__parse_request_framed_1672:
    add x28, x28, #1
    sxtw x28, w28
    b .Lssa_http__parse_request_framed_1671
.Lssa_http__parse_request_framed_148:
    tst x24, #1
    b.ne .Lssa_http__parse_request_framed_uq148
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq148
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq148:
    b.ne .Lssa_http__parse_request_framed_1695
.Lssa_http__parse_request_framed_1693:
    mov x28, #0
.Lssa_http__parse_request_framed_1697:
    ldr x9, [x24, #0]
    cmp x28, x9
    b.ge .Lssa_http__parse_request_framed_1695
.Lssa_http__parse_request_framed_1698:
    add x5, x28, #1
    ldr x9, [x24, x5, lsl #3]
    tbnz x9, #0, .Lssa_http__parse_request_framed_rcdeck4038
    cmp x9, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4038
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4038
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4038
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4038
.Lssa_http__parse_request_framed_rcdecd4038:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_http__parse_request_framed_rcdeck4038:
    mov x0, x9
.Lssa_http__parse_request_framed_rcdece4038:
    add x28, x28, #1
    b .Lssa_http__parse_request_framed_1697
.Lssa_http__parse_request_framed_1695:
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4042
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4042
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4042
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece4042
.Lssa_http__parse_request_framed_rcdecd4042:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_framed_rcdeck4042:
    mov x0, x24
.Lssa_http__parse_request_framed_rcdece4042:
    cmp x21, #1
    b.le .Lssa_http__parse_request_framed_144
.Lssa_http__parse_request_framed_1701:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4045
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4045
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4045
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4045
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4045
.Lssa_http__parse_request_framed_rcdecd4045:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4045:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4045:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_147:
    mov x10, #501
    b .Lssa_http__parse_request_framed_112
.Lssa_http__parse_request_framed_146:
    mov x10, #400
    b .Lssa_http__parse_request_framed_112
.Lssa_http__parse_request_framed_145:
    mov x10, #400
    b .Lssa_http__parse_request_framed_112
.Lssa_http__parse_request_framed_144:
    mov x21, #0
    mov x28, #0
    b .Lssa_http__parse_request_framed_131
.Lssa_http__parse_request_framed_142:
    mov x9, #-2
    cmp x27, x9
    b.ne .Lssa_http__parse_request_framed_139
.Lssa_http__parse_request_framed_1709:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4052
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4052
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4052
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4052
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4052
.Lssa_http__parse_request_framed_rcdecd4052:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4052:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4052:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_113
.Lssa_http__parse_request_framed_139:
    ldr x9, [x20, #16]
    ldr x6, [x9]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, #1
    ldr x21, [x9, x5, lsl #3]
    ldr x9, [x21, #8]
    cmp x9, #0
    b.ne .Lssa_http__parse_request_framed_136
.Lssa_http__parse_request_framed_1714:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4059
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4059
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4059
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4059
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4059
.Lssa_http__parse_request_framed_rcdecd4059:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4059:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4059:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_113
.Lssa_http__parse_request_framed_136:
.Lssa_http__parse_request_framed_135:
    ldr x27, [x21, #8]
    ldr x24, [x21, #0]
    mov x21, #0
    mov x28, #0
.Lssa_http__parse_request_framed_1719:
    cmp x28, x27
    b.ge .Lssa_http__parse_request_framed_133
.Lssa_http__parse_request_framed_1727:
    ldrb w23, [x24, x28]
    cmp x23, #48
    b.ge .Lssa_http__parse_request_framed_1726
.Lssa_http__parse_request_framed_1732:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4076
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4076
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4076
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4076
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4076
.Lssa_http__parse_request_framed_rcdecd4076:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4076:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4076:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_113
.Lssa_http__parse_request_framed_1726:
    cmp x23, #57
    b.le .Lssa_http__parse_request_framed_1724
.Lssa_http__parse_request_framed_1736:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4080
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4080
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4080
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4080
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4080
.Lssa_http__parse_request_framed_rcdecd4080:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4080:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4080:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_113
.Lssa_http__parse_request_framed_1724:
    sub x23, x23, #48
    sxtw x23, w23
    ldr x9, =214748364
    cmp x21, x9
    b.le .Lssa_http__parse_request_framed_1723
.Lssa_http__parse_request_framed_1740:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4087
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4087
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4087
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4087
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4087
.Lssa_http__parse_request_framed_rcdecd4087:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4087:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4087:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_113
.Lssa_http__parse_request_framed_1723:
    ldr x9, =214748364
    cmp x21, x9
    b.ne .Lssa_http__parse_request_framed_1720
.Lssa_http__parse_request_framed_1722:
    cmp x23, #7
    b.le .Lssa_http__parse_request_framed_1720
.Lssa_http__parse_request_framed_1748:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck4093
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck4093
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd4093
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck4093
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece4093
.Lssa_http__parse_request_framed_rcdecd4093:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck4093:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece4093:
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
    b .Lssa_http__parse_request_framed_113
.Lssa_http__parse_request_framed_1720:
    mov x9, #10
    mul x9, x21, x9
    add x9, x9, x23
    sxtw x21, w9
    add x28, x28, #1
    cmp x28, x27
    b.lt .Lssa_http__parse_request_framed_1727
.Lssa_http__parse_request_framed_134:
.Lssa_http__parse_request_framed_133:
    mov x28, x21
    mov x21, #1
.Lssa_http__parse_request_framed_132:
.Lssa_http__parse_request_framed_131:
    mov x0, x19
    ldr x9, [sp, #104]
    ldr x10, [sp, #112]
    ldr x11, [sp, #120]
    bl __fn_http____shared_string.r
    str x0, [sp, #64]
    ldr x4, [sp, #104]
    ldr x5, [sp, #88]
    add x9, x4, x5
    sxtw x27, w9
.Lssa_http__parse_request_framed_130:
.Lssa_http__parse_request_framed_129:
    mov x23, #0
    mov x24, #0
.Lssa_http__parse_request_framed_1754:
    cmp x25, #0
    b.lt .Lssa_http__parse_request_framed_128
.Lssa_http__parse_request_framed_1761:
    ldr x26, [x20, #16]
    ldr x6, [x26]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x0, [x26, x5, lsl #3]
    adrp x9, .SB20
    add x9, x9, :lo12:.SB20
    bl __fn_http____lists_token.r
    cbz x0, .Lssa_http__parse_request_framed_1758
.Lssa_http__parse_request_framed_1760:
    mov x23, #1
.Lssa_http__parse_request_framed_1759:
.Lssa_http__parse_request_framed_1758:
    ldr x6, [x26]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x0, [x26, x5, lsl #3]
    adrp x9, .SB21
    add x9, x9, :lo12:.SB21
    bl __fn_http____lists_token.r
    cbz x0, .Lssa_http__parse_request_framed_1755
.Lssa_http__parse_request_framed_1757:
    mov x24, #1
.Lssa_http__parse_request_framed_1756:
.Lssa_http__parse_request_framed_1755:
    adrp x9, .SB14
    add x9, x9, :lo12:.SB14
    add x25, x25, #1
    sxtw x10, w25
    mov x0, x20
    bl __fn_http____field_at.r
    mov x25, x0
    cmp x25, #0
    b.ge .Lssa_http__parse_request_framed_1761
.Lssa_http__parse_request_framed_128:
    cbz x23, .Lssa_http__parse_request_framed_125
.Lssa_http__parse_request_framed_127:
    str xzr, [sp, #120]
    b .Lssa_http__parse_request_framed_119
.Lssa_http__parse_request_framed_125:
    adrp x10, .SB10
    add x10, x10, :lo12:.SB10
    ldr x4, [sp, #80]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_http__parse_request_framed_122
.Lssa_http__parse_request_framed_1783:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn4152
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_framed_streqn4152
    ldr x0, [sp, #80]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd4152
.Lssa_http__parse_request_framed_streqn4152:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd4152:
    cbz x0, .Lssa_http__parse_request_framed_122
.Lssa_http__parse_request_framed_124:
    str x24, [sp, #120]
    b .Lssa_http__parse_request_framed_119
.Lssa_http__parse_request_framed_122:
    mov x5, #1
    str x5, [sp, #120]
.Lssa_http__parse_request_framed_121:
.Lssa_http__parse_request_framed_119:
    adrp x4, .K7
    add x4, x4, :lo12:.K7
    str x4, [sp, #112]
    adrp x4, .K1
    add x4, x4, :lo12:.K1
    str x4, [sp, #104]
    cbz x21, .Lssa_http__parse_request_framed_105
.Lssa_http__parse_request_framed_118:
    ldr x5, [sp, #128]
    cmp x28, x5
    b.le .Lssa_http__parse_request_framed_110
.Lssa_http__parse_request_framed_117:
    ldr x23, [sp, #112]
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x21, #413
    mov x28, #0
    b .Lssa_http__parse_request_framed_20
.Lssa_http__parse_request_framed_113:
    mov x10, #400
.Lssa_http__parse_request_framed_112:
    mov x11, x10
    b .Lssa_http__parse_request_framed_50
.Lssa_http__parse_request_framed_110:
    add x10, x27, x28
    sxtw x10, w10
    ldr x9, [x19, #0]
    cmp x10, x9
    b.le .Lssa_http__parse_request_framed_107
.Lssa_http__parse_request_framed_109:
    ldr x23, [sp, #112]
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x21, #1
    mov x28, #0
    b .Lssa_http__parse_request_framed_20
.Lssa_http__parse_request_framed_107:
    add x28, x27, x28
    sxtw x28, w28
    str x19, [sp, #-16]!
    str x27, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_bytes_range
    add sp, sp, #48
    mov x23, x0
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x21, #2
    b .Lssa_http__parse_request_framed_20
.Lssa_http__parse_request_framed_105:
    adrp x10, .SB11
    add x10, x10, :lo12:.SB11
    ldr x4, [sp, #80]
    ldr x9, [x4, #8]
    cmp x9, #8
    b.ne .Lssa_http__parse_request_framed_1809
.Lssa_http__parse_request_framed_1808:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn4184
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_framed_streqn4184
    ldr x0, [sp, #80]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd4184
.Lssa_http__parse_request_framed_streqn4184:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd4184:
    b .Lssa_http__parse_request_framed_1810
.Lssa_http__parse_request_framed_1809:
    mov x0, #0
.Lssa_http__parse_request_framed_1810:
    cbnz x0, .Lssa_http__parse_request_framed_101
.Lssa_http__parse_request_framed_104:
    b .Lssa_http__parse_request_framed_pool_1787
    .ltorg
.Lssa_http__parse_request_framed_pool_1787:
    ldr x23, [sp, #112]
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x21, #400
    mov x28, #0
    b .Lssa_http__parse_request_framed_20
.Lssa_http__parse_request_framed_101:
    adrp x10, .K0
    add x10, x10, :lo12:.K0
    adrp x4, .K1
    add x4, x4, :lo12:.K1
    str x4, [sp, #88]
.Lssa_http__parse_request_framed_100:
    ldr x26, [sp, #128]
    mov x24, x10
.Lssa_http__parse_request_framed_1816:
.Lssa_http__parse_request_framed_1888:
    ldr x25, [x19, #0]
    ldr x5, [sp, #136]
    add x10, x27, x5
    sxtw x10, w10
    cmp x10, x25
    csel x23, x25, x10, gt
.Lssa_http__parse_request_framed_1885:
.Lssa_http__parse_request_framed_1884:
    mov x9, #13
    mov x2, x27
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L80
    mov x2, #0
.L80:
    cmp x1, #255
    b.hi .L85
    cmp x2, x3
    b.ge .L85
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L82
.L81:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L87
    cmp x5, x8
    b.ls .L81
.L82:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L83
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L83
    sub x5, x5, #16
    b .L88
.L87:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L88
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L88:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L86
.L83:
    cmp x5, x6
    b.ge .L85
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L84
    add x5, x5, #1
    b .L83
.L84:
    sub x2, x5, x0
    b .L86
.L85:
    mov x2, #-1
.L86:
    mov x0, x2
.Lssa_http__parse_request_framed_1883:
    mov x28, x0
.Lssa_http__parse_request_framed_1895:
    cmp x28, #0
    b.lt .Lssa_http__parse_request_framed_1882
.Lssa_http__parse_request_framed_1899:
    add x9, x28, #1
    sxtw x9, w9
    cmp x9, x23
    b.ge .Lssa_http__parse_request_framed_1882
.Lssa_http__parse_request_framed_1898:
    add w9, w28, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http__parse_request_framed_1880
.Lssa_http__parse_request_framed_1896:
    add x10, x28, #1
    sxtw x10, w10
    mov x9, #13
    mov x2, x10
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L89
    mov x2, #0
.L89:
    cmp x1, #255
    b.hi .L94
    cmp x2, x3
    b.ge .L94
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L91
.L90:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L96
    cmp x5, x8
    b.ls .L90
.L91:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L92
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L92
    sub x5, x5, #16
    b .L97
.L96:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L97
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L97:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L95
.L92:
    cmp x5, x6
    b.ge .L94
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L93
    add x5, x5, #1
    b .L92
.L93:
    sub x2, x5, x0
    b .L95
.L94:
    mov x2, #-1
.L95:
    mov x28, x2
    cmp x28, #0
    b.ge .Lssa_http__parse_request_framed_1899
.Lssa_http__parse_request_framed_1882:
    mov x9, #-1
    mov x28, x9
.Lssa_http__parse_request_framed_1881:
.Lssa_http__parse_request_framed_1880:
    cmp x28, #0
    csel x23, x28, x23, ge
.Lssa_http__parse_request_framed_1877:
.Lssa_http__parse_request_framed_1876:
    mov x21, x27
.Lssa_http__parse_request_framed_1920:
.Lssa_http__parse_request_framed_1930:
    mov x9, #13
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L98
    mov x2, #0
.L98:
    cmp x1, #255
    b.hi .L103
    cmp x2, x3
    b.ge .L103
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L100
.L99:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L105
    cmp x5, x8
    b.ls .L99
.L100:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L101
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L101
    sub x5, x5, #16
    b .L106
.L105:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L106
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L106:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L104
.L101:
    cmp x5, x6
    b.ge .L103
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L102
    add x5, x5, #1
    b .L101
.L102:
    sub x2, x5, x0
    b .L104
.L103:
    mov x2, #-1
.L104:
    mov x22, x2
    mov x9, #10
    mov x2, x21
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L107
    mov x2, #0
.L107:
    cmp x1, #255
    b.hi .L112
    cmp x2, x3
    b.ge .L112
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L109
.L108:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L114
    cmp x5, x8
    b.ls .L108
.L109:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L110
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L110
    sub x5, x5, #16
    b .L115
.L114:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L115
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L115:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L113
.L110:
    cmp x5, x6
    b.ge .L112
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L111
    add x5, x5, #1
    b .L110
.L111:
    sub x2, x5, x0
    b .L113
.L112:
    mov x2, #-1
.L113:
    mov x0, x2
    cmp x22, #0
    b.lt .Lssa_http__parse_request_framed_1875
.Lssa_http__parse_request_framed_1929:
    cmp x22, x23
    b.ge .Lssa_http__parse_request_framed_1875
.Lssa_http__parse_request_framed_1927:
    cmp x0, #0
    b.lt .Lssa_http__parse_request_framed_1924
.Lssa_http__parse_request_framed_1926:
    cmp x0, x22
    b.lt .Lssa_http__parse_request_framed_1864
.Lssa_http__parse_request_framed_1924:
    add x9, x22, #1
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http__parse_request_framed_1921
.Lssa_http__parse_request_framed_1923:
    add x9, x22, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.ne .Lssa_http__parse_request_framed_1864
.Lssa_http__parse_request_framed_1921:
    add x22, x22, #2
    sxtw x21, w22
    b .Lssa_http__parse_request_framed_1930
.Lssa_http__parse_request_framed_1875:
    cmp x0, #0
    b.lt .Lssa_http__parse_request_framed_1867
.Lssa_http__parse_request_framed_1873:
    cmp x0, x23
    b.lt .Lssa_http__parse_request_framed_1864
.Lssa_http__parse_request_framed_1867:
    cmp x28, #0
    b.ge .Lssa_http__parse_request_framed_1859
.Lssa_http__parse_request_framed_1866:
    ldr x5, [sp, #136]
    add x10, x27, x5
    sxtw x10, w10
    cmp x25, x10
    b.lt .Lssa_http__parse_request_framed_1862
.Lssa_http__parse_request_framed_1865:
    mov x12, #431
    mov x28, #0
    mov x25, #0
    b .Lssa_http__parse_request_framed_1840
.Lssa_http__parse_request_framed_1864:
    mov x12, #400
    mov x28, #0
    mov x25, #0
    b .Lssa_http__parse_request_framed_1840
.Lssa_http__parse_request_framed_1862:
    mov x12, #1
    mov x28, #0
    mov x25, #0
    b .Lssa_http__parse_request_framed_1840
.Lssa_http__parse_request_framed_1859:
.Lssa_http__parse_request_framed_1858:
    mov x9, x27
    mov x10, #0
.Lssa_http__parse_request_framed_1979:
    cmp x9, x28
    b.ge .Lssa_http__parse_request_framed_1857
.Lssa_http__parse_request_framed_2011:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w14, [x5, #8]
.Lssa_http__parse_request_framed_2010:
    cmp x14, #48
    b.lo .Lssa_http__parse_request_framed_2006
.Lssa_http__parse_request_framed_2009:
    cmp x14, #57
    b.hi .Lssa_http__parse_request_framed_2006
.Lssa_http__parse_request_framed_2008:
    sub x12, x14, #48
    sxtw x12, w12
    b .Lssa_http__parse_request_framed_1997
.Lssa_http__parse_request_framed_2006:
    cmp x14, #97
    b.lo .Lssa_http__parse_request_framed_2002
.Lssa_http__parse_request_framed_2005:
    cmp x14, #102
    b.hi .Lssa_http__parse_request_framed_2002
.Lssa_http__parse_request_framed_2004:
    sub x12, x14, #87
    sxtw x12, w12
    b .Lssa_http__parse_request_framed_1997
.Lssa_http__parse_request_framed_2002:
    cmp x14, #65
    b.lo .Lssa_http__parse_request_framed_1998
.Lssa_http__parse_request_framed_2001:
    cmp x14, #70
    b.hi .Lssa_http__parse_request_framed_1998
.Lssa_http__parse_request_framed_2000:
    sub x12, x14, #55
    sxtw x12, w12
    b .Lssa_http__parse_request_framed_1997
.Lssa_http__parse_request_framed_1998:
    mov x12, #-1
.Lssa_http__parse_request_framed_1997:
    cmp x12, #0
    b.lt .Lssa_http__parse_request_framed_1857
.Lssa_http__parse_request_framed_1995:
    cmp x14, #48
    b.lo .Lssa_http__parse_request_framed_1991
.Lssa_http__parse_request_framed_1994:
    cmp x14, #57
    b.hi .Lssa_http__parse_request_framed_1991
.Lssa_http__parse_request_framed_1993:
    sub x12, x14, #48
    mov x14, x12
    b .Lssa_http__parse_request_framed_1982
.Lssa_http__parse_request_framed_1991:
    cmp x14, #97
    b.lo .Lssa_http__parse_request_framed_1987
.Lssa_http__parse_request_framed_1990:
    cmp x14, #102
    b.hi .Lssa_http__parse_request_framed_1987
.Lssa_http__parse_request_framed_1989:
    sub x12, x14, #87
    mov x14, x12
    b .Lssa_http__parse_request_framed_1982
.Lssa_http__parse_request_framed_1987:
    cmp x14, #65
    b.lo .Lssa_http__parse_request_framed_1983
.Lssa_http__parse_request_framed_1986:
    cmp x14, #70
    b.hi .Lssa_http__parse_request_framed_1983
.Lssa_http__parse_request_framed_1985:
    sub x14, x14, #55
    b .Lssa_http__parse_request_framed_1982
.Lssa_http__parse_request_framed_1983:
    mov x14, #-1
.Lssa_http__parse_request_framed_1982:
    lsl x12, x10, #4
    add x12, x12, x14
    sxtw x12, w12
    cmp x12, x26
    b.gt .Lssa_http__parse_request_framed_1855
.Lssa_http__parse_request_framed_1980:
    lsl x12, x10, #4
    add x12, x12, x14
    sxtw x10, w12
    add x9, x9, #1
    cmp x9, x28
    b.lt .Lssa_http__parse_request_framed_2011
.Lssa_http__parse_request_framed_1857:
    cmp x9, x27
    b.ne .Lssa_http__parse_request_framed_1853
.Lssa_http__parse_request_framed_1856:
    mov x12, #400
    mov x25, #0
    b .Lssa_http__parse_request_framed_1852
.Lssa_http__parse_request_framed_1855:
    mov x12, #413
    mov x25, #0
    b .Lssa_http__parse_request_framed_1852
.Lssa_http__parse_request_framed_1853:
    mov x25, x10
    mov x12, #0
.Lssa_http__parse_request_framed_1852:
    cmp x12, #0
    b.eq .Lssa_http__parse_request_framed_2091
.Lssa_http__parse_request_framed_1851:
    mov x28, #0
    mov x25, #0
    b .Lssa_http__parse_request_framed_1840
.Lssa_http__parse_request_framed_1849:
.Lssa_http__parse_request_framed_2091:
    cmp x9, x28
    b.ge .Lssa_http__parse_request_framed_1842
.Lssa_http__parse_request_framed_2126:
.Lssa_http__parse_request_framed_2132:
    cmp x9, x28
    b.ge .Lssa_http__parse_request_framed_2124
.Lssa_http__parse_request_framed_2139:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_framed_2138:
    cmp x10, #32
    b.eq .Lssa_http__parse_request_framed_2133
.Lssa_http__parse_request_framed_2136:
    cmp x10, #9
    b.ne .Lssa_http__parse_request_framed_2124
.Lssa_http__parse_request_framed_2133:
    add x9, x9, #1
    cmp x9, x28
    b.lt .Lssa_http__parse_request_framed_2139
.Lssa_http__parse_request_framed_2124:
    cmp x9, x28
    b.ge .Lssa_http__parse_request_framed_1841
.Lssa_http__parse_request_framed_2123:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #59
    b.ne .Lssa_http__parse_request_framed_1841
.Lssa_http__parse_request_framed_2121:
    add x9, x9, #1
.Lssa_http__parse_request_framed_2120:
    mov x23, x9
.Lssa_http__parse_request_framed_2163:
    cmp x23, x28
    b.ge .Lssa_http__parse_request_framed_2118
.Lssa_http__parse_request_framed_2170:
    ldr x6, [x19]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x23
    ldrb w9, [x5, #8]
.Lssa_http__parse_request_framed_2169:
    cmp x9, #32
    b.eq .Lssa_http__parse_request_framed_2164
.Lssa_http__parse_request_framed_2167:
    cmp x9, #9
    b.ne .Lssa_http__parse_request_framed_2118
.Lssa_http__parse_request_framed_2164:
    add x23, x23, #1
    cmp x23, x28
    b.lt .Lssa_http__parse_request_framed_2170
.Lssa_http__parse_request_framed_2118:
    adrp x9, .K5
    add x9, x9, :lo12:.K5
    mov x2, x9
    mov x1, x23
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L116
    mov x1, #0
.L116:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L119
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L117:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L118
    add x5, x5, #16
    cmp x5, x8
    b.ls .L117
    sub x1, x5, x0
    b .L119
.L118:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L120
.L119:
    add x10, x9, #96
.L123:
    cmp x1, x3
    b.ge .L121
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L120
    add x1, x1, #1
    b .L123
.L120:
    str x1, [sp, #-16]!
    b .L122
.L121:
    str x3, [sp, #-16]!
.L122:
    ldr x0, [sp], #16
    cmp x0, x28
    csel x0, x28, x0, gt
.Lssa_http__parse_request_framed_2186:
    cmp x0, x23
    b.eq .Lssa_http__parse_request_framed_1841
.Lssa_http__parse_request_framed_2116:
    mov x9, x0
.Lssa_http__parse_request_framed_2200:
    cmp x9, x28
    b.ge .Lssa_http__parse_request_framed_2114
.Lssa_http__parse_request_framed_2207:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
.Lssa_http__parse_request_framed_2206:
    cmp x10, #32
    b.eq .Lssa_http__parse_request_framed_2201
.Lssa_http__parse_request_framed_2204:
    cmp x10, #9
    b.ne .Lssa_http__parse_request_framed_2114
.Lssa_http__parse_request_framed_2201:
    add x9, x9, #1
    cmp x9, x28
    b.lt .Lssa_http__parse_request_framed_2207
.Lssa_http__parse_request_framed_2114:
    cmp x9, x28
    b.ge .Lssa_http__parse_request_framed_2106
.Lssa_http__parse_request_framed_2113:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #61
    b.ne .Lssa_http__parse_request_framed_2106
.Lssa_http__parse_request_framed_2112:
    add x9, x9, #1
.Lssa_http__parse_request_framed_2111:
    mov x23, x9
.Lssa_http__parse_request_framed_2231:
    cmp x23, x28
    b.ge .Lssa_http__parse_request_framed_2108
.Lssa_http__parse_request_framed_2238:
    ldr x6, [x19]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x23
    ldrb w9, [x5, #8]
.Lssa_http__parse_request_framed_2237:
    cmp x9, #32
    b.eq .Lssa_http__parse_request_framed_2232
.Lssa_http__parse_request_framed_2235:
    cmp x9, #9
    b.ne .Lssa_http__parse_request_framed_2108
.Lssa_http__parse_request_framed_2232:
    add x23, x23, #1
    cmp x23, x28
    b.lt .Lssa_http__parse_request_framed_2238
.Lssa_http__parse_request_framed_2108:
    cmp x23, x28
    b.lt .Lssa_http__parse_request_framed_2104
.Lssa_http__parse_request_framed_2107:
    mov x9, #-1
    mov x10, x9
    b .Lssa_http__parse_request_framed_2094
.Lssa_http__parse_request_framed_2106:
    mov x9, x0
    b .Lssa_http__parse_request_framed_2091
.Lssa_http__parse_request_framed_2104:
    ldr x6, [x19]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x23
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_http__parse_request_framed_2099
.Lssa_http__parse_request_framed_2103:
    adrp x9, .K5
    add x9, x9, :lo12:.K5
    mov x2, x9
    mov x1, x23
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L124
    mov x1, #0
.L124:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L127
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L125:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L126
    add x5, x5, #16
    cmp x5, x8
    b.ls .L125
    sub x1, x5, x0
    b .L127
.L126:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L128
.L127:
    add x10, x9, #96
.L131:
    cmp x1, x3
    b.ge .L129
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L128
    add x1, x1, #1
    b .L131
.L128:
    str x1, [sp, #-16]!
    b .L130
.L129:
    str x3, [sp, #-16]!
.L130:
    ldr x0, [sp], #16
    cmp x0, x28
    csel x0, x28, x0, gt
.Lssa_http__parse_request_framed_2264:
    cmp x0, x23
    b.ne .Lssa_http__parse_request_framed_2101
.Lssa_http__parse_request_framed_2102:
    mov x9, #-1
    mov x10, x9
    b .Lssa_http__parse_request_framed_2094
.Lssa_http__parse_request_framed_2101:
    mov x10, x0
    b .Lssa_http__parse_request_framed_2094
.Lssa_http__parse_request_framed_2099:
    add x23, x23, #1
.Lssa_http__parse_request_framed_2098:
.Lssa_http__parse_request_framed_2280:
    cmp x23, x28
    b.ge .Lssa_http__parse_request_framed_2097
.Lssa_http__parse_request_framed_2297:
    ldr x6, [x19]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x23
    ldrb w9, [x5, #8]
    cmp x9, #34
    b.eq .Lssa_http__parse_request_framed_2096
.Lssa_http__parse_request_framed_2295:
    add x10, x23, #1
    cmp x9, #92
    csel x10, x10, x23, eq
.Lssa_http__parse_request_framed_2292:
    cmp x10, x28
    b.ge .Lssa_http__parse_request_framed_2095
.Lssa_http__parse_request_framed_2291:
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x10
    ldrb w9, [x5, #8]
.Lssa_http__parse_request_framed_2290:
    cmp x9, #9
    b.eq .Lssa_http__parse_request_framed_2281
.Lssa_http__parse_request_framed_2288:
    cmp x9, #32
    b.lo .Lssa_http__parse_request_framed_2095
.Lssa_http__parse_request_framed_2287:
    cmp x9, #127
    b.eq .Lssa_http__parse_request_framed_2095
.Lssa_http__parse_request_framed_2281:
    add x23, x10, #1
    cmp x23, x28
    b.lt .Lssa_http__parse_request_framed_2297
.Lssa_http__parse_request_framed_2097:
    mov x10, #-1
    b .Lssa_http__parse_request_framed_2094
.Lssa_http__parse_request_framed_2096:
    add x23, x23, #1
    mov x10, x23
    b .Lssa_http__parse_request_framed_2094
.Lssa_http__parse_request_framed_2095:
    mov x10, #-1
.Lssa_http__parse_request_framed_2094:
    cmp x10, #0
    b.lt .Lssa_http__parse_request_framed_1841
.Lssa_http__parse_request_framed_2093:
    mov x9, x10
.Lssa_http__parse_request_framed_2092:
    cmp x9, x28
    b.lt .Lssa_http__parse_request_framed_2132
.Lssa_http__parse_request_framed_1842:
    mov x12, #2
    b .Lssa_http__parse_request_framed_1840
.Lssa_http__parse_request_framed_1841:
    mov x12, #400
    mov x28, #0
    mov x25, #0
.Lssa_http__parse_request_framed_1840:
    cmp x12, #2
    b.ne .Lssa_http__parse_request_framed_99
.Lssa_http__parse_request_framed_1838:
    add x28, x28, #2
    sxtw x28, w28
    sub x27, x28, x27
    ldr x4, [sp, #136]
    sub x27, x4, x27
    sub x27, x27, #2
    sxtw x27, w27
    cmp x27, #0
    b.lt .Lssa_http__parse_request_framed_98
.Lssa_http__parse_request_framed_1836:
    cmp x25, #0
    b.eq .Lssa_http__parse_request_framed_97
.Lssa_http__parse_request_framed_1834:
    add x9, x28, x25
    sxtw x9, w9
.Lssa_http__parse_request_framed_1833:
    ldr x10, [x19, #0]
    cmp x9, x10
    b.ge .Lssa_http__parse_request_framed_1829
.Lssa_http__parse_request_framed_1832:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w14, [x5, #8]
    cmp x14, #13
    b.eq .Lssa_http__parse_request_framed_1829
.Lssa_http__parse_request_framed_1831:
    mov x9, #0
    b .Lssa_http__parse_request_framed_1821
.Lssa_http__parse_request_framed_1829:
    add x14, x9, #1
    sxtw x14, w14
    cmp x14, x10
    b.ge .Lssa_http__parse_request_framed_1825
.Lssa_http__parse_request_framed_1828:
    add w14, w9, #1
    ldr x6, [x19]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x14
    ldrb w15, [x5, #8]
    cmp x15, #10
    b.eq .Lssa_http__parse_request_framed_1825
.Lssa_http__parse_request_framed_1827:
    mov x9, #0
    b .Lssa_http__parse_request_framed_1821
.Lssa_http__parse_request_framed_1825:
    add x9, x9, #2
    sxtw x9, w9
    cmp x9, x10
    b.le .Lssa_http__parse_request_framed_1822
.Lssa_http__parse_request_framed_1824:
    mov x9, #1
    b .Lssa_http__parse_request_framed_1821
.Lssa_http__parse_request_framed_1822:
    mov x9, #2
.Lssa_http__parse_request_framed_1821:
    cmp x9, #0
    b.eq .Lssa_http__parse_request_framed_94
.Lssa_http__parse_request_framed_1819:
    cmp x9, #1
    b.eq .Lssa_http__parse_request_framed_93
.Lssa_http__parse_request_framed_1817:
    mov x0, x24
    mov x1, x28
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush4801s
.Lssa_http__parse_request_framed_apush4801o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush4801e
.Lssa_http__parse_request_framed_apush4801s:
    str x12, [sp, #56]
    bl __fern_arr_push_owned
    ldr x12, [sp, #56]
.Lssa_http__parse_request_framed_apush4801e:
    mov x1, x25
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush4802s
.Lssa_http__parse_request_framed_apush4802o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush4802e
.Lssa_http__parse_request_framed_apush4802s:
    str x12, [sp, #56]
    bl __fern_arr_push_owned
    ldr x12, [sp, #56]
.Lssa_http__parse_request_framed_apush4802e:
    mov x24, x0
    sub x26, x26, x25
    sxtw x26, w26
    add x25, x28, x25
    add x25, x25, #2
    sxtw x25, w25
    str x27, [sp, #136]
    mov x27, x25
    b .Lssa_http__parse_request_framed_1888
.Lssa_http__parse_request_framed_99:
    mov x21, x12
    ldr x5, [sp, #88]
    str x5, [sp, #136]
    mov x28, #0
    b .Lssa_http__parse_request_framed_29
.Lssa_http__parse_request_framed_98:
    ldr x5, [sp, #88]
    str x5, [sp, #136]
    mov x21, #431
    mov x28, #0
    b .Lssa_http__parse_request_framed_29
.Lssa_http__parse_request_framed_97:
    add x27, x27, #2
.Lssa_http__parse_request_framed_96:
    ldr x25, [x19, #0]
    adrp x4, .K1
    add x4, x4, :lo12:.K1
    str x4, [sp, #136]
    add x12, x28, x27
    sxtw x12, w12
    cmp x12, x25
    csel x23, x25, x12, gt
    b .Lssa_http__parse_request_framed_91
.Lssa_http__parse_request_framed_94:
    ldr x5, [sp, #88]
    str x5, [sp, #136]
    mov x21, #400
    mov x28, #0
    b .Lssa_http__parse_request_framed_29
.Lssa_http__parse_request_framed_93:
    ldr x5, [sp, #88]
    str x5, [sp, #136]
    mov x21, #1
    mov x28, #0
    b .Lssa_http__parse_request_framed_29
.Lssa_http__parse_request_framed_91:
    sub x9, x28, #2
    sxtw x9, w9
.Lssa_http__parse_request_framed_90:
    mov x12, #13
    mov x2, x9
    mov x1, x12
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L132
    mov x2, #0
.L132:
    cmp x1, #255
    b.hi .L137
    cmp x2, x3
    b.ge .L137
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L134
.L133:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L139
    cmp x5, x8
    b.ls .L133
.L134:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L135
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L135
    sub x5, x5, #16
    b .L140
.L139:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L140
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L140:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L138
.L135:
    cmp x5, x6
    b.ge .L137
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L136
    add x5, x5, #1
    b .L135
.L136:
    sub x2, x5, x0
    b .L138
.L137:
    mov x2, #-1
.L138:
    mov x0, x2
    b .Lssa_http__parse_request_framed_pool_2260
    .ltorg
.Lssa_http__parse_request_framed_pool_2260:
.Lssa_http__parse_request_framed_89:
    mov x21, x0
.Lssa_http__parse_request_framed_2401:
    cmp x21, #0
    b.lt .Lssa_http__parse_request_framed_88
.Lssa_http__parse_request_framed_2407:
    add x12, x21, #3
    sxtw x12, w12
    cmp x12, x23
    b.ge .Lssa_http__parse_request_framed_88
.Lssa_http__parse_request_framed_2406:
    add w12, w21, #1
    ldr x6, [x19]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x12
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.ne .Lssa_http__parse_request_framed_2402
.Lssa_http__parse_request_framed_2405:
    add w9, w21, #2
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w12, [x5, #8]
    cmp x12, #13
    b.ne .Lssa_http__parse_request_framed_2402
.Lssa_http__parse_request_framed_2404:
    add w12, w21, #3
    ldr x6, [x19]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x12
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.eq .Lssa_http__parse_request_framed_86
.Lssa_http__parse_request_framed_2402:
    add x9, x21, #1
    sxtw x9, w9
    mov x12, #13
    mov x2, x9
    mov x1, x12
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L141
    mov x2, #0
.L141:
    cmp x1, #255
    b.hi .L146
    cmp x2, x3
    b.ge .L146
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L143
.L142:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L148
    cmp x5, x8
    b.ls .L142
.L143:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L144
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L144
    sub x5, x5, #16
    b .L149
.L148:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L149
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L149:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L147
.L144:
    cmp x5, x6
    b.ge .L146
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L145
    add x5, x5, #1
    b .L144
.L145:
    sub x2, x5, x0
    b .L147
.L146:
    mov x2, #-1
.L147:
    mov x21, x2
    cmp x21, #0
    b.ge .Lssa_http__parse_request_framed_2407
.Lssa_http__parse_request_framed_88:
    mov x12, #-1
    mov x21, x12
.Lssa_http__parse_request_framed_87:
.Lssa_http__parse_request_framed_86:
    cmp x21, #0
    csel x23, x21, x23, ge
.Lssa_http__parse_request_framed_83:
    cmp x23, x28
    b.le .Lssa_http__parse_request_framed_72
.Lssa_http__parse_request_framed_81:
    mov x22, x28
.Lssa_http__parse_request_framed_2440:
.Lssa_http__parse_request_framed_2450:
    mov x12, #13
    mov x2, x22
    mov x1, x12
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L150
    mov x2, #0
.L150:
    cmp x1, #255
    b.hi .L155
    cmp x2, x3
    b.ge .L155
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L152
.L151:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L157
    cmp x5, x8
    b.ls .L151
.L152:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L153
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L153
    sub x5, x5, #16
    b .L158
.L157:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L158
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L158:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L156
.L153:
    cmp x5, x6
    b.ge .L155
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L154
    add x5, x5, #1
    b .L153
.L154:
    sub x2, x5, x0
    b .L156
.L155:
    mov x2, #-1
.L156:
    mov x26, x2
    mov x12, #10
    mov x2, x22
    mov x1, x12
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L159
    mov x2, #0
.L159:
    cmp x1, #255
    b.hi .L164
    cmp x2, x3
    b.ge .L164
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L161
.L160:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L166
    cmp x5, x8
    b.ls .L160
.L161:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L162
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L162
    sub x5, x5, #16
    b .L167
.L166:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L167
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L167:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L165
.L162:
    cmp x5, x6
    b.ge .L164
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L163
    add x5, x5, #1
    b .L162
.L163:
    sub x2, x5, x0
    b .L165
.L164:
    mov x2, #-1
.L165:
    mov x0, x2
    cmp x26, #0
    b.lt .Lssa_http__parse_request_framed_80
.Lssa_http__parse_request_framed_2449:
    cmp x26, x23
    b.ge .Lssa_http__parse_request_framed_80
.Lssa_http__parse_request_framed_2447:
    cmp x0, #0
    b.lt .Lssa_http__parse_request_framed_2444
.Lssa_http__parse_request_framed_2446:
    cmp x0, x26
    b.lt .Lssa_http__parse_request_framed_69
.Lssa_http__parse_request_framed_2444:
    add x12, x26, #1
    ldr x9, [x19, #0]
    cmp x12, x9
    b.ge .Lssa_http__parse_request_framed_2441
.Lssa_http__parse_request_framed_2443:
    add x12, x26, #1
    ldr x6, [x19]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x12
    ldrb w9, [x5, #8]
    cmp x9, #10
    b.ne .Lssa_http__parse_request_framed_69
.Lssa_http__parse_request_framed_2441:
    add x26, x26, #2
    sxtw x22, w26
    b .Lssa_http__parse_request_framed_2450
.Lssa_http__parse_request_framed_80:
    cmp x0, #0
    b.lt .Lssa_http__parse_request_framed_72
.Lssa_http__parse_request_framed_78:
    cmp x0, x23
    b.lt .Lssa_http__parse_request_framed_69
.Lssa_http__parse_request_framed_72:
    cmp x21, #0
    b.ge .Lssa_http__parse_request_framed_65
.Lssa_http__parse_request_framed_71:
    add x27, x28, x27
    sxtw x27, w27
    cmp x25, x27
    b.lt .Lssa_http__parse_request_framed_67
.Lssa_http__parse_request_framed_70:
    mov x11, #431
    mov x21, #0
    b .Lssa_http__parse_request_framed_30
.Lssa_http__parse_request_framed_69:
    mov x11, #400
    mov x21, #0
    b .Lssa_http__parse_request_framed_30
.Lssa_http__parse_request_framed_67:
    mov x11, #1
    mov x21, #0
    b .Lssa_http__parse_request_framed_30
.Lssa_http__parse_request_framed_65:
    cmp x21, x28
    b.le .Lssa_http__parse_request_framed_37
.Lssa_http__parse_request_framed_64:
    adrp x25, .K1
    add x25, x25, :lo12:.K1
.Lssa_http__parse_request_framed_63:
    adrp x0, .K1
    add x0, x0, :lo12:.K1
.Lssa_http__parse_request_framed_62:
    mov x22, x28
    mov x28, x0
    mov x27, #1
    mov x23, #0
.Lssa_http__parse_request_framed_2503:
    cmp x22, x21
    b.ge .Lssa_http__parse_request_framed_61
.Lssa_http__parse_request_framed_2558:
    adrp x9, .K5
    add x9, x9, :lo12:.K5
    mov x2, x9
    mov x1, x22
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L168
    mov x1, #0
.L168:
    adrp x9, .S6
    add x9, x9, :lo12:.S6
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L171
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L169:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L170
    add x5, x5, #16
    cmp x5, x8
    b.ls .L169
    sub x1, x5, x0
    b .L171
.L170:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L172
.L171:
    add x10, x9, #96
.L175:
    cmp x1, x3
    b.ge .L173
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L172
    add x1, x1, #1
    b .L175
.L172:
    str x1, [sp, #-16]!
    b .L174
.L173:
    str x3, [sp, #-16]!
.L174:
    ldr x0, [sp], #16
    cmp x0, x21
    csel x26, x21, x0, gt
.Lssa_http__parse_request_framed_2564:
    cmp x26, x22
    b.eq .Lssa_http__parse_request_framed_2555
.Lssa_http__parse_request_framed_2557:
    cmp x26, x21
    b.ge .Lssa_http__parse_request_framed_2555
.Lssa_http__parse_request_framed_2556:
    ldr x6, [x19]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x26
    ldrb w9, [x5, #8]
    cmp x9, #58
    b.eq .Lssa_http__parse_request_framed_2553
.Lssa_http__parse_request_framed_2555:
    mov x10, #-1
    mov x26, x10
    mov x10, x21
    b .Lssa_http__parse_request_framed_2541
.Lssa_http__parse_request_framed_2553:
    add x10, x26, #1
.Lssa_http__parse_request_framed_2552:
    mov x9, #13
    mov x2, x10
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x2, #0
    b.ge .L176
    mov x2, #0
.L176:
    cmp x1, #255
    b.hi .L181
    cmp x2, x3
    b.ge .L181
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L178
.L177:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L183
    cmp x5, x8
    b.ls .L177
.L178:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L179
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L179
    sub x5, x5, #16
    b .L184
.L183:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L184
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L184:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L182
.L179:
    cmp x5, x6
    b.ge .L181
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L180
    add x5, x5, #1
    b .L179
.L180:
    sub x2, x5, x0
    b .L182
.L181:
    mov x2, #-1
.L182:
    mov x0, x2
    cmp x0, #0
    b.lt .Lssa_http__parse_request_framed_2550
.Lssa_http__parse_request_framed_2551:
    cmp x0, x21
    b.lt .Lssa_http__parse_request_framed_2548
.Lssa_http__parse_request_framed_2550:
    mov x0, x21
    b .Lssa_http__parse_request_framed_2544
.Lssa_http__parse_request_framed_2548:
    add x9, x0, #1
    cmp x9, x21
    b.ge .Lssa_http__parse_request_framed_2546
.Lssa_http__parse_request_framed_2547:
    add x9, x0, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w10, [x5, #8]
    cmp x10, #10
    b.eq .Lssa_http__parse_request_framed_2544
.Lssa_http__parse_request_framed_2546:
    mov x10, #-1
    mov x0, x10
.Lssa_http__parse_request_framed_2545:
.Lssa_http__parse_request_framed_2544:
    cmp x0, #0
    b.ge .Lssa_http__parse_request_framed_2542
.Lssa_http__parse_request_framed_2543:
    mov x10, #-1
    mov x26, x10
    mov x10, x21
    b .Lssa_http__parse_request_framed_2541
.Lssa_http__parse_request_framed_2542:
    mov x10, x0
.Lssa_http__parse_request_framed_2541:
    cmp x26, #0
    b.ge .Lssa_http__parse_request_framed_2539
.Lssa_http__parse_request_framed_2610:
    str x10, [sp, #56]
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    b .Lssa_http__parse_request_framed_44
.Lssa_http__parse_request_framed_2539:
    add x9, x23, #1
    sxtw x23, w9
    cmp x23, #100
    b.le .Lssa_http__parse_request_framed_2537
.Lssa_http__parse_request_framed_2614:
    str x10, [sp, #56]
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    b .Lssa_http__parse_request_framed_43
.Lssa_http__parse_request_framed_2537:
    sub x9, x23, #1
    sxtw x12, w9
    cbz x27, .Lssa_http__parse_request_framed_2530
.Lssa_http__parse_request_framed_2536:
    ldr x9, [x25, #8]
    ldr x15, [x9, #0]
    cmp x12, x15
    b.lt .Lssa_http__parse_request_framed_2530
.Lssa_http__parse_request_framed_2535:
    cmp x12, #0
    b.le .Lssa_http__parse_request_framed_2532
.Lssa_http__parse_request_framed_2626:
    str x10, [sp, #56]
    str x12, [sp, #48]
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
.Lssa_http__parse_request_framed_2534:
    tbnz x25, #0, .Lssa_http__parse_request_framed_rcinc5069
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc5069
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc5069
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_framed_rcinc5069:
    mov x0, x25
    str x10, [sp, #56]
    str x12, [sp, #48]
    mov x0, x25
    mov x9, x12
    bl __fn_http____leading_fields.r
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    mov x28, x0
.Lssa_http__parse_request_framed_2533:
.Lssa_http__parse_request_framed_2532:
    mov x27, #0
.Lssa_http__parse_request_framed_2531:
.Lssa_http__parse_request_framed_2530:
    mov x15, #-1
    cmp x27, #0
    csel x15, x12, x15, ne
.Lssa_http__parse_request_framed_2527:
    add x9, x26, #1
    sxtw x9, w9
.Lssa_http__parse_request_framed_2526:
.Lssa_http__parse_request_framed_2637:
    cmp x9, x10
    b.ge .Lssa_http__parse_request_framed_2524
.Lssa_http__parse_request_framed_2644:
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x9
    ldrb w14, [x5, #8]
.Lssa_http__parse_request_framed_2643:
    cmp x14, #32
    b.eq .Lssa_http__parse_request_framed_2638
.Lssa_http__parse_request_framed_2641:
    cmp x14, #9
    b.ne .Lssa_http__parse_request_framed_2524
.Lssa_http__parse_request_framed_2638:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http__parse_request_framed_2644
.Lssa_http__parse_request_framed_2524:
    mov x14, x10
.Lssa_http__parse_request_framed_2660:
    cmp x14, x9
    b.le .Lssa_http__parse_request_framed_2523
.Lssa_http__parse_request_framed_2667:
    sub x8, x14, #1
    ldr x6, [x19]
    cmp x8, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, x8
    ldrb w13, [x5, #8]
.Lssa_http__parse_request_framed_2666:
    cmp x13, #32
    b.eq .Lssa_http__parse_request_framed_2661
.Lssa_http__parse_request_framed_2664:
    cmp x13, #9
    b.ne .Lssa_http__parse_request_framed_2523
.Lssa_http__parse_request_framed_2661:
    sub x14, x14, #1
    cmp x14, x9
    b.gt .Lssa_http__parse_request_framed_2667
.Lssa_http__parse_request_framed_2523:
    cmp x15, #0
    b.lt .Lssa_http__parse_request_framed_2518
.Lssa_http__parse_request_framed_2522:
    ldr x13, [x25, #16]
    ldr x6, [x13]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x15, #1
    ldr x8, [x13, x5, lsl #3]
    ldr x13, [x8, #8]
    sub x8, x14, x9
    sxtw x8, w8
    cmp x13, x8
    b.ne .Lssa_http__parse_request_framed_2518
.Lssa_http__parse_request_framed_2521:
    ldr x13, [x25, #16]
    ldr x6, [x13]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x15, #1
    ldr x8, [x13, x5, lsl #3]
    ldr x11, [x8, #8]
    mov x2, #0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x4, x11
    mov x3, x2
    mov x2, x8
    mov x1, x9
    mov x0, x19
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L185_aop
    mov x1, #0
.L185_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L185_bop
    mov x3, #0
.L185_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L185_nok
    mov x4, #0
.L185_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L185_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L185_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L185_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L185_done
.L185_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L185_vec
.L185_short:
    cmp x10, #8
    b.lt .L185_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L185_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L185_eq
    add x8, x8, x14
.L185_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L185_done
.L185_w4:
    cmp x10, #4
    b.lt .L185_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L185_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L185_eq
    add x8, x8, x14
.L185_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L185_done
.L185_w2:
    cmp x10, #2
    b.lt .L185_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L185_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L185_eq
    add x8, x8, x14
.L185_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L185_done
.L185_tail:
    cmp x8, x13
    b.ge .L185_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L185_th
    add x8, x8, #1
    add x9, x9, #1
    b .L185_tail
.L185_th:
    sub x2, x8, x12
    b .L185_done
.L185_eq:
    mov x2, x4
.L185_done:
    mov x0, x2
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    ldr x2, [x8, #8]
    cmp x0, x2
    b.ne .Lssa_http__parse_request_framed_2518
.Lssa_http__parse_request_framed_2520:
    ldr x6, [x13]
    cmp x15, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x15, #1
    ldr x2, [x13, x5, lsl #3]
    tbnz x2, #0, .Lssa_http__parse_request_framed_rcinc5136
    cmp x2, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc5136
    ldur w5, [x2, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc5136
    add w5, w5, #1
    stur w5, [x2, #-8]
.Lssa_http__parse_request_framed_rcinc5136:
    mov x0, x2
    mov x13, x2
    b .Lssa_http__parse_request_framed_2514
.Lssa_http__parse_request_framed_2518:
    adrp x2, .K8
    add x2, x2, :lo12:.K8
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x1, x9
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    cmp x1, #0
    b.ge .L186
    mov x1, #0
.L186:
    adrp x9, .S9
    add x9, x9, :lo12:.S9
    add x5, x0, x1
    add x6, x0, x3
    sub x8, x6, #16
    cmp x5, x8
    b.hi .L189
    ldp q20, q21, [x9]
    ldr q22, [x9, #32]
    movi v26.16b, #128
    movi v27.16b, #143
.L187:
    ldr q0, [x5]
    and v1.16b, v0.16b, v27.16b
    eor v2.16b, v0.16b, v26.16b
    and v2.16b, v2.16b, v27.16b
    tbl v1.16b, {v20.16b}, v1.16b
    tbl v2.16b, {v21.16b}, v2.16b
    orr v1.16b, v1.16b, v2.16b
    ushr v2.16b, v0.16b, #4
    tbl v2.16b, {v22.16b}, v2.16b
    cmtst v1.16b, v1.16b, v2.16b
    shrn v1.8b, v1.8h, #4
    fmov x7, d1
    cbnz x7, .L188
    add x5, x5, #16
    cmp x5, x8
    b.ls .L187
    sub x1, x5, x0
    b .L189
.L188:
    rbit x7, x7
    clz x7, x7
    lsr x7, x7, #2
    sub x1, x5, x0
    add x1, x1, x7
    b .L190
.L189:
    add x10, x9, #96
.L193:
    cmp x1, x3
    b.ge .L191
    ldrb w6, [x0, x1]
    ldrb w7, [x10, x6]
    cbnz w7, .L190
    add x1, x1, #1
    b .L193
.L190:
    str x1, [sp, #-16]!
    b .L192
.L191:
    str x3, [sp, #-16]!
.L192:
    ldr x0, [sp], #16
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    cmp x0, x14
    b.ge .Lssa_http__parse_request_framed_2516
.Lssa_http__parse_request_framed_2696:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x14, [sp, #32]
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x14, [sp, #32]
    b .Lssa_http__parse_request_framed_33
.Lssa_http__parse_request_framed_2516:
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x14, [sp, #-16]!
    str x9, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x13, x0
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
.Lssa_http__parse_request_framed_2700:
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    mov x0, x13
    bl __fn_utf8__is_valid.r
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    cbnz x0, .Lssa_http__parse_request_framed_2514
.Lssa_http__parse_request_framed_2703:
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    tbnz x13, #0, .Lssa_http__parse_request_framed_rcdeck5151
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5151
    ldur w5, [x13, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5151
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5151
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    mov x0, x13
    bl __fn___fern_str_free.u
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    b .Lssa_http__parse_request_framed_rcdece5151
.Lssa_http__parse_request_framed_rcdecd5151:
    sub w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_framed_rcdeck5151:
    mov x0, x13
.Lssa_http__parse_request_framed_rcdece5151:
    b .Lssa_http__parse_request_framed_33
.Lssa_http__parse_request_framed_2515:
.Lssa_http__parse_request_framed_2514:
    cbz x27, .Lssa_http__parse_request_framed_2506
.Lssa_http__parse_request_framed_2513:
    ldr x14, [x25, #8]
    ldr x6, [x14]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x11, [x14, x5, lsl #3]
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    mov x0, x19
    mov x9, x22
    mov x10, x26
    bl __fn_http____shared_string.r
    mov x14, x0
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    str x14, [sp, #32]
    ldr x6, [x14, #8]
    ldr x7, [x11, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn5170
    mov x0, x14
    mov x9, x11
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd5170
.Lssa_http__parse_request_framed_streqn5170:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd5170:
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    ldr x14, [sp, #32]
    cbz x0, .Lssa_http__parse_request_framed_2511
.Lssa_http__parse_request_framed_2512:
    ldr x11, [x25, #16]
    ldr x6, [x11]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x9, [x11, x5, lsl #3]
    str x10, [sp, #56]
    str x12, [sp, #48]
    str x13, [sp, #40]
    str x14, [sp, #32]
    ldr x6, [x13, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn5173
    mov x0, x13
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd5173
.Lssa_http__parse_request_framed_streqn5173:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd5173:
    ldr x10, [sp, #56]
    ldr x12, [sp, #48]
    ldr x13, [sp, #40]
    ldr x14, [sp, #32]
    mov x9, x0
    b .Lssa_http__parse_request_framed_2510
.Lssa_http__parse_request_framed_2511:
    mov x9, #0
.Lssa_http__parse_request_framed_2510:
    cbz x9, .Lssa_http__parse_request_framed_2716
.Lssa_http__parse_request_framed_2715:
    tbnz x14, #0, .Lssa_http__parse_request_framed_rcdeck5177
    cmp x14, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5177
    ldur w5, [x14, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5177
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5177
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    mov x0, x14
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    b .Lssa_http__parse_request_framed_rcdece5177
.Lssa_http__parse_request_framed_rcdecd5177:
    sub w5, w5, #1
    stur w5, [x14, #-8]
.Lssa_http__parse_request_framed_rcdeck5177:
    mov x0, x14
.Lssa_http__parse_request_framed_rcdece5177:
    tbnz x13, #0, .Lssa_http__parse_request_framed_rcdeck5178
    cmp x13, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5178
    ldur w5, [x13, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5178
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5178
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    mov x0, x13
    bl __fn___fern_str_free.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    b .Lssa_http__parse_request_framed_rcdece5178
.Lssa_http__parse_request_framed_rcdecd5178:
    sub w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_http__parse_request_framed_rcdeck5178:
    mov x0, x13
.Lssa_http__parse_request_framed_rcdece5178:
    b .Lssa_http__parse_request_framed_2507
.Lssa_http__parse_request_framed_2716:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x12, [sp, #40]
    str x13, [sp, #32]
    str x14, [sp, #24]
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x12, [sp, #40]
    ldr x13, [sp, #32]
    ldr x14, [sp, #24]
    b .Lssa_http__parse_request_framed_2508
.Lssa_http__parse_request_framed_2509:
    b .Lssa_http__parse_request_framed_2507
.Lssa_http__parse_request_framed_2508:
    tbnz x25, #0, .Lssa_http__parse_request_framed_rcinc5180
    cmp x25, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc5180
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc5180
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_http__parse_request_framed_rcinc5180:
    mov x0, x25
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x13, [sp, #40]
    str x14, [sp, #32]
    mov x0, x25
    mov x9, x12
    bl __fn_http____leading_fields.r
    mov x11, x0
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x13, [sp, #40]
    ldr x14, [sp, #32]
    tst x11, #1
    b.ne .Lssa_http__parse_request_framed_uq2508
    cmp x11, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq2508
    ldur w5, [x11, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq2508:
    b.ne .Lssa_http__parse_request_framed_2721
.Lssa_http__parse_request_framed_2720:
    mov x12, x11
    b .Lssa_http__parse_request_framed_2722
.Lssa_http__parse_request_framed_2721:
    mov x12, #0
.Lssa_http__parse_request_framed_2722:
    ldr x15, [x11, #8]
    cmp x12, #0
    b.ne .Lssa_http__parse_request_framed_2725
.Lssa_http__parse_request_framed_2723:
    tbnz x15, #0, .Lssa_http__parse_request_framed_rcinc5188
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc5188
    ldur w5, [x15, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc5188
    add w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_framed_rcinc5188:
    mov x0, x15
.Lssa_http__parse_request_framed_2725:
    tst x15, #1
    b.ne .Lssa_http__parse_request_framed_uq2725
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq2725
    ldur w5, [x15, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq2725:
    b.ne .Lssa_http__parse_request_framed_2727
.Lssa_http__parse_request_framed_2726:
    mov x0, x15
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5190s
.Lssa_http__parse_request_framed_apush5190o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5190e
.Lssa_http__parse_request_framed_apush5190s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
.Lssa_http__parse_request_framed_apush5190e:
    mov x8, x0
    b .Lssa_http__parse_request_framed_2728
.Lssa_http__parse_request_framed_2727:
    mov x0, x15
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5191s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush5191o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush5191s
.Lssa_http__parse_request_framed_apush5191o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5191e
.Lssa_http__parse_request_framed_apush5191s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
.Lssa_http__parse_request_framed_apush5191e:
    mov x8, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    mov x0, x15
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5193
    ldur w5, [x15, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5193
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5193
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x8, [sp, #16]
    mov x0, x15
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x8, [sp, #16]
    b .Lssa_http__parse_request_framed_rcdece5193
.Lssa_http__parse_request_framed_rcdecd5193:
    sub w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_framed_rcdeck5193:
    mov x0, x15
.Lssa_http__parse_request_framed_rcdece5193:
.Lssa_http__parse_request_framed_2728:
    ldr x15, [x11, #16]
    cmp x12, #0
    b.ne .Lssa_http__parse_request_framed_2731
.Lssa_http__parse_request_framed_2729:
    tbnz x15, #0, .Lssa_http__parse_request_framed_rcinc5198
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc5198
    ldur w5, [x15, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc5198
    add w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_framed_rcinc5198:
    mov x0, x15
.Lssa_http__parse_request_framed_2731:
    tst x15, #1
    b.ne .Lssa_http__parse_request_framed_uq2731
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq2731
    ldur w5, [x15, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq2731:
    b.ne .Lssa_http__parse_request_framed_2733
.Lssa_http__parse_request_framed_2732:
    mov x0, x15
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5200s
.Lssa_http__parse_request_framed_apush5200o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5200e
.Lssa_http__parse_request_framed_apush5200s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_framed_apush5200e:
    mov x14, x0
    b .Lssa_http__parse_request_framed_2734
.Lssa_http__parse_request_framed_2733:
    mov x0, x15
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5201s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush5201o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush5201s
.Lssa_http__parse_request_framed_apush5201o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5201e
.Lssa_http__parse_request_framed_apush5201s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x15, [sp, #16]
    str x8, [sp, #8]
    bl __fern_arr_push
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x15, [sp, #16]
    ldr x8, [sp, #8]
.Lssa_http__parse_request_framed_apush5201e:
    mov x14, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x15, [sp, #8]
    str x8, [sp, #0]
    mov x0, x15
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x15, [sp, #8]
    ldr x8, [sp, #0]
    cmp x15, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5203
    ldur w5, [x15, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5203
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5203
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x8, [sp, #8]
    mov x0, x15
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x8, [sp, #8]
    b .Lssa_http__parse_request_framed_rcdece5203
.Lssa_http__parse_request_framed_rcdecd5203:
    sub w5, w5, #1
    stur w5, [x15, #-8]
.Lssa_http__parse_request_framed_rcdeck5203:
    mov x0, x15
.Lssa_http__parse_request_framed_rcdece5203:
.Lssa_http__parse_request_framed_2734:
    cmp x12, #0
    b.ne .Lssa_http__parse_request_framed_2736
.Lssa_http__parse_request_framed_2735:
    mov x15, #3
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    str x13, [sp, #24]
    str x14, [sp, #16]
    str x8, [sp, #8]
    str x12, [sp, #-16]!
    str x15, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
    ldr x13, [sp, #24]
    ldr x14, [sp, #16]
    ldr x8, [sp, #8]
    adrp x15, .S0
    add x15, x15, :lo12:.S0
    str x15, [x0, #0]
    mov x15, x0
    b .Lssa_http__parse_request_framed_2737
.Lssa_http__parse_request_framed_2736:
    mov x15, x12
.Lssa_http__parse_request_framed_2737:
    cmp x12, #0
    b.ne .Lssa_http__parse_request_framed_2740
.Lssa_http__parse_request_framed_2739:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x13, [sp, #40]
    str x14, [sp, #32]
    str x15, [sp, #24]
    str x8, [sp, #16]
    mov x0, x11
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x13, [sp, #40]
    ldr x14, [sp, #32]
    ldr x15, [sp, #24]
    ldr x8, [sp, #16]
.Lssa_http__parse_request_framed_2740:
    str x8, [x15, #8]
    str x14, [x15, #16]
    mov x28, x15
.Lssa_http__parse_request_framed_2507:
    mov x27, x9
    b .Lssa_http__parse_request_framed_2504
.Lssa_http__parse_request_framed_2506:
    str x10, [sp, #56]
    str x13, [sp, #48]
    str x26, [sp, #-16]!
    str x22, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_string_from_bytes_range_u8
    add sp, sp, #48
    mov x9, x0
    ldr x10, [sp, #56]
    ldr x13, [sp, #48]
.Lssa_http__parse_request_framed_2742:
    tst x28, #1
    b.ne .Lssa_http__parse_request_framed_uq2742
    cmp x28, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq2742
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq2742:
    b.ne .Lssa_http__parse_request_framed_2745
.Lssa_http__parse_request_framed_2744:
    mov x26, x28
    b .Lssa_http__parse_request_framed_2746
.Lssa_http__parse_request_framed_2745:
    mov x26, #0
.Lssa_http__parse_request_framed_2746:
    ldr x22, [x28, #8]
    cmp x26, #0
    b.ne .Lssa_http__parse_request_framed_2749
.Lssa_http__parse_request_framed_2747:
    tbnz x22, #0, .Lssa_http__parse_request_framed_rcinc5234
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc5234
    ldur w5, [x22, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc5234
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_framed_rcinc5234:
    mov x0, x22
.Lssa_http__parse_request_framed_2749:
    tst x22, #1
    b.ne .Lssa_http__parse_request_framed_uq2749
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq2749
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq2749:
    b.ne .Lssa_http__parse_request_framed_2751
.Lssa_http__parse_request_framed_2750:
    mov x0, x22
    mov x1, x9
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5236s
.Lssa_http__parse_request_framed_apush5236o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5236e
.Lssa_http__parse_request_framed_apush5236s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x13, [sp, #40]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x13, [sp, #40]
.Lssa_http__parse_request_framed_apush5236e:
    mov x22, x0
    b .Lssa_http__parse_request_framed_2752
.Lssa_http__parse_request_framed_2751:
    mov x0, x22
    mov x1, x9
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5237s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush5237o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush5237s
.Lssa_http__parse_request_framed_apush5237o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5237e
.Lssa_http__parse_request_framed_apush5237s:
    str x10, [sp, #56]
    str x13, [sp, #48]
    bl __fern_arr_push
    ldr x10, [sp, #56]
    ldr x13, [sp, #48]
.Lssa_http__parse_request_framed_apush5237e:
    mov x11, x0
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x13, [sp, #40]
    mov x0, x22
    bl __fn___fern_arr_inc_elems.r
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x13, [sp, #40]
    cmp x22, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5239
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5239
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5239
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x13, [sp, #40]
    mov x0, x22
    bl __fn___fern_arr_dec.u
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x13, [sp, #40]
    b .Lssa_http__parse_request_framed_rcdece5239
.Lssa_http__parse_request_framed_rcdecd5239:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_http__parse_request_framed_rcdeck5239:
    mov x0, x22
.Lssa_http__parse_request_framed_rcdece5239:
    mov x22, x11
.Lssa_http__parse_request_framed_2752:
    ldr x11, [x28, #16]
    cmp x26, #0
    b.ne .Lssa_http__parse_request_framed_2755
.Lssa_http__parse_request_framed_2753:
    tbnz x11, #0, .Lssa_http__parse_request_framed_rcinc5244
    cmp x11, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcinc5244
    ldur w5, [x11, #-8]
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcinc5244
    add w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_http__parse_request_framed_rcinc5244:
    mov x0, x11
.Lssa_http__parse_request_framed_2755:
    tst x11, #1
    b.ne .Lssa_http__parse_request_framed_uq2755
    cmp x11, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_uq2755
    ldur w5, [x11, #-8]
    cmp w5, #1
.Lssa_http__parse_request_framed_uq2755:
    b.ne .Lssa_http__parse_request_framed_2757
.Lssa_http__parse_request_framed_2756:
    mov x0, x11
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5246s
.Lssa_http__parse_request_framed_apush5246o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5246e
.Lssa_http__parse_request_framed_apush5246s:
    str x10, [sp, #56]
    str x11, [sp, #48]
    str x13, [sp, #40]
    bl __fern_arr_push_owned
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
    ldr x13, [sp, #40]
.Lssa_http__parse_request_framed_apush5246e:
    mov x9, x0
    b .Lssa_http__parse_request_framed_2758
.Lssa_http__parse_request_framed_2757:
    mov x0, x11
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_http__parse_request_framed_apush5247s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_http__parse_request_framed_apush5247o
    tbz w3, #31, .Lssa_http__parse_request_framed_apush5247s
.Lssa_http__parse_request_framed_apush5247o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_http__parse_request_framed_apush5247e
.Lssa_http__parse_request_framed_apush5247s:
    str x10, [sp, #56]
    str x11, [sp, #48]
    bl __fern_arr_push
    ldr x10, [sp, #56]
    ldr x11, [sp, #48]
.Lssa_http__parse_request_framed_apush5247e:
    mov x9, x0
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    mov x0, x11
    bl __fn___fern_arr_inc_elems.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    cmp x11, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5249
    ldur w5, [x11, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5249
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5249
    str x9, [sp, #56]
    str x10, [sp, #48]
    mov x0, x11
    bl __fn___fern_arr_dec.u
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    b .Lssa_http__parse_request_framed_rcdece5249
.Lssa_http__parse_request_framed_rcdecd5249:
    sub w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_http__parse_request_framed_rcdeck5249:
    mov x0, x11
.Lssa_http__parse_request_framed_rcdece5249:
.Lssa_http__parse_request_framed_2758:
    cmp x26, #0
    b.ne .Lssa_http__parse_request_framed_2760
.Lssa_http__parse_request_framed_2759:
    mov x11, #3
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x26, [sp, #-16]!
    str x11, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    adrp x11, .S0
    add x11, x11, :lo12:.S0
    str x11, [x0, #0]
    mov x13, x0
    b .Lssa_http__parse_request_framed_2761
.Lssa_http__parse_request_framed_2760:
    mov x13, x26
.Lssa_http__parse_request_framed_2761:
    cmp x26, #0
    b.ne .Lssa_http__parse_request_framed_2764
.Lssa_http__parse_request_framed_2763:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x13, [sp, #40]
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x13, [sp, #40]
.Lssa_http__parse_request_framed_2764:
    str x22, [x13, #8]
    str x9, [x13, #16]
    mov x28, x13
.Lssa_http__parse_request_framed_2505:
.Lssa_http__parse_request_framed_2504:
    add x10, x10, #2
    sxtw x22, w10
    cmp x22, x21
    b.lt .Lssa_http__parse_request_framed_2558
.Lssa_http__parse_request_framed_61:
    cbz x27, .Lssa_http__parse_request_framed_41
.Lssa_http__parse_request_framed_60:
    ldr x10, [x25, #8]
    ldr x11, [x10, #0]
    cmp x23, x11
    b.ne .Lssa_http__parse_request_framed_41
.Lssa_http__parse_request_framed_2771:
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_59:
    mov x28, x25
    b .Lssa_http__parse_request_framed_38
.Lssa_http__parse_request_framed_58:
    b .Lssa_http__parse_request_framed_37
.Lssa_http__parse_request_framed_54:
    mov x11, #400
.Lssa_http__parse_request_framed_53:
.Lssa_http__parse_request_framed_52:
.Lssa_http__parse_request_framed_50:
    cmp x11, #1
    b.ne .Lssa_http__parse_request_framed_48
.Lssa_http__parse_request_framed_49:
    mov x10, #0
    mov x22, #0
    mov x11, #1
    mov x26, #0
    b .Lssa_http__parse_request_framed_47
.Lssa_http__parse_request_framed_48:
    mov x22, x11
    mov x10, #0
    mov x11, #0
    mov x26, #0
.Lssa_http__parse_request_framed_47:
    cbnz x10, .Lssa_http__parse_request_framed_2
.Lssa_http__parse_request_framed_46:
    cbz x11, .Lssa_http__parse_request_framed_3
.Lssa_http__parse_request_framed_45:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_framed_44:
    mov x11, #400
    b .Lssa_http__parse_request_framed_31
.Lssa_http__parse_request_framed_43:
    mov x11, #431
    b .Lssa_http__parse_request_framed_31
.Lssa_http__parse_request_framed_41:
    cbz x27, .Lssa_http__parse_request_framed_38
.Lssa_http__parse_request_framed_2793:
    mov x0, x28
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_40:
    mov x0, x25
    mov x9, x23
    bl __fn_http____leading_fields.r
    mov x28, x0
.Lssa_http__parse_request_framed_39:
.Lssa_http__parse_request_framed_38:
    str x28, [sp, #136]
.Lssa_http__parse_request_framed_37:
    add x21, x21, #4
    sxtw x21, w21
    mov x11, #2
    b .Lssa_http__parse_request_framed_30
.Lssa_http__parse_request_framed_33:
    mov x11, #400
.Lssa_http__parse_request_framed_32:
.Lssa_http__parse_request_framed_31:
    mov x21, #0
.Lssa_http__parse_request_framed_30:
    mov x28, x21
    mov x21, x11
.Lssa_http__parse_request_framed_29:
    b .Lssa_http__parse_request_framed_pool_2733
    .ltorg
.Lssa_http__parse_request_framed_pool_2733:
    cmp x21, #2
    b.eq .Lssa_http__parse_request_framed_26
.Lssa_http__parse_request_framed_2800:
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5342
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5342
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5342
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece5342
.Lssa_http__parse_request_framed_rcdecd5342:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_framed_rcdeck5342:
    mov x0, x24
.Lssa_http__parse_request_framed_rcdece5342:
    ldr x0, [sp, #136]
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_28:
    ldr x23, [sp, #112]
    ldr x5, [sp, #104]
    str x5, [sp, #136]
    mov x28, #0
    b .Lssa_http__parse_request_framed_20
.Lssa_http__parse_request_framed_26:
.Lssa_http__parse_request_framed_25:
.Lssa_http__parse_request_framed_24:
    mov x11, #0
    mov x10, #1
.Lssa_http__parse_request_framed_2805:
    ldr x13, [x24, #0]
    cmp x10, x13
    b.ge .Lssa_http__parse_request_framed_23
.Lssa_http__parse_request_framed_2806:
    add x5, x10, #1
    ldr x13, [x24, x5, lsl #3]
    add x13, x11, x13
    sxtw x11, w13
    add x10, x10, #2
    sxtw x10, w10
    b .Lssa_http__parse_request_framed_2805
.Lssa_http__parse_request_framed_23:
    mov x0, x11
    bl __fern_alloc_bytes
.Lssa_http__parse_request_framed_22:
    mov x23, x0
    mov x21, #0
    mov x25, #0
.Lssa_http__parse_request_framed_2813:
    add x11, x21, #1
    sxtw x11, w11
    ldr x10, [x24, #0]
    cmp x11, x10
    b.lt .Lssa_http__parse_request_framed_2814
.Lssa_http__parse_request_framed_2816:
    cmp x24, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5386
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5386
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5386
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece5386
.Lssa_http__parse_request_framed_rcdecd5386:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_http__parse_request_framed_rcdeck5386:
    mov x0, x24
.Lssa_http__parse_request_framed_rcdece5386:
    b .Lssa_http__parse_request_framed_21
.Lssa_http__parse_request_framed_2814:
    add x11, x21, #1
    sxtw x27, w11
    asr x11, x21, #31
    orr x11, x27, x11
    ldr x6, [x24]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x10, [x24, x5, lsl #3]
    add x5, x27, #1
    ldr x11, [x24, x5, lsl #3]
    str x23, [sp, #-16]!
    str x25, [sp, #-16]!
    str x19, [sp, #-16]!
    str x10, [sp, #-16]!
    str x11, [sp, #-16]!
    bl __fn___fern_bytes_into
    add sp, sp, #80
    mov x23, x0
    ldr x6, [x24]
    cmp x27, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x27, #1
    ldr x11, [x24, x5, lsl #3]
    add x25, x25, x11
    sxtw x25, w25
    add x21, x21, #2
    sxtw x21, w21
    b .Lssa_http__parse_request_framed_2813
.Lssa_http__parse_request_framed_21:
    mov x21, #2
.Lssa_http__parse_request_framed_20:
    cmp x21, #2
    b.eq .Lssa_http__parse_request_framed_15
.Lssa_http__parse_request_framed_2821:
    ldr x4, [sp, #64]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck5420
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5420
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5420
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5420
    ldr x0, [sp, #64]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece5420
.Lssa_http__parse_request_framed_rcdecd5420:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck5420:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece5420:
    ldr x4, [sp, #96]
    tbnz x4, #0, .Lssa_http__parse_request_framed_rcdeck5421
    cmp x4, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5421
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5421
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5421
    ldr x0, [sp, #96]
    bl __fn___fern_str_free.u
    b .Lssa_http__parse_request_framed_rcdece5421
.Lssa_http__parse_request_framed_rcdecd5421:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_http__parse_request_framed_rcdeck5421:
    mov x0, x4
.Lssa_http__parse_request_framed_rcdece5421:
    cmp x23, #16, lsl #12
    b.lo .Lssa_http__parse_request_framed_rcdeck5422
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_http__parse_request_framed_rcdecd5422
    tbnz w5, #31, .Lssa_http__parse_request_framed_rcdeck5422
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_http__parse_request_framed_rcdece5422
.Lssa_http__parse_request_framed_rcdecd5422:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_http__parse_request_framed_rcdeck5422:
    mov x0, x23
.Lssa_http__parse_request_framed_rcdece5422:
    ldr x0, [sp, #136]
    bl __fn___sem_release_HeaderMap.r
    mov x0, x20
    bl __fn___sem_release_HeaderMap.r
.Lssa_http__parse_request_framed_18:
    cmp x21, #400
    b.lt .Lssa_http__parse_request_framed_13
.Lssa_http__parse_request_framed_17:
    mov x10, #0
    mov x11, #0
    mov x13, #0
    b .Lssa_http__parse_request_framed_9
.Lssa_http__parse_request_framed_15:
    adrp x21, .K9
    add x21, x21, :lo12:.K9
    mov x25, #0
    mov x0, #4
    bl __fern_arr_box
    mov x24, x0
    adrp x11, .S22
    add x11, x11, :lo12:.S22
    str x11, [x24, #0]
    str x23, [x24, #8]
    str x25, [x24, #16]
    str x21, [x24, #24]
    mov x0, #6
    bl __fern_arr_box
    mov x21, x0
    adrp x10, .S23
    add x10, x10, :lo12:.S23
    str x10, [x21, #0]
    ldr x5, [sp, #64]
    str x5, [x21, #8]
    ldr x5, [sp, #96]
    str x5, [x21, #16]
    str x24, [x21, #24]
    str x20, [x21, #32]
    ldr x5, [sp, #136]
    str x5, [x21, #40]
    mov x0, #5
    bl __fern_arr_box
    adrp x11, .S24
    add x11, x11, :lo12:.S24
    str x11, [x0, #0]
    str x21, [x0, #8]
    str x28, [x0, #16]
    ldr x5, [sp, #120]
    str x5, [x0, #24]
    ldr x5, [sp, #80]
    str x5, [x0, #32]
    mov x1, x0
    mov x10, x1
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_framed_13:
    adrp x10, .SB10
    add x10, x10, :lo12:.SB10
    ldr x4, [sp, #80]
    ldr x11, [x4, #8]
    cmp x11, #8
    b.ne .Lssa_http__parse_request_framed_2831
.Lssa_http__parse_request_framed_2830:
    ldr x4, [sp, #80]
    ldr x6, [x4, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_http__parse_request_framed_streqn5457
    ldr x6, [x4]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_http__parse_request_framed_streqn5457
    ldr x0, [sp, #80]
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_http__parse_request_framed_streqd5457
.Lssa_http__parse_request_framed_streqn5457:
    mov x0, #0
.Lssa_http__parse_request_framed_streqd5457:
    b .Lssa_http__parse_request_framed_2832
.Lssa_http__parse_request_framed_2831:
    mov x0, #0
.Lssa_http__parse_request_framed_2832:
    cbnz x0, .Lssa_http__parse_request_framed_10
.Lssa_http__parse_request_framed_12:
    ldr x4, [sp, #72]
    cmp x4, #1
    b.ne .Lssa_http__parse_request_framed_10
.Lssa_http__parse_request_framed_11:
    mov x10, #0
    mov x21, #0
    mov x11, #0
    mov x13, #1
    b .Lssa_http__parse_request_framed_9
.Lssa_http__parse_request_framed_10:
    mov x10, #0
    mov x21, #0
    mov x11, #1
    mov x13, #0
.Lssa_http__parse_request_framed_9:
    cbnz x10, .Lssa_http__parse_request_framed_2
.Lssa_http__parse_request_framed_8:
    cbz x11, .Lssa_http__parse_request_framed_6
.Lssa_http__parse_request_framed_7:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_framed_6:
    cbz x13, .Lssa_http__parse_request_framed_4
.Lssa_http__parse_request_framed_5:
    mov x0, #2
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_framed_4:
    mov x1, x21
    mov x0, x1
    mov x0, #3
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_framed_3:
    cbz x26, .Lssa_http__parse_request_framed_1
.Lssa_http__parse_request_framed_2:
    mov x13, #134
    mov x0, x13
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http__parse_request_framed_1:
    mov x1, x22
    mov x0, x1
    mov x0, #3
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____absolute_form_path:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____absolute_form_path.k:
__fn_http____absolute_form_path.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_http____absolute_form_path_0:
    mov x9, #2
    and x9, x19, x9
    cbz x9, .Lssa_http____absolute_form_path_2
.Lssa_http____absolute_form_path_1:
    mov x9, #-2
    add x9, x19, x9
    ldr x10, [x9, #0]
    ldr x11, [x9, #8]
    mov x22, x10
    mov x23, x11
    b .Lssa_http____absolute_form_path_3
.Lssa_http____absolute_form_path_2:
    add x11, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____absolute_form_path_5
.Lssa_http____absolute_form_path_4:
    ldr x10, [x19, #0]
    b .Lssa_http____absolute_form_path_6
.Lssa_http____absolute_form_path_5:
    mov x10, #0
.Lssa_http____absolute_form_path_6:
    mov x22, x11
    mov x23, x10
.Lssa_http____absolute_form_path_3:
    mov x24, #-1
    adrp x11, .SB25
    add x11, x11, :lo12:.SB25
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_18
.Lssa_http____absolute_form_path_20:
    add x11, x20, #7
    sxtw x11, w11
    mov x24, x11
.Lssa_http____absolute_form_path_19:
.Lssa_http____absolute_form_path_18:
    adrp x11, .SB26
    add x11, x11, :lo12:.SB26
    mov x0, x19
    mov x9, x20
    mov x10, x21
    bl __fn_http____prefix_ci.r
    cbz x0, .Lssa_http____absolute_form_path_15
.Lssa_http____absolute_form_path_17:
    add x20, x20, #8
    sxtw x20, w20
    mov x24, x20
.Lssa_http____absolute_form_path_16:
.Lssa_http____absolute_form_path_15:
    cmp x24, #0
    b.ge .Lssa_http____absolute_form_path_12
.Lssa_http____absolute_form_path_14:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_12:
    mov x20, x24
.Lssa_http____absolute_form_path_35:
    cmp x20, x21
    b.ge .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_40:
    mov w11, w20
    cmp x11, x23
    b.lo .Lssa_http____absolute_form_path_47
.Lssa_http____absolute_form_path_45:
    bl __fern_oob_abort
    mov x10, x0
.Lssa_http____absolute_form_path_47:
    ldrb w0, [x22, x11]
    cmp x0, #47
    b.eq .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_39:
    cmp x0, #63
    b.eq .Lssa_http____absolute_form_path_11
.Lssa_http____absolute_form_path_38:
    bl __fn_http____is_pchar.r
    cbz x0, .Lssa_http____absolute_form_path_9
.Lssa_http____absolute_form_path_36:
    add x20, x20, #1
    cmp x20, x21
    b.lt .Lssa_http____absolute_form_path_40
.Lssa_http____absolute_form_path_11:
    mov x11, #-1
    cmp x20, x24
    csel x0, x11, x20, eq
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____absolute_form_path_9:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____prefix_ci:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_http____prefix_ci.k:
__fn_http____prefix_ci.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____prefix_ci_0:
    mov x12, #2
    and x12, x0, x12
    cbz x12, .Lssa_http____prefix_ci_2
.Lssa_http____prefix_ci_1:
    mov x12, #-2
    add x12, x0, x12
    ldr x13, [x12, #0]
    ldr x14, [x12, #8]
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_2:
    add x14, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____prefix_ci_5
.Lssa_http____prefix_ci_4:
    ldr x13, [x0, #0]
    b .Lssa_http____prefix_ci_3
.Lssa_http____prefix_ci_5:
    mov x13, #0
.Lssa_http____prefix_ci_6:
.Lssa_http____prefix_ci_3:
    sub x10, x10, x9
    sxtw x10, w10
    ldr x12, [x11, #8]
    cmp x10, x12
    b.ge .Lssa_http____prefix_ci_10
.Lssa_http____prefix_ci_12:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_10:
.Lssa_http____prefix_ci_9:
    ldr x10, [x11, #8]
    ldr x12, [x11, #0]
    mov x11, #0
.Lssa_http____prefix_ci_17:
    cmp x11, x10
    b.ge .Lssa_http____prefix_ci_8
.Lssa_http____prefix_ci_25:
    add w15, w9, w11
    cmp x15, x13
    b.lo .Lssa_http____prefix_ci_32
.Lssa_http____prefix_ci_30:
    bl __fern_oob_abort
    mov x1, x0
.Lssa_http____prefix_ci_32:
    ldrb w1, [x14, x15]
.Lssa_http____prefix_ci_24:
    cmp x1, #65
    b.lt .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_23:
    cmp x1, #90
    b.gt .Lssa_http____prefix_ci_20
.Lssa_http____prefix_ci_22:
    add x15, x1, #32
    sxtw x15, w15
    mov x1, x15
.Lssa_http____prefix_ci_21:
.Lssa_http____prefix_ci_20:
    ldrb w15, [x12, x11]
    cmp x1, x15
    b.ne .Lssa_http____prefix_ci_7
.Lssa_http____prefix_ci_18:
    add x11, x11, #1
    cmp x11, x10
    b.lt .Lssa_http____prefix_ci_25
.Lssa_http____prefix_ci_8:
    mov x0, #1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____prefix_ci_7:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____is_pchar:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_http____is_pchar.k:
__fn_http____is_pchar.r:
.Lssa_http____is_pchar_0:
.Lssa_http____is_pchar_46:
    cmp x0, #97
    b.lt .Lssa_http____is_pchar_41
.Lssa_http____is_pchar_45:
    cmp x0, #122
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_41:
    cmp x0, #65
    b.lt .Lssa_http____is_pchar_35
.Lssa_http____is_pchar_40:
    cmp x0, #90
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_35:
    cmp x0, #48
    b.lt .Lssa_http____is_pchar_29
.Lssa_http____is_pchar_34:
    cmp x0, #57
    b.le .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_29:
    cmp x0, #45
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_26:
    cmp x0, #46
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_23:
    cmp x0, #95
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_20:
    cmp x0, #126
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_15:
    adrp x9, .SB27
    add x9, x9, :lo12:.SB27
.Lssa_http____is_pchar_14:
    ldr x10, [x9, #8]
    ldr x11, [x9, #0]
    mov x9, #0
.Lssa_http____is_pchar_97:
    cmp x9, x10
    b.ge .Lssa_http____is_pchar_8
.Lssa_http____is_pchar_100:
    ldrb w12, [x11, x9]
    cmp x12, x0
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_98:
    add x9, x9, #1
    cmp x9, x10
    b.lt .Lssa_http____is_pchar_100
.Lssa_http____is_pchar_8:
    cmp x0, #58
    b.eq .Lssa_http____is_pchar_3
.Lssa_http____is_pchar_5:
    cmp x0, #64
    b.ne .Lssa_http____is_pchar_2
.Lssa_http____is_pchar_3:
    mov x0, #1
    b .Lssa_http____is_pchar_1
.Lssa_http____is_pchar_2:
    cmp x0, #37
    cset x0, eq
.Lssa_http____is_pchar_1:
    ret
    .cfi_endproc
    .ltorg
__fn_http____query_ok:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____query_ok.k:
__fn_http____query_ok.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x10
.Lssa_http____query_ok_0:
    mov x10, #2
    and x10, x19, x10
    cbz x10, .Lssa_http____query_ok_2
.Lssa_http____query_ok_1:
    mov x10, #-2
    add x10, x19, x10
    ldr x11, [x10, #0]
    ldr x12, [x10, #8]
    mov x21, x11
    mov x22, x12
    b .Lssa_http____query_ok_10
.Lssa_http____query_ok_2:
    add x12, x19, #8
    cmp x19, #0
    b.eq .Lssa_http____query_ok_5
.Lssa_http____query_ok_4:
    ldr x11, [x19, #0]
    b .Lssa_http____query_ok_6
.Lssa_http____query_ok_5:
    mov x11, #0
.Lssa_http____query_ok_6:
    mov x21, x12
    mov x22, x11
.Lssa_http____query_ok_3:
.Lssa_http____query_ok_10:
    mov x23, x9
.Lssa_http____query_ok_11:
    cmp x23, x20
    b.ge .Lssa_http____query_ok_9
.Lssa_http____query_ok_21:
    mov w9, w23
    cmp x9, x22
    b.lo .Lssa_http____query_ok_28
.Lssa_http____query_ok_26:
    bl __fern_oob_abort
    mov x11, x0
.Lssa_http____query_ok_28:
    ldrb w24, [x21, x9]
    cmp x24, #37
    b.ne .Lssa_http____query_ok_17
.Lssa_http____query_ok_20:
    mov x0, x19
    mov x9, x23
    mov x10, x20
    bl __fn_http____pct_byte.r
    cmp x0, #0
    b.lt .Lssa_http____query_ok_8
.Lssa_http____query_ok_18:
    add x9, x23, #3
    sxtw x9, w9
    mov x23, x9
    b .Lssa_http____query_ok_11
.Lssa_http____query_ok_17:
    mov x0, x24
    bl __fn_http____is_pchar.r
    cbnz x0, .Lssa_http____query_ok_13
.Lssa_http____query_ok_16:
    cmp x24, #47
    b.eq .Lssa_http____query_ok_13
.Lssa_http____query_ok_15:
    cmp x24, #63
    b.ne .Lssa_http____query_ok_7
.Lssa_http____query_ok_13:
    add x23, x23, #1
.Lssa_http____query_ok_12:
    cmp x23, x20
    b.lt .Lssa_http____query_ok_21
.Lssa_http____query_ok_9:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_8:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____query_ok_7:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____pct_byte:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_http____pct_byte.k:
__fn_http____pct_byte.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_http____pct_byte_0:
    mov x11, #2
    and x11, x0, x11
    cbz x11, .Lssa_http____pct_byte_2
.Lssa_http____pct_byte_1:
    mov x11, #-2
    add x11, x0, x11
    ldr x12, [x11, #0]
    ldr x13, [x11, #8]
    mov x4, x12
    mov x12, x13
    mov x13, x4
    b .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_2:
    add x13, x0, #8
    cmp x0, #0
    b.eq .Lssa_http____pct_byte_5
.Lssa_http____pct_byte_4:
    ldr x12, [x0, #0]
    b .Lssa_http____pct_byte_3
.Lssa_http____pct_byte_5:
    mov x12, #0
.Lssa_http____pct_byte_6:
.Lssa_http____pct_byte_3:
    add x11, x9, #2
    sxtw x11, w11
    cmp x11, x10
    b.lt .Lssa_http____pct_byte_39
.Lssa_http____pct_byte_41:
    mov x0, #-1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_39:
    add w11, w9, #1
    cmp x11, x12
    b.lo .Lssa_http____pct_byte_48
.Lssa_http____pct_byte_46:
    bl __fern_oob_abort
    mov x10, x0
.Lssa_http____pct_byte_48:
    ldrb w10, [x13, x11]
.Lssa_http____pct_byte_38:
    cmp x10, #48
    b.lo .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_37:
    cmp x10, #57
    b.hi .Lssa_http____pct_byte_34
.Lssa_http____pct_byte_36:
    sub x11, x10, #48
    sxtw x11, w11
    mov x10, x11
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_34:
    cmp x10, #97
    b.lo .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_33:
    cmp x10, #102
    b.hi .Lssa_http____pct_byte_30
.Lssa_http____pct_byte_32:
    sub x11, x10, #87
    sxtw x11, w11
    mov x10, x11
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_30:
    cmp x10, #65
    b.lo .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_29:
    cmp x10, #70
    b.hi .Lssa_http____pct_byte_26
.Lssa_http____pct_byte_28:
    sub x10, x10, #55
    sxtw x10, w10
    b .Lssa_http____pct_byte_25
.Lssa_http____pct_byte_26:
    mov x10, #-1
.Lssa_http____pct_byte_25:
    add w9, w9, #2
    cmp x9, x12
    b.lo .Lssa_http____pct_byte_78
.Lssa_http____pct_byte_76:
    bl __fern_oob_abort
    mov x12, x0
.Lssa_http____pct_byte_78:
    ldrb w12, [x13, x9]
.Lssa_http____pct_byte_24:
    cmp x12, #48
    b.lo .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_23:
    cmp x12, #57
    b.hi .Lssa_http____pct_byte_20
.Lssa_http____pct_byte_22:
    sub x9, x12, #48
    sxtw x9, w9
    mov x12, x9
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_20:
    cmp x12, #97
    b.lo .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_19:
    cmp x12, #102
    b.hi .Lssa_http____pct_byte_16
.Lssa_http____pct_byte_18:
    sub x9, x12, #87
    sxtw x9, w9
    mov x12, x9
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_16:
    cmp x12, #65
    b.lo .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_15:
    cmp x12, #70
    b.hi .Lssa_http____pct_byte_12
.Lssa_http____pct_byte_14:
    sub x12, x12, #55
    sxtw x12, w12
    b .Lssa_http____pct_byte_11
.Lssa_http____pct_byte_12:
    mov x12, #-1
.Lssa_http____pct_byte_11:
    cmp x10, #0
    b.lt .Lssa_http____pct_byte_9
.Lssa_http____pct_byte_10:
    cmp x12, #0
    b.ge .Lssa_http____pct_byte_7
.Lssa_http____pct_byte_9:
    mov x0, #-1
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____pct_byte_7:
    lsl x10, x10, #4
    add x10, x10, x12
    sxtw x0, w10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_http____lists_token:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_http____lists_token.k:
__fn_http____lists_token.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_http____lists_token_0:
    ldr x21, [x19, #8]
.Lssa_http____lists_token_3:
    mov x9, #0
.Lssa_http____lists_token_4:
    cmp x9, x21
    b.gt .Lssa_http____lists_token_2
.Lssa_http____lists_token_8:
    mov x22, x9
.Lssa_http____lists_token_14:
    cmp x22, x21
    b.ge .Lssa_http____lists_token_7
.Lssa_http____lists_token_16:
    ldr x6, [x19, #8]
    cmp x22, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x22]
    cmp x10, #44
    b.eq .Lssa_http____lists_token_7
.Lssa_http____lists_token_15:
    add x22, x22, #1
    cmp x22, x21
    b.lt .Lssa_http____lists_token_16
.Lssa_http____lists_token_7:
    mov x0, x19
    mov x10, x22
    mov x11, x20
    bl __fn_http____token_at.r
    cbnz x0, .Lssa_http____lists_token_1
.Lssa_http____lists_token_5:
    add x22, x22, #1
    sxtw x9, w22
    cmp x9, x21
    b.le .Lssa_http____lists_token_8
.Lssa_http____lists_token_2:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_http____lists_token_1:
    mov x0, #1
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___map_fnv_str_seeded:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___map_fnv_str_seeded.k:
__fn___map_fnv_str_seeded.r:
.Lssa___map_fnv_str_seeded_0:
    ldr x10, =2166136261
    mov w9, w9
    eor x10, x10, x9
    ldr x9, =16777619
    ldr x11, [x0, #8]
.Lssa___map_fnv_str_seeded_4:
    mov x12, #0
.Lssa___map_fnv_str_seeded_5:
    add x13, x12, #4
    sxtw x13, w13
    cmp x13, x11
    b.gt .Lssa___map_fnv_str_seeded_13
.Lssa___map_fnv_str_seeded_6:
    add x13, x12, #3
    sxtw x13, w13
    asr x14, x12, #31
    orr x13, x13, x14
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x14, [x0, #0]
    add x14, x14, x12
    ldrsw x14, [x14]
    eor x14, x10, x14
    ldr x13, =16777619
    mul w10, w14, w13
    add x14, x12, #4
    sxtw x12, w14
    b .Lssa___map_fnv_str_seeded_5
.Lssa___map_fnv_str_seeded_2:
.Lssa___map_fnv_str_seeded_13:
    cmp x12, x11
    b.ge .Lssa___map_fnv_str_seeded_1
.Lssa___map_fnv_str_seeded_14:
    ldr x6, [x0, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x12]
    eor x14, x10, x14
    mul w10, w14, w9
    add x12, x12, #1
    cmp x12, x11
    b.lt .Lssa___map_fnv_str_seeded_14
.Lssa___map_fnv_str_seeded_1:
    lsr x12, x10, #16
    eor x10, x10, x12
    ldr x12, =2246822507
    mul w10, w10, w12
    lsr x12, x10, #13
    eor x10, x10, x12
    ldr x12, =3266489909
    mul w10, w10, w12
    lsr x12, x10, #16
    eor x10, x10, x12
    sxtw x0, w10
    ret
    .cfi_endproc
    .ltorg
__fn_string____str_maxsuf:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_maxsuf.k:
__fn_string____str_maxsuf.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
.Lssa_string____str_maxsuf_0:
    mov x13, #-1
.Lssa_string____str_maxsuf_2:
    mov x19, x13
    mov x13, #0
    mov x14, #1
    mov x15, #1
.Lssa_string____str_maxsuf_3:
    add x1, x13, x14
    sxtw x1, w1
    cmp x1, x9
    b.ge .Lssa_string____str_maxsuf_1
.Lssa_string____str_maxsuf_16:
    add x1, x13, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w2, [x6, x1]
    add x1, x19, x14
    mul x1, x12, x1
    add w1, w11, w1
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x0]
    ldrb w3, [x6, x1]
    cmp x10, #0
    csel x1, x3, x2, ne
    cmp x10, #0
    csel x2, x2, x3, ne
.Lssa_string____str_maxsuf_13:
    cmp x1, x2
    b.ge .Lssa_string____str_maxsuf_11
.Lssa_string____str_maxsuf_12:
    add x3, x13, x14
    sxtw x3, w3
    sub x8, x3, x19
    sxtw x8, w8
    mov x13, x3
    mov x15, x8
    mov x14, #1
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_11:
    cmp x1, x2
    b.ne .Lssa_string____str_maxsuf_6
.Lssa_string____str_maxsuf_10:
    cmp x14, x15
    b.ne .Lssa_string____str_maxsuf_8
.Lssa_string____str_maxsuf_9:
    add x1, x13, x15
    sxtw x1, w1
    mov x13, x1
    mov x14, #1
    b .Lssa_string____str_maxsuf_7
.Lssa_string____str_maxsuf_8:
    add x14, x14, #1
    sxtw x14, w14
.Lssa_string____str_maxsuf_7:
    mov x4, x13
    mov x13, x14
    mov x14, x4
    b .Lssa_string____str_maxsuf_5
.Lssa_string____str_maxsuf_6:
    add x14, x13, #1
    sxtw x14, w14
    mov x19, x13
    mov x13, #1
    mov x15, #1
.Lssa_string____str_maxsuf_5:
    mov x4, x14
    mov x14, x13
    mov x13, x4
.Lssa_string____str_maxsuf_4:
    b .Lssa_string____str_maxsuf_3
.Lssa_string____str_maxsuf_1:
    mov x1, x15
    mov x0, x1
    mov x0, x19
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string____str_find_from:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_string____str_find_from.k:
__fn_string____str_find_from.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
    mov x22, x11
.Lssa_string____str_find_from_0:
    mov x9, #0
    cmp x12, #0
    csel x23, x9, x12, lt
.Lssa_string____str_find_from_47:
    cmp x22, #0
    b.ne .Lssa_string____str_find_from_41
.Lssa_string____str_find_from_46:
    cmp x23, x20
    csel x0, x20, x23, gt
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_41:
    sub x10, x20, x23
    sxtw x10, w10
    cmp x22, x10
    b.le .Lssa_string____str_find_from_38
.Lssa_string____str_find_from_40:
    mov x0, #-1
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_38:
    cmp x22, #1
    b.ne .Lssa_string____str_find_from_35
.Lssa_string____str_find_from_37:
    ldr x6, [x21, #8]
    cmp x6, #0
    b.hi 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w10, [x6, #0]
    mov x2, x23
    mov x1, x10
    mov x0, x19
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L194
    mov x2, #0
.L194:
    cmp x1, #255
    b.hi .L199
    cmp x2, x3
    b.ge .L199
    add x5, x0, x2
    add x6, x0, x3
    sub x8, x6, #32
    dup v1.16b, w1
    cmp x5, x8
    b.hi .L196
.L195:
    ldp q0, q2, [x5], #32
    cmeq v0.16b, v0.16b, v1.16b
    cmeq v2.16b, v2.16b, v1.16b
    orr v3.16b, v0.16b, v2.16b
    shrn v3.8b, v3.8h, #4
    fmov x7, d3
    cbnz x7, .L201
    cmp x5, x8
    b.ls .L195
.L196:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L197
    ldr q0, [x5], #16
    cmeq v0.16b, v0.16b, v1.16b
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L197
    sub x5, x5, #16
    b .L202
.L201:
    sub x5, x5, #32
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbnz x7, .L202
    shrn v2.8b, v2.8h, #4
    fmov x7, d2
    add x5, x5, #16
.L202:
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L200
.L197:
    cmp x5, x6
    b.ge .L199
    ldrb w4, [x5]
    cmp x4, x1
    b.eq .L198
    add x5, x5, #1
    b .L197
.L198:
    sub x2, x5, x0
    b .L200
.L199:
    mov x2, #-1
.L200:
    mov x0, x2
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_35:
    cmp x22, #4
    b.gt .Lssa_string____str_find_from_30
.Lssa_string____str_find_from_33:
    sub x10, x20, x22
    sxtw x10, w10
.Lssa_string____str_find_from_75:
    cmp x23, x10
    b.gt .Lssa_string____str_find_from_32
.Lssa_string____str_find_from_80:
.Lssa_string____str_find_from_79:
    mov x9, #0
.Lssa_string____str_find_from_85:
    cmp x9, x22
    b.ge .Lssa_string____str_find_from_78
.Lssa_string____str_find_from_87:
    add w12, w23, w9
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w11, [x6, x12]
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w12, [x6, x9]
    cmp x11, x12
    b.ne .Lssa_string____str_find_from_78
.Lssa_string____str_find_from_86:
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_string____str_find_from_87
.Lssa_string____str_find_from_78:
    cmp x9, x22
    b.eq .Lssa_string____str_find_from_26
.Lssa_string____str_find_from_76:
    add x9, x23, #1
    sxtw x23, w9
    cmp x23, x10
    b.le .Lssa_string____str_find_from_80
.Lssa_string____str_find_from_32:
    mov x0, #-1
    b .Lssa_string____str_find_from_25
.Lssa_string____str_find_from_30:
    mov x24, #0
    mov x25, #1
.Lssa_string____str_find_from_28:
    cmp x22, #3
    b.ge .Lssa_string____str_find_from_23
.Lssa_string____str_find_from_27:
    sub x9, x22, #1
    mov x28, x9
    mov x0, #1
    b .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_26:
    mov x0, x23
.Lssa_string____str_find_from_25:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string____str_find_from_23:
    mov x10, #0
    mov x0, x21
    mov x9, x22
    mov x11, x24
    mov x12, x25
    bl __fn_string____str_maxsuf.r
    mov x26, x0
    mov x27, x1
    mov x10, #1
    mov x0, x21
    mov x9, x22
    mov x11, x24
    mov x12, x25
    bl __fn_string____str_maxsuf.r
    mov x28, x0
    mov x0, x1
    cmp x28, x26
    b.ge .Lssa_string____str_find_from_20
.Lssa_string____str_find_from_22:
    add x26, x26, #1
    sxtw x26, w26
    mov x28, x26
    mov x0, x27
    b .Lssa_string____str_find_from_19
.Lssa_string____str_find_from_20:
    add x28, x28, #1
    sxtw x28, w28
.Lssa_string____str_find_from_19:
    sub x20, x20, x22
    sxtw x20, w20
.Lssa_string____str_find_from_18:
.Lssa_string____str_find_from_17:
    mov x10, #0
.Lssa_string____str_find_from_115:
    cmp x10, x28
    b.ge .Lssa_string____str_find_from_13
.Lssa_string____str_find_from_118:
    add w9, w0, w10
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w11, [x6, x9]
    mov w9, w10
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w12, [x6, x9]
    cmp x11, x12
    b.ne .Lssa_string____str_find_from_8
.Lssa_string____str_find_from_116:
    add x10, x10, #1
    cmp x10, x28
    b.lt .Lssa_string____str_find_from_118
.Lssa_string____str_find_from_13:
.Lssa_string____str_find_from_12:
    sub x10, x22, x0
    sxtw x10, w10
    mov x11, #0
.Lssa_string____str_find_from_134:
    cmp x23, x20
    b.gt .Lssa_string____str_find_from_11
.Lssa_string____str_find_from_147:
    cmp x11, x28
    csel x9, x11, x28, gt
.Lssa_string____str_find_from_144:
.Lssa_string____str_find_from_143:
.Lssa_string____str_find_from_157:
    cmp x9, x22
    b.ge .Lssa_string____str_find_from_142
.Lssa_string____str_find_from_159:
    mov w12, w9
    ldr x6, [x21, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w13, [x6, x12]
    add w12, w9, w23
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w14, [x6, x12]
    cmp x13, x14
    b.ne .Lssa_string____str_find_from_142
.Lssa_string____str_find_from_158:
    add x9, x9, #1
    cmp x9, x22
    b.lt .Lssa_string____str_find_from_159
.Lssa_string____str_find_from_142:
    cmp x9, x22
    b.lt .Lssa_string____str_find_from_136
.Lssa_string____str_find_from_141:
    sub x13, x28, #1
    sxtw x13, w13
.Lssa_string____str_find_from_140:
.Lssa_string____str_find_from_174:
    cmp x13, x11
    b.lt .Lssa_string____str_find_from_139
.Lssa_string____str_find_from_176:
    ldr x6, [x21, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w14, [x6, x13]
    add w12, w13, w23
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x12]
    cmp x14, x15
    b.ne .Lssa_string____str_find_from_139
.Lssa_string____str_find_from_175:
    sub x14, x13, #1
    sxtw x13, w14
    cmp x13, x11
    b.ge .Lssa_string____str_find_from_176
.Lssa_string____str_find_from_139:
    cmp x13, x11
    b.lt .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_137:
    add x13, x23, x0
    sxtw x13, w13
    mov x23, x13
    mov x11, x10
    b .Lssa_string____str_find_from_134
.Lssa_string____str_find_from_136:
    sub x9, x9, x28
    add x9, x23, x9
    add x9, x9, #1
    sxtw x9, w9
    mov x23, x9
    mov x11, #0
.Lssa_string____str_find_from_135:
    cmp x23, x20
    b.le .Lssa_string____str_find_from_147
.Lssa_string____str_find_from_11:
    mov x0, #-1
    mov x23, x0
.Lssa_string____str_find_from_10:
    b .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_8:
    sub x11, x22, x28
    sxtw x11, w11
    sub x10, x22, x28
    cmp x11, x28
    csel x10, x10, x28, gt
.Lssa_string____str_find_from_5:
    add x10, x10, #1
.Lssa_string____str_find_from_4:
.Lssa_string____str_find_from_201:
    cmp x23, x20
    b.gt .Lssa_string____str_find_from_3
.Lssa_string____str_find_from_210:
    mov x11, x28
.Lssa_string____str_find_from_216:
    cmp x11, x22
    b.ge .Lssa_string____str_find_from_209
.Lssa_string____str_find_from_218:
    mov w9, w11
    ldr x6, [x21, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w13, [x6, x9]
    add w9, w11, w23
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w14, [x6, x9]
    cmp x13, x14
    b.ne .Lssa_string____str_find_from_209
.Lssa_string____str_find_from_217:
    add x11, x11, #1
    cmp x11, x22
    b.lt .Lssa_string____str_find_from_218
.Lssa_string____str_find_from_209:
    cmp x11, x22
    b.lt .Lssa_string____str_find_from_203
.Lssa_string____str_find_from_208:
    sub x13, x28, #1
    sxtw x13, w13
.Lssa_string____str_find_from_207:
.Lssa_string____str_find_from_233:
    cmp x13, #0
    b.lt .Lssa_string____str_find_from_206
.Lssa_string____str_find_from_235:
    ldr x6, [x21, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x21]
    ldrb w14, [x6, x13]
    add w9, w13, w23
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w15, [x6, x9]
    cmp x14, x15
    b.ne .Lssa_string____str_find_from_206
.Lssa_string____str_find_from_234:
    sub x14, x13, #1
    sxtw x13, w14
    cmp x13, #0
    b.ge .Lssa_string____str_find_from_235
.Lssa_string____str_find_from_206:
    cmp x13, #0
    b.lt .Lssa_string____str_find_from_1
.Lssa_string____str_find_from_204:
    add x13, x23, x10
    sxtw x13, w13
    mov x23, x13
    b .Lssa_string____str_find_from_201
.Lssa_string____str_find_from_203:
    sub x11, x11, x28
    add x11, x23, x11
    add x11, x11, #1
    sxtw x11, w11
    mov x23, x11
.Lssa_string____str_find_from_202:
    cmp x23, x20
    b.le .Lssa_string____str_find_from_210
.Lssa_string____str_find_from_3:
    mov x0, #-1
    mov x23, x0
.Lssa_string____str_find_from_2:
.Lssa_string____str_find_from_1:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__split.k:
__fn_string__split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #80
    mov x19, x0
    mov x20, x9
.Lssa_string__split_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    adrp x23, .K0
    add x23, x23, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa_string__split_3
.Lssa_string__split_8:
    ldr x24, [x19, #8]
    adrp x0, .K0
    add x0, x0, :lo12:.K0
.Lssa_string__split_7:
    mov x25, x0
    mov x26, #0
.Lssa_string__split_14:
    cmp x26, x24
    b.ge .Lssa_string__split_5
.Lssa_string__split_15:
    mov x0, x19
    mov x9, x26
    mov x10, x24
    bl __fn_utf8_scalar__step.r
    add x0, x26, x0
    sxtw x27, w0
    mov x0, x19
    mov x1, x26
    mov x2, x27
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x28, x0
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    str x9, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x26, x0
    str x28, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x25
    mov x1, x26
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush73s
.Lssa_string__split_apush73o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush73e
.Lssa_string__split_apush73s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush73e:
    mov x25, x0
    mov x26, x27
    cmp x26, x24
    b.lt .Lssa_string__split_15
.Lssa_string__split_5:
    mov x0, x25
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_string__split_3:
    mov x12, #0
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    bl __fn_string____str_find_from.r
.Lssa_string__split_2:
    mov x26, x0
    mov x25, #0
.Lssa_string__split_22:
    cmp x26, #0
    b.lt .Lssa_string__split_1
.Lssa_string__split_23:
    mov x0, x19
    mov x1, x25
    mov x2, x26
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x27, x0
    adrp x12, .SB4
    add x12, x12, :lo12:.SB4
    str x12, [sp, #-16]!
    str x27, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x24, x0
    str x27, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush94s
.Lssa_string__split_apush94o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush94e
.Lssa_string__split_apush94s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush94e:
    mov x23, x0
    add x26, x26, x22
    sxtw x25, w26
    mov x0, x19
    mov x9, x21
    mov x10, x20
    mov x11, x22
    mov x12, x25
    bl __fn_string____str_find_from.r
    mov x26, x0
    cmp x26, #0
    b.ge .Lssa_string__split_23
.Lssa_string__split_1:
    mov x0, x19
    mov x1, x25
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x12, .SB4
    add x12, x12, :lo12:.SB4
    str x12, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x25, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x25
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_string__split_apush102s
.Lssa_string__split_apush102o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_string__split_apush102e
.Lssa_string__split_apush102s:
    bl __fern_arr_push_owned
.Lssa_string__split_apush102e:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_string__eq_ignore_ascii_case:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_string__eq_ignore_ascii_case.k:
__fn_string__eq_ignore_ascii_case.r:
.Lssa_string__eq_ignore_ascii_case_0:
    ldr x10, [x0, #8]
    ldr x11, [x9, #8]
    cmp x10, x11
    b.eq .Lssa_string__eq_ignore_ascii_case_5
.Lssa_string__eq_ignore_ascii_case_7:
    mov x0, #0
    ret
.Lssa_string__eq_ignore_ascii_case_5:
    mov x11, #-1
.Lssa_string__eq_ignore_ascii_case_4:
.Lssa_string__eq_ignore_ascii_case_12:
.Lssa_string__eq_ignore_ascii_case_19:
    add x11, x11, #1
    sxtw x11, w11
    cmp x11, x10
    b.ge .Lssa_string__eq_ignore_ascii_case_2
.Lssa_string__eq_ignore_ascii_case_17:
    ldr x12, [x0, #0]
    ldrb w13, [x12, x11]
    ldr x6, [x9, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x9]
    ldrb w12, [x6, x11]
    eor x12, x13, x12
    cmp x12, #0
    b.eq .Lssa_string__eq_ignore_ascii_case_19
.Lssa_string__eq_ignore_ascii_case_16:
    cmp x12, #32
    b.ne .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_15:
    mov x12, #32
    orr x12, x13, x12
    cmp x12, #97
    b.lt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_14:
    mov x12, #32
    orr x13, x13, x12
    cmp x13, #122
    b.gt .Lssa_string__eq_ignore_ascii_case_1
.Lssa_string__eq_ignore_ascii_case_13:
    b .Lssa_string__eq_ignore_ascii_case_19
.Lssa_string__eq_ignore_ascii_case_2:
    mov x0, #1
    ret
.Lssa_string__eq_ignore_ascii_case_1:
    mov x0, #0
    ret
    .cfi_endproc
    .ltorg
__fn_io_buffered__BufBlock__drop:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_io_buffered__BufBlock__drop.k:
__fn_io_buffered__BufBlock__drop.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa_io_buffered__BufBlock__drop_0:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fern_buf_free
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_json__JsonError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_json__JsonError__eq.k:
__fn_json__JsonError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_json__JsonError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_json__JsonError__eq_streqn22
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_json__JsonError__eq_streqd22
.Lssa_json__JsonError__eq_streqn22:
    mov x0, #0
.Lssa_json__JsonError__eq_streqd22:
    cbz x0, .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_9:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_6:
    ldr x10, [x19, #24]
    ldr x9, [x20, #24]
    cmp x10, x9
    b.ne .Lssa_json__JsonError__eq_2
.Lssa_json__JsonError__eq_3:
    ldr x10, [x19, #32]
    ldr x9, [x20, #32]
    cmp x10, x9
    cset x0, eq
    b .Lssa_json__JsonError__eq_1
.Lssa_json__JsonError__eq_2:
    mov x0, #0
.Lssa_json__JsonError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8__is_valid:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_utf8__is_valid.k:
__fn_utf8__is_valid.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa_utf8__is_valid_0:
.Lssa_utf8__is_valid_21:
    ldr x20, [x19, #8]
.Lssa_utf8__is_valid_20:
    mov x21, #0
.Lssa_utf8__is_valid_22:
    cmp x21, x20
    b.ge .Lssa_utf8__is_valid_19
.Lssa_utf8__is_valid_71:
    ldr x6, [x19, #8]
    cmp x21, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w22, [x6, x21]
    cmp x22, #128
    b.ge .Lssa_utf8__is_valid_66
.Lssa_utf8__is_valid_70:
    mov x2, x21
    mov x0, x19
    ldr x3, [x0, #8]
    ldr x0, [x0]
    cmp x2, #0
    b.ge .L203
    mov x2, #0
.L203:
    cmp x2, x3
    b.ge .L208
    add x5, x0, x2
    add x6, x0, x3
.L204:
    sub x7, x6, x5
    cmp x7, #16
    b.lt .L206
    ld1 {v0.16b}, [x5]
    cmlt v0.16b, v0.16b, #0
    shrn v0.8b, v0.8h, #4
    fmov x7, d0
    cbz x7, .L205
    rbit x4, x7
    clz x4, x4
    lsr x4, x4, #2
    add x5, x5, x4
    sub x2, x5, x0
    b .L209
.L205:
    add x5, x5, #16
    b .L204
.L206:
    cmp x5, x6
    b.ge .L208
    ldrb w4, [x5]
    tbnz w4, #7, .L207
    add x5, x5, #1
    b .L206
.L207:
    sub x2, x5, x0
    b .L209
.L208:
    mov x2, x3
.L209:
    mov x0, x2
    cmp x0, x20
    b.ge .Lssa_utf8__is_valid_18
.Lssa_utf8__is_valid_68:
    ldr x6, [x19, #8]
    cmp x0, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w9, [x6, x0]
    mov x21, x0
    mov x22, x9
.Lssa_utf8__is_valid_67:
.Lssa_utf8__is_valid_66:
    cmp x22, #192
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_65:
    cmp x22, #224
    b.ge .Lssa_utf8__is_valid_56
.Lssa_utf8__is_valid_64:
    add x9, x21, #1
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_62:
    add w9, w21, #1
    ldr x6, [x19, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w10, [x6, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_61:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_59:
    sub x9, x22, #192
    lsl x9, x9, #6
    sxtw x9, w9
    sub x10, x10, #128
    sxtw x10, w10
    orr x9, x9, x10
    cmp x9, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_57:
    add x9, x21, #2
    sxtw x9, w9
    mov x21, x9
    b .Lssa_utf8__is_valid_22
.Lssa_utf8__is_valid_56:
    cmp x22, #240
    b.ge .Lssa_utf8__is_valid_41
.Lssa_utf8__is_valid_55:
    add x9, x21, #2
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_53:
    add x9, x21, #1
    sxtw x9, w9
    add x10, x9, #1
    sxtw x10, w10
    asr x11, x9, #31
    orr x10, x10, x11
    ldr x6, [x19, #8]
    cmp x10, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x11, [x19, #0]
    ldrb w10, [x11, x9]
    add x9, x21, #2
    sxtw x9, w9
    ldrb w12, [x11, x9]
    cmp x10, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_52:
    cmp x10, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_50:
    cmp x12, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_49:
    cmp x12, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_47:
    sub x9, x22, #224
    lsl x9, x9, #12
    sxtw x9, w9
    sub x10, x10, #128
    lsl x10, x10, #6
    sxtw x10, w10
    orr x9, x9, x10
    sub x12, x12, #128
    sxtw x12, w12
    orr x9, x9, x12
    cmp x9, #2048
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_45:
    mov x12, #55296
    cmp x9, x12
    b.lt .Lssa_utf8__is_valid_42
.Lssa_utf8__is_valid_44:
    mov x12, #57343
    cmp x9, x12
    b.le .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_42:
    add x9, x21, #3
    sxtw x9, w9
    mov x13, x9
    b .Lssa_utf8__is_valid_24
.Lssa_utf8__is_valid_41:
    cmp x22, #248
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_40:
    add x9, x21, #3
    sxtw x9, w9
    cmp x9, x20
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_38:
    add x9, x21, #1
    sxtw x9, w9
    add x12, x9, #2
    sxtw x12, w12
    asr x10, x9, #31
    orr x12, x12, x10
    ldr x6, [x19, #8]
    cmp x12, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x10, [x19, #0]
    ldrb w12, [x10, x9]
    add x9, x21, #2
    sxtw x9, w9
    ldrb w11, [x10, x9]
    add x9, x21, #3
    sxtw x9, w9
    ldrb w13, [x10, x9]
    cmp x12, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_37:
    cmp x12, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_35:
    cmp x11, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_34:
    cmp x11, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_32:
    cmp x13, #128
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_31:
    cmp x13, #192
    b.ge .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_29:
    sub x22, x22, #240
    lsl x22, x22, #18
    sxtw x22, w22
    sub x12, x12, #128
    lsl x12, x12, #12
    sxtw x12, w12
    orr x22, x22, x12
    sub x11, x11, #128
    lsl x11, x11, #6
    sxtw x11, w11
    orr x22, x22, x11
    sub x13, x13, #128
    sxtw x13, w13
    orr x22, x22, x13
    movz x13, #1, lsl #16
    cmp x22, x13
    b.lt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_27:
    movn w13, #65519, lsl #16
    cmp x22, x13
    b.gt .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_25:
    add x13, x21, #4
    sxtw x13, w13
.Lssa_utf8__is_valid_24:
    mov x21, x13
.Lssa_utf8__is_valid_23:
    cmp x21, x20
    b.lt .Lssa_utf8__is_valid_71
.Lssa_utf8__is_valid_19:
    mov x21, x20
    b .Lssa_utf8__is_valid_1
.Lssa_utf8__is_valid_18:
    mov x21, x20
.Lssa_utf8__is_valid_17:
.Lssa_utf8__is_valid_16:
.Lssa_utf8__is_valid_15:
.Lssa_utf8__is_valid_14:
.Lssa_utf8__is_valid_13:
.Lssa_utf8__is_valid_12:
.Lssa_utf8__is_valid_11:
.Lssa_utf8__is_valid_10:
.Lssa_utf8__is_valid_9:
.Lssa_utf8__is_valid_8:
.Lssa_utf8__is_valid_7:
.Lssa_utf8__is_valid_6:
.Lssa_utf8__is_valid_5:
.Lssa_utf8__is_valid_4:
.Lssa_utf8__is_valid_3:
.Lssa_utf8__is_valid_2:
.Lssa_utf8__is_valid_1:
    ldr x13, [x19, #8]
    cmp x21, x13
    cset x0, eq
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___primitive_i32_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___primitive_i32_to_string.k:
__fn___primitive_i32_to_string.r:
.Lssa___primitive_i32_to_string_0:
    b __fn_int__int_to_string.r
    .cfi_endproc
    .ltorg
__fn_int__int_to_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn_int__int_to_string.k:
__fn_int__int_to_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
.Lssa_int__int_to_string_0:
    cmp x0, #0
    b.lt .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_47:
    cmp x0, #100
    b.ge .Lssa_int__int_to_string_44
.Lssa_int__int_to_string_46:
    adrp x9, .K10
    add x9, x9, :lo12:.K10
    ldr x6, [x9]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x0, #1
    ldr x10, [x9, x5, lsl #3]
    tbnz x10, #0, .Lssa_int__int_to_string_rcinc221
    cmp x10, #16, lsl #12
    b.lo .Lssa_int__int_to_string_rcinc221
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_int__int_to_string_rcinc221
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_int__int_to_string_rcinc221:
    mov x9, x10
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_int__int_to_string_44:
    mov x9, #0
    mov x10, #0
    sub x10, x10, x0
    mov x11, #1
    cmp x0, #0
    csel x10, x10, x0, lt
    csel x19, x11, x9, lt
.Lssa_int__int_to_string_41:
    mov w20, w10
.Lssa_int__int_to_string_40:
    cmp x20, #10
    b.hs .Lssa_int__int_to_string_37
.Lssa_int__int_to_string_39:
    mov x10, #1
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_37:
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_34
.Lssa_int__int_to_string_36:
    mov x10, #2
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_34:
    cmp x20, #1000
    b.hs .Lssa_int__int_to_string_31
.Lssa_int__int_to_string_33:
    mov x10, #3
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_31:
    mov x10, #10000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_28
.Lssa_int__int_to_string_30:
    mov x10, #4
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_28:
    ldr x10, =100000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_25
.Lssa_int__int_to_string_27:
    mov x10, #5
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_25:
    ldr x10, =1000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_22
.Lssa_int__int_to_string_24:
    mov x10, #6
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_22:
    ldr x10, =10000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_19
.Lssa_int__int_to_string_21:
    mov x10, #7
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_19:
    ldr x10, =100000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_16
.Lssa_int__int_to_string_18:
    mov x10, #8
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_16:
    ldr x10, =1000000000
    cmp x20, x10
    b.hs .Lssa_int__int_to_string_13
.Lssa_int__int_to_string_15:
    mov x10, #9
    b .Lssa_int__int_to_string_12
.Lssa_int__int_to_string_13:
    mov x10, #10
.Lssa_int__int_to_string_12:
    add x12, x10, #1
    sxtw x12, w12
    cmp x19, #0
    csel x21, x12, x10, ne
.Lssa_int__int_to_string_9:
    mov x0, x21
    bl __fern_alloc_bytes
    mov x22, x0
    adrp x12, .SB128
    add x12, x12, :lo12:.SB128
.Lssa_int__int_to_string_8:
.Lssa_int__int_to_string_111:
    cmp x20, #100
    b.lo .Lssa_int__int_to_string_7
.Lssa_int__int_to_string_112:
    mov x4, x20
    ldr x5, =184467440737095517
    umulh x5, x4, x5
    mov x4, x5
    mov x10, x4
    mov x11, #100
    mul x11, x10, x11
    sub x11, x20, x11
    sub x9, x21, #2
    sxtw x21, w9
    lsl x11, x11, #1
    sxtw x11, w11
    ldr x6, [x12, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w9, [x6, x11]
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w9, [x5, #8]
    add w13, w21, #1
    add w11, w11, #1
    ldr x6, [x12, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w9, [x6, x11]
    ldr x7, [x22]
    cmp x13, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x13
    strb w9, [x5, #8]
    mov x20, x10
    cmp x20, #100
    b.hs .Lssa_int__int_to_string_112
.Lssa_int__int_to_string_7:
    cmp x20, #10
    b.lo .Lssa_int__int_to_string_5
.Lssa_int__int_to_string_6:
    sub x11, x21, #2
    sxtw x11, w11
    lsl x9, x20, #1
    sxtw x9, w9
    ldr x6, [x12, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w13, [x6, x9]
    ldr x7, [x22]
    cmp x11, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    strb w13, [x5, #8]
    add w11, w11, #1
    add w9, w9, #1
    ldr x6, [x12, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x12]
    ldrb w10, [x6, x9]
    ldr x7, [x22]
    cmp x11, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x11
    strb w10, [x5, #8]
    b .Lssa_int__int_to_string_4
.Lssa_int__int_to_string_5:
    sub w21, w21, #1
    add x20, x20, #48
    and x20, x20, #255
    ldr x7, [x22]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, x21
    strb w20, [x5, #8]
.Lssa_int__int_to_string_4:
    cbz x19, .Lssa_int__int_to_string_1
.Lssa_int__int_to_string_3:
    tst x22, #1
    b.ne .Lssa_int__int_to_string_uq3
    cmp x22, #16, lsl #12
    b.lo .Lssa_int__int_to_string_uq3
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_int__int_to_string_uq3:
    b.ne .Lssa_int__int_to_string_129
.Lssa_int__int_to_string_128:
    b .Lssa_int__int_to_string_130
.Lssa_int__int_to_string_129:
    cmp x22, #16, lsl #12
    b.lo .Lssa_int__int_to_string_rcdeck346
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_int__int_to_string_rcdecd346
    tbnz w5, #31, .Lssa_int__int_to_string_rcdeck346
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_int__int_to_string_rcdece346
.Lssa_int__int_to_string_rcdecd346:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_int__int_to_string_rcdeck346:
    mov x0, x22
.Lssa_int__int_to_string_rcdece346:
    mov x9, #0
    ldr x10, [x22, #0]
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice_u8
    add sp, sp, #48
    mov x22, x0
.Lssa_int__int_to_string_130:
    mov x10, #45
    ldr x6, [x22, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    strb w10, [x22, #8]
.Lssa_int__int_to_string_2:
.Lssa_int__int_to_string_1:
    str x22, [sp, #-16]!
    bl __fn___fern_string_from_bytes_u8
    add sp, sp, #16
    mov x20, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa_int__int_to_string_rcdeck356
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_int__int_to_string_rcdecd356
    tbnz w5, #31, .Lssa_int__int_to_string_rcdeck356
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_int__int_to_string_rcdece356
.Lssa_int__int_to_string_rcdecd356:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_int__int_to_string_rcdeck356:
    mov x0, x22
.Lssa_int__int_to_string_rcdece356:
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_utf8_scalar__step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_utf8_scalar__step.k:
__fn_utf8_scalar__step.r:
.Lssa_utf8_scalar__step_0:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x9]
.Lssa_utf8_scalar__step_47:
    cmp x11, #128
    b.ge .Lssa_utf8_scalar__step_44
.Lssa_utf8_scalar__step_46:
    mov x12, #1
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_44:
    cmp x11, #194
    b.ge .Lssa_utf8_scalar__step_41
.Lssa_utf8_scalar__step_43:
    mov x12, #0
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_41:
    cmp x11, #224
    b.ge .Lssa_utf8_scalar__step_38
.Lssa_utf8_scalar__step_40:
    mov x12, #2
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_38:
    cmp x11, #240
    b.ge .Lssa_utf8_scalar__step_35
.Lssa_utf8_scalar__step_37:
    mov x12, #3
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_35:
    cmp x11, #245
    b.ge .Lssa_utf8_scalar__step_32
.Lssa_utf8_scalar__step_34:
    mov x12, #4
    b .Lssa_utf8_scalar__step_31
.Lssa_utf8_scalar__step_32:
    mov x12, #0
.Lssa_utf8_scalar__step_31:
    cmp x12, #1
    b.gt .Lssa_utf8_scalar__step_28
.Lssa_utf8_scalar__step_30:
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_28:
    add x13, x9, #1
    sxtw x13, w13
    cmp x13, x10
    b.lt .Lssa_utf8_scalar__step_25
.Lssa_utf8_scalar__step_27:
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_25:
    add w13, w9, #1
    ldr x6, [x0, #8]
    cmp x13, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w14, [x6, x13]
.Lssa_utf8_scalar__step_24:
    cmp x11, #224
    b.ne .Lssa_utf8_scalar__step_21
.Lssa_utf8_scalar__step_23:
    mov x13, #160
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_21:
    cmp x11, #240
    b.ne .Lssa_utf8_scalar__step_18
.Lssa_utf8_scalar__step_20:
    mov x13, #144
    b .Lssa_utf8_scalar__step_17
.Lssa_utf8_scalar__step_18:
    mov x13, #128
.Lssa_utf8_scalar__step_17:
    cmp x14, x13
    b.lt .Lssa_utf8_scalar__step_7
.Lssa_utf8_scalar__step_15:
    cmp x11, #237
    b.ne .Lssa_utf8_scalar__step_12
.Lssa_utf8_scalar__step_14:
    mov x11, #159
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_12:
    cmp x11, #244
    b.ne .Lssa_utf8_scalar__step_9
.Lssa_utf8_scalar__step_11:
    mov x11, #143
    b .Lssa_utf8_scalar__step_8
.Lssa_utf8_scalar__step_9:
    mov x11, #191
.Lssa_utf8_scalar__step_8:
    cmp x14, x11
    b.le .Lssa_utf8_scalar__step_5
.Lssa_utf8_scalar__step_7:
    mov x0, #1
    ret
.Lssa_utf8_scalar__step_5:
.Lssa_utf8_scalar__step_4:
    mov x14, #2
.Lssa_utf8_scalar__step_109:
    cmp x14, x12
    b.ge .Lssa_utf8_scalar__step_3
.Lssa_utf8_scalar__step_119:
    add x11, x9, x14
    sxtw x11, w11
    cmp x11, x10
    b.ge .Lssa_utf8_scalar__step_2
.Lssa_utf8_scalar__step_117:
    add w11, w9, w14
    ldr x6, [x0, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w13, [x6, x11]
.Lssa_utf8_scalar__step_116:
    cmp x13, #128
    b.lt .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_115:
    cmp x13, #192
    b.ge .Lssa_utf8_scalar__step_1
.Lssa_utf8_scalar__step_110:
    add x14, x14, #1
    cmp x14, x12
    b.lt .Lssa_utf8_scalar__step_119
.Lssa_utf8_scalar__step_3:
    mov x0, x12
    ret
.Lssa_utf8_scalar__step_2:
    mov x0, x14
    ret
.Lssa_utf8_scalar__step_1:
    mov x0, x14
    ret
    .cfi_endproc
    .ltorg
__fn_deflate____ReadPhase__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_deflate____ReadPhase__eq.k:
__fn_deflate____ReadPhase__eq.r:
.Lssa_deflate____ReadPhase__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S129
    add x11, x11, :lo12:.S129
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_20
.Lssa_deflate____ReadPhase__eq_24:
    ldr x11, [x9, #0]
    adrp x12, .S129
    add x12, x12, :lo12:.S129
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_20:
    adrp x11, .S130
    add x11, x11, :lo12:.S130
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_15
.Lssa_deflate____ReadPhase__eq_19:
    ldr x11, [x9, #0]
    adrp x14, .S130
    add x14, x14, :lo12:.S130
    mov x13, #1
    mov x12, #0
    cmp x11, x14
    csel x0, x13, x12, eq
    ret
.Lssa_deflate____ReadPhase__eq_15:
    adrp x11, .S131
    add x11, x11, :lo12:.S131
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_10
.Lssa_deflate____ReadPhase__eq_14:
    ldr x11, [x9, #0]
    adrp x12, .S131
    add x12, x12, :lo12:.S131
    mov x13, #1
    mov x14, #0
    cmp x11, x12
    csel x0, x13, x14, eq
    ret
.Lssa_deflate____ReadPhase__eq_10:
    adrp x11, .S132
    add x11, x11, :lo12:.S132
    cmp x10, x11
    b.ne .Lssa_deflate____ReadPhase__eq_4
.Lssa_deflate____ReadPhase__eq_9:
    ldr x10, [x9, #0]
    adrp x11, .S132
    add x11, x11, :lo12:.S132
    mov x14, #1
    mov x13, #0
    cmp x10, x11
    csel x0, x14, x13, eq
    ret
.Lssa_deflate____ReadPhase__eq_4:
    ldr x10, [x9, #0]
    adrp x9, .S133
    add x9, x9, :lo12:.S133
    mov x13, #1
    mov x14, #0
    cmp x10, x9
    csel x0, x13, x14, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeErrorKind__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeErrorKind__eq.k:
__fn_codec__DecodeErrorKind__eq.r:
.Lssa_codec__DecodeErrorKind__eq_0:
    ldr x10, [x0, #0]
    adrp x11, .S134
    add x11, x11, :lo12:.S134
    cmp x10, x11
    b.ne .Lssa_codec__DecodeErrorKind__eq_15
.Lssa_codec__DecodeErrorKind__eq_19:
    ldr x11, [x0, #8]
    ldr x12, [x9, #0]
    adrp x13, .S134
    add x13, x13, :lo12:.S134
    cmp x12, x13
    b.ne .Lssa_codec__DecodeErrorKind__eq_16
.Lssa_codec__DecodeErrorKind__eq_18:
    ldr x12, [x9, #8]
    cmp x11, x12
    cset x0, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_16:
    mov x0, #0
    ret
.Lssa_codec__DecodeErrorKind__eq_15:
    adrp x12, .S135
    add x12, x12, :lo12:.S135
    cmp x10, x12
    b.ne .Lssa_codec__DecodeErrorKind__eq_10
.Lssa_codec__DecodeErrorKind__eq_14:
    ldr x12, [x9, #0]
    adrp x11, .S135
    add x11, x11, :lo12:.S135
    mov x13, #1
    mov x14, #0
    cmp x12, x11
    csel x0, x13, x14, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_10:
    adrp x12, .S136
    add x12, x12, :lo12:.S136
    cmp x10, x12
    b.ne .Lssa_codec__DecodeErrorKind__eq_4
.Lssa_codec__DecodeErrorKind__eq_9:
    ldr x10, [x9, #0]
    adrp x12, .S136
    add x12, x12, :lo12:.S136
    mov x14, #1
    mov x13, #0
    cmp x10, x12
    csel x0, x14, x13, eq
    ret
.Lssa_codec__DecodeErrorKind__eq_4:
    ldr x10, [x9, #0]
    adrp x9, .S137
    add x9, x9, :lo12:.S137
    mov x13, #1
    mov x14, #0
    cmp x10, x9
    csel x0, x13, x14, eq
    ret
    .cfi_endproc
    .ltorg
__fn_codec__DecodeError__eq:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_codec__DecodeError__eq.k:
__fn_codec__DecodeError__eq.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_codec__DecodeError__eq_0:
    ldr x9, [x19, #8]
    ldr x10, [x20, #8]
    ldr x6, [x9, #8]
    ldr x7, [x10, #8]
    cmp x6, x7
    b.ne .Lssa_codec__DecodeError__eq_streqn36
    mov x0, x9
    mov x9, x10
    bl __fn___fern_str_eq.r
    b .Lssa_codec__DecodeError__eq_streqd36
.Lssa_codec__DecodeError__eq_streqn36:
    mov x0, #0
.Lssa_codec__DecodeError__eq_streqd36:
    cbz x0, .Lssa_codec__DecodeError__eq_20
.Lssa_codec__DecodeError__eq_27:
    ldr x10, [x19, #16]
    ldr x9, [x20, #16]
    cmp x10, x9
    b.ne .Lssa_codec__DecodeError__eq_20
.Lssa_codec__DecodeError__eq_24:
    ldr x10, [x19, #24]
    ldr x9, [x20, #24]
.Lssa_codec__DecodeError__eq_23:
    ldr x11, [x10, #0]
    adrp x12, .S134
    add x12, x12, :lo12:.S134
    cmp x11, x12
    b.ne .Lssa_codec__DecodeError__eq_17
.Lssa_codec__DecodeError__eq_22:
    ldr x12, [x10, #8]
    ldr x10, [x9, #0]
    adrp x13, .S134
    add x13, x13, :lo12:.S134
    cmp x10, x13
    b.ne .Lssa_codec__DecodeError__eq_18
.Lssa_codec__DecodeError__eq_21:
    ldr x10, [x9, #8]
    cmp x12, x10
    cset x0, eq
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_20:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_18:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_17:
    adrp x10, .S135
    add x10, x10, :lo12:.S135
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_12
.Lssa_codec__DecodeError__eq_16:
    ldr x10, [x9, #0]
    adrp x12, .S135
    add x12, x12, :lo12:.S135
    cmp x10, x12
    b.ne .Lssa_codec__DecodeError__eq_13
.Lssa_codec__DecodeError__eq_15:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_13:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_12:
    adrp x10, .S136
    add x10, x10, :lo12:.S136
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_6
.Lssa_codec__DecodeError__eq_11:
    ldr x11, [x9, #0]
    adrp x10, .S136
    add x10, x10, :lo12:.S136
    cmp x11, x10
    b.ne .Lssa_codec__DecodeError__eq_8
.Lssa_codec__DecodeError__eq_10:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_8:
    mov x0, #0
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_6:
    ldr x11, [x9, #0]
    adrp x9, .S137
    add x9, x9, :lo12:.S137
    cmp x11, x9
    b.ne .Lssa_codec__DecodeError__eq_3
.Lssa_codec__DecodeError__eq_5:
    mov x0, #1
    b .Lssa_codec__DecodeError__eq_1
.Lssa_codec__DecodeError__eq_3:
    mov x0, #0
.Lssa_codec__DecodeError__eq_2:
.Lssa_codec__DecodeError__eq_1:
    .cfi_remember_state
    sub sp, x29, #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_main:
    .cfi_startproc
__fn_main.k:
__fn_main.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #32
.Lssa_main_0:
    adrp x4, .SB138
    add x4, x4, :lo12:.SB138
    str x4, [sp, #24]
.Lssa_main_6:
    mov x21, #0
    str xzr, [sp, #16]
.Lssa_main_7:
    cmp x21, #4000
    b.ge .Lssa_main_5
.Lssa_main_59:
    ldr x4, [sp, #24]
    str x4, [sp, #-16]!
    bl __fn___fern_str_bytes_u8
    add sp, sp, #16
    mov x22, x0
    mov x0, x22
    bl __fn_http__parse_request_bytes.r
    mov x23, x0
    mov x24, x1
    cmp x22, #16, lsl #12
    b.lo .Lssa_main_rcdeck390
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd390
    tbnz w5, #31, .Lssa_main_rcdeck390
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece390
.Lssa_main_rcdecd390:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_main_rcdeck390:
    mov x0, x22
.Lssa_main_rcdece390:
    cmp x23, #0
    b.ne .Lssa_main_4
.Lssa_main_57:
    adrp x9, .SB139
    add x9, x9, :lo12:.SB139
    ldr x10, [x24, #16]
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x23, x0
    adrp x22, .K0
    add x22, x22, :lo12:.K0
    adrp x25, .K0
    add x25, x25, :lo12:.K0
.Lssa_main_55:
    adrp x26, .SB140
    add x26, x26, :lo12:.SB140
.Lssa_main_50:
    mov x4, #0
    str x4, [sp, #8]
.Lssa_main_44:
    adrp x28, .SB141
    add x28, x28, :lo12:.SB141
    ldr x0, [x23, #8]
    bl __fn_int__int_to_string.r
    mov x19, x0
    str x19, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x20, x0
    tbnz x19, #0, .Lssa_main_rcdeck407
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck407
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd407
    tbnz w5, #31, .Lssa_main_rcdeck407
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece407
.Lssa_main_rcdecd407:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck407:
    mov x0, x19
.Lssa_main_rcdece407:
    adrp x19, .SB142
    add x19, x19, :lo12:.SB142
    str x20, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_69
.Lssa_main_68:
    mov x28, x20
    b .Lssa_main_43
.Lssa_main_69:
    str x20, [sp, #-16]!
    str x19, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x28, x0
    tbnz x20, #0, .Lssa_main_rcdeck411
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_rcdeck411
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd411
    tbnz w5, #31, .Lssa_main_rcdeck411
    mov x0, x20
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece411
.Lssa_main_rcdecd411:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_main_rcdeck411:
    mov x0, x20
.Lssa_main_rcdece411:
.Lssa_main_70:
.Lssa_main_43:
    mov x10, #256
    mov x0, x10
    bl __fern_buf_new
    mov x20, x0
.Lssa_main_41:
    adrp x10, .SB143
    add x10, x10, :lo12:.SB143
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push
    mov x10, #200
.Lssa_main_37:
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push_decimal
.Lssa_main_36:
    adrp x10, .SB144
    add x10, x10, :lo12:.SB144
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push
.Lssa_main_34:
    adrp x10, .K11
    add x10, x10, :lo12:.K11
    adrp x9, .K12
    add x9, x9, :lo12:.K12
.Lssa_main_33:
    mov x11, #0
.Lssa_main_74:
    ldr x12, [x10, #0]
    cmp x11, x12
    b.ge .Lssa_main_32
.Lssa_main_77:
    add x5, x11, #1
    ldr x12, [x10, x5, lsl #3]
    cmp x12, #200
    b.eq .Lssa_main_31
.Lssa_main_75:
    add x11, x11, #1
    b .Lssa_main_74
.Lssa_main_32:
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    mov x19, x10
    b .Lssa_main_30
.Lssa_main_31:
    ldr x6, [x9]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x10, [x9, x5, lsl #3]
    tbnz x10, #0, .Lssa_main_rcinc440
    cmp x10, #16, lsl #12
    b.lo .Lssa_main_rcinc440
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_main_rcinc440
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_main_rcinc440:
    mov x0, x10
    mov x19, x10
.Lssa_main_30:
    ldr x10, [x19, #8]
    cmp x10, #0
    b.ne .Lssa_main_27
.Lssa_main_89:
    tbnz x19, #0, .Lssa_main_rcdeck446
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck446
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd446
    tbnz w5, #31, .Lssa_main_rcdeck446
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece446
.Lssa_main_rcdecd446:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck446:
    mov x0, x19
.Lssa_main_rcdece446:
.Lssa_main_29:
    adrp x10, .SB194
    add x10, x10, :lo12:.SB194
    mov x19, x10
.Lssa_main_28:
.Lssa_main_27:
    mov x0, x20
    mov x1, x19
    bl __fern_buf_push
    tbnz x19, #0, .Lssa_main_rcdeck450
    cmp x19, #16, lsl #12
    b.lo .Lssa_main_rcdeck450
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd450
    tbnz w5, #31, .Lssa_main_rcdeck450
    mov x0, x19
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece450
.Lssa_main_rcdecd450:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_main_rcdeck450:
    mov x0, x19
.Lssa_main_rcdece450:
    adrp x10, .SB142
    add x10, x10, :lo12:.SB142
    mov x0, x20
    mov x1, x10
    bl __fern_buf_push
.Lssa_main_26:
    mov x19, #0
.Lssa_main_94:
    ldr x10, [x22, #0]
    cmp x19, x10
    b.ge .Lssa_main_24
.Lssa_main_100:
    add x5, x19, #1
    ldr x27, [x22, x5, lsl #3]
    adrp x9, .SB15
    add x9, x9, :lo12:.SB15
    mov x0, x27
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_95
.Lssa_main_99:
    adrp x9, .SB14
    add x9, x9, :lo12:.SB14
    mov x0, x27
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_95
.Lssa_main_98:
    adrp x9, .SB16
    add x9, x9, :lo12:.SB16
    mov x0, x27
    bl __fn_string__eq_ignore_ascii_case.r
    cbnz x0, .Lssa_main_95
.Lssa_main_96:
    mov x0, x20
    mov x1, x27
    bl __fern_buf_push
    adrp x9, .SB195
    add x9, x9, :lo12:.SB195
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
    ldr x6, [x25]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x9, [x25, x5, lsl #3]
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
    adrp x9, .SB142
    add x9, x9, :lo12:.SB142
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_95:
    add x19, x19, #1
    b .Lssa_main_94
.Lssa_main_24:
    mov x0, x20
    mov x1, x28
    bl __fern_buf_push
    tbnz x28, #0, .Lssa_main_rcdeck490
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck490
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd490
    tbnz w5, #31, .Lssa_main_rcdeck490
    mov x0, x28
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece490
.Lssa_main_rcdecd490:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck490:
    mov x0, x28
.Lssa_main_rcdece490:
.Lssa_main_19:
    adrp x9, .SB196
    add x9, x9, :lo12:.SB196
    mov x0, x20
    mov x1, x9
    bl __fern_buf_push
.Lssa_main_16:
    mov x0, x20
    bl __fern_buf_take
    mov x28, x0
    mov x0, x20
    bl __fern_buf_free
    ldr x4, [sp, #8]
    cbz x4, .Lssa_main_15
.Lssa_main_120:
    tbnz x23, #0, .Lssa_main_rcdeck495
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_rcdeck495
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd495
    tbnz w5, #31, .Lssa_main_rcdeck495
    mov x0, x23
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece495
.Lssa_main_rcdecd495:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_main_rcdeck495:
    mov x0, x23
.Lssa_main_rcdece495:
    tbnz x28, #0, .Lssa_main_rcdeck496
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck496
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd496
    tbnz w5, #31, .Lssa_main_rcdeck496
    mov x0, x28
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece496
.Lssa_main_rcdecd496:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck496:
    mov x0, x28
.Lssa_main_rcdece496:
    mov x0, x24
    bl __fn___sem_release_HttpRequest.r
    b .Lssa_main_1
.Lssa_main_15:
    adrp x9, .SB197
    add x9, x9, :lo12:.SB197
    ldr x10, [x26, #8]
    cmp x10, #4
    b.ne .Lssa_main_12
.Lssa_main_124:
    ldr x6, [x26, #8]
    ldr x7, [x9, #8]
    cmp x6, x7
    b.ne .Lssa_main_streqn503
    ldr x6, [x26]
    ldrb w6, [x6]
    cmp w6, #72
    b.ne .Lssa_main_streqn503
    mov x0, x26
    bl __fn___fern_str_eq.r
    b .Lssa_main_streqd503
.Lssa_main_streqn503:
    mov x0, #0
.Lssa_main_streqd503:
    cbz x0, .Lssa_main_12
.Lssa_main_127:
    tbnz x23, #0, .Lssa_main_rcdeck505
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_rcdeck505
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd505
    tbnz w5, #31, .Lssa_main_rcdeck505
    mov x0, x23
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece505
.Lssa_main_rcdecd505:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_main_rcdeck505:
    mov x0, x23
.Lssa_main_rcdece505:
.Lssa_main_14:
    mov x26, x28
    b .Lssa_main_9
.Lssa_main_12:
    str x28, [sp, #-16]!
    str x23, [sp, #-16]!
    bl __fn___fern_str_grow
    add sp, sp, #32
    cbz x0, .Lssa_main_133
.Lssa_main_132:
    mov x26, x28
    b .Lssa_main_134
.Lssa_main_133:
    str x28, [sp, #-16]!
    str x23, [sp, #-16]!
    bl __fn___fern_str_grow_fresh
    add sp, sp, #32
    mov x26, x0
    tbnz x28, #0, .Lssa_main_rcdeck508
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck508
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd508
    tbnz w5, #31, .Lssa_main_rcdeck508
    mov x0, x28
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece508
.Lssa_main_rcdecd508:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck508:
    mov x0, x28
.Lssa_main_rcdece508:
.Lssa_main_134:
    tbnz x23, #0, .Lssa_main_rcdeck510
    cmp x23, #16, lsl #12
    b.lo .Lssa_main_rcdeck510
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd510
    tbnz w5, #31, .Lssa_main_rcdeck510
    mov x0, x23
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece510
.Lssa_main_rcdecd510:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_main_rcdeck510:
    mov x0, x23
.Lssa_main_rcdece510:
.Lssa_main_11:
.Lssa_main_9:
    ldr x23, [x26, #8]
    tbnz x26, #0, .Lssa_main_rcdeck515
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcdeck515
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd515
    tbnz w5, #31, .Lssa_main_rcdeck515
    mov x0, x26
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece515
.Lssa_main_rcdecd515:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcdeck515:
    mov x0, x26
.Lssa_main_rcdece515:
    tst x24, #1
    b.ne .Lssa_main_uq9
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_uq9
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_main_uq9:
    b.ne .Lssa_main_136
.Lssa_main_135:
    mov x9, x24
    b .Lssa_main_137
.Lssa_main_136:
    mov x9, #0
.Lssa_main_137:
    ldr x26, [x24, #32]
    cmp x9, #0
    b.ne .Lssa_main_140
.Lssa_main_138:
    tbnz x26, #0, .Lssa_main_rcinc522
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_rcinc522
    ldur w5, [x26, #-8]
    tbnz w5, #31, .Lssa_main_rcinc522
    add w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_main_rcinc522:
    mov x0, x26
.Lssa_main_140:
    cmp x9, #0
    b.eq .Lssa_main_142
.Lssa_main_141:
    mov x9, #0
    str x9, [x24, #32]
    mov x0, x24
    bl __fn___sem_drop_HttpRequest.r
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_main_143
.Lssa_main_142:
    mov x0, x24
    bl __fn___sem_release_HttpRequest.r
.Lssa_main_143:
    tst x26, #1
    b.ne .Lssa_main_uq143
    cmp x26, #16, lsl #12
    b.lo .Lssa_main_uq143
    ldur w5, [x26, #-8]
    cmp w5, #1
.Lssa_main_uq143:
    b.ne .Lssa_main_145
.Lssa_main_144:
    mov x10, x26
    b .Lssa_main_146
.Lssa_main_145:
    mov x10, #0
.Lssa_main_146:
    ldr x28, [x26, #8]
    cmp x10, #0
    b.ne .Lssa_main_149
.Lssa_main_147:
    tbnz x28, #0, .Lssa_main_rcinc536
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcinc536
    ldur w5, [x28, #-8]
    tbnz w5, #31, .Lssa_main_rcinc536
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcinc536:
    mov x0, x28
.Lssa_main_149:
    cmp x10, #0
    b.eq .Lssa_main_151
.Lssa_main_150:
    ldr x20, [x26, #16]
    tst x20, #1
    b.ne .Lssa_main_uq150
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_uq150
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa_main_uq150:
    b.ne .Lssa_main_155
.Lssa_main_153:
    mov x19, #0
.Lssa_main_157:
    ldr x10, [x20, #0]
    cmp x19, x10
    b.ge .Lssa_main_155
.Lssa_main_158:
    add x5, x19, #1
    ldr x10, [x20, x5, lsl #3]
    tbnz x10, #0, .Lssa_main_rcdeck546
    cmp x10, #16, lsl #12
    b.lo .Lssa_main_rcdeck546
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd546
    tbnz w5, #31, .Lssa_main_rcdeck546
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece546
.Lssa_main_rcdecd546:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_main_rcdeck546:
    mov x0, x10
.Lssa_main_rcdece546:
    add x19, x19, #1
    b .Lssa_main_157
.Lssa_main_155:
    cmp x20, #16, lsl #12
    b.lo .Lssa_main_rcdeck550
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd550
    tbnz w5, #31, .Lssa_main_rcdeck550
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece550
.Lssa_main_rcdecd550:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_main_rcdeck550:
    mov x0, x20
.Lssa_main_rcdece550:
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_main_152
.Lssa_main_151:
    mov x0, x26
    bl __fn___sem_release_HeaderMap.r
.Lssa_main_152:
    ldr x26, [x28, #0]
    tst x28, #1
    b.ne .Lssa_main_uq152
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_uq152
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_main_uq152:
    b.ne .Lssa_main_163
.Lssa_main_161:
    mov x20, #0
.Lssa_main_165:
    ldr x10, [x28, #0]
    cmp x20, x10
    b.ge .Lssa_main_163
.Lssa_main_166:
    add x5, x20, #1
    ldr x10, [x28, x5, lsl #3]
    tbnz x10, #0, .Lssa_main_rcdeck563
    cmp x10, #16, lsl #12
    b.lo .Lssa_main_rcdeck563
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd563
    tbnz w5, #31, .Lssa_main_rcdeck563
    mov x0, x10
    bl __fn___fern_str_free.u
    b .Lssa_main_rcdece563
.Lssa_main_rcdecd563:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_main_rcdeck563:
    mov x0, x10
.Lssa_main_rcdece563:
    add x20, x20, #1
    b .Lssa_main_165
.Lssa_main_163:
    cmp x28, #16, lsl #12
    b.lo .Lssa_main_rcdeck568
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd568
    tbnz w5, #31, .Lssa_main_rcdeck568
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece568
.Lssa_main_rcdecd568:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_main_rcdeck568:
    mov x0, x28
.Lssa_main_rcdece568:
    add x23, x23, x26
    sxtw x23, w23
    ldr x4, [sp, #16]
    add x4, x4, x23
    str x4, [sp, #16]
.Lssa_main_8:
    add x21, x21, #1
    cmp x21, #4000
    b.lt .Lssa_main_59
.Lssa_main_5:
    ldr x4, [sp, #16]
    ldr x5, =-6275696437447579415
    smulh x5, x4, x5
    add x5, x5, x4
    asr x5, x5, #6
    add x5, x5, x5, lsr #63
    mov x6, #97
    msub x4, x5, x6, x4
    mov x10, x4
    sxtw x0, w10
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_4:
    cmp x24, #16, lsl #12
    b.lo .Lssa_main_rcdeck579
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_main_rcdecd579
    tbnz w5, #31, .Lssa_main_rcdeck579
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_main_rcdece579
.Lssa_main_rcdecd579:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_main_rcdeck579:
    mov x0, x24
.Lssa_main_rcdece579:
.Lssa_main_2:
    mov x0, #100
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_main_1:
    mov x10, #134
    mov x0, x10
    mov x8, #94
    svc #0
    mov x0, #0
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HeaderMap
.weak __fn___sem_drop_HeaderMap.k
__fn___sem_drop_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HeaderMap.k:
__fn___sem_drop_HeaderMap.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HeaderMap_0:
    ldr x20, [x19, #8]
    tst x20, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq0
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq0:
    b.ne .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_1:
    mov x21, #0
.Lssa___sem_drop_HeaderMap_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_HeaderMap_3
.Lssa___sem_drop_HeaderMap_6:
    add x5, x21, #1
    ldr x9, [x20, x5, lsl #3]
    tbnz x9, #0, .Lssa___sem_drop_HeaderMap_rcdeck11
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck11
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd11
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck11
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HeaderMap_rcdece11
.Lssa___sem_drop_HeaderMap_rcdecd11:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck11:
    mov x0, x9
.Lssa___sem_drop_HeaderMap_rcdece11:
    add x21, x21, #1
    b .Lssa___sem_drop_HeaderMap_5
.Lssa___sem_drop_HeaderMap_3:
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck15
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd15
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck15
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_HeaderMap_rcdece15
.Lssa___sem_drop_HeaderMap_rcdecd15:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck15:
    mov x0, x20
.Lssa___sem_drop_HeaderMap_rcdece15:
    ldr x20, [x19, #16]
    tst x20, #1
    b.ne .Lssa___sem_drop_HeaderMap_uq3
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_uq3
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_HeaderMap_uq3:
    b.ne .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_9:
    mov x19, #0
.Lssa___sem_drop_HeaderMap_13:
    ldr x9, [x20, #0]
    cmp x19, x9
    b.ge .Lssa___sem_drop_HeaderMap_11
.Lssa___sem_drop_HeaderMap_14:
    add x5, x19, #1
    ldr x9, [x20, x5, lsl #3]
    tbnz x9, #0, .Lssa___sem_drop_HeaderMap_rcdeck23
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck23
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd23
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck23
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HeaderMap_rcdece23
.Lssa___sem_drop_HeaderMap_rcdecd23:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck23:
    mov x0, x9
.Lssa___sem_drop_HeaderMap_rcdece23:
    add x19, x19, #1
    b .Lssa___sem_drop_HeaderMap_13
.Lssa___sem_drop_HeaderMap_11:
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_HeaderMap_rcdeck27
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HeaderMap_rcdecd27
    tbnz w5, #31, .Lssa___sem_drop_HeaderMap_rcdeck27
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_HeaderMap_rcdece27
.Lssa___sem_drop_HeaderMap_rcdecd27:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___sem_drop_HeaderMap_rcdeck27:
    mov x0, x20
.Lssa___sem_drop_HeaderMap_rcdece27:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HeaderMap
.weak __fn___sem_release_HeaderMap.k
__fn___sem_release_HeaderMap:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HeaderMap.k:
__fn___sem_release_HeaderMap.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HeaderMap_release_dec
    tbz w5, #31, .Lssa___sem_release_HeaderMap_release_slow
.Lssa___sem_release_HeaderMap_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_HeaderMap_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_HeaderMap_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HeaderMap_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HeaderMap_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_HeaderMap_uq0:
    b.ne .Lssa___sem_release_HeaderMap_3
.Lssa___sem_release_HeaderMap_1:
    mov x0, x19
    bl __fn___sem_drop_HeaderMap.r
.Lssa___sem_release_HeaderMap_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HeaderMap_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HeaderMap_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_HeaderMap_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_HeaderMap_rcdece3
.Lssa___sem_release_HeaderMap_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_HeaderMap_rcdeck3:
    mov x0, x19
.Lssa___sem_release_HeaderMap_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ByteStream
.weak __fn___sem_drop_ByteStream.k
__fn___sem_drop_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ByteStream.k:
__fn___sem_drop_ByteStream.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_ByteStream_0:
    ldr x9, [x19, #8]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ByteStream_rcdeck3
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ByteStream_rcdecd3
    tbnz w5, #31, .Lssa___sem_drop_ByteStream_rcdeck3
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ByteStream_rcdece3
.Lssa___sem_drop_ByteStream_rcdecd3:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ByteStream_rcdeck3:
    mov x0, x9
.Lssa___sem_drop_ByteStream_rcdece3:
    ldr x0, [x19, #24]
    bl __fn___sem_release_Option$BodySource.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ByteStream
.weak __fn___sem_release_ByteStream.k
__fn___sem_release_ByteStream:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ByteStream.k:
__fn___sem_release_ByteStream.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ByteStream_release_dec
    tbz w5, #31, .Lssa___sem_release_ByteStream_release_slow
.Lssa___sem_release_ByteStream_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_ByteStream_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_ByteStream_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ByteStream_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ByteStream_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_ByteStream_uq0:
    b.ne .Lssa___sem_release_ByteStream_3
.Lssa___sem_release_ByteStream_1:
    mov x0, x19
    bl __fn___sem_drop_ByteStream.r
.Lssa___sem_release_ByteStream_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ByteStream_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ByteStream_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_ByteStream_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_ByteStream_rcdece3
.Lssa___sem_release_ByteStream_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_ByteStream_rcdeck3:
    mov x0, x19
.Lssa___sem_release_ByteStream_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_BodySource
.weak __fn___sem_drop_BodySource.k
__fn___sem_drop_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_BodySource.k:
__fn___sem_drop_BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_BodySource_0:
    ldr x9, [x19, #8]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_rcdeck5
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_BodySource_rcdecd5
    tbnz w5, #31, .Lssa___sem_drop_BodySource_rcdeck5
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_BodySource_rcdece5
.Lssa___sem_drop_BodySource_rcdecd5:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_BodySource_rcdeck5:
    mov x0, x9
.Lssa___sem_drop_BodySource_rcdece5:
    ldr x20, [x19, #16]
    tst x20, #1
    b.ne .Lssa___sem_drop_BodySource_uq0
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_uq0
    ldur w5, [x20, #-8]
    cmp w5, #1
.Lssa___sem_drop_BodySource_uq0:
    b.ne .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_1:
    mov x21, #0
.Lssa___sem_drop_BodySource_5:
    ldr x9, [x20, #0]
    cmp x21, x9
    b.ge .Lssa___sem_drop_BodySource_3
.Lssa___sem_drop_BodySource_6:
    add x5, x21, #1
    ldr x0, [x20, x5, lsl #3]
    bl __fn___sem_release_Option$StreamFault.r
    add x21, x21, #1
    b .Lssa___sem_drop_BodySource_5
.Lssa___sem_drop_BodySource_3:
    cmp x20, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_rcdeck17
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_BodySource_rcdecd17
    tbnz w5, #31, .Lssa___sem_drop_BodySource_rcdeck17
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_BodySource_rcdece17
.Lssa___sem_drop_BodySource_rcdecd17:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa___sem_drop_BodySource_rcdeck17:
    mov x0, x20
.Lssa___sem_drop_BodySource_rcdece17:
    ldr x9, [x19, #24]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_BodySource_rcdeck19
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_BodySource_rcdecd19
    tbnz w5, #31, .Lssa___sem_drop_BodySource_rcdeck19
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_BodySource_rcdece19
.Lssa___sem_drop_BodySource_rcdecd19:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_BodySource_rcdeck19:
    mov x0, x9
.Lssa___sem_drop_BodySource_rcdece19:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_BodySource
.weak __fn___sem_release_BodySource.k
__fn___sem_release_BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_BodySource.k:
__fn___sem_release_BodySource.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_BodySource_release_dec
    tbz w5, #31, .Lssa___sem_release_BodySource_release_slow
.Lssa___sem_release_BodySource_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_BodySource_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_BodySource_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_BodySource_uq0:
    b.ne .Lssa___sem_release_BodySource_3
.Lssa___sem_release_BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_BodySource.r
.Lssa___sem_release_BodySource_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_BodySource_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_BodySource_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_BodySource_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_BodySource_rcdece3
.Lssa___sem_release_BodySource_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_BodySource_rcdeck3:
    mov x0, x19
.Lssa___sem_release_BodySource_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_http__HttpFramed
.weak __fn___sem_drop_http__HttpFramed.k
__fn___sem_drop_http__HttpFramed:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_http__HttpFramed.k:
__fn___sem_drop_http__HttpFramed.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_http__HttpFramed_0:
    ldr x0, [x19, #8]
    bl __fn___sem_release_HttpRequest.r
    ldr x9, [x19, #32]
    tbnz x9, #0, .Lssa___sem_drop_http__HttpFramed_rcdeck5
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_http__HttpFramed_rcdeck5
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_http__HttpFramed_rcdecd5
    tbnz w5, #31, .Lssa___sem_drop_http__HttpFramed_rcdeck5
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_http__HttpFramed_rcdece5
.Lssa___sem_drop_http__HttpFramed_rcdecd5:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_http__HttpFramed_rcdeck5:
    mov x0, x9
.Lssa___sem_drop_http__HttpFramed_rcdece5:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_http__HttpFramed
.weak __fn___sem_release_http__HttpFramed.k
__fn___sem_release_http__HttpFramed:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_http__HttpFramed.k:
__fn___sem_release_http__HttpFramed.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_http__HttpFramed_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_http__HttpFramed_release_dec
    tbz w5, #31, .Lssa___sem_release_http__HttpFramed_release_slow
.Lssa___sem_release_http__HttpFramed_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_http__HttpFramed_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_http__HttpFramed_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_http__HttpFramed_0:
    tst x19, #1
    b.ne .Lssa___sem_release_http__HttpFramed_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_http__HttpFramed_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_http__HttpFramed_uq0:
    b.ne .Lssa___sem_release_http__HttpFramed_3
.Lssa___sem_release_http__HttpFramed_1:
    mov x0, x19
    bl __fn___sem_drop_http__HttpFramed.r
.Lssa___sem_release_http__HttpFramed_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_http__HttpFramed_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_http__HttpFramed_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_http__HttpFramed_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_http__HttpFramed_rcdece3
.Lssa___sem_release_http__HttpFramed_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_http__HttpFramed_rcdeck3:
    mov x0, x19
.Lssa___sem_release_http__HttpFramed_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_HttpRequest
.weak __fn___sem_drop_HttpRequest.k
__fn___sem_drop_HttpRequest:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_HttpRequest.k:
__fn___sem_drop_HttpRequest.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_drop_HttpRequest_0:
    ldr x9, [x19, #8]
    tbnz x9, #0, .Lssa___sem_drop_HttpRequest_rcdeck3
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HttpRequest_rcdeck3
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HttpRequest_rcdecd3
    tbnz w5, #31, .Lssa___sem_drop_HttpRequest_rcdeck3
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HttpRequest_rcdece3
.Lssa___sem_drop_HttpRequest_rcdecd3:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HttpRequest_rcdeck3:
    mov x0, x9
.Lssa___sem_drop_HttpRequest_rcdece3:
    ldr x9, [x19, #16]
    tbnz x9, #0, .Lssa___sem_drop_HttpRequest_rcdeck5
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_HttpRequest_rcdeck5
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_HttpRequest_rcdecd5
    tbnz w5, #31, .Lssa___sem_drop_HttpRequest_rcdeck5
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___sem_drop_HttpRequest_rcdece5
.Lssa___sem_drop_HttpRequest_rcdecd5:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_HttpRequest_rcdeck5:
    mov x0, x9
.Lssa___sem_drop_HttpRequest_rcdece5:
    ldr x0, [x19, #24]
    bl __fn___sem_release_ByteStream.r
    ldr x0, [x19, #32]
    bl __fn___sem_release_HeaderMap.r
    ldr x0, [x19, #40]
    bl __fn___sem_release_HeaderMap.r
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_HttpRequest
.weak __fn___sem_release_HttpRequest.k
__fn___sem_release_HttpRequest:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_HttpRequest.k:
__fn___sem_release_HttpRequest.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_HttpRequest_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HttpRequest_release_dec
    tbz w5, #31, .Lssa___sem_release_HttpRequest_release_slow
.Lssa___sem_release_HttpRequest_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_HttpRequest_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_HttpRequest_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_HttpRequest_0:
    tst x19, #1
    b.ne .Lssa___sem_release_HttpRequest_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HttpRequest_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_HttpRequest_uq0:
    b.ne .Lssa___sem_release_HttpRequest_3
.Lssa___sem_release_HttpRequest_1:
    mov x0, x19
    bl __fn___sem_drop_HttpRequest.r
.Lssa___sem_release_HttpRequest_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_HttpRequest_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_HttpRequest_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_HttpRequest_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_HttpRequest_rcdece3
.Lssa___sem_release_HttpRequest_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_HttpRequest_rcdeck3:
    mov x0, x19
.Lssa___sem_release_HttpRequest_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$BodySource
.weak __fn___sem_drop_Option$BodySource.k
__fn___sem_drop_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$BodySource.k:
__fn___sem_drop_Option$BodySource.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$BodySource_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$BodySource_3
.Lssa___sem_drop_Option$BodySource_1:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___sem_release_BodySource.r
.Lssa___sem_drop_Option$BodySource_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$BodySource
.weak __fn___sem_release_Option$BodySource.k
__fn___sem_release_Option$BodySource:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$BodySource.k:
__fn___sem_release_Option$BodySource.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$BodySource_release_dec
    tbz w5, #31, .Lssa___sem_release_Option$BodySource_release_slow
.Lssa___sem_release_Option$BodySource_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Option$BodySource_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Option$BodySource_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$BodySource_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$BodySource_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Option$BodySource_uq0:
    b.ne .Lssa___sem_release_Option$BodySource_3
.Lssa___sem_release_Option$BodySource_1:
    mov x0, x19
    bl __fn___sem_drop_Option$BodySource.r
.Lssa___sem_release_Option$BodySource_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$BodySource_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$BodySource_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_Option$BodySource_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_Option$BodySource_rcdece3
.Lssa___sem_release_Option$BodySource_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_Option$BodySource_rcdeck3:
    mov x0, x19
.Lssa___sem_release_Option$BodySource_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_Option$StreamFault
.weak __fn___sem_drop_Option$StreamFault.k
__fn___sem_drop_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_Option$StreamFault.k:
__fn___sem_drop_Option$StreamFault.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_Option$StreamFault_0:
    ldr x9, [x0, #0]
    cmp x9, #0
    b.ne .Lssa___sem_drop_Option$StreamFault_3
.Lssa___sem_drop_Option$StreamFault_1:
    ldr x9, [x0, #8]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_Option$StreamFault_rcdeck6
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_Option$StreamFault_rcdecd6
    tbnz w5, #31, .Lssa___sem_drop_Option$StreamFault_rcdeck6
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_Option$StreamFault_rcdece6
.Lssa___sem_drop_Option$StreamFault_rcdecd6:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_Option$StreamFault_rcdeck6:
    mov x0, x9
.Lssa___sem_drop_Option$StreamFault_rcdece6:
.Lssa___sem_drop_Option$StreamFault_3:
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_Option$StreamFault
.weak __fn___sem_release_Option$StreamFault.k
__fn___sem_release_Option$StreamFault:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_Option$StreamFault.k:
__fn___sem_release_Option$StreamFault.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$StreamFault_release_dec
    tbz w5, #31, .Lssa___sem_release_Option$StreamFault_release_slow
.Lssa___sem_release_Option$StreamFault_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_Option$StreamFault_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_Option$StreamFault_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_Option$StreamFault_0:
    tst x19, #1
    b.ne .Lssa___sem_release_Option$StreamFault_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_Option$StreamFault_uq0:
    b.ne .Lssa___sem_release_Option$StreamFault_3
.Lssa___sem_release_Option$StreamFault_1:
    mov x0, x19
    bl __fn___sem_drop_Option$StreamFault.r
.Lssa___sem_release_Option$StreamFault_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_Option$StreamFault_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_Option$StreamFault_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_Option$StreamFault_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_Option$StreamFault_rcdece3
.Lssa___sem_release_Option$StreamFault_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_Option$StreamFault_rcdeck3:
    mov x0, x19
.Lssa___sem_release_Option$StreamFault_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_len
.weak __fn___sem_view_len.k
__fn___sem_view_len:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_len.k:
__fn___sem_view_len.r:
.Lssa___sem_view_len_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_len_3
.Lssa___sem_view_len_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #8]
    mov x0, x10
    ret
.Lssa___sem_view_len_3:
    ldr x10, [x0, #0]
    mov x0, x10
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_data
.weak __fn___sem_view_data.k
__fn___sem_view_data:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_data.k:
__fn___sem_view_data.r:
.Lssa___sem_view_data_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_data_3
.Lssa___sem_view_data_1:
    mov x9, #-2
    add x9, x0, x9
    ldr x10, [x9, #0]
    mov x0, x10
    ret
.Lssa___sem_view_data_3:
    add x0, x0, #8
    ret
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_slice
.weak __fn___sem_byte_view_slice.k
__fn___sem_byte_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_byte_view_slice.k:
__fn___sem_byte_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_byte_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_byte_view_slice_3
.Lssa___sem_byte_view_slice_1:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_byte_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_byte_view_slice_6
.Lssa___sem_byte_view_slice_4:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_byte_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_byte_view_slice_9
.Lssa___sem_byte_view_slice_7:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_byte_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    add x0, x0, x20
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice
.weak __fn___sem_view_slice.k
__fn___sem_view_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice.k:
__fn___sem_view_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_3
.Lssa___sem_view_slice_1:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_6
.Lssa___sem_view_slice_4:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_9
.Lssa___sem_view_slice_7:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_slice_wide
.weak __fn___sem_view_slice_wide.k
__fn___sem_view_slice_wide:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___sem_view_slice_wide.k:
__fn___sem_view_slice_wide.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa___sem_view_slice_wide_0:
    cmp x20, #0
    b.ge .Lssa___sem_view_slice_wide_3
.Lssa___sem_view_slice_wide_1:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_wide_3:
    cmp x21, x20
    b.ge .Lssa___sem_view_slice_wide_6
.Lssa___sem_view_slice_wide_4:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_wide_6:
    mov x0, x19
    bl __fn___sem_view_len.r
    cmp x21, x0
    b.le .Lssa___sem_view_slice_wide_9
.Lssa___sem_view_slice_wide_7:
    bl __fern_slice_abort
    mov x9, x0
.Lssa___sem_view_slice_wide_9:
    mov x0, x19
    bl __fn___sem_view_data.r
    mov w9, w20
    mov x10, #8
    mul x9, x9, x10
    add x0, x0, x9
    sub x21, x21, x20
    str x0, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_str_borrow
    add sp, sp, #32
    add x0, x0, #2
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_view_release
.weak __fn___sem_view_release.k
__fn___sem_view_release:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_view_release.k:
__fn___sem_view_release.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_view_release_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_view_release_3
.Lssa___sem_view_release_1:
    mov x9, #-2
    add x9, x0, x9
    str x9, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_view_release_3:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_view_release_rcdeck6
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_view_release_rcdecd6
    tbnz w5, #31, .Lssa___sem_view_release_rcdeck6
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_view_release_rcdece6
.Lssa___sem_view_release_rcdecd6:
    sub w5, w5, #1
    stur w5, [x0, #-8]
.Lssa___sem_view_release_rcdeck6:
.Lssa___sem_view_release_rcdece6:
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_mismatch
.weak __fn___sem_byte_view_mismatch.k
__fn___sem_byte_view_mismatch:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___sem_byte_view_mismatch.k:
__fn___sem_byte_view_mismatch.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_mismatch_0:
    mov x13, #2
    and x13, x0, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_3
.Lssa___sem_byte_view_mismatch_1:
    mov x13, #2
    and x13, x10, x13
    cbz x13, .Lssa___sem_byte_view_mismatch_6
.Lssa___sem_byte_view_mismatch_4:
    mov x13, #-2
    add x13, x0, x13
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    mov x0, x13
    ldr x5, [x0, #8]
    ldr x0, [x0]
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L210_aop
    mov x1, #0
.L210_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L210_bop
    mov x3, #0
.L210_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L210_nok
    mov x4, #0
.L210_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L210_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L210_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L210_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L210_done
.L210_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L210_vec
.L210_short:
    cmp x10, #8
    b.lt .L210_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L210_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L210_eq
    add x8, x8, x14
.L210_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L210_done
.L210_w4:
    cmp x10, #4
    b.lt .L210_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L210_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L210_eq
    add x8, x8, x14
.L210_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L210_done
.L210_w2:
    cmp x10, #2
    b.lt .L210_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L210_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L210_eq
    add x8, x8, x14
.L210_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L210_done
.L210_tail:
    cmp x8, x13
    b.ge .L210_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L210_th
    add x8, x8, #1
    add x9, x9, #1
    b .L210_tail
.L210_th:
    sub x2, x8, x12
    b .L210_done
.L210_eq:
    mov x2, x4
.L210_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_6:
    mov x15, #-2
    add x15, x0, x15
    mov x4, x12
    mov x3, x9
    mov x2, x15
    mov x1, x11
    mov x0, x10
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L211_aop
    mov x1, #0
.L211_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L211_bop
    mov x3, #0
.L211_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L211_nok
    mov x4, #0
.L211_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L211_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L211_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L211_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L211_done
.L211_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L211_vec
.L211_short:
    cmp x10, #8
    b.lt .L211_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L211_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L211_eq
    add x8, x8, x14
.L211_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L211_done
.L211_w4:
    cmp x10, #4
    b.lt .L211_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L211_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L211_eq
    add x8, x8, x14
.L211_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L211_done
.L211_w2:
    cmp x10, #2
    b.lt .L211_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L211_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L211_eq
    add x8, x8, x14
.L211_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L211_done
.L211_tail:
    cmp x8, x13
    b.ge .L211_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L211_th
    add x8, x8, #1
    add x9, x9, #1
    b .L211_tail
.L211_th:
    sub x2, x8, x12
    b .L211_done
.L211_eq:
    mov x2, x4
.L211_done:
    mov x14, x2
    mov x0, x14
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_3:
    mov x14, #2
    and x14, x10, x14
    cbz x14, .Lssa___sem_byte_view_mismatch_9
.Lssa___sem_byte_view_mismatch_7:
    mov x14, #-2
    add x14, x10, x14
    mov x4, x12
    mov x3, x11
    mov x2, x14
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2, #8]
    ldr x2, [x2]
    cmp x1, #0
    b.ge .L212_aop
    mov x1, #0
.L212_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L212_bop
    mov x3, #0
.L212_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L212_nok
    mov x4, #0
.L212_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L212_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L212_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L212_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L212_done
.L212_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L212_vec
.L212_short:
    cmp x10, #8
    b.lt .L212_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L212_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L212_eq
    add x8, x8, x14
.L212_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L212_done
.L212_w4:
    cmp x10, #4
    b.lt .L212_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L212_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L212_eq
    add x8, x8, x14
.L212_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L212_done
.L212_w2:
    cmp x10, #2
    b.lt .L212_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L212_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L212_eq
    add x8, x8, x14
.L212_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L212_done
.L212_tail:
    cmp x8, x13
    b.ge .L212_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L212_th
    add x8, x8, #1
    add x9, x9, #1
    b .L212_tail
.L212_th:
    sub x2, x8, x12
    b .L212_done
.L212_eq:
    mov x2, x4
.L212_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_mismatch_9:
    mov x4, x12
    mov x3, x11
    mov x2, x10
    mov x1, x9
    ldr x5, [x0]
    add x0, x0, #8
    ldr x6, [x2]
    add x2, x2, #8
    cmp x1, #0
    b.ge .L213_aop
    mov x1, #0
.L213_aop:
    cmp x1, x5
    csel x1, x5, x1, gt
    cmp x3, #0
    b.ge .L213_bop
    mov x3, #0
.L213_bop:
    cmp x3, x6
    csel x3, x6, x3, gt
    sub x5, x5, x1
    sub x6, x6, x3
    cmp x4, x5
    csel x4, x5, x4, gt
    cmp x4, x6
    csel x4, x6, x4, gt
    cmp x4, #0
    b.ge .L213_nok
    mov x4, #0
.L213_nok:
    add x8, x0, x1
    add x9, x2, x3
    mov x12, x8
    add x13, x8, x4
.L213_vec:
    sub x10, x13, x8
    cmp x10, #16
    b.lt .L213_short
    ld1 {v0.16b}, [x8]
    ld1 {v1.16b}, [x9]
    eor v0.16b, v0.16b, v1.16b
    cmtst v0.16b, v0.16b, v0.16b
    shrn v0.8b, v0.8h, #4
    fmov x11, d0
    cbz x11, .L213_next
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #2
    add x8, x8, x11
    sub x2, x8, x12
    b .L213_done
.L213_next:
    add x8, x8, #16
    add x9, x9, #16
    b .L213_vec
.L213_short:
    cmp x10, #8
    b.lt .L213_w4
    ldr x11, [x8]
    ldr x14, [x9]
    eor x11, x11, x14
    cbnz x11, .L213_w8l
    sub x14, x10, #8
    ldr x11, [x8, x14]
    ldr x15, [x9, x14]
    eor x11, x11, x15
    cbz x11, .L213_eq
    add x8, x8, x14
.L213_w8l:
    rbit x11, x11
    clz x11, x11
    lsr x11, x11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L213_done
.L213_w4:
    cmp x10, #4
    b.lt .L213_w2
    ldr w11, [x8]
    ldr w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L213_w4l
    sub x14, x10, #4
    ldr w11, [x8, x14]
    ldr w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L213_eq
    add x8, x8, x14
.L213_w4l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L213_done
.L213_w2:
    cmp x10, #2
    b.lt .L213_tail
    ldrh w11, [x8]
    ldrh w14, [x9]
    eor w11, w11, w14
    cbnz w11, .L213_w2l
    sub x14, x10, #2
    ldrh w11, [x8, x14]
    ldrh w15, [x9, x14]
    eor w11, w11, w15
    cbz w11, .L213_eq
    add x8, x8, x14
.L213_w2l:
    rbit w11, w11
    clz w11, w11
    lsr w11, w11, #3
    add x8, x8, x11
    sub x2, x8, x12
    b .L213_done
.L213_tail:
    cmp x8, x13
    b.ge .L213_eq
    ldrb w11, [x8]
    ldrb w14, [x9]
    cmp w11, w14
    b.ne .L213_th
    add x8, x8, #1
    add x9, x9, #1
    b .L213_tail
.L213_th:
    sub x2, x8, x12
    b .L213_done
.L213_eq:
    mov x2, x4
.L213_done:
    mov x15, x2
    mov x0, x15
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_byte_view_string
.weak __fn___sem_byte_view_string.k
__fn___sem_byte_view_string:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_byte_view_string.k:
__fn___sem_byte_view_string.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_byte_view_string_0:
    mov x9, #2
    and x9, x0, x9
    cbz x9, .Lssa___sem_byte_view_string_3
.Lssa___sem_byte_view_string_1:
    mov x9, #-2
    add x9, x0, x9
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___sem_byte_view_string_3:
    str x0, [sp, #-16]!
    bl __fn___fern_string_from_bytes_u8
    add sp, sp, #16
    mov x11, x0
    mov x0, x11
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
_start:
    adrp x9, .Lfern_relanchor
    add x9, x9, :lo12:.Lfern_relanchor
    ldr x10, [x9]
    sub x9, x9, x10
    cbz x9, .Lfern_reloc_done
    adrp x11, .Lfern_sbox_begin
    add x11, x11, :lo12:.Lfern_sbox_begin
    adrp x12, .Lfern_sbox_end
    add x12, x12, :lo12:.Lfern_sbox_end
.Lfern_sbox_loop:
    cmp x11, x12
    b.hs .Lfern_sbox_done
    ldr x13, [x11, #8]
    add x13, x13, x9
    str x13, [x11, #8]
    add x11, x11, #24
    b .Lfern_sbox_loop
.Lfern_sbox_done:
    adrp x11, .Lfern_cagg_begin
    add x11, x11, :lo12:.Lfern_cagg_begin
    adrp x12, .Lfern_cagg_end
    add x12, x12, :lo12:.Lfern_cagg_end
.Lfern_cagg_loop:
    cmp x11, x12
    b.hs .Lfern_cagg_done
    ldr x13, [x11, #16]
    add x13, x13, x9
    str x13, [x11, #16]
    ldr x14, [x11]
    add x11, x11, #16
    add x11, x11, x14, lsl #3
    b .Lfern_cagg_loop
.Lfern_cagg_done:
    adrp x11, .Lfern_cfn_begin
    add x11, x11, :lo12:.Lfern_cfn_begin
    adrp x12, .Lfern_cfn_end
    add x12, x12, :lo12:.Lfern_cfn_end
.Lfern_cfn_loop:
    cmp x11, x12
    b.hs .Lfern_cfn_done
    ldr x13, [x11, #24]
    add x13, x13, x9
    str x13, [x11, #24]
    add x11, x11, #32
    b .Lfern_cfn_loop
.Lfern_cfn_done:
    adrp x11, .Lfern_cref_begin
    add x11, x11, :lo12:.Lfern_cref_begin
    adrp x12, .Lfern_cref_end
    add x12, x12, :lo12:.Lfern_cref_end
.Lfern_cref_loop:
    cmp x11, x12
    b.hs .Lfern_reloc_done
    ldr x13, [x11]
    add x13, x13, x9
    ldr x14, [x13]
    add x14, x14, x9
    str x14, [x13]
    add x11, x11, #8
    b .Lfern_cref_loop
.Lfern_reloc_done:
    ldr x0, [sp]
    lsl x0, x0, #3
    add x0, x0, #16
    add x0, sp, x0
    adrp x1, __fern_envp
    add x1, x1, :lo12:__fern_envp
    str x0, [x1]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #30
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_stack_kept
    mov x19, x0
    mov x1, #1
    lsl x1, x1, #20
    mov x2, #0
    mov x8, #226
    svc #0
    cbnz x0, .Lfern_stack_guard_failed
    mov x9, #1
    lsl x9, x9, #30
    add x9, x19, x9
    sub sp, x9, #16
    mov x10, sp
    adrp x11, __fern_stack_top
    add x11, x11, :lo12:__fern_stack_top
    str x10, [x11]
.Lfern_stack_kept:
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #16
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_signal_stack_map_failed
    mov x9, #1
    lsl x9, x9, #16
    sub sp, sp, #32
    stp x0, xzr, [sp]
    str x9, [sp, #16]
    mov x0, sp
    mov x1, #0
    mov x8, #132
    svc #0
    cbnz x0, .Lfern_signal_stack_failed
    adrp x9, __fern_segv
    add x9, x9, :lo12:__fern_segv
    mov x10, #4
    movk x10, #0x800, lsl #16
    mov x11, #0
    stp x9, x10, [sp]
    stp x11, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_handler_failed
    add sp, sp, #32
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    bl __fn_main
    mov x8, #94
    svc #0
__fn___fern_str_concat:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_concat.k:
__fn___fern_str_concat.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_concat_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    add x9, x21, x22
    sxtw x23, w9
    mov x0, x23
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    ldr x9, [x19, #0]
    mov x2, x21
    mov x1, x9
    mov x0, x24
    cbz x2, .Lssa___fern_str_concat_mcd18
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb18
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc18:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct18
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc18
.Lssa___fern_str_concat_mct18:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd18
.Lssa___fern_str_concat_mcb18:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb18
.Lssa___fern_str_concat_mcd18:
    mov x0, #0
    sxtw x21, w21
    add x21, x24, x21
    ldr x9, [x20, #0]
    mov x2, x22
    mov x1, x9
    mov x0, x21
    cbz x2, .Lssa___fern_str_concat_mcd34
    cmp x2, #8
    b.lo .Lssa___fern_str_concat_mcb34
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_concat_mc34:
    cmp x0, x10
    b.hs .Lssa___fern_str_concat_mct34
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_concat_mc34
.Lssa___fern_str_concat_mct34:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_concat_mcd34
.Lssa___fern_str_concat_mcb34:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_concat_mcb34
.Lssa___fern_str_concat_mcd34:
    mov x0, #0
    mov x0, x24
    mov x1, x23
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_eq:
    ldr x0, [sp]
    ldr x9, [sp, #16]
__fn___fern_str_eq.r:
    cmp x0, x9
    b.eq .Lseq_yes
    ldr x4, [x0, #8]
    ldr x5, [x9, #8]
    cmp x4, x5
    b.ne .Lseq_no
    ldr x2, [x0]
    ldr x3, [x9]
    cmp x2, x3
    b.eq .Lseq_yes
    add x6, x2, x4
    add x7, x3, x4
    cmp x4, #8
    b.lo .Lseq_short
    sub x6, x6, #8
    sub x7, x7, #8
.Lseq_word:
    ldr x0, [x2]
    ldr x1, [x3]
    cmp x0, x1
    b.ne .Lseq_no
    add x2, x2, #8
    add x3, x3, #8
    cmp x2, x6
    b.lo .Lseq_word
    ldr x0, [x6]
    ldr x1, [x7]
    cmp x0, x1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_short:
    cbz x4, .Lseq_yes
    cmp x4, #4
    b.lo .Lseq_byte
    ldr w0, [x2]
    ldr w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #4
    sub x7, x7, #4
    ldr w0, [x6]
    ldr w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    b .Lseq_yes
.Lseq_byte:
    ldrb w0, [x2]
    ldrb w1, [x3]
    cmp w0, w1
    b.ne .Lseq_no
    sub x6, x6, #1
    sub x7, x7, #1
    ldrb w0, [x6]
    ldrb w1, [x7]
    cmp w0, w1
    b.ne .Lseq_no
    cmp x4, #3
    b.lo .Lseq_yes
    ldrb w0, [x2, #1]
    ldrb w1, [x3, #1]
    cmp w0, w1
    b.ne .Lseq_no
.Lseq_yes:
    mov x0, #1
    ret
.Lseq_no:
    mov x0, #0
    ret
.size __fn___fern_str_eq, .-__fn___fern_str_eq
    .bss
    .align 3
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 3
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 3
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 3
__fern_rc_underflow: .quad 0
    .align 3
__fern_map_seed: .quad 0
    .align 3
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 3
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 3
__fern_freelist_shadow: .skip 524288
    .align 3
__fern_large_freelist_shadow: .skip 20480
    .text
.globl __fern_capw
__fern_capw:
    stp x9, x10, [sp, #-32]!
    str x11, [sp, #16]
    ldr x9, [sp, #32]
    cmp x9, #256
    b.ls .Lcapw_ret
    clz x10, x9
    mov x11, #61
    sub x10, x11, x10
    mov x11, #1
    lsl x11, x11, x10
    add x9, x9, x11
    sub x9, x9, #1
    neg x11, x11
    and x9, x9, x11
    mov x10, #0x10000
    cmp x9, x10
    b.lo .Lcapw_store
    mov x9, #65535
.Lcapw_store:
    str x9, [sp, #32]
.Lcapw_ret:
    ldr x11, [sp, #16]
    ldp x9, x10, [sp], #32
    ret
.globl __fern_alloc
.type __fern_alloc, %function
__fern_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    add x0, x0, #7
    lsr x3, x0, #3
    lsl x0, x3, #3
    mov x2, #0x10000
    cmp x3, x2
    b.hs .Lalloc_large
    cmp x3, #256
    b.ls .L214
    str x3, [sp, #-16]!
    bl __fern_capw
    ldr x3, [sp], #16
.L214:
    lsl x0, x3, #3
    adrp x1, __fern_freelist
    add x1, x1, :lo12:__fern_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_large:
    mov x1, #1
    lsl x1, x1, #34
    cmp x0, x1
    b.hi .Lalloc_nofl
    mov x1, #1
    lsl x1, x1, #19
    cmp x0, x1
    csel x0, x1, x0, lo
    clz x1, x0
    mov x3, #61
    sub x3, x3, x1
    mov x1, #1
    lsl x1, x1, x3
    sub x1, x1, #1
    add x0, x0, x1
    bic x0, x0, x1
    clz x1, x0
    mov x3, #61
    sub x1, x3, x1
    lsr x3, x0, x1
    add x3, x3, x1, lsl #2
    sub x3, x3, #72
    adrp x1, __fern_large_freelist
    add x1, x1, :lo12:__fern_large_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_nofl:
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    ldr x2, [x1]
    cbnz x2, .Lalloc_inited
    stp x4, x5, [sp, #-16]!
    stp x8, x9, [sp, #-16]!
    mov x9, x0
    mov x0, #1
    lsl x0, x0, #28
    movz x1, #0
    movk x1, #4, lsl #32
    mov x2, #3
    mov x3, #0x4022
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    cmn x0, #0
    b.mi .Lalloc_map_fail
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    str x0, [x1]
    adrp x1, __fern_heap_base
    add x1, x1, :lo12:__fern_heap_base
    str x0, [x1]
    movz x2, #0
    movk x2, #4, lsl #32
    add x2, x0, x2
    adrp x3, __fern_heap_end
    add x3, x3, :lo12:__fern_heap_end
    str x2, [x3]
    mov x0, x9
    ldp x8, x9, [sp], #16
    ldp x4, x5, [sp], #16
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
.Lalloc_inited:
    ldr x2, [x1]
    adds x3, x2, x0
    b.cs __fern_alloc_size_abort
    str x4, [sp, #-16]!
    adrp x4, __fern_heap_end
    add x4, x4, :lo12:__fern_heap_end
    ldr x4, [x4]
    cmp x3, x4
    ldr x4, [sp], #16
    b.hi .Lalloc_oom
    str x3, [x1]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .text
.Lalloc_oom:
    adrp x1, .Lmsg_oom
    add x1, x1, :lo12:.Lmsg_oom
    mov x2, #43
    mov x0, #125
    b __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .text
.Lalloc_map_fail:
    neg x9, x0
    sub sp, sp, #96
    add x10, sp, #96
    mov x12, #10
    sub x10, x10, #1
    strb w12, [x10]
    mov x11, #41
    sub x10, x10, #1
    strb w11, [x10]
.Lmap_fail_digit:
    udiv x13, x9, x12
    msub x14, x13, x12, x9
    add x14, x14, #48
    sub x10, x10, #1
    strb w14, [x10]
    mov x9, x13
    cbnz x9, .Lmap_fail_digit
    adrp x15, .Lmsg_map_fail
    add x15, x15, :lo12:.Lmsg_map_fail
    add x15, x15, #42
    mov x11, #42
.Lmap_fail_copy:
    sub x15, x15, #1
    ldrb w14, [x15]
    sub x10, x10, #1
    strb w14, [x10]
    subs x11, x11, #1
    b.ne .Lmap_fail_copy
    mov x1, x10
    add x2, sp, #96
    sub x2, x2, x10
    mov x0, #123
    b __fern_report
.size __fern_alloc, .-__fern_alloc
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .text
__fern_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_oob_abort
.type __fern_oob_abort, %function
__fern_oob_abort:
    adrp x1, .Lmsg_arr_oob
    add x1, x1, :lo12:.Lmsg_arr_oob
    mov x2, #31
    b __fern_abort_134
.size __fern_oob_abort, .-__fern_oob_abort
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .text
__fern_str_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_str_oob_abort
.type __fern_str_oob_abort, %function
__fern_str_oob_abort:
    adrp x1, .Lmsg_str_oob
    add x1, x1, :lo12:.Lmsg_str_oob
    mov x2, #32
    b __fern_abort_134
.size __fern_str_oob_abort, .-__fern_str_oob_abort
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .text
__fern_slice_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_slice_abort
.type __fern_slice_abort, %function
__fern_slice_abort:
    adrp x1, .Lmsg_slice
    add x1, x1, :lo12:.Lmsg_slice
    mov x2, #32
    b __fern_abort_134
.size __fern_slice_abort, .-__fern_slice_abort
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .text
__fern_alloc_size_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_alloc_size_abort
.type __fern_alloc_size_abort, %function
__fern_alloc_size_abort:
    adrp x1, .Lmsg_alloc_size
    add x1, x1, :lo12:.Lmsg_alloc_size
    mov x2, #35
    b __fern_abort_134
.size __fern_alloc_size_abort, .-__fern_alloc_size_abort
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .text
.globl __fern_free_range_abort
.type __fern_free_range_abort, %function
__fern_free_range_abort:
    adrp x1, .Lmsg_free_range
    add x1, x1, :lo12:.Lmsg_free_range
    mov x2, #41
    b __fern_abort_134
.size __fern_free_range_abort, .-__fern_free_range_abort
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .text
__fern_double_free_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_double_free_abort
.type __fern_double_free_abort, %function
__fern_double_free_abort:
    adrp x1, .Lmsg_double_free
    add x1, x1, :lo12:.Lmsg_double_free
    mov x2, #45
    b __fern_abort_134
.size __fern_double_free_abort, .-__fern_double_free_abort
__fern_arr_box:
    movz x1, #65535
    movk x1, #4095, lsl #16
    cmp x0, x1
    b.ls .Larrbox_sized
    b __fern_alloc_size_abort_leaf
.Larrbox_sized:
    add x1, x0, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Larrbox_alloc
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    add x1, x2, x1
    ldr x2, [x1]
    cbz x2, .Larrbox_miss
    ldr x3, [x2]
    str x3, [x1]
    str x0, [x2]
    mov w3, #1
    str w3, [x2, #8]
    str x0, [x2, #16]
    add x0, x2, #16
    ret
.Larrbox_miss:
    add x1, x0, #3
    lsl x1, x1, #3
.Larrbox_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    mov x0, x1
    bl __fern_alloc
    ldr x1, [sp]
    str x1, [x0]
    mov w2, #1
    str w2, [x0, #8]
    str x1, [x0, #16]
    add x0, x0, #16
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
__fern_str_box:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x0, #24
    bl __fern_alloc
    mov x2, #1
    str x2, [x0]
    ldp x2, x3, [sp], #16
    str x2, [x0, #8]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fern_str_box_hdr:
    sub x2, x0, #24
    mov w3, #1
    str w3, [x2]
    mov w4, #32781
    movk w4, #29519, lsl #16
    stur w4, [x2, #4]
    str x0, [x2, #8]
    str x1, [x2, #16]
    add x0, x2, #8
    ret
.globl __fern_buf_new
.type __fern_buf_new, %function
__fern_buf_new:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cmp x19, #16
    b.hs .Lbufnew_cap
    mov x19, #16
.Lbufnew_cap:
    mov x0, #32
    bl __fern_alloc
    mov x20, x0
    mov x0, x19
    bl __fern_alloc
    str x0, [x20]
    str xzr, [x20, #8]
    str x19, [x20, #16]
    str x19, [x20, #24]
    mov x0, x20
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_new, .-__fern_buf_new
.globl __fern_buf_reserve
.type __fern_buf_reserve, %function
__fern_buf_reserve:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19, #16]
    cbnz x21, .Lbufres_dbl
    ldr x21, [x19, #24]
    cbnz x21, .Lbufres_dbl
    mov x21, #64
.Lbufres_dbl:
    cmp x21, x20
    b.hs .Lbufres_alloc
    lsl x21, x21, #1
    b .Lbufres_dbl
.Lbufres_alloc:
    mov x0, x21
    bl __fern_alloc
    mov x22, x0
    ldr x2, [x19, #8]
    cbz x2, .Lbufres_nocopy
    ldr x1, [x19]
    mov x3, x22
    cbz x2, .Lbufres_copy_d
    cmp x2, #8
    b.lo .Lbufres_copy_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x3, x2
    sub x11, x11, #8
.Lbufres_copy_w:
    cmp x3, x11
    b.hs .Lbufres_copy_t
    ldr x9, [x1], #8
    str x9, [x3], #8
    b .Lbufres_copy_w
.Lbufres_copy_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufres_copy_d
.Lbufres_copy_b:
    ldrb w9, [x1], #1
    strb w9, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufres_copy_b
.Lbufres_copy_d:
.Lbufres_nocopy:
    ldr x5, [x19]
    cbz x5, .Lbufres_store
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbufres_old_large
    cmp x6, #256
    b.ls .L215
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L215:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbufres_old_done
.Lbufres_old_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbufres_old_done:
.Lbufres_store:
    str x22, [x19]
    str x21, [x19, #16]
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_reserve, .-__fern_buf_reserve
.globl __fern_buf_push
.type __fern_buf_push, %function
__fern_buf_push:
    ldrsw x3, [x1, #8]
    cbz x3, .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufpush_grow
    str x5, [x0, #8]
    ldr x1, [x1]
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
    b .Lbufrange_tail
.Lbufpush_grow:
    mov x2, #0
    b .Lbufrange_grow
.size __fern_buf_push, .-__fern_buf_push
.globl __fern_buf_push_range
.type __fern_buf_push_range, %function
__fern_buf_push_range:
    sxtw x2, w2
    sxtw x3, w3
    tbz x2, #63, .Lbufrange_lo
    b __fern_slice_abort_leaf
.Lbufrange_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lbufrange_hi
    b __fern_slice_abort_leaf
.Lbufrange_hi:
    subs x3, x3, x2
    b.ge .Lbufrange_range
    b __fern_slice_abort_leaf
.Lbufrange_range:
    b.eq .Lbufrange_done
    ldr x4, [x0, #8]
    add x5, x4, x3
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufrange_grow
.Lbufrange_copy:
    str x5, [x0, #8]
    ldr x1, [x1]
    add x1, x1, x2
    ldr x6, [x0]
    add x6, x6, x4
    mov x2, x3
.Lbufrange_tail:
    cbz x2, .Lbufrange_done
    cmp x2, #8
    b.lo .Lbufrange_loop_b
    add x10, x1, x2
    sub x10, x10, #8
    add x11, x6, x2
    sub x11, x11, #8
.Lbufrange_loop_w:
    cmp x6, x11
    b.hs .Lbufrange_loop_t
    ldr x9, [x1], #8
    str x9, [x6], #8
    b .Lbufrange_loop_w
.Lbufrange_loop_t:
    ldr x9, [x10]
    str x9, [x11]
    b .Lbufrange_done
.Lbufrange_loop_b:
    ldrb w9, [x1], #1
    strb w9, [x6], #1
    sub x2, x2, #1
    cbnz x2, .Lbufrange_loop_b
.Lbufrange_done:
    ret
.Lbufrange_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    stp x2, x3, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x2, x3, [sp], #16
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, x3
    b .Lbufrange_copy
.size __fern_buf_push_range, .-__fern_buf_push_range
.globl __fern_buf_push_mapped
.type __fern_buf_push_mapped, %function
__fern_buf_push_mapped:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    mov x21, x2
    ldr x22, [x20, #8]
    cbz x22, .Lbufmap_done
    ldr x0, [x19, #8]
    add x0, x0, x22
    ldr x1, [x19, #16]
    cmp x0, x1
    b.ls .Lbufmap_fits
    mov x1, x0
    mov x0, x19
    bl __fern_buf_reserve
.Lbufmap_fits:
    ldr x1, [x20]
    ldr x3, [x19]
    ldr x4, [x19, #8]
    add x3, x3, x4
    ldr x4, [x21]
    mov x2, x22
    cmp x4, #256
    b.lo .Lbufmap_short
.Lbufmap_full:
    ldrb w5, [x1], #1
    add x6, x21, x5, lsl #3
    ldrb w5, [x6, #8]
    strb w5, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufmap_full
    b .Lbufmap_len
.Lbufmap_short:
    ldrb w5, [x1], #1
    cmp x5, x4
    b.hs .Lbufmap_keep
    add x6, x21, x5, lsl #3
    ldrb w5, [x6, #8]
.Lbufmap_keep:
    strb w5, [x3], #1
    sub x2, x2, #1
    cbnz x2, .Lbufmap_short
.Lbufmap_len:
    ldr x0, [x19, #8]
    add x0, x0, x22
    str x0, [x19, #8]
.Lbufmap_done:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_push_mapped, .-__fern_buf_push_mapped
.globl __fern_buf_push_filtered
.type __fern_buf_push_filtered, %function
__fern_buf_push_filtered:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    mov x21, x2
    ldr x22, [x20, #8]
    cbz x22, .Lbuffilt_done
    ldr x0, [x19, #8]
    add x0, x0, x22
    ldr x1, [x19, #16]
    cmp x0, x1
    b.ls .Lbuffilt_fits
    mov x1, x0
    mov x0, x19
    bl __fern_buf_reserve
.Lbuffilt_fits:
    ldr x1, [x20]
    ldr x3, [x19]
    ldr x4, [x19, #8]
    add x3, x3, x4
    ldr x4, [x21]
    mov x2, x22
    mov x7, #0
    cmp x4, #256
    b.lo .Lbuffilt_loop
.Lbuffilt_full:
    ldrb w5, [x1], #1
    add x6, x21, x5, lsl #3
    ldrb w6, [x6, #8]
    strb w5, [x3, x7]
    cmp w6, #0
    cinc x7, x7, eq
    sub x2, x2, #1
    cbnz x2, .Lbuffilt_full
    b .Lbuffilt_len
.Lbuffilt_loop:
    ldrb w5, [x1], #1
    cmp x5, x4
    b.hs .Lbuffilt_keep
    add x6, x21, x5, lsl #3
    ldrb w6, [x6, #8]
    cbnz w6, .Lbuffilt_next
.Lbuffilt_keep:
    strb w5, [x3], #1
    add x7, x7, #1
.Lbuffilt_next:
    sub x2, x2, #1
    cbnz x2, .Lbuffilt_loop
.Lbuffilt_len:
    ldr x0, [x19, #8]
    add x0, x0, x7
    str x0, [x19, #8]
.Lbuffilt_done:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_push_filtered, .-__fern_buf_push_filtered
.globl __fern_buf_push_expanded
.type __fern_buf_push_expanded, %function
__fern_buf_push_expanded:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    mov x21, x2
    ldr x22, [x20, #8]
    cbz x22, .Lbufexp_done
    lsl x0, x22, #3
    add x0, x0, #8
    ldr x1, [x19, #8]
    add x0, x0, x1
    ldr x1, [x19, #16]
    cmp x0, x1
    b.ls .Lbufexp_fits
    mov x1, x0
    mov x0, x19
    bl __fern_buf_reserve
.Lbufexp_fits:
    ldr x1, [x20]
    ldr x3, [x19]
    ldr x4, [x19, #8]
    add x3, x3, x4
    ldr x4, [x21]
    lsr x4, x4, #3
    mov x2, x22
    cmp x4, #256
    b.lo .Lbufexp_loop
    cmp x2, #256
    b.lo .Lbufexp_loop
    sub sp, sp, #2048
    add x6, x21, #8
    mov x7, #0
.Lbufexp_pack:
    ldr x8, [x6, x7, lsl #3]
    strb w8, [sp, x7]
    add x7, x7, #1
    cmp x7, #2048
    b.lo .Lbufexp_pack
    mov x9, #7
.Lbufexp_fast:
    ldrb w5, [x1], #1
    ldr x8, [sp, x5, lsl #3]
    and x7, x8, #255
    cmp x7, x9
    csel x7, x7, x9, ls
    lsr x8, x8, #8
    str x8, [x3]
    add x3, x3, x7
    subs x2, x2, #1
    b.ne .Lbufexp_fast
    add sp, sp, #2048
    b .Lbufexp_len
.Lbufexp_loop:
    cbz x2, .Lbufexp_len
    ldrb w5, [x1], #1
    cmp x5, x4
    b.hs .Lbufexp_keep
    add x6, x21, x5, lsl #6
    ldr x7, [x6, #8]
    cmp x7, #7
    b.ls .Lbufexp_room
    mov x7, #7
.Lbufexp_room:
    add x6, x6, #16
.Lbufexp_byte:
    cbz x7, .Lbufexp_next
    ldr x8, [x6], #8
    strb w8, [x3], #1
    sub x7, x7, #1
    b .Lbufexp_byte
.Lbufexp_keep:
    strb w5, [x3], #1
.Lbufexp_next:
    sub x2, x2, #1
    b .Lbufexp_loop
.Lbufexp_len:
    ldr x0, [x19]
    sub x3, x3, x0
    str x3, [x19, #8]
.Lbufexp_done:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_push_expanded, .-__fern_buf_push_expanded
.globl __fern_buf_push_byte
.type __fern_buf_push_byte, %function
__fern_buf_push_byte:
    ldr x4, [x0, #8]
    add x5, x4, #1
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufbyte_grow
.Lbufbyte_fits:
    ldr x6, [x0]
    strb w1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufbyte_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #1
    b .Lbufbyte_fits
.size __fern_buf_push_byte, .-__fern_buf_push_byte
.globl __fern_buf_push_u64
.type __fern_buf_push_u64, %function
__fern_buf_push_u64:
    ldr x4, [x0, #8]
    add x5, x4, #8
    ldr x6, [x0, #16]
    cmp x5, x6
    b.hi .Lbufu64_grow
.Lbufu64_fits:
    ldr x6, [x0]
    str x1, [x6, x4]
    str x5, [x0, #8]
    ret
.Lbufu64_grow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x1, x5
    bl __fern_buf_reserve
    ldp x0, x1, [sp], #16
    ldp x29, x30, [sp], #16
    ldr x4, [x0, #8]
    add x5, x4, #8
    b .Lbufu64_fits
.size __fern_buf_push_u64, .-__fern_buf_push_u64
.globl __fern_buf_push_decimal
.type __fern_buf_push_decimal, %function
__fern_buf_push_decimal:
    stp x29, x30, [sp, #-64]!
    mov x29, sp
    add x8, sp, #40
    adrp x11, .Ldecimal_pairs
    add x11, x11, :lo12:.Ldecimal_pairs
    mov x9, #0xf5c3
    movk x9, #0x5c28, lsl #16
    movk x9, #0xc28f, lsl #32
    movk x9, #0x28f5, lsl #48
    mov x12, #100
.Ldecimal_loop:
    cmp x1, #100
    b.lo .Ldecimal_tail
    lsr x10, x1, #2
    umulh x10, x10, x9
    lsr x10, x10, #2
    msub x13, x10, x12, x1
    ldrh w13, [x11, x13, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    mov x1, x10
    b .Ldecimal_loop
.Ldecimal_tail:
    cmp x1, #10
    b.lo .Ldecimal_one
    ldrh w13, [x11, x1, lsl #1]
    sub x8, x8, #2
    strh w13, [x8]
    b .Ldecimal_copy
.Ldecimal_one:
    add w13, w1, #48
    sub x8, x8, #1
    strb w13, [x8]
.Ldecimal_copy:
    add x2, sp, #40
    sub x2, x2, x8
    ldr x3, [x0, #8]
    add x4, x3, x2
    ldr x5, [x0, #16]
    cmp x4, x5
    b.hi .Ldecimal_grow
.Ldecimal_fits:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x3
.Ldecimal_byte:
    ldrb w6, [x8], #1
    strb w6, [x5], #1
    subs x2, x2, #1
    b.ne .Ldecimal_byte
    ldp x29, x30, [sp], #64
    ret
.Ldecimal_grow:
    str x0, [sp, #40]
    stp x2, x8, [sp, #48]
    mov x1, x4
    bl __fern_buf_reserve
    ldr x0, [sp, #40]
    ldp x2, x8, [sp, #48]
    ldr x3, [x0, #8]
    add x4, x3, x2
    b .Ldecimal_fits
.size __fern_buf_push_decimal, .-__fern_buf_push_decimal
    .section .rodata
.Ldecimal_pairs:
    .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
    .text
.globl __fern_buf_len
.type __fern_buf_len, %function
__fern_buf_len:
    ldr x0, [x0, #8]
    ret
.size __fern_buf_len, .-__fern_buf_len
.globl __fern_buf_clear
.type __fern_buf_clear, %function
__fern_buf_clear:
    str xzr, [x0, #8]
    mov x0, #0
    ret
.size __fern_buf_clear, .-__fern_buf_clear
.globl __fern_buf_take
.type __fern_buf_take, %function
__fern_buf_take:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    bl __fn___fern_buf_take_text
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_take, .-__fern_buf_take
__fn___fern_buf_text_part:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_buf_text_part.k:
__fn___fern_buf_text_part.r:
.Lssa___fern_buf_text_part_0:
    ldrb w11, [x0, x9]
    cmp x11, #128
    b.ge .Lssa___fern_buf_text_part_20
.Lssa___fern_buf_text_part_22:
    mov x0, #1
    ret
.Lssa___fern_buf_text_part_20:
    cmp x11, #194
    b.lt .Lssa___fern_buf_text_part_17
.Lssa___fern_buf_text_part_19:
    cmp x11, #223
    b.gt .Lssa___fern_buf_text_part_17
.Lssa___fern_buf_text_part_18:
    mov x12, #2
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_17:
    cmp x11, #224
    b.lt .Lssa___fern_buf_text_part_14
.Lssa___fern_buf_text_part_16:
    cmp x11, #239
    b.gt .Lssa___fern_buf_text_part_14
.Lssa___fern_buf_text_part_15:
    mov x12, #3
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_14:
    cmp x11, #240
    b.lt .Lssa___fern_buf_text_part_11
.Lssa___fern_buf_text_part_13:
    cmp x11, #244
    b.gt .Lssa___fern_buf_text_part_11
.Lssa___fern_buf_text_part_12:
    mov x12, #4
    b .Lssa___fern_buf_text_part_8
.Lssa___fern_buf_text_part_11:
    mov x12, #0
.Lssa___fern_buf_text_part_10:
.Lssa___fern_buf_text_part_9:
.Lssa___fern_buf_text_part_8:
.Lssa___fern_buf_text_part_7:
    sub x10, x10, x9
    sxtw x10, w10
    mov x13, #1
.Lssa___fern_buf_text_part_54:
    cmp x13, x12
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_69:
    cmp x13, x10
    b.ge .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_68:
    add x14, x9, x13
    sxtw x14, w14
    ldrb w15, [x0, x14]
    cmp x15, #128
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_67:
    cmp x15, #191
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_65:
    cmp x13, #1
    b.ne .Lssa___fern_buf_text_part_55
.Lssa___fern_buf_text_part_64:
    cmp x11, #224
    b.ne .Lssa___fern_buf_text_part_62
.Lssa___fern_buf_text_part_63:
    cmp x15, #160
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_62:
    cmp x11, #237
    b.ne .Lssa___fern_buf_text_part_60
.Lssa___fern_buf_text_part_61:
    cmp x15, #159
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_60:
    cmp x11, #240
    b.ne .Lssa___fern_buf_text_part_58
.Lssa___fern_buf_text_part_59:
    cmp x15, #144
    b.lt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_58:
    cmp x11, #244
    b.ne .Lssa___fern_buf_text_part_55
.Lssa___fern_buf_text_part_57:
    cmp x15, #143
    b.gt .Lssa___fern_buf_text_part_4
.Lssa___fern_buf_text_part_55:
    add x13, x13, #1
    cmp x13, x12
    b.lt .Lssa___fern_buf_text_part_69
.Lssa___fern_buf_text_part_4:
    mov x10, #0
    sub x10, x10, x13
    sxtw x10, w10
    cmp x13, x12
    csel x0, x13, x10, eq
    ret
    .cfi_endproc
    .ltorg
__fn___fern_buf_take_text:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_buf_take_text.k:
__fn___fern_buf_take_text.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x0
.Lssa___fern_buf_take_text_0:
    ldr x20, [x19, #8]
    cmp x20, #0
    b.lt .Lssa___fern_buf_take_text_16
.Lssa___fern_buf_take_text_17:
    movn w9, #32768, lsl #16
    cmp x20, x9
    b.le .Lssa___fern_buf_take_text_14
.Lssa___fern_buf_take_text_16:
    mov x9, #-1
    mov x0, x9
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x9, #0
    mov x1, x9
    bl __fern_str_box_hdr
    mov x10, x0
    mov x0, x10
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_14:
    sxtw x21, w20
    cmp x21, #0
    b.ne .Lssa___fern_buf_take_text_11
.Lssa___fern_buf_take_text_13:
    adrp x0, .SB4
    add x0, x0, :lo12:.SB4
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_11:
    ldr x22, [x19, #0]
    ldr x23, =9259542123273814144
.Lssa___fern_buf_take_text_10:
    mov x24, #0
    mov x25, #0
.Lssa___fern_buf_take_text_30:
    cmp x24, x21
    b.ge .Lssa___fern_buf_take_text_9
.Lssa___fern_buf_take_text_40:
    sub x10, x21, x24
    sxtw x10, w10
    cmp x10, #8
    b.lt .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_39:
    add x10, x22, x24
    ldr x9, [x10, #0]
    and x9, x9, x23
    cmp x9, #0
    b.ne .Lssa___fern_buf_take_text_34
.Lssa___fern_buf_take_text_38:
    add x9, x24, #8
    sxtw x24, w9
    cmp x24, x21
    b.ge .Lssa___fern_buf_take_text_9
    b .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_34:
    mov x0, x22
    mov x9, x24
    mov x10, x21
    bl __fn___fern_buf_text_part.r
    cmp x0, #0
    b.ge .Lssa___fern_buf_take_text_32
.Lssa___fern_buf_take_text_33:
    add x9, x0, #3
    sxtw x9, w9
    add x9, x20, x9
    sub x10, x24, x0
    sxtw x10, w10
    mov x20, x9
    mov x24, x10
    mov x25, #1
    b .Lssa___fern_buf_take_text_30
.Lssa___fern_buf_take_text_32:
    add x24, x24, x0
    sxtw x24, w24
.Lssa___fern_buf_take_text_31:
    cmp x24, x21
    b.lt .Lssa___fern_buf_take_text_40
.Lssa___fern_buf_take_text_9:
    movn w10, #32768, lsl #16
    cmp x20, x10
    b.le .Lssa___fern_buf_take_text_6
.Lssa___fern_buf_take_text_8:
    mov x10, #-1
    mov x0, x10
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x10, #0
    mov x1, x10
    bl __fern_str_box_hdr
    mov x9, x0
    mov x0, x9
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_buf_take_text_6:
    sxtw x20, w20
    mov x0, x20
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x24, x0
    cbz x25, .Lssa___fern_buf_take_text_2
.Lssa___fern_buf_take_text_5:
.Lssa___fern_buf_take_text_4:
    mov x25, #0
    mov x26, #0
    mov x27, #0
.Lssa___fern_buf_take_text_70:
    cmp x25, x21
    b.ge .Lssa___fern_buf_take_text_3
.Lssa___fern_buf_take_text_80:
    sub x9, x21, x25
    sxtw x9, w9
    cmp x9, #8
    b.lt .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_79:
    add x9, x22, x25
    ldr x10, [x9, #0]
    and x10, x10, x23
    cmp x10, #0
    b.ne .Lssa___fern_buf_take_text_74
.Lssa___fern_buf_take_text_78:
    add x10, x25, #8
    sxtw x25, w10
    cmp x25, x21
    b.ge .Lssa___fern_buf_take_text_3
    b .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_74:
    mov x0, x22
    mov x9, x25
    mov x10, x21
    bl __fn___fern_buf_text_part.r
    mov x28, x0
    cmp x28, #0
    b.ge .Lssa___fern_buf_take_text_72
.Lssa___fern_buf_take_text_73:
    sxtw x10, w27
    add x10, x24, x10
    add x9, x22, x26
    sub x11, x25, x26
    sxtw x11, w11
    str x11, [sp, #56]
    mov x2, x11
    mov x1, x9
    mov x0, x10
    cbz x2, .Lssa___fern_buf_take_text_mcd338
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb338
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc338:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct338
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc338
.Lssa___fern_buf_take_text_mct338:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd338
.Lssa___fern_buf_take_text_mcb338:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb338
.Lssa___fern_buf_take_text_mcd338:
    mov x0, #0
    ldr x11, [sp, #56]
    add x11, x27, x11
    sxtw x11, w11
    mov x9, #239
    strb w9, [x24, x11]
    add x10, x11, #1
    sxtw x10, w10
    mov x9, #191
    strb w9, [x24, x10]
    add x12, x11, #2
    sxtw x12, w12
    mov x9, #189
    strb w9, [x24, x12]
    add x11, x11, #3
    sub x10, x25, x28
    sxtw x10, w10
    mov x25, x10
    mov x26, x10
    mov x27, x11
    b .Lssa___fern_buf_take_text_70
.Lssa___fern_buf_take_text_72:
    add x25, x25, x28
    sxtw x25, w25
.Lssa___fern_buf_take_text_71:
    cmp x25, x21
    b.lt .Lssa___fern_buf_take_text_80
.Lssa___fern_buf_take_text_3:
    sxtw x27, w27
    add x27, x24, x27
    add x10, x22, x26
    sub x26, x21, x26
    sxtw x26, w26
    mov x2, x26
    mov x1, x10
    mov x0, x27
    cbz x2, .Lssa___fern_buf_take_text_mcd435
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb435
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc435:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct435
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc435
.Lssa___fern_buf_take_text_mct435:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd435
.Lssa___fern_buf_take_text_mcb435:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb435
.Lssa___fern_buf_take_text_mcd435:
    mov x0, #0
    b .Lssa___fern_buf_take_text_1
.Lssa___fern_buf_take_text_2:
    mov x2, x21
    mov x1, x22
    mov x0, x24
    cbz x2, .Lssa___fern_buf_take_text_mcd442
    cmp x2, #8
    b.lo .Lssa___fern_buf_take_text_mcb442
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_buf_take_text_mc442:
    cmp x0, x10
    b.hs .Lssa___fern_buf_take_text_mct442
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_buf_take_text_mc442
.Lssa___fern_buf_take_text_mct442:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_buf_take_text_mcd442
.Lssa___fern_buf_take_text_mcb442:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_buf_take_text_mcb442
.Lssa___fern_buf_take_text_mcd442:
    mov x0, #0
.Lssa___fern_buf_take_text_1:
    mov x10, #0
    str x10, [x19, #8]
    mov x0, x24
    mov x1, x20
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.globl __fern_buf_free
.type __fern_buf_free, %function
__fern_buf_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    cbz x19, .Lbuffree_ret
    ldr x5, [x19]
    cbz x5, .Lbuffree_ctl
    ldr x6, [x19, #16]
    add x6, x6, #7
    lsr x6, x6, #3
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_data_large
    cmp x6, #256
    b.ls .L216
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L216:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbuffree_data_done
.Lbuffree_data_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbuffree_data_done:
.Lbuffree_ctl:
    mov x5, x19
    mov x6, #4
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lbuffree_ctlblk_large
    cmp x6, #256
    b.ls .L217
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
.L217:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x6, lsl #3]
    str x10, [x5]
    str x5, [x3, x6, lsl #3]
    b .Lbuffree_ctlblk_done
.Lbuffree_ctlblk_large:
    mov x1, x5
    lsl x2, x6, #3
    bl __fern_large_push
.Lbuffree_ctlblk_done:
.Lbuffree_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.size __fern_buf_free, .-__fern_buf_free
__fn___alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    bl __fern_alloc
    ldp x29, x30, [sp], #16
    ret
__fn___free:
    ret
__fn___memset:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    ldr x2, [x29, #48]
    cbz x2, .Lfnmemset_done
.Lfnmemset_loop:
    strb w1, [x0], #1
    subs x2, x2, #1
    bne .Lfnmemset_loop
.Lfnmemset_done:
    ldp x29, x30, [sp], #16
    ret
__fn___load_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldrsw x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str w1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_i64:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str x1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___ptr_width:
    mov x0, #8
    ret
__fn___fern_rc_inc:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcinc_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcinc_ret
    and x0, x0, #0xfffffffffffffffd
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcinc_ret
    add w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcinc_ret:
    ldr x0, [sp]
    ret
__fn___fern_rc_dec:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcdec_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcdec_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcdec_ret
    cmp w1, #0
    bgt .Lshrcdec_dec
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w11, [x10]
    add w11, w11, #1
    str w11, [x10]
.Lshrcdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcdec_ret:
    ret
__fn___fern_rc_is_unique:
    ldr x2, [sp]
    mov x0, #0
    tbnz x2, #0, .Lshuniq_ret
    mov x9, #0x10000
    cmp x2, x9
    blo .Lshuniq_ret
    and x2, x2, #0xfffffffffffffffd
    ldur w3, [x2, #-8]
    tbnz w3, #31, .Lshuniq_ret
    cmp w3, #1
    bne .Lshuniq_ret
    mov x0, #1
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    ldr x0, [sp]
__fn___fern_arr_inc_elems.r:
    mov x9, #0x10000
    cmp x0, x9
    blo .Laie_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Laie_ret
    stp x19, x30, [sp, #-16]!
    stp x20, x21, [sp, #-16]!
    mov x19, x0
    ldr x20, [x19]
    mov x21, #0
.Laie_loop:
    cmp x21, x20
    bge .Laie_done
    add x9, x21, #1
    ldr x0, [x19, x9, lsl #3]
    str x0, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    add x21, x21, #1
    b .Laie_loop
.Laie_done:
    mov x0, x19
    ldp x20, x21, [sp], #16
    ldp x19, x30, [sp], #16
.Laie_ret:
    ret
__fn___fern_str_grow:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsg_body
__fn___fern_str_grow_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbnz x2, #63, .Lsg_no
    ldr x4, [x1, #8]
    cmp x3, x4
    b.gt .Lsg_no
    subs x3, x3, x2
    b.lt .Lsg_no
    ldr x1, [x1]
    add x1, x1, x2
.Lsg_body:
    tbnz x0, #0, .Lsg_no
    mov x9, #0x10000
    cmp x0, x9
    blo .Lsg_no
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.ne .Lsg_no
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbnz x9, .Lsg_no
    ldur w5, [x0, #-4]
    mov w6, #0x4F57
    movk w6, #0x4752, lsl #16
    cmp w5, w6
    b.ne .Lsg_fused
    add x6, x4, #39
    lsr x6, x6, #3
    ldur x7, [x0, #-16]
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_copy
.Lsg_fused:
    mov w6, #32781
    movk w6, #29519, lsl #16
    cmp w5, w6
    b.ne .Lsg_no
    add x5, x2, #31
    lsr x5, x5, #3
    add x6, x4, #31
    lsr x6, x6, #3
    cmp x6, x5
    b.eq .Lsg_copy
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lsg_large
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x7, x30, [sp], #16
    cmp x6, x7
    b.hi .Lsg_no
    b .Lsg_fits
.Lsg_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsg_no
    lsl x7, x5, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x7, x7, #3
    cmp x6, x7
    b.hi .Lsg_no
.Lsg_fits:
.Lsg_copy:
    str x4, [x0, #8]
    ldr x5, [x0]
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsg_d
    cmp x3, #8
    b.lo .Lsg_b
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsg_w:
    cmp x5, x10
    b.hs .Lsg_t
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsg_w
.Lsg_t:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsg_d
.Lsg_b:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsg_b
.Lsg_d:
    mov x0, #1
    ret
.Lsg_no:
    mov x0, #0
    ret
__fn___fern_str_grow_fresh:
    ldr x0, [sp, #16]
    ldr x1, [sp]
    ldr x3, [x1, #8]
    ldr x1, [x1]
    b .Lsgf_body
__fn___fern_str_grow_fresh_range:
    ldr x0, [sp, #48]
    ldr x1, [sp, #32]
    ldrsw x2, [sp, #16]
    ldrsw x3, [sp]
    tbz x2, #63, .Lsgf_lo
    b __fern_slice_abort_leaf
.Lsgf_lo:
    ldr x4, [x1, #8]
    cmp x3, x4
    b.le .Lsgf_hi
    b __fern_slice_abort_leaf
.Lsgf_hi:
    subs x3, x3, x2
    b.ge .Lsgf_range
    b __fern_slice_abort_leaf
.Lsgf_range:
    ldr x1, [x1]
    add x1, x1, x2
.Lsgf_body:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x2, [x0, #8]
    add x4, x2, x3
    lsr x9, x4, #31
    cbz x9, .Lsgf_sized
    b __fern_alloc_size_abort
.Lsgf_sized:
    add x5, x4, #39
    lsr x5, x5, #3
    add x6, x2, #31
    lsr x6, x6, #3
    lsl x6, x6, #1
    cmp x6, x5
    csel x6, x5, x6, lo
    mov x9, #0x10000
    cmp x6, x9
    b.hs .Lsgf_large
    stp x6, x30, [sp, #-16]!
    bl __fern_capw
    ldp x6, x30, [sp], #16
    b .Lsgf_alloc
.Lsgf_large:
    mov x9, #1
    lsl x9, x9, #27
    cmp x6, x9
    b.hi .Lsgf_alloc
    lsl x7, x6, #3
    mov x11, #1
    lsl x11, x11, #19
    cmp x7, x11
    csel x7, x11, x7, lo
    clz x11, x7
    mov x10, #61
    sub x10, x10, x11
    mov x11, #1
    lsl x11, x11, x10
    sub x11, x11, #1
    add x7, x7, x11
    bic x7, x7, x11
    clz x11, x7
    mov x10, #61
    sub x11, x10, x11
    lsr x10, x7, x11
    add x10, x10, x11, lsl #2
    sub x10, x10, #72
    lsr x6, x7, #3
.Lsgf_alloc:
    stp x0, x1, [sp, #-48]!
    stp x2, x3, [sp, #16]
    str x6, [sp, #32]
    lsl x0, x6, #3
    bl __fern_alloc
    ldr x6, [sp, #32]
    ldp x2, x3, [sp, #16]
    ldp x4, x1, [sp], #48
    str x6, [x0]
    mov w5, #1
    str w5, [x0, #8]
    mov w5, #0x4F57
    movk w5, #0x4752, lsl #16
    str w5, [x0, #12]
    add x5, x0, #32
    str x5, [x0, #16]
    add x6, x2, x3
    str x6, [x0, #24]
    ldr x6, [x4]
    cbz x2, .Lsgf_ad
    cmp x2, #8
    b.lo .Lsgf_ab
    add x9, x6, x2
    sub x9, x9, #8
    add x10, x5, x2
    sub x10, x10, #8
.Lsgf_aw:
    cmp x5, x10
    b.hs .Lsgf_at
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_aw
.Lsgf_at:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_ad
.Lsgf_ab:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x2, x2, #1
    cbnz x2, .Lsgf_ab
.Lsgf_ad:
    add x5, x0, #32
    ldr x2, [x0, #24]
    sub x2, x2, x3
    add x5, x5, x2
    mov x6, x1
    cbz x3, .Lsgf_bd
    cmp x3, #8
    b.lo .Lsgf_bb
    add x9, x6, x3
    sub x9, x9, #8
    add x10, x5, x3
    sub x10, x10, #8
.Lsgf_bw:
    cmp x5, x10
    b.hs .Lsgf_bt
    ldr x7, [x6], #8
    str x7, [x5], #8
    b .Lsgf_bw
.Lsgf_bt:
    ldr x7, [x9]
    str x7, [x10]
    b .Lsgf_bd
.Lsgf_bb:
    ldrb w7, [x6], #1
    strb w7, [x5], #1
    sub x3, x3, #1
    cbnz x3, .Lsgf_bb
.Lsgf_bd:
    add x0, x0, #16
    ldp x29, x30, [sp], #16
    ret
__fn___fern_str_borrow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    mov x0, #24
    bl __fern_alloc
    mov w2, #1
    str w2, [x0]
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    stur w3, [x0, #4]
    ldr x2, [sp, #32]
    str x2, [x0, #8]
    ldr x3, [sp, #16]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fn___fern_alloc_reuse:
    ldr x0, [sp, #16]
    cbz x0, .Lsarelo_fresh
    ldr x1, [sp]
    ldur x2, [x0, #-16]
    cmp x2, x1
    beq .Lsarelo_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_arr_dec.r
    ldp x29, x30, [sp], #16
.Lsarelo_fresh:
    ldr x0, [sp]
    b __fern_arr_box
.Lsarelo_ret:
    ret
__fn___fern_rc_underflow_count:
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w0, [x10]
    ret
__fern_large_push:
    mov x3, #1
    lsl x3, x3, #34
    cmp x2, x3
    b.hi .Llpush_ret
    mov x3, #1
    lsl x3, x3, #19
    cmp x2, x3
    csel x2, x3, x2, lo
    clz x3, x2
    mov x4, #61
    sub x4, x4, x3
    mov x3, #1
    lsl x3, x3, x4
    sub x3, x3, #1
    add x2, x2, x3
    bic x2, x2, x3
    clz x3, x2
    mov x4, #61
    sub x3, x4, x3
    lsr x4, x2, x3
    add x4, x4, x3, lsl #2
    sub x4, x4, #72
    mov x2, x4
    adrp x3, __fern_large_freelist
    add x3, x3, :lo12:__fern_large_freelist
    ldr x4, [x3, x2, lsl #3]
    cmp x4, x1
    b.eq __fern_double_free_abort_leaf
    str x4, [x1]
    str x1, [x3, x2, lsl #3]
.Llpush_ret:
    ret
__fern_raw_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    cbz x0, .Lrawfree_done
    adrp x9, __fern_heap_base
    add x9, x9, :lo12:__fern_heap_base
    ldr x9, [x9]
    cmp x0, x9
    b.lo .Lrawfree_bad
    adrp x9, __fern_heap_end
    add x9, x9, :lo12:__fern_heap_end
    ldr x9, [x9]
    cmp x0, x9
    b.hs .Lrawfree_bad
    add x1, x1, #7
    lsr x5, x1, #3
    cbz x5, .Lrawfree_done
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lrawfree_b_large
    cmp x5, #256
    b.ls .L218
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x5, x30, [sp], #16
.L218:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x5, lsl #3]
    cmp x10, x0
    b.eq __fern_double_free_abort
    str x10, [x0]
    str x0, [x3, x5, lsl #3]
    b .Lrawfree_b_done
.Lrawfree_b_large:
    mov x1, x0
    lsl x2, x5, #3
    bl __fern_large_push
.Lrawfree_b_done:
.Lrawfree_done:
    ldp x29, x30, [sp], #16
    ret
.Lrawfree_bad:
    b __fern_free_range_abort
__fn___fern_arr_dec:
    ldr x0, [sp]
__fn___fern_arr_dec.r:
    cmp x0, #16, lsl #12
    blo .Larrdec_ret
__fn___fern_arr_dec.u:
    ldur w1, [x0, #-8]
    cmp w1, #1
    bne .Larrdec_shared
    stur wzr, [x0, #-8]
    ldur x1, [x0, #-16]
    add x1, x1, #3
    sub x2, x0, #16
    cmp x1, #256
    b.hi .Larrdec_big
.Larrdec_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Larrdec_ret:
    ret
.Larrdec_shared:
    tbnz w1, #31, .Larrdec_ret
    bgt .Larrdec_dec
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    ret
.Larrdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
    ret
.Larrdec_big:
    mov x9, #0x10000
    cmp x1, x9
    bhs .Larrdec_large
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
    b .Larrdec_push
.Larrdec_large:
    lsl x2, x1, #3
    sub x1, x0, #16
    b __fern_large_push
__fn___fern_str_free:
    ldr x0, [sp]
__fn___fern_str_free.r:
    tbnz x0, #0, .Lstrfree_ret
    cmp x0, #16, lsl #12
    blo .Lstrfree_ret
__fn___fern_str_free.u:
    mov x9, #0x10000
    ldur w4, [x0, #-8]
    cmp w4, #1
    bne .Lstrfree_shared
    ldur w2, [x0, #-4]
    mov w3, #32781
    movk w3, #29519, lsl #16
    cmp w2, w3
    beq .Lstrfree_fused
    mov w3, #0x4F57
    movk w3, #0x4752, lsl #16
    cmp w2, w3
    beq .Lstrfree_grown
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    cmp w2, w3
    beq .Lstrfree_box
    ldr x1, [x0]
    ldr x2, [x0, #8]
    cmp x1, x9
    blo .Lstrfree_box
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrfree_box
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrfree_box
    cmp x2, #0
    ble .Lstrfree_box
    add x2, x2, #7
    lsr x2, x2, #3
    cmp x2, x9
    bhs .Lstrfree_box
    cmp x2, #256
    b.ls .L219
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
.L219:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
.Lstrfree_box:
    stur wzr, [x0, #-8]
    sub x1, x0, #8
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
    b .Lstrfree_ret
.Lstrfree_grown:
    ldur x2, [x0, #-16]
    stur wzr, [x0, #-8]
    sub x1, x0, #16
    b .Lstrfree_block
.Lstrfree_fused:
    ldr x2, [x0, #8]
    add x2, x2, #7
    lsr x2, x2, #3
    add x2, x2, #3
    stur wzr, [x0, #-8]
    sub x1, x0, #8
.Lstrfree_block:
    cmp x2, #256
    b.hi .Lstrfree_fused_big
.Lstrfree_fused_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
    b .Lstrfree_ret
.Lstrfree_fused_big:
    cmp x2, x9
    bhs .Lstrfree_fused_large
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
    b .Lstrfree_fused_push
.Lstrfree_fused_large:
    lsl x2, x2, #3
    b __fern_large_push
.Lstrfree_shared:
    tbnz w4, #31, .Lstrfree_ret
    blt .Lstrfree_uf
    sub w4, w4, #1
    stur w4, [x0, #-8]
    ret
.Lstrfree_uf:
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    ldr x0, [sp]
    tbnz x0, #0, .Lstrvfree_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lstrvfree_ret
    ldur w4, [x0, #-8]
    tbnz w4, #31, .Lstrvfree_view
    b __fn___fern_str_free
.Lstrvfree_view:
    sub x1, x0, #8
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrvfree_ret
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrvfree_ret
    stur wzr, [x0, #-8]
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_arr_free.k:
__fn___fern_str_arr_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_arr_free_0:
    movz x9, #1, lsl #16
    cmp x19, x9
    b.lo .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    ldrsw x20, [x19]
.Lssa___fern_str_arr_free_4:
    mov x9, #0
.Lssa___fern_str_arr_free_15:
    cmp x9, x20
    b.ge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    add x21, x9, #1
    ldr x9, [x19, x21, lsl #3]
    tbnz x9, #0, .Lssa___fern_str_arr_free_rcdeck36
    cmp x9, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck36
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd36
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck36
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___fern_str_arr_free_rcdece36
.Lssa___fern_str_arr_free_rcdecd36:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___fern_str_arr_free_rcdeck36:
    mov x0, x9
.Lssa___fern_str_arr_free_rcdece36:
    mov x9, x21
    cmp x9, x20
    b.lt .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    cmp x19, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck40
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd40
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck40
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___fern_str_arr_free_rcdece40
.Lssa___fern_str_arr_free_rcdecd40:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___fern_str_arr_free_rcdeck40:
    mov x0, x19
.Lssa___fern_str_arr_free_rcdece40:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_drop_arr_ptr:
    ret
    .section .bss
    .align 8
__fern_envp: .quad 0
    .section .text
    .section .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_u8:
    .quad 0
    .text
.globl __fern_alloc_u8
.type __fern_alloc_u8, %function
__fern_alloc_u8:
    tbz w0, #31, .Lfern_alloc_u8_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_u8_sized:
    cbz w0, .Lfern_alloc_u8_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x0, x19
    bl __fern_arr_box
    add x2, x0, #8
    mov w1, w19
.Lfern_alloc_u8_zero:
    cbz x1, .Lfern_alloc_u8_done
    str xzr, [x2], #8
    sub x1, x1, #1
    b .Lfern_alloc_u8_zero
.Lfern_alloc_u8_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_u8_empty:
    adrp x0, .Lfern_empty_u8
    add x0, x0, :lo12:.Lfern_empty_u8
    ret
.size __fern_alloc_u8, .-__fern_alloc_u8
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
    .text
__fern_segv:
    ldr x9, [x1, #16]
    adrp x14, __fern_stack_top
    add x14, x14, :lo12:__fern_stack_top
    ldr x14, [x14]
    cbz x14, .Lfern_segv_near_sp
    mov x15, #1
    lsl x15, x15, #30
    sub x14, x14, x15
    add x14, x14, #16
    sub x15, x9, x14
    mov x16, #1
    lsl x16, x16, #20
    cmp x15, x16
    b.lo .Lfern_segv_overflow
    b .Lfern_segv_other
.Lfern_segv_near_sp:
    ldr x10, [x2, #432]
    sub x9, x9, x10
    mov x10, #1
    lsl x10, x10, #20
    add x9, x9, x10
    lsl x10, x10, #1
    cmp x9, x10
    b.hs .Lfern_segv_other
.Lfern_segv_overflow:
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_stack_overflow
    add x1, x1, :lo12:.Lmsg_stack_overflow
    mov x2, #21
    mov x0, #134
    b __fern_report
.Lfern_segv_other:
    stp x29, x30, [sp, #-16]!
    sub sp, sp, #32
    stp xzr, xzr, [sp]
    stp xzr, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    add sp, sp, #32
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    adrp x1, .Lfern_stack_guard_failed_msg
    add x1, x1, :lo12:.Lfern_stack_guard_failed_msg
    mov x2, #40
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    adrp x1, .Lfern_signal_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_map_failed_msg
    mov x2, #37
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    adrp x1, .Lfern_signal_stack_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_failed_msg
    mov x2, #41
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    adrp x1, .Lfern_fault_handler_failed_msg
    add x1, x1, :lo12:.Lfern_fault_handler_failed_msg
    mov x2, #42
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=arm64-linux profile= harden=0 pie=0 sanitize=0 backtrace=1 size=0 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .bss
    .align 3
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .align 3
__fern_bt_floor: .quad 0
    .text
.globl __fern_report
.type __fern_report, %function
__fern_abort_134:
    mov x0, #134
__fern_report:
    mov x19, x0
    mov x0, #2
    mov x8, #64
    svc #0
    b __fern_bt_exit
.size __fern_report, .-__fern_report
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .text
    .globl __fern_bt_exit
__fern_bt_exit:
    adrp x1, .Lmsg_bt
    add x1, x1, :lo12:.Lmsg_bt
    mov x2, #11
    mov x0, #2
    mov x8, #64
    svc #0
    mov x20, x29
    mov x21, #64
    mov x22, sp
.Lbt_loop:
    cmp x20, x22
    b.lo .Lbt_done
    and x23, x20, #7
    cbnz x23, .Lbt_done
    ldr x1, [x20, #8]
    cmp x1, #16, lsl #12
    b.lo .Lbt_done
    bl .Lbt_hex
    adrp x24, __fern_bt_floor
    add x24, x24, :lo12:__fern_bt_floor
    ldr x22, [x24]
    str xzr, [x24]
    cmp x22, #0
    csel x22, x20, x22, eq
    ldr x20, [x20]
    adrp x24, __fern_stack_top
    add x24, x24, :lo12:__fern_stack_top
    ldr x24, [x24]
    cbz x24, .Lbt_next
    cmp x20, x24
    b.hs .Lbt_done
.Lbt_next:
    subs x21, x21, #1
    b.ne .Lbt_loop
.Lbt_done:
    mov x0, x19
    mov x8, #94
    svc #0
.Lbt_hex:
    sub sp, sp, #32
    mov w2, #0x2020
    movk w2, #0x7830, lsl #16
    str w2, [sp]
    mov w2, #10
    strb w2, [sp, #20]
    mov x3, #16
    add x4, sp, #3
.Lbt_hloop:
    and x2, x1, #15
    cmp x2, #10
    add x5, x2, #87
    add x2, x2, #48
    csel x2, x5, x2, hs
    strb w2, [x4, x3]
    lsr x1, x1, #4
    subs x3, x3, #1
    b.ne .Lbt_hloop
    mov x0, #2
    mov x1, sp
    mov x2, #21
    mov x8, #64
    svc #0
    add sp, sp, #32
    ret
__fern_arr_push:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Larr_push_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_slow_ok
    tbz w3, #31, .Larr_push_slow
.Larr_push_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Larr_push_slow:
    ldr x2, [x0]
    cbnz x2, .Larr_push_frame
    ldur x2, [x0, #-16]
    cbnz x2, .Larr_push_frame
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    ldr x3, [x2, #56]
    cbz x3, .Larr_push_fresh
    ldr x4, [x3]
    str x4, [x2, #56]
    mov x2, #4
    str x2, [x3]
    mov w2, #1
    str w2, [x3, #8]
    mov x2, #1
    str x2, [x3, #16]
    str x1, [x3, #24]
    add x0, x3, #16
    ret
.Larr_push_fresh:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x1, [sp, #-16]!
    mov x0, #4
    bl __fern_arr_box
    ldr x1, [sp], #16
    mov x2, #1
    str x2, [x0]
    str x1, [x0, #8]
    ldp x29, x30, [sp], #16
    ret
.Larr_push_frame:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_rc_ok
    tbnz w2, #31, .Larr_push_rc_ok
    b .Larr_push_grow
.Larr_push_rc_ok:
    cmp x21, x22
    b.ge .Larr_push_grow
    add x1, x21, #1
    str x20, [x19, x1, lsl #3]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_ret
.Larr_push_grow:
    mov x2, x22
    cmp x21, x22
    b.lt .Larr_push_shared_cliff
    cmp x22, #0
    b.ne .Larr_push_dbl
    mov x2, #4
    b .Larr_push_cap
.Larr_push_shared_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21, lsl #3
    str x4, [x3]
    b .Larr_push_cap
.Larr_push_dbl:
    lsl x2, x22, #1
.Larr_push_cap:
    add x9, x21, #1
    cmp x2, x9
    csel x2, x2, x9, hs
    mov x22, x2
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Larr_push_copy4:
    cmp x4, #4
    b.lt .Larr_push_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Larr_push_copy4
.Larr_push_copy1:
    cbz x4, .Larr_push_copy_done
.Larr_push_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Larr_push_copy1_loop
.Larr_push_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
.Larr_push_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lapo_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapo_slow_ok
    tbz w3, #31, .Lapo_slow
.Lapo_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Lapo_slow:
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.eq .Lapo_own
    b .Larr_push_slow
.Lapo_own:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    lsl x8, x22, #1
    cbnz x8, .Lapo_cap
    mov x8, #4
.Lapo_cap:
    add x9, x21, #1
    cmp x8, x9
    csel x8, x8, x9, hs
    movz x9, #65535
    movk x9, #4095, lsl #16
    cmp x8, x9
    b.ls .Lapo_sized
    b __fern_alloc_size_abort
.Lapo_sized:
    add x1, x8, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Lapo_alloc
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    add x1, x3, x1
    ldr x3, [x1]
    cbz x3, .Lapo_miss
    ldr x4, [x3]
    str x4, [x1]
.Lapo_box:
    str x8, [x3]
    mov w4, #1
    str w4, [x3, #8]
    add x0, x3, #16
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Lapo_copy4:
    cmp x4, #4
    b.lt .Lapo_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Lapo_copy4
.Lapo_copy1:
    cbz x4, .Lapo_copy_done
.Lapo_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Lapo_copy1_loop
.Lapo_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
    add x1, x22, #3
    mov x9, #0x10000
    cmp x1, x9
    b.hs .Lapo_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L220
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L220:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapo_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapo_miss:
    add x1, x8, #3
    lsl x1, x1, #3
.Lapo_alloc:
    mov x0, x1
    bl __fern_alloc
    mov x3, x0
    b .Lapo_box
.Lapo_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapo_ret
__fern_arr_push_u8:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Larr_push_u8_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_u8_slow_ok
    tbz w3, #31, .Larr_push_u8_slow
.Larr_push_u8_slow_ok:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    ret
.Larr_push_u8_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_u8_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_u8_rc_ok
    tbnz w2, #31, .Larr_push_u8_rc_ok
    b .Larr_push_u8_grow
.Larr_push_u8_rc_ok:
    lsl x2, x22, #3
    cmp x21, x2
    b.ge .Larr_push_u8_grow
    add x2, x19, x21
    strb w20, [x2, #8]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_u8_ret
.Larr_push_u8_grow:
    mov x2, x22
    lsl x3, x22, #3
    cmp x21, x3
    b.lt .Larr_push_u8_cliff
    cbnz x22, .Larr_push_u8_dbl
    mov x2, #4
    b .Larr_push_u8_cap
.Larr_push_u8_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21
    str x4, [x3]
    b .Larr_push_u8_cap
.Larr_push_u8_dbl:
    lsl x2, x22, #1
.Larr_push_u8_cap:
    add x3, x21, #8
    lsr x3, x3, #3
    cmp x2, x3
    csel x2, x2, x3, hs
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    add x4, x21, #7
    lsr x4, x4, #3
.Larr_push_u8_copy:
    cbz x4, .Larr_push_u8_copied
    ldr x5, [x2], #8
    str x5, [x3], #8
    sub x4, x4, #1
    b .Larr_push_u8_copy
.Larr_push_u8_copied:
    add x2, x0, x21
    strb w20, [x2, #8]
.Larr_push_u8_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned_u8:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    lsl x3, x3, #3
    cmp x2, x3
    b.ge .Lapou_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapou_slow_ok
    tbz w3, #31, .Lapou_slow
.Lapou_slow_ok:
    add x3, x0, x2
    strb w1, [x3, #8]
    add x2, x2, #1
    str x2, [x0]
    ret
.Lapou_slow:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    bl .Larr_push_u8_slow
    cmp x0, x19
    beq .Lapou_ret
    mov x9, #0x10000
    cmp x19, x9
    blo .Lapou_ret
    ldur w1, [x19, #-8]
    tbnz w1, #31, .Lapou_ret
    cmp w1, #1
    bne .Lapou_ret
    ldur x1, [x19, #-16]
    add x1, x1, #3
    mov x9, #0x10000
    cmp x1, x9
    bhs .Lapou_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L221
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L221:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapou_ret:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapou_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapou_ret
    .section .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_bytes:
    .quad 0
    .text
__fern_alloc_bytes:
    tbz w0, #31, .Lfern_alloc_bytes_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_bytes_sized:
    cbz w0, .Lfern_alloc_bytes_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    sxtw x19, w0
    add x0, x19, #7
    lsr x0, x0, #3
    mov x20, x0
    bl __fern_arr_box
    str x19, [x0]
    add x2, x0, #8
.Lfern_alloc_bytes_zero:
    cbz x20, .Lfern_alloc_bytes_done
    str xzr, [x2], #8
    sub x20, x20, #1
    b .Lfern_alloc_bytes_zero
.Lfern_alloc_bytes_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_bytes_empty:
    adrp x0, .Lfern_empty_bytes
    add x0, x0, :lo12:.Lfern_empty_bytes
    ret
__fn___fern_bytes_range:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_bytes_range.k:
__fn___fern_bytes_range.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
.Lssa___fern_bytes_range_0:
    sxtw x9, w10
    mov x11, #2
    and x9, x9, x11
    cmp x9, #0
    b.eq .Lssa___fern_bytes_range_10
.Lssa___fern_bytes_range_11:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x20, x12
    mov x12, x11
    b .Lssa___fern_bytes_range_9
.Lssa___fern_bytes_range_10:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x20, x10
.Lssa___fern_bytes_range_9:
    cmp x19, #0
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_8:
    cmp x0, x19
    b.lt .Lssa___fern_bytes_range_6
.Lssa___fern_bytes_range_7:
    cmp x0, x12
    b.le .Lssa___fern_bytes_range_4
.Lssa___fern_bytes_range_6:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_bytes_range_4:
    sub x0, x0, x19
    sxtw x21, w0
    cmp x21, #0
    b.ne .Lssa___fern_bytes_range_1
.Lssa___fern_bytes_range_3:
    adrp x0, .K0
    add x0, x0, :lo12:.K0
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_range_1:
    add x12, x21, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    sxtw x19, w19
    add x20, x20, x19
    mov x2, x21
    mov x1, x20
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_range_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_bytes_range_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_range_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_range_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_range_mc136
.Lssa___fern_bytes_range_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_range_mcd136
.Lssa___fern_bytes_range_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_range_mcb136
.Lssa___fern_bytes_range_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_bytes_into:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn___fern_bytes_into.k:
__fn___fern_bytes_into.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    str x25, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x11
    mov x22, x12
.Lssa___fern_bytes_into_0:
    sxtw x9, w10
    mov x11, #2
    and x9, x9, x11
    cmp x9, #0
    b.eq .Lssa___fern_bytes_into_15
.Lssa___fern_bytes_into_16:
    sub x9, x10, #2
    add x11, x9, #8
    ldrsw x11, [x11]
    ldr x12, [x9, #0]
    mov x23, x12
    mov x12, x11
    b .Lssa___fern_bytes_into_14
.Lssa___fern_bytes_into_15:
    ldrsw x12, [x10]
    add x10, x10, #8
    mov x23, x10
.Lssa___fern_bytes_into_14:
    ldrsw x24, [x22]
    cmp x19, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_13:
    cmp x21, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_12:
    cmp x20, #0
    b.lt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_11:
    sub x10, x24, x19
    sxtw x10, w10
    cmp x21, x10
    b.gt .Lssa___fern_bytes_into_9
.Lssa___fern_bytes_into_10:
    sub x12, x12, x19
    sxtw x12, w12
    cmp x20, x12
    b.le .Lssa___fern_bytes_into_7
.Lssa___fern_bytes_into_9:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_bytes_into_7:
    cmp x19, #0
    b.ne .Lssa___fern_bytes_into_4
.Lssa___fern_bytes_into_6:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_bytes_into_4:
    mov x6, #0
    tbnz x22, #0, .Lssa___fern_bytes_into_rcuniq100
    cmp x22, #16, lsl #12
    b.lo .Lssa___fern_bytes_into_rcuniq100
    and x7, x22, #0xfffffffffffffffd
    ldur w5, [x7, #-8]
    cmp w5, #1
    b.ne .Lssa___fern_bytes_into_rcuniq100
    mov x6, #1
.Lssa___fern_bytes_into_rcuniq100:
    mov x0, x6
    cmp x0, #0
    b.ne .Lssa___fern_bytes_into_1
.Lssa___fern_bytes_into_3:
    add x12, x24, #7
    sxtw x12, w12
    mov x4, x12
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    mov x0, x10
    bl __fern_arr_box
    mov x25, x0
    str x24, [x25, #0]
    add x10, x25, #8
    add x12, x22, #8
    mov x2, x24
    mov x1, x12
    mov x0, x10
    cbz x2, .Lssa___fern_bytes_into_mcd172
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb172
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc172:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct172
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc172
.Lssa___fern_bytes_into_mct172:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd172
.Lssa___fern_bytes_into_mcb172:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb172
.Lssa___fern_bytes_into_mcd172:
    mov x0, #0
    cmp x22, #16, lsl #12
    b.lo .Lssa___fern_bytes_into_rcdeck117
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_bytes_into_rcdecd117
    tbnz w5, #31, .Lssa___fern_bytes_into_rcdeck117
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa___fern_bytes_into_rcdece117
.Lssa___fern_bytes_into_rcdecd117:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa___fern_bytes_into_rcdeck117:
    mov x0, x22
.Lssa___fern_bytes_into_rcdece117:
    mov x22, x25
.Lssa___fern_bytes_into_2:
.Lssa___fern_bytes_into_1:
    add x12, x22, #8
    sxtw x21, w21
    add x12, x12, x21
    sxtw x20, w20
    add x23, x23, x20
    mov x2, x19
    mov x1, x23
    mov x0, x12
    cbz x2, .Lssa___fern_bytes_into_mcd207
    cmp x2, #8
    b.lo .Lssa___fern_bytes_into_mcb207
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_bytes_into_mc207:
    cmp x0, x10
    b.hs .Lssa___fern_bytes_into_mct207
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_bytes_into_mc207
.Lssa___fern_bytes_into_mct207:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_bytes_into_mcd207
.Lssa___fern_bytes_into_mcb207:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_bytes_into_mcb207
.Lssa___fern_bytes_into_mcd207:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #64
    ldr x25, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_utf8_step:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_utf8_step.k:
__fn___fern_utf8_step.r:
.Lssa___fern_utf8_step_0:
    ldr x6, [x0, #8]
    cmp x9, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w11, [x6, x9]
    mov x12, #0
    mov x13, #1
    cmp x11, #128
    csel x13, x13, x12, lt
.Lssa___fern_utf8_step_42:
    cmp x11, #194
    b.lt .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_41:
    cmp x11, #224
    b.ge .Lssa___fern_utf8_step_38
.Lssa___fern_utf8_step_40:
    mov x13, #2
.Lssa___fern_utf8_step_39:
.Lssa___fern_utf8_step_38:
    cmp x11, #224
    b.lt .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_37:
    cmp x11, #240
    b.ge .Lssa___fern_utf8_step_34
.Lssa___fern_utf8_step_36:
    mov x13, #3
.Lssa___fern_utf8_step_35:
.Lssa___fern_utf8_step_34:
    cmp x11, #240
    b.lt .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_33:
    cmp x11, #245
    b.ge .Lssa___fern_utf8_step_30
.Lssa___fern_utf8_step_32:
    mov x13, #4
.Lssa___fern_utf8_step_31:
.Lssa___fern_utf8_step_30:
    cmp x13, #1
    b.gt .Lssa___fern_utf8_step_27
.Lssa___fern_utf8_step_29:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_27:
    add x14, x9, #1
    sxtw x14, w14
    cmp x14, x10
    b.lt .Lssa___fern_utf8_step_24
.Lssa___fern_utf8_step_26:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_24:
    mov x14, #128
    mov x12, #160
    cmp x11, #224
    csel x12, x12, x14, eq
.Lssa___fern_utf8_step_21:
    mov x15, #144
    cmp x11, #240
    csel x15, x15, x12, eq
.Lssa___fern_utf8_step_18:
    mov x14, #191
    mov x12, #159
    cmp x11, #237
    csel x12, x12, x14, eq
.Lssa___fern_utf8_step_15:
    mov x1, #143
    cmp x11, #244
    csel x1, x1, x12, eq
.Lssa___fern_utf8_step_12:
    add w11, w9, #1
    ldr x6, [x0, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w12, [x6, x11]
    cmp x12, x15
    b.ge .Lssa___fern_utf8_step_9
.Lssa___fern_utf8_step_11:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_9:
    cmp x12, x1
    b.le .Lssa___fern_utf8_step_6
.Lssa___fern_utf8_step_8:
    mov x0, #1
    ret
.Lssa___fern_utf8_step_6:
.Lssa___fern_utf8_step_5:
    mov x12, #2
.Lssa___fern_utf8_step_113:
    cmp x12, x13
    b.ge .Lssa___fern_utf8_step_4
.Lssa___fern_utf8_step_120:
    add x1, x9, x12
    sxtw x1, w1
    cmp x1, x10
    b.ge .Lssa___fern_utf8_step_3
.Lssa___fern_utf8_step_118:
    add w1, w9, w12
    ldr x6, [x0, #8]
    cmp x1, x6
    b.lo 1f
    b __fern_str_oob_abort_leaf
1:
    ldr x6, [x0]
    ldrb w15, [x6, x1]
    cmp x15, #128
    b.lt .Lssa___fern_utf8_step_2
.Lssa___fern_utf8_step_116:
    cmp x15, #191
    b.gt .Lssa___fern_utf8_step_1
.Lssa___fern_utf8_step_114:
    add x12, x12, #1
    cmp x12, x13
    b.lt .Lssa___fern_utf8_step_120
.Lssa___fern_utf8_step_4:
    mov x0, x13
    ret
.Lssa___fern_utf8_step_3:
    mov x0, x12
    ret
.Lssa___fern_utf8_step_2:
    mov x0, x12
    ret
.Lssa___fern_utf8_step_1:
    mov x0, x12
    ret
    .cfi_endproc
    .ltorg
__fn___fern_str_split:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn___fern_str_split.k:
__fn___fern_str_split.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    str x27, [sp, #-16]!
    sub sp, sp, #80
    mov x19, x0
    mov x20, x9
.Lssa___fern_str_split_0:
    ldr x21, [x19, #8]
    ldr x22, [x20, #8]
    adrp x23, .K0
    add x23, x23, :lo12:.K0
    cmp x22, #0
    b.ne .Lssa___fern_str_split_3
.Lssa___fern_str_split_7:
.Lssa___fern_str_split_6:
    mov x24, #0
.Lssa___fern_str_split_12:
    cmp x24, x21
    b.ge .Lssa___fern_str_split_5
.Lssa___fern_str_split_13:
    mov x0, x19
    mov x9, x24
    mov x10, x21
    bl __fn___fern_utf8_step.r
    add x0, x24, x0
    sxtw x25, w0
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #104
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x9, .SB4
    add x9, x9, :lo12:.SB4
    str x9, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x24, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush87s
.Lssa___fern_str_split_apush87o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush87e
.Lssa___fern_str_split_apush87s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush87e:
    mov x23, x0
    mov x24, x25
    cmp x24, x21
    b.lt .Lssa___fern_str_split_13
.Lssa___fern_str_split_5:
    mov x0, x23
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa___fern_str_split_3:
.Lssa___fern_str_split_2:
    mov x24, #0
    mov x25, #0
.Lssa___fern_str_split_20:
    add x9, x25, x22
    sxtw x9, w9
    cmp x9, x21
    b.gt .Lssa___fern_str_split_1
.Lssa___fern_str_split_26:
.Lssa___fern_str_split_25:
    mov x9, #0
    mov x10, #1
.Lssa___fern_str_split_31:
    cmp x9, x22
    b.ge .Lssa___fern_str_split_24
.Lssa___fern_str_split_35:
    add w11, w25, w9
    ldr x6, [x19, #8]
    cmp x11, x6
    b.lo 1f
    b __fern_str_oob_abort
1:
    ldr x6, [x19]
    ldrb w12, [x6, x11]
    ldr x11, [x20, #0]
    ldrb w13, [x11, x9]
    mov x11, #0
    add x9, x9, #1
    cmp x12, x13
    csel x9, x22, x9, ne
    csel x10, x11, x10, ne
.Lssa___fern_str_split_32:
    cmp x9, x22
    b.lt .Lssa___fern_str_split_35
.Lssa___fern_str_split_24:
    cmp x10, #1
    b.ne .Lssa___fern_str_split_22
.Lssa___fern_str_split_23:
    mov x0, x19
    mov x1, x24
    mov x2, x25
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #128
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x26, x0
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    str x10, [sp, #-16]!
    str x26, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x27, x0
    str x26, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x27
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush142s
.Lssa___fern_str_split_apush142o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush142e
.Lssa___fern_str_split_apush142s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush142e:
    add x10, x25, x22
    sxtw x10, w10
    mov x23, x0
    mov x24, x10
    mov x25, x10
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_22:
    add x25, x25, #1
    sxtw x25, w25
.Lssa___fern_str_split_21:
    b .Lssa___fern_str_split_20
.Lssa___fern_str_split_1:
    mov x0, x19
    mov x1, x24
    mov x2, x21
    ldr x3, [x0, #8]
    cmp x2, x3
    b.ls 1f
    b __fern_str_oob_abort
1:
    cmp x1, x2
    b.ls 1f
    b __fern_str_oob_abort
1:
    sub x2, x2, x1
    ldr x3, [x0]
    add x1, x3, x1
    sub x0, x29, #152
    mov x3, #-1
    str x3, [x0]
    str x1, [x0, #8]
    str x2, [x0, #16]
    add x0, x0, #8
    mov x25, x0
    adrp x10, .SB4
    add x10, x10, :lo12:.SB4
    str x10, [sp, #-16]!
    str x25, [sp, #-16]!
    bl __fn___fern_str_concat
    add sp, sp, #32
    mov x24, x0
    str x25, [sp, #-16]!
    bl __fn___fern_str_view_free
    add sp, sp, #16
    mov x0, x23
    mov x1, x24
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa___fern_str_split_apush161s
.Lssa___fern_str_split_apush161o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa___fern_str_split_apush161e
.Lssa___fern_str_split_apush161s:
    bl __fern_arr_push_owned
.Lssa___fern_str_split_apush161e:
    .cfi_remember_state
    sub sp, x29, #80
    ldr x27, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_str_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_bytes_u8.k:
__fn___fern_str_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_bytes_u8_0:
    ldr x20, [x19, #8]
    sxtw x21, w20
    add x9, x21, #7
    mov x4, x9
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x10, x4
    sxtw x10, w10
    mov x0, x10
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x10, x22, #8
    ldr x9, [x19, #0]
    mov x2, x20
    mov x1, x9
    mov x0, x10
    cbz x2, .Lssa___fern_str_bytes_u8_mcd36
    cmp x2, #8
    b.lo .Lssa___fern_str_bytes_u8_mcb36
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_str_bytes_u8_mc36:
    cmp x0, x10
    b.hs .Lssa___fern_str_bytes_u8_mct36
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_str_bytes_u8_mc36
.Lssa___fern_str_bytes_u8_mct36:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_str_bytes_u8_mcd36
.Lssa___fern_str_bytes_u8_mcb36:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_str_bytes_u8_mcb36
.Lssa___fern_str_bytes_u8_mcd36:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_string_from_bytes_u8.k:
__fn___fern_string_from_bytes_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_string_from_bytes_u8_0:
    ldr x20, [x19, #0]
    mov x0, x20
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x21, x0
    add x19, x19, #8
    mov x2, x20
    mov x1, x19
    mov x0, x21
    cbz x2, .Lssa___fern_string_from_bytes_u8_mcd14
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_u8_mcb14
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_u8_mc14:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_u8_mct14
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_u8_mc14
.Lssa___fern_string_from_bytes_u8_mct14:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_u8_mcd14
.Lssa___fern_string_from_bytes_u8_mcb14:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_u8_mcb14
.Lssa___fern_string_from_bytes_u8_mcd14:
    mov x0, #0
    mov x0, x21
    mov x1, x20
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_string_from_bytes_range_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_string_from_bytes_range_u8.k:
__fn___fern_string_from_bytes_range_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_string_from_bytes_range_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
.Lssa___fern_string_from_bytes_range_u8_13:
    mov x13, #1
    cmp x10, x9
    csel x13, x13, x12, gt
.Lssa___fern_string_from_bytes_range_u8_10:
    mov x9, #1
    cmp x20, #0
    csel x9, x9, x13, lt
.Lssa___fern_string_from_bytes_range_u8_7:
    mov x12, #1
    cmp x20, x10
    csel x12, x12, x9, gt
.Lssa___fern_string_from_bytes_range_u8_4:
    cmp x12, #1
    b.ne .Lssa___fern_string_from_bytes_range_u8_1
.Lssa___fern_string_from_bytes_range_u8_3:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_string_from_bytes_range_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    mov x0, x21
    tbz w0, #31, 1f
    b __fern_alloc_size_abort
1:
    add x0, x0, #24
    bl __fern_alloc
    add x0, x0, #24
    mov x22, x0
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x22
    cbz x2, .Lssa___fern_string_from_bytes_range_u8_mcd117
    cmp x2, #8
    b.lo .Lssa___fern_string_from_bytes_range_u8_mcb117
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_string_from_bytes_range_u8_mc117:
    cmp x0, x10
    b.hs .Lssa___fern_string_from_bytes_range_u8_mct117
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_string_from_bytes_range_u8_mc117
.Lssa___fern_string_from_bytes_range_u8_mct117:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_string_from_bytes_range_u8_mcd117
.Lssa___fern_string_from_bytes_range_u8_mcb117:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_string_from_bytes_range_u8_mcb117
.Lssa___fern_string_from_bytes_range_u8_mcd117:
    mov x0, #0
    mov x0, x22
    mov x1, x21
    bl __fern_str_box_hdr
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_arr_slice_u8:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_arr_slice_u8.k:
__fn___fern_arr_slice_u8.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_arr_slice_u8_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
.Lssa___fern_arr_slice_u8_13:
    mov x13, #1
    cmp x10, x9
    csel x13, x13, x12, gt
.Lssa___fern_arr_slice_u8_10:
    mov x9, #1
    cmp x20, #0
    csel x9, x9, x13, lt
.Lssa___fern_arr_slice_u8_7:
    mov x12, #1
    cmp x20, x10
    csel x12, x12, x9, gt
.Lssa___fern_arr_slice_u8_4:
    cmp x12, #1
    b.ne .Lssa___fern_arr_slice_u8_1
.Lssa___fern_arr_slice_u8_3:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_arr_slice_u8_1:
    sub x10, x10, x20
    sxtw x21, w10
    add x10, x21, #7
    sxtw x10, w10
    mov x4, x10
    asr x5, x4, #63
    add x5, x4, x5, lsr #61
    asr x4, x5, #3
    mov x12, x4
    mov x0, x12
    bl __fern_arr_box
    mov x22, x0
    str x21, [x22, #0]
    add x12, x22, #8
    add x19, x19, #8
    sxtw x20, w20
    add x19, x19, x20
    mov x2, x21
    mov x1, x19
    mov x0, x12
    cbz x2, .Lssa___fern_arr_slice_u8_mcd136
    cmp x2, #8
    b.lo .Lssa___fern_arr_slice_u8_mcb136
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_arr_slice_u8_mc136:
    cmp x0, x10
    b.hs .Lssa___fern_arr_slice_u8_mct136
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_arr_slice_u8_mc136
.Lssa___fern_arr_slice_u8_mct136:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_arr_slice_u8_mcd136
.Lssa___fern_arr_slice_u8_mcb136:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_arr_slice_u8_mcb136
.Lssa___fern_arr_slice_u8_mcd136:
    mov x0, #0
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
    .section .rodata
.S0: .ascii "HeaderMap"
.S1: .ascii "http__RequestParseError$http__Incomplete"
.S2: .ascii "http__RequestParseError$http__NeedsContinue"
.S3: .ascii "http__RequestParseError$http__Malformed"
.S4: .ascii ""
.S5: .ascii "\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\000\000\000\000\000\000\000\000\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\n\r"
.S6: .ascii "\027\003\007\003\003\003\003\003\007\007\013\253/\253\013\217\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\377\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\001\000\000\000\000\000\001\001\000\000\001\000\000\001\000\000\000\000\000\000\000\000\000\000\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001"
.S7: .ascii "OPTIONS"
.S8: .ascii "*"
.S9: .ascii "\003\003\003\003\003\003\003\003\003\002\003\003\003\003\003\203\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\002\004\010\020 @\200\001\002\004\010\020 @\200\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\217\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\200\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017\001\001\001\001\001\001\001\001\001\000\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
.S10: .ascii "HTTP/1.0"
.S11: .ascii "HTTP/1.1"
.S12: .ascii "host"
.S13: .ascii "expect"
.S14: .ascii "connection"
.S15: .ascii "content-length"
.S16: .ascii "transfer-encoding"
.S17: .ascii "100-continue"
.S18: .ascii ","
.S19: .ascii "chunked"
.S20: .ascii "close"
.S21: .ascii "keep-alive"
.S22: .ascii "ByteStream"
.S23: .ascii "HttpRequest"
.S24: .ascii "http__HttpFramed"
.S25: .ascii "http://"
.S26: .ascii "https://"
.S27: .ascii "!$&'()*+,;="
.S28: .ascii "0"
.S29: .ascii "1"
.S30: .ascii "2"
.S31: .ascii "3"
.S32: .ascii "4"
.S33: .ascii "5"
.S34: .ascii "6"
.S35: .ascii "7"
.S36: .ascii "8"
.S37: .ascii "9"
.S38: .ascii "10"
.S39: .ascii "11"
.S40: .ascii "12"
.S41: .ascii "13"
.S42: .ascii "14"
.S43: .ascii "15"
.S44: .ascii "16"
.S45: .ascii "17"
.S46: .ascii "18"
.S47: .ascii "19"
.S48: .ascii "20"
.S49: .ascii "21"
.S50: .ascii "22"
.S51: .ascii "23"
.S52: .ascii "24"
.S53: .ascii "25"
.S54: .ascii "26"
.S55: .ascii "27"
.S56: .ascii "28"
.S57: .ascii "29"
.S58: .ascii "30"
.S59: .ascii "31"
.S60: .ascii "32"
.S61: .ascii "33"
.S62: .ascii "34"
.S63: .ascii "35"
.S64: .ascii "36"
.S65: .ascii "37"
.S66: .ascii "38"
.S67: .ascii "39"
.S68: .ascii "40"
.S69: .ascii "41"
.S70: .ascii "42"
.S71: .ascii "43"
.S72: .ascii "44"
.S73: .ascii "45"
.S74: .ascii "46"
.S75: .ascii "47"
.S76: .ascii "48"
.S77: .ascii "49"
.S78: .ascii "50"
.S79: .ascii "51"
.S80: .ascii "52"
.S81: .ascii "53"
.S82: .ascii "54"
.S83: .ascii "55"
.S84: .ascii "56"
.S85: .ascii "57"
.S86: .ascii "58"
.S87: .ascii "59"
.S88: .ascii "60"
.S89: .ascii "61"
.S90: .ascii "62"
.S91: .ascii "63"
.S92: .ascii "64"
.S93: .ascii "65"
.S94: .ascii "66"
.S95: .ascii "67"
.S96: .ascii "68"
.S97: .ascii "69"
.S98: .ascii "70"
.S99: .ascii "71"
.S100: .ascii "72"
.S101: .ascii "73"
.S102: .ascii "74"
.S103: .ascii "75"
.S104: .ascii "76"
.S105: .ascii "77"
.S106: .ascii "78"
.S107: .ascii "79"
.S108: .ascii "80"
.S109: .ascii "81"
.S110: .ascii "82"
.S111: .ascii "83"
.S112: .ascii "84"
.S113: .ascii "85"
.S114: .ascii "86"
.S115: .ascii "87"
.S116: .ascii "88"
.S117: .ascii "89"
.S118: .ascii "90"
.S119: .ascii "91"
.S120: .ascii "92"
.S121: .ascii "93"
.S122: .ascii "94"
.S123: .ascii "95"
.S124: .ascii "96"
.S125: .ascii "97"
.S126: .ascii "98"
.S127: .ascii "99"
.S128: .ascii "00010203040506070809101112131415161718192021222324252627282930313233343536373839404142434445464748495051525354555657585960616263646566676869707172737475767778798081828384858687888990919293949596979899"
.S129: .ascii "deflate____ReadPhase$deflate__ReadHeader"
.S130: .ascii "deflate____ReadPhase$deflate__ReadStored"
.S131: .ascii "deflate____ReadPhase$deflate__ReadCodes"
.S132: .ascii "deflate____ReadPhase$deflate__ReadCopy"
.S133: .ascii "deflate____ReadPhase$deflate__ReadEnd"
.S134: .ascii "codec__DecodeErrorKind$codec__InvalidByte"
.S135: .ascii "codec__DecodeErrorKind$codec__InvalidLength"
.S136: .ascii "codec__DecodeErrorKind$codec__InvalidPadding"
.S137: .ascii "codec__DecodeErrorKind$codec__NonZeroTrailingBits"
.S138: .ascii "GET /hello HTTP/1.1\r\nHost: bench\r\nUser-Agent: perf-bench\r\nAccept: */*\r\n\r\n"
.S139: .ascii "hello "
.S140: .ascii "GET"
.S141: .ascii "Content-Length: "
.S142: .ascii "\r\n"
.S143: .ascii "HTTP/1.1 "
.S144: .ascii " "
.S145: .ascii "Continue"
.S146: .ascii "Switching Protocols"
.S147: .ascii "OK"
.S148: .ascii "Created"
.S149: .ascii "Accepted"
.S150: .ascii "Non-Authoritative Information"
.S151: .ascii "No Content"
.S152: .ascii "Reset Content"
.S153: .ascii "Partial Content"
.S154: .ascii "Multiple Choices"
.S155: .ascii "Moved Permanently"
.S156: .ascii "Found"
.S157: .ascii "See Other"
.S158: .ascii "Not Modified"
.S159: .ascii "Use Proxy"
.S160: .ascii "Temporary Redirect"
.S161: .ascii "Permanent Redirect"
.S162: .ascii "Bad Request"
.S163: .ascii "Unauthorized"
.S164: .ascii "Payment Required"
.S165: .ascii "Forbidden"
.S166: .ascii "Not Found"
.S167: .ascii "Method Not Allowed"
.S168: .ascii "Not Acceptable"
.S169: .ascii "Proxy Authentication Required"
.S170: .ascii "Request Timeout"
.S171: .ascii "Conflict"
.S172: .ascii "Gone"
.S173: .ascii "Length Required"
.S174: .ascii "Precondition Failed"
.S175: .ascii "Payload Too Large"
.S176: .ascii "URI Too Long"
.S177: .ascii "Unsupported Media Type"
.S178: .ascii "Range Not Satisfiable"
.S179: .ascii "Expectation Failed"
.S180: .ascii "I'm a teapot"
.S181: .ascii "Misdirected Request"
.S182: .ascii "Unprocessable Entity"
.S183: .ascii "Upgrade Required"
.S184: .ascii "Precondition Required"
.S185: .ascii "Too Many Requests"
.S186: .ascii "Request Header Fields Too Large"
.S187: .ascii "Internal Server Error"
.S188: .ascii "Not Implemented"
.S189: .ascii "Bad Gateway"
.S190: .ascii "Service Unavailable"
.S191: .ascii "Gateway Timeout"
.S192: .ascii "HTTP Version Not Supported"
.S193: .ascii "Network Authentication Required"
.S194: .ascii "Status"
.S195: .ascii ": "
.S196: .ascii "Connection: close\r\n\r\n"
.S197: .ascii "HEAD"
    .section .data
    .align 8
.Lfern_relanchor:
    .quad .Lfern_relanchor
    .section .data.rel.ro
    .align 8
.Lfern_sbox_begin:
    .section .data.rel.ro
    .align 8
    .quad -1
.SB0:
    .quad .S0
    .quad 9
    .quad -1
.SB1:
    .quad .S1
    .quad 40
    .quad -1
.SB2:
    .quad .S2
    .quad 43
    .quad -1
.SB3:
    .quad .S3
    .quad 39
    .quad -1
.SB4:
    .quad .S4
    .quad 0
    .quad -1
.SB5:
    .quad .S5
    .quad 354
    .quad -1
.SB6:
    .quad .S6
    .quad 352
    .quad -1
.SB7:
    .quad .S7
    .quad 7
    .quad -1
.SB8:
    .quad .S8
    .quad 1
    .quad -1
.SB9:
    .quad .S9
    .quad 352
    .quad -1
.SB10:
    .quad .S10
    .quad 8
    .quad -1
.SB11:
    .quad .S11
    .quad 8
    .quad -1
.SB12:
    .quad .S12
    .quad 4
    .quad -1
.SB13:
    .quad .S13
    .quad 6
    .quad -1
.SB14:
    .quad .S14
    .quad 10
    .quad -1
.SB15:
    .quad .S15
    .quad 14
    .quad -1
.SB16:
    .quad .S16
    .quad 17
    .quad -1
.SB17:
    .quad .S17
    .quad 12
    .quad -1
.SB18:
    .quad .S18
    .quad 1
    .quad -1
.SB19:
    .quad .S19
    .quad 7
    .quad -1
.SB20:
    .quad .S20
    .quad 5
    .quad -1
.SB21:
    .quad .S21
    .quad 10
    .quad -1
.SB22:
    .quad .S22
    .quad 10
    .quad -1
.SB23:
    .quad .S23
    .quad 11
    .quad -1
.SB24:
    .quad .S24
    .quad 16
    .quad -1
.SB25:
    .quad .S25
    .quad 7
    .quad -1
.SB26:
    .quad .S26
    .quad 8
    .quad -1
.SB27:
    .quad .S27
    .quad 11
    .quad -1
.SB28:
    .quad .S28
    .quad 1
    .quad -1
.SB29:
    .quad .S29
    .quad 1
    .quad -1
.SB30:
    .quad .S30
    .quad 1
    .quad -1
.SB31:
    .quad .S31
    .quad 1
    .quad -1
.SB32:
    .quad .S32
    .quad 1
    .quad -1
.SB33:
    .quad .S33
    .quad 1
    .quad -1
.SB34:
    .quad .S34
    .quad 1
    .quad -1
.SB35:
    .quad .S35
    .quad 1
    .quad -1
.SB36:
    .quad .S36
    .quad 1
    .quad -1
.SB37:
    .quad .S37
    .quad 1
    .quad -1
.SB38:
    .quad .S38
    .quad 2
    .quad -1
.SB39:
    .quad .S39
    .quad 2
    .quad -1
.SB40:
    .quad .S40
    .quad 2
    .quad -1
.SB41:
    .quad .S41
    .quad 2
    .quad -1
.SB42:
    .quad .S42
    .quad 2
    .quad -1
.SB43:
    .quad .S43
    .quad 2
    .quad -1
.SB44:
    .quad .S44
    .quad 2
    .quad -1
.SB45:
    .quad .S45
    .quad 2
    .quad -1
.SB46:
    .quad .S46
    .quad 2
    .quad -1
.SB47:
    .quad .S47
    .quad 2
    .quad -1
.SB48:
    .quad .S48
    .quad 2
    .quad -1
.SB49:
    .quad .S49
    .quad 2
    .quad -1
.SB50:
    .quad .S50
    .quad 2
    .quad -1
.SB51:
    .quad .S51
    .quad 2
    .quad -1
.SB52:
    .quad .S52
    .quad 2
    .quad -1
.SB53:
    .quad .S53
    .quad 2
    .quad -1
.SB54:
    .quad .S54
    .quad 2
    .quad -1
.SB55:
    .quad .S55
    .quad 2
    .quad -1
.SB56:
    .quad .S56
    .quad 2
    .quad -1
.SB57:
    .quad .S57
    .quad 2
    .quad -1
.SB58:
    .quad .S58
    .quad 2
    .quad -1
.SB59:
    .quad .S59
    .quad 2
    .quad -1
.SB60:
    .quad .S60
    .quad 2
    .quad -1
.SB61:
    .quad .S61
    .quad 2
    .quad -1
.SB62:
    .quad .S62
    .quad 2
    .quad -1
.SB63:
    .quad .S63
    .quad 2
    .quad -1
.SB64:
    .quad .S64
    .quad 2
    .quad -1
.SB65:
    .quad .S65
    .quad 2
    .quad -1
.SB66:
    .quad .S66
    .quad 2
    .quad -1
.SB67:
    .quad .S67
    .quad 2
    .quad -1
.SB68:
    .quad .S68
    .quad 2
    .quad -1
.SB69:
    .quad .S69
    .quad 2
    .quad -1
.SB70:
    .quad .S70
    .quad 2
    .quad -1
.SB71:
    .quad .S71
    .quad 2
    .quad -1
.SB72:
    .quad .S72
    .quad 2
    .quad -1
.SB73:
    .quad .S73
    .quad 2
    .quad -1
.SB74:
    .quad .S74
    .quad 2
    .quad -1
.SB75:
    .quad .S75
    .quad 2
    .quad -1
.SB76:
    .quad .S76
    .quad 2
    .quad -1
.SB77:
    .quad .S77
    .quad 2
    .quad -1
.SB78:
    .quad .S78
    .quad 2
    .quad -1
.SB79:
    .quad .S79
    .quad 2
    .quad -1
.SB80:
    .quad .S80
    .quad 2
    .quad -1
.SB81:
    .quad .S81
    .quad 2
    .quad -1
.SB82:
    .quad .S82
    .quad 2
    .quad -1
.SB83:
    .quad .S83
    .quad 2
    .quad -1
.SB84:
    .quad .S84
    .quad 2
    .quad -1
.SB85:
    .quad .S85
    .quad 2
    .quad -1
.SB86:
    .quad .S86
    .quad 2
    .quad -1
.SB87:
    .quad .S87
    .quad 2
    .quad -1
.SB88:
    .quad .S88
    .quad 2
    .quad -1
.SB89:
    .quad .S89
    .quad 2
    .quad -1
.SB90:
    .quad .S90
    .quad 2
    .quad -1
.SB91:
    .quad .S91
    .quad 2
    .quad -1
.SB92:
    .quad .S92
    .quad 2
    .quad -1
.SB93:
    .quad .S93
    .quad 2
    .quad -1
.SB94:
    .quad .S94
    .quad 2
    .quad -1
.SB95:
    .quad .S95
    .quad 2
    .quad -1
.SB96:
    .quad .S96
    .quad 2
    .quad -1
.SB97:
    .quad .S97
    .quad 2
    .quad -1
.SB98:
    .quad .S98
    .quad 2
    .quad -1
.SB99:
    .quad .S99
    .quad 2
    .quad -1
.SB100:
    .quad .S100
    .quad 2
    .quad -1
.SB101:
    .quad .S101
    .quad 2
    .quad -1
.SB102:
    .quad .S102
    .quad 2
    .quad -1
.SB103:
    .quad .S103
    .quad 2
    .quad -1
.SB104:
    .quad .S104
    .quad 2
    .quad -1
.SB105:
    .quad .S105
    .quad 2
    .quad -1
.SB106:
    .quad .S106
    .quad 2
    .quad -1
.SB107:
    .quad .S107
    .quad 2
    .quad -1
.SB108:
    .quad .S108
    .quad 2
    .quad -1
.SB109:
    .quad .S109
    .quad 2
    .quad -1
.SB110:
    .quad .S110
    .quad 2
    .quad -1
.SB111:
    .quad .S111
    .quad 2
    .quad -1
.SB112:
    .quad .S112
    .quad 2
    .quad -1
.SB113:
    .quad .S113
    .quad 2
    .quad -1
.SB114:
    .quad .S114
    .quad 2
    .quad -1
.SB115:
    .quad .S115
    .quad 2
    .quad -1
.SB116:
    .quad .S116
    .quad 2
    .quad -1
.SB117:
    .quad .S117
    .quad 2
    .quad -1
.SB118:
    .quad .S118
    .quad 2
    .quad -1
.SB119:
    .quad .S119
    .quad 2
    .quad -1
.SB120:
    .quad .S120
    .quad 2
    .quad -1
.SB121:
    .quad .S121
    .quad 2
    .quad -1
.SB122:
    .quad .S122
    .quad 2
    .quad -1
.SB123:
    .quad .S123
    .quad 2
    .quad -1
.SB124:
    .quad .S124
    .quad 2
    .quad -1
.SB125:
    .quad .S125
    .quad 2
    .quad -1
.SB126:
    .quad .S126
    .quad 2
    .quad -1
.SB127:
    .quad .S127
    .quad 2
    .quad -1
.SB128:
    .quad .S128
    .quad 200
    .quad -1
.SB129:
    .quad .S129
    .quad 40
    .quad -1
.SB130:
    .quad .S130
    .quad 40
    .quad -1
.SB131:
    .quad .S131
    .quad 39
    .quad -1
.SB132:
    .quad .S132
    .quad 38
    .quad -1
.SB133:
    .quad .S133
    .quad 37
    .quad -1
.SB134:
    .quad .S134
    .quad 41
    .quad -1
.SB135:
    .quad .S135
    .quad 43
    .quad -1
.SB136:
    .quad .S136
    .quad 44
    .quad -1
.SB137:
    .quad .S137
    .quad 49
    .quad -1
.SB138:
    .quad .S138
    .quad 73
    .quad -1
.SB139:
    .quad .S139
    .quad 6
    .quad -1
.SB140:
    .quad .S140
    .quad 3
    .quad -1
.SB141:
    .quad .S141
    .quad 16
    .quad -1
.SB142:
    .quad .S142
    .quad 2
    .quad -1
.SB143:
    .quad .S143
    .quad 9
    .quad -1
.SB144:
    .quad .S144
    .quad 1
    .quad -1
.SB145:
    .quad .S145
    .quad 8
    .quad -1
.SB146:
    .quad .S146
    .quad 19
    .quad -1
.SB147:
    .quad .S147
    .quad 2
    .quad -1
.SB148:
    .quad .S148
    .quad 7
    .quad -1
.SB149:
    .quad .S149
    .quad 8
    .quad -1
.SB150:
    .quad .S150
    .quad 29
    .quad -1
.SB151:
    .quad .S151
    .quad 10
    .quad -1
.SB152:
    .quad .S152
    .quad 13
    .quad -1
.SB153:
    .quad .S153
    .quad 15
    .quad -1
.SB154:
    .quad .S154
    .quad 16
    .quad -1
.SB155:
    .quad .S155
    .quad 17
    .quad -1
.SB156:
    .quad .S156
    .quad 5
    .quad -1
.SB157:
    .quad .S157
    .quad 9
    .quad -1
.SB158:
    .quad .S158
    .quad 12
    .quad -1
.SB159:
    .quad .S159
    .quad 9
    .quad -1
.SB160:
    .quad .S160
    .quad 18
    .quad -1
.SB161:
    .quad .S161
    .quad 18
    .quad -1
.SB162:
    .quad .S162
    .quad 11
    .quad -1
.SB163:
    .quad .S163
    .quad 12
    .quad -1
.SB164:
    .quad .S164
    .quad 16
    .quad -1
.SB165:
    .quad .S165
    .quad 9
    .quad -1
.SB166:
    .quad .S166
    .quad 9
    .quad -1
.SB167:
    .quad .S167
    .quad 18
    .quad -1
.SB168:
    .quad .S168
    .quad 14
    .quad -1
.SB169:
    .quad .S169
    .quad 29
    .quad -1
.SB170:
    .quad .S170
    .quad 15
    .quad -1
.SB171:
    .quad .S171
    .quad 8
    .quad -1
.SB172:
    .quad .S172
    .quad 4
    .quad -1
.SB173:
    .quad .S173
    .quad 15
    .quad -1
.SB174:
    .quad .S174
    .quad 19
    .quad -1
.SB175:
    .quad .S175
    .quad 17
    .quad -1
.SB176:
    .quad .S176
    .quad 12
    .quad -1
.SB177:
    .quad .S177
    .quad 22
    .quad -1
.SB178:
    .quad .S178
    .quad 21
    .quad -1
.SB179:
    .quad .S179
    .quad 18
    .quad -1
.SB180:
    .quad .S180
    .quad 12
    .quad -1
.SB181:
    .quad .S181
    .quad 19
    .quad -1
.SB182:
    .quad .S182
    .quad 20
    .quad -1
.SB183:
    .quad .S183
    .quad 16
    .quad -1
.SB184:
    .quad .S184
    .quad 21
    .quad -1
.SB185:
    .quad .S185
    .quad 17
    .quad -1
.SB186:
    .quad .S186
    .quad 31
    .quad -1
.SB187:
    .quad .S187
    .quad 21
    .quad -1
.SB188:
    .quad .S188
    .quad 15
    .quad -1
.SB189:
    .quad .S189
    .quad 11
    .quad -1
.SB190:
    .quad .S190
    .quad 19
    .quad -1
.SB191:
    .quad .S191
    .quad 15
    .quad -1
.SB192:
    .quad .S192
    .quad 26
    .quad -1
.SB193:
    .quad .S193
    .quad 31
    .quad -1
.SB194:
    .quad .S194
    .quad 6
    .quad -1
.SB195:
    .quad .S195
    .quad 2
    .quad -1
.SB196:
    .quad .S196
    .quad 21
    .quad -1
.SB197:
    .quad .S197
    .quad 4
.Lfern_sbox_end:
    .section .data
    .align 8
    .quad 0
    .quad -1
.K0:
    .quad 0
    .quad 0
    .quad -1
.K4:
    .quad 14
    .byte 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1
    .balign 8
    .quad 0
    .quad -1
.K5:
    .quad 256
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
    .balign 8
    .quad 0
    .quad -1
.K6:
    .quad 5
    .byte 72, 84, 84, 80, 47
    .balign 8
    .quad 0
    .quad -1
.K7:
    .quad 0
    .balign 8
    .quad 0
    .quad -1
.K8:
    .quad 128
    .byte 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1
    .balign 8
    .quad 2
    .quad -1
.K9:
    .quad 1
    .quad 0
    .quad 100
    .quad -1
.K10:
    .quad 100
.K10_0:
    .quad .SB28
.K10_1:
    .quad .SB29
.K10_2:
    .quad .SB30
.K10_3:
    .quad .SB31
.K10_4:
    .quad .SB32
.K10_5:
    .quad .SB33
.K10_6:
    .quad .SB34
.K10_7:
    .quad .SB35
.K10_8:
    .quad .SB36
.K10_9:
    .quad .SB37
.K10_10:
    .quad .SB38
.K10_11:
    .quad .SB39
.K10_12:
    .quad .SB40
.K10_13:
    .quad .SB41
.K10_14:
    .quad .SB42
.K10_15:
    .quad .SB43
.K10_16:
    .quad .SB44
.K10_17:
    .quad .SB45
.K10_18:
    .quad .SB46
.K10_19:
    .quad .SB47
.K10_20:
    .quad .SB48
.K10_21:
    .quad .SB49
.K10_22:
    .quad .SB50
.K10_23:
    .quad .SB51
.K10_24:
    .quad .SB52
.K10_25:
    .quad .SB53
.K10_26:
    .quad .SB54
.K10_27:
    .quad .SB55
.K10_28:
    .quad .SB56
.K10_29:
    .quad .SB57
.K10_30:
    .quad .SB58
.K10_31:
    .quad .SB59
.K10_32:
    .quad .SB60
.K10_33:
    .quad .SB61
.K10_34:
    .quad .SB62
.K10_35:
    .quad .SB63
.K10_36:
    .quad .SB64
.K10_37:
    .quad .SB65
.K10_38:
    .quad .SB66
.K10_39:
    .quad .SB67
.K10_40:
    .quad .SB68
.K10_41:
    .quad .SB69
.K10_42:
    .quad .SB70
.K10_43:
    .quad .SB71
.K10_44:
    .quad .SB72
.K10_45:
    .quad .SB73
.K10_46:
    .quad .SB74
.K10_47:
    .quad .SB75
.K10_48:
    .quad .SB76
.K10_49:
    .quad .SB77
.K10_50:
    .quad .SB78
.K10_51:
    .quad .SB79
.K10_52:
    .quad .SB80
.K10_53:
    .quad .SB81
.K10_54:
    .quad .SB82
.K10_55:
    .quad .SB83
.K10_56:
    .quad .SB84
.K10_57:
    .quad .SB85
.K10_58:
    .quad .SB86
.K10_59:
    .quad .SB87
.K10_60:
    .quad .SB88
.K10_61:
    .quad .SB89
.K10_62:
    .quad .SB90
.K10_63:
    .quad .SB91
.K10_64:
    .quad .SB92
.K10_65:
    .quad .SB93
.K10_66:
    .quad .SB94
.K10_67:
    .quad .SB95
.K10_68:
    .quad .SB96
.K10_69:
    .quad .SB97
.K10_70:
    .quad .SB98
.K10_71:
    .quad .SB99
.K10_72:
    .quad .SB100
.K10_73:
    .quad .SB101
.K10_74:
    .quad .SB102
.K10_75:
    .quad .SB103
.K10_76:
    .quad .SB104
.K10_77:
    .quad .SB105
.K10_78:
    .quad .SB106
.K10_79:
    .quad .SB107
.K10_80:
    .quad .SB108
.K10_81:
    .quad .SB109
.K10_82:
    .quad .SB110
.K10_83:
    .quad .SB111
.K10_84:
    .quad .SB112
.K10_85:
    .quad .SB113
.K10_86:
    .quad .SB114
.K10_87:
    .quad .SB115
.K10_88:
    .quad .SB116
.K10_89:
    .quad .SB117
.K10_90:
    .quad .SB118
.K10_91:
    .quad .SB119
.K10_92:
    .quad .SB120
.K10_93:
    .quad .SB121
.K10_94:
    .quad .SB122
.K10_95:
    .quad .SB123
.K10_96:
    .quad .SB124
.K10_97:
    .quad .SB125
.K10_98:
    .quad .SB126
.K10_99:
    .quad .SB127
    .quad 49
    .quad -1
.K11:
    .quad 49
    .quad 100
    .quad 101
    .quad 200
    .quad 201
    .quad 202
    .quad 203
    .quad 204
    .quad 205
    .quad 206
    .quad 300
    .quad 301
    .quad 302
    .quad 303
    .quad 304
    .quad 305
    .quad 307
    .quad 308
    .quad 400
    .quad 401
    .quad 402
    .quad 403
    .quad 404
    .quad 405
    .quad 406
    .quad 407
    .quad 408
    .quad 409
    .quad 410
    .quad 411
    .quad 412
    .quad 413
    .quad 414
    .quad 415
    .quad 416
    .quad 417
    .quad 418
    .quad 421
    .quad 422
    .quad 426
    .quad 428
    .quad 429
    .quad 431
    .quad 500
    .quad 501
    .quad 502
    .quad 503
    .quad 504
    .quad 505
    .quad 511
    .quad 49
    .quad -1
.K12:
    .quad 49
.K12_0:
    .quad .SB145
.K12_1:
    .quad .SB146
.K12_2:
    .quad .SB147
.K12_3:
    .quad .SB148
.K12_4:
    .quad .SB149
.K12_5:
    .quad .SB150
.K12_6:
    .quad .SB151
.K12_7:
    .quad .SB152
.K12_8:
    .quad .SB153
.K12_9:
    .quad .SB154
.K12_10:
    .quad .SB155
.K12_11:
    .quad .SB156
.K12_12:
    .quad .SB157
.K12_13:
    .quad .SB158
.K12_14:
    .quad .SB159
.K12_15:
    .quad .SB160
.K12_16:
    .quad .SB161
.K12_17:
    .quad .SB162
.K12_18:
    .quad .SB163
.K12_19:
    .quad .SB164
.K12_20:
    .quad .SB165
.K12_21:
    .quad .SB166
.K12_22:
    .quad .SB167
.K12_23:
    .quad .SB168
.K12_24:
    .quad .SB169
.K12_25:
    .quad .SB170
.K12_26:
    .quad .SB171
.K12_27:
    .quad .SB172
.K12_28:
    .quad .SB173
.K12_29:
    .quad .SB174
.K12_30:
    .quad .SB175
.K12_31:
    .quad .SB176
.K12_32:
    .quad .SB177
.K12_33:
    .quad .SB178
.K12_34:
    .quad .SB179
.K12_35:
    .quad .SB180
.K12_36:
    .quad .SB181
.K12_37:
    .quad .SB182
.K12_38:
    .quad .SB183
.K12_39:
    .quad .SB184
.K12_40:
    .quad .SB185
.K12_41:
    .quad .SB186
.K12_42:
    .quad .SB187
.K12_43:
    .quad .SB188
.K12_44:
    .quad .SB189
.K12_45:
    .quad .SB190
.K12_46:
    .quad .SB191
.K12_47:
    .quad .SB192
.K12_48:
    .quad .SB193
    .section .data.rel.ro
    .align 8
.Lfern_cagg_begin:
    .section .data.rel.ro
    .align 8
    .quad 3
    .quad -1
.K1:
    .quad .S0
.K1_0:
    .quad .K0
.K1_1:
    .quad .K0
    .quad 1
    .quad -1
.K2:
    .quad .S1
    .quad 1
    .quad -1
.K3:
    .quad .S2
.Lfern_cagg_end:
    .align 8
.Lfern_cfn_begin:
.Lfern_cfn_end:
    .align 8
.Lfern_cref_begin:
    .quad .K1_0
    .quad .K1_1
    .quad .K10_0
    .quad .K10_1
    .quad .K10_2
    .quad .K10_3
    .quad .K10_4
    .quad .K10_5
    .quad .K10_6
    .quad .K10_7
    .quad .K10_8
    .quad .K10_9
    .quad .K10_10
    .quad .K10_11
    .quad .K10_12
    .quad .K10_13
    .quad .K10_14
    .quad .K10_15
    .quad .K10_16
    .quad .K10_17
    .quad .K10_18
    .quad .K10_19
    .quad .K10_20
    .quad .K10_21
    .quad .K10_22
    .quad .K10_23
    .quad .K10_24
    .quad .K10_25
    .quad .K10_26
    .quad .K10_27
    .quad .K10_28
    .quad .K10_29
    .quad .K10_30
    .quad .K10_31
    .quad .K10_32
    .quad .K10_33
    .quad .K10_34
    .quad .K10_35
    .quad .K10_36
    .quad .K10_37
    .quad .K10_38
    .quad .K10_39
    .quad .K10_40
    .quad .K10_41
    .quad .K10_42
    .quad .K10_43
    .quad .K10_44
    .quad .K10_45
    .quad .K10_46
    .quad .K10_47
    .quad .K10_48
    .quad .K10_49
    .quad .K10_50
    .quad .K10_51
    .quad .K10_52
    .quad .K10_53
    .quad .K10_54
    .quad .K10_55
    .quad .K10_56
    .quad .K10_57
    .quad .K10_58
    .quad .K10_59
    .quad .K10_60
    .quad .K10_61
    .quad .K10_62
    .quad .K10_63
    .quad .K10_64
    .quad .K10_65
    .quad .K10_66
    .quad .K10_67
    .quad .K10_68
    .quad .K10_69
    .quad .K10_70
    .quad .K10_71
    .quad .K10_72
    .quad .K10_73
    .quad .K10_74
    .quad .K10_75
    .quad .K10_76
    .quad .K10_77
    .quad .K10_78
    .quad .K10_79
    .quad .K10_80
    .quad .K10_81
    .quad .K10_82
    .quad .K10_83
    .quad .K10_84
    .quad .K10_85
    .quad .K10_86
    .quad .K10_87
    .quad .K10_88
    .quad .K10_89
    .quad .K10_90
    .quad .K10_91
    .quad .K10_92
    .quad .K10_93
    .quad .K10_94
    .quad .K10_95
    .quad .K10_96
    .quad .K10_97
    .quad .K10_98
    .quad .K10_99
    .quad .K12_0
    .quad .K12_1
    .quad .K12_2
    .quad .K12_3
    .quad .K12_4
    .quad .K12_5
    .quad .K12_6
    .quad .K12_7
    .quad .K12_8
    .quad .K12_9
    .quad .K12_10
    .quad .K12_11
    .quad .K12_12
    .quad .K12_13
    .quad .K12_14
    .quad .K12_15
    .quad .K12_16
    .quad .K12_17
    .quad .K12_18
    .quad .K12_19
    .quad .K12_20
    .quad .K12_21
    .quad .K12_22
    .quad .K12_23
    .quad .K12_24
    .quad .K12_25
    .quad .K12_26
    .quad .K12_27
    .quad .K12_28
    .quad .K12_29
    .quad .K12_30
    .quad .K12_31
    .quad .K12_32
    .quad .K12_33
    .quad .K12_34
    .quad .K12_35
    .quad .K12_36
    .quad .K12_37
    .quad .K12_38
    .quad .K12_39
    .quad .K12_40
    .quad .K12_41
    .quad .K12_42
    .quad .K12_43
    .quad .K12_44
    .quad .K12_45
    .quad .K12_46
    .quad .K12_47
    .quad .K12_48
.Lfern_cref_end:
    .text
