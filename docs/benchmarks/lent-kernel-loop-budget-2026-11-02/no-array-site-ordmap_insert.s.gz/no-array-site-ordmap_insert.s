    .globl _start
    .text
__fn_main:
    .cfi_startproc
__fn_main.k:
__fn_main.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
.Lssa_main_0:
    adrp x0, .K2
    add x0, x0, :lo12:.K2
.Lssa_main_6:
    mov x19, x0
    mov x20, #0
.Lssa_main_7:
    cmp x20, #4000
    b.ge .Lssa_main_5
.Lssa_main_8:
    mov x9, #7
    mul x9, x20, x9
    sxtw x9, w9
    mov x0, x19
    mov x10, x20
    bl __fn_ordmap__OrdMap__i32__i32__insert.r
    mov x19, x0
    add x20, x20, #1
    cmp x20, #4000
    b.lt .Lssa_main_8
.Lssa_main_5:
.Lssa_main_4:
    mov x20, #0
.Lssa_main_15:
    cmp x20, #20
    b.ge .Lssa_main_3
.Lssa_main_18:
.Lssa_main_17:
    mov x21, #0
.Lssa_main_23:
    cmp x21, #4000
    b.ge .Lssa_main_16
.Lssa_main_24:
    mov x9, #7
    mul x9, x21, x9
    sxtw x9, w9
    add x10, x21, x20
    sxtw x10, w10
    mov x0, x19
    bl __fn_ordmap__OrdMap__i32__i32__insert.r
    mov x19, x0
    add x21, x21, #1
    cmp x21, #4000
    b.lt .Lssa_main_24
.Lssa_main_16:
    add x20, x20, #1
    cmp x20, #20
    b.lt .Lssa_main_18
.Lssa_main_3:
.Lssa_main_2:
    mov x20, #0
    mov x21, #0
.Lssa_main_33:
    cmp x20, #4000
    b.lt .Lssa_main_34
.Lssa_main_36:
    mov x0, x19
    bl __fn___sem_release_ordmap__OrdMap__i32__i32.r
    b .Lssa_main_1
.Lssa_main_34:
    mov x10, #7
    mul x10, x20, x10
    sxtw x9, w10
    mov x10, #0
    mov x0, x19
    bl __fn_ordmap__OrdMap__i32__i32__get_or.r
    sxtw x0, w0
    add x21, x21, x0
    add x20, x20, #1
    cmp x20, #4000
    b.ge .Lssa_main_36
    b .Lssa_main_34
.Lssa_main_1:
    mov x4, x21
    ldr x5, =-6275696437447579415
    smulh x5, x4, x5
    add x5, x5, x4
    asr x5, x5, #6
    add x5, x5, x5, lsr #63
    mov x6, #97
    msub x4, x5, x6, x4
    mov x10, x4
    sxtw x0, w10
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__OrdMap__i32__i32__insert:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_ordmap__OrdMap__i32__i32__insert.k:
__fn_ordmap__OrdMap__i32__i32__insert.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    mov x19, x9
    mov x20, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_0:
    tst x0, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq0
    cmp x0, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq0
    ldur w5, [x0, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq0:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_27
.Lssa_ordmap__OrdMap__i32__i32__insert_26:
    mov x9, x0
    b .Lssa_ordmap__OrdMap__i32__i32__insert_28
.Lssa_ordmap__OrdMap__i32__i32__insert_27:
    mov x9, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_28:
    ldr x21, [x0, #8]
    cmp x9, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_31
.Lssa_ordmap__OrdMap__i32__i32__insert_29:
    tbnz x21, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc127
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc127
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc127
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc127:
    mov x10, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_31:
    cmp x9, #0
    b.eq .Lssa_ordmap__OrdMap__i32__i32__insert_33
.Lssa_ordmap__OrdMap__i32__i32__insert_32:
    mov x22, x0
    b .Lssa_ordmap__OrdMap__i32__i32__insert_34
.Lssa_ordmap__OrdMap__i32__i32__insert_33:
    bl __fn___sem_release_ordmap__OrdMap__i32__i32.r
    mov x22, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_34:
    mov x0, x21
    mov x9, x19
    mov x10, x20
    bl __fn_ordmap__node_insert__i32__i32.r
    mov x23, x0
.Lssa_ordmap__OrdMap__i32__i32__insert_24:
    ldr x9, [x23, #0]
    adrp x10, .S1
    add x10, x10, :lo12:.S1
    cmp x9, x10
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_21
.Lssa_ordmap__OrdMap__i32__i32__insert_23:
    ldr x9, [x23, #24]
    ldr x10, [x9, #0]
    mov x9, x10
    b .Lssa_ordmap__OrdMap__i32__i32__insert_20
.Lssa_ordmap__OrdMap__i32__i32__insert_21:
    ldr x10, [x23, #32]
    ldr x9, [x10, #0]
.Lssa_ordmap__OrdMap__i32__i32__insert_20:
    cmp x9, #64
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_16
.Lssa_ordmap__OrdMap__i32__i32__insert_19:
    mov x21, x23
    b .Lssa_ordmap__OrdMap__i32__i32__insert_1
.Lssa_ordmap__OrdMap__i32__i32__insert_16:
    ldr x9, [x23, #0]
    adrp x10, .S1
    add x10, x10, :lo12:.S1
    cmp x9, x10
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_13
.Lssa_ordmap__OrdMap__i32__i32__insert_15:
    tst x23, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq15
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq15
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq15:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_50
.Lssa_ordmap__OrdMap__i32__i32__insert_49:
    mov x21, x23
    b .Lssa_ordmap__OrdMap__i32__i32__insert_51
.Lssa_ordmap__OrdMap__i32__i32__insert_50:
    mov x21, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_51:
    ldr x9, [x23, #16]
    cmp x21, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_54
.Lssa_ordmap__OrdMap__i32__i32__insert_52:
    tbnz x9, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc163
    cmp x9, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc163
    ldur w5, [x9, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc163
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc163:
    mov x0, x9
.Lssa_ordmap__OrdMap__i32__i32__insert_54:
    cmp x9, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck164
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd164
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck164
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece164
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd164:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck164:
    mov x0, x9
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece164:
    ldr x20, [x23, #24]
    cmp x21, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_57
.Lssa_ordmap__OrdMap__i32__i32__insert_55:
    tbnz x20, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc168
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc168
    ldur w5, [x20, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc168
    add w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc168:
    mov x0, x20
.Lssa_ordmap__OrdMap__i32__i32__insert_57:
    ldr x19, [x23, #32]
    cmp x21, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_60
.Lssa_ordmap__OrdMap__i32__i32__insert_58:
    tbnz x19, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc172
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc172
    ldur w5, [x19, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc172
    add w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc172:
    mov x0, x19
.Lssa_ordmap__OrdMap__i32__i32__insert_60:
    cmp x21, #0
    b.eq .Lssa_ordmap__OrdMap__i32__i32__insert_62
.Lssa_ordmap__OrdMap__i32__i32__insert_61:
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_63
.Lssa_ordmap__OrdMap__i32__i32__insert_62:
    mov x0, x23
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__OrdMap__i32__i32__insert_63:
    ldr x21, [x20, #0]
    asr x24, x21, #1
    mov x9, #0
    mov x0, x20
    mov x10, x24
    bl __fn_ordmap__span__i32.r
    mov x25, x0
    mov x9, #0
    mov x0, x19
    mov x10, x24
    bl __fn_ordmap__span__i32.r
    mov x26, x0
    mov x0, x25
    mov x9, x26
    bl __fn_ordmap__make_leaf__i32__i32.r
    mov x27, x0
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck186
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd186
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck186
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece186
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd186:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck186:
    mov x0, x25
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece186:
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck187
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd187
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck187
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece187
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd187:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck187:
    mov x0, x26
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece187:
    ldr x6, [x20]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    ldr x26, [x20, x5, lsl #3]
    mov x0, x20
    mov x9, x24
    mov x10, x21
    bl __fn_ordmap__span__i32.r
    mov x25, x0
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck190
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd190
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck190
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece190
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd190:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck190:
    mov x0, x20
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece190:
    mov x0, x19
    mov x9, x24
    mov x10, x21
    bl __fn_ordmap__span__i32.r
    mov x20, x0
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck192
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd192
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck192
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece192
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd192:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck192:
    mov x0, x19
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece192:
    mov x0, x25
    mov x9, x20
    bl __fn_ordmap__make_leaf__i32__i32.r
    mov x19, x0
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck194
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd194
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck194
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece194
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd194:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck194:
    mov x0, x25
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece194:
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck195
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd195
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck195
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece195
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd195:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck195:
    mov x0, x20
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece195:
    mov x28, x27
    mov x27, x19
    b .Lssa_ordmap__OrdMap__i32__i32__insert_12
.Lssa_ordmap__OrdMap__i32__i32__insert_13:
    tst x23, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq13
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq13
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq13:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_66
.Lssa_ordmap__OrdMap__i32__i32__insert_65:
    mov x19, x23
    b .Lssa_ordmap__OrdMap__i32__i32__insert_67
.Lssa_ordmap__OrdMap__i32__i32__insert_66:
    mov x19, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_67:
    ldr x9, [x23, #16]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_70
.Lssa_ordmap__OrdMap__i32__i32__insert_68:
    tbnz x9, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc203
    cmp x9, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc203
    ldur w5, [x9, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc203
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc203:
    mov x0, x9
.Lssa_ordmap__OrdMap__i32__i32__insert_70:
    cmp x9, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck204
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd204
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck204
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece204
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd204:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck204:
    mov x0, x9
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece204:
    ldr x20, [x23, #24]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_73
.Lssa_ordmap__OrdMap__i32__i32__insert_71:
    tbnz x20, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc208
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc208
    ldur w5, [x20, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc208
    add w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc208:
    mov x0, x20
.Lssa_ordmap__OrdMap__i32__i32__insert_73:
    ldr x26, [x23, #32]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_76
.Lssa_ordmap__OrdMap__i32__i32__insert_74:
    tbnz x26, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc212
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc212
    ldur w5, [x26, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc212
    add w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc212:
    mov x0, x26
.Lssa_ordmap__OrdMap__i32__i32__insert_76:
    ldr x27, [x23, #40]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_79
.Lssa_ordmap__OrdMap__i32__i32__insert_77:
    tbnz x27, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc216
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc216
    ldur w5, [x27, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc216
    add w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc216:
    mov x0, x27
.Lssa_ordmap__OrdMap__i32__i32__insert_79:
    cmp x19, #0
    b.eq .Lssa_ordmap__OrdMap__i32__i32__insert_81
.Lssa_ordmap__OrdMap__i32__i32__insert_80:
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_82
.Lssa_ordmap__OrdMap__i32__i32__insert_81:
    mov x0, x23
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__OrdMap__i32__i32__insert_82:
    ldr x23, [x26, #0]
    asr x19, x23, #1
    sub x9, x19, #1
    sxtw x10, w9
    mov x9, #0
    mov x0, x20
    bl __fn_ordmap__span__i32.r
    mov x25, x0
    mov x9, #0
    mov x0, x26
    mov x10, x19
    bl __fn_ordmap__span__ordmap__Node__i32__i32.r
    mov x24, x0
    mov x9, #0
    mov x0, x27
    mov x10, x19
    bl __fn_ordmap__span__i32.r
    mov x21, x0
    mov x0, x25
    mov x9, x24
    mov x10, x21
    bl __fn_ordmap__make_branch__i32__i32.r
    mov x28, x0
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck236
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd236
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck236
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece236
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd236:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck236:
    mov x0, x25
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece236:
    tst x24, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq82
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq82
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq82:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_85
.Lssa_ordmap__OrdMap__i32__i32__insert_83:
    mov x25, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_87:
    ldr x9, [x24, #0]
    cmp x25, x9
    b.ge .Lssa_ordmap__OrdMap__i32__i32__insert_85
.Lssa_ordmap__OrdMap__i32__i32__insert_88:
    add x5, x25, #1
    ldr x0, [x24, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x25, x25, #1
    b .Lssa_ordmap__OrdMap__i32__i32__insert_87
.Lssa_ordmap__OrdMap__i32__i32__insert_85:
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck247
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd247
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck247
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece247
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd247:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck247:
    mov x0, x24
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece247:
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck248
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd248
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck248
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece248
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd248:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck248:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece248:
    sub x9, x23, #1
    sxtw x10, w9
    mov x0, x20
    mov x9, x19
    bl __fn_ordmap__span__i32.r
    mov x21, x0
    mov x0, x26
    mov x9, x19
    mov x10, x23
    bl __fn_ordmap__span__ordmap__Node__i32__i32.r
    mov x24, x0
    tst x26, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq85
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq85
    ldur w5, [x26, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq85:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_93
.Lssa_ordmap__OrdMap__i32__i32__insert_91:
    mov x25, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_95:
    ldr x10, [x26, #0]
    cmp x25, x10
    b.ge .Lssa_ordmap__OrdMap__i32__i32__insert_93
.Lssa_ordmap__OrdMap__i32__i32__insert_96:
    add x5, x25, #1
    ldr x0, [x26, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x25, x25, #1
    b .Lssa_ordmap__OrdMap__i32__i32__insert_95
.Lssa_ordmap__OrdMap__i32__i32__insert_93:
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck264
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd264
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck264
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece264
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd264:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck264:
    mov x0, x26
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece264:
    mov x0, x27
    mov x9, x19
    mov x10, x23
    bl __fn_ordmap__span__i32.r
    mov x26, x0
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck266
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd266
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck266
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece266
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd266:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck266:
    mov x0, x27
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece266:
    mov x0, x21
    mov x9, x24
    mov x10, x26
    bl __fn_ordmap__make_branch__i32__i32.r
    mov x27, x0
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck268
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd268
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck268
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece268
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd268:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck268:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece268:
    tst x24, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq93
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq93
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq93:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_101
.Lssa_ordmap__OrdMap__i32__i32__insert_99:
    mov x21, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_103:
    ldr x10, [x24, #0]
    cmp x21, x10
    b.ge .Lssa_ordmap__OrdMap__i32__i32__insert_101
.Lssa_ordmap__OrdMap__i32__i32__insert_104:
    add x5, x21, #1
    ldr x0, [x24, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x21, x21, #1
    b .Lssa_ordmap__OrdMap__i32__i32__insert_103
.Lssa_ordmap__OrdMap__i32__i32__insert_101:
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck279
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd279
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck279
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece279
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd279:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck279:
    mov x0, x24
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece279:
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck280
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd280
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck280
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece280
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd280:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck280:
    mov x0, x26
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece280:
    sub w19, w19, #1
    ldr x6, [x20]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x26, [x20, x5, lsl #3]
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck285
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd285
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck285
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece285
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd285:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck285:
    mov x0, x20
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece285:
.Lssa_ordmap__OrdMap__i32__i32__insert_12:
    mov x0, #1
    bl __fern_arr_box
    mov x20, x0
    str x26, [x20, #8]
    tbnz x28, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc312
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc312
    ldur w5, [x28, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc312
    add w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc312:
    mov x0, x28
    tbnz x27, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc313
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc313
    ldur w5, [x27, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc313
    add w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc313:
    mov x0, x27
    mov x0, #2
    bl __fern_arr_box
    mov x26, x0
    str x28, [x26, #8]
    str x27, [x26, #16]
.Lssa_ordmap__OrdMap__i32__i32__insert_11:
    ldr x10, [x28, #0]
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    cmp x10, x9
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_8
.Lssa_ordmap__OrdMap__i32__i32__insert_10:
    tst x28, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq10
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq10
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq10:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_112
.Lssa_ordmap__OrdMap__i32__i32__insert_111:
    mov x19, x28
    b .Lssa_ordmap__OrdMap__i32__i32__insert_113
.Lssa_ordmap__OrdMap__i32__i32__insert_112:
    mov x19, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_113:
    ldr x10, [x28, #16]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_116
.Lssa_ordmap__OrdMap__i32__i32__insert_114:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc327
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc327
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc327
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc327:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_116:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck328
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd328
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck328
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece328
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd328:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck328:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece328:
    ldr x24, [x28, #24]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_119
.Lssa_ordmap__OrdMap__i32__i32__insert_117:
    tbnz x24, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc332
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc332
    ldur w5, [x24, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc332
    add w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc332:
    mov x0, x24
.Lssa_ordmap__OrdMap__i32__i32__insert_119:
    ldr x21, [x28, #32]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_122
.Lssa_ordmap__OrdMap__i32__i32__insert_120:
    tbnz x21, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc336
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc336
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc336
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc336:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_122:
    cmp x19, #0
    b.eq .Lssa_ordmap__OrdMap__i32__i32__insert_124
.Lssa_ordmap__OrdMap__i32__i32__insert_123:
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_125
.Lssa_ordmap__OrdMap__i32__i32__insert_124:
    mov x0, x28
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__OrdMap__i32__i32__insert_125:
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck341
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd341
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck341
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece341
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd341:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck341:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece341:
    ldr x21, [x24, #0]
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck343
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd343
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck343
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece343
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd343:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck343:
    mov x0, x24
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece343:
    mov x24, x21
    b .Lssa_ordmap__OrdMap__i32__i32__insert_6
.Lssa_ordmap__OrdMap__i32__i32__insert_8:
    tst x28, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq8
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq8
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq8:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_128
.Lssa_ordmap__OrdMap__i32__i32__insert_127:
    mov x21, x28
    b .Lssa_ordmap__OrdMap__i32__i32__insert_129
.Lssa_ordmap__OrdMap__i32__i32__insert_128:
    mov x21, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_129:
    ldr x10, [x28, #16]
    cmp x21, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_132
.Lssa_ordmap__OrdMap__i32__i32__insert_130:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc351
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc351
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc351
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc351:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_132:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck352
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd352
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck352
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece352
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd352:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck352:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece352:
    ldr x10, [x28, #24]
    cmp x21, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_135
.Lssa_ordmap__OrdMap__i32__i32__insert_133:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc356
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc356
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc356
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc356:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_135:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck357
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd357
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck357
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece357
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd357:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck357:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece357:
    ldr x24, [x28, #32]
    cmp x21, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_138
.Lssa_ordmap__OrdMap__i32__i32__insert_136:
    tbnz x24, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc361
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc361
    ldur w5, [x24, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc361
    add w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc361:
    mov x0, x24
.Lssa_ordmap__OrdMap__i32__i32__insert_138:
    tst x24, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq138
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq138
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq138:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_141
.Lssa_ordmap__OrdMap__i32__i32__insert_139:
    mov x19, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_143:
    ldr x10, [x24, #0]
    cmp x19, x10
    b.ge .Lssa_ordmap__OrdMap__i32__i32__insert_141
.Lssa_ordmap__OrdMap__i32__i32__insert_144:
    add x5, x19, #1
    ldr x0, [x24, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x19, x19, #1
    b .Lssa_ordmap__OrdMap__i32__i32__insert_143
.Lssa_ordmap__OrdMap__i32__i32__insert_141:
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck372
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd372
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck372
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece372
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd372:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck372:
    mov x0, x24
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece372:
    ldr x10, [x28, #40]
    cmp x21, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_149
.Lssa_ordmap__OrdMap__i32__i32__insert_147:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc376
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc376
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc376
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc376:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_149:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck377
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd377
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck377
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece377
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd377:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck377:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece377:
    ldr x24, [x28, #48]
    cmp x21, #0
    b.eq .Lssa_ordmap__OrdMap__i32__i32__insert_151
.Lssa_ordmap__OrdMap__i32__i32__insert_150:
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_6
.Lssa_ordmap__OrdMap__i32__i32__insert_151:
    mov x0, x28
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__OrdMap__i32__i32__insert_152:
.Lssa_ordmap__OrdMap__i32__i32__insert_7:
.Lssa_ordmap__OrdMap__i32__i32__insert_6:
    ldr x10, [x27, #0]
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    cmp x10, x9
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_3
.Lssa_ordmap__OrdMap__i32__i32__insert_5:
    tst x27, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq5
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq5
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq5:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_158
.Lssa_ordmap__OrdMap__i32__i32__insert_157:
    mov x28, x27
    b .Lssa_ordmap__OrdMap__i32__i32__insert_159
.Lssa_ordmap__OrdMap__i32__i32__insert_158:
    mov x28, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_159:
    ldr x10, [x27, #16]
    cmp x28, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_162
.Lssa_ordmap__OrdMap__i32__i32__insert_160:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc401
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc401
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc401
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc401:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_162:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck402
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd402
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck402
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece402
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd402:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck402:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece402:
    ldr x21, [x27, #24]
    cmp x28, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_165
.Lssa_ordmap__OrdMap__i32__i32__insert_163:
    tbnz x21, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc406
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc406
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc406
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc406:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_165:
    ldr x19, [x27, #32]
    cmp x28, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_168
.Lssa_ordmap__OrdMap__i32__i32__insert_166:
    tbnz x19, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc410
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc410
    ldur w5, [x19, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc410
    add w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc410:
    mov x0, x19
.Lssa_ordmap__OrdMap__i32__i32__insert_168:
    cmp x28, #0
    b.eq .Lssa_ordmap__OrdMap__i32__i32__insert_170
.Lssa_ordmap__OrdMap__i32__i32__insert_169:
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_171
.Lssa_ordmap__OrdMap__i32__i32__insert_170:
    mov x0, x27
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__OrdMap__i32__i32__insert_171:
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck415
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd415
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck415
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece415
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd415:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck415:
    mov x0, x19
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece415:
    ldr x19, [x21, #0]
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck417
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd417
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck417
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece417
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd417:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck417:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece417:
    mov x21, x19
    b .Lssa_ordmap__OrdMap__i32__i32__insert_2
.Lssa_ordmap__OrdMap__i32__i32__insert_3:
    tst x27, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq3
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq3
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq3:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_174
.Lssa_ordmap__OrdMap__i32__i32__insert_173:
    mov x19, x27
    b .Lssa_ordmap__OrdMap__i32__i32__insert_175
.Lssa_ordmap__OrdMap__i32__i32__insert_174:
    mov x19, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_175:
    ldr x10, [x27, #16]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_178
.Lssa_ordmap__OrdMap__i32__i32__insert_176:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc425
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc425
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc425
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc425:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_178:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck426
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd426
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck426
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece426
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd426:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck426:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece426:
    ldr x10, [x27, #24]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_181
.Lssa_ordmap__OrdMap__i32__i32__insert_179:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc430
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc430
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc430
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc430:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_181:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck431
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd431
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck431
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece431
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd431:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck431:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece431:
    ldr x21, [x27, #32]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_184
.Lssa_ordmap__OrdMap__i32__i32__insert_182:
    tbnz x21, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc435
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc435
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc435
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc435:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_184:
    tst x21, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq184
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq184
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq184:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_187
.Lssa_ordmap__OrdMap__i32__i32__insert_185:
    mov x28, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_189:
    ldr x10, [x21, #0]
    cmp x28, x10
    b.ge .Lssa_ordmap__OrdMap__i32__i32__insert_187
.Lssa_ordmap__OrdMap__i32__i32__insert_190:
    add x5, x28, #1
    ldr x0, [x21, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x28, x28, #1
    b .Lssa_ordmap__OrdMap__i32__i32__insert_189
.Lssa_ordmap__OrdMap__i32__i32__insert_187:
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck446
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd446
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck446
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece446
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd446:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck446:
    mov x0, x21
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece446:
    ldr x10, [x27, #40]
    cmp x19, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_195
.Lssa_ordmap__OrdMap__i32__i32__insert_193:
    tbnz x10, #0, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc450
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc450
    ldur w5, [x10, #-8]
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcinc450
    add w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcinc450:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_195:
    cmp x10, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck451
    ldur w5, [x10, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd451
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck451
    mov x0, x10
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece451
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd451:
    sub w5, w5, #1
    stur w5, [x10, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck451:
    mov x0, x10
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece451:
    ldr x21, [x27, #48]
    cmp x19, #0
    b.eq .Lssa_ordmap__OrdMap__i32__i32__insert_197
.Lssa_ordmap__OrdMap__i32__i32__insert_196:
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_2
.Lssa_ordmap__OrdMap__i32__i32__insert_197:
    mov x0, x27
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__OrdMap__i32__i32__insert_198:
.Lssa_ordmap__OrdMap__i32__i32__insert_2:
    mov x0, #2
    bl __fern_arr_box
    mov x27, x0
    str x24, [x27, #8]
    str x21, [x27, #16]
    mov x0, x20
    mov x9, x26
    mov x10, x27
    bl __fn_ordmap__make_branch__i32__i32.r
    mov x21, x0
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck469
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd469
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck469
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece469
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd469:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck469:
    mov x0, x20
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece469:
    tst x26, #1
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_uq2
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_uq2
    ldur w5, [x26, #-8]
    cmp w5, #1
.Lssa_ordmap__OrdMap__i32__i32__insert_uq2:
    b.ne .Lssa_ordmap__OrdMap__i32__i32__insert_201
.Lssa_ordmap__OrdMap__i32__i32__insert_199:
    mov x20, #0
.Lssa_ordmap__OrdMap__i32__i32__insert_203:
    ldr x10, [x26, #0]
    cmp x20, x10
    b.ge .Lssa_ordmap__OrdMap__i32__i32__insert_201
.Lssa_ordmap__OrdMap__i32__i32__insert_204:
    add x5, x20, #1
    ldr x0, [x26, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x20, x20, #1
    b .Lssa_ordmap__OrdMap__i32__i32__insert_203
.Lssa_ordmap__OrdMap__i32__i32__insert_201:
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck480
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd480
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck480
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece480
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd480:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck480:
    mov x0, x26
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece480:
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck481
    ldur w5, [x27, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd481
    tbnz w5, #31, .Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck481
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__OrdMap__i32__i32__insert_rcdece481
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdecd481:
    sub w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdeck481:
    mov x0, x27
.Lssa_ordmap__OrdMap__i32__i32__insert_rcdece481:
.Lssa_ordmap__OrdMap__i32__i32__insert_1:
    mov x10, #2
    str x22, [sp, #-16]!
    str x10, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x10, .S0
    add x10, x10, :lo12:.S0
    b .Lssa_ordmap__OrdMap__i32__i32__insert_pool_437
    .ltorg
.Lssa_ordmap__OrdMap__i32__i32__insert_pool_437:
    str x10, [x0, #0]
    str x21, [x0, #8]
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__OrdMap__i32__i32__get_or:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_ordmap__OrdMap__i32__i32__get_or.k:
__fn_ordmap__OrdMap__i32__i32__get_or.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
    mov x20, x10
.Lssa_ordmap__OrdMap__i32__i32__get_or_0:
    ldr x9, [x0, #8]
.Lssa_ordmap__OrdMap__i32__i32__get_or_19:
    mov x21, x9
.Lssa_ordmap__OrdMap__i32__i32__get_or_20:
.Lssa_ordmap__OrdMap__i32__i32__get_or_23:
    ldr x9, [x21, #0]
    adrp x10, .S1
    add x10, x10, :lo12:.S1
    cmp x9, x10
    b.eq .Lssa_ordmap__OrdMap__i32__i32__get_or_18
.Lssa_ordmap__OrdMap__i32__i32__get_or_21:
    ldr x0, [x21, #8]
    ldr x9, [x21, #16]
    ldr x10, [x21, #24]
    ldr x22, [x21, #32]
    mov x11, x19
    bl __fn_ordmap__upper__i32.r
    ldr x6, [x22]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x0, #1
    ldr x21, [x22, x5, lsl #3]
    b .Lssa_ordmap__OrdMap__i32__i32__get_or_23
.Lssa_ordmap__OrdMap__i32__i32__get_or_18:
    ldr x0, [x21, #8]
    ldr x9, [x21, #16]
    ldr x22, [x21, #24]
.Lssa_ordmap__OrdMap__i32__i32__get_or_17:
    mov x10, x22
    mov x11, x19
    bl __fn_ordmap__lower__i32.r
    ldr x9, [x22, #0]
    cmp x0, x9
    b.ge .Lssa_ordmap__OrdMap__i32__i32__get_or_5
.Lssa_ordmap__OrdMap__i32__i32__get_or_16:
    ldr x6, [x22]
    cmp x0, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x0, #1
    ldr x9, [x22, x5, lsl #3]
.Lssa_ordmap__OrdMap__i32__i32__get_or_15:
    cmp x9, x19
    b.ge .Lssa_ordmap__OrdMap__i32__i32__get_or_12
.Lssa_ordmap__OrdMap__i32__i32__get_or_14:
    mov x10, #-1
    b .Lssa_ordmap__OrdMap__i32__i32__get_or_8
.Lssa_ordmap__OrdMap__i32__i32__get_or_12:
    cmp x9, x19
    b.le .Lssa_ordmap__OrdMap__i32__i32__get_or_9
.Lssa_ordmap__OrdMap__i32__i32__get_or_11:
    mov x10, #1
    b .Lssa_ordmap__OrdMap__i32__i32__get_or_8
.Lssa_ordmap__OrdMap__i32__i32__get_or_9:
    mov x10, #0
.Lssa_ordmap__OrdMap__i32__i32__get_or_8:
    cmp x10, #0
    b.ne .Lssa_ordmap__OrdMap__i32__i32__get_or_5
.Lssa_ordmap__OrdMap__i32__i32__get_or_7:
    mov x10, x0
    b .Lssa_ordmap__OrdMap__i32__i32__get_or_3
.Lssa_ordmap__OrdMap__i32__i32__get_or_5:
    mov x10, #-1
.Lssa_ordmap__OrdMap__i32__i32__get_or_4:
.Lssa_ordmap__OrdMap__i32__i32__get_or_3:
    cmp x10, #0
    b.ge .Lssa_ordmap__OrdMap__i32__i32__get_or_1
.Lssa_ordmap__OrdMap__i32__i32__get_or_2:
    mov x0, x20
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_ordmap__OrdMap__i32__i32__get_or_1:
    ldr x9, [x21, #32]
    ldr x6, [x9]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x10, #1
    ldr x0, [x9, x5, lsl #3]
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__node_insert__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_ordmap__node_insert__i32__i32.k:
__fn_ordmap__node_insert__i32__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    stp x25, x26, [sp, #-16]!
    stp x27, x28, [sp, #-16]!
    sub sp, sp, #176
    mov x19, x0
    mov x20, x9
    str x10, [sp, #168]
.Lssa_ordmap__node_insert__i32__i32_0:
    ldr x9, [x19, #0]
    adrp x10, .S1
    add x10, x10, :lo12:.S1
    cmp x9, x10
    b.ne .Lssa_ordmap__node_insert__i32__i32_108
.Lssa_ordmap__node_insert__i32__i32_114:
    ldr x4, [x19, #8]
    str x4, [sp, #160]
    tst x19, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq114
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq114
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq114:
    b.ne .Lssa_ordmap__node_insert__i32__i32_120
.Lssa_ordmap__node_insert__i32__i32_119:
    mov x9, x19
    b .Lssa_ordmap__node_insert__i32__i32_121
.Lssa_ordmap__node_insert__i32__i32_120:
    mov x9, #0
.Lssa_ordmap__node_insert__i32__i32_121:
    ldr x4, [x19, #16]
    str x4, [sp, #152]
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_124
.Lssa_ordmap__node_insert__i32__i32_122:
    ldr x4, [sp, #152]
    tbnz x4, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc388
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc388
    ldur w5, [x4, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc388
    add w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc388:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_124:
    ldr x24, [x19, #24]
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_127
.Lssa_ordmap__node_insert__i32__i32_125:
    tbnz x24, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc392
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc392
    ldur w5, [x24, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc392
    add w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc392:
    mov x0, x24
.Lssa_ordmap__node_insert__i32__i32_127:
    ldr x25, [x19, #32]
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_130
.Lssa_ordmap__node_insert__i32__i32_128:
    tbnz x25, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc396
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc396
    ldur w5, [x25, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc396
    add w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc396:
    mov x0, x25
.Lssa_ordmap__node_insert__i32__i32_130:
    cmp x9, #0
    b.eq .Lssa_ordmap__node_insert__i32__i32_132
.Lssa_ordmap__node_insert__i32__i32_131:
    str x19, [sp, #144]
    b .Lssa_ordmap__node_insert__i32__i32_113
.Lssa_ordmap__node_insert__i32__i32_132:
    mov x0, x19
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    str xzr, [sp, #144]
.Lssa_ordmap__node_insert__i32__i32_133:
.Lssa_ordmap__node_insert__i32__i32_113:
    ldr x0, [sp, #160]
    ldr x9, [sp, #152]
    mov x10, x24
    mov x11, x20
    bl __fn_ordmap__lower__i32.r
    mov x26, x0
    ldr x9, [x24, #0]
    cmp x26, x9
    b.ge .Lssa_ordmap__node_insert__i32__i32_95
.Lssa_ordmap__node_insert__i32__i32_112:
    ldr x6, [x24]
    cmp x26, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    ldr x4, [x24, x5, lsl #3]
    str x4, [sp, #136]
.Lssa_ordmap__node_insert__i32__i32_111:
    ldr x4, [sp, #136]
    cmp x4, x20
    b.ge .Lssa_ordmap__node_insert__i32__i32_103
.Lssa_ordmap__node_insert__i32__i32_110:
    mov x9, #-1
    b .Lssa_ordmap__node_insert__i32__i32_99
.Lssa_ordmap__node_insert__i32__i32_108:
    ldr x4, [x19, #8]
    str x4, [sp, #128]
    tst x19, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq108
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq108
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq108:
    b.ne .Lssa_ordmap__node_insert__i32__i32_144
.Lssa_ordmap__node_insert__i32__i32_143:
    mov x9, x19
    b .Lssa_ordmap__node_insert__i32__i32_145
.Lssa_ordmap__node_insert__i32__i32_144:
    mov x9, #0
.Lssa_ordmap__node_insert__i32__i32_145:
    ldr x4, [x19, #16]
    str x4, [sp, #120]
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_148
.Lssa_ordmap__node_insert__i32__i32_146:
    ldr x4, [sp, #120]
    tbnz x4, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc415
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc415
    ldur w5, [x4, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc415
    add w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc415:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_148:
    ldr x4, [x19, #24]
    str x4, [sp, #112]
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_151
.Lssa_ordmap__node_insert__i32__i32_149:
    ldr x4, [sp, #112]
    tbnz x4, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc419
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc419
    ldur w5, [x4, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc419
    add w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc419:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_151:
    ldr x23, [x19, #32]
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_154
.Lssa_ordmap__node_insert__i32__i32_152:
    tbnz x23, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc423
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc423
    ldur w5, [x23, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc423
    add w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc423:
    mov x0, x23
.Lssa_ordmap__node_insert__i32__i32_154:
    ldr x4, [x19, #40]
    str x4, [sp, #104]
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_157
.Lssa_ordmap__node_insert__i32__i32_155:
    ldr x4, [sp, #104]
    tbnz x4, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc427
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc427
    ldur w5, [x4, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc427
    add w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc427:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_157:
    ldr x4, [x19, #48]
    str x4, [sp, #96]
    cmp x9, #0
    b.eq .Lssa_ordmap__node_insert__i32__i32_159
.Lssa_ordmap__node_insert__i32__i32_158:
    str x19, [sp, #88]
    b .Lssa_ordmap__node_insert__i32__i32_160
.Lssa_ordmap__node_insert__i32__i32_159:
    mov x0, x19
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    str xzr, [sp, #88]
.Lssa_ordmap__node_insert__i32__i32_160:
    ldr x0, [sp, #128]
    ldr x9, [sp, #120]
    ldr x10, [sp, #112]
    mov x11, x20
    bl __fn_ordmap__upper__i32.r
    mov x19, x0
    ldr x6, [x23]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x0, [x23, x5, lsl #3]
    mov x6, #0
    tbnz x23, #0, .Lssa_ordmap__node_insert__i32__i32_rcuniq436
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcuniq436
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_rcuniq436
    mov x6, #1
.Lssa_ordmap__node_insert__i32__i32_rcuniq436:
    mov x9, x6
    cbz x9, .Lssa_ordmap__node_insert__i32__i32_163
.Lssa_ordmap__node_insert__i32__i32_161:
    mov x10, #0
    add x5, x19, #1
    str x10, [x23, x5, lsl #3]
.Lssa_ordmap__node_insert__i32__i32_163:
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_166
.Lssa_ordmap__node_insert__i32__i32_164:
    tbnz x0, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc441
    cmp x0, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc441
    ldur w5, [x0, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc441
    add w5, w5, #1
    stur w5, [x0, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc441:
    mov x9, x0
.Lssa_ordmap__node_insert__i32__i32_166:
    mov x9, x20
    ldr x10, [sp, #168]
    bl __fn_ordmap__node_insert__i32__i32.r
    mov x27, x0
.Lssa_ordmap__node_insert__i32__i32_106:
    ldr x9, [x27, #0]
    adrp x11, .S1
    add x11, x11, :lo12:.S1
    cmp x9, x11
    b.ne .Lssa_ordmap__node_insert__i32__i32_71
.Lssa_ordmap__node_insert__i32__i32_105:
    ldr x9, [x27, #24]
    ldr x11, [x9, #0]
    mov x9, x11
    b .Lssa_ordmap__node_insert__i32__i32_70
.Lssa_ordmap__node_insert__i32__i32_103:
    ldr x4, [sp, #136]
    cmp x4, x20
    b.le .Lssa_ordmap__node_insert__i32__i32_100
.Lssa_ordmap__node_insert__i32__i32_102:
    mov x9, #1
    b .Lssa_ordmap__node_insert__i32__i32_99
.Lssa_ordmap__node_insert__i32__i32_100:
    mov x9, #0
.Lssa_ordmap__node_insert__i32__i32_99:
    cmp x9, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_95
.Lssa_ordmap__node_insert__i32__i32_98:
    tst x24, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq98
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq98
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq98:
    b.ne .Lssa_ordmap__node_insert__i32__i32_182
.Lssa_ordmap__node_insert__i32__i32_181:
    b .Lssa_ordmap__node_insert__i32__i32_183
.Lssa_ordmap__node_insert__i32__i32_182:
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck458
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd458
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck458
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece458
.Lssa_ordmap__node_insert__i32__i32_rcdecd458:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck458:
    mov x0, x24
.Lssa_ordmap__node_insert__i32__i32_rcdece458:
    mov x9, #0
    ldr x11, [x24, #0]
    str x11, [sp, #-16]!
    str x9, [sp, #-16]!
    str x24, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x24, x0
.Lssa_ordmap__node_insert__i32__i32_183:
    ldr x7, [x24]
    cmp x26, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    str x20, [x24, x5, lsl #3]
    tst x25, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq183
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq183
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq183:
    b.ne .Lssa_ordmap__node_insert__i32__i32_185
.Lssa_ordmap__node_insert__i32__i32_184:
    b .Lssa_ordmap__node_insert__i32__i32_186
.Lssa_ordmap__node_insert__i32__i32_185:
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck465
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd465
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck465
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece465
.Lssa_ordmap__node_insert__i32__i32_rcdecd465:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck465:
    mov x0, x25
.Lssa_ordmap__node_insert__i32__i32_rcdece465:
    mov x11, #0
    ldr x9, [x25, #0]
    str x9, [sp, #-16]!
    str x11, [sp, #-16]!
    str x25, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x25, x0
.Lssa_ordmap__node_insert__i32__i32_186:
    ldr x6, [sp, #168]
    ldr x7, [x25]
    cmp x26, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    str x6, [x25, x5, lsl #3]
    mov x9, #5
    ldr x4, [sp, #144]
    str x4, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    str x9, [x0, #0]
    ldr x5, [sp, #160]
    str x5, [x0, #8]
    ldr x5, [sp, #152]
    str x5, [x0, #16]
    str x24, [x0, #24]
    str x25, [x0, #32]
    b .Lssa_ordmap__node_insert__i32__i32_52
.Lssa_ordmap__node_insert__i32__i32_95:
    ldr x22, [x24, #0]
    cmp x22, x26
    b.ne .Lssa_ordmap__node_insert__i32__i32_92
.Lssa_ordmap__node_insert__i32__i32_94:
    tst x24, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq94
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq94
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq94:
    b.ne .Lssa_ordmap__node_insert__i32__i32_193
.Lssa_ordmap__node_insert__i32__i32_192:
    mov x0, x24
    mov x1, x20
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush483s
.Lssa_ordmap__node_insert__i32__i32_apush483o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush483e
.Lssa_ordmap__node_insert__i32__i32_apush483s:
    bl __fern_arr_push_owned
.Lssa_ordmap__node_insert__i32__i32_apush483e:
    mov x11, x0
    mov x28, x11
    b .Lssa_ordmap__node_insert__i32__i32_194
.Lssa_ordmap__node_insert__i32__i32_193:
    mov x0, x24
    mov x1, x20
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush484s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__node_insert__i32__i32_apush484o
    tbz w3, #31, .Lssa_ordmap__node_insert__i32__i32_apush484s
.Lssa_ordmap__node_insert__i32__i32_apush484o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush484e
.Lssa_ordmap__node_insert__i32__i32_apush484s:
    bl __fern_arr_push
.Lssa_ordmap__node_insert__i32__i32_apush484e:
    mov x28, x0
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck485
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd485
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck485
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece485
.Lssa_ordmap__node_insert__i32__i32_rcdecd485:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck485:
    mov x0, x24
.Lssa_ordmap__node_insert__i32__i32_rcdece485:
.Lssa_ordmap__node_insert__i32__i32_194:
    str x28, [sp, #136]
    b .Lssa_ordmap__node_insert__i32__i32_88
.Lssa_ordmap__node_insert__i32__i32_92:
    sub w11, w22, #1
    ldr x6, [x24]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x9, [x24, x5, lsl #3]
    tst x24, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq92
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq92
    ldur w5, [x24, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq92:
    b.ne .Lssa_ordmap__node_insert__i32__i32_197
.Lssa_ordmap__node_insert__i32__i32_196:
    mov x0, x24
    mov x1, x9
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush492s
.Lssa_ordmap__node_insert__i32__i32_apush492o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush492e
.Lssa_ordmap__node_insert__i32__i32_apush492s:
    str x9, [sp, #56]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
.Lssa_ordmap__node_insert__i32__i32_apush492e:
    mov x11, x0
    mov x28, x11
    b .Lssa_ordmap__node_insert__i32__i32_198
.Lssa_ordmap__node_insert__i32__i32_197:
    mov x0, x24
    mov x1, x9
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush493s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__node_insert__i32__i32_apush493o
    tbz w3, #31, .Lssa_ordmap__node_insert__i32__i32_apush493s
.Lssa_ordmap__node_insert__i32__i32_apush493o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush493e
.Lssa_ordmap__node_insert__i32__i32_apush493s:
    bl __fern_arr_push
.Lssa_ordmap__node_insert__i32__i32_apush493e:
    mov x28, x0
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck494
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd494
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck494
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece494
.Lssa_ordmap__node_insert__i32__i32_rcdecd494:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck494:
    mov x0, x24
.Lssa_ordmap__node_insert__i32__i32_rcdece494:
.Lssa_ordmap__node_insert__i32__i32_198:
    sub x22, x22, #1
    sxtw x22, w22
.Lssa_ordmap__node_insert__i32__i32_91:
.Lssa_ordmap__node_insert__i32__i32_199:
    cmp x22, x26
    b.le .Lssa_ordmap__node_insert__i32__i32_90
.Lssa_ordmap__node_insert__i32__i32_200:
    sub x9, x22, #1
    ldr x6, [x28]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x24, [x28, x5, lsl #3]
    tst x28, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq200
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq200
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq200:
    b.ne .Lssa_ordmap__node_insert__i32__i32_206
.Lssa_ordmap__node_insert__i32__i32_205:
    b .Lssa_ordmap__node_insert__i32__i32_207
.Lssa_ordmap__node_insert__i32__i32_206:
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck512
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd512
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck512
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece512
.Lssa_ordmap__node_insert__i32__i32_rcdecd512:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck512:
    mov x0, x28
.Lssa_ordmap__node_insert__i32__i32_rcdece512:
    mov x9, #0
    ldr x11, [x28, #0]
    str x11, [sp, #-16]!
    str x9, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x28, x0
.Lssa_ordmap__node_insert__i32__i32_207:
    ldr x7, [x28]
    cmp x22, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x22, #1
    str x24, [x28, x5, lsl #3]
    sub x22, x22, #1
    cmp x22, x26
    b.gt .Lssa_ordmap__node_insert__i32__i32_200
.Lssa_ordmap__node_insert__i32__i32_90:
    tst x28, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq90
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq90
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq90:
    b.ne .Lssa_ordmap__node_insert__i32__i32_211
.Lssa_ordmap__node_insert__i32__i32_210:
    mov x0, x28
    b .Lssa_ordmap__node_insert__i32__i32_212
.Lssa_ordmap__node_insert__i32__i32_211:
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck522
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd522
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck522
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece522
.Lssa_ordmap__node_insert__i32__i32_rcdecd522:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck522:
    mov x0, x28
.Lssa_ordmap__node_insert__i32__i32_rcdece522:
    mov x11, #0
    ldr x9, [x28, #0]
    str x9, [sp, #-16]!
    str x11, [sp, #-16]!
    str x28, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
.Lssa_ordmap__node_insert__i32__i32_212:
    ldr x7, [x0]
    cmp x26, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    str x20, [x0, x5, lsl #3]
    str x0, [sp, #136]
.Lssa_ordmap__node_insert__i32__i32_89:
.Lssa_ordmap__node_insert__i32__i32_88:
    ldr x28, [x25, #0]
    cmp x28, x26
    b.ne .Lssa_ordmap__node_insert__i32__i32_85
.Lssa_ordmap__node_insert__i32__i32_87:
    tst x25, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq87
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq87
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq87:
    b.ne .Lssa_ordmap__node_insert__i32__i32_218
.Lssa_ordmap__node_insert__i32__i32_217:
    mov x0, x25
    ldr x1, [sp, #168]
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush534s
.Lssa_ordmap__node_insert__i32__i32_apush534o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush534e
.Lssa_ordmap__node_insert__i32__i32_apush534s:
    bl __fern_arr_push_owned
.Lssa_ordmap__node_insert__i32__i32_apush534e:
    mov x22, x0
    b .Lssa_ordmap__node_insert__i32__i32_219
.Lssa_ordmap__node_insert__i32__i32_218:
    mov x0, x25
    ldr x1, [sp, #168]
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush535s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__node_insert__i32__i32_apush535o
    tbz w3, #31, .Lssa_ordmap__node_insert__i32__i32_apush535s
.Lssa_ordmap__node_insert__i32__i32_apush535o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush535e
.Lssa_ordmap__node_insert__i32__i32_apush535s:
    bl __fern_arr_push
.Lssa_ordmap__node_insert__i32__i32_apush535e:
    mov x22, x0
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck536
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd536
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck536
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece536
.Lssa_ordmap__node_insert__i32__i32_rcdecd536:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck536:
    mov x0, x25
.Lssa_ordmap__node_insert__i32__i32_rcdece536:
.Lssa_ordmap__node_insert__i32__i32_219:
    str x22, [sp, #168]
    b .Lssa_ordmap__node_insert__i32__i32_82
.Lssa_ordmap__node_insert__i32__i32_85:
    sub w9, w28, #1
    ldr x6, [x25]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x11, [x25, x5, lsl #3]
    tst x25, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq85
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq85
    ldur w5, [x25, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq85:
    b.ne .Lssa_ordmap__node_insert__i32__i32_222
.Lssa_ordmap__node_insert__i32__i32_221:
    mov x0, x25
    mov x1, x11
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush543s
.Lssa_ordmap__node_insert__i32__i32_apush543o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush543e
.Lssa_ordmap__node_insert__i32__i32_apush543s:
    str x11, [sp, #56]
    bl __fern_arr_push_owned
    ldr x11, [sp, #56]
.Lssa_ordmap__node_insert__i32__i32_apush543e:
    mov x22, x0
    b .Lssa_ordmap__node_insert__i32__i32_223
.Lssa_ordmap__node_insert__i32__i32_222:
    mov x0, x25
    mov x1, x11
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush544s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__node_insert__i32__i32_apush544o
    tbz w3, #31, .Lssa_ordmap__node_insert__i32__i32_apush544s
.Lssa_ordmap__node_insert__i32__i32_apush544o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush544e
.Lssa_ordmap__node_insert__i32__i32_apush544s:
    bl __fern_arr_push
.Lssa_ordmap__node_insert__i32__i32_apush544e:
    mov x22, x0
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck545
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd545
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck545
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece545
.Lssa_ordmap__node_insert__i32__i32_rcdecd545:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck545:
    mov x0, x25
.Lssa_ordmap__node_insert__i32__i32_rcdece545:
.Lssa_ordmap__node_insert__i32__i32_223:
    sub x28, x28, #1
    sxtw x28, w28
.Lssa_ordmap__node_insert__i32__i32_84:
.Lssa_ordmap__node_insert__i32__i32_224:
    cmp x28, x26
    b.le .Lssa_ordmap__node_insert__i32__i32_83
.Lssa_ordmap__node_insert__i32__i32_225:
    sub x11, x28, #1
    ldr x6, [x22]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x25, [x22, x5, lsl #3]
    tst x22, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq225
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq225
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq225:
    b.ne .Lssa_ordmap__node_insert__i32__i32_231
.Lssa_ordmap__node_insert__i32__i32_230:
    b .Lssa_ordmap__node_insert__i32__i32_232
.Lssa_ordmap__node_insert__i32__i32_231:
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck563
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd563
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck563
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece563
.Lssa_ordmap__node_insert__i32__i32_rcdecd563:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck563:
    mov x0, x22
.Lssa_ordmap__node_insert__i32__i32_rcdece563:
    mov x11, #0
    ldr x9, [x22, #0]
    str x9, [sp, #-16]!
    str x11, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x22, x0
.Lssa_ordmap__node_insert__i32__i32_232:
    ldr x7, [x22]
    cmp x28, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    str x25, [x22, x5, lsl #3]
    sub x28, x28, #1
    cmp x28, x26
    b.gt .Lssa_ordmap__node_insert__i32__i32_225
.Lssa_ordmap__node_insert__i32__i32_83:
    tst x22, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq83
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq83
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq83:
    b.ne .Lssa_ordmap__node_insert__i32__i32_236
.Lssa_ordmap__node_insert__i32__i32_235:
    mov x0, x22
    b .Lssa_ordmap__node_insert__i32__i32_237
.Lssa_ordmap__node_insert__i32__i32_236:
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck573
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd573
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck573
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece573
.Lssa_ordmap__node_insert__i32__i32_rcdecd573:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck573:
    mov x0, x22
.Lssa_ordmap__node_insert__i32__i32_rcdece573:
    mov x9, #0
    ldr x11, [x22, #0]
    str x11, [sp, #-16]!
    str x9, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
.Lssa_ordmap__node_insert__i32__i32_237:
    ldr x6, [sp, #168]
    ldr x7, [x0]
    cmp x26, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x26, #1
    str x6, [x0, x5, lsl #3]
    str x0, [sp, #168]
.Lssa_ordmap__node_insert__i32__i32_82:
    ldr x4, [sp, #136]
    ldr x28, [x4, #0]
    cmp x28, #64
    b.le .Lssa_ordmap__node_insert__i32__i32_78
.Lssa_ordmap__node_insert__i32__i32_81:
    mov x11, #5
    ldr x4, [sp, #144]
    str x4, [sp, #-16]!
    str x11, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x11, .S1
    add x11, x11, :lo12:.S1
    str x11, [x0, #0]
    ldr x5, [sp, #160]
    str x5, [x0, #8]
    ldr x5, [sp, #152]
    str x5, [x0, #16]
    ldr x5, [sp, #136]
    str x5, [x0, #24]
    ldr x5, [sp, #168]
    str x5, [x0, #32]
    b .Lssa_ordmap__node_insert__i32__i32_52
.Lssa_ordmap__node_insert__i32__i32_78:
    ldr x4, [sp, #160]
    cmp x4, #0
    b.le .Lssa_ordmap__node_insert__i32__i32_59
.Lssa_ordmap__node_insert__i32__i32_77:
    cmp x26, #0
    b.eq .Lssa_ordmap__node_insert__i32__i32_74
.Lssa_ordmap__node_insert__i32__i32_76:
    sub x28, x28, #1
    sxtw x28, w28
    cmp x26, x28
    b.ne .Lssa_ordmap__node_insert__i32__i32_59
.Lssa_ordmap__node_insert__i32__i32_74:
    ldr x4, [sp, #136]
    ldr x4, [x4, #0]
    str x4, [sp, #80]
    cmp x4, #2
    b.ge .Lssa_ordmap__node_insert__i32__i32_57
.Lssa_ordmap__node_insert__i32__i32_73:
    mov x9, #0
    b .Lssa_ordmap__node_insert__i32__i32_56
.Lssa_ordmap__node_insert__i32__i32_71:
    ldr x9, [x27, #48]
.Lssa_ordmap__node_insert__i32__i32_70:
    ldr x4, [sp, #104]
    ldr x6, [x4]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x25, [x4, x5, lsl #3]
    sub x4, x9, x25
    str x4, [sp, #72]
.Lssa_ordmap__node_insert__i32__i32_69:
    ldr x9, [x27, #0]
    adrp x11, .S1
    add x11, x11, :lo12:.S1
    cmp x9, x11
    b.ne .Lssa_ordmap__node_insert__i32__i32_66
.Lssa_ordmap__node_insert__i32__i32_68:
    ldr x9, [x27, #24]
    ldr x11, [x9, #0]
    mov x9, x11
    b .Lssa_ordmap__node_insert__i32__i32_65
.Lssa_ordmap__node_insert__i32__i32_66:
    ldr x11, [x27, #32]
    ldr x9, [x11, #0]
.Lssa_ordmap__node_insert__i32__i32_65:
    cmp x9, #64
    b.gt .Lssa_ordmap__node_insert__i32__i32_61
.Lssa_ordmap__node_insert__i32__i32_64:
    tst x23, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq64
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq64
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq64:
    b.ne .Lssa_ordmap__node_insert__i32__i32_270
.Lssa_ordmap__node_insert__i32__i32_269:
    b .Lssa_ordmap__node_insert__i32__i32_271
.Lssa_ordmap__node_insert__i32__i32_270:
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck639
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd639
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck639
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece639
.Lssa_ordmap__node_insert__i32__i32_rcdecd639:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck639:
    mov x0, x23
.Lssa_ordmap__node_insert__i32__i32_rcdece639:
    mov x9, #0
    ldr x11, [x23, #0]
    str x11, [sp, #-16]!
    str x9, [sp, #-16]!
    str x23, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x24, x0
    mov x0, x24
    bl __fn___fern_arr_inc_elems.r
    mov x23, x24
.Lssa_ordmap__node_insert__i32__i32_271:
    ldr x6, [x23]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x0, [x23, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    ldr x7, [x23]
    cmp x19, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    str x27, [x23, x5, lsl #3]
    ldr x5, [sp, #72]
    add x25, x25, x5
    sxtw x25, w25
    ldr x4, [sp, #104]
    tst x4, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq271
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq271
    ldur w5, [x4, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq271:
    b.ne .Lssa_ordmap__node_insert__i32__i32_273
.Lssa_ordmap__node_insert__i32__i32_272:
    b .Lssa_ordmap__node_insert__i32__i32_274
.Lssa_ordmap__node_insert__i32__i32_273:
    ldr x4, [sp, #104]
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck651
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd651
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck651
    ldr x0, [sp, #104]
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece651
.Lssa_ordmap__node_insert__i32__i32_rcdecd651:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck651:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_rcdece651:
    mov x11, #0
    ldr x4, [sp, #104]
    ldr x9, [x4, #0]
    str x9, [sp, #-16]!
    str x11, [sp, #-16]!
    ldr x4, [sp, #136]
    str x4, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    str x0, [sp, #104]
.Lssa_ordmap__node_insert__i32__i32_274:
    ldr x4, [sp, #104]
    ldr x7, [x4]
    cmp x19, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    str x25, [x4, x5, lsl #3]
    ldr x4, [sp, #96]
    ldr x5, [sp, #72]
    add x9, x4, x5
    sxtw x25, w9
    mov x9, #7
    ldr x4, [sp, #88]
    str x4, [sp, #-16]!
    str x9, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x9, .S2
    add x9, x9, :lo12:.S2
    str x9, [x0, #0]
    ldr x5, [sp, #128]
    str x5, [x0, #8]
    ldr x5, [sp, #120]
    str x5, [x0, #16]
    ldr x5, [sp, #112]
    str x5, [x0, #24]
    str x23, [x0, #32]
    ldr x5, [sp, #104]
    str x5, [x0, #40]
    str x25, [x0, #48]
    b .Lssa_ordmap__node_insert__i32__i32_1
.Lssa_ordmap__node_insert__i32__i32_61:
    ldr x11, [x27, #0]
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    cmp x11, x9
    b.ne .Lssa_ordmap__node_insert__i32__i32_50
.Lssa_ordmap__node_insert__i32__i32_60:
    tst x27, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq60
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq60
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq60:
    b.ne .Lssa_ordmap__node_insert__i32__i32_281
.Lssa_ordmap__node_insert__i32__i32_280:
    mov x25, x27
    b .Lssa_ordmap__node_insert__i32__i32_282
.Lssa_ordmap__node_insert__i32__i32_281:
    mov x25, #0
.Lssa_ordmap__node_insert__i32__i32_282:
    ldr x11, [x27, #16]
    cmp x25, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_285
.Lssa_ordmap__node_insert__i32__i32_283:
    tbnz x11, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc680
    cmp x11, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc680
    ldur w5, [x11, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc680
    add w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc680:
    mov x0, x11
.Lssa_ordmap__node_insert__i32__i32_285:
    cmp x11, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck681
    ldur w5, [x11, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd681
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck681
    mov x0, x11
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece681
.Lssa_ordmap__node_insert__i32__i32_rcdecd681:
    sub w5, w5, #1
    stur w5, [x11, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck681:
    mov x0, x11
.Lssa_ordmap__node_insert__i32__i32_rcdece681:
    ldr x24, [x27, #24]
    cmp x25, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_288
.Lssa_ordmap__node_insert__i32__i32_286:
    tbnz x24, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc685
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc685
    ldur w5, [x24, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc685
    add w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc685:
    mov x0, x24
.Lssa_ordmap__node_insert__i32__i32_288:
    ldr x22, [x27, #32]
    cmp x25, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_291
.Lssa_ordmap__node_insert__i32__i32_289:
    tbnz x22, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc689
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc689
    ldur w5, [x22, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc689
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc689:
    mov x0, x22
.Lssa_ordmap__node_insert__i32__i32_291:
    cmp x25, #0
    b.eq .Lssa_ordmap__node_insert__i32__i32_293
.Lssa_ordmap__node_insert__i32__i32_292:
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_294
.Lssa_ordmap__node_insert__i32__i32_293:
    mov x0, x27
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__node_insert__i32__i32_294:
    ldr x25, [x24, #0]
    asr x28, x25, #1
    mov x9, #0
    mov x0, x24
    mov x10, x28
    bl __fn_ordmap__span__i32.r
    mov x20, x0
    mov x9, #0
    mov x0, x22
    mov x10, x28
    bl __fn_ordmap__span__i32.r
    mov x21, x0
    mov x0, x20
    mov x9, x21
    bl __fn_ordmap__make_leaf__i32__i32.r
    str x0, [sp, #64]
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck703
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd703
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck703
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece703
.Lssa_ordmap__node_insert__i32__i32_rcdecd703:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck703:
    mov x0, x20
.Lssa_ordmap__node_insert__i32__i32_rcdece703:
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck704
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd704
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck704
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece704
.Lssa_ordmap__node_insert__i32__i32_rcdecd704:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck704:
    mov x0, x21
.Lssa_ordmap__node_insert__i32__i32_rcdece704:
    ldr x6, [x24]
    cmp x28, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x28, #1
    ldr x21, [x24, x5, lsl #3]
    mov x0, x24
    mov x9, x28
    mov x10, x25
    bl __fn_ordmap__span__i32.r
    mov x20, x0
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck707
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd707
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck707
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece707
.Lssa_ordmap__node_insert__i32__i32_rcdecd707:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck707:
    mov x0, x24
.Lssa_ordmap__node_insert__i32__i32_rcdece707:
    mov x0, x22
    mov x9, x28
    mov x10, x25
    bl __fn_ordmap__span__i32.r
    mov x24, x0
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck709
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd709
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck709
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece709
.Lssa_ordmap__node_insert__i32__i32_rcdecd709:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck709:
    mov x0, x22
.Lssa_ordmap__node_insert__i32__i32_rcdece709:
    mov x0, x20
    mov x9, x24
    bl __fn_ordmap__make_leaf__i32__i32.r
    mov x22, x0
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck711
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd711
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck711
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece711
.Lssa_ordmap__node_insert__i32__i32_rcdecd711:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck711:
    mov x0, x20
.Lssa_ordmap__node_insert__i32__i32_rcdece711:
    cmp x24, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck712
    ldur w5, [x24, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd712
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck712
    mov x0, x24
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece712
.Lssa_ordmap__node_insert__i32__i32_rcdecd712:
    sub w5, w5, #1
    stur w5, [x24, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck712:
    mov x0, x24
.Lssa_ordmap__node_insert__i32__i32_rcdece712:
    ldr x5, [sp, #64]
    str x5, [sp, #168]
    mov x26, x21
    mov x21, x22
    b .Lssa_ordmap__node_insert__i32__i32_48
.Lssa_ordmap__node_insert__i32__i32_59:
    ldr x22, [sp, #160]
    b .Lssa_ordmap__node_insert__i32__i32_53
.Lssa_ordmap__node_insert__i32__i32_57:
    ldr x4, [sp, #136]
    ldr x9, [x4, #8]
    ldr x4, [sp, #80]
    sub w9, w4, #1
    ldr x4, [sp, #136]
    add x5, x9, #1
    ldr x11, [x4, x5, lsl #3]
    mov x9, #0
.Lssa_ordmap__node_insert__i32__i32_56:
    ldr x5, [sp, #160]
    cmp x9, x5
    b.ge .Lssa_ordmap__node_insert__i32__i32_54
.Lssa_ordmap__node_insert__i32__i32_55:
    mov x22, x9
    b .Lssa_ordmap__node_insert__i32__i32_53
.Lssa_ordmap__node_insert__i32__i32_54:
    ldr x22, [sp, #160]
.Lssa_ordmap__node_insert__i32__i32_53:
    b .Lssa_ordmap__node_insert__i32__i32_pool_432
    .ltorg
.Lssa_ordmap__node_insert__i32__i32_pool_432:
    ldr x0, [sp, #160]
    mov x9, x22
    ldr x10, [sp, #152]
    ldr x11, [sp, #136]
    mov x12, x26
    bl __fn_ordmap__fitted_words__i32.r
    mov x24, x0
    ldr x4, [sp, #152]
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck727
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd727
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck727
    ldr x0, [sp, #152]
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece727
.Lssa_ordmap__node_insert__i32__i32_rcdecd727:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck727:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_rcdece727:
    mov x11, #5
    ldr x4, [sp, #144]
    str x4, [sp, #-16]!
    str x11, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x11, .S1
    add x11, x11, :lo12:.S1
    str x11, [x0, #0]
    str x22, [x0, #8]
    str x24, [x0, #16]
    ldr x5, [sp, #136]
    str x5, [x0, #24]
    ldr x5, [sp, #168]
    str x5, [x0, #32]
.Lssa_ordmap__node_insert__i32__i32_52:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_ordmap__node_insert__i32__i32_50:
    tst x27, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq50
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq50
    ldur w5, [x27, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq50:
    b.ne .Lssa_ordmap__node_insert__i32__i32_303
.Lssa_ordmap__node_insert__i32__i32_302:
    mov x24, x27
    b .Lssa_ordmap__node_insert__i32__i32_304
.Lssa_ordmap__node_insert__i32__i32_303:
    mov x24, #0
.Lssa_ordmap__node_insert__i32__i32_304:
    ldr x9, [x27, #16]
    cmp x24, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_307
.Lssa_ordmap__node_insert__i32__i32_305:
    tbnz x9, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc752
    cmp x9, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc752
    ldur w5, [x9, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc752
    add w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc752:
    mov x0, x9
.Lssa_ordmap__node_insert__i32__i32_307:
    cmp x9, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck753
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd753
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck753
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece753
.Lssa_ordmap__node_insert__i32__i32_rcdecd753:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck753:
    mov x0, x9
.Lssa_ordmap__node_insert__i32__i32_rcdece753:
    ldr x22, [x27, #24]
    cmp x24, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_310
.Lssa_ordmap__node_insert__i32__i32_308:
    tbnz x22, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc757
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc757
    ldur w5, [x22, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc757
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc757:
    mov x0, x22
.Lssa_ordmap__node_insert__i32__i32_310:
    ldr x26, [x27, #32]
    cmp x24, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_313
.Lssa_ordmap__node_insert__i32__i32_311:
    tbnz x26, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc761
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc761
    ldur w5, [x26, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc761
    add w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc761:
    mov x0, x26
.Lssa_ordmap__node_insert__i32__i32_313:
    ldr x21, [x27, #40]
    cmp x24, #0
    b.ne .Lssa_ordmap__node_insert__i32__i32_316
.Lssa_ordmap__node_insert__i32__i32_314:
    tbnz x21, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc765
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc765
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc765
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc765:
    mov x0, x21
.Lssa_ordmap__node_insert__i32__i32_316:
    cmp x24, #0
    b.eq .Lssa_ordmap__node_insert__i32__i32_318
.Lssa_ordmap__node_insert__i32__i32_317:
    mov x0, x27
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_319
.Lssa_ordmap__node_insert__i32__i32_318:
    mov x0, x27
    bl __fn___sem_release_ordmap__Node__i32__i32.r
.Lssa_ordmap__node_insert__i32__i32_319:
    ldr x27, [x26, #0]
    asr x24, x27, #1
    sub x9, x24, #1
    sxtw x10, w9
    mov x9, #0
    mov x0, x22
    bl __fn_ordmap__span__i32.r
    mov x20, x0
    mov x9, #0
    mov x0, x26
    mov x10, x24
    bl __fn_ordmap__span__ordmap__Node__i32__i32.r
    mov x28, x0
    mov x9, #0
    mov x0, x21
    mov x10, x24
    bl __fn_ordmap__span__i32.r
    mov x25, x0
    mov x0, x20
    mov x9, x28
    mov x10, x25
    bl __fn_ordmap__make_branch__i32__i32.r
    str x0, [sp, #168]
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck785
    ldur w5, [x20, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd785
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck785
    mov x0, x20
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece785
.Lssa_ordmap__node_insert__i32__i32_rcdecd785:
    sub w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck785:
    mov x0, x20
.Lssa_ordmap__node_insert__i32__i32_rcdece785:
    tst x28, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq319
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq319
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq319:
    b.ne .Lssa_ordmap__node_insert__i32__i32_322
.Lssa_ordmap__node_insert__i32__i32_320:
    mov x20, #0
.Lssa_ordmap__node_insert__i32__i32_324:
    ldr x9, [x28, #0]
    cmp x20, x9
    b.ge .Lssa_ordmap__node_insert__i32__i32_322
.Lssa_ordmap__node_insert__i32__i32_325:
    add x5, x20, #1
    ldr x0, [x28, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x20, x20, #1
    b .Lssa_ordmap__node_insert__i32__i32_324
.Lssa_ordmap__node_insert__i32__i32_322:
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck796
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd796
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck796
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece796
.Lssa_ordmap__node_insert__i32__i32_rcdecd796:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck796:
    mov x0, x28
.Lssa_ordmap__node_insert__i32__i32_rcdece796:
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck797
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd797
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck797
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece797
.Lssa_ordmap__node_insert__i32__i32_rcdecd797:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck797:
    mov x0, x25
.Lssa_ordmap__node_insert__i32__i32_rcdece797:
    sub x9, x27, #1
    sxtw x10, w9
    mov x0, x22
    mov x9, x24
    bl __fn_ordmap__span__i32.r
    mov x25, x0
    mov x0, x26
    mov x9, x24
    mov x10, x27
    bl __fn_ordmap__span__ordmap__Node__i32__i32.r
    mov x28, x0
    tst x26, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq322
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq322
    ldur w5, [x26, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq322:
    b.ne .Lssa_ordmap__node_insert__i32__i32_330
.Lssa_ordmap__node_insert__i32__i32_328:
    mov x20, #0
.Lssa_ordmap__node_insert__i32__i32_332:
    ldr x10, [x26, #0]
    cmp x20, x10
    b.ge .Lssa_ordmap__node_insert__i32__i32_330
.Lssa_ordmap__node_insert__i32__i32_333:
    add x5, x20, #1
    ldr x0, [x26, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x20, x20, #1
    b .Lssa_ordmap__node_insert__i32__i32_332
.Lssa_ordmap__node_insert__i32__i32_330:
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck813
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd813
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck813
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece813
.Lssa_ordmap__node_insert__i32__i32_rcdecd813:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck813:
    mov x0, x26
.Lssa_ordmap__node_insert__i32__i32_rcdece813:
    mov x0, x21
    mov x9, x24
    mov x10, x27
    bl __fn_ordmap__span__i32.r
    mov x26, x0
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck815
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd815
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck815
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece815
.Lssa_ordmap__node_insert__i32__i32_rcdecd815:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck815:
    mov x0, x21
.Lssa_ordmap__node_insert__i32__i32_rcdece815:
    mov x0, x25
    mov x9, x28
    mov x10, x26
    bl __fn_ordmap__make_branch__i32__i32.r
    mov x21, x0
    cmp x25, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck817
    ldur w5, [x25, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd817
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck817
    mov x0, x25
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece817
.Lssa_ordmap__node_insert__i32__i32_rcdecd817:
    sub w5, w5, #1
    stur w5, [x25, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck817:
    mov x0, x25
.Lssa_ordmap__node_insert__i32__i32_rcdece817:
    tst x28, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq330
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq330
    ldur w5, [x28, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq330:
    b.ne .Lssa_ordmap__node_insert__i32__i32_338
.Lssa_ordmap__node_insert__i32__i32_336:
    mov x25, #0
.Lssa_ordmap__node_insert__i32__i32_340:
    ldr x10, [x28, #0]
    cmp x25, x10
    b.ge .Lssa_ordmap__node_insert__i32__i32_338
.Lssa_ordmap__node_insert__i32__i32_341:
    add x5, x25, #1
    ldr x0, [x28, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x25, x25, #1
    b .Lssa_ordmap__node_insert__i32__i32_340
.Lssa_ordmap__node_insert__i32__i32_338:
    cmp x28, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck828
    ldur w5, [x28, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd828
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck828
    mov x0, x28
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece828
.Lssa_ordmap__node_insert__i32__i32_rcdecd828:
    sub w5, w5, #1
    stur w5, [x28, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck828:
    mov x0, x28
.Lssa_ordmap__node_insert__i32__i32_rcdece828:
    cmp x26, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck829
    ldur w5, [x26, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd829
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck829
    mov x0, x26
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece829
.Lssa_ordmap__node_insert__i32__i32_rcdecd829:
    sub w5, w5, #1
    stur w5, [x26, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck829:
    mov x0, x26
.Lssa_ordmap__node_insert__i32__i32_rcdece829:
    sub w24, w24, #1
    ldr x6, [x22]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    ldr x26, [x22, x5, lsl #3]
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck834
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd834
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck834
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece834
.Lssa_ordmap__node_insert__i32__i32_rcdecd834:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck834:
    mov x0, x22
.Lssa_ordmap__node_insert__i32__i32_rcdece834:
.Lssa_ordmap__node_insert__i32__i32_49:
.Lssa_ordmap__node_insert__i32__i32_48:
    ldr x4, [sp, #168]
    ldr x10, [x4, #0]
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    cmp x10, x9
    b.ne .Lssa_ordmap__node_insert__i32__i32_45
.Lssa_ordmap__node_insert__i32__i32_47:
    ldr x4, [sp, #168]
    ldr x10, [x4, #24]
    ldr x9, [x10, #0]
    mov x22, x9
    b .Lssa_ordmap__node_insert__i32__i32_44
.Lssa_ordmap__node_insert__i32__i32_45:
    ldr x4, [sp, #168]
    ldr x9, [x4, #48]
    mov x22, x9
.Lssa_ordmap__node_insert__i32__i32_44:
    ldr x4, [sp, #104]
    tst x4, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq44
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq44
    ldur w5, [x4, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq44:
    b.ne .Lssa_ordmap__node_insert__i32__i32_350
.Lssa_ordmap__node_insert__i32__i32_349:
    ldr x10, [sp, #104]
    b .Lssa_ordmap__node_insert__i32__i32_351
.Lssa_ordmap__node_insert__i32__i32_350:
    ldr x4, [sp, #104]
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck875
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd875
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck875
    ldr x0, [sp, #104]
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece875
.Lssa_ordmap__node_insert__i32__i32_rcdecd875:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck875:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_rcdece875:
    mov x9, #0
    ldr x4, [sp, #104]
    ldr x10, [x4, #0]
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    ldr x4, [sp, #136]
    str x4, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x10, x0
.Lssa_ordmap__node_insert__i32__i32_351:
    ldr x7, [x10]
    cmp x19, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    str x22, [x10, x5, lsl #3]
    add x9, x19, #1
    sxtw x9, w9
.Lssa_ordmap__node_insert__i32__i32_43:
    ldr x11, [x21, #0]
    adrp x12, .S1
    add x12, x12, :lo12:.S1
    cmp x11, x12
    b.ne .Lssa_ordmap__node_insert__i32__i32_40
.Lssa_ordmap__node_insert__i32__i32_42:
    ldr x11, [x21, #24]
    ldr x12, [x11, #0]
    b .Lssa_ordmap__node_insert__i32__i32_38
.Lssa_ordmap__node_insert__i32__i32_40:
    ldr x12, [x21, #48]
.Lssa_ordmap__node_insert__i32__i32_39:
.Lssa_ordmap__node_insert__i32__i32_38:
    ldr x11, [x10, #0]
    cmp x11, x9
    b.ne .Lssa_ordmap__node_insert__i32__i32_35
.Lssa_ordmap__node_insert__i32__i32_37:
    mov x0, x10
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush901s
.Lssa_ordmap__node_insert__i32__i32_apush901o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush901e
.Lssa_ordmap__node_insert__i32__i32_apush901s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
.Lssa_ordmap__node_insert__i32__i32_apush901e:
    mov x22, x0
    b .Lssa_ordmap__node_insert__i32__i32_32
.Lssa_ordmap__node_insert__i32__i32_35:
    sub x11, x11, #1
    sxtw x11, w11
    ldr x6, [x10]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x13, [x10, x5, lsl #3]
    mov x0, x10
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush906s
.Lssa_ordmap__node_insert__i32__i32_apush906o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush906e
.Lssa_ordmap__node_insert__i32__i32_apush906s:
    str x9, [sp, #56]
    str x11, [sp, #48]
    str x12, [sp, #40]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x11, [sp, #48]
    ldr x12, [sp, #40]
.Lssa_ordmap__node_insert__i32__i32_apush906e:
.Lssa_ordmap__node_insert__i32__i32_34:
.Lssa_ordmap__node_insert__i32__i32_362:
    cmp x11, x9
    b.le .Lssa_ordmap__node_insert__i32__i32_33
.Lssa_ordmap__node_insert__i32__i32_363:
    sub x13, x11, #1
    ldr x6, [x0]
    cmp x13, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x13, #1
    ldr x10, [x0, x5, lsl #3]
    ldr x7, [x0]
    cmp x11, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    str x10, [x0, x5, lsl #3]
    mov x11, x13
    cmp x11, x9
    b.gt .Lssa_ordmap__node_insert__i32__i32_363
.Lssa_ordmap__node_insert__i32__i32_33:
    ldr x7, [x0]
    cmp x9, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    str x12, [x0, x5, lsl #3]
    mov x22, x0
.Lssa_ordmap__node_insert__i32__i32_32:
    tst x23, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq32
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq32
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq32:
    b.ne .Lssa_ordmap__node_insert__i32__i32_371
.Lssa_ordmap__node_insert__i32__i32_370:
    mov x24, x23
    b .Lssa_ordmap__node_insert__i32__i32_372
.Lssa_ordmap__node_insert__i32__i32_371:
    cmp x23, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck931
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd931
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck931
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece931
.Lssa_ordmap__node_insert__i32__i32_rcdecd931:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck931:
    mov x0, x23
.Lssa_ordmap__node_insert__i32__i32_rcdece931:
    mov x14, #0
    ldr x12, [x23, #0]
    str x12, [sp, #-16]!
    str x14, [sp, #-16]!
    str x23, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x24, x0
    mov x0, x24
    bl __fn___fern_arr_inc_elems.r
.Lssa_ordmap__node_insert__i32__i32_372:
    ldr x6, [x24]
    cmp x19, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    ldr x0, [x24, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    ldr x6, [sp, #168]
    ldr x7, [x24]
    cmp x19, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    str x6, [x24, x5, lsl #3]
    add x12, x19, #1
    sxtw x23, w12
.Lssa_ordmap__node_insert__i32__i32_31:
    ldr x12, [x24, #0]
    cmp x12, x23
    b.ne .Lssa_ordmap__node_insert__i32__i32_28
.Lssa_ordmap__node_insert__i32__i32_30:
    mov x0, x24
    mov x1, x21
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush945s
.Lssa_ordmap__node_insert__i32__i32_apush945o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush945e
.Lssa_ordmap__node_insert__i32__i32_apush945s:
    str x12, [sp, #56]
    bl __fern_arr_push_owned
    ldr x12, [sp, #56]
.Lssa_ordmap__node_insert__i32__i32_apush945e:
    mov x28, x0
    b .Lssa_ordmap__node_insert__i32__i32_24
.Lssa_ordmap__node_insert__i32__i32_28:
    sub x12, x12, #1
    sxtw x12, w12
    ldr x6, [x24]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x14, [x24, x5, lsl #3]
    tbnz x14, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc950
    cmp x14, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc950
    ldur w5, [x14, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc950
    add w5, w5, #1
    stur w5, [x14, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc950:
    mov x0, x14
    mov x0, x24
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush951s
.Lssa_ordmap__node_insert__i32__i32_apush951o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush951e
.Lssa_ordmap__node_insert__i32__i32_apush951s:
    str x12, [sp, #56]
    bl __fern_arr_push_owned
    ldr x12, [sp, #56]
.Lssa_ordmap__node_insert__i32__i32_apush951e:
    mov x28, x0
.Lssa_ordmap__node_insert__i32__i32_27:
    mov x24, x12
.Lssa_ordmap__node_insert__i32__i32_378:
    cmp x24, x23
    b.le .Lssa_ordmap__node_insert__i32__i32_26
.Lssa_ordmap__node_insert__i32__i32_379:
    sub x25, x24, #1
    ldr x6, [x28]
    cmp x25, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x25, #1
    ldr x27, [x28, x5, lsl #3]
    tbnz x27, #0, .Lssa_ordmap__node_insert__i32__i32_rcinc967
    cmp x27, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcinc967
    ldur w5, [x27, #-8]
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcinc967
    add w5, w5, #1
    stur w5, [x27, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcinc967:
    mov x0, x27
    ldr x6, [x28]
    cmp x24, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    ldr x0, [x28, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    ldr x7, [x28]
    cmp x24, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x24, #1
    str x27, [x28, x5, lsl #3]
    mov x24, x25
    cmp x24, x23
    b.gt .Lssa_ordmap__node_insert__i32__i32_379
.Lssa_ordmap__node_insert__i32__i32_26:
    ldr x6, [x28]
    cmp x23, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    ldr x0, [x28, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    ldr x7, [x28]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    str x21, [x28, x5, lsl #3]
.Lssa_ordmap__node_insert__i32__i32_25:
.Lssa_ordmap__node_insert__i32__i32_24:
    ldr x4, [sp, #112]
    ldr x23, [x4, #0]
    cmp x23, x19
    b.ne .Lssa_ordmap__node_insert__i32__i32_21
.Lssa_ordmap__node_insert__i32__i32_23:
    ldr x4, [sp, #112]
    tst x4, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq23
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq23
    ldur w5, [x4, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq23:
    b.ne .Lssa_ordmap__node_insert__i32__i32_391
.Lssa_ordmap__node_insert__i32__i32_390:
    ldr x0, [sp, #112]
    mov x1, x26
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush983s
.Lssa_ordmap__node_insert__i32__i32_apush983o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush983e
.Lssa_ordmap__node_insert__i32__i32_apush983s:
    bl __fern_arr_push_owned
.Lssa_ordmap__node_insert__i32__i32_apush983e:
    mov x11, x0
    mov x21, x11
    b .Lssa_ordmap__node_insert__i32__i32_392
.Lssa_ordmap__node_insert__i32__i32_391:
    ldr x0, [sp, #112]
    mov x1, x26
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush984s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__node_insert__i32__i32_apush984o
    tbz w3, #31, .Lssa_ordmap__node_insert__i32__i32_apush984s
.Lssa_ordmap__node_insert__i32__i32_apush984o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush984e
.Lssa_ordmap__node_insert__i32__i32_apush984s:
    bl __fern_arr_push
.Lssa_ordmap__node_insert__i32__i32_apush984e:
    mov x21, x0
    ldr x4, [sp, #112]
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck985
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd985
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck985
    ldr x0, [sp, #112]
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece985
.Lssa_ordmap__node_insert__i32__i32_rcdecd985:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck985:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_rcdece985:
.Lssa_ordmap__node_insert__i32__i32_392:
    mov x26, x21
    b .Lssa_ordmap__node_insert__i32__i32_18
.Lssa_ordmap__node_insert__i32__i32_21:
    sub w11, w23, #1
    ldr x4, [sp, #112]
    ldr x6, [x4]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x14, [x4, x5, lsl #3]
    tst x4, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq21
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq21
    ldur w5, [x4, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq21:
    b.ne .Lssa_ordmap__node_insert__i32__i32_395
.Lssa_ordmap__node_insert__i32__i32_394:
    ldr x0, [sp, #112]
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush992s
.Lssa_ordmap__node_insert__i32__i32_apush992o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush992e
.Lssa_ordmap__node_insert__i32__i32_apush992s:
    str x14, [sp, #56]
    bl __fern_arr_push_owned
    ldr x14, [sp, #56]
.Lssa_ordmap__node_insert__i32__i32_apush992e:
    mov x11, x0
    mov x21, x11
    b .Lssa_ordmap__node_insert__i32__i32_396
.Lssa_ordmap__node_insert__i32__i32_395:
    ldr x0, [sp, #112]
    mov x1, x14
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__node_insert__i32__i32_apush993s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__node_insert__i32__i32_apush993o
    tbz w3, #31, .Lssa_ordmap__node_insert__i32__i32_apush993s
.Lssa_ordmap__node_insert__i32__i32_apush993o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__node_insert__i32__i32_apush993e
.Lssa_ordmap__node_insert__i32__i32_apush993s:
    bl __fern_arr_push
.Lssa_ordmap__node_insert__i32__i32_apush993e:
    mov x21, x0
    ldr x4, [sp, #112]
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck994
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd994
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck994
    ldr x0, [sp, #112]
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece994
.Lssa_ordmap__node_insert__i32__i32_rcdecd994:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck994:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_rcdece994:
.Lssa_ordmap__node_insert__i32__i32_396:
    sub x23, x23, #1
    sxtw x23, w23
.Lssa_ordmap__node_insert__i32__i32_20:
.Lssa_ordmap__node_insert__i32__i32_397:
    cmp x23, x19
    b.le .Lssa_ordmap__node_insert__i32__i32_19
.Lssa_ordmap__node_insert__i32__i32_398:
    sub x14, x23, #1
    ldr x6, [x21]
    cmp x14, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x14, #1
    ldr x27, [x21, x5, lsl #3]
    tst x21, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq398
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq398
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq398:
    b.ne .Lssa_ordmap__node_insert__i32__i32_404
.Lssa_ordmap__node_insert__i32__i32_403:
    b .Lssa_ordmap__node_insert__i32__i32_405
.Lssa_ordmap__node_insert__i32__i32_404:
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck1012
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd1012
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck1012
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece1012
.Lssa_ordmap__node_insert__i32__i32_rcdecd1012:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck1012:
    mov x0, x21
.Lssa_ordmap__node_insert__i32__i32_rcdece1012:
    mov x14, #0
    ldr x11, [x21, #0]
    str x11, [sp, #-16]!
    str x14, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x21, x0
.Lssa_ordmap__node_insert__i32__i32_405:
    ldr x7, [x21]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    str x27, [x21, x5, lsl #3]
    sub x23, x23, #1
    cmp x23, x19
    b.gt .Lssa_ordmap__node_insert__i32__i32_398
.Lssa_ordmap__node_insert__i32__i32_19:
    tst x21, #1
    b.ne .Lssa_ordmap__node_insert__i32__i32_uq19
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_uq19
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa_ordmap__node_insert__i32__i32_uq19:
    b.ne .Lssa_ordmap__node_insert__i32__i32_409
.Lssa_ordmap__node_insert__i32__i32_408:
    mov x0, x21
    b .Lssa_ordmap__node_insert__i32__i32_410
.Lssa_ordmap__node_insert__i32__i32_409:
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck1022
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd1022
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck1022
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece1022
.Lssa_ordmap__node_insert__i32__i32_rcdecd1022:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck1022:
    mov x0, x21
.Lssa_ordmap__node_insert__i32__i32_rcdece1022:
    mov x11, #0
    ldr x14, [x21, #0]
    str x14, [sp, #-16]!
    str x11, [sp, #-16]!
    str x21, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
.Lssa_ordmap__node_insert__i32__i32_410:
    ldr x7, [x0]
    cmp x19, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x19, #1
    str x26, [x0, x5, lsl #3]
    mov x26, x0
.Lssa_ordmap__node_insert__i32__i32_18:
    ldr x14, [x28, #0]
    cmp x14, #64
    b.le .Lssa_ordmap__node_insert__i32__i32_14
.Lssa_ordmap__node_insert__i32__i32_17:
    ldr x4, [sp, #96]
    ldr x5, [sp, #72]
    add x14, x4, x5
    sxtw x21, w14
    mov x14, #7
    ldr x4, [sp, #88]
    str x4, [sp, #-16]!
    str x14, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x14, .S2
    add x14, x14, :lo12:.S2
    str x14, [x0, #0]
    ldr x5, [sp, #128]
    str x5, [x0, #8]
    ldr x5, [sp, #120]
    str x5, [x0, #16]
    str x26, [x0, #24]
    str x28, [x0, #32]
    str x22, [x0, #40]
    str x21, [x0, #48]
    b .Lssa_ordmap__node_insert__i32__i32_1
.Lssa_ordmap__node_insert__i32__i32_14:
    ldr x4, [sp, #128]
    cmp x4, #0
    b.le .Lssa_ordmap__node_insert__i32__i32_8
.Lssa_ordmap__node_insert__i32__i32_13:
    cmp x19, #0
    b.eq .Lssa_ordmap__node_insert__i32__i32_10
.Lssa_ordmap__node_insert__i32__i32_12:
    ldr x11, [x26, #0]
    sub x11, x11, #1
    sxtw x11, w11
    cmp x19, x11
    b.ne .Lssa_ordmap__node_insert__i32__i32_8
.Lssa_ordmap__node_insert__i32__i32_10:
    ldr x11, [x26, #0]
    cmp x11, #2
    b.ge .Lssa_ordmap__node_insert__i32__i32_6
.Lssa_ordmap__node_insert__i32__i32_9:
    mov x9, #0
    b .Lssa_ordmap__node_insert__i32__i32_5
.Lssa_ordmap__node_insert__i32__i32_8:
    ldr x21, [sp, #128]
    b .Lssa_ordmap__node_insert__i32__i32_2
.Lssa_ordmap__node_insert__i32__i32_6:
    ldr x14, [x26, #8]
    sub w11, w11, #1
    add x5, x11, #1
    ldr x14, [x26, x5, lsl #3]
    mov x9, #0
.Lssa_ordmap__node_insert__i32__i32_5:
    ldr x5, [sp, #128]
    cmp x9, x5
    b.ge .Lssa_ordmap__node_insert__i32__i32_3
.Lssa_ordmap__node_insert__i32__i32_4:
    mov x21, x9
    b .Lssa_ordmap__node_insert__i32__i32_2
.Lssa_ordmap__node_insert__i32__i32_3:
    ldr x21, [sp, #128]
.Lssa_ordmap__node_insert__i32__i32_2:
    ldr x0, [sp, #128]
    mov x9, x21
    ldr x10, [sp, #120]
    mov x11, x26
    mov x12, x19
    bl __fn_ordmap__fitted_words__i32.r
    mov x23, x0
    ldr x4, [sp, #120]
    cmp x4, #16, lsl #12
    b.lo .Lssa_ordmap__node_insert__i32__i32_rcdeck1076
    ldur w5, [x4, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__node_insert__i32__i32_rcdecd1076
    tbnz w5, #31, .Lssa_ordmap__node_insert__i32__i32_rcdeck1076
    ldr x0, [sp, #120]
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__node_insert__i32__i32_rcdece1076
.Lssa_ordmap__node_insert__i32__i32_rcdecd1076:
    sub w5, w5, #1
    stur w5, [x4, #-8]
.Lssa_ordmap__node_insert__i32__i32_rcdeck1076:
    mov x0, x4
.Lssa_ordmap__node_insert__i32__i32_rcdece1076:
    ldr x4, [sp, #96]
    ldr x5, [sp, #72]
    add x14, x4, x5
    sxtw x19, w14
    mov x14, #7
    ldr x4, [sp, #88]
    str x4, [sp, #-16]!
    str x14, [sp, #-16]!
    bl __fn___fern_alloc_reuse
    add sp, sp, #32
    adrp x14, .S2
    add x14, x14, :lo12:.S2
    str x14, [x0, #0]
    str x21, [x0, #8]
    str x23, [x0, #16]
    str x26, [x0, #24]
    str x28, [x0, #32]
    str x22, [x0, #40]
    str x19, [x0, #48]
.Lssa_ordmap__node_insert__i32__i32_1:
    .cfi_remember_state
    sub sp, x29, #80
    ldp x27, x28, [sp], #16
    ldp x25, x26, [sp], #16
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__upper__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_ordmap__upper__i32.k:
__fn_ordmap__upper__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
    mov x20, x10
    mov x21, x11
.Lssa_ordmap__upper__i32_0:
.Lssa_ordmap__upper__i32_34:
    cmp x0, #0
    b.eq .Lssa_ordmap__upper__i32_31
.Lssa_ordmap__upper__i32_33:
    ldr x9, [x20, #0]
    cmp x9, #0
    b.eq .Lssa_ordmap__upper__i32_31
.Lssa_ordmap__upper__i32_32:
    ldr x6, [x20, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    ldr x9, [x20, #8]
    cmp x0, #0
    b.gt .Lssa_ordmap__upper__i32_29
.Lssa_ordmap__upper__i32_31:
    mov x0, #-1
    b .Lssa_ordmap__upper__i32_17
.Lssa_ordmap__upper__i32_29:
    ldr x6, [x20, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    ldr x9, [x20, #8]
.Lssa_ordmap__upper__i32_28:
    cmp x21, x9
    b.ge .Lssa_ordmap__upper__i32_25
.Lssa_ordmap__upper__i32_27:
    mov x10, #-1
    b .Lssa_ordmap__upper__i32_21
.Lssa_ordmap__upper__i32_25:
    cmp x21, x9
    b.le .Lssa_ordmap__upper__i32_22
.Lssa_ordmap__upper__i32_24:
    mov x10, #1
    b .Lssa_ordmap__upper__i32_21
.Lssa_ordmap__upper__i32_22:
    mov x10, #0
.Lssa_ordmap__upper__i32_21:
    cmp x10, #0
    b.ge .Lssa_ordmap__upper__i32_18
.Lssa_ordmap__upper__i32_20:
    mov x0, #0
    b .Lssa_ordmap__upper__i32_17
.Lssa_ordmap__upper__i32_18:
    ldr x0, [x20, #0]
.Lssa_ordmap__upper__i32_17:
    cmp x0, #0
    b.lt .Lssa_ordmap__upper__i32_14
.Lssa_ordmap__upper__i32_16:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_ordmap__upper__i32_14:
    sxtw x10, w21
    movz x9, #32768, lsl #48
    eor x22, x10, x9
.Lssa_ordmap__upper__i32_13:
    ldr x0, [x19, #0]
    cmp x0, #0
    b.eq .Lssa_ordmap__upper__i32_11
.Lssa_ordmap__upper__i32_12:
    ldr x6, [x19, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    ldr x9, [x19, #8]
    cmp x22, x9
    b.hi .Lssa_ordmap__upper__i32_9
.Lssa_ordmap__upper__i32_11:
    mov x0, #0
    b .Lssa_ordmap__upper__i32_4
.Lssa_ordmap__upper__i32_9:
    sub w9, w0, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x10, [x19, x5, lsl #3]
    cmp x22, x10
    b.ls .Lssa_ordmap__upper__i32_6
.Lssa_ordmap__upper__i32_8:
    b .Lssa_ordmap__upper__i32_4
.Lssa_ordmap__upper__i32_6:
    mov x1, x22
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    mov x2, #0
    dup v1.2d, x1
    eor v3.16b, v3.16b, v3.16b
.L0:
    sub x4, x3, x2
    cmp x4, #2
    b.lt .L1
    add x5, x0, x2, lsl #3
    ld1 {v0.2d}, [x5]
    cmhi v0.2d, v1.2d, v0.2d
    sub v3.2d, v3.2d, v0.2d
    add x2, x2, #2
    b .L0
.L1:
    umov x7, v3.d[0]
    umov x4, v3.d[1]
    add x7, x7, x4
    cmp x2, x3
    b.ge .L2
    add x5, x0, x2, lsl #3
    ldr x4, [x5]
    cmp x4, x1
    cinc x7, x7, lo
.L2:
    mov x0, x7
.Lssa_ordmap__upper__i32_5:
.Lssa_ordmap__upper__i32_4:
    mov x10, x0
.Lssa_ordmap__upper__i32_81:
    ldr x9, [x19, #0]
    cmp x10, x9
    b.ge .Lssa_ordmap__upper__i32_94
.Lssa_ordmap__upper__i32_83:
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x10, #1
    ldr x9, [x19, x5, lsl #3]
    cmp x9, x22
    b.ne .Lssa_ordmap__upper__i32_94
.Lssa_ordmap__upper__i32_82:
    add x10, x10, #1
    b .Lssa_ordmap__upper__i32_81
.Lssa_ordmap__upper__i32_2:
.Lssa_ordmap__upper__i32_94:
    cmp x0, x10
    b.ge .Lssa_ordmap__upper__i32_1
.Lssa_ordmap__upper__i32_106:
    sub x9, x10, x0
    sxtw x9, w9
    mov x4, x9
    asr x5, x4, #63
    add x5, x4, x5, lsr #63
    asr x4, x5, #1
    mov x11, x4
    add x11, x0, x11
    sxtw x11, w11
    ldr x6, [x20]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x9, [x20, x5, lsl #3]
.Lssa_ordmap__upper__i32_105:
    cmp x9, x21
    b.ge .Lssa_ordmap__upper__i32_102
.Lssa_ordmap__upper__i32_104:
    mov x12, #-1
    b .Lssa_ordmap__upper__i32_98
.Lssa_ordmap__upper__i32_102:
    cmp x9, x21
    b.le .Lssa_ordmap__upper__i32_99
.Lssa_ordmap__upper__i32_101:
    mov x12, #1
    b .Lssa_ordmap__upper__i32_98
.Lssa_ordmap__upper__i32_99:
    mov x12, #0
.Lssa_ordmap__upper__i32_98:
    add x9, x11, #1
    sxtw x9, w9
    cmp x12, #0
    csel x0, x9, x0, le
    csel x10, x10, x11, le
.Lssa_ordmap__upper__i32_95:
    cmp x0, x10
    b.lt .Lssa_ordmap__upper__i32_106
.Lssa_ordmap__upper__i32_1:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__make_branch__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_ordmap__make_branch__i32__i32.k:
__fn_ordmap__make_branch__i32__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
    mov x21, x10
.Lssa_ordmap__make_branch__i32__i32_0:
.Lssa_ordmap__make_branch__i32__i32_7:
    ldr x9, [x19, #0]
    cmp x9, #2
    b.ge .Lssa_ordmap__make_branch__i32__i32_4
.Lssa_ordmap__make_branch__i32__i32_6:
    mov x22, #0
    b .Lssa_ordmap__make_branch__i32__i32_3
.Lssa_ordmap__make_branch__i32__i32_4:
    ldr x10, [x19, #8]
    sub w9, w9, #1
    add x5, x9, #1
    ldr x10, [x19, x5, lsl #3]
    mov x22, #0
.Lssa_ordmap__make_branch__i32__i32_3:
    mov x10, #-1
.Lssa_ordmap__make_branch__i32__i32_2:
    mov x23, #0
.Lssa_ordmap__make_branch__i32__i32_13:
    add x10, x10, #1
    sxtw x10, w10
    ldr x9, [x21, #0]
    cmp x10, x9
    b.ge .Lssa_ordmap__make_branch__i32__i32_1
.Lssa_ordmap__make_branch__i32__i32_14:
    add x5, x10, #1
    ldr x9, [x21, x5, lsl #3]
    add x9, x23, x9
    sxtw x23, w9
    b .Lssa_ordmap__make_branch__i32__i32_13
.Lssa_ordmap__make_branch__i32__i32_1:
    mov x0, x19
    mov x9, x22
    bl __fn_ordmap__words_at__i32.r
    mov x24, x0
    tbnz x19, #0, .Lssa_ordmap__make_branch__i32__i32_rcinc62
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__make_branch__i32__i32_rcinc62
    ldur w5, [x19, #-8]
    tbnz w5, #31, .Lssa_ordmap__make_branch__i32__i32_rcinc62
    add w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_ordmap__make_branch__i32__i32_rcinc62:
    mov x0, x19
    tbnz x20, #0, .Lssa_ordmap__make_branch__i32__i32_rcinc63
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__make_branch__i32__i32_rcinc63
    ldur w5, [x20, #-8]
    tbnz w5, #31, .Lssa_ordmap__make_branch__i32__i32_rcinc63
    add w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__make_branch__i32__i32_rcinc63:
    mov x0, x20
    tbnz x21, #0, .Lssa_ordmap__make_branch__i32__i32_rcinc64
    cmp x21, #16, lsl #12
    b.lo .Lssa_ordmap__make_branch__i32__i32_rcinc64
    ldur w5, [x21, #-8]
    tbnz w5, #31, .Lssa_ordmap__make_branch__i32__i32_rcinc64
    add w5, w5, #1
    stur w5, [x21, #-8]
.Lssa_ordmap__make_branch__i32__i32_rcinc64:
    mov x0, x21
    mov x0, #7
    bl __fern_arr_box
    adrp x9, .S2
    add x9, x9, :lo12:.S2
    str x9, [x0, #0]
    str x22, [x0, #8]
    str x24, [x0, #16]
    str x19, [x0, #24]
    str x20, [x0, #32]
    str x21, [x0, #40]
    str x23, [x0, #48]
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__lower__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
__fn_ordmap__lower__i32.k:
__fn_ordmap__lower__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x9
    mov x20, x10
    mov x21, x11
.Lssa_ordmap__lower__i32_0:
.Lssa_ordmap__lower__i32_34:
    cmp x0, #0
    b.eq .Lssa_ordmap__lower__i32_31
.Lssa_ordmap__lower__i32_33:
    ldr x9, [x20, #0]
    cmp x9, #0
    b.eq .Lssa_ordmap__lower__i32_31
.Lssa_ordmap__lower__i32_32:
    ldr x6, [x20, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    ldr x9, [x20, #8]
    cmp x0, #0
    b.gt .Lssa_ordmap__lower__i32_29
.Lssa_ordmap__lower__i32_31:
    mov x0, #-1
    b .Lssa_ordmap__lower__i32_17
.Lssa_ordmap__lower__i32_29:
    ldr x6, [x20, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    ldr x9, [x20, #8]
.Lssa_ordmap__lower__i32_28:
    cmp x21, x9
    b.ge .Lssa_ordmap__lower__i32_25
.Lssa_ordmap__lower__i32_27:
    mov x10, #-1
    b .Lssa_ordmap__lower__i32_21
.Lssa_ordmap__lower__i32_25:
    cmp x21, x9
    b.le .Lssa_ordmap__lower__i32_22
.Lssa_ordmap__lower__i32_24:
    mov x10, #1
    b .Lssa_ordmap__lower__i32_21
.Lssa_ordmap__lower__i32_22:
    mov x10, #0
.Lssa_ordmap__lower__i32_21:
    cmp x10, #0
    b.ge .Lssa_ordmap__lower__i32_18
.Lssa_ordmap__lower__i32_20:
    mov x0, #0
    b .Lssa_ordmap__lower__i32_17
.Lssa_ordmap__lower__i32_18:
    ldr x0, [x20, #0]
.Lssa_ordmap__lower__i32_17:
    cmp x0, #0
    b.lt .Lssa_ordmap__lower__i32_14
.Lssa_ordmap__lower__i32_16:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_ordmap__lower__i32_14:
    sxtw x10, w21
    movz x9, #32768, lsl #48
    eor x22, x10, x9
.Lssa_ordmap__lower__i32_13:
    ldr x0, [x19, #0]
    cmp x0, #0
    b.eq .Lssa_ordmap__lower__i32_11
.Lssa_ordmap__lower__i32_12:
    ldr x6, [x19, #0]
    cmp x6, #0
    b.hi 1f
    b __fern_oob_abort
1:
    ldr x9, [x19, #8]
    cmp x22, x9
    b.hi .Lssa_ordmap__lower__i32_9
.Lssa_ordmap__lower__i32_11:
    mov x0, #0
    b .Lssa_ordmap__lower__i32_4
.Lssa_ordmap__lower__i32_9:
    sub w9, w0, #1
    ldr x6, [x19]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x10, [x19, x5, lsl #3]
    cmp x22, x10
    b.ls .Lssa_ordmap__lower__i32_6
.Lssa_ordmap__lower__i32_8:
    b .Lssa_ordmap__lower__i32_4
.Lssa_ordmap__lower__i32_6:
    mov x1, x22
    mov x0, x19
    ldr x3, [x0]
    add x0, x0, #8
    mov x2, #0
    dup v1.2d, x1
    eor v3.16b, v3.16b, v3.16b
.L3:
    sub x4, x3, x2
    cmp x4, #2
    b.lt .L4
    add x5, x0, x2, lsl #3
    ld1 {v0.2d}, [x5]
    cmhi v0.2d, v1.2d, v0.2d
    sub v3.2d, v3.2d, v0.2d
    add x2, x2, #2
    b .L3
.L4:
    umov x7, v3.d[0]
    umov x4, v3.d[1]
    add x7, x7, x4
    cmp x2, x3
    b.ge .L5
    add x5, x0, x2, lsl #3
    ldr x4, [x5]
    cmp x4, x1
    cinc x7, x7, lo
.L5:
    mov x0, x7
.Lssa_ordmap__lower__i32_5:
.Lssa_ordmap__lower__i32_4:
    mov x10, x0
.Lssa_ordmap__lower__i32_81:
    ldr x9, [x19, #0]
    cmp x10, x9
    b.ge .Lssa_ordmap__lower__i32_94
.Lssa_ordmap__lower__i32_83:
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x10, #1
    ldr x9, [x19, x5, lsl #3]
    cmp x9, x22
    b.ne .Lssa_ordmap__lower__i32_94
.Lssa_ordmap__lower__i32_82:
    add x10, x10, #1
    b .Lssa_ordmap__lower__i32_81
.Lssa_ordmap__lower__i32_2:
.Lssa_ordmap__lower__i32_94:
    cmp x0, x10
    b.ge .Lssa_ordmap__lower__i32_1
.Lssa_ordmap__lower__i32_106:
    sub x9, x10, x0
    sxtw x9, w9
    mov x4, x9
    asr x5, x4, #63
    add x5, x4, x5, lsr #63
    asr x4, x5, #1
    mov x11, x4
    add x11, x0, x11
    sxtw x11, w11
    ldr x6, [x20]
    cmp x11, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x11, #1
    ldr x9, [x20, x5, lsl #3]
.Lssa_ordmap__lower__i32_105:
    cmp x9, x21
    b.ge .Lssa_ordmap__lower__i32_102
.Lssa_ordmap__lower__i32_104:
    mov x12, #-1
    b .Lssa_ordmap__lower__i32_98
.Lssa_ordmap__lower__i32_102:
    cmp x9, x21
    b.le .Lssa_ordmap__lower__i32_99
.Lssa_ordmap__lower__i32_101:
    mov x12, #1
    b .Lssa_ordmap__lower__i32_98
.Lssa_ordmap__lower__i32_99:
    mov x12, #0
.Lssa_ordmap__lower__i32_98:
    add x9, x11, #1
    sxtw x9, w9
    cmp x12, #0
    csel x0, x9, x0, lt
    csel x10, x10, x11, lt
.Lssa_ordmap__lower__i32_95:
    cmp x0, x10
    b.lt .Lssa_ordmap__lower__i32_106
.Lssa_ordmap__lower__i32_1:
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__fitted_words__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
    ldr x11, [sp, #48]
    ldr x12, [sp, #64]
__fn_ordmap__fitted_words__i32.k:
__fn_ordmap__fitted_words__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    sub sp, sp, #64
    mov x19, x10
    mov x20, x11
    mov x21, x12
.Lssa_ordmap__fitted_words__i32_0:
    cmp x9, x0
    b.eq .Lssa_ordmap__fitted_words__i32_8
.Lssa_ordmap__fitted_words__i32_10:
    mov x0, x20
    bl __fn_ordmap__words_at__i32.r
    mov x22, x0
    cmp x22, x20
    b.ne .Lssa_ordmap__fitted_words__i32_17
.Lssa_ordmap__fitted_words__i32_15:
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_rcdeck45
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__fitted_words__i32_rcdecd45
    tbnz w5, #31, .Lssa_ordmap__fitted_words__i32_rcdeck45
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__fitted_words__i32_rcdece45
.Lssa_ordmap__fitted_words__i32_rcdecd45:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__fitted_words__i32_rcdeck45:
    mov x0, x22
.Lssa_ordmap__fitted_words__i32_rcdece45:
.Lssa_ordmap__fitted_words__i32_17:
    cmp x22, x20
    b.ne .Lssa_ordmap__fitted_words__i32_20
.Lssa_ordmap__fitted_words__i32_18:
    tbnz x22, #0, .Lssa_ordmap__fitted_words__i32_rcinc47
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_rcinc47
    ldur w5, [x22, #-8]
    tbnz w5, #31, .Lssa_ordmap__fitted_words__i32_rcinc47
    add w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__fitted_words__i32_rcinc47:
    mov x0, x22
.Lssa_ordmap__fitted_words__i32_20:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
.Lssa_ordmap__fitted_words__i32_8:
    ldr x6, [x20]
    cmp x21, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    ldr x9, [x20, x5, lsl #3]
    sxtw x9, w9
    movz x10, #32768, lsl #48
    eor x20, x9, x10
.Lssa_ordmap__fitted_words__i32_7:
    ldr x10, [x19, #0]
    cmp x10, x21
    b.ne .Lssa_ordmap__fitted_words__i32_4
.Lssa_ordmap__fitted_words__i32_6:
    mov x0, x19
    mov x1, x20
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__fitted_words__i32_apush54s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__fitted_words__i32_apush54o
    tbz w3, #31, .Lssa_ordmap__fitted_words__i32_apush54s
.Lssa_ordmap__fitted_words__i32_apush54o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__fitted_words__i32_apush54e
.Lssa_ordmap__fitted_words__i32_apush54s:
    str x10, [sp, #56]
    bl __fern_arr_push
    ldr x10, [sp, #56]
.Lssa_ordmap__fitted_words__i32_apush54e:
    b .Lssa_ordmap__fitted_words__i32_1
.Lssa_ordmap__fitted_words__i32_4:
    sub x10, x10, #1
    sxtw x10, w10
    ldr x6, [x19]
    cmp x10, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x10, #1
    ldr x9, [x19, x5, lsl #3]
    mov x0, x19
    mov x1, x9
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__fitted_words__i32_apush59s
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lssa_ordmap__fitted_words__i32_apush59o
    tbz w3, #31, .Lssa_ordmap__fitted_words__i32_apush59s
.Lssa_ordmap__fitted_words__i32_apush59o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__fitted_words__i32_apush59e
.Lssa_ordmap__fitted_words__i32_apush59s:
    str x10, [sp, #56]
    bl __fern_arr_push
    ldr x10, [sp, #56]
.Lssa_ordmap__fitted_words__i32_apush59e:
.Lssa_ordmap__fitted_words__i32_3:
    mov x22, x0
    mov x23, x10
.Lssa_ordmap__fitted_words__i32_26:
    cmp x23, x21
    b.le .Lssa_ordmap__fitted_words__i32_2
.Lssa_ordmap__fitted_words__i32_27:
    sub x9, x23, #1
    ldr x6, [x22]
    cmp x9, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x9, #1
    ldr x24, [x22, x5, lsl #3]
    cmp x22, x19
    b.ne .Lssa_ordmap__fitted_words__i32_33
.Lssa_ordmap__fitted_words__i32_32:
    tst x22, #1
    b.ne .Lssa_ordmap__fitted_words__i32_uq32
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_uq32
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_ordmap__fitted_words__i32_uq32:
    b.ne .Lssa_ordmap__fitted_words__i32_36
.Lssa_ordmap__fitted_words__i32_35:
    b .Lssa_ordmap__fitted_words__i32_34
.Lssa_ordmap__fitted_words__i32_36:
    mov x9, #0
    ldr x10, [x22, #0]
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x22, x0
.Lssa_ordmap__fitted_words__i32_37:
    b .Lssa_ordmap__fitted_words__i32_34
.Lssa_ordmap__fitted_words__i32_33:
    tst x22, #1
    b.ne .Lssa_ordmap__fitted_words__i32_uq33
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_uq33
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_ordmap__fitted_words__i32_uq33:
    b.ne .Lssa_ordmap__fitted_words__i32_39
.Lssa_ordmap__fitted_words__i32_38:
    b .Lssa_ordmap__fitted_words__i32_34
.Lssa_ordmap__fitted_words__i32_39:
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_rcdeck82
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__fitted_words__i32_rcdecd82
    tbnz w5, #31, .Lssa_ordmap__fitted_words__i32_rcdeck82
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__fitted_words__i32_rcdece82
.Lssa_ordmap__fitted_words__i32_rcdecd82:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__fitted_words__i32_rcdeck82:
    mov x0, x22
.Lssa_ordmap__fitted_words__i32_rcdece82:
    mov x10, #0
    ldr x9, [x22, #0]
    str x9, [sp, #-16]!
    str x10, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x22, x0
.Lssa_ordmap__fitted_words__i32_40:
.Lssa_ordmap__fitted_words__i32_34:
    ldr x7, [x22]
    cmp x23, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x23, #1
    str x24, [x22, x5, lsl #3]
    sub x23, x23, #1
    cmp x23, x21
    b.gt .Lssa_ordmap__fitted_words__i32_27
.Lssa_ordmap__fitted_words__i32_2:
    cmp x22, x19
    b.ne .Lssa_ordmap__fitted_words__i32_44
.Lssa_ordmap__fitted_words__i32_43:
    tst x22, #1
    b.ne .Lssa_ordmap__fitted_words__i32_uq43
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_uq43
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_ordmap__fitted_words__i32_uq43:
    b.ne .Lssa_ordmap__fitted_words__i32_47
.Lssa_ordmap__fitted_words__i32_46:
    b .Lssa_ordmap__fitted_words__i32_48
.Lssa_ordmap__fitted_words__i32_47:
    mov x9, #0
    ldr x10, [x22, #0]
    str x10, [sp, #-16]!
    str x9, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
    mov x22, x0
.Lssa_ordmap__fitted_words__i32_48:
    mov x0, x22
    b .Lssa_ordmap__fitted_words__i32_45
.Lssa_ordmap__fitted_words__i32_44:
    tst x22, #1
    b.ne .Lssa_ordmap__fitted_words__i32_uq44
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_uq44
    ldur w5, [x22, #-8]
    cmp w5, #1
.Lssa_ordmap__fitted_words__i32_uq44:
    b.ne .Lssa_ordmap__fitted_words__i32_50
.Lssa_ordmap__fitted_words__i32_49:
    mov x0, x22
    b .Lssa_ordmap__fitted_words__i32_45
.Lssa_ordmap__fitted_words__i32_50:
    cmp x22, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_rcdeck99
    ldur w5, [x22, #-8]
    cmp w5, #1
    b.gt .Lssa_ordmap__fitted_words__i32_rcdecd99
    tbnz w5, #31, .Lssa_ordmap__fitted_words__i32_rcdeck99
    mov x0, x22
    bl __fn___fern_arr_dec.u
    b .Lssa_ordmap__fitted_words__i32_rcdece99
.Lssa_ordmap__fitted_words__i32_rcdecd99:
    sub w5, w5, #1
    stur w5, [x22, #-8]
.Lssa_ordmap__fitted_words__i32_rcdeck99:
    mov x0, x22
.Lssa_ordmap__fitted_words__i32_rcdece99:
    mov x10, #0
    ldr x9, [x22, #0]
    str x9, [sp, #-16]!
    str x10, [sp, #-16]!
    str x22, [sp, #-16]!
    bl __fn___fern_arr_slice
    add sp, sp, #48
.Lssa_ordmap__fitted_words__i32_51:
.Lssa_ordmap__fitted_words__i32_45:
    ldr x7, [x0]
    cmp x21, x7
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x21, #1
    str x20, [x0, x5, lsl #3]
.Lssa_ordmap__fitted_words__i32_1:
    cmp x0, x19
    b.ne .Lssa_ordmap__fitted_words__i32_54
.Lssa_ordmap__fitted_words__i32_52:
    tbnz x0, #0, .Lssa_ordmap__fitted_words__i32_rcinc110
    cmp x0, #16, lsl #12
    b.lo .Lssa_ordmap__fitted_words__i32_rcinc110
    ldur w5, [x0, #-8]
    tbnz w5, #31, .Lssa_ordmap__fitted_words__i32_rcinc110
    add w5, w5, #1
    stur w5, [x0, #-8]
.Lssa_ordmap__fitted_words__i32_rcinc110:
    mov x9, x0
.Lssa_ordmap__fitted_words__i32_54:
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__span__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_ordmap__span__i32.k:
__fn_ordmap__span__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    sub sp, sp, #64
    mov x11, x10
    mov x10, x9
    mov x9, x0
.Lssa_ordmap__span__i32_0:
    adrp x0, .K0
    add x0, x0, :lo12:.K0
.Lssa_ordmap__span__i32_2:
    mov x12, x10
    mov x10, x0
.Lssa_ordmap__span__i32_3:
    cmp x12, x11
    b.ge .Lssa_ordmap__span__i32_1
.Lssa_ordmap__span__i32_4:
    ldr x6, [x9]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x13, [x9, x5, lsl #3]
    mov x0, x10
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__span__i32_apush19s
.Lssa_ordmap__span__i32_apush19o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__span__i32_apush19e
.Lssa_ordmap__span__i32_apush19s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
.Lssa_ordmap__span__i32_apush19e:
    mov x10, x0
    add x12, x12, #1
    cmp x12, x11
    b.lt .Lssa_ordmap__span__i32_4
.Lssa_ordmap__span__i32_1:
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__make_leaf__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_ordmap__make_leaf__i32__i32.k:
__fn_ordmap__make_leaf__i32__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa_ordmap__make_leaf__i32__i32_0:
.Lssa_ordmap__make_leaf__i32__i32_5:
    ldr x9, [x19, #0]
    cmp x9, #2
    b.ge .Lssa_ordmap__make_leaf__i32__i32_2
.Lssa_ordmap__make_leaf__i32__i32_4:
    mov x21, #0
    b .Lssa_ordmap__make_leaf__i32__i32_1
.Lssa_ordmap__make_leaf__i32__i32_2:
    ldr x10, [x19, #8]
    sub w9, w9, #1
    add x5, x9, #1
    ldr x10, [x19, x5, lsl #3]
    mov x21, #0
.Lssa_ordmap__make_leaf__i32__i32_1:
    mov x0, x19
    mov x9, x21
    bl __fn_ordmap__words_at__i32.r
    mov x22, x0
    tbnz x19, #0, .Lssa_ordmap__make_leaf__i32__i32_rcinc36
    cmp x19, #16, lsl #12
    b.lo .Lssa_ordmap__make_leaf__i32__i32_rcinc36
    ldur w5, [x19, #-8]
    tbnz w5, #31, .Lssa_ordmap__make_leaf__i32__i32_rcinc36
    add w5, w5, #1
    stur w5, [x19, #-8]
.Lssa_ordmap__make_leaf__i32__i32_rcinc36:
    mov x0, x19
    tbnz x20, #0, .Lssa_ordmap__make_leaf__i32__i32_rcinc37
    cmp x20, #16, lsl #12
    b.lo .Lssa_ordmap__make_leaf__i32__i32_rcinc37
    ldur w5, [x20, #-8]
    tbnz w5, #31, .Lssa_ordmap__make_leaf__i32__i32_rcinc37
    add w5, w5, #1
    stur w5, [x20, #-8]
.Lssa_ordmap__make_leaf__i32__i32_rcinc37:
    mov x0, x20
    mov x0, #5
    bl __fern_arr_box
    adrp x10, .S1
    add x10, x10, :lo12:.S1
    str x10, [x0, #0]
    str x21, [x0, #8]
    str x22, [x0, #16]
    str x19, [x0, #24]
    str x20, [x0, #32]
    .cfi_remember_state
    sub sp, x29, #32
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__span__ordmap__Node__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn_ordmap__span__ordmap__Node__i32__i32.k:
__fn_ordmap__span__ordmap__Node__i32__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    sub sp, sp, #64
    mov x11, x10
    mov x10, x9
    mov x9, x0
.Lssa_ordmap__span__ordmap__Node__i32__i32_0:
    adrp x0, .K0
    add x0, x0, :lo12:.K0
.Lssa_ordmap__span__ordmap__Node__i32__i32_2:
    mov x12, x10
    mov x10, x0
.Lssa_ordmap__span__ordmap__Node__i32__i32_3:
    cmp x12, x11
    b.ge .Lssa_ordmap__span__ordmap__Node__i32__i32_1
.Lssa_ordmap__span__ordmap__Node__i32__i32_4:
    ldr x6, [x9]
    cmp x12, x6
    b.lo 1f
    b __fern_oob_abort
1:
    add x5, x12, #1
    ldr x13, [x9, x5, lsl #3]
    tbnz x13, #0, .Lssa_ordmap__span__ordmap__Node__i32__i32_rcinc19
    cmp x13, #16, lsl #12
    b.lo .Lssa_ordmap__span__ordmap__Node__i32__i32_rcinc19
    ldur w5, [x13, #-8]
    tbnz w5, #31, .Lssa_ordmap__span__ordmap__Node__i32__i32_rcinc19
    add w5, w5, #1
    stur w5, [x13, #-8]
.Lssa_ordmap__span__ordmap__Node__i32__i32_rcinc19:
    mov x0, x13
    mov x0, x10
    mov x1, x13
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__span__ordmap__Node__i32__i32_apush20s
.Lssa_ordmap__span__ordmap__Node__i32__i32_apush20o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__span__ordmap__Node__i32__i32_apush20e
.Lssa_ordmap__span__ordmap__Node__i32__i32_apush20s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    str x12, [sp, #32]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
    ldr x12, [sp, #32]
.Lssa_ordmap__span__ordmap__Node__i32__i32_apush20e:
    mov x10, x0
    add x12, x12, #1
    cmp x12, x11
    b.lt .Lssa_ordmap__span__ordmap__Node__i32__i32_4
.Lssa_ordmap__span__ordmap__Node__i32__i32_1:
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn_ordmap__words_at__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
__fn_ordmap__words_at__i32.k:
__fn_ordmap__words_at__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    sub sp, sp, #64
    mov x10, x9
    mov x9, x0
.Lssa_ordmap__words_at__i32_0:
    adrp x0, .K0
    add x0, x0, :lo12:.K0
    mov x10, #-1
.Lssa_ordmap__words_at__i32_2:
    mov x11, x10
    mov x10, x0
.Lssa_ordmap__words_at__i32_3:
    add x11, x11, #1
    sxtw x11, w11
    ldr x12, [x9, #0]
    cmp x11, x12
    b.ge .Lssa_ordmap__words_at__i32_1
.Lssa_ordmap__words_at__i32_4:
    add x5, x11, #1
    ldr x12, [x9, x5, lsl #3]
    sxtw x12, w12
    movz x13, #32768, lsl #48
    eor x12, x12, x13
    mov x0, x10
    mov x1, x12
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lssa_ordmap__words_at__i32_apush38s
.Lssa_ordmap__words_at__i32_apush38o:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    b .Lssa_ordmap__words_at__i32_apush38e
.Lssa_ordmap__words_at__i32_apush38s:
    str x9, [sp, #56]
    str x10, [sp, #48]
    str x11, [sp, #40]
    bl __fern_arr_push_owned
    ldr x9, [sp, #56]
    ldr x10, [sp, #48]
    ldr x11, [sp, #40]
.Lssa_ordmap__words_at__i32_apush38e:
    mov x10, x0
    b .Lssa_ordmap__words_at__i32_3
.Lssa_ordmap__words_at__i32_1:
    mov x0, x10
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ordmap__OrdMap__i32__i32
.weak __fn___sem_drop_ordmap__OrdMap__i32__i32.k
__fn___sem_drop_ordmap__OrdMap__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ordmap__OrdMap__i32__i32.k:
__fn___sem_drop_ordmap__OrdMap__i32__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
.Lssa___sem_drop_ordmap__OrdMap__i32__i32_0:
    ldr x9, [x0, #8]
    mov x0, x9
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    mov x0, #0
    .cfi_remember_state
    mov sp, x29
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ordmap__OrdMap__i32__i32
.weak __fn___sem_release_ordmap__OrdMap__i32__i32.k
__fn___sem_release_ordmap__OrdMap__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ordmap__OrdMap__i32__i32.k:
__fn___sem_release_ordmap__OrdMap__i32__i32.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_ordmap__OrdMap__i32__i32_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ordmap__OrdMap__i32__i32_release_dec
    tbz w5, #31, .Lssa___sem_release_ordmap__OrdMap__i32__i32_release_slow
.Lssa___sem_release_ordmap__OrdMap__i32__i32_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_ordmap__OrdMap__i32__i32_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_ordmap__OrdMap__i32__i32_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ordmap__OrdMap__i32__i32_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ordmap__OrdMap__i32__i32_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ordmap__OrdMap__i32__i32_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_ordmap__OrdMap__i32__i32_uq0:
    b.ne .Lssa___sem_release_ordmap__OrdMap__i32__i32_3
.Lssa___sem_release_ordmap__OrdMap__i32__i32_1:
    mov x0, x19
    bl __fn___sem_drop_ordmap__OrdMap__i32__i32.r
.Lssa___sem_release_ordmap__OrdMap__i32__i32_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ordmap__OrdMap__i32__i32_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ordmap__OrdMap__i32__i32_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_ordmap__OrdMap__i32__i32_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_ordmap__OrdMap__i32__i32_rcdece3
.Lssa___sem_release_ordmap__OrdMap__i32__i32_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_ordmap__OrdMap__i32__i32_rcdeck3:
    mov x0, x19
.Lssa___sem_release_ordmap__OrdMap__i32__i32_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_drop_ordmap__Node__i32__i32
.weak __fn___sem_drop_ordmap__Node__i32__i32.k
__fn___sem_drop_ordmap__Node__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_drop_ordmap__Node__i32__i32.k:
__fn___sem_drop_ordmap__Node__i32__i32.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    str x23, [sp, #-16]!
.Lssa___sem_drop_ordmap__Node__i32__i32_0:
    mov x19, x0
    mov x20, #1
.Lssa___sem_drop_ordmap__Node__i32__i32_2:
    ldr x21, [x19, #0]
    adrp x9, .S1
    add x9, x9, :lo12:.S1
    cmp x21, x9
    b.ne .Lssa___sem_drop_ordmap__Node__i32__i32_4
.Lssa___sem_drop_ordmap__Node__i32__i32_3:
    ldr x9, [x19, #16]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck20
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd20
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck20
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece20
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd20:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck20:
    mov x0, x9
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece20:
    ldr x9, [x19, #24]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck22
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd22
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck22
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece22
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd22:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck22:
    mov x0, x9
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece22:
    ldr x9, [x19, #32]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck24
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd24
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck24
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece24
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd24:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck24:
    mov x0, x9
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece24:
    mov x23, #0
    b .Lssa___sem_drop_ordmap__Node__i32__i32_5
.Lssa___sem_drop_ordmap__Node__i32__i32_4:
    adrp x9, .S2
    add x9, x9, :lo12:.S2
    cmp x21, x9
    b.ne .Lssa___sem_drop_ordmap__Node__i32__i32_7
.Lssa___sem_drop_ordmap__Node__i32__i32_6:
    ldr x9, [x19, #16]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck29
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd29
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck29
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece29
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd29:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck29:
    mov x0, x9
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece29:
    ldr x9, [x19, #24]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck31
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd31
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck31
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece31
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd31:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck31:
    mov x0, x9
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece31:
    ldr x21, [x19, #32]
    tst x21, #1
    b.ne .Lssa___sem_drop_ordmap__Node__i32__i32_uq6
    cmp x21, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_uq6
    ldur w5, [x21, #-8]
    cmp w5, #1
.Lssa___sem_drop_ordmap__Node__i32__i32_uq6:
    b.ne .Lssa___sem_drop_ordmap__Node__i32__i32_10
.Lssa___sem_drop_ordmap__Node__i32__i32_9:
    ldr x22, [x21, #0]
    cmp x22, #0
    b.le .Lssa___sem_drop_ordmap__Node__i32__i32_13
.Lssa___sem_drop_ordmap__Node__i32__i32_12:
    mov x23, #0
.Lssa___sem_drop_ordmap__Node__i32__i32_16:
    add x9, x23, #1
    cmp x9, x22
    b.ge .Lssa___sem_drop_ordmap__Node__i32__i32_15
.Lssa___sem_drop_ordmap__Node__i32__i32_17:
    add x5, x23, #1
    ldr x0, [x21, x5, lsl #3]
    bl __fn___sem_release_ordmap__Node__i32__i32.r
    add x23, x23, #1
    b .Lssa___sem_drop_ordmap__Node__i32__i32_16
.Lssa___sem_drop_ordmap__Node__i32__i32_15:
    add x5, x23, #1
    ldr x9, [x21, x5, lsl #3]
    b .Lssa___sem_drop_ordmap__Node__i32__i32_14
.Lssa___sem_drop_ordmap__Node__i32__i32_13:
    mov x9, #0
.Lssa___sem_drop_ordmap__Node__i32__i32_14:
    mov x23, x9
    b .Lssa___sem_drop_ordmap__Node__i32__i32_11
.Lssa___sem_drop_ordmap__Node__i32__i32_10:
    mov x23, #0
.Lssa___sem_drop_ordmap__Node__i32__i32_11:
    cmp x21, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck52
    ldur w5, [x21, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd52
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck52
    mov x0, x21
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece52
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd52:
    sub w5, w5, #1
    stur w5, [x21, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck52:
    mov x0, x21
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece52:
    ldr x9, [x19, #40]
    cmp x9, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck54
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd54
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck54
    mov x0, x9
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece54
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd54:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck54:
    mov x0, x9
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece54:
    b .Lssa___sem_drop_ordmap__Node__i32__i32_5
.Lssa___sem_drop_ordmap__Node__i32__i32_7:
    mov x23, #0
.Lssa___sem_drop_ordmap__Node__i32__i32_8:
.Lssa___sem_drop_ordmap__Node__i32__i32_5:
    cmp x20, #0
    b.ne .Lssa___sem_drop_ordmap__Node__i32__i32_22
.Lssa___sem_drop_ordmap__Node__i32__i32_20:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck65
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd65
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck65
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece65
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd65:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck65:
    mov x0, x19
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece65:
.Lssa___sem_drop_ordmap__Node__i32__i32_22:
    cmp x23, #0
    b.eq .Lssa___sem_drop_ordmap__Node__i32__i32_1
.Lssa___sem_drop_ordmap__Node__i32__i32_23:
    tst x23, #1
    b.ne .Lssa___sem_drop_ordmap__Node__i32__i32_uq23
    cmp x23, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_uq23
    ldur w5, [x23, #-8]
    cmp w5, #1
.Lssa___sem_drop_ordmap__Node__i32__i32_uq23:
    b.eq .Lssa___sem_drop_ordmap__Node__i32__i32_26
.Lssa___sem_drop_ordmap__Node__i32__i32_25:
    cmp x23, #16, lsl #12
    b.lo .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck70
    ldur w5, [x23, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd70
    tbnz w5, #31, .Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck70
    mov x0, x23
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_drop_ordmap__Node__i32__i32_rcdece70
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdecd70:
    sub w5, w5, #1
    stur w5, [x23, #-8]
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdeck70:
    mov x0, x23
.Lssa___sem_drop_ordmap__Node__i32__i32_rcdece70:
    b .Lssa___sem_drop_ordmap__Node__i32__i32_1
.Lssa___sem_drop_ordmap__Node__i32__i32_26:
    mov x19, x23
    mov x20, #0
    b .Lssa___sem_drop_ordmap__Node__i32__i32_2
.Lssa___sem_drop_ordmap__Node__i32__i32_1:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #48
    ldr x23, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
.weak __fn___sem_release_ordmap__Node__i32__i32
.weak __fn___sem_release_ordmap__Node__i32__i32.k
__fn___sem_release_ordmap__Node__i32__i32:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___sem_release_ordmap__Node__i32__i32.k:
__fn___sem_release_ordmap__Node__i32__i32.r:
    cmp x0, #16, lsl #12
    b.lo .Lssa___sem_release_ordmap__Node__i32__i32_release_kept
    ldur w5, [x0, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ordmap__Node__i32__i32_release_dec
    tbz w5, #31, .Lssa___sem_release_ordmap__Node__i32__i32_release_slow
.Lssa___sem_release_ordmap__Node__i32__i32_release_kept:
    mov x0, #0
    ret
.Lssa___sem_release_ordmap__Node__i32__i32_release_dec:
    sub w5, w5, #1
    stur w5, [x0, #-8]
    mov x0, #0
    ret
.Lssa___sem_release_ordmap__Node__i32__i32_release_slow:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    str x19, [sp, #-16]!
    mov x19, x0
.Lssa___sem_release_ordmap__Node__i32__i32_0:
    tst x19, #1
    b.ne .Lssa___sem_release_ordmap__Node__i32__i32_uq0
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ordmap__Node__i32__i32_uq0
    ldur w5, [x19, #-8]
    cmp w5, #1
.Lssa___sem_release_ordmap__Node__i32__i32_uq0:
    b.ne .Lssa___sem_release_ordmap__Node__i32__i32_3
.Lssa___sem_release_ordmap__Node__i32__i32_1:
    mov x0, x19
    bl __fn___sem_drop_ordmap__Node__i32__i32.r
.Lssa___sem_release_ordmap__Node__i32__i32_3:
    cmp x19, #16, lsl #12
    b.lo .Lssa___sem_release_ordmap__Node__i32__i32_rcdeck3
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___sem_release_ordmap__Node__i32__i32_rcdecd3
    tbnz w5, #31, .Lssa___sem_release_ordmap__Node__i32__i32_rcdeck3
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___sem_release_ordmap__Node__i32__i32_rcdece3
.Lssa___sem_release_ordmap__Node__i32__i32_rcdecd3:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___sem_release_ordmap__Node__i32__i32_rcdeck3:
    mov x0, x19
.Lssa___sem_release_ordmap__Node__i32__i32_rcdece3:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #16
    ldr x19, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
_start:
    adrp x9, .Lfern_relanchor
    add x9, x9, :lo12:.Lfern_relanchor
    ldr x10, [x9]
    sub x9, x9, x10
    cbz x9, .Lfern_reloc_done
    adrp x11, .Lfern_sbox_begin
    add x11, x11, :lo12:.Lfern_sbox_begin
    adrp x12, .Lfern_sbox_end
    add x12, x12, :lo12:.Lfern_sbox_end
.Lfern_sbox_loop:
    cmp x11, x12
    b.hs .Lfern_sbox_done
    ldr x13, [x11, #8]
    add x13, x13, x9
    str x13, [x11, #8]
    add x11, x11, #24
    b .Lfern_sbox_loop
.Lfern_sbox_done:
    adrp x11, .Lfern_cagg_begin
    add x11, x11, :lo12:.Lfern_cagg_begin
    adrp x12, .Lfern_cagg_end
    add x12, x12, :lo12:.Lfern_cagg_end
.Lfern_cagg_loop:
    cmp x11, x12
    b.hs .Lfern_cagg_done
    ldr x13, [x11, #16]
    add x13, x13, x9
    str x13, [x11, #16]
    ldr x14, [x11]
    add x11, x11, #16
    add x11, x11, x14, lsl #3
    b .Lfern_cagg_loop
.Lfern_cagg_done:
    adrp x11, .Lfern_cfn_begin
    add x11, x11, :lo12:.Lfern_cfn_begin
    adrp x12, .Lfern_cfn_end
    add x12, x12, :lo12:.Lfern_cfn_end
.Lfern_cfn_loop:
    cmp x11, x12
    b.hs .Lfern_cfn_done
    ldr x13, [x11, #24]
    add x13, x13, x9
    str x13, [x11, #24]
    add x11, x11, #32
    b .Lfern_cfn_loop
.Lfern_cfn_done:
    adrp x11, .Lfern_cref_begin
    add x11, x11, :lo12:.Lfern_cref_begin
    adrp x12, .Lfern_cref_end
    add x12, x12, :lo12:.Lfern_cref_end
.Lfern_cref_loop:
    cmp x11, x12
    b.hs .Lfern_reloc_done
    ldr x13, [x11]
    add x13, x13, x9
    ldr x14, [x13]
    add x14, x14, x9
    str x14, [x13]
    add x11, x11, #8
    b .Lfern_cref_loop
.Lfern_reloc_done:
    ldr x0, [sp]
    lsl x0, x0, #3
    add x0, x0, #16
    add x0, sp, x0
    adrp x1, __fern_envp
    add x1, x1, :lo12:__fern_envp
    str x0, [x1]
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #30
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_stack_kept
    mov x19, x0
    mov x1, #1
    lsl x1, x1, #20
    mov x2, #0
    mov x8, #226
    svc #0
    cbnz x0, .Lfern_stack_guard_failed
    mov x9, #1
    lsl x9, x9, #30
    add x9, x19, x9
    sub sp, x9, #16
    mov x10, sp
    adrp x11, __fern_stack_top
    add x11, x11, :lo12:__fern_stack_top
    str x10, [x11]
.Lfern_stack_kept:
    mov x0, #0
    mov x1, #1
    lsl x1, x1, #16
    mov x2, #3
    mov x3, #0x4022
    orr x3, x3, #0x20000
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    tbnz x0, #63, .Lfern_signal_stack_map_failed
    mov x9, #1
    lsl x9, x9, #16
    sub sp, sp, #32
    stp x0, xzr, [sp]
    str x9, [sp, #16]
    mov x0, sp
    mov x1, #0
    mov x8, #132
    svc #0
    cbnz x0, .Lfern_signal_stack_failed
    adrp x9, __fern_segv
    add x9, x9, :lo12:__fern_segv
    mov x10, #4
    movk x10, #0x800, lsl #16
    mov x11, #0
    stp x9, x10, [sp]
    stp x11, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    cbnz x0, .Lfern_fault_handler_failed
    add sp, sp, #32
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    bl __fn_main
    mov x8, #94
    svc #0
    .bss
    .align 3
    .globl __fern_heap_ptr
__fern_heap_ptr: .quad 0
    .align 3
    .globl __fern_heap_end
__fern_heap_end: .quad 0
    .align 3
    .globl __fern_heap_base
__fern_heap_base: .quad 0
    .align 3
__fern_rc_underflow: .quad 0
    .align 3
__fern_map_seed: .quad 0
    .align 3
    .globl __fern_arr_push_shared
__fern_arr_push_shared: .quad 0
    .align 8
    .globl __fern_arr_push_copied
__fern_arr_push_copied: .quad 0
    .align 3
__fern_freelist: .skip 524288
    .align 8
__fern_large_freelist: .skip 20480
    .align 3
__fern_freelist_shadow: .skip 524288
    .align 3
__fern_large_freelist_shadow: .skip 20480
    .text
.globl __fern_capw
__fern_capw:
    stp x9, x10, [sp, #-32]!
    str x11, [sp, #16]
    ldr x9, [sp, #32]
    cmp x9, #256
    b.ls .Lcapw_ret
    clz x10, x9
    mov x11, #61
    sub x10, x11, x10
    mov x11, #1
    lsl x11, x11, x10
    add x9, x9, x11
    sub x9, x9, #1
    neg x11, x11
    and x9, x9, x11
    mov x10, #0x10000
    cmp x9, x10
    b.lo .Lcapw_store
    mov x9, #65535
.Lcapw_store:
    str x9, [sp, #32]
.Lcapw_ret:
    ldr x11, [sp, #16]
    ldp x9, x10, [sp], #32
    ret
.globl __fern_alloc
.type __fern_alloc, %function
__fern_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    add x0, x0, #7
    lsr x3, x0, #3
    lsl x0, x3, #3
    mov x2, #0x10000
    cmp x3, x2
    b.hs .Lalloc_large
    cmp x3, #256
    b.ls .L6
    str x3, [sp, #-16]!
    bl __fern_capw
    ldr x3, [sp], #16
.L6:
    lsl x0, x3, #3
    adrp x1, __fern_freelist
    add x1, x1, :lo12:__fern_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_large:
    mov x1, #1
    lsl x1, x1, #34
    cmp x0, x1
    b.hi .Lalloc_nofl
    mov x1, #1
    lsl x1, x1, #19
    cmp x0, x1
    csel x0, x1, x0, lo
    clz x1, x0
    mov x3, #61
    sub x3, x3, x1
    mov x1, #1
    lsl x1, x1, x3
    sub x1, x1, #1
    add x0, x0, x1
    bic x0, x0, x1
    clz x1, x0
    mov x3, #61
    sub x1, x3, x1
    lsr x3, x0, x1
    add x3, x3, x1, lsl #2
    sub x3, x3, #72
    adrp x1, __fern_large_freelist
    add x1, x1, :lo12:__fern_large_freelist
    ldr x2, [x1, x3, lsl #3]
    cbz x2, .Lalloc_nofl
    ldr x0, [x2]
    str x0, [x1, x3, lsl #3]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
.Lalloc_nofl:
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    ldr x2, [x1]
    cbnz x2, .Lalloc_inited
    stp x4, x5, [sp, #-16]!
    stp x8, x9, [sp, #-16]!
    mov x9, x0
    mov x0, #1
    lsl x0, x0, #28
    movz x1, #0
    movk x1, #4, lsl #32
    mov x2, #3
    mov x3, #0x4022
    mov x4, #0
    sub x4, x4, #1
    mov x5, #0
    mov x8, #222
    svc #0
    cmn x0, #0
    b.mi .Lalloc_map_fail
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
    str x0, [x1]
    adrp x1, __fern_heap_base
    add x1, x1, :lo12:__fern_heap_base
    str x0, [x1]
    movz x2, #0
    movk x2, #4, lsl #32
    add x2, x0, x2
    adrp x3, __fern_heap_end
    add x3, x3, :lo12:__fern_heap_end
    str x2, [x3]
    mov x0, x9
    ldp x8, x9, [sp], #16
    ldp x4, x5, [sp], #16
    adrp x1, __fern_heap_ptr
    add x1, x1, :lo12:__fern_heap_ptr
.Lalloc_inited:
    ldr x2, [x1]
    adds x3, x2, x0
    b.cs __fern_alloc_size_abort
    str x4, [sp, #-16]!
    adrp x4, __fern_heap_end
    add x4, x4, :lo12:__fern_heap_end
    ldr x4, [x4]
    cmp x3, x4
    ldr x4, [sp], #16
    b.hi .Lalloc_oom
    str x3, [x1]
    mov x0, x2
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lmsg_oom:
    .ascii "fern: out of memory (heap arena exhausted)\n"
    .text
.Lalloc_oom:
    adrp x1, .Lmsg_oom
    add x1, x1, :lo12:.Lmsg_oom
    mov x2, #43
    mov x0, #125
    b __fern_report
    .section .rodata
.Lmsg_map_fail:
    .ascii "fern: could not map the heap arena (errno "
    .text
.Lalloc_map_fail:
    neg x9, x0
    sub sp, sp, #96
    add x10, sp, #96
    mov x12, #10
    sub x10, x10, #1
    strb w12, [x10]
    mov x11, #41
    sub x10, x10, #1
    strb w11, [x10]
.Lmap_fail_digit:
    udiv x13, x9, x12
    msub x14, x13, x12, x9
    add x14, x14, #48
    sub x10, x10, #1
    strb w14, [x10]
    mov x9, x13
    cbnz x9, .Lmap_fail_digit
    adrp x15, .Lmsg_map_fail
    add x15, x15, :lo12:.Lmsg_map_fail
    add x15, x15, #42
    mov x11, #42
.Lmap_fail_copy:
    sub x15, x15, #1
    ldrb w14, [x15]
    sub x10, x10, #1
    strb w14, [x10]
    subs x11, x11, #1
    b.ne .Lmap_fail_copy
    mov x1, x10
    add x2, sp, #96
    sub x2, x2, x10
    mov x0, #123
    b __fern_report
.size __fern_alloc, .-__fern_alloc
    .section .rodata
.Lmsg_arr_oob:
    .ascii "fern: array index out of range\n"
    .text
__fern_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_oob_abort
.type __fern_oob_abort, %function
__fern_oob_abort:
    adrp x1, .Lmsg_arr_oob
    add x1, x1, :lo12:.Lmsg_arr_oob
    mov x2, #31
    b __fern_abort_134
.size __fern_oob_abort, .-__fern_oob_abort
    .section .rodata
.Lmsg_str_oob:
    .ascii "fern: string index out of range\n"
    .text
__fern_str_oob_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_str_oob_abort
.type __fern_str_oob_abort, %function
__fern_str_oob_abort:
    adrp x1, .Lmsg_str_oob
    add x1, x1, :lo12:.Lmsg_str_oob
    mov x2, #32
    b __fern_abort_134
.size __fern_str_oob_abort, .-__fern_str_oob_abort
    .section .rodata
.Lmsg_slice:
    .ascii "fern: slice range out of bounds\n"
    .text
__fern_slice_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_slice_abort
.type __fern_slice_abort, %function
__fern_slice_abort:
    adrp x1, .Lmsg_slice
    add x1, x1, :lo12:.Lmsg_slice
    mov x2, #32
    b __fern_abort_134
.size __fern_slice_abort, .-__fern_slice_abort
    .section .rodata
.Lmsg_alloc_size:
    .ascii "fern: allocation size out of range\n"
    .text
__fern_alloc_size_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_alloc_size_abort
.type __fern_alloc_size_abort, %function
__fern_alloc_size_abort:
    adrp x1, .Lmsg_alloc_size
    add x1, x1, :lo12:.Lmsg_alloc_size
    mov x2, #35
    b __fern_abort_134
.size __fern_alloc_size_abort, .-__fern_alloc_size_abort
    .section .rodata
.Lmsg_free_range:
    .ascii "fern: release of memory outside the heap\n"
    .text
.globl __fern_free_range_abort
.type __fern_free_range_abort, %function
__fern_free_range_abort:
    adrp x1, .Lmsg_free_range
    add x1, x1, :lo12:.Lmsg_free_range
    mov x2, #41
    b __fern_abort_134
.size __fern_free_range_abort, .-__fern_free_range_abort
    .section .rodata
.Lmsg_double_free:
    .ascii "fern: release of memory that is already free\n"
    .text
__fern_double_free_abort_leaf:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
.globl __fern_double_free_abort
.type __fern_double_free_abort, %function
__fern_double_free_abort:
    adrp x1, .Lmsg_double_free
    add x1, x1, :lo12:.Lmsg_double_free
    mov x2, #45
    b __fern_abort_134
.size __fern_double_free_abort, .-__fern_double_free_abort
__fern_arr_box:
    movz x1, #65535
    movk x1, #4095, lsl #16
    cmp x0, x1
    b.ls .Larrbox_sized
    b __fern_alloc_size_abort_leaf
.Larrbox_sized:
    add x1, x0, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Larrbox_alloc
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    add x1, x2, x1
    ldr x2, [x1]
    cbz x2, .Larrbox_miss
    ldr x3, [x2]
    str x3, [x1]
    str x0, [x2]
    mov w3, #1
    str w3, [x2, #8]
    str x0, [x2, #16]
    add x0, x2, #16
    ret
.Larrbox_miss:
    add x1, x0, #3
    lsl x1, x1, #3
.Larrbox_alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x0, [sp, #-16]!
    mov x0, x1
    bl __fern_alloc
    ldr x1, [sp]
    str x1, [x0]
    mov w2, #1
    str w2, [x0, #8]
    str x1, [x0, #16]
    add x0, x0, #16
    add sp, sp, #16
    ldp x29, x30, [sp], #16
    ret
__fern_str_box:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x0, x1, [sp, #-16]!
    mov x0, #24
    bl __fern_alloc
    mov x2, #1
    str x2, [x0]
    ldp x2, x3, [sp], #16
    str x2, [x0, #8]
    str x3, [x0, #16]
    add x0, x0, #8
    ldp x29, x30, [sp], #16
    ret
__fern_str_box_hdr:
    sub x2, x0, #24
    mov w3, #1
    str w3, [x2]
    mov w4, #32781
    movk w4, #29519, lsl #16
    stur w4, [x2, #4]
    str x0, [x2, #8]
    str x1, [x2, #16]
    add x0, x2, #8
    ret
__fn___alloc:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    bl __fern_alloc
    ldp x29, x30, [sp], #16
    ret
__fn___free:
    ret
__fn___memset:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    ldr x2, [x29, #48]
    cbz x2, .Lfnmemset_done
.Lfnmemset_loop:
    strb w1, [x0], #1
    subs x2, x2, #1
    bne .Lfnmemset_loop
.Lfnmemset_done:
    ldp x29, x30, [sp], #16
    ret
__fn___load_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldrsw x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_i32:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str w1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_i64:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___load_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x0, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___store_ptr:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    ldr x0, [x29, #16]
    ldr x1, [x29, #32]
    str x1, [x0]
    ldp x29, x30, [sp], #16
    ret
__fn___ptr_width:
    mov x0, #8
    ret
__fn___fern_rc_inc:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcinc_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcinc_ret
    and x0, x0, #0xfffffffffffffffd
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcinc_ret
    add w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcinc_ret:
    ldr x0, [sp]
    ret
__fn___fern_rc_dec:
    ldr x0, [sp]
    tbnz x0, #0, .Lshrcdec_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lshrcdec_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Lshrcdec_ret
    cmp w1, #0
    bgt .Lshrcdec_dec
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w11, [x10]
    add w11, w11, #1
    str w11, [x10]
.Lshrcdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
.Lshrcdec_ret:
    ret
__fn___fern_rc_is_unique:
    ldr x2, [sp]
    mov x0, #0
    tbnz x2, #0, .Lshuniq_ret
    mov x9, #0x10000
    cmp x2, x9
    blo .Lshuniq_ret
    and x2, x2, #0xfffffffffffffffd
    ldur w3, [x2, #-8]
    tbnz w3, #31, .Lshuniq_ret
    cmp w3, #1
    bne .Lshuniq_ret
    mov x0, #1
.Lshuniq_ret:
    ret
__fn___fern_arr_inc_elems:
    ldr x0, [sp]
__fn___fern_arr_inc_elems.r:
    mov x9, #0x10000
    cmp x0, x9
    blo .Laie_ret
    ldur w1, [x0, #-8]
    tbnz w1, #31, .Laie_ret
    stp x19, x30, [sp, #-16]!
    stp x20, x21, [sp, #-16]!
    mov x19, x0
    ldr x20, [x19]
    mov x21, #0
.Laie_loop:
    cmp x21, x20
    bge .Laie_done
    add x9, x21, #1
    ldr x0, [x19, x9, lsl #3]
    str x0, [sp, #-16]!
    bl __fn___fern_rc_inc
    add sp, sp, #16
    add x21, x21, #1
    b .Laie_loop
.Laie_done:
    mov x0, x19
    ldp x20, x21, [sp], #16
    ldp x19, x30, [sp], #16
.Laie_ret:
    ret
__fn___fern_alloc_reuse:
    ldr x0, [sp, #16]
    cbz x0, .Lsarelo_fresh
    ldr x1, [sp]
    ldur x2, [x0, #-16]
    cmp x2, x1
    beq .Lsarelo_ret
    stp x29, x30, [sp, #-16]!
    bl __fn___fern_arr_dec.r
    ldp x29, x30, [sp], #16
.Lsarelo_fresh:
    ldr x0, [sp]
    b __fern_arr_box
.Lsarelo_ret:
    ret
__fn___fern_rc_underflow_count:
    adrp x10, __fern_rc_underflow
    add x10, x10, :lo12:__fern_rc_underflow
    ldr w0, [x10]
    ret
__fern_large_push:
    mov x3, #1
    lsl x3, x3, #34
    cmp x2, x3
    b.hi .Llpush_ret
    mov x3, #1
    lsl x3, x3, #19
    cmp x2, x3
    csel x2, x3, x2, lo
    clz x3, x2
    mov x4, #61
    sub x4, x4, x3
    mov x3, #1
    lsl x3, x3, x4
    sub x3, x3, #1
    add x2, x2, x3
    bic x2, x2, x3
    clz x3, x2
    mov x4, #61
    sub x3, x4, x3
    lsr x4, x2, x3
    add x4, x4, x3, lsl #2
    sub x4, x4, #72
    mov x2, x4
    adrp x3, __fern_large_freelist
    add x3, x3, :lo12:__fern_large_freelist
    ldr x4, [x3, x2, lsl #3]
    cmp x4, x1
    b.eq __fern_double_free_abort_leaf
    str x4, [x1]
    str x1, [x3, x2, lsl #3]
.Llpush_ret:
    ret
__fern_raw_free:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    cbz x0, .Lrawfree_done
    adrp x9, __fern_heap_base
    add x9, x9, :lo12:__fern_heap_base
    ldr x9, [x9]
    cmp x0, x9
    b.lo .Lrawfree_bad
    adrp x9, __fern_heap_end
    add x9, x9, :lo12:__fern_heap_end
    ldr x9, [x9]
    cmp x0, x9
    b.hs .Lrawfree_bad
    add x1, x1, #7
    lsr x5, x1, #3
    cbz x5, .Lrawfree_done
    mov x9, #0x10000
    cmp x5, x9
    b.hs .Lrawfree_b_large
    cmp x5, #256
    b.ls .L7
    stp x5, x30, [sp, #-16]!
    bl __fern_capw
    ldp x5, x30, [sp], #16
.L7:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x5, lsl #3]
    cmp x10, x0
    b.eq __fern_double_free_abort
    str x10, [x0]
    str x0, [x3, x5, lsl #3]
    b .Lrawfree_b_done
.Lrawfree_b_large:
    mov x1, x0
    lsl x2, x5, #3
    bl __fern_large_push
.Lrawfree_b_done:
.Lrawfree_done:
    ldp x29, x30, [sp], #16
    ret
.Lrawfree_bad:
    b __fern_free_range_abort
__fn___fern_arr_dec:
    ldr x0, [sp]
__fn___fern_arr_dec.r:
    cmp x0, #16, lsl #12
    blo .Larrdec_ret
__fn___fern_arr_dec.u:
    ldur w1, [x0, #-8]
    cmp w1, #1
    bne .Larrdec_shared
    stur wzr, [x0, #-8]
    ldur x1, [x0, #-16]
    add x1, x1, #3
    sub x2, x0, #16
    cmp x1, #256
    b.hi .Larrdec_big
.Larrdec_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Larrdec_ret:
    ret
.Larrdec_shared:
    tbnz w1, #31, .Larrdec_ret
    bgt .Larrdec_dec
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
    ret
.Larrdec_dec:
    sub w1, w1, #1
    stur w1, [x0, #-8]
    ret
.Larrdec_big:
    mov x9, #0x10000
    cmp x1, x9
    bhs .Larrdec_large
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
    b .Larrdec_push
.Larrdec_large:
    lsl x2, x1, #3
    sub x1, x0, #16
    b __fern_large_push
__fn___fern_str_free:
    ldr x0, [sp]
__fn___fern_str_free.r:
    tbnz x0, #0, .Lstrfree_ret
    cmp x0, #16, lsl #12
    blo .Lstrfree_ret
__fn___fern_str_free.u:
    mov x9, #0x10000
    ldur w4, [x0, #-8]
    cmp w4, #1
    bne .Lstrfree_shared
    ldur w2, [x0, #-4]
    mov w3, #32781
    movk w3, #29519, lsl #16
    cmp w2, w3
    beq .Lstrfree_fused
    mov w3, #0x4F57
    movk w3, #0x4752, lsl #16
    cmp w2, w3
    beq .Lstrfree_grown
    mov w3, #0x5252
    movk w3, #0x424F, lsl #16
    cmp w2, w3
    beq .Lstrfree_box
    ldr x1, [x0]
    ldr x2, [x0, #8]
    cmp x1, x9
    blo .Lstrfree_box
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrfree_box
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrfree_box
    cmp x2, #0
    ble .Lstrfree_box
    add x2, x2, #7
    lsr x2, x2, #3
    cmp x2, x9
    bhs .Lstrfree_box
    cmp x2, #256
    b.ls .L8
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
.L8:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
.Lstrfree_box:
    stur wzr, [x0, #-8]
    sub x1, x0, #8
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
    b .Lstrfree_ret
.Lstrfree_grown:
    ldur x2, [x0, #-16]
    stur wzr, [x0, #-8]
    sub x1, x0, #16
    b .Lstrfree_block
.Lstrfree_fused:
    ldr x2, [x0, #8]
    add x2, x2, #7
    lsr x2, x2, #3
    add x2, x2, #3
    stur wzr, [x0, #-8]
    sub x1, x0, #8
.Lstrfree_block:
    cmp x2, #256
    b.hi .Lstrfree_fused_big
.Lstrfree_fused_push:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, x2, lsl #3]
    str x10, [x1]
    str x1, [x3, x2, lsl #3]
    b .Lstrfree_ret
.Lstrfree_fused_big:
    cmp x2, x9
    bhs .Lstrfree_fused_large
    stp x2, x30, [sp, #-16]!
    bl __fern_capw
    ldp x2, x30, [sp], #16
    b .Lstrfree_fused_push
.Lstrfree_fused_large:
    lsl x2, x2, #3
    b __fern_large_push
.Lstrfree_shared:
    tbnz w4, #31, .Lstrfree_ret
    blt .Lstrfree_uf
    sub w4, w4, #1
    stur w4, [x0, #-8]
    ret
.Lstrfree_uf:
    adrp x2, __fern_rc_underflow
    add x2, x2, :lo12:__fern_rc_underflow
    ldr w3, [x2]
    add w3, w3, #1
    str w3, [x2]
.Lstrfree_ret:
    ret
__fn___fern_str_view_free:
    ldr x0, [sp]
    tbnz x0, #0, .Lstrvfree_ret
    mov x9, #0x10000
    cmp x0, x9
    blo .Lstrvfree_ret
    ldur w4, [x0, #-8]
    tbnz w4, #31, .Lstrvfree_view
    b __fn___fern_str_free
.Lstrvfree_view:
    sub x1, x0, #8
    adrp x11, __fern_heap_base
    add x11, x11, :lo12:__fern_heap_base
    ldr x11, [x11]
    cmp x1, x11
    blo .Lstrvfree_ret
    adrp x12, __fern_heap_end
    add x12, x12, :lo12:__fern_heap_end
    ldr x12, [x12]
    cmp x1, x12
    bhs .Lstrvfree_ret
    stur wzr, [x0, #-8]
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x10, [x3, #24]
    str x10, [x1]
    str x1, [x3, #24]
.Lstrvfree_ret:
    ret
__fn___fern_str_arr_free:
    .cfi_startproc
    ldr x0, [sp, #0]
__fn___fern_str_arr_free.k:
__fn___fern_str_arr_free.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    str x21, [sp, #-16]!
    mov x19, x0
.Lssa___fern_str_arr_free_0:
    movz x9, #1, lsl #16
    cmp x19, x9
    b.lo .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_6:
    sub x9, x19, #8
    ldrsw x9, [x9]
    cmp x9, #1
    b.ne .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_5:
    ldrsw x20, [x19]
.Lssa___fern_str_arr_free_4:
    mov x9, #0
.Lssa___fern_str_arr_free_15:
    cmp x9, x20
    b.ge .Lssa___fern_str_arr_free_1
.Lssa___fern_str_arr_free_16:
    add x21, x9, #1
    ldr x9, [x19, x21, lsl #3]
    tbnz x9, #0, .Lssa___fern_str_arr_free_rcdeck36
    cmp x9, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck36
    ldur w5, [x9, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd36
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck36
    mov x0, x9
    bl __fn___fern_str_free.u
    b .Lssa___fern_str_arr_free_rcdece36
.Lssa___fern_str_arr_free_rcdecd36:
    sub w5, w5, #1
    stur w5, [x9, #-8]
.Lssa___fern_str_arr_free_rcdeck36:
    mov x0, x9
.Lssa___fern_str_arr_free_rcdece36:
    mov x9, x21
    cmp x9, x20
    b.lt .Lssa___fern_str_arr_free_16
.Lssa___fern_str_arr_free_1:
    cmp x19, #16, lsl #12
    b.lo .Lssa___fern_str_arr_free_rcdeck40
    ldur w5, [x19, #-8]
    cmp w5, #1
    b.gt .Lssa___fern_str_arr_free_rcdecd40
    tbnz w5, #31, .Lssa___fern_str_arr_free_rcdeck40
    mov x0, x19
    bl __fn___fern_arr_dec.u
    b .Lssa___fern_str_arr_free_rcdece40
.Lssa___fern_str_arr_free_rcdecd40:
    sub w5, w5, #1
    stur w5, [x19, #-8]
.Lssa___fern_str_arr_free_rcdeck40:
    mov x0, x19
.Lssa___fern_str_arr_free_rcdece40:
    mov x0, #0
    .cfi_remember_state
    sub sp, x29, #32
    ldr x21, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
__fn___fern_drop_arr_ptr:
    ret
    .section .bss
    .align 8
__fern_envp: .quad 0
    .section .text
    .section .data
    .balign 8
    .quad 0
    .quad -1
.Lfern_empty_u8:
    .quad 0
    .text
.globl __fern_alloc_u8
.type __fern_alloc_u8, %function
__fern_alloc_u8:
    tbz w0, #31, .Lfern_alloc_u8_sized
    b __fern_alloc_size_abort_leaf
.Lfern_alloc_u8_sized:
    cbz w0, .Lfern_alloc_u8_empty
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    mov x19, x0
    mov x0, x19
    bl __fern_arr_box
    add x2, x0, #8
    mov w1, w19
.Lfern_alloc_u8_zero:
    cbz x1, .Lfern_alloc_u8_done
    str xzr, [x2], #8
    sub x1, x1, #1
    b .Lfern_alloc_u8_zero
.Lfern_alloc_u8_done:
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lfern_alloc_u8_empty:
    adrp x0, .Lfern_empty_u8
    add x0, x0, :lo12:.Lfern_empty_u8
    ret
.size __fern_alloc_u8, .-__fern_alloc_u8
    .section .rodata
.Lmsg_stack_overflow:
    .ascii "fern: stack overflow\n"
    .text
__fern_segv:
    ldr x9, [x1, #16]
    adrp x14, __fern_stack_top
    add x14, x14, :lo12:__fern_stack_top
    ldr x14, [x14]
    cbz x14, .Lfern_segv_near_sp
    mov x15, #1
    lsl x15, x15, #30
    sub x14, x14, x15
    add x14, x14, #16
    sub x15, x9, x14
    mov x16, #1
    lsl x16, x16, #20
    cmp x15, x16
    b.lo .Lfern_segv_overflow
    b .Lfern_segv_other
.Lfern_segv_near_sp:
    ldr x10, [x2, #432]
    sub x9, x9, x10
    mov x10, #1
    lsl x10, x10, #20
    add x9, x9, x10
    lsl x10, x10, #1
    cmp x9, x10
    b.hs .Lfern_segv_other
.Lfern_segv_overflow:
    ldr x11, [x2, #440]
    ldr x12, [x2, #416]
    stp x12, x11, [sp, #-16]!
    mov x29, sp
    ldr x10, [x2, #432]
    adrp x9, __fern_bt_floor
    add x9, x9, :lo12:__fern_bt_floor
    str x10, [x9]
    adrp x1, .Lmsg_stack_overflow
    add x1, x1, :lo12:.Lmsg_stack_overflow
    mov x2, #21
    mov x0, #134
    b __fern_report
.Lfern_segv_other:
    stp x29, x30, [sp, #-16]!
    sub sp, sp, #32
    stp xzr, xzr, [sp]
    stp xzr, xzr, [sp, #16]
    mov x0, #11
    mov x1, sp
    mov x2, #0
    mov x3, #8
    mov x8, #134
    svc #0
    add sp, sp, #32
    ldp x29, x30, [sp], #16
    ret
    .section .rodata
.Lfern_stack_guard_failed_msg:
    .ascii "fern: could not protect the stack guard\n"
    .text
.Lfern_stack_guard_failed:
    adrp x1, .Lfern_stack_guard_failed_msg
    add x1, x1, :lo12:.Lfern_stack_guard_failed_msg
    mov x2, #40
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_map_failed_msg:
    .ascii "fern: could not map the signal stack\n"
    .text
.Lfern_signal_stack_map_failed:
    adrp x1, .Lfern_signal_stack_map_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_map_failed_msg
    mov x2, #37
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_signal_stack_failed_msg:
    .ascii "fern: could not install the signal stack\n"
    .text
.Lfern_signal_stack_failed:
    adrp x1, .Lfern_signal_stack_failed_msg
    add x1, x1, :lo12:.Lfern_signal_stack_failed_msg
    mov x2, #41
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
.Lfern_fault_handler_failed_msg:
    .ascii "fern: could not install the fault handler\n"
    .text
.Lfern_fault_handler_failed:
    adrp x1, .Lfern_fault_handler_failed_msg
    add x1, x1, :lo12:.Lfern_fault_handler_failed_msg
    mov x2, #42
    mov x0, #2
    mov x8, #64
    svc #0
    mov x0, #134
    mov x8, #94
    svc #0
    .section .rodata
__fern_build:
    .ascii "FERNBUILD1 target=arm64-linux profile= harden=0 pie=0 sanitize=0 backtrace=1 size=0 shared=0 heap_limit=17179869184 quarantine=67108864\n"
    .text
    .bss
    .align 3
    .globl __fern_stack_top
__fern_stack_top: .quad 0
    .align 3
__fern_bt_floor: .quad 0
    .text
.globl __fern_report
.type __fern_report, %function
__fern_abort_134:
    mov x0, #134
__fern_report:
    mov x19, x0
    mov x0, #2
    mov x8, #64
    svc #0
    b __fern_bt_exit
.size __fern_report, .-__fern_report
    .section .rodata
.Lmsg_bt:
    .ascii "backtrace:\n"
    .text
    .globl __fern_bt_exit
__fern_bt_exit:
    adrp x1, .Lmsg_bt
    add x1, x1, :lo12:.Lmsg_bt
    mov x2, #11
    mov x0, #2
    mov x8, #64
    svc #0
    mov x20, x29
    mov x21, #64
    mov x22, sp
.Lbt_loop:
    cmp x20, x22
    b.lo .Lbt_done
    and x23, x20, #7
    cbnz x23, .Lbt_done
    ldr x1, [x20, #8]
    cmp x1, #16, lsl #12
    b.lo .Lbt_done
    bl .Lbt_hex
    adrp x24, __fern_bt_floor
    add x24, x24, :lo12:__fern_bt_floor
    ldr x22, [x24]
    str xzr, [x24]
    cmp x22, #0
    csel x22, x20, x22, eq
    ldr x20, [x20]
    adrp x24, __fern_stack_top
    add x24, x24, :lo12:__fern_stack_top
    ldr x24, [x24]
    cbz x24, .Lbt_next
    cmp x20, x24
    b.hs .Lbt_done
.Lbt_next:
    subs x21, x21, #1
    b.ne .Lbt_loop
.Lbt_done:
    mov x0, x19
    mov x8, #94
    svc #0
.Lbt_hex:
    sub sp, sp, #32
    mov w2, #0x2020
    movk w2, #0x7830, lsl #16
    str w2, [sp]
    mov w2, #10
    strb w2, [sp, #20]
    mov x3, #16
    add x4, sp, #3
.Lbt_hloop:
    and x2, x1, #15
    cmp x2, #10
    add x5, x2, #87
    add x2, x2, #48
    csel x2, x5, x2, hs
    strb w2, [x4, x3]
    lsr x1, x1, #4
    subs x3, x3, #1
    b.ne .Lbt_hloop
    mov x0, #2
    mov x1, sp
    mov x2, #21
    mov x8, #64
    svc #0
    add sp, sp, #32
    ret
__fern_arr_push:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Larr_push_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Larr_push_slow_ok
    tbz w3, #31, .Larr_push_slow
.Larr_push_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Larr_push_slow:
    ldr x2, [x0]
    cbnz x2, .Larr_push_frame
    ldur x2, [x0, #-16]
    cbnz x2, .Larr_push_frame
    adrp x2, __fern_freelist
    add x2, x2, :lo12:__fern_freelist
    ldr x3, [x2, #56]
    cbz x3, .Larr_push_fresh
    ldr x4, [x3]
    str x4, [x2, #56]
    mov x2, #4
    str x2, [x3]
    mov w2, #1
    str w2, [x3, #8]
    mov x2, #1
    str x2, [x3, #16]
    str x1, [x3, #24]
    add x0, x3, #16
    ret
.Larr_push_fresh:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    str x1, [sp, #-16]!
    mov x0, #4
    bl __fern_arr_box
    ldr x1, [sp], #16
    mov x2, #1
    str x2, [x0]
    str x1, [x0, #8]
    ldp x29, x30, [sp], #16
    ret
.Larr_push_frame:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    b .Larr_push_grow
    ldur w2, [x19, #-8]
    cmp w2, #1
    b.eq .Larr_push_rc_ok
    tbnz w2, #31, .Larr_push_rc_ok
    b .Larr_push_grow
.Larr_push_rc_ok:
    cmp x21, x22
    b.ge .Larr_push_grow
    add x1, x21, #1
    str x20, [x19, x1, lsl #3]
    add x21, x21, #1
    str x21, [x19]
    mov x0, x19
    b .Larr_push_ret
.Larr_push_grow:
    mov x2, x22
    cmp x21, x22
    b.lt .Larr_push_shared_cliff
    cmp x22, #0
    b.ne .Larr_push_dbl
    mov x2, #4
    b .Larr_push_cap
.Larr_push_shared_cliff:
    adrp x3, __fern_arr_push_shared
    add x3, x3, :lo12:__fern_arr_push_shared
    ldr x4, [x3]
    add x4, x4, #1
    str x4, [x3]
    adrp x3, __fern_arr_push_copied
    add x3, x3, :lo12:__fern_arr_push_copied
    ldr x4, [x3]
    add x4, x4, x21, lsl #3
    str x4, [x3]
    b .Larr_push_cap
.Larr_push_dbl:
    lsl x2, x22, #1
.Larr_push_cap:
    add x9, x21, #1
    cmp x2, x9
    csel x2, x2, x9, hs
    mov x22, x2
    mov x0, x2
    bl __fern_arr_box
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Larr_push_copy4:
    cmp x4, #4
    b.lt .Larr_push_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Larr_push_copy4
.Larr_push_copy1:
    cbz x4, .Larr_push_copy_done
.Larr_push_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Larr_push_copy1_loop
.Larr_push_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
.Larr_push_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
__fern_arr_push_owned:
    ldr x2, [x0]
    ldur x3, [x0, #-16]
    cmp x2, x3
    b.ge .Lapo_slow
    ldur w3, [x0, #-8]
    cmp w3, #1
    b.eq .Lapo_slow_ok
    tbz w3, #31, .Lapo_slow
.Lapo_slow_ok:
    add x2, x2, #1
    str x1, [x0, x2, lsl #3]
    str x2, [x0]
    ret
.Lapo_slow:
    ldur w2, [x0, #-8]
    cmp w2, #1
    b.eq .Lapo_own
    b .Larr_push_slow
.Lapo_own:
    stp x29, x30, [sp, #-16]!
    mov x29, sp
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    mov x19, x0
    mov x20, x1
    ldr x21, [x19]
    ldur x22, [x19, #-16]
    lsl x8, x22, #1
    cbnz x8, .Lapo_cap
    mov x8, #4
.Lapo_cap:
    add x9, x21, #1
    cmp x8, x9
    csel x8, x8, x9, hs
    movz x9, #65535
    movk x9, #4095, lsl #16
    cmp x8, x9
    b.ls .Lapo_sized
    b __fern_alloc_size_abort
.Lapo_sized:
    add x1, x8, #3
    lsl x1, x1, #3
    cmp x1, #2048
    b.hi .Lapo_alloc
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    add x1, x3, x1
    ldr x3, [x1]
    cbz x3, .Lapo_miss
    ldr x4, [x3]
    str x4, [x1]
.Lapo_box:
    str x8, [x3]
    mov w4, #1
    str w4, [x3, #8]
    add x0, x3, #16
    add x1, x21, #1
    str x1, [x0]
    add x2, x19, #8
    add x3, x0, #8
    mov x4, x21
.Lapo_copy4:
    cmp x4, #4
    b.lt .Lapo_copy1
    ldp x5, x6, [x2], #16
    ldp x7, x8, [x2], #16
    stp x5, x6, [x3], #16
    stp x7, x8, [x3], #16
    sub x4, x4, #4
    b .Lapo_copy4
.Lapo_copy1:
    cbz x4, .Lapo_copy_done
.Lapo_copy1_loop:
    ldr x5, [x2], #8
    str x5, [x3], #8
    subs x4, x4, #1
    b.ne .Lapo_copy1_loop
.Lapo_copy_done:
    add x1, x21, #1
    str x20, [x0, x1, lsl #3]
    add x1, x22, #3
    mov x9, #0x10000
    cmp x1, x9
    b.hs .Lapo_large
    stur wzr, [x19, #-8]
    sub x2, x19, #16
    cmp x1, #256
    b.ls .L9
    stp x1, x30, [sp, #-16]!
    bl __fern_capw
    ldp x1, x30, [sp], #16
.L9:
    adrp x3, __fern_freelist
    add x3, x3, :lo12:__fern_freelist
    ldr x9, [x3, x1, lsl #3]
    str x9, [x2]
    str x2, [x3, x1, lsl #3]
.Lapo_ret:
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    ret
.Lapo_miss:
    add x1, x8, #3
    lsl x1, x1, #3
.Lapo_alloc:
    mov x0, x1
    bl __fern_alloc
    mov x3, x0
    b .Lapo_box
.Lapo_large:
    stur wzr, [x19, #-8]
    lsl x2, x1, #3
    sub x1, x19, #16
    bl __fern_large_push
    b .Lapo_ret
__fn___fern_arr_slice:
    .cfi_startproc
    ldr x0, [sp, #0]
    ldr x9, [sp, #16]
    ldr x10, [sp, #32]
__fn___fern_arr_slice.k:
__fn___fern_arr_slice.r:
    stp x29, x30, [sp, #-16]!
    .cfi_def_cfa_offset 16
    .cfi_offset x29, -16
    .cfi_offset x30, -8
    mov x29, sp
    .cfi_def_cfa_register x29
    stp x19, x20, [sp, #-16]!
    stp x21, x22, [sp, #-16]!
    stp x23, x24, [sp, #-16]!
    mov x19, x0
    mov x20, x9
.Lssa___fern_arr_slice_0:
    ldr x9, [x19, #0]
    mov x11, #0
    mov x12, #1
    cmp x10, #0
    csel x12, x12, x11, lt
.Lssa___fern_arr_slice_17:
    mov x13, #1
    cmp x10, x9
    csel x13, x13, x12, gt
.Lssa___fern_arr_slice_14:
    mov x9, #1
    cmp x20, #0
    csel x9, x9, x13, lt
.Lssa___fern_arr_slice_11:
    mov x12, #1
    cmp x20, x10
    csel x12, x12, x9, gt
.Lssa___fern_arr_slice_8:
    cmp x12, #1
    b.ne .Lssa___fern_arr_slice_5
.Lssa___fern_arr_slice_7:
    bl __fern_slice_abort
    mov x12, x0
.Lssa___fern_arr_slice_5:
    sub x10, x10, x20
    sxtw x21, w10
    mov x0, x21
    bl __fern_arr_box
    mov x22, x0
    add x10, x22, #8
    add x19, x19, #8
.Lssa___fern_arr_slice_4:
.Lssa___fern_arr_slice_45:
    cmp x20, #0
    b.le .Lssa___fern_arr_slice_2
.Lssa___fern_arr_slice_49:
    movz x12, #2048, lsl #16
    movz x13, #2048, lsl #16
    cmp x20, x12
    csel x13, x13, x20, gt
.Lssa___fern_arr_slice_46:
    lsl x12, x13, #3
    sxtw x12, w12
    add x19, x19, x12
    sub x20, x20, x13
    sxtw x20, w20
    cmp x20, #0
    b.gt .Lssa___fern_arr_slice_49
.Lssa___fern_arr_slice_2:
    mov x20, x10
.Lssa___fern_arr_slice_61:
    cmp x21, #0
    b.le .Lssa___fern_arr_slice_1
.Lssa___fern_arr_slice_65:
    movz x10, #2048, lsl #16
    movz x13, #2048, lsl #16
    cmp x21, x10
    csel x23, x13, x21, gt
.Lssa___fern_arr_slice_62:
    lsl x10, x23, #3
    sxtw x24, w10
    mov x2, x24
    mov x1, x19
    mov x0, x20
    cbz x2, .Lssa___fern_arr_slice_mcd211
    cmp x2, #8
    b.lo .Lssa___fern_arr_slice_mcb211
    add x9, x1, x2
    sub x9, x9, #8
    add x10, x0, x2
    sub x10, x10, #8
.Lssa___fern_arr_slice_mc211:
    cmp x0, x10
    b.hs .Lssa___fern_arr_slice_mct211
    ldr x4, [x1], #8
    str x4, [x0], #8
    b .Lssa___fern_arr_slice_mc211
.Lssa___fern_arr_slice_mct211:
    ldr x4, [x9]
    str x4, [x10]
    b .Lssa___fern_arr_slice_mcd211
.Lssa___fern_arr_slice_mcb211:
    ldrb w4, [x1], #1
    strb w4, [x0], #1
    sub x2, x2, #1
    cbnz x2, .Lssa___fern_arr_slice_mcb211
.Lssa___fern_arr_slice_mcd211:
    mov x0, #0
    add x20, x20, x24
    add x19, x19, x24
    sub x21, x21, x23
    sxtw x21, w21
    cmp x21, #0
    b.gt .Lssa___fern_arr_slice_65
.Lssa___fern_arr_slice_1:
    mov x0, x22
    .cfi_remember_state
    sub sp, x29, #48
    ldp x23, x24, [sp], #16
    ldp x21, x22, [sp], #16
    ldp x19, x20, [sp], #16
    ldp x29, x30, [sp], #16
    .cfi_def_cfa sp, 0
    ret
    .cfi_restore_state
    .cfi_endproc
    .ltorg
    .section .rodata
.S0: .ascii "ordmap__OrdMap__i32__i32"
.S1: .ascii "ordmap__Node__i32__i32$ordmap__Leaf__i32__i32"
.S2: .ascii "ordmap__Node__i32__i32$ordmap__Branch__i32__i32"
    .section .data
    .align 8
.Lfern_relanchor:
    .quad .Lfern_relanchor
    .section .data.rel.ro
    .align 8
.Lfern_sbox_begin:
    .section .data.rel.ro
    .align 8
    .quad -1
.SB0:
    .quad .S0
    .quad 24
    .quad -1
.SB1:
    .quad .S1
    .quad 45
    .quad -1
.SB2:
    .quad .S2
    .quad 47
.Lfern_sbox_end:
    .section .data
    .align 8
    .quad 0
    .quad -1
.K0:
    .quad 0
    .section .data.rel.ro
    .align 8
.Lfern_cagg_begin:
    .section .data.rel.ro
    .align 8
    .quad 5
    .quad -1
.K1:
    .quad .S1
    .quad 0
.K1_1:
    .quad .K0
.K1_2:
    .quad .K0
.K1_3:
    .quad .K0
    .quad 2
    .quad -1
.K2:
    .quad .S0
.K2_0:
    .quad .K1
.Lfern_cagg_end:
    .align 8
.Lfern_cfn_begin:
.Lfern_cfn_end:
    .align 8
.Lfern_cref_begin:
    .quad .K1_1
    .quad .K1_2
    .quad .K1_3
    .quad .K2_0
.Lfern_cref_end:
    .text
